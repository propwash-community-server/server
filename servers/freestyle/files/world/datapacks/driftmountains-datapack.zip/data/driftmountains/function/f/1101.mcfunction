scoreboard players set #gx driftmountains -58229
scoreboard players set #gdx driftmountains -1165
scoreboard players set #gy driftmountains 70513
scoreboard players set #gdy driftmountains 3
scoreboard players set #gz driftmountains 42817
scoreboard players set #gdz driftmountains -728
scoreboard players set #gr driftmountains 17070
scoreboard players set #gdr driftmountains 185
scoreboard players set #gp driftmountains -11
scoreboard players set #gdp driftmountains 6
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.3150f,0.3897f,-0.0818f,0.8615f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.1728f,0.8749f,0.2758f,-0.3587f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.8262f,0.0108f,0.0074f,0.5632f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0074f,0.5632f,0.8262f,0.0108f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3666f,0.8230f,0.0905f],left_rotation:[-0.1563f,-0.0909f,0.5147f,-0.8380f]}}
particle minecraft:cloud -58.85 70.83 44.20 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -58.85 70.63 44.20 0.013 0.02 0.081 1 0 force
particle minecraft:cloud -57.20 70.83 43.93 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -48187
scoreboard players set #gdx driftmountains -1239
scoreboard players set #gy driftmountains 70468
scoreboard players set #gdy driftmountains 2
scoreboard players set #gz driftmountains 47566
scoreboard players set #gdz driftmountains -561
scoreboard players set #gr driftmountains 15740
scoreboard players set #gdr driftmountains 103
scoreboard players set #gp driftmountains -3
scoreboard players set #gdp driftmountains -7
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.4211f,-0.2937f,-0.2115f,-0.8317f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.1253f,-0.8140f,0.4543f,0.3396f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.8262f,0.0108f,0.0074f,0.5632f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0074f,0.5632f,0.8262f,0.0108f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3716f,0.8289f,0.2329f],left_rotation:[-0.1758f,-0.0316f,0.1870f,-0.9660f]}}
particle minecraft:cloud -48.45 70.79 49.15 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -48.45 70.59 49.15 0.031 0.02 0.075 1 0 force
particle minecraft:cloud -46.87 70.79 48.50 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -43597
scoreboard players set #gdx driftmountains -1236
scoreboard players set #gy driftmountains 70489
scoreboard players set #gdy driftmountains -11
scoreboard players set #gz driftmountains 50066
scoreboard players set #gdz driftmountains -499
scoreboard players set #gr driftmountains 15538
scoreboard players set #gdr driftmountains 36
scoreboard players set #gp driftmountains 41
scoreboard players set #gdp driftmountains -15
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.9081f,0.1338f,-0.3411f,0.2028f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.3643f,0.2398f,0.8990f,-0.0390f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.8262f,0.0108f,0.0074f,0.5632f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0074f,0.5632f,0.8262f,0.0108f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3554f,0.8326f,0.0943f],left_rotation:[-0.1806f,-0.0366f,0.2292f,-0.9557f]}}
particle minecraft:cloud -43.83 70.81 51.56 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -43.83 70.61 51.56 0.033 0.02 0.072 1 0 force
particle minecraft:cloud -42.31 70.81 50.86 0.35 0.18 0.35 0.02 3 force
