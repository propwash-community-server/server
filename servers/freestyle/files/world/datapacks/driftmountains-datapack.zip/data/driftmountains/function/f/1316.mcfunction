scoreboard players set #gx driftmountains -45662
scoreboard players set #gdx driftmountains 575
scoreboard players set #gy driftmountains 67662
scoreboard players set #gdy driftmountains -13
scoreboard players set #gz driftmountains -88723
scoreboard players set #gdz driftmountains -427
scoreboard players set #gr driftmountains -9290
scoreboard players set #gdr driftmountains 235
scoreboard players set #gp driftmountains 86
scoreboard players set #gdp driftmountains 2
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[0.0061f,0.0001f,-0.0212f,0.9998f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.8077f,-0.0880f,-0.2304f,-0.5355f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.1754f,-0.5142f,0.8214f,0.1734f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.7590f,0.0099f,-0.0085f,-0.6510f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0085f,-0.6510f,0.7590f,0.0099f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3827f,0.8659f,0.1073f],left_rotation:[-0.1172f,0.1514f,-0.7865f,-0.5871f]}}
particle minecraft:cloud -46.96 67.98 -89.49 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -46.96 67.78 -89.49 -0.043 0.02 0.002 1 0 force
particle minecraft:cloud -46.88 67.98 -87.82 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -49485
scoreboard players set #gdx driftmountains 494
scoreboard players set #gy driftmountains 67750
scoreboard players set #gdy driftmountains -12
scoreboard players set #gz driftmountains -85235
scoreboard players set #gdz driftmountains -576
scoreboard players set #gr driftmountains -10531
scoreboard players set #gdr driftmountains 162
scoreboard players set #gp driftmountains 75
scoreboard players set #gdp driftmountains 1
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[0.0059f,0.0001f,-0.0213f,0.9998f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.8855f,-0.0514f,-0.2535f,-0.3859f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.2143f,-0.3614f,0.8958f,0.1448f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.7590f,0.0099f,-0.0085f,-0.6510f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0085f,-0.6510f,0.7590f,0.0099f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3637f,0.8679f,0.2483f],left_rotation:[-0.1272f,0.1424f,-0.7123f,-0.6754f]}}
particle minecraft:cloud -51.03 68.07 -85.70 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -51.03 67.87 -85.70 -0.045 0.02 0.012 1 0 force
particle minecraft:cloud -50.58 68.07 -84.05 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -52046
scoreboard players set #gdx driftmountains 331
scoreboard players set #gy driftmountains 67846
scoreboard players set #gdy driftmountains -13
scoreboard players set #gz driftmountains -80019
scoreboard players set #gdz driftmountains -643
scoreboard players set #gr driftmountains -12300
scoreboard players set #gdr driftmountains 130
scoreboard players set #gp driftmountains 87
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0001f,-0.0185f,0.9998f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.5550f,0.2180f,-0.0861f,0.7982f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.1704f,0.8116f,0.5351f,-0.1608f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.7590f,0.0099f,-0.0085f,-0.6510f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0085f,-0.6510f,0.7590f,0.0099f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3881f,0.8640f,0.1066f],left_rotation:[-0.0991f,0.1627f,-0.8504f,-0.4903f]}}
particle minecraft:cloud -53.56 68.17 -80.03 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -53.56 67.97 -80.03 -0.036 0.02 0.024 1 0 force
particle minecraft:cloud -52.65 68.17 -78.63 0.35 0.18 0.35 0.02 3 force
