scoreboard players set #gx driftmountains -77626
scoreboard players set #gdx driftmountains 628
scoreboard players set #gy driftmountains 69324
scoreboard players set #gdy driftmountains -10
scoreboard players set #gz driftmountains -27670
scoreboard players set #gdz driftmountains -213
scoreboard players set #gr driftmountains -12754
scoreboard players set #gdr driftmountains -3
scoreboard players set #gp driftmountains 79
scoreboard players set #gdp driftmountains -2
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,0.0000f,0.0119f,0.9999f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.7629f,-0.0367f,0.1268f,0.6329f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[-0.0610f,0.6231f,0.7709f,0.1171f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.8346f,0.0109f,0.0072f,0.5507f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0072f,0.5507f,0.8346f,0.0109f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3908f,0.8625f,0.1060f],left_rotation:[0.0889f,-0.1679f,0.8799f,0.4354f]}}
particle minecraft:cloud -79.13 69.64 -27.56 0.35 0.18 0.35 0.02 2 force
particle minecraft:cloud -78.12 69.64 -26.24 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -78.12 69.44 -26.24 -0.031 0.02 0.024 1 0 force
scoreboard players set #gx driftmountains -83768
scoreboard players set #gdx driftmountains 604
scoreboard players set #gy driftmountains 69431
scoreboard players set #gdy driftmountains -13
scoreboard players set #gz driftmountains -27246
scoreboard players set #gdz driftmountains -121
scoreboard players set #gr driftmountains -8165
scoreboard players set #gdr driftmountains -389
scoreboard players set #gp driftmountains 114
scoreboard players set #gdp driftmountains -3
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0000f,-0.0123f,0.9999f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.1840f,-0.0936f,-0.0712f,-0.9759f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[-0.0310f,-0.9738f,0.1948f,0.1134f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.8346f,0.0109f,0.0072f,0.5507f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0072f,0.5507f,0.8346f,0.0109f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.4041f,0.8412f,0.2378f],left_rotation:[0.0997f,0.1538f,-0.8031f,0.5670f]}}
particle minecraft:cloud -84.99 69.75 -28.29 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -84.99 69.55 -28.29 -0.036 0.02 -0.005 1 0 force
particle minecraft:cloud -85.24 69.75 -26.60 0.35 0.18 0.35 0.02 2 force
scoreboard players set #gx driftmountains -87322
scoreboard players set #gdx driftmountains 147
scoreboard players set #gy driftmountains 69539
scoreboard players set #gdy driftmountains -4
scoreboard players set #gz driftmountains -25091
scoreboard players set #gdz driftmountains -80
scoreboard players set #gr driftmountains -7198
scoreboard players set #gdr driftmountains 25
scoreboard players set #gp driftmountains 102
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.0755f,0.3324f,0.0289f,0.9397f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.0697f,0.9418f,0.0410f,-0.3263f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.8346f,0.0109f,0.0072f,0.5507f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0072f,0.5507f,0.8346f,0.0109f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3525f,0.8468f,0.0998f],left_rotation:[-0.1870f,0.0224f,-0.0845f,-0.9784f]}}
particle minecraft:cloud -88.26 69.86 -26.27 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -88.26 69.66 -26.27 -0.009 0.02 -0.003 1 0 force
particle minecraft:cloud -88.78 69.86 -24.69 0.35 0.18 0.35 0.02 3 force
