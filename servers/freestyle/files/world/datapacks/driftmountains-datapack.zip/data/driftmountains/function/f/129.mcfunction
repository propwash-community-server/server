scoreboard players set #gx driftmountains 9364
scoreboard players set #gdx driftmountains 465
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains -10308
scoreboard players set #gdz driftmountains 833
scoreboard players set #gr driftmountains 916
scoreboard players set #gdr driftmountains 23
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.6952f,0.2587f,-0.1993f,0.6404f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.2677f,0.6648f,0.6718f,-0.1871f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.2045f,0.0027f,0.0128f,0.9788f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0128f,0.9788f,0.2045f,0.0027f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3532f,0.8499f,0.1010f],left_rotation:[-0.1859f,0.0350f,-0.1522f,-0.9700f]}}
particle minecraft:cloud 10.39 71.32 -11.42 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 10.39 71.12 -11.42 0.009 0.02 -0.056 1 0 force
particle minecraft:cloud 8.74 71.32 -11.68 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains 6393
scoreboard players set #gdx driftmountains 421
scoreboard players set #gy driftmountains 70925
scoreboard players set #gdy driftmountains 38
scoreboard players set #gz driftmountains -15725
scoreboard players set #gdz driftmountains 794
scoreboard players set #gr driftmountains 1333
scoreboard players set #gdr driftmountains -90
scoreboard players set #gp driftmountains -207
scoreboard players set #gdp driftmountains 50
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.1005f,0.3497f,0.0184f,0.9313f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.0794f,0.9345f,0.0643f,-0.3410f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.2045f,0.0027f,0.0128f,0.9788f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0128f,0.9788f,0.2045f,0.0027f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3664f,0.8315f,0.2340f],left_rotation:[-0.1791f,-0.0094f,0.0738f,-0.9810f]}}
particle minecraft:cloud 7.54 71.25 -16.86 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 7.54 71.05 -16.86 0.012 0.02 -0.052 1 0 force
particle minecraft:cloud 5.88 71.25 -17.25 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains 3615
scoreboard players set #gdx driftmountains 473
scoreboard players set #gy driftmountains 70573
scoreboard players set #gdy driftmountains 58
scoreboard players set #gz driftmountains -20104
scoreboard players set #gdz driftmountains 654
scoreboard players set #gr driftmountains 779
scoreboard players set #gdr driftmountains 219
scoreboard players set #gp driftmountains -258
scoreboard players set #gdp driftmountains -48
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.8644f,0.1798f,-0.2669f,0.3863f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.3090f,0.4165f,0.8503f,-0.0899f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.2045f,0.0027f,0.0128f,0.9788f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0128f,0.9788f,0.2045f,0.0027f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3539f,0.8519f,0.1018f],left_rotation:[-0.1846f,0.0433f,-0.1969f,-0.9619f]}}
particle minecraft:cloud 4.61 70.89 -21.24 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 4.61 70.69 -21.24 0.007 0.02 -0.051 1 0 force
particle minecraft:cloud 2.96 70.89 -21.47 0.35 0.18 0.35 0.02 3 force
