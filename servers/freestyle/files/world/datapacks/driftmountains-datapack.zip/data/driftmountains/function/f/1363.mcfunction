scoreboard players set #gx driftmountains -14820
scoreboard players set #gdx driftmountains 746
scoreboard players set #gy driftmountains 67067
scoreboard players set #gdy driftmountains -10
scoreboard players set #gz driftmountains -81116
scoreboard players set #gdz driftmountains 471
scoreboard players set #gr driftmountains -3447
scoreboard players set #gdr driftmountains -102
scoreboard players set #gp driftmountains 62
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0001f,-0.0142f,0.9999f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.0631f,0.2018f,0.0405f,0.9765f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.0619f,0.9777f,0.0423f,-0.1963f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.7551f,0.0099f,0.0086f,0.6555f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0086f,0.6555f,0.7551f,0.0099f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3978f,0.8556f,0.1033f],left_rotation:[-0.0525f,0.1801f,-0.9519f,-0.2422f]}}
particle minecraft:cloud -14.84 67.39 -82.63 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -14.84 67.19 -82.63 -0.030 0.02 -0.044 1 0 force
particle minecraft:cloud -16.22 67.39 -81.68 0.35 0.18 0.35 0.02 2 force
scoreboard players set #gx driftmountains -21392
scoreboard players set #gdx driftmountains 722
scoreboard players set #gy driftmountains 67159
scoreboard players set #gdy driftmountains -11
scoreboard players set #gz driftmountains -84753
scoreboard players set #gdz driftmountains 438
scoreboard players set #gr driftmountains -3075
scoreboard players set #gdr driftmountains 13
scoreboard players set #gp driftmountains 65
scoreboard players set #gdp driftmountains -1
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0001f,-0.0172f,0.9998f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.4954f,-0.1738f,-0.1658f,-0.8348f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.0789f,-0.8220f,0.5164f,0.2269f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.7551f,0.0099f,0.0086f,0.6555f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0086f,0.6555f,0.7551f,0.0099f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3711f,0.8725f,0.2500f],left_rotation:[-0.1027f,0.1628f,-0.8202f,-0.5388f]}}
particle minecraft:cloud -21.35 67.48 -86.36 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -21.35 67.28 -86.36 -0.026 0.02 -0.043 1 0 force
particle minecraft:cloud -22.82 67.48 -85.49 0.35 0.18 0.35 0.02 2 force
scoreboard players set #gx driftmountains -28435
scoreboard players set #gdx driftmountains 743
scoreboard players set #gy driftmountains 67274
scoreboard players set #gdy driftmountains -12
scoreboard players set #gz driftmountains -89300
scoreboard players set #gdz driftmountains 367
scoreboard players set #gr driftmountains -3446
scoreboard players set #gdr driftmountains 48
scoreboard players set #gp driftmountains 74
scoreboard players set #gdp driftmountains -1
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0001f,-0.0181f,0.9998f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.8701f,0.1525f,-0.1870f,0.4298f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.2332f,0.4519f,0.8588f,-0.0619f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.7551f,0.0099f,0.0086f,0.6555f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0086f,0.6555f,0.7551f,0.0099f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3851f,0.8652f,0.1071f],left_rotation:[-0.1095f,0.1566f,-0.8157f,-0.5460f]}}
particle minecraft:cloud -28.46 67.59 -90.81 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -28.46 67.39 -90.81 -0.025 0.02 -0.036 1 0 force
particle minecraft:cloud -29.84 67.59 -89.87 0.35 0.18 0.35 0.02 2 force
