scoreboard players set #gx driftmountains -79981
scoreboard players set #gdx driftmountains -845
scoreboard players set #gy driftmountains 70101
scoreboard players set #gdy driftmountains -20
scoreboard players set #gz driftmountains 21792
scoreboard players set #gdz driftmountains -977
scoreboard players set #gr driftmountains 17824
scoreboard players set #gdr driftmountains -247
scoreboard players set #gp driftmountains 72
scoreboard players set #gdp driftmountains -2
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.7199f,0.2560f,-0.2174f,0.6074f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.2825f,0.6336f,0.6970f,-0.1818f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.9917f,0.0130f,0.0017f,0.1281f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0017f,0.1281f,0.9917f,0.0130f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3524f,0.8458f,0.0994f],left_rotation:[-0.1872f,0.0184f,-0.0633f,-0.9801f]}}
particle minecraft:cloud -80.78 70.42 23.08 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -80.78 70.22 23.08 0.002 0.02 0.078 1 0 force
particle minecraft:cloud -79.11 70.42 23.03 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -72615
scoreboard players set #gdx driftmountains -964
scoreboard players set #gy driftmountains 70294
scoreboard players set #gdy driftmountains -26
scoreboard players set #gz driftmountains 29522
scoreboard players set #gdz driftmountains -1000
scoreboard players set #gr driftmountains 17559
scoreboard players set #gdr driftmountains -21
scoreboard players set #gp driftmountains 83
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.0503f,0.3367f,0.0376f,0.9395f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.0609f,0.9407f,0.0151f,-0.3333f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.9917f,0.0130f,0.0017f,0.1281f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0017f,0.1281f,0.9917f,0.0130f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3622f,0.8349f,0.2353f],left_rotation:[-0.1800f,0.0119f,-0.0353f,-0.9830f]}}
particle minecraft:cloud -73.36 70.61 30.95 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -73.36 70.41 30.95 0.006 0.02 0.083 1 0 force
particle minecraft:cloud -71.66 70.61 30.82 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -68535
scoreboard players set #gdx driftmountains -921
scoreboard players set #gy driftmountains 70399
scoreboard players set #gdy driftmountains -23
scoreboard players set #gz driftmountains 33625
scoreboard players set #gdz driftmountains -981
scoreboard players set #gr driftmountains -17966
scoreboard players set #gdr driftmountains -66
scoreboard players set #gp driftmountains 71
scoreboard players set #gdp driftmountains 3
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.8863f,-0.0559f,-0.3660f,-0.2781f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.3388f,-0.2412f,0.8971f,0.1494f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.9917f,0.0130f,0.0017f,0.1281f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0017f,0.1281f,0.9917f,0.0130f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3564f,0.8311f,0.0937f],left_rotation:[-0.1786f,-0.0435f,0.2656f,-0.9463f]}}
particle minecraft:cloud -69.38 70.72 34.88 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -69.38 70.52 34.88 -0.000 0.02 0.081 1 0 force
particle minecraft:cloud -67.71 70.72 34.89 0.35 0.18 0.35 0.02 3 force
