scoreboard players set #gx driftmountains -12565
scoreboard players set #gdx driftmountains 762
scoreboard players set #gy driftmountains 67036
scoreboard players set #gdy driftmountains -10
scoreboard players set #gz driftmountains -79687
scoreboard players set #gdz driftmountains 487
scoreboard players set #gr driftmountains -3754
scoreboard players set #gdr driftmountains -106
scoreboard players set #gp driftmountains 62
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0000f,-0.0122f,0.9999f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.7382f,0.1523f,-0.0924f,0.6506f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.1613f,0.6639f,0.7263f,-0.0755f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.9979f,0.0131f,-0.0008f,-0.0631f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0008f,-0.0631f,0.9979f,0.0131f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.4013f,0.8440f,0.0987f],left_rotation:[-0.0033f,0.1841f,-0.9827f,0.0173f]}}
particle minecraft:cloud -12.67 67.36 -81.20 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -12.67 67.16 -81.20 -0.033 0.02 -0.043 1 0 force
particle minecraft:cloud -13.99 67.36 -80.18 0.35 0.18 0.35 0.02 2 force
scoreboard players set #gx driftmountains -19218
scoreboard players set #gdx driftmountains 735
scoreboard players set #gy driftmountains 67127
scoreboard players set #gdy driftmountains -11
scoreboard players set #gz driftmountains -83422
scoreboard players set #gdz driftmountains 457
scoreboard players set #gr driftmountains -3066
scoreboard players set #gdr driftmountains -34
scoreboard players set #gp driftmountains 63
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0001f,-0.0168f,0.9999f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.1593f,0.2384f,0.0149f,0.9579f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.0857f,0.9616f,0.1352f,-0.2230f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.9979f,0.0131f,-0.0008f,-0.0631f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0008f,-0.0631f,0.9979f,0.0131f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3718f,0.8727f,0.2501f],left_rotation:[-0.1008f,0.1641f,-0.8271f,-0.5281f]}}
particle minecraft:cloud -19.18 67.45 -85.03 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -19.18 67.25 -85.03 -0.026 0.02 -0.044 1 0 force
particle minecraft:cloud -20.65 67.45 -84.16 0.35 0.18 0.35 0.02 2 force
scoreboard players set #gx driftmountains -26406
scoreboard players set #gdx driftmountains 694
scoreboard players set #gy driftmountains 67241
scoreboard players set #gdy driftmountains -11
scoreboard players set #gz driftmountains -88274
scoreboard players set #gdz driftmountains 367
scoreboard players set #gr driftmountains -3332
scoreboard players set #gdr driftmountains 40
scoreboard players set #gp driftmountains 71
scoreboard players set #gdp driftmountains -1
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0001f,-0.0178f,0.9998f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.9598f,0.0880f,-0.2248f,0.1432f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.2411f,0.1676f,0.9558f,0.0124f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.9979f,0.0131f,-0.0008f,-0.0631f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0008f,-0.0631f,0.9979f,0.0131f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3851f,0.8652f,0.1071f],left_rotation:[-0.1097f,0.1565f,-0.8151f,-0.5469f]}}
particle minecraft:cloud -26.40 67.56 -89.79 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -26.40 67.36 -89.79 -0.026 0.02 -0.039 1 0 force
particle minecraft:cloud -27.80 67.56 -88.87 0.35 0.18 0.35 0.02 2 force
