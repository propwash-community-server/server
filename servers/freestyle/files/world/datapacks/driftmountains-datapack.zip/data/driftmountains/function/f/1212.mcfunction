scoreboard players set #gx driftmountains -71143
scoreboard players set #gdx driftmountains 689
scoreboard players set #gy driftmountains 69231
scoreboard players set #gdy driftmountains -10
scoreboard players set #gz driftmountains -30195
scoreboard players set #gdz driftmountains -258
scoreboard players set #gr driftmountains -11507
scoreboard players set #gdr driftmountains 0
scoreboard players set #gp driftmountains 75
scoreboard players set #gdp driftmountains 1
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,0.0000f,0.0026f,1.0000f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.9210f,0.0686f,0.0285f,-0.3825f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[-0.0688f,-0.3876f,0.9188f,0.0278f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.9964f,0.0130f,0.0011f,0.0840f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0011f,0.0840f,0.9964f,0.0130f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3620f,0.8620f,0.1058f],left_rotation:[0.1687f,-0.0913f,0.4559f,0.8691f]}}
scoreboard players set #gx driftmountains -77528
scoreboard players set #gdx driftmountains 745
scoreboard players set #gy driftmountains 69321
scoreboard players set #gdy driftmountains -11
scoreboard players set #gz driftmountains -28852
scoreboard players set #gdz driftmountains -308
scoreboard players set #gr driftmountains -13151
scoreboard players set #gdr driftmountains 38
scoreboard players set #gp driftmountains 76
scoreboard players set #gdp driftmountains -2
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[-0.0039f,0.0000f,0.0120f,0.9999f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.1615f,-0.1184f,0.0731f,0.9770f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.0292f,0.9747f,0.1748f,0.1360f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.9964f,0.0130f,0.0011f,0.0840f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0011f,0.0840f,0.9964f,0.0130f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3805f,0.8743f,0.2508f],left_rotation:[0.0730f,-0.1789f,0.9071f,0.3740f]}}
particle minecraft:cloud -79.12 69.64 -28.59 0.35 0.18 0.35 0.02 2 force
particle minecraft:cloud -77.98 69.64 -27.31 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -77.98 69.44 -27.31 -0.031 0.02 0.027 1 0 force
scoreboard players set #gx driftmountains -82464
scoreboard players set #gdx driftmountains 669
scoreboard players set #gy driftmountains 69410
scoreboard players set #gdy driftmountains -13
scoreboard players set #gz driftmountains -26520
scoreboard players set #gdz driftmountains -75
scoreboard players set #gr driftmountains -8490
scoreboard players set #gdr driftmountains -520
scoreboard players set #gp driftmountains 112
scoreboard players set #gdp driftmountains -5
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0000f,-0.0071f,1.0000f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.9884f,0.0625f,-0.0888f,0.1066f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.1005f,0.1165f,0.9872f,0.0411f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.9964f,0.0130f,0.0011f,0.0840f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0011f,0.0840f,0.9964f,0.0130f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3816f,0.8214f,0.0899f],left_rotation:[0.1168f,0.1359f,-0.7477f,0.6393f]}}
particle minecraft:cloud -83.64 69.73 -27.46 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -83.64 69.53 -27.46 -0.040 0.02 -0.004 1 0 force
particle minecraft:cloud -83.79 69.73 -25.80 0.35 0.18 0.35 0.02 2 force
