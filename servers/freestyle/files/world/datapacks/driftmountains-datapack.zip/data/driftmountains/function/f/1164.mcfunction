scoreboard players set #gx driftmountains -97482
scoreboard players set #gdx driftmountains 233
scoreboard players set #gy driftmountains 69919
scoreboard players set #gdy driftmountains -15
scoreboard players set #gz driftmountains -14028
scoreboard players set #gdz driftmountains -705
scoreboard players set #gr driftmountains -11367
scoreboard players set #gdr driftmountains 313
scoreboard players set #gp driftmountains 73
scoreboard players set #gdp driftmountains 3
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.2360f,0.3325f,-0.0287f,0.9126f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.1248f,0.9207f,0.2024f,-0.3095f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.9994f,0.0131f,-0.0004f,-0.0332f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0004f,-0.0332f,0.9994f,0.0131f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3525f,0.8467f,0.0998f],left_rotation:[-0.1871f,0.0223f,-0.0839f,-0.9785f]}}
particle minecraft:cloud -98.97 70.24 -14.29 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -98.97 70.04 -14.29 -0.041 0.02 0.018 1 0 force
particle minecraft:cloud -98.30 70.24 -12.76 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -98122
scoreboard players set #gdx driftmountains -47
scoreboard players set #gy driftmountains 70021
scoreboard players set #gdy driftmountains -6
scoreboard players set #gz driftmountains -6642
scoreboard players set #gdz driftmountains -841
scoreboard players set #gr driftmountains -13506
scoreboard players set #gdr driftmountains 207
scoreboard players set #gp driftmountains 24
scoreboard players set #gdp driftmountains 6
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.1708f,0.3699f,-0.0120f,0.9132f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.1080f,0.9194f,0.1329f,-0.3540f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.9994f,0.0131f,-0.0004f,-0.0332f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0004f,-0.0332f,0.9994f,0.0131f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3754f,0.8277f,0.2325f],left_rotation:[-0.1721f,-0.0466f,0.2636f,-0.9480f]}}
particle minecraft:cloud -99.69 70.34 -6.28 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -99.69 70.14 -6.28 -0.035 0.02 0.035 1 0 force
particle minecraft:cloud -98.48 70.34 -5.07 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -97260
scoreboard players set #gdx driftmountains -248
scoreboard players set #gy driftmountains 70033
scoreboard players set #gdy driftmountains 1
scoreboard players set #gz driftmountains -1397
scoreboard players set #gdz driftmountains -931
scoreboard players set #gr driftmountains -14444
scoreboard players set #gdr driftmountains 209
scoreboard players set #gp driftmountains -4
scoreboard players set #gdp driftmountains 4
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[0.0041f,0.0001f,-0.0223f,0.9997f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.7788f,-0.1564f,-0.3512f,-0.4957f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.3010f,-0.4615f,0.7995f,0.2391f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.9994f,0.0131f,-0.0004f,-0.0332f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0004f,-0.0332f,0.9994f,0.0131f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3610f,0.8264f,0.0918f],left_rotation:[-0.1689f,-0.0681f,0.3953f,-0.9002f]}}
particle minecraft:cloud -98.67 70.35 -0.86 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -98.67 70.15 -0.86 -0.031 0.02 0.044 1 0 force
particle minecraft:cloud -97.31 70.35 0.11 0.35 0.18 0.35 0.02 3 force
