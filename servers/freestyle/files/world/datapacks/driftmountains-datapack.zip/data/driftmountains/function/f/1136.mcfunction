scoreboard players set #gx driftmountains -90098
scoreboard players set #gdx driftmountains -709
scoreboard players set #gy driftmountains 69985
scoreboard players set #gdy driftmountains 3
scoreboard players set #gz driftmountains 9832
scoreboard players set #gdz driftmountains -846
scoreboard players set #gr driftmountains 17953
scoreboard players set #gdr driftmountains 99
scoreboard players set #gp driftmountains -10
scoreboard players set #gdp driftmountains -3
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.7712f,-0.1469f,-0.3080f,-0.5374f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.2533f,-0.5079f,0.7909f,0.2287f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.4096f,0.0054f,-0.0119f,-0.9122f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0119f,-0.9122f,0.4096f,0.0054f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3523f,0.8434f,0.0985f],left_rotation:[-0.1873f,0.0088f,-0.0118f,-0.9821f]}}
particle minecraft:cloud -90.92 70.31 11.10 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -90.92 70.11 11.10 0.001 0.02 0.067 1 0 force
particle minecraft:cloud -89.25 70.31 11.09 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -84145
scoreboard players set #gdx driftmountains -721
scoreboard players set #gy driftmountains 70016
scoreboard players set #gdy driftmountains -10
scoreboard players set #gz driftmountains 17017
scoreboard players set #gdz driftmountains -833
scoreboard players set #gr driftmountains 17447
scoreboard players set #gdr driftmountains 28
scoreboard players set #gp driftmountains 47
scoreboard players set #gdp driftmountains -7
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.9319f,0.1160f,-0.2801f,0.1992f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.3025f,0.2297f,0.9248f,-0.0186f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.4096f,0.0054f,-0.0119f,-0.9122f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0119f,-0.9122f,0.4096f,0.0054f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3557f,0.8498f,0.2411f],left_rotation:[-0.1686f,0.0762f,-0.3668f,-0.9117f]}}
particle minecraft:cloud -84.86 70.34 18.46 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -84.86 70.14 18.46 0.007 0.02 0.071 1 0 force
particle minecraft:cloud -83.16 70.34 18.29 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -79896
scoreboard players set #gdx driftmountains -803
scoreboard players set #gy driftmountains 70096
scoreboard players set #gdy driftmountains -18
scoreboard players set #gz driftmountains 21324
scoreboard players set #gdz driftmountains -884
scoreboard players set #gr driftmountains 17578
scoreboard players set #gdr driftmountains -113
scoreboard players set #gp driftmountains 72
scoreboard players set #gdp driftmountains -3
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.0374f,0.3258f,0.0425f,0.9438f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.0565f,0.9445f,0.0034f,-0.3236f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.4096f,0.0054f,-0.0119f,-0.9122f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0119f,-0.9122f,0.4096f,0.0054f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3530f,0.8490f,0.1007f],left_rotation:[-0.1863f,0.0315f,-0.1335f,-0.9728f]}}
particle minecraft:cloud -80.64 70.42 22.64 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -80.64 70.22 22.64 0.005 0.02 0.072 1 0 force
particle minecraft:cloud -78.97 70.42 22.52 0.35 0.18 0.35 0.02 3 force
