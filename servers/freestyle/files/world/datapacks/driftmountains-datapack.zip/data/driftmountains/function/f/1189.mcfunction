scoreboard players set #gx driftmountains -85433
scoreboard players set #gdx driftmountains 547
scoreboard players set #gy driftmountains 69479
scoreboard players set #gdy driftmountains -15
scoreboard players set #gz driftmountains -26217
scoreboard players set #gdz driftmountains -157
scoreboard players set #gr driftmountains -7326
scoreboard players set #gdr driftmountains -123
scoreboard players set #gp driftmountains 130
scoreboard players set #gdp driftmountains -1
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0001f,-0.0211f,0.9998f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.9729f,0.0778f,-0.1651f,0.1420f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.1809f,0.1601f,0.9701f,0.0240f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.2857f,0.0037f,-0.0125f,-0.9582f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0125f,-0.9582f,0.2857f,0.0037f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.4012f,0.8459f,0.0995f],left_rotation:[-0.0111f,0.1843f,-0.9825f,-0.0239f]}}
particle minecraft:cloud -86.40 69.80 -27.38 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -86.40 69.60 -27.38 -0.033 0.02 -0.010 1 0 force
particle minecraft:cloud -86.88 69.80 -25.78 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -90365
scoreboard players set #gdx driftmountains 534
scoreboard players set #gy driftmountains 69628
scoreboard players set #gdy driftmountains -19
scoreboard players set #gz driftmountains -23528
scoreboard players set #gdz driftmountains -436
scoreboard players set #gr driftmountains -8495
scoreboard players set #gdr driftmountains 113
scoreboard players set #gp driftmountains 110
scoreboard players set #gdp driftmountains -1
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.7595f,0.2477f,-0.2479f,0.5481f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.3069f,0.5772f,0.7376f,-0.1693f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.2857f,0.0037f,-0.0125f,-0.9582f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0125f,-0.9582f,0.2857f,0.0037f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3665f,0.8314f,0.2339f],left_rotation:[-0.1790f,-0.0100f,0.0768f,-0.9808f]}}
particle minecraft:cloud -91.65 69.95 -24.50 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -91.65 69.75 -24.50 -0.041 0.02 -0.004 1 0 force
particle minecraft:cloud -91.80 69.95 -22.80 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -93771
scoreboard players set #gdx driftmountains 536
scoreboard players set #gy driftmountains 69755
scoreboard players set #gdy driftmountains -20
scoreboard players set #gz driftmountains -20132
scoreboard players set #gdz driftmountains -585
scoreboard players set #gr driftmountains -9139
scoreboard players set #gdr driftmountains 139
scoreboard players set #gp driftmountains 98
scoreboard players set #gdp driftmountains 3
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[0.0035f,0.0001f,-0.0223f,0.9997f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.4435f,0.3356f,-0.1174f,0.8227f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.2045f,0.8396f,0.4107f,-0.2908f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.2857f,0.0037f,-0.0125f,-0.9582f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0125f,-0.9582f,0.2857f,0.0037f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3534f,0.8371f,0.0960f],left_rotation:[-0.1849f,-0.0170f,0.1253f,-0.9745f]}}
particle minecraft:cloud -95.05 70.07 -20.94 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -95.05 69.87 -20.94 -0.047 0.02 0.001 1 0 force
particle minecraft:cloud -95.01 70.07 -19.27 0.35 0.18 0.35 0.02 3 force
