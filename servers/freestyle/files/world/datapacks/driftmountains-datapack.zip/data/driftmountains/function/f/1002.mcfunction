scoreboard players set #gx driftmountains 26831
scoreboard players set #gdx driftmountains 219
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 29296
scoreboard players set #gdz driftmountains 1019
scoreboard players set #gr driftmountains 3716
scoreboard players set #gdr driftmountains 311
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.3863f,-0.3342f,-0.2181f,-0.8316f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.1319f,-0.8132f,0.4235f,0.3767f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.4159f,0.0054f,0.0119f,0.9093f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0119f,0.9093f,0.4159f,0.0054f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3671f,0.8229f,0.0905f],left_rotation:[-0.1553f,-0.0923f,0.5223f,-0.8333f]}}
particle minecraft:cloud 28.26 71.32 28.80 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 28.26 71.12 28.80 0.038 0.02 -0.050 1 0 force
particle minecraft:cloud 26.93 71.32 27.79 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains 25094
scoreboard players set #gdx driftmountains 444
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 22708
scoreboard players set #gdz driftmountains 718
scoreboard players set #gr driftmountains 626
scoreboard players set #gdr driftmountains 421
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.8986f,-0.0471f,-0.3237f,-0.2923f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.2948f,-0.2599f,0.9085f,0.1419f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.4159f,0.0054f,0.0119f,0.9093f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0119f,0.9093f,0.4159f,0.0054f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3588f,0.8393f,0.2370f],left_rotation:[-0.1786f,0.0335f,-0.1465f,-0.9724f]}}
particle minecraft:cloud 26.09 71.32 21.44 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 26.09 71.12 21.44 0.006 0.02 -0.055 1 0 force
particle minecraft:cloud 24.39 71.32 21.26 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains 22020
scoreboard players set #gdx driftmountains 434
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 17694
scoreboard players set #gdz driftmountains 1060
scoreboard players set #gr driftmountains 889
scoreboard players set #gdr driftmountains 60
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0001f,-0.0190f,0.9998f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.5118f,0.2475f,-0.0910f,0.8177f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.1774f,0.8317f,0.4886f,-0.1951f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.4159f,0.0054f,0.0119f,0.9093f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0119f,0.9093f,0.4159f,0.0054f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3747f,0.8665f,0.1076f],left_rotation:[-0.1395f,0.1322f,-0.6797f,-0.7078f]}}
particle minecraft:cloud 23.04 71.32 16.58 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 23.04 71.12 16.58 0.010 0.02 -0.063 1 0 force
particle minecraft:cloud 21.39 71.32 16.32 0.35 0.18 0.35 0.02 3 force
