scoreboard players set #gx driftmountains -7242
scoreboard players set #gdx driftmountains -1010
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 61201
scoreboard players set #gdz driftmountains -277
scoreboard players set #gr driftmountains 15509
scoreboard players set #gdr driftmountains -68
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.8185f,0.2324f,-0.3651f,0.3778f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.4068f,0.4183f,0.7986f,-0.1476f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.9561f,0.0125f,-0.0038f,-0.2927f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0038f,-0.2927f,0.9561f,0.0125f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3833f,0.8218f,0.0900f],left_rotation:[-0.1116f,-0.1402f,0.7699f,-0.6125f]}}
particle minecraft:cloud -7.47 71.32 62.70 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -7.47 71.12 62.70 0.026 0.02 0.057 1 0 force
particle minecraft:cloud -5.95 71.32 61.99 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains 398
scoreboard players set #gdx driftmountains -942
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 61222
scoreboard players set #gdz driftmountains 30
scoreboard players set #gr driftmountains 14502
scoreboard players set #gdr driftmountains -298
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.2802f,0.4705f,-0.0957f,0.8312f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.1836f,0.8459f,0.2323f,-0.4437f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.9561f,0.0125f,-0.0038f,-0.2927f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0038f,-0.2927f,0.9561f,0.0125f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.4039f,0.8608f,0.2455f],left_rotation:[-0.0282f,-0.1874f,0.9651f,-0.1808f]}}
particle minecraft:cloud 0.48 71.32 62.83 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 0.48 71.12 62.83 0.032 0.02 0.046 1 0 force
particle minecraft:cloud 1.88 71.32 61.85 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains 6767
scoreboard players set #gdx driftmountains -1057
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 62628
scoreboard players set #gdz driftmountains 139
scoreboard players set #gr driftmountains 14269
scoreboard players set #gdr driftmountains 286
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.7463f,-0.1978f,-0.4158f,-0.4807f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.3676f,-0.4396f,0.7712f,0.2773f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.9561f,0.0125f,-0.0038f,-0.2927f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0038f,-0.2927f,0.9561f,0.0125f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3950f,0.8285f,0.0927f],left_rotation:[-0.0651f,-0.1681f,0.9098f,-0.3737f]}}
particle minecraft:cloud 6.87 71.32 64.14 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 6.87 71.12 64.14 0.040 0.02 0.053 1 0 force
particle minecraft:cloud 8.20 71.32 63.12 0.35 0.18 0.35 0.02 3 force
