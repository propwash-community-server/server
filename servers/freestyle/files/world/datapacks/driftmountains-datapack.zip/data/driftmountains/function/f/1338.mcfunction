scoreboard players set #gx driftmountains -32122
scoreboard players set #gdx driftmountains 651
scoreboard players set #gy driftmountains 67335
scoreboard players set #gdy driftmountains -12
scoreboard players set #gz driftmountains -90501
scoreboard players set #gdz driftmountains 260
scoreboard players set #gr driftmountains -3723
scoreboard players set #gdr driftmountains 27
scoreboard players set #gp driftmountains 87
scoreboard players set #gdp driftmountains -6
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0001f,-0.0191f,0.9998f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.9573f,0.0127f,-0.2303f,-0.1743f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.2132f,-0.1511f,0.9612f,0.0879f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.3820f,0.0050f,-0.0121f,-0.9241f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0121f,-0.9241f,0.3820f,0.0050f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3896f,0.8632f,0.1063f],left_rotation:[-0.0934f,0.1657f,-0.8674f,-0.4597f]}}
particle minecraft:cloud -32.22 67.66 -92.01 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -32.22 67.46 -92.01 -0.025 0.02 -0.033 1 0 force
particle minecraft:cloud -33.55 67.66 -91.00 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -37752
scoreboard players set #gdx driftmountains 610
scoreboard players set #gy driftmountains 67454
scoreboard players set #gdy driftmountains -17
scoreboard players set #gz driftmountains -91692
scoreboard players set #gdz driftmountains 33
scoreboard players set #gr driftmountains -5112
scoreboard players set #gdr driftmountains 130
scoreboard players set #gp driftmountains 134
scoreboard players set #gdp driftmountains -10
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.5799f,0.2121f,-0.0905f,0.7814f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.1732f,0.7952f,0.5608f,-0.1524f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.3820f,0.0050f,-0.0121f,-0.9241f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0121f,-0.9241f,0.3820f,0.0050f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3756f,0.8738f,0.2505f],left_rotation:[-0.0888f,0.1713f,-0.8661f,-0.4612f]}}
particle minecraft:cloud -38.28 67.77 -93.21 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -38.28 67.57 -93.21 -0.028 0.02 -0.023 1 0 force
particle minecraft:cloud -39.35 67.77 -91.88 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -42874
scoreboard players set #gdx driftmountains 461
scoreboard players set #gy driftmountains 67592
scoreboard players set #gdy driftmountains -12
scoreboard players set #gz driftmountains -90926
scoreboard players set #gdz driftmountains -271
scoreboard players set #gr driftmountains -8606
scoreboard players set #gdr driftmountains 272
scoreboard players set #gp driftmountains 105
scoreboard players set #gdp driftmountains 2
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[0.0061f,0.0001f,-0.0217f,0.9997f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.1895f,0.2199f,0.0111f,0.9569f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.0894f,0.9610f,0.1674f,-0.2012f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.3820f,0.0050f,-0.0121f,-0.9241f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0121f,-0.9241f,0.3820f,0.0050f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3935f,0.8604f,0.1052f],left_rotation:[-0.0767f,0.1729f,-0.9093f,-0.3706f]}}
particle minecraft:cloud -44.07 67.91 -91.85 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -44.07 67.71 -91.85 -0.022 0.02 -0.002 1 0 force
particle minecraft:cloud -44.19 67.91 -90.18 0.35 0.18 0.35 0.02 3 force
