scoreboard players set #gx driftmountains -83160
scoreboard players set #gdx driftmountains 594
scoreboard players set #gy driftmountains 69423
scoreboard players set #gdy driftmountains -12
scoreboard players set #gz driftmountains -26657
scoreboard players set #gdz driftmountains -67
scoreboard players set #gr driftmountains -8018
scoreboard players set #gdr driftmountains -358
scoreboard players set #gp driftmountains 117
scoreboard players set #gdp driftmountains -5
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0000f,-0.0101f,0.9999f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.9703f,0.0297f,-0.1096f,-0.2137f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.0878f,-0.2033f,0.9725f,0.0721f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.9749f,0.0128f,-0.0029f,-0.2222f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0029f,-0.2222f,0.9749f,0.0128f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3841f,0.8220f,0.0901f],left_rotation:[0.1090f,0.1422f,-0.7801f,0.5994f]}}
particle minecraft:cloud -84.26 69.74 -27.69 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -84.26 69.54 -27.69 -0.035 0.02 -0.006 1 0 force
particle minecraft:cloud -84.54 69.74 -26.05 0.35 0.18 0.35 0.02 2 force
scoreboard players set #gx driftmountains -88681
scoreboard players set #gdx driftmountains 552
scoreboard players set #gy driftmountains 69570
scoreboard players set #gdy driftmountains -18
scoreboard players set #gz driftmountains -24855
scoreboard players set #gdz driftmountains -399
scoreboard players set #gr driftmountains -8113
scoreboard players set #gdr driftmountains 142
scoreboard players set #gp driftmountains 108
scoreboard players set #gdp driftmountains -2
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.7990f,0.2254f,-0.2589f,0.4938f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.3122f,0.5237f,0.7797f,-0.1426f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.9749f,0.0128f,-0.0029f,-0.2222f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0029f,-0.2222f,0.9749f,0.0128f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3637f,0.8335f,0.2348f],left_rotation:[-0.1799f,0.0036f,0.0073f,-0.9837f]}}
particle minecraft:cloud -89.90 69.89 -25.91 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -89.90 69.69 -25.91 -0.021 0.02 -0.003 1 0 force
particle minecraft:cloud -90.16 69.89 -24.22 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -91504
scoreboard players set #gdx driftmountains 516
scoreboard players set #gy driftmountains 69673
scoreboard players set #gdy driftmountains -17
scoreboard players set #gz driftmountains -22336
scoreboard players set #gdz driftmountains -414
scoreboard players set #gr driftmountains -8438
scoreboard players set #gdr driftmountains 203
scoreboard players set #gp driftmountains 106
scoreboard players set #gdp driftmountains 1
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.8706f,-0.0749f,-0.3243f,-0.3623f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.2880f,-0.3302f,0.8833f,0.1668f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.9749f,0.0128f,-0.0029f,-0.2222f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0029f,-0.2222f,0.9749f,0.0128f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3526f,0.8471f,0.1000f],left_rotation:[-0.1870f,0.0238f,-0.0921f,-0.9777f]}}
particle minecraft:cloud -92.68 69.99 -23.29 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -92.68 69.79 -23.29 -0.044 0.02 -0.004 1 0 force
particle minecraft:cloud -92.84 69.99 -21.63 0.35 0.18 0.35 0.02 3 force
