scoreboard players set #gx driftmountains -98036
scoreboard players set #gdx driftmountains 93
scoreboard players set #gy driftmountains 69974
scoreboard players set #gdy driftmountains -13
scoreboard players set #gz driftmountains -10967
scoreboard players set #gdz driftmountains -795
scoreboard players set #gr driftmountains -12483
scoreboard players set #gdr driftmountains 223
scoreboard players set #gp driftmountains 58
scoreboard players set #gdp driftmountains 3
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.8759f,-0.0689f,-0.3634f,-0.3100f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.3328f,-0.2735f,0.8879f,0.1614f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.4623f,0.0061f,-0.0116f,-0.8866f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0116f,-0.8866f,0.4623f,0.0061f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3563f,0.8313f,0.0938f],left_rotation:[-0.1788f,-0.0427f,0.2616f,-0.9475f]}}
particle minecraft:cloud -99.55 70.29 -10.93 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -99.55 70.09 -10.93 -0.040 0.02 0.028 1 0 force
particle minecraft:cloud -98.59 70.29 -9.56 0.35 0.18 0.35 0.02 3 force
playsound driftgen:grain.kaze.030 neutral @a -96.30 70.36 -16.76 12 1
scoreboard players set #gx driftmountains -97633
scoreboard players set #gdx driftmountains -172
scoreboard players set #gy driftmountains 70033
scoreboard players set #gdy driftmountains -1
scoreboard players set #gz driftmountains -3178
scoreboard players set #gdz driftmountains -923
scoreboard players set #gr driftmountains -14150
scoreboard players set #gdr driftmountains 169
scoreboard players set #gp driftmountains 3
scoreboard players set #gdp driftmountains 5
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.9058f,0.1319f,-0.3556f,0.1890f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.3774f,0.2274f,0.8969f,-0.0374f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.4623f,0.0061f,-0.0116f,-0.8866f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0116f,-0.8866f,0.4623f,0.0061f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3800f,0.8272f,0.2323f],left_rotation:[-0.1666f,-0.0633f,0.3481f,-0.9204f]}}
particle minecraft:cloud -99.15 70.35 -2.64 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -99.15 70.15 -2.64 -0.034 0.02 0.042 1 0 force
particle minecraft:cloud -97.81 70.35 -1.58 0.35 0.18 0.35 0.02 3 force
playsound driftgen:grain.onyx.049 neutral @a -98.15 70.49 -9.95 12 1
scoreboard players set #gx driftmountains -95934
scoreboard players set #gdx driftmountains -397
scoreboard players set #gy driftmountains 70023
scoreboard players set #gdy driftmountains 3
scoreboard players set #gz driftmountains 1980
scoreboard players set #gdz driftmountains -839
scoreboard players set #gr driftmountains -15553
scoreboard players set #gdr driftmountains 288
scoreboard players set #gp driftmountains -13
scoreboard players set #gdp driftmountains 2
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.0398f,0.3790f,0.0403f,0.9237f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.0566f,0.9245f,0.0001f,-0.3769f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.4623f,0.0061f,-0.0116f,-0.8866f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0116f,-0.8866f,0.4623f,0.0061f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3598f,0.8274f,0.0922f],left_rotation:[-0.1715f,-0.0625f,0.3659f,-0.9125f]}}
particle minecraft:cloud -97.22 70.34 2.78 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -97.22 70.14 2.78 -0.023 0.02 0.050 1 0 force
particle minecraft:cloud -95.70 70.34 3.47 0.35 0.18 0.35 0.02 3 force
playsound driftgen:grain.kaze.047 neutral @a -98.00 70.53 -4.90 12 1
