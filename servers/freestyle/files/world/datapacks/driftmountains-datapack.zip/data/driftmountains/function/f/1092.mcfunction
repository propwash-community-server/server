scoreboard players set #gx driftmountains -47413
scoreboard players set #gdx driftmountains -1210
scoreboard players set #gy driftmountains 70468
scoreboard players set #gdy driftmountains 1
scoreboard players set #gz driftmountains 48072
scoreboard players set #gdz driftmountains -498
scoreboard players set #gr driftmountains 15669
scoreboard players set #gdr driftmountains 72
scoreboard players set #gp driftmountains 2
scoreboard players set #gdp driftmountains -8
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.8405f,0.2074f,-0.3112f,0.3921f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.3541f,0.4270f,0.8233f,-0.1202f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.9781f,0.0128f,-0.0027f,-0.2076f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0027f,-0.2076f,0.9781f,0.0128f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3575f,0.8298f,0.0932f],left_rotation:[-0.1764f,-0.0499f,0.2998f,-0.9362f]}}
particle minecraft:cloud -47.68 70.79 49.56 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -47.68 70.59 49.56 0.031 0.02 0.072 1 0 force
particle minecraft:cloud -46.15 70.79 48.90 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -37309
scoreboard players set #gdx driftmountains -1196
scoreboard players set #gy driftmountains 70624
scoreboard players set #gdy driftmountains -37
scoreboard players set #gz driftmountains 51961
scoreboard players set #gdz driftmountains -436
scoreboard players set #gr driftmountains 15465
scoreboard players set #gdr driftmountains -11
scoreboard players set #gp driftmountains 122
scoreboard players set #gdp driftmountains -11
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.2894f,0.3715f,-0.0628f,0.8800f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.1556f,0.8914f,0.2519f,-0.3431f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.9781f,0.0128f,-0.0027f,-0.2076f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0027f,-0.2076f,0.9781f,0.0128f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3787f,0.8273f,0.2323f],left_rotation:[-0.1683f,-0.0587f,0.3250f,-0.9288f]}}
particle minecraft:cloud -37.50 70.94 53.56 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -37.50 70.74 53.56 0.033 0.02 0.069 1 0 force
particle minecraft:cloud -35.95 70.94 52.83 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -32736
scoreboard players set #gdx driftmountains -1168
scoreboard players set #gy driftmountains 70786
scoreboard players set #gdy driftmountains -41
scoreboard players set #gz driftmountains 53884
scoreboard players set #gdz driftmountains -371
scoreboard players set #gr driftmountains 15387
scoreboard players set #gdr driftmountains 7
scoreboard players set #gp driftmountains 131
scoreboard players set #gdp driftmountains 4
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.7759f,-0.1604f,-0.3574f,-0.4944f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.3074f,-0.4596f,0.7971f,0.2428f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.9781f,0.0128f,-0.0027f,-0.2076f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0027f,-0.2076f,0.9781f,0.0128f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3639f,0.8244f,0.0911f],left_rotation:[-0.1626f,-0.0804f,0.4598f,-0.8693f]}}
particle minecraft:cloud -32.93 71.11 55.38 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -32.93 70.91 55.38 0.033 0.02 0.067 1 0 force
particle minecraft:cloud -31.43 71.11 54.65 0.35 0.18 0.35 0.02 3 force
