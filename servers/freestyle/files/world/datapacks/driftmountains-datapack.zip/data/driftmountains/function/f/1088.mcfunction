scoreboard players set #gx driftmountains -42606
scoreboard players set #gdx driftmountains -1194
scoreboard players set #gy driftmountains 70498
scoreboard players set #gdy driftmountains -14
scoreboard players set #gz driftmountains 49954
scoreboard players set #gdz driftmountains -459
scoreboard players set #gr driftmountains 15540
scoreboard players set #gdr driftmountains 5
scoreboard players set #gp driftmountains 51
scoreboard players set #gdp driftmountains -15
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.7591f,-0.1670f,-0.3369f,-0.5314f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.2829f,-0.4990f,0.7808f,0.2477f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.3000f,0.0039f,-0.0125f,-0.9538f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0125f,-0.9538f,0.3000f,0.0039f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3581f,0.8291f,0.0929f],left_rotation:[-0.1751f,-0.0535f,0.3187f,-0.9299f]}}
particle minecraft:cloud -42.84 70.82 51.45 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -42.84 70.62 51.45 0.032 0.02 0.070 1 0 force
particle minecraft:cloud -41.32 70.82 50.75 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -32680
scoreboard players set #gdx driftmountains -1076
scoreboard players set #gy driftmountains 70785
scoreboard players set #gdy driftmountains -38
scoreboard players set #gz driftmountains 53568
scoreboard players set #gdz driftmountains -364
scoreboard players set #gr driftmountains 15450
scoreboard players set #gdr driftmountains 9
scoreboard players set #gp driftmountains 133
scoreboard players set #gdp driftmountains 3
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.9025f,0.1336f,-0.3638f,0.1878f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.3855f,0.2271f,0.8934f,-0.0395f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.3000f,0.0039f,-0.0125f,-0.9538f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0125f,-0.9538f,0.3000f,0.0039f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3842f,0.8274f,0.2324f],left_rotation:[-0.1604f,-0.0780f,0.4227f,-0.8886f]}}
particle minecraft:cloud -32.86 71.11 55.17 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -32.86 70.91 55.17 0.032 0.02 0.067 1 0 force
particle minecraft:cloud -31.32 71.11 54.43 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -27933
scoreboard players set #gdx driftmountains -1171
scoreboard players set #gy driftmountains 70934
scoreboard players set #gdy driftmountains -31
scoreboard players set #gz driftmountains 55347
scoreboard players set #gdz driftmountains -348
scoreboard players set #gr driftmountains 15303
scoreboard players set #gdr driftmountains 33
scoreboard players set #gp driftmountains 95
scoreboard players set #gdp driftmountains 12
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.0403f,0.3926f,0.0397f,0.9180f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.0566f,0.9188f,-0.0007f,-0.3906f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.3000f,0.0039f,-0.0125f,-0.9538f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0125f,-0.9538f,0.3000f,0.0039f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3651f,0.8237f,0.0908f],left_rotation:[-0.1599f,-0.0851f,0.4846f,-0.8557f]}}
particle minecraft:cloud -28.11 71.25 56.85 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -28.11 71.05 56.85 0.034 0.02 0.066 1 0 force
particle minecraft:cloud -26.62 71.25 56.09 0.35 0.18 0.35 0.02 3 force
