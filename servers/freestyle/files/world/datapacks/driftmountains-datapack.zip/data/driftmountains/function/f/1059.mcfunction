scoreboard players set #gx driftmountains -10292
scoreboard players set #gdx driftmountains -1029
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 60357
scoreboard players set #gdz driftmountains -291
scoreboard players set #gr driftmountains 15297
scoreboard players set #gdr driftmountains -47
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.8607f,-0.0825f,-0.3916f,-0.3148f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.3606f,-0.2754f,0.8741f,0.1734f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.4756f,0.0062f,-0.0115f,-0.8796f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0115f,-0.8796f,0.4756f,0.0062f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3675f,0.8227f,0.0904f],left_rotation:[-0.1542f,-0.0940f,0.5311f,-0.8278f]}}
particle minecraft:cloud -10.46 71.32 61.86 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -10.46 71.12 61.86 0.029 0.02 0.057 1 0 force
particle minecraft:cloud -8.98 71.32 61.10 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -2400
scoreboard players set #gdx driftmountains -922
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 61340
scoreboard players set #gdz driftmountains 23
scoreboard players set #gr driftmountains 14106
scoreboard players set #gdr driftmountains 113
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.8130f,0.2358f,-0.3419f,0.4080f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.3867f,0.4461f,0.7927f,-0.1517f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.4756f,0.0062f,-0.0115f,-0.8796f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0115f,-0.8796f,0.4756f,0.0062f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3970f,0.8325f,0.2344f],left_rotation:[-0.1318f,-0.1231f,0.6500f,-0.7383f]}}
particle minecraft:cloud -2.21 71.32 62.94 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -2.21 71.12 62.94 0.035 0.02 0.043 1 0 force
particle minecraft:cloud -0.88 71.32 61.86 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains 3607
scoreboard players set #gdx driftmountains -1143
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 62876
scoreboard players set #gdz driftmountains -22
scoreboard players set #gr driftmountains 15000
scoreboard players set #gdr driftmountains 129
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.1882f,-0.4315f,-0.1536f,-0.8688f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.0632f,-0.8574f,0.2346f,0.4537f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.4756f,0.0062f,-0.0115f,-0.8796f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0115f,-0.8796f,0.4756f,0.0062f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3941f,0.8277f,0.0923f],left_rotation:[-0.0694f,-0.1661f,0.9004f,-0.3959f]}}
particle minecraft:cloud 3.51 71.32 64.38 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 3.51 71.12 64.38 0.033 0.02 0.057 1 0 force
particle minecraft:cloud 4.96 71.32 63.55 0.35 0.18 0.35 0.02 3 force
