scoreboard players set #gx driftmountains -1113
scoreboard players set #gdx driftmountains 662
scoreboard players set #gy driftmountains 70525
scoreboard players set #gdy driftmountains -8
scoreboard players set #gz driftmountains -24142
scoreboard players set #gdz driftmountains 466
scoreboard players set #gr driftmountains -974
scoreboard players set #gdr driftmountains 93
scoreboard players set #gp driftmountains 13
scoreboard players set #gdp driftmountains 42
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.1675f,0.3687f,-0.0104f,0.9142f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.1066f,0.9204f,0.1297f,-0.3532f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.7120f,0.0093f,-0.0092f,-0.7021f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0092f,-0.7021f,0.7120f,0.0093f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3561f,0.8316f,0.0939f],left_rotation:[-0.1794f,-0.0410f,0.2526f,-0.9499f]}}
particle minecraft:cloud -0.50 70.84 -25.52 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -0.50 70.64 -25.52 -0.008 0.02 -0.048 1 0 force
particle minecraft:cloud -2.15 70.84 -25.24 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -4873
scoreboard players set #gdx driftmountains 622
scoreboard players set #gy driftmountains 70337
scoreboard players set #gdy driftmountains 53
scoreboard players set #gz driftmountains -27552
scoreboard players set #gdz driftmountains 428
scoreboard players set #gr driftmountains -1059
scoreboard players set #gdr driftmountains 42
scoreboard players set #gp driftmountains -306
scoreboard players set #gdp driftmountains 52
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.2264f,0.3332f,-0.0253f,0.9149f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.1216f,0.9226f,0.1927f,-0.3113f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.7120f,0.0093f,-0.0092f,-0.7021f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0092f,-0.7021f,0.7120f,0.0093f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3607f,0.8366f,0.2360f],left_rotation:[-0.1797f,0.0204f,-0.0792f,-0.9803f]}}
particle minecraft:cloud -4.28 70.66 -29.05 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -4.28 70.46 -29.05 -0.008 0.02 -0.044 1 0 force
particle minecraft:cloud -5.96 70.66 -28.74 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -9285
scoreboard players set #gdx driftmountains 807
scoreboard players set #gy driftmountains 69916
scoreboard players set #gdy driftmountains 70
scoreboard players set #gz driftmountains -28856
scoreboard players set #gdz driftmountains 195
scoreboard players set #gr driftmountains -3071
scoreboard players set #gdr driftmountains 308
scoreboard players set #gp driftmountains -309
scoreboard players set #gdp driftmountains -46
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.6065f,-0.2160f,-0.2539f,-0.7219f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.1794f,-0.6991f,0.6325f,0.2809f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.7120f,0.0093f,-0.0092f,-0.7021f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0092f,-0.7021f,0.7120f,0.0093f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3525f,0.8469f,0.0999f],left_rotation:[-0.1870f,0.0230f,-0.0879f,-0.9781f]}}
particle minecraft:cloud -9.21 70.24 -30.37 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -9.21 70.04 -30.37 -0.024 0.02 -0.041 1 0 force
particle minecraft:cloud -10.65 70.24 -29.51 0.35 0.18 0.35 0.02 3 force
