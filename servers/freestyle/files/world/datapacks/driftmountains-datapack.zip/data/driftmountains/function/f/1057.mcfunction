scoreboard players set #gx driftmountains -8252
scoreboard players set #gdx driftmountains -1017
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 60923
scoreboard players set #gdz driftmountains -281
scoreboard players set #gr driftmountains 15441
scoreboard players set #gdr driftmountains -86
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.5825f,-0.2799f,-0.3085f,-0.6980f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.2368f,-0.6694f,0.6151f,0.3427f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.0328f,0.0004f,0.0131f,0.9994f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0131f,0.9994f,0.0328f,0.0004f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3754f,0.8210f,0.0897f],left_rotation:[-0.1347f,-0.1188f,0.6596f,-0.7298f]}}
particle minecraft:cloud -8.46 71.32 62.42 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -8.46 71.12 62.42 0.027 0.02 0.057 1 0 force
particle minecraft:cloud -6.96 71.32 61.70 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -543
scoreboard players set #gdx driftmountains -934
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 61251
scoreboard players set #gdz driftmountains 48
scoreboard players set #gr driftmountains 14204
scoreboard players set #gdr driftmountains -82
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.8789f,0.0297f,-0.4729f,-0.0553f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.4697f,-0.0059f,0.8806f,0.0625f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.0328f,0.0004f,0.0131f,0.9994f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0131f,0.9994f,0.0328f,0.0004f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.4051f,0.8579f,0.2443f],left_rotation:[-0.0399f,-0.1844f,0.9511f,-0.2446f]}}
particle minecraft:cloud -0.38 71.32 62.85 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -0.38 71.12 62.85 0.034 0.02 0.044 1 0 force
particle minecraft:cloud 0.97 71.32 61.80 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains 5710
scoreboard players set #gdx driftmountains -1089
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 62766
scoreboard players set #gdz driftmountains 84
scoreboard players set #gr driftmountains 14555
scoreboard players set #gdr driftmountains 255
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.2713f,0.4511f,-0.0829f,0.8462f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.1723f,0.8596f,0.2254f,-0.4250f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.0328f,0.0004f,0.0131f,0.9994f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0131f,0.9994f,0.0328f,0.0004f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3943f,0.8279f,0.0924f],left_rotation:[-0.0684f,-0.1666f,0.9027f,-0.3907f]}}
particle minecraft:cloud 5.73 71.32 64.28 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 5.73 71.12 64.28 0.038 0.02 0.055 1 0 force
particle minecraft:cloud 7.11 71.32 63.33 0.35 0.18 0.35 0.02 3 force
