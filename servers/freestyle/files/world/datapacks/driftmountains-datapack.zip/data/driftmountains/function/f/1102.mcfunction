scoreboard players set #gx driftmountains -59394
scoreboard players set #gdx driftmountains -1149
scoreboard players set #gy driftmountains 70516
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 42089
scoreboard players set #gdz driftmountains -766
scoreboard players set #gr driftmountains 17255
scoreboard players set #gdr driftmountains 170
scoreboard players set #gp driftmountains -5
scoreboard players set #gdp driftmountains 8
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.9138f,0.0219f,-0.3974f,-0.0813f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.3911f,-0.0399f,0.9165f,0.0741f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.7594f,0.0099f,-0.0085f,-0.6505f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0085f,-0.6505f,0.7594f,0.0099f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3666f,0.8231f,0.0905f],left_rotation:[-0.1564f,-0.0906f,0.5135f,-0.8388f]}}
particle minecraft:cloud -60.06 70.84 43.45 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -60.06 70.64 43.45 0.011 0.02 0.082 1 0 force
particle minecraft:cloud -58.40 70.84 43.23 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -49426
scoreboard players set #gdx driftmountains -1328
scoreboard players set #gy driftmountains 70470
scoreboard players set #gdy driftmountains 5
scoreboard players set #gz driftmountains 47006
scoreboard players set #gdz driftmountains -622
scoreboard players set #gr driftmountains 15843
scoreboard players set #gdr driftmountains 139
scoreboard players set #gp driftmountains -11
scoreboard players set #gdp driftmountains -5
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.6940f,0.2814f,-0.2301f,0.6215f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.2967f,0.6491f,0.6682f,-0.2100f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.7594f,0.0099f,-0.0085f,-0.6505f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0085f,-0.6505f,0.7594f,0.0099f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3723f,0.8286f,0.2328f],left_rotation:[-0.1752f,-0.0344f,0.2013f,-0.9631f]}}
particle minecraft:cloud -49.72 70.79 48.59 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -49.72 70.59 48.59 0.030 0.02 0.077 1 0 force
particle minecraft:cloud -48.13 70.79 47.96 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -44833
scoreboard players set #gdx driftmountains -1250
scoreboard players set #gy driftmountains 70478
scoreboard players set #gdy driftmountains -7
scoreboard players set #gz driftmountains 49567
scoreboard players set #gdz driftmountains -517
scoreboard players set #gr driftmountains 15574
scoreboard players set #gdr driftmountains 59
scoreboard players set #gp driftmountains 26
scoreboard players set #gdp driftmountains -12
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.4310f,-0.2949f,-0.2175f,-0.8246f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.1320f,-0.8063f,0.4643f,0.3418f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.7594f,0.0099f,-0.0085f,-0.6505f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0085f,-0.6505f,0.7594f,0.0099f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3554f,0.8326f,0.0943f],left_rotation:[-0.1806f,-0.0366f,0.2291f,-0.9557f]}}
particle minecraft:cloud -45.08 70.80 51.06 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -45.08 70.60 51.06 0.033 0.02 0.073 1 0 force
particle minecraft:cloud -43.55 70.80 50.37 0.35 0.18 0.35 0.02 3 force
