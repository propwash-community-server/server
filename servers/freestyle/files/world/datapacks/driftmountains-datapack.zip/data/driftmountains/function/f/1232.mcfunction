scoreboard players set #gx driftmountains -59343
scoreboard players set #gdx driftmountains 371
scoreboard players set #gy driftmountains 68982
scoreboard players set #gdy driftmountains -18
scoreboard players set #gz driftmountains -35718
scoreboard players set #gdz driftmountains -455
scoreboard players set #gr driftmountains -17388
scoreboard players set #gdr driftmountains -152
scoreboard players set #gp driftmountains 144
scoreboard players set #gdp driftmountains -2
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,0.0001f,0.0208f,0.9998f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.3617f,0.2061f,0.0245f,-0.9089f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[-0.1202f,-0.9165f,0.3421f,-0.1692f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.6104f,0.0080f,-0.0104f,-0.7920f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0104f,-0.7920f,0.6104f,0.0080f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3982f,0.8327f,0.0943f],left_rotation:[-0.0445f,-0.1757f,0.9465f,-0.2667f]}}
particle minecraft:cloud -60.31 69.30 -34.55 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud -58.65 69.30 -34.38 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -58.65 69.10 -34.38 -0.004 0.02 0.035 1 0 force
playsound driftgen:grain.kaze.033 neutral @a -56.54 69.34 -39.73 12 1
scoreboard players set #gx driftmountains -64169
scoreboard players set #gdx driftmountains 560
scoreboard players set #gy driftmountains 69118
scoreboard players set #gdy driftmountains -12
scoreboard players set #gz driftmountains -34496
scoreboard players set #gdz driftmountains -247
scoreboard players set #gr driftmountains -14136
scoreboard players set #gdr driftmountains -435
scoreboard players set #gp driftmountains 96
scoreboard players set #gdp driftmountains 5
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[0.0061f,-0.0001f,0.0172f,0.9998f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.2772f,0.1999f,0.0033f,-0.9398f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[-0.1021f,-0.9453f,0.2577f,-0.1718f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.6104f,0.0080f,-0.0104f,-0.7920f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0104f,-0.7920f,0.6104f,0.0080f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.4042f,0.8601f,0.2452f],left_rotation:[-0.0311f,-0.1867f,0.9621f,-0.1965f]}}
particle minecraft:cloud -65.69 69.44 -33.96 0.35 0.18 0.35 0.02 2 force
particle minecraft:cloud -64.35 69.44 -32.90 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -64.35 69.24 -32.90 -0.024 0.02 0.030 1 0 force
playsound driftgen:grain.onyx.034 neutral @a -60.38 69.48 -37.03 12 1
scoreboard players set #gx driftmountains -68847
scoreboard players set #gdx driftmountains 674
scoreboard players set #gy driftmountains 69198
scoreboard players set #gdy driftmountains -10
scoreboard players set #gz driftmountains -31453
scoreboard players set #gdz driftmountains -274
scoreboard players set #gr driftmountains -11894
scoreboard players set #gdr driftmountains -139
scoreboard players set #gp driftmountains 77
scoreboard players set #gdp driftmountains 2
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[0.0061f,-0.0000f,0.0041f,1.0000f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.9727f,0.0370f,0.0753f,0.2163f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[-0.0530f,0.2096f,0.9742f,0.0651f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.6104f,0.0080f,-0.0104f,-0.7920f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0104f,-0.7920f,0.6104f,0.0080f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3670f,0.8647f,0.1068f],left_rotation:[0.1579f,-0.1095f,0.5551f,0.8092f]}}
playsound driftgen:grain.kaze.032 neutral @a -64.36 69.63 -33.30 12 1
