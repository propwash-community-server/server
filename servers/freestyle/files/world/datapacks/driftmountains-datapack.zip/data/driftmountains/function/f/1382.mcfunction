scoreboard players set #gx driftmountains 253
scoreboard players set #gdx driftmountains 846
scoreboard players set #gy driftmountains 66866
scoreboard players set #gdy driftmountains -11
scoreboard players set #gz driftmountains -71261
scoreboard players set #gdz driftmountains 571
scoreboard players set #gr driftmountains -5058
scoreboard players set #gdr driftmountains -25
scoreboard players set #gp driftmountains 61
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0000f,-0.0033f,1.0000f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.2035f,-0.0342f,-0.0607f,-0.9766f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[-0.0417f,-0.9756f,0.2083f,0.0558f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.5207f,0.0068f,0.0112f,0.8537f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0112f,0.8537f,0.5207f,0.0068f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3611f,0.8263f,0.0918f],left_rotation:[0.1688f,0.0685f,-0.3974f,0.8993f]}}
scoreboard players set #gx driftmountains -6772
scoreboard players set #gdx driftmountains 929
scoreboard players set #gy driftmountains 66956
scoreboard players set #gdy driftmountains -12
scoreboard players set #gz driftmountains -75582
scoreboard players set #gdz driftmountains 591
scoreboard players set #gr driftmountains -4739
scoreboard players set #gdr driftmountains -96
scoreboard players set #gp driftmountains 62
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0000f,-0.0062f,1.0000f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.7761f,-0.0138f,-0.1012f,-0.6222f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.0364f,-0.6150f,0.7819f,0.0955f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.5207f,0.0068f,0.0112f,0.8537f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0112f,0.8537f,0.5207f,0.0068f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3997f,0.8348f,0.2353f],left_rotation:[0.1223f,0.1336f,-0.7025f,0.6883f]}}
particle minecraft:cloud -7.20 67.28 -77.14 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -7.20 67.08 -77.14 -0.044 0.02 -0.041 1 0 force
particle minecraft:cloud -8.36 67.28 -75.88 0.35 0.18 0.35 0.02 2 force
scoreboard players set #gx driftmountains -14756
scoreboard players set #gdx driftmountains 815
scoreboard players set #gy driftmountains 67067
scoreboard players set #gdy driftmountains -11
scoreboard players set #gz driftmountains -81192
scoreboard players set #gdz driftmountains 535
scoreboard players set #gr driftmountains -3327
scoreboard players set #gdr driftmountains -120
scoreboard players set #gp driftmountains 62
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0001f,-0.0143f,0.9999f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.2239f,-0.1835f,-0.0980f,-0.9522f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[-0.0015f,-0.9471f,0.2444f,0.2080f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.5207f,0.0068f,0.0112f,0.8537f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0112f,0.8537f,0.5207f,0.0068f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3972f,0.8564f,0.1036f],left_rotation:[-0.0563f,0.1792f,-0.9465f,-0.2622f]}}
particle minecraft:cloud -14.75 67.39 -82.70 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -14.75 67.19 -82.70 -0.030 0.02 -0.046 1 0 force
particle minecraft:cloud -16.15 67.39 -81.79 0.35 0.18 0.35 0.02 2 force
