scoreboard players set #gx driftmountains -54410
scoreboard players set #gdx driftmountains 92
scoreboard players set #gy driftmountains 68623
scoreboard players set #gdy driftmountains -21
scoreboard players set #gz driftmountains -46872
scoreboard players set #gdz driftmountains -719
scoreboard players set #gr driftmountains 15583
scoreboard players set #gdr driftmountains -97
scoreboard players set #gp driftmountains 138
scoreboard players set #gdp driftmountains 1
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,0.0001f,0.0194f,0.9998f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.4605f,0.2438f,0.0705f,-0.8506f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[-0.1603f,-0.8627f,0.4374f,-0.1967f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.8219f,0.0108f,-0.0075f,-0.5695f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0075f,-0.5695f,0.8219f,0.0108f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3811f,0.8213f,0.0899f],left_rotation:[-0.1183f,-0.1346f,0.7412f,-0.6469f]}}
particle minecraft:cloud -54.66 68.94 -45.38 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud -53.13 68.94 -46.06 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -53.13 68.74 -46.06 0.018 0.02 0.040 1 0 force
scoreboard players set #gx driftmountains -56491
scoreboard players set #gdx driftmountains 233
scoreboard players set #gy driftmountains 68759
scoreboard players set #gdy driftmountains -18
scoreboard players set #gz driftmountains -42679
scoreboard players set #gdz driftmountains -538
scoreboard players set #gr driftmountains 16948
scoreboard players set #gdr driftmountains -173
scoreboard players set #gp driftmountains 142
scoreboard players set #gdp driftmountains -1
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[-0.0039f,0.0001f,0.0213f,0.9998f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.8990f,-0.0367f,0.2299f,0.3710f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[-0.1922f,0.3489f,0.9078f,0.1314f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.8219f,0.0108f,-0.0075f,-0.5695f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0075f,-0.5695f,0.8219f,0.0108f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.4057f,0.8455f,0.2395f],left_rotation:[-0.0846f,-0.1642f,0.8541f,-0.4862f]}}
particle minecraft:cloud -57.08 69.08 -41.18 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud -55.40 69.08 -41.49 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -55.40 68.88 -41.49 0.007 0.02 0.039 1 0 force
scoreboard players set #gx driftmountains -59079
scoreboard players set #gdx driftmountains 349
scoreboard players set #gy driftmountains 68935
scoreboard players set #gdy driftmountains -19
scoreboard players set #gz driftmountains -37587
scoreboard players set #gdz driftmountains -488
scoreboard players set #gr driftmountains -17810
scoreboard players set #gdr driftmountains -56
scoreboard players set #gp driftmountains 148
scoreboard players set #gdp driftmountains -1
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,0.0001f,0.0208f,0.9998f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.0411f,-0.2479f,0.0647f,0.9657f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.0365f,0.9643f,0.0674f,0.2536f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.8219f,0.0108f,-0.0075f,-0.5695f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0075f,-0.5695f,0.8219f,0.0108f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3800f,0.8212f,0.0898f],left_rotation:[-0.1218f,-0.1316f,0.7256f,-0.6643f]}}
particle minecraft:cloud -59.95 69.26 -36.35 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud -58.29 69.26 -36.30 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -58.29 69.06 -36.30 -0.001 0.02 0.038 1 0 force
