scoreboard players set #gx driftmountains 32975
scoreboard players set #gdx driftmountains 1092
scoreboard players set #gy driftmountains 66449
scoreboard players set #gdy driftmountains -13
scoreboard players set #gz driftmountains -50531
scoreboard players set #gdz driftmountains 642
scoreboard players set #gr driftmountains -5888
scoreboard players set #gdr driftmountains 7
scoreboard players set #gp driftmountains 61
scoreboard players set #gdp driftmountains -1
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0000f,-0.0006f,1.0000f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.3102f,0.0196f,0.0487f,0.9492f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.0508f,0.9493f,0.3099f,0.0129f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.8350f,0.0109f,0.0072f,0.5501f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0072f,0.5501f,0.8350f,0.0109f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3524f,0.8415f,0.0978f],left_rotation:[0.1870f,-0.0012f,-0.0288f,0.9819f]}}
playsound driftgen:grain.kaze.002 neutral @a 41.80 66.84 -45.14 12 1
scoreboard players set #gx driftmountains 25189
scoreboard players set #gdx driftmountains 1015
scoreboard players set #gy driftmountains 66545
scoreboard players set #gdy driftmountains -14
scoreboard players set #gz driftmountains -54552
scoreboard players set #gdz driftmountains 755
scoreboard players set #gr driftmountains -5255
scoreboard players set #gdr driftmountains 118
scoreboard players set #gp driftmountains 64
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0000f,-0.0008f,1.0000f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.3670f,0.0238f,-0.0469f,-0.9287f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[-0.0505f,-0.9289f,0.3665f,0.0146f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.8350f,0.0109f,0.0072f,0.5501f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0072f,0.5501f,0.8350f,0.0109f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3618f,0.8353f,0.2355f],left_rotation:[0.1800f,-0.0140f,0.0462f,0.9825f]}}
playsound driftgen:grain.onyx.061 neutral @a 33.53 66.93 -48.53 12 1
scoreboard players set #gx driftmountains 15809
scoreboard players set #gdx driftmountains 1033
scoreboard players set #gy driftmountains 66668
scoreboard players set #gdy driftmountains -13
scoreboard players set #gz driftmountains -60987
scoreboard players set #gdz driftmountains 660
scoreboard players set #gr driftmountains -5963
scoreboard players set #gdr driftmountains -39
scoreboard players set #gp driftmountains 61
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,0.0000f,0.0015f,1.0000f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.2770f,-0.0002f,0.0545f,0.9593f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.0460f,0.9589f,0.2785f,0.0293f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.8350f,0.0109f,0.0072f,0.5501f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0072f,0.5501f,0.8350f,0.0109f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3530f,0.8492f,0.1008f],left_rotation:[0.1862f,-0.0325f,0.1389f,0.9721f]}}
playsound driftgen:grain.kaze.004 neutral @a 24.36 67.06 -55.76 12 1
