scoreboard players set #gx driftmountains 26996
scoreboard players set #gdx driftmountains -245
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 39329
scoreboard players set #gdz driftmountains 980
scoreboard players set #gr driftmountains 6854
scoreboard players set #gdr driftmountains 152
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.0818f,0.4208f,0.0198f,0.9033f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.0751f,0.9062f,0.0380f,-0.4145f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.8005f,0.0105f,0.0078f,0.5993f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0078f,0.5993f,0.8005f,0.0105f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3777f,0.8210f,0.0897f],left_rotation:[-0.1284f,-0.1253f,0.6932f,-0.6980f]}}
particle minecraft:cloud 28.47 71.32 39.65 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 28.47 71.12 39.65 0.056 0.02 -0.022 1 0 force
particle minecraft:cloud 27.86 71.32 38.09 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains 28255
scoreboard players set #gdx driftmountains 117
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 31648
scoreboard players set #gdz driftmountains 990
scoreboard players set #gr driftmountains 5371
scoreboard players set #gdr driftmountains 363
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.5871f,-0.3044f,-0.3475f,-0.6647f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.2796f,-0.6319f,0.6223f,0.3678f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.8005f,0.0105f,0.0078f,0.5993f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0078f,0.5993f,0.8005f,0.0105f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.4062f,0.8522f,0.2421f],left_rotation:[-0.0610f,-0.1766f,0.9145f,-0.3589f]}}
particle minecraft:cloud 29.86 71.32 31.53 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 29.86 71.12 31.53 0.049 0.02 -0.036 1 0 force
particle minecraft:cloud 28.85 71.32 30.15 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains 25230
scoreboard players set #gdx driftmountains 366
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 27380
scoreboard players set #gdz driftmountains 994
scoreboard players set #gr driftmountains 2779
scoreboard players set #gdr driftmountains 255
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.8091f,0.2385f,-0.3352f,0.4197f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.3812f,0.4572f,0.7885f,-0.1548f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.8005f,0.0105f,0.0078f,0.5993f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0078f,0.5993f,0.8005f,0.0105f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3728f,0.8213f,0.0898f],left_rotation:[-0.1413f,-0.1112f,0.6206f,-0.7631f]}}
particle minecraft:cloud 26.56 71.32 26.65 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 26.56 71.12 26.65 0.027 0.02 -0.051 1 0 force
particle minecraft:cloud 25.08 71.32 25.88 0.35 0.18 0.35 0.02 3 force
