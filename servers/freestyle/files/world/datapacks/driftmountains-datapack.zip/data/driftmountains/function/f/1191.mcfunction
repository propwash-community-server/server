scoreboard players set #gx driftmountains -84324
scoreboard players set #gdx driftmountains 577
scoreboard players set #gy driftmountains 69449
scoreboard players set #gdy driftmountains -13
scoreboard players set #gz driftmountains -26499
scoreboard players set #gdz driftmountains -87
scoreboard players set #gr driftmountains -7503
scoreboard players set #gdr driftmountains -176
scoreboard players set #gp driftmountains 124
scoreboard players set #gdp driftmountains -4
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0001f,-0.0154f,0.9999f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.0132f,0.1233f,0.0511f,0.9910f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.0528f,0.9911f,0.0003f,-0.1226f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.7299f,0.0096f,-0.0089f,-0.6835f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0089f,-0.6835f,0.7299f,0.0096f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3927f,0.8264f,0.0919f],left_rotation:[0.0763f,0.1628f,-0.8839f,0.4315f]}}
particle minecraft:cloud -85.33 69.77 -27.63 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -85.33 69.57 -27.63 -0.034 0.02 -0.009 1 0 force
particle minecraft:cloud -85.76 69.77 -26.02 0.35 0.18 0.35 0.02 2 force
scoreboard players set #gx driftmountains -89290
scoreboard players set #gdx driftmountains 347
scoreboard players set #gy driftmountains 69590
scoreboard players set #gdy driftmountains -12
scoreboard players set #gz driftmountains -24393
scoreboard players set #gdz driftmountains -266
scoreboard players set #gr driftmountains -8274
scoreboard players set #gdr driftmountains 87
scoreboard players set #gp driftmountains 109
scoreboard players set #gdp driftmountains -1
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.1511f,-0.3346f,-0.1114f,-0.9235f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.0149f,-0.9168f,0.1871f,0.3524f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.7299f,0.0096f,-0.0089f,-0.6835f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0089f,-0.6835f,0.7299f,0.0096f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3674f,0.8308f,0.2337f],left_rotation:[-0.1786f,-0.0142f,0.0984f,-0.9789f]}}
particle minecraft:cloud -90.54 69.91 -25.41 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -90.54 69.71 -25.41 -0.040 0.02 -0.005 1 0 force
particle minecraft:cloud -90.75 69.91 -23.72 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -92682
scoreboard players set #gdx driftmountains 559
scoreboard players set #gy driftmountains 69714
scoreboard players set #gdy driftmountains -20
scoreboard players set #gz driftmountains -21276
scoreboard players set #gdz driftmountains -523
scoreboard players set #gr driftmountains -8828
scoreboard players set #gdr driftmountains 180
scoreboard players set #gp driftmountains 103
scoreboard players set #gdp driftmountains 2
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.2654f,-0.3042f,-0.1473f,-0.9030f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.0532f,-0.8924f,0.2989f,0.3338f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.7299f,0.0096f,-0.0089f,-0.6835f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0089f,-0.6835f,0.7299f,0.0096f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3523f,0.8448f,0.0991f],left_rotation:[-0.1873f,0.0147f,-0.0431f,-0.9812f]}}
particle minecraft:cloud -93.92 70.03 -22.15 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -93.92 69.83 -22.15 -0.047 0.02 -0.001 1 0 force
particle minecraft:cloud -93.97 70.03 -20.48 0.35 0.18 0.35 0.02 3 force
