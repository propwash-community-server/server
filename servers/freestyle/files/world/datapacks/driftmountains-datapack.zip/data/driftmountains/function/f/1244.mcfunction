scoreboard players set #gx driftmountains -55472
scoreboard players set #gdx driftmountains 214
scoreboard players set #gy driftmountains 68762
scoreboard players set #gdy driftmountains -19
scoreboard players set #gz driftmountains -42126
scoreboard players set #gdz driftmountains -639
scoreboard players set #gr driftmountains 16689
scoreboard players set #gdr driftmountains -210
scoreboard players set #gp driftmountains 138
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,0.0001f,0.0200f,0.9998f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.9755f,0.0538f,0.2134f,-0.0009f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[-0.2147f,-0.0233f,0.9752f,0.0485f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.6333f,0.0083f,-0.0101f,-0.7738f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0101f,-0.7738f,0.6333f,0.0083f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3948f,0.8283f,0.0926f],left_rotation:[-0.0661f,-0.1676f,0.9078f,-0.3787f]}}
particle minecraft:cloud -56.00 69.08 -40.71 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud -54.37 69.08 -41.09 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -54.37 68.88 -41.09 0.009 0.02 0.039 1 0 force
scoreboard players set #gx driftmountains -58787
scoreboard players set #gdx driftmountains 366
scoreboard players set #gy driftmountains 68896
scoreboard players set #gdy driftmountains -19
scoreboard players set #gz driftmountains -38947
scoreboard players set #gdz driftmountains -470
scoreboard players set #gr driftmountains -17724
scoreboard players set #gdr driftmountains -99
scoreboard players set #gp driftmountains 150
scoreboard players set #gdp driftmountains -1
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[-0.0039f,0.0001f,0.0218f,0.9998f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.7238f,-0.1289f,0.2281f,0.6383f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[-0.1622f,0.6179f,0.7413f,0.2057f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.6333f,0.0083f,-0.0101f,-0.7738f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0101f,-0.7738f,0.6333f,0.0083f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3989f,0.8341f,0.2350f],left_rotation:[-0.1253f,-0.1305f,0.6870f,-0.7038f]}}
particle minecraft:cloud -59.71 69.22 -37.62 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud -58.00 69.22 -37.54 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -58.00 69.02 -37.54 -0.002 0.02 0.036 1 0 force
scoreboard players set #gx driftmountains -62043
scoreboard players set #gdx driftmountains 516
scoreboard players set #gy driftmountains 69073
scoreboard players set #gdy driftmountains -16
scoreboard players set #gz driftmountains -34502
scoreboard players set #gdz driftmountains -342
scoreboard players set #gr driftmountains -15564
scoreboard players set #gdr driftmountains -424
scoreboard players set #gp driftmountains 113
scoreboard players set #gdp driftmountains 17
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[0.0061f,-0.0001f,0.0207f,0.9998f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.1591f,0.1812f,-0.0242f,-0.9702f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[-0.0777f,-0.9730f,0.1409f,-0.1655f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.6333f,0.0083f,-0.0101f,-0.7738f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0101f,-0.7738f,0.6333f,0.0083f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.4013f,0.8431f,0.0984f],left_rotation:[-0.0003f,-0.1839f,0.9822f,-0.0363f]}}
particle minecraft:cloud -63.32 69.39 -33.70 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud -61.80 69.39 -33.01 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -61.80 69.19 -33.01 -0.016 0.02 0.035 1 0 force
