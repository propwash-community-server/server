scoreboard players set #gx driftmountains 1490
scoreboard players set #gdx driftmountains 616
scoreboard players set #gy driftmountains 70482
scoreboard players set #gdy driftmountains 2
scoreboard players set #gz driftmountains -22147
scoreboard players set #gdz driftmountains 568
scoreboard players set #gr driftmountains -225
scoreboard players set #gdr driftmountains 278
scoreboard players set #gp driftmountains 14
scoreboard players set #gdp driftmountains -55
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.8619f,-0.0826f,-0.3239f,-0.3812f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.2856f,-0.3493f,0.8754f,0.1737f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.9614f,0.0126f,0.0036f,0.2749f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0036f,0.2749f,0.9614f,0.0126f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3525f,0.8465f,0.0997f],left_rotation:[-0.1871f,0.0213f,-0.0785f,-0.9789f]}}
particle minecraft:cloud 2.27 70.80 -23.44 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 2.27 70.60 -23.44 -0.002 0.02 -0.050 1 0 force
particle minecraft:cloud 0.61 70.80 -23.37 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -2415
scoreboard players set #gdx driftmountains 642
scoreboard players set #gy driftmountains 70495
scoreboard players set #gdy driftmountains 19
scoreboard players set #gz driftmountains -25803
scoreboard players set #gdz driftmountains 453
scoreboard players set #gr driftmountains -1015
scoreboard players set #gdr driftmountains -17
scoreboard players set #gp driftmountains -121
scoreboard players set #gdp driftmountains 47
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.9247f,0.0287f,-0.3734f,-0.0688f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.3683f,-0.0299f,0.9267f,0.0683f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.9614f,0.0126f,0.0036f,0.2749f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0036f,0.2749f,0.9614f,0.0126f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3776f,0.8274f,0.2324f],left_rotation:[-0.1696f,-0.0547f,0.3049f,-0.9356f]}}
particle minecraft:cloud -1.81 70.81 -27.30 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -1.81 70.61 -27.30 -0.008 0.02 -0.046 1 0 force
particle minecraft:cloud -3.50 70.81 -27.00 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -6444
scoreboard players set #gdx driftmountains 613
scoreboard players set #gy driftmountains 70204
scoreboard players set #gdy driftmountains 66
scoreboard players set #gz driftmountains -27873
scoreboard players set #gdz driftmountains 336
scoreboard players set #gr driftmountains -1683
scoreboard players set #gdr driftmountains 283
scoreboard players set #gp driftmountains -395
scoreboard players set #gdp driftmountains 37
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0001f,-0.0223f,0.9997f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.5795f,0.2735f,-0.1407f,0.7547f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.2208f,0.7737f,0.5539f,-0.2141f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.9614f,0.0126f,0.0036f,0.2749f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0036f,0.2749f,0.9614f,0.0126f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3572f,0.8574f,0.1040f],left_rotation:[-0.1785f,0.0677f,-0.3282f,-0.9251f]}}
particle minecraft:cloud -6.01 70.52 -29.32 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -6.01 70.32 -29.32 -0.013 0.02 -0.042 1 0 force
particle minecraft:cloud -7.61 70.52 -28.84 0.35 0.18 0.35 0.02 3 force
