scoreboard players set #gx driftmountains -14446
scoreboard players set #gdx driftmountains -1054
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 59164
scoreboard players set #gdz driftmountains -310
scoreboard players set #gr driftmountains 15237
scoreboard players set #gdr driftmountains 17
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.7056f,0.2919f,-0.2601f,0.5909f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.3237f,0.6215f,0.6788f,-0.2194f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.9997f,0.0131f,-0.0002f,-0.0181f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0002f,-0.0181f,0.9997f,0.0131f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3636f,0.8246f,0.0911f],left_rotation:[-0.1633f,-0.0792f,0.4534f,-0.8726f]}}
particle minecraft:cloud -14.60 71.32 60.67 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -14.60 71.12 60.67 0.030 0.02 0.058 1 0 force
particle minecraft:cloud -13.12 71.32 59.89 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -6134
scoreboard players set #gdx driftmountains -920
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 61130
scoreboard players set #gdz driftmountains -205
scoreboard players set #gr driftmountains 15125
scoreboard players set #gdr driftmountains 251
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0001f,-0.0223f,0.9997f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.0515f,0.3675f,0.0359f,0.9279f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.0614f,0.9292f,0.0131f,-0.3641f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.9997f,0.0131f,-0.0002f,-0.0181f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0002f,-0.0181f,0.9997f,0.0131f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3750f,0.8278f,0.2325f],left_rotation:[-0.1725f,-0.0451f,0.2559f,-0.9502f]}}
particle minecraft:cloud -6.23 71.32 62.74 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -6.23 71.12 62.74 0.027 0.02 0.048 1 0 force
particle minecraft:cloud -4.73 71.32 61.92 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -771
scoreboard players set #gdx driftmountains -1021
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 62560
scoreboard players set #gdz driftmountains -166
scoreboard players set #gr driftmountains 15407
scoreboard players set #gdr driftmountains 100
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.8587f,-0.0751f,-0.4267f,-0.2736f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.4003f,-0.2303f,0.8714f,0.1658f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.9997f,0.0131f,-0.0002f,-0.0181f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0002f,-0.0181f,0.9997f,0.0131f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3835f,0.8219f,0.0901f],left_rotation:[-0.1109f,-0.1408f,0.7727f,-0.6089f]}}
particle minecraft:cloud -0.97 71.32 64.06 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -0.97 71.12 64.06 0.028 0.02 0.058 1 0 force
particle minecraft:cloud 0.53 71.32 63.33 0.35 0.18 0.35 0.02 3 force
