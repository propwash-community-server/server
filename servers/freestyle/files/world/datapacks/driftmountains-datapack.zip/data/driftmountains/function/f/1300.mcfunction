scoreboard players set #gx driftmountains -53305
scoreboard players set #gdx driftmountains 347
scoreboard players set #gy driftmountains 67858
scoreboard players set #gdy driftmountains -12
scoreboard players set #gz driftmountains -79884
scoreboard players set #gdz driftmountains -595
scoreboard players set #gr driftmountains -11901
scoreboard players set #gdr driftmountains 145
scoreboard players set #gp driftmountains 82
scoreboard players set #gdp driftmountains 1
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0001f,-0.0192f,0.9998f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.1774f,0.2404f,0.0101f,0.9543f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.0902f,0.9585f,0.1531f,-0.2230f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.2226f,0.0029f,0.0128f,0.9748f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0128f,0.9748f,0.2226f,0.0029f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3854f,0.8651f,0.1070f],left_rotation:[-0.1085f,0.1572f,-0.8194f,-0.5404f]}}
particle minecraft:cloud -54.81 68.18 -80.00 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -54.81 67.98 -80.00 -0.036 0.02 0.020 1 0 force
particle minecraft:cloud -54.00 68.18 -78.54 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -54924
scoreboard players set #gdx driftmountains 223
scoreboard players set #gy driftmountains 67946
scoreboard players set #gdy driftmountains -13
scoreboard players set #gz driftmountains -75533
scoreboard players set #gdz driftmountains -588
scoreboard players set #gr driftmountains -12479
scoreboard players set #gdr driftmountains 46
scoreboard players set #gp driftmountains 103
scoreboard players set #gdp driftmountains -5
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0001f,-0.0213f,0.9998f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.7019f,0.2190f,-0.1536f,0.6601f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.2239f,0.6799f,0.6828f,-0.1464f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.2226f,0.0029f,0.0128f,0.9748f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0128f,0.9748f,0.2226f,0.0029f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3608f,0.8650f,0.2471f],left_rotation:[-0.1375f,0.1310f,-0.6524f,-0.7337f]}}
particle minecraft:cloud -56.53 68.27 -75.46 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -56.53 68.07 -75.46 -0.030 0.02 0.021 1 0 force
particle minecraft:cloud -55.56 68.27 -74.05 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -55379
scoreboard players set #gdx driftmountains 1
scoreboard players set #gy driftmountains 68110
scoreboard players set #gdy driftmountains -14
scoreboard players set #gz driftmountains -69990
scoreboard players set #gdz driftmountains -633
scoreboard players set #gr driftmountains -14916
scoreboard players set #gdr driftmountains 201
scoreboard players set #gp driftmountains 106
scoreboard players set #gdp driftmountains 8
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[0.0061f,0.0001f,-0.0192f,0.9998f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.1173f,0.1958f,0.0301f,0.9731f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.0720f,0.9753f,0.0974f,-0.1846f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.2226f,0.0029f,0.0128f,0.9748f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0128f,0.9748f,0.2226f,0.0029f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3994f,0.8526f,0.1021f],left_rotation:[-0.0391f,0.1825f,-0.9673f,-0.1712f]}}
particle minecraft:cloud -56.74 68.43 -69.34 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -56.74 68.23 -69.34 -0.020 0.02 0.034 1 0 force
particle minecraft:cloud -55.31 68.43 -68.48 0.35 0.18 0.35 0.02 3 force
