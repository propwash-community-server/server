scoreboard players set #gx driftmountains -15499
scoreboard players set #gdx driftmountains -1060
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 58854
scoreboard players set #gdz driftmountains -314
scoreboard players set #gr driftmountains 15254
scoreboard players set #gdr driftmountains 17
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.7533f,-0.1760f,-0.3497f,-0.5285f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.2960f,-0.4947f,0.7759f,0.2561f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.2436f,0.0032f,-0.0127f,-0.9698f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0127f,-0.9698f,0.2436f,0.0032f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3637f,0.8245f,0.0911f],left_rotation:[-0.1629f,-0.0799f,0.4573f,-0.8706f]}}
particle minecraft:cloud -15.66 71.32 60.36 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -15.66 71.12 60.36 0.031 0.02 0.059 1 0 force
particle minecraft:cloud -14.18 71.32 59.59 0.35 0.18 0.35 0.02 3 force
playsound driftgen:grain.kaze.016 neutral @a -24.15 71.50 56.21 12 1
scoreboard players set #gx driftmountains -7054
scoreboard players set #gdx driftmountains -911
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 60925
scoreboard players set #gdz driftmountains -230
scoreboard players set #gr driftmountains 15376
scoreboard players set #gdr driftmountains -80
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.9066f,0.1314f,-0.3534f,0.1893f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.3752f,0.2275f,0.8978f,-0.0369f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.2436f,0.0032f,-0.0127f,-0.9698f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0127f,-0.9698f,0.2436f,0.0032f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3789f,0.8272f,0.2323f],left_rotation:[-0.1680f,-0.0593f,0.3281f,-0.9277f]}}
particle minecraft:cloud -7.22 71.32 62.53 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -7.22 71.12 62.53 0.025 0.02 0.051 1 0 force
particle minecraft:cloud -5.68 71.32 61.77 0.35 0.18 0.35 0.02 3 force
playsound driftgen:grain.onyx.001 neutral @a -14.87 71.50 58.88 12 1
scoreboard players set #gx driftmountains -1792
scoreboard players set #gdx driftmountains -1066
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 62394
scoreboard players set #gdz driftmountains -212
scoreboard players set #gr driftmountains 15507
scoreboard players set #gdr driftmountains 91
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.0419f,0.4280f,0.0381f,0.9020f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.0565f,0.9030f,-0.0029f,-0.4260f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.2436f,0.0032f,-0.0127f,-0.9698f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0127f,-0.9698f,0.2436f,0.0032f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3818f,0.8215f,0.0899f],left_rotation:[-0.1163f,-0.1364f,0.7503f,-0.6363f]}}
particle minecraft:cloud -2.02 71.32 63.89 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -2.02 71.12 63.89 0.027 0.02 0.058 1 0 force
particle minecraft:cloud -0.50 71.32 63.18 0.35 0.18 0.35 0.02 3 force
playsound driftgen:grain.kaze.017 neutral @a -10.12 71.50 60.33 12 1
