scoreboard players set #gx driftmountains 2696
scoreboard players set #gdx driftmountains 558
scoreboard players set #gy driftmountains 70504
scoreboard players set #gdy driftmountains 43
scoreboard players set #gz driftmountains -20973
scoreboard players set #gdz driftmountains 645
scoreboard players set #gr driftmountains 397
scoreboard players set #gdr driftmountains 295
scoreboard players set #gp driftmountains -157
scoreboard players set #gdp driftmountains -77
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.9288f,0.1138f,-0.3066f,0.1743f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.3266f,0.2075f,0.9219f,-0.0168f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.6916f,0.0091f,0.0095f,0.7222f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0095f,0.7222f,0.6916f,0.0091f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3531f,0.8496f,0.1010f],left_rotation:[-0.1860f,0.0341f,-0.1474f,-0.9708f]}}
particle minecraft:cloud 3.62 70.82 -22.17 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 3.62 70.62 -22.17 0.004 0.02 -0.051 1 0 force
particle minecraft:cloud 1.95 70.82 -22.29 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -1124
scoreboard players set #gdx driftmountains 655
scoreboard players set #gy driftmountains 70524
scoreboard players set #gdy driftmountains -1
scoreboard players set #gz driftmountains -24886
scoreboard players set #gdz driftmountains 485
scoreboard players set #gr driftmountains -942
scoreboard players set #gdr driftmountains 75
scoreboard players set #gp driftmountains -27
scoreboard players set #gdp driftmountains 64
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.7284f,0.2668f,-0.2440f,0.5820f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.3066f,0.6109f,0.7044f,-0.1917f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.6916f,0.0091f,0.0095f,0.7222f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0095f,0.7222f,0.6916f,0.0091f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3714f,0.8289f,0.2330f],left_rotation:[-0.1759f,-0.0308f,0.1830f,-0.9668f]}}
particle minecraft:cloud -0.50 70.84 -26.37 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -0.50 70.64 -26.37 -0.008 0.02 -0.048 1 0 force
particle minecraft:cloud -2.19 70.84 -26.09 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -5108
scoreboard players set #gdx driftmountains 569
scoreboard players set #gy driftmountains 70341
scoreboard players set #gdy driftmountains 47
scoreboard players set #gz driftmountains -27092
scoreboard players set #gdz driftmountains 374
scoreboard players set #gr driftmountains -1166
scoreboard players set #gdr driftmountains 64
scoreboard players set #gp driftmountains -307
scoreboard players set #gdp driftmountains 49
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.2589f,-0.3076f,-0.1459f,-0.9039f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.0517f,-0.8936f,0.2926f,0.3365f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.6916f,0.0091f,0.0095f,0.7222f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0095f,0.7222f,0.6916f,0.0091f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3523f,0.8437f,0.0986f],left_rotation:[-0.1873f,0.0103f,-0.0196f,-0.9820f]}}
particle minecraft:cloud -4.54 70.66 -28.49 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -4.54 70.46 -28.49 -0.009 0.02 -0.043 1 0 force
particle minecraft:cloud -6.18 70.66 -28.16 0.35 0.18 0.35 0.02 3 force
