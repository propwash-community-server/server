scoreboard players set #gx driftmountains 3729
scoreboard players set #gdx driftmountains -1049
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 63245
scoreboard players set #gdz driftmountains 30
scoreboard players set #gr driftmountains 14477
scoreboard players set #gdr driftmountains 180
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.5757f,-0.2948f,-0.3209f,-0.6918f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.2499f,-0.6619f,0.6099f,0.3570f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.0621f,0.0008f,0.0131f,0.9980f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0131f,0.9980f,0.0621f,0.0008f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3847f,0.8222f,0.0902f],left_rotation:[-0.1070f,-0.1438f,0.7880f,-0.5890f]}}
particle minecraft:cloud 3.77 71.32 64.76 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 3.77 71.12 64.76 0.037 0.02 0.052 1 0 force
particle minecraft:cloud 5.14 71.32 63.79 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains 10977
scoreboard players set #gdx driftmountains -856
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 59459
scoreboard players set #gdz driftmountains 356
scoreboard players set #gr driftmountains 12744
scoreboard players set #gdr driftmountains 297
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0001f,-0.0223f,0.9997f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.8909f,0.0311f,-0.4498f,-0.0545f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.4465f,-0.0075f,0.8926f,0.0623f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.0621f,0.0008f,0.0131f,0.9980f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0131f,0.9980f,0.0621f,0.0008f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.4059f,0.8468f,0.2400f],left_rotation:[-0.0800f,-0.1670f,0.8678f,-0.4613f]}}
particle minecraft:cloud 11.54 71.32 60.97 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 11.54 71.12 60.97 0.046 0.02 0.035 1 0 force
particle minecraft:cloud 12.58 71.32 59.61 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains 17032
scoreboard players set #gdx driftmountains -798
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 57651
scoreboard players set #gdz driftmountains 680
scoreboard players set #gr driftmountains 10783
scoreboard players set #gdr driftmountains 258
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.2718f,0.4464f,-0.0814f,0.8487f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.1710f,0.8619f,0.2264f,-0.4203f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.0621f,0.0008f,0.0131f,0.9980f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0131f,0.9980f,0.0621f,0.0008f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3925f,0.8263f,0.0918f],left_rotation:[-0.0771f,-0.1625f,0.8821f,-0.4352f]}}
particle minecraft:cloud 17.98 71.32 58.83 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 17.98 71.12 58.83 0.061 0.02 0.020 1 0 force
particle minecraft:cloud 18.49 71.32 57.24 0.35 0.18 0.35 0.02 3 force
