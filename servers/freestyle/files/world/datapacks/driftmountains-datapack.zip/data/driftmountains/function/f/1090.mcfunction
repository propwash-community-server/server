scoreboard players set #gx driftmountains -45001
scoreboard players set #gdx driftmountains -1204
scoreboard players set #gy driftmountains 70475
scoreboard players set #gdy driftmountains -5
scoreboard players set #gz driftmountains 49030
scoreboard players set #gdz driftmountains -474
scoreboard players set #gr driftmountains 15573
scoreboard players set #gdr driftmountains 39
scoreboard players set #gp driftmountains 23
scoreboard players set #gdp driftmountains -11
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.9230f,0.0238f,-0.3754f,-0.0807f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.3690f,-0.0417f,0.9256f,0.0731f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.7400f,0.0097f,-0.0088f,-0.6724f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0088f,-0.6724f,0.7400f,0.0097f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3581f,0.8290f,0.0929f],left_rotation:[-0.1750f,-0.0538f,0.3202f,-0.9294f]}}
particle minecraft:cloud -45.24 70.80 50.52 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -45.24 70.60 50.52 0.032 0.02 0.071 1 0 force
particle minecraft:cloud -43.72 70.80 49.84 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -34940
scoreboard players set #gdx driftmountains -1169
scoreboard players set #gy driftmountains 70705
scoreboard players set #gdy driftmountains -41
scoreboard players set #gz driftmountains 52798
scoreboard players set #gdz driftmountains -409
scoreboard players set #gr driftmountains 15463
scoreboard players set #gdr driftmountains 10
scoreboard players set #gp driftmountains 135
scoreboard players set #gdp driftmountains -5
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.6887f,0.2951f,-0.2455f,0.6151f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.3115f,0.6443f,0.6615f,-0.2244f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.7400f,0.0097f,-0.0088f,-0.6724f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0088f,-0.6724f,0.7400f,0.0097f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3823f,0.8272f,0.2323f],left_rotation:[-0.1633f,-0.0715f,0.3899f,-0.9034f]}}
particle minecraft:cloud -35.13 71.02 54.40 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -35.13 70.82 54.40 0.032 0.02 0.068 1 0 force
particle minecraft:cloud -33.58 71.02 53.66 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -30285
scoreboard players set #gdx driftmountains -1181
scoreboard players set #gy driftmountains 70868
scoreboard players set #gdy driftmountains -38
scoreboard players set #gz driftmountains 54642
scoreboard players set #gdz driftmountains -362
scoreboard players set #gr driftmountains 15365
scoreboard players set #gdr driftmountains 9
scoreboard players set #gp driftmountains 118
scoreboard players set #gdp driftmountains 8
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.4239f,-0.3207f,-0.2309f,-0.8150f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.1465f,-0.7952f,0.4599f,0.3670f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.7400f,0.0097f,-0.0088f,-0.6724f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0088f,-0.6724f,0.7400f,0.0097f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3653f,0.8236f,0.0908f],left_rotation:[-0.1593f,-0.0860f,0.4892f,-0.8531f]}}
particle minecraft:cloud -30.47 71.19 56.14 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -30.47 70.99 56.14 0.033 0.02 0.067 1 0 force
particle minecraft:cloud -28.98 71.19 55.40 0.35 0.18 0.35 0.02 3 force
