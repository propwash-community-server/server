scoreboard players set #gx driftmountains -98098
scoreboard players set #gdx driftmountains 62
scoreboard players set #gy driftmountains 69987
scoreboard players set #gdy driftmountains -12
scoreboard players set #gz driftmountains -10154
scoreboard players set #gdz driftmountains -813
scoreboard players set #gr driftmountains -12722
scoreboard players set #gdr driftmountains 239
scoreboard players set #gp driftmountains 53
scoreboard players set #gdp driftmountains 5
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.5974f,0.3189f,-0.1948f,0.7096f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.2705f,0.7339f,0.5672f,-0.2578f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.9766f,0.0128f,0.0028f,0.2147f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0028f,0.2147f,0.9766f,0.0128f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3574f,0.8299f,0.0932f],left_rotation:[-0.1766f,-0.0495f,0.2973f,-0.9370f]}}
particle minecraft:cloud -99.61 70.31 -10.06 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -99.61 70.11 -10.06 -0.039 0.02 0.030 1 0 force
particle minecraft:cloud -98.60 70.31 -8.73 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -97434
scoreboard players set #gdx driftmountains -199
scoreboard players set #gy driftmountains 70034
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains -2285
scoreboard players set #gdz driftmountains -893
scoreboard players set #gr driftmountains -14327
scoreboard players set #gdr driftmountains 177
scoreboard players set #gp driftmountains -1
scoreboard players set #gdp driftmountains 4
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.0517f,0.3742f,0.0356f,0.9252f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.0615f,0.9266f,0.0127f,-0.3708f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.9766f,0.0128f,0.0028f,0.2147f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0028f,0.2147f,0.9766f,0.0128f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3783f,0.8273f,0.2323f],left_rotation:[-0.1688f,-0.0572f,0.3175f,-0.9314f]}}
particle minecraft:cloud -98.94 70.35 -1.70 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -98.94 70.15 -1.70 -0.032 0.02 0.043 1 0 force
particle minecraft:cloud -97.57 70.35 -0.68 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -95547
scoreboard players set #gdx driftmountains -386
scoreboard players set #gy driftmountains 70020
scoreboard players set #gdy driftmountains 3
scoreboard players set #gz driftmountains 2719
scoreboard players set #gdz driftmountains -739
scoreboard players set #gr driftmountains -15825
scoreboard players set #gdr driftmountains 272
scoreboard players set #gp driftmountains -15
scoreboard players set #gdp driftmountains 2
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.8827f,-0.0586f,-0.3746f,-0.2776f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.3475f,-0.2397f,0.8937f,0.1517f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.9766f,0.0128f,0.0028f,0.2147f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0028f,0.2147f,0.9766f,0.0128f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3591f,0.8280f,0.0925f],left_rotation:[-0.1730f,-0.0590f,0.3476f,-0.9196f]}}
particle minecraft:cloud -96.79 70.34 3.58 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -96.79 70.14 3.58 -0.020 0.02 0.051 1 0 force
particle minecraft:cloud -95.24 70.34 4.20 0.35 0.18 0.35 0.02 3 force
