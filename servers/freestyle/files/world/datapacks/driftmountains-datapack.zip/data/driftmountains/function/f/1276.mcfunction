scoreboard players set #gx driftmountains -56061
scoreboard players set #gdx driftmountains -105
scoreboard players set #gy driftmountains 68193
scoreboard players set #gdy driftmountains -12
scoreboard players set #gz driftmountains -65090
scoreboard players set #gdz driftmountains -719
scoreboard players set #gr driftmountains -16616
scoreboard players set #gdr driftmountains 207
scoreboard players set #gp driftmountains 91
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[0.0061f,0.0001f,-0.0136f,0.9999f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.8583f,-0.0405f,-0.1821f,-0.4780f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.1329f,-0.4615f,0.8673f,0.1310f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.2793f,0.0037f,0.0126f,0.9601f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0126f,0.9601f,0.2793f,0.0037f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.4009f,0.8477f,0.1002f],left_rotation:[-0.0185f,0.1843f,-0.9807f,-0.0627f]}}
particle minecraft:cloud -57.17 68.51 -64.07 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -57.17 68.31 -64.07 -0.011 0.02 0.043 1 0 force
particle minecraft:cloud -55.55 68.51 -63.67 0.35 0.18 0.35 0.02 2 force
scoreboard players set #gx driftmountains -54565
scoreboard players set #gdx driftmountains -111
scoreboard players set #gy driftmountains 68302
scoreboard players set #gdy driftmountains -12
scoreboard players set #gz driftmountains -58895
scoreboard players set #gdz driftmountains -710
scoreboard players set #gr driftmountains 16050
scoreboard players set #gdr driftmountains 407
scoreboard players set #gp driftmountains 98
scoreboard players set #gdp driftmountains -1
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[-0.0039f,0.0000f,0.0064f,1.0000f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.7089f,-0.0239f,0.0992f,0.6979f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[-0.0263f,0.6914f,0.7153f,0.0985f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.2793f,0.0037f,0.0126f,0.9601f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0126f,0.9601f,0.2793f,0.0037f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3632f,0.8676f,0.2481f],left_rotation:[0.1287f,-0.1409f,0.7043f,0.6838f]}}
particle minecraft:cloud -54.92 68.62 -57.32 0.35 0.18 0.35 0.02 2 force
particle minecraft:cloud -53.30 68.62 -57.89 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -53.30 68.42 -57.89 0.014 0.02 0.041 1 0 force
scoreboard players set #gx driftmountains -53853
scoreboard players set #gdx driftmountains 2
scoreboard players set #gy driftmountains 68424
scoreboard players set #gdy driftmountains -18
scoreboard players set #gz driftmountains -53144
scoreboard players set #gdz driftmountains -649
scoreboard players set #gr driftmountains 15111
scoreboard players set #gdr driftmountains -290
scoreboard players set #gp driftmountains 145
scoreboard players set #gdp driftmountains -22
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[0.0005f,-0.0000f,0.0188f,0.9998f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.0655f,0.1773f,-0.0414f,-0.9811f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[-0.0615f,-0.9822f,0.0472f,-0.1714f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.2793f,0.0037f,0.0126f,0.9601f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0126f,0.9601f,0.2793f,0.0037f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.4013f,0.8434f,0.0985f],left_rotation:[0.0010f,-0.1840f,0.9824f,-0.0293f]}}
particle minecraft:cloud -53.98 68.74 -51.64 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud -52.51 68.74 -52.44 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -52.51 68.54 -52.44 0.019 0.02 0.034 1 0 force
