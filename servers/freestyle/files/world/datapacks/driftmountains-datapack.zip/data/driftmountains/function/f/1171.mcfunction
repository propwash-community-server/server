scoreboard players set #gx driftmountains -95010
scoreboard players set #gdx driftmountains 485
scoreboard players set #gy driftmountains 69802
scoreboard players set #gdy driftmountains -19
scoreboard players set #gz driftmountains -18667
scoreboard players set #gdz driftmountains -614
scoreboard players set #gr driftmountains -9495
scoreboard players set #gdr driftmountains 87
scoreboard players set #gp driftmountains 93
scoreboard players set #gdp driftmountains 3
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.8720f,-0.0741f,-0.3504f,-0.3336f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.3173f,-0.2986f,0.8846f,0.1662f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.9699f,0.0127f,0.0032f,0.2433f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0032f,0.2433f,0.9699f,0.0127f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3538f,0.8360f,0.0956f],left_rotation:[-0.1841f,-0.0217f,0.1507f,-0.9710f]}}
particle minecraft:cloud -96.34 70.12 -19.39 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -96.34 69.92 -19.39 -0.047 0.02 0.004 1 0 force
particle minecraft:cloud -96.19 70.12 -17.73 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -97886
scoreboard players set #gdx driftmountains 143
scoreboard players set #gy driftmountains 69951
scoreboard players set #gdy driftmountains -14
scoreboard players set #gz driftmountains -12338
scoreboard players set #gdz driftmountains -769
scoreboard players set #gr driftmountains -12086
scoreboard players set #gdr driftmountains 289
scoreboard players set #gp driftmountains 65
scoreboard players set #gdp driftmountains 4
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.6567f,-0.2069f,-0.2815f,-0.6684f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.2128f,-0.6425f,0.6820f,0.2771f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.9699f,0.0127f,0.0032f,0.2433f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0032f,0.2433f,0.9699f,0.0127f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3661f,0.8317f,0.2341f],left_rotation:[-0.1792f,-0.0079f,0.0661f,-0.9816f]}}
particle minecraft:cloud -99.50 70.27 -12.37 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -99.50 70.07 -12.37 -0.040 0.02 0.024 1 0 force
particle minecraft:cloud -98.62 70.27 -10.90 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -98239
scoreboard players set #gdx driftmountains -18
scoreboard players set #gy driftmountains 70016
scoreboard players set #gdy driftmountains -7
scoreboard players set #gz driftmountains -7413
scoreboard players set #gdz driftmountains -823
scoreboard players set #gr driftmountains -13200
scoreboard players set #gdr driftmountains 190
scoreboard players set #gp driftmountains 29
scoreboard players set #gdp driftmountains 6
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.9225f,0.0268f,-0.3781f,-0.0728f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.3726f,-0.0335f,0.9248f,0.0700f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.9699f,0.0127f,0.0032f,0.2433f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0032f,0.2433f,0.9699f,0.0127f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3591f,0.8280f,0.0925f],left_rotation:[-0.1730f,-0.0589f,0.3469f,-0.9199f]}}
particle minecraft:cloud -99.73 70.34 -7.19 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -99.73 70.14 -7.19 -0.037 0.02 0.033 1 0 force
particle minecraft:cloud -98.62 70.34 -5.95 0.35 0.18 0.35 0.02 3 force
