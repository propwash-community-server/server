scoreboard players set #gx driftmountains -11321
scoreboard players set #gdx driftmountains -1035
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 60066
scoreboard players set #gdz driftmountains -296
scoreboard players set #gr driftmountains 15249
scoreboard players set #gdr driftmountains -26
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.0812f,0.3942f,0.0221f,0.9152f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.0739f,0.9179f,0.0402f,-0.3878f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.7248f,0.0095f,0.0090f,0.6888f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0090f,0.6888f,0.7248f,0.0095f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3652f,0.8237f,0.0908f],left_rotation:[-0.1597f,-0.0854f,0.4860f,-0.8549f]}}
particle minecraft:cloud -11.48 71.32 61.57 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -11.48 71.12 61.57 0.030 0.02 0.057 1 0 force
particle minecraft:cloud -10.00 71.32 60.80 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -3322
scoreboard players set #gdx driftmountains -988
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 61363
scoreboard players set #gdz driftmountains -24
scoreboard players set #gr driftmountains 14219
scoreboard players set #gdr driftmountains 281
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.6127f,-0.2510f,-0.3001f,-0.6867f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.2296f,-0.6589f,0.6425f,0.3168f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.7248f,0.0095f,0.0090f,0.6888f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0090f,0.6888f,0.7248f,0.0095f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3860f,0.8276f,0.2325f],left_rotation:[-0.1573f,-0.0843f,0.4546f,-0.8726f]}}
particle minecraft:cloud -3.16 71.32 62.97 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -3.16 71.12 62.97 0.034 0.02 0.043 1 0 force
particle minecraft:cloud -1.81 71.32 61.92 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains 2464
scoreboard players set #gdx driftmountains -1086
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 62855
scoreboard players set #gdz driftmountains -60
scoreboard players set #gr driftmountains 15128
scoreboard players set #gdr driftmountains 87
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.7918f,0.2586f,-0.3742f,0.4076f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.4191f,0.4492f,0.7690f,-0.1768f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.7248f,0.0095f,0.0090f,0.6888f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0090f,0.6888f,0.7248f,0.0095f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3930f,0.8266f,0.0919f],left_rotation:[-0.0751f,-0.1634f,0.8870f,-0.4252f]}}
particle minecraft:cloud 2.34 71.32 64.36 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 2.34 71.12 64.36 0.032 0.02 0.058 1 0 force
particle minecraft:cloud 3.80 71.32 63.56 0.35 0.18 0.35 0.02 3 force
