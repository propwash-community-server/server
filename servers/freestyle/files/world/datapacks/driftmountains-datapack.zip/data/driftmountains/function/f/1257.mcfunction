scoreboard players set #gx driftmountains -53936
scoreboard players set #gdx driftmountains 46
scoreboard players set #gy driftmountains 68490
scoreboard players set #gdy driftmountains -28
scoreboard players set #gz driftmountains -51271
scoreboard players set #gdz driftmountains -717
scoreboard players set #gr driftmountains 15334
scoreboard players set #gdr driftmountains -416
scoreboard players set #gp driftmountains 192
scoreboard players set #gdp driftmountains -15
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[0.0061f,-0.0001f,0.0196f,0.9998f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.1313f,0.2189f,-0.0243f,-0.9666f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[-0.0771f,-0.9693f,0.1090f,-0.2063f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.5574f,0.0073f,0.0109f,0.8301f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0109f,0.8301f,0.5574f,0.0073f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3947f,0.8282f,0.0926f],left_rotation:[-0.0664f,-0.1675f,0.9071f,-0.3802f]}}
particle minecraft:cloud -54.12 68.81 -49.77 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud -52.62 68.81 -50.52 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -52.62 68.61 -50.52 0.020 0.02 0.039 1 0 force
scoreboard players set #gx driftmountains -55184
scoreboard players set #gdx driftmountains 169
scoreboard players set #gy driftmountains 68636
scoreboard players set #gdy driftmountains -21
scoreboard players set #gz driftmountains -46606
scoreboard players set #gdz driftmountains -705
scoreboard players set #gr driftmountains 16010
scoreboard players set #gdr driftmountains -94
scoreboard players set #gp driftmountains 139
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[-0.0039f,0.0001f,0.0207f,0.9998f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.8695f,-0.0630f,0.2562f,0.4176f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[-0.2138f,0.3930f,0.8809f,0.1547f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.5574f,0.0073f,0.0109f,0.8301f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0109f,0.8301f,0.5574f,0.0073f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3982f,0.8335f,0.2348f],left_rotation:[-0.1276f,-0.1279f,0.6742f,-0.7161f]}}
particle minecraft:cloud -55.52 68.96 -45.03 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud -53.92 68.96 -45.61 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -53.92 68.76 -45.61 0.015 0.02 0.040 1 0 force
scoreboard players set #gx driftmountains -56978
scoreboard players set #gdx driftmountains 280
scoreboard players set #gy driftmountains 68814
scoreboard players set #gdy driftmountains -19
scoreboard players set #gz driftmountains -40902
scoreboard players set #gdz driftmountains -575
scoreboard players set #gr driftmountains 17407
scoreboard players set #gdr driftmountains -179
scoreboard players set #gp driftmountains 146
scoreboard players set #gdp driftmountains -1
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.3090f,0.2230f,0.0180f,-0.9244f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[-0.1153f,-0.9313f,0.2873f,-0.1918f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.5574f,0.0073f,0.0109f,0.8301f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0109f,0.8301f,0.5574f,0.0073f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3936f,0.8272f,0.0921f],left_rotation:[-0.0722f,-0.1649f,0.8940f,-0.4102f]}}
particle minecraft:cloud -57.68 69.13 -39.56 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud -56.02 69.13 -39.74 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -56.02 68.93 -39.74 0.004 0.02 0.040 1 0 force
