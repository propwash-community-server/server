scoreboard players set #gx driftmountains 11965
scoreboard players set #gdx driftmountains -949
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 60934
scoreboard players set #gdz driftmountains 479
scoreboard players set #gr driftmountains 11969
scoreboard players set #gdr driftmountains 377
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0001f,-0.0223f,0.9997f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.8906f,0.1291f,-0.4079f,0.1538f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.4263f,0.1975f,0.8820f,-0.0362f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.8223f,0.0108f,-0.0074f,-0.5689f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0074f,-0.5689f,0.8223f,0.0108f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3809f,0.8213f,0.0898f],left_rotation:[-0.1189f,-0.1341f,0.7385f,-0.6499f]}}
particle minecraft:cloud 12.65 71.32 62.28 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 12.65 71.12 62.28 0.055 0.02 0.031 1 0 force
particle minecraft:cloud 13.47 71.32 60.83 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains 17556
scoreboard players set #gdx driftmountains -744
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 54977
scoreboard players set #gdz driftmountains 652
scoreboard players set #gr driftmountains 10724
scoreboard players set #gdr driftmountains 181
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.4896f,0.4163f,-0.2053f,0.7381f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.2840f,0.7638f,0.4486f,-0.3671f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.8223f,0.0108f,-0.0074f,-0.5689f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0074f,-0.5689f,0.8223f,0.0108f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.4061f,0.8533f,0.2425f],left_rotation:[-0.0572f,-0.1782f,0.9222f,-0.3384f]}}
particle minecraft:cloud 18.61 71.32 56.20 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 18.61 71.12 56.20 0.061 0.02 0.019 1 0 force
particle minecraft:cloud 19.11 71.32 54.57 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains 22695
scoreboard players set #gdx driftmountains -606
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 51005
scoreboard players set #gdz driftmountains 909
scoreboard players set #gr driftmountains 8941
scoreboard players set #gdr driftmountains 210
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.6035f,-0.2850f,-0.3380f,-0.6635f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.2702f,-0.6316f,0.6368f,0.3500f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.8223f,0.0108f,-0.0074f,-0.5689f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0074f,-0.5689f,0.8223f,0.0108f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3877f,0.8233f,0.0906f],left_rotation:[-0.0967f,-0.1510f,0.8246f,-0.5364f]}}
particle minecraft:cloud 23.96 71.32 51.83 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 23.96 71.12 51.83 0.066 0.02 -0.001 1 0 force
particle minecraft:cloud 23.95 71.32 50.16 0.35 0.18 0.35 0.02 3 force
