scoreboard players set #gx driftmountains -3297
scoreboard players set #gdx driftmountains -974
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 62383
scoreboard players set #gdz driftmountains -299
scoreboard players set #gr driftmountains 15989
scoreboard players set #gdr driftmountains -48
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.7423f,-0.1919f,-0.3724f,-0.5230f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.3194f,-0.4867f,0.7666f,0.2710f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.2151f,0.0028f,-0.0128f,-0.9765f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0128f,-0.9765f,0.2151f,0.0028f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3765f,0.8210f,0.0897f],left_rotation:[-0.1316f,-0.1221f,0.6766f,-0.7140f]}}
particle minecraft:cloud -3.65 71.32 63.85 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -3.65 71.12 63.85 0.021 0.02 0.057 1 0 force
particle minecraft:cloud -2.08 71.32 63.28 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains 4271
scoreboard players set #gdx driftmountains -970
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 61142
scoreboard players set #gdz driftmountains 58
scoreboard players set #gr driftmountains 14526
scoreboard players set #gdr driftmountains 142
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.8746f,0.1465f,-0.4266f,0.1779f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.4476f,0.2237f,0.8640f,-0.0554f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.2151f,0.0028f,-0.0128f,-0.9765f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0128f,-0.9765f,0.2151f,0.0028f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.4060f,0.8469f,0.2400f],left_rotation:[-0.0797f,-0.1672f,0.8686f,-0.4596f]}}
particle minecraft:cloud 4.35 71.32 62.75 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 4.35 71.12 62.75 0.034 0.02 0.049 1 0 force
particle minecraft:cloud 5.75 71.32 61.78 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains 10882
scoreboard players set #gdx driftmountains -1064
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 61512
scoreboard players set #gdz driftmountains 380
scoreboard players set #gr driftmountains 13053
scoreboard players set #gdr driftmountains 346
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0001f,-0.0223f,0.9997f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.0431f,0.4569f,0.0367f,0.8877f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.0564f,0.8887f,-0.0047f,-0.4549f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.2151f,0.0028f,-0.0128f,-0.9765f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0128f,-0.9765f,0.2151f,0.0028f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3943f,0.8278f,0.0924f],left_rotation:[-0.0688f,-0.1664f,0.9019f,-0.3926f]}}
particle minecraft:cloud 11.30 71.32 62.97 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 11.30 71.12 62.97 0.047 0.02 0.041 1 0 force
particle minecraft:cloud 12.38 71.32 61.70 0.35 0.18 0.35 0.02 3 force
