scoreboard players set #gx driftmountains -2328
scoreboard players set #gdx driftmountains -969
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 62673
scoreboard players set #gdz driftmountains -290
scoreboard players set #gr driftmountains 15880
scoreboard players set #gdr driftmountains 110
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.7001f,0.3041f,-0.2747f,0.5848f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.3376f,0.6169f,0.6720f,-0.2322f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.9988f,0.0131f,-0.0006f,-0.0475f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0006f,-0.0475f,0.9988f,0.0131f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3720f,0.8214f,0.0899f],left_rotation:[-0.1433f,-0.1088f,0.6082f,-0.7731f]}}
particle minecraft:cloud -2.65 71.32 64.15 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -2.65 71.12 64.15 0.022 0.02 0.056 1 0 force
particle minecraft:cloud -1.09 71.32 63.55 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains 5254
scoreboard players set #gdx driftmountains -982
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 61040
scoreboard players set #gdz driftmountains 102
scoreboard players set #gr driftmountains 14327
scoreboard players set #gdr driftmountains 198
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[0.0061f,0.0001f,-0.0223f,0.9997f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.0545f,0.4496f,0.0312f,0.8910f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.0623f,0.8926f,0.0075f,-0.4464f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.9988f,0.0131f,-0.0006f,-0.0475f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0006f,-0.0475f,0.9988f,0.0131f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.4059f,0.8468f,0.2400f],left_rotation:[-0.0802f,-0.1668f,0.8670f,-0.4627f]}}
particle minecraft:cloud 5.38 71.32 62.65 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 5.38 71.12 62.65 0.036 0.02 0.049 1 0 force
particle minecraft:cloud 6.76 71.32 61.62 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains 11832
scoreboard players set #gdx driftmountains -950
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 61109
scoreboard players set #gdz driftmountains 403
scoreboard players set #gr driftmountains 12698
scoreboard players set #gdr driftmountains 355
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[-0.0036f,-0.0001f,-0.0223f,0.9997f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.8477f,-0.0820f,-0.4483f,-0.2716f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.4222f,-0.2260f,0.8610f,0.1715f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.9988f,0.0131f,-0.0006f,-0.0475f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0006f,-0.0475f,0.9988f,0.0131f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3933f,0.8269f,0.0920f],left_rotation:[-0.0736f,-0.1642f,0.8906f,-0.4176f]}}
particle minecraft:cloud 12.34 71.32 62.53 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 12.34 71.12 62.53 0.049 0.02 0.037 1 0 force
particle minecraft:cloud 13.34 71.32 61.20 0.35 0.18 0.35 0.02 3 force
