scoreboard players set #gx driftmountains -52958
scoreboard players set #gdx driftmountains 364
scoreboard players set #gy driftmountains 67847
scoreboard players set #gdy driftmountains -12
scoreboard players set #gz driftmountains -80479
scoreboard players set #gdz driftmountains -594
scoreboard players set #gr driftmountains -11755
scoreboard players set #gdr driftmountains 145
scoreboard players set #gp driftmountains 83
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0001f,-0.0193f,0.9998f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.9134f,0.1296f,-0.2007f,0.3295f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.2365f,0.3525f,0.9048f,-0.0344f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.9991f,0.0131f,0.0005f,0.0398f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0005f,0.0398f,0.9991f,0.0131f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3861f,0.8648f,0.1069f],left_rotation:[-0.1061f,0.1587f,-0.8277f,-0.5276f]}}
particle minecraft:cloud -54.46 68.17 -80.64 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -54.46 67.97 -80.64 -0.037 0.02 0.019 1 0 force
particle minecraft:cloud -53.69 68.17 -79.16 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -54701
scoreboard players set #gdx driftmountains 240
scoreboard players set #gy driftmountains 67933
scoreboard players set #gdy driftmountains -13
scoreboard players set #gz driftmountains -76121
scoreboard players set #gdz driftmountains -604
scoreboard players set #gr driftmountains -12433
scoreboard players set #gdr driftmountains 50
scoreboard players set #gp driftmountains 99
scoreboard players set #gdp driftmountains -3
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0001f,-0.0211f,0.9998f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.9452f,0.0024f,-0.2679f,-0.1868f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.2497f,-0.1597f,0.9501f,0.0970f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.9991f,0.0131f,0.0005f,0.0398f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0005f,0.0398f,0.9991f,0.0131f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3607f,0.8648f,0.2470f],left_rotation:[-0.1380f,0.1305f,-0.6497f,-0.7361f]}}
particle minecraft:cloud -56.31 68.25 -76.06 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -56.31 68.05 -76.06 -0.031 0.02 0.021 1 0 force
particle minecraft:cloud -55.35 68.25 -74.64 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -55378
scoreboard players set #gdx driftmountains 30
scoreboard players set #gy driftmountains 68096
scoreboard players set #gdy driftmountains -17
scoreboard players set #gz driftmountains -70623
scoreboard players set #gdz driftmountains -651
scoreboard players set #gr driftmountains -14715
scoreboard players set #gdr driftmountains 427
scoreboard players set #gp driftmountains 113
scoreboard players set #gdp driftmountains 26
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[0.0057f,0.0001f,-0.0194f,0.9998f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.8765f,0.1270f,-0.1326f,0.4450f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.1801f,0.4614f,0.8680f,-0.0355f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.9991f,0.0131f,0.0005f,0.0398f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0005f,0.0398f,0.9991f,0.0131f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.4011f,0.8464f,0.0997f],left_rotation:[-0.0131f,0.1843f,-0.9821f,-0.0342f]}}
particle minecraft:cloud -56.76 68.42 -70.02 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -56.76 68.22 -70.02 -0.021 0.02 0.033 1 0 force
particle minecraft:cloud -55.36 68.42 -69.11 0.35 0.18 0.35 0.02 3 force
