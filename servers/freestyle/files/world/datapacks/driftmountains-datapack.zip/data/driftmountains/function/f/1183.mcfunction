scoreboard players set #gx driftmountains -88629
scoreboard players set #gdx driftmountains 541
scoreboard players set #gy driftmountains 69575
scoreboard players set #gdy driftmountains -17
scoreboard players set #gz driftmountains -24569
scoreboard players set #gdz driftmountains -336
scoreboard players set #gr driftmountains -7812
scoreboard players set #gdr driftmountains 144
scoreboard players set #gp driftmountains 110
scoreboard players set #gdp driftmountains -1
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.6578f,-0.1987f,-0.2715f,-0.6738f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.2022f,-0.6490f,0.6823f,0.2689f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.9623f,0.0126f,0.0036f,0.2716f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0036f,0.2716f,0.9623f,0.0126f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3524f,0.8455f,0.0993f],left_rotation:[-0.1873f,0.0174f,-0.0579f,-0.9804f]}}
particle minecraft:cloud -89.69 69.89 -25.65 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -89.69 69.69 -25.65 -0.038 0.02 -0.008 1 0 force
particle minecraft:cloud -90.03 69.89 -24.01 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -93569
scoreboard players set #gdx driftmountains 528
scoreboard players set #gy driftmountains 69744
scoreboard players set #gdy driftmountains -20
scoreboard players set #gz driftmountains -20474
scoreboard players set #gdz driftmountains -579
scoreboard players set #gr driftmountains -9256
scoreboard players set #gdr driftmountains 129
scoreboard players set #gp driftmountains 101
scoreboard players set #gdp driftmountains 2
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.5758f,0.3045f,-0.1662f,0.7404f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.2449f,0.7619f,0.5469f,-0.2456f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.9623f,0.0126f,0.0036f,0.2716f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0036f,0.2716f,0.9623f,0.0126f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3651f,0.8324f,0.2343f],left_rotation:[-0.1796f,-0.0033f,0.0423f,-0.9829f]}}
particle minecraft:cloud -94.97 70.06 -21.27 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -94.97 69.86 -21.27 -0.047 0.02 0.002 1 0 force
particle minecraft:cloud -94.89 70.06 -19.56 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -96532
scoreboard players set #gdx driftmountains 440
scoreboard players set #gy driftmountains 69865
scoreboard players set #gdy driftmountains -19
scoreboard players set #gz driftmountains -16375
scoreboard players set #gdz driftmountains -736
scoreboard players set #gr driftmountains -10065
scoreboard players set #gdr driftmountains 299
scoreboard players set #gp driftmountains 81
scoreboard players set #gdp driftmountains 3
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.2658f,-0.3124f,-0.1504f,-0.8995f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.0567f,-0.8886f,0.3001f,0.3421f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.9623f,0.0126f,0.0036f,0.2716f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0036f,0.2716f,0.9623f,0.0126f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3525f,0.8409f,0.0975f],left_rotation:[-0.1868f,-0.0011f,0.0411f,-0.9815f]}}
particle minecraft:cloud -97.93 70.19 -16.96 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -97.93 69.99 -16.96 -0.045 0.02 0.008 1 0 force
particle minecraft:cloud -97.62 70.19 -15.32 0.35 0.18 0.35 0.02 3 force
