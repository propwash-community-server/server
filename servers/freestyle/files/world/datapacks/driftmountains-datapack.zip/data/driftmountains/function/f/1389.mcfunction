scoreboard players set #gx driftmountains 6291
scoreboard players set #gdx driftmountains 886
scoreboard players set #gy driftmountains 66788
scoreboard players set #gdy driftmountains -11
scoreboard players set #gz driftmountains -67166
scoreboard players set #gdz driftmountains 603
scoreboard players set #gr driftmountains -5308
scoreboard players set #gdr driftmountains -79
scoreboard players set #gp driftmountains 61
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0000f,-0.0016f,1.0000f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.4508f,0.0030f,-0.0572f,-0.8908f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[-0.0361f,-0.8897f,0.4530f,0.0444f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.2655f,0.0035f,0.0126f,0.9640f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0126f,0.9640f,0.2655f,0.0035f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3548f,0.8337f,0.0947f],left_rotation:[0.1819f,0.0318f,-0.2039f,0.9614f]}}
scoreboard players set #gx driftmountains -685
scoreboard players set #gdx driftmountains 880
scoreboard players set #gy driftmountains 66877
scoreboard players set #gdy driftmountains -11
scoreboard players set #gz driftmountains -71690
scoreboard players set #gdz driftmountains 568
scoreboard players set #gr driftmountains -5151
scoreboard players set #gdr driftmountains -30
scoreboard players set #gp driftmountains 61
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0000f,-0.0035f,1.0000f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.9141f,0.0289f,-0.0648f,-0.3993f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.0231f,-0.3947f,0.9161f,0.0670f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.2655f,0.0035f,0.0126f,0.9640f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0126f,0.9640f,0.2655f,0.0035f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3836f,0.8273f,0.2323f],left_rotation:[0.1614f,0.0759f,-0.4123f,0.8935f]}}
scoreboard players set #gx driftmountains -9154
scoreboard players set #gdx driftmountains 807
scoreboard players set #gy driftmountains 66989
scoreboard players set #gdy driftmountains -11
scoreboard players set #gz driftmountains -77497
scoreboard players set #gdz driftmountains 535
scoreboard players set #gr driftmountains -4224
scoreboard players set #gdr driftmountains -124
scoreboard players set #gp driftmountains 62
scoreboard players set #gdp driftmountains -1
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0000f,-0.0087f,1.0000f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.4726f,-0.0827f,-0.1049f,-0.8711f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.0139f,-0.8649f,0.4838f,0.1328f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.2655f,0.0035f,0.0126f,0.9640f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0126f,0.9640f,0.2655f,0.0035f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3927f,0.8265f,0.0919f],left_rotation:[0.0762f,0.1629f,-0.8842f,0.4309f]}}
particle minecraft:cloud -9.38 67.31 -78.99 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -9.38 67.11 -78.99 -0.040 0.02 -0.045 1 0 force
particle minecraft:cloud -10.62 67.31 -77.87 0.35 0.18 0.35 0.02 2 force
