scoreboard players set #gx driftmountains -40229
scoreboard players set #gdx driftmountains -1187
scoreboard players set #gy driftmountains 70542
scoreboard players set #gdy driftmountains -25
scoreboard players set #gz driftmountains 50842
scoreboard players set #gdz driftmountains -438
scoreboard players set #gr driftmountains 15480
scoreboard players set #gdr driftmountains 20
scoreboard players set #gp driftmountains 89
scoreboard players set #gdp driftmountains -18
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.3916f,-0.3133f,-0.2083f,-0.8397f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.1212f,-0.8224f,0.4267f,0.3562f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.2219f,0.0029f,0.0128f,0.9750f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0128f,0.9750f,0.2219f,0.0029f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3582f,0.8290f,0.0929f],left_rotation:[-0.1750f,-0.0539f,0.3208f,-0.9292f]}}
particle minecraft:cloud -40.45 70.86 52.34 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -40.45 70.66 52.34 0.032 0.02 0.069 1 0 force
particle minecraft:cloud -38.94 70.86 51.63 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -30322
scoreboard players set #gdx driftmountains -1117
scoreboard players set #gy driftmountains 70865
scoreboard players set #gdy driftmountains -37
scoreboard players set #gz driftmountains 54343
scoreboard players set #gdz driftmountains -364
scoreboard players set #gr driftmountains 15420
scoreboard players set #gdr driftmountains 15
scoreboard players set #gp driftmountains 119
scoreboard players set #gdp driftmountains 8
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.8743f,-0.0671f,-0.3845f,-0.2884f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.3564f,-0.2496f,0.8862f,0.1593f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.2219f,0.0029f,0.0128f,0.9750f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0128f,0.9750f,0.2219f,0.0029f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3855f,0.8276f,0.2324f],left_rotation:[-0.1581f,-0.0828f,0.4472f,-0.8765f]}}
particle minecraft:cloud -30.50 71.18 55.94 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -30.50 70.98 55.94 0.032 0.02 0.067 1 0 force
particle minecraft:cloud -28.96 71.18 55.20 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -25595
scoreboard players set #gdx driftmountains -1160
scoreboard players set #gy driftmountains 70984
scoreboard players set #gdy driftmountains -21
scoreboard players set #gz driftmountains 56033
scoreboard players set #gdz driftmountains -339
scoreboard players set #gr driftmountains 15257
scoreboard players set #gdr driftmountains 20
scoreboard players set #gp driftmountains 54
scoreboard players set #gdp driftmountains 29
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.4941f,0.3590f,-0.1614f,0.7752f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.2438f,0.7964f,0.4591f,-0.3091f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.2219f,0.0029f,0.0128f,0.9750f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0128f,0.9750f,0.2219f,0.0029f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3647f,0.8240f,0.0909f],left_rotation:[-0.1608f,-0.0835f,0.4764f,-0.8603f]}}
particle minecraft:cloud -25.76 71.30 57.54 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -25.76 71.10 57.54 0.034 0.02 0.065 1 0 force
particle minecraft:cloud -24.27 71.30 56.77 0.35 0.18 0.35 0.02 3 force
