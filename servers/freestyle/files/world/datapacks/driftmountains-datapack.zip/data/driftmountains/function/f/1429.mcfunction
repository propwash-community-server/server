scoreboard players set #gx driftmountains 47447
scoreboard players set #gdx driftmountains 1137
scoreboard players set #gy driftmountains 66282
scoreboard players set #gdy driftmountains -12
scoreboard players set #gz driftmountains -41550
scoreboard players set #gdz driftmountains 747
scoreboard players set #gr driftmountains -3142
scoreboard players set #gdr driftmountains -55
scoreboard players set #gp driftmountains 48
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0001f,-0.0155f,0.9999f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.9733f,0.0395f,-0.2170f,-0.0638f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.2115f,-0.0413f,0.9745f,0.0626f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.7682f,0.0101f,-0.0084f,-0.6401f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0084f,-0.6401f,0.7682f,0.0101f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3934f,0.8605f,0.1052f],left_rotation:[-0.0773f,0.1727f,-0.9080f,-0.3736f]}}
particle minecraft:cloud 47.50 66.60 -43.06 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke 47.50 66.40 -43.06 -0.042 0.02 -0.070 1 0 force
particle minecraft:cloud 46.08 66.60 -42.19 0.35 0.18 0.35 0.02 2 force
scoreboard players set #gx driftmountains 38990
scoreboard players set #gdx driftmountains 1056
scoreboard players set #gy driftmountains 66365
scoreboard players set #gdy driftmountains -12
scoreboard players set #gz driftmountains -44724
scoreboard players set #gdz driftmountains 704
scoreboard players set #gr driftmountains -4515
scoreboard players set #gdr driftmountains 225
scoreboard players set #gp driftmountains 55
scoreboard players set #gdp driftmountains -1
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0000f,-0.0067f,1.0000f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.8011f,0.1039f,-0.0528f,0.5870f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.1148f,0.5958f,0.7946f,-0.0203f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.7682f,0.0101f,-0.0084f,-0.6401f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0084f,-0.6401f,0.7682f,0.0101f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.4039f,0.8407f,0.2376f],left_rotation:[0.1012f,0.1527f,-0.7973f,0.5752f]}}
particle minecraft:cloud 38.63 66.68 -46.29 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke 38.63 66.48 -46.29 -0.057 0.02 -0.057 1 0 force
particle minecraft:cloud 37.42 66.68 -45.08 0.35 0.18 0.35 0.02 2 force
scoreboard players set #gx driftmountains 29794
scoreboard players set #gdx driftmountains 1002
scoreboard players set #gy driftmountains 66491
scoreboard players set #gdy driftmountains -14
scoreboard players set #gz driftmountains -52674
scoreboard players set #gdz driftmountains 728
scoreboard players set #gr driftmountains -5184
scoreboard players set #gdr driftmountains -28
scoreboard players set #gp driftmountains 64
scoreboard players set #gdp driftmountains -1
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0000f,-0.0015f,1.0000f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.9984f,0.0524f,0.0029f,-0.0198f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[-0.0050f,-0.0202f,0.9984f,0.0522f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.7682f,0.0101f,-0.0084f,-0.6401f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0084f,-0.6401f,0.7682f,0.0101f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3523f,0.8446f,0.0990f],left_rotation:[0.1873f,-0.0137f,0.0379f,0.9814f]}}
