scoreboard players set #gx driftmountains 4767
scoreboard players set #gdx driftmountains 465
scoreboard players set #gy driftmountains 70737
scoreboard players set #gdy driftmountains 65
scoreboard players set #gz driftmountains -18213
scoreboard players set #gdz driftmountains 749
scoreboard players set #gr driftmountains 1242
scoreboard players set #gdr driftmountains 36
scoreboard players set #gp driftmountains -306
scoreboard players set #gdp driftmountains 18
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.2807f,0.3464f,-0.0503f,0.8937f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.1445f,0.9039f,0.2458f,-0.3188f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.2890f,0.0038f,-0.0125f,-0.9572f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0125f,-0.9572f,0.2890f,0.0038f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3528f,0.8395f,0.0970f],left_rotation:[-0.1862f,-0.0071f,0.0730f,-0.9797f]}}
particle minecraft:cloud 5.85 71.06 -19.26 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 5.85 70.86 -19.26 0.011 0.02 -0.051 1 0 force
particle minecraft:cloud 4.22 71.06 -19.62 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains 1477
scoreboard players set #gdx driftmountains 618
scoreboard players set #gy driftmountains 70486
scoreboard players set #gdy driftmountains -3
scoreboard players set #gz driftmountains -22806
scoreboard players set #gdz driftmountains 594
scoreboard players set #gr driftmountains -241
scoreboard players set #gdr driftmountains 298
scoreboard players set #gp driftmountains 47
scoreboard players set #gdp driftmountains -55
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.3193f,-0.2797f,-0.1588f,-0.8914f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.0660f,-0.8796f,0.3505f,0.3148f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.2890f,0.0038f,-0.0125f,-0.9572f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0125f,-0.9572f,0.2890f,0.0038f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3577f,0.8415f,0.2379f],left_rotation:[-0.1772f,0.0435f,-0.1978f,-0.9631f]}}
particle minecraft:cloud 2.27 70.81 -24.21 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 2.27 70.61 -24.21 -0.002 0.02 -0.051 1 0 force
particle minecraft:cloud 0.57 70.81 -24.13 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -2599
scoreboard players set #gdx driftmountains 655
scoreboard players set #gy driftmountains 70497
scoreboard players set #gdy driftmountains 18
scoreboard players set #gz driftmountains -25388
scoreboard players set #gdz driftmountains 440
scoreboard players set #gr driftmountains -1142
scoreboard players set #gdr driftmountains -14
scoreboard players set #gp driftmountains -116
scoreboard players set #gdp driftmountains 47
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.8349f,0.2126f,-0.3137f,0.3992f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.3573f,0.4343f,0.8172f,-0.1260f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.2890f,0.0038f,-0.0125f,-0.9572f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0125f,-0.9572f,0.2890f,0.0038f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3590f,0.8281f,0.0925f],left_rotation:[-0.1731f,-0.0586f,0.3453f,-0.9205f]}}
particle minecraft:cloud -2.03 70.82 -26.79 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -2.03 70.62 -26.79 -0.009 0.02 -0.046 1 0 force
particle minecraft:cloud -3.67 70.82 -26.46 0.35 0.18 0.35 0.02 3 force
