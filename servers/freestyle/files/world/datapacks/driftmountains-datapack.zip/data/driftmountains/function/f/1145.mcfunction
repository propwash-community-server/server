scoreboard players set #gx driftmountains -95631
scoreboard players set #gdx driftmountains -427
scoreboard players set #gy driftmountains 70022
scoreboard players set #gdy driftmountains 4
scoreboard players set #gz driftmountains 2250
scoreboard players set #gdz driftmountains -874
scoreboard players set #gr driftmountains -15721
scoreboard players set #gdr driftmountains 301
scoreboard players set #gp driftmountains -15
scoreboard players set #gdp driftmountains 2
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.9124f,0.1202f,-0.3567f,0.1609f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.3755f,0.1993f,0.9048f,-0.0249f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.9422f,0.0123f,-0.0044f,-0.3348f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0044f,-0.3348f,0.9422f,0.0123f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3582f,0.8289f,0.0928f],left_rotation:[-0.1749f,-0.0542f,0.3220f,-0.9288f]}}
particle minecraft:cloud -96.89 70.34 3.09 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -96.89 70.14 3.09 -0.023 0.02 0.054 1 0 force
particle minecraft:cloud -95.35 70.34 3.74 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -90694
scoreboard players set #gdx driftmountains -663
scoreboard players set #gy driftmountains 69987
scoreboard players set #gdy driftmountains 3
scoreboard players set #gz driftmountains 9361
scoreboard players set #gdz driftmountains -788
scoreboard players set #gr driftmountains 17957
scoreboard players set #gdr driftmountains 107
scoreboard players set #gp driftmountains -12
scoreboard players set #gdp driftmountains -2
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.5133f,0.3103f,-0.1357f,0.7886f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.2193f,0.8072f,0.4835f,-0.2581f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.9422f,0.0123f,-0.0044f,-0.3348f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0044f,-0.3348f,0.9422f,0.0123f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3621f,0.8350f,0.2353f],left_rotation:[-0.1800f,0.0121f,-0.0363f,-0.9829f]}}
particle minecraft:cloud -91.54 70.31 10.73 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -91.54 70.11 10.73 0.000 0.02 0.063 1 0 force
particle minecraft:cloud -89.83 70.31 10.72 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -86769
scoreboard players set #gdx driftmountains -768
scoreboard players set #gy driftmountains 69987
scoreboard players set #gdy driftmountains -3
scoreboard players set #gz driftmountains 13643
scoreboard players set #gdz driftmountains -868
scoreboard players set #gr driftmountains 17517
scoreboard players set #gdr driftmountains 43
scoreboard players set #gp driftmountains 15
scoreboard players set #gdp driftmountains -7
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[0.0061f,0.0001f,-0.0223f,0.9997f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.6435f,-0.1932f,-0.2538f,-0.6958f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.1820f,-0.6730f,0.6674f,0.2619f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.9422f,0.0123f,-0.0044f,-0.3348f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0044f,-0.3348f,0.9422f,0.0123f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3544f,0.8530f,0.1023f],left_rotation:[-0.1837f,0.0484f,-0.2238f,-0.9559f]}}
particle minecraft:cloud -87.49 70.31 14.97 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -87.49 70.11 14.97 0.005 0.02 0.065 1 0 force
particle minecraft:cloud -85.83 70.31 14.83 0.35 0.18 0.35 0.02 3 force
