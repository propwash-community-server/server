scoreboard players set #gx driftmountains -55951
scoreboard players set #gdx driftmountains -111
scoreboard players set #gy driftmountains 68205
scoreboard players set #gdy driftmountains -12
scoreboard players set #gz driftmountains -64357
scoreboard players set #gdz driftmountains -733
scoreboard players set #gr driftmountains -16888
scoreboard players set #gdr driftmountains 272
scoreboard players set #gp driftmountains 90
scoreboard players set #gdp driftmountains 1
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[0.0061f,0.0001f,-0.0122f,0.9999f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.8174f,0.1341f,-0.1042f,0.5505f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.1626f,0.5645f,0.8078f,-0.0489f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.8538f,0.0112f,-0.0068f,-0.5204f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0068f,-0.5204f,0.8538f,0.0112f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.4010f,0.8403f,0.0973f],left_rotation:[0.0118f,0.1828f,-0.9783f,0.0963f]}}
particle minecraft:cloud -57.01 68.53 -63.28 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -57.01 68.33 -63.28 -0.009 0.02 0.044 1 0 force
particle minecraft:cloud -55.37 68.53 -62.96 0.35 0.18 0.35 0.02 2 force
scoreboard players set #gx driftmountains -54452
scoreboard players set #gdx driftmountains -113
scoreboard players set #gy driftmountains 68315
scoreboard players set #gdy driftmountains -13
scoreboard players set #gz driftmountains -58186
scoreboard players set #gdz driftmountains -710
scoreboard players set #gr driftmountains 15628
scoreboard players set #gdr driftmountains 422
scoreboard players set #gp driftmountains 99
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[-0.0039f,0.0000f,0.0090f,1.0000f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.2852f,0.1295f,-0.0161f,-0.9496f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[-0.0836f,-0.9531f,0.2731f,-0.1003f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.8538f,0.0112f,-0.0068f,-0.5204f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0068f,-0.5204f,0.8538f,0.0112f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3762f,0.8739f,0.2506f],left_rotation:[0.0868f,-0.1724f,0.8718f,0.4503f]}}
particle minecraft:cloud -54.69 68.64 -56.59 0.35 0.18 0.35 0.02 2 force
particle minecraft:cloud -53.12 68.64 -57.28 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -53.12 68.44 -57.28 0.017 0.02 0.039 1 0 force
scoreboard players set #gx driftmountains -53901
scoreboard players set #gdx driftmountains 48
scoreboard players set #gy driftmountains 68446
scoreboard players set #gdy driftmountains -22
scoreboard players set #gz driftmountains -52450
scoreboard players set #gdz driftmountains -694
scoreboard players set #gr driftmountains 15497
scoreboard players set #gdr driftmountains -386
scoreboard players set #gp driftmountains 166
scoreboard players set #gdp driftmountains -21
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[0.0061f,-0.0001f,0.0189f,0.9998f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.8429f,0.1398f,0.1304f,-0.5029f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[-0.1840f,-0.5194f,0.8329f,-0.0520f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.8538f,0.0112f,-0.0068f,-0.5204f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0068f,-0.5204f,0.8538f,0.0112f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.4008f,0.8394f,0.0970f],left_rotation:[-0.0155f,-0.1822f,0.9762f,-0.1158f]}}
particle minecraft:cloud -54.12 68.77 -50.95 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud -52.61 68.77 -51.66 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -52.61 68.57 -51.66 0.017 0.02 0.036 1 0 force
