scoreboard players set #gx driftmountains -9269
scoreboard players set #gdx driftmountains -1023
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 60643
scoreboard players set #gdz driftmountains -285
scoreboard players set #gr driftmountains 15355
scoreboard players set #gdr driftmountains -58
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.5256f,0.3621f,-0.1847f,0.7474f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.2643f,0.7709f,0.4904f,-0.3089f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.9733f,0.0127f,0.0030f,0.2294f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0030f,0.2294f,0.9733f,0.0127f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3705f,0.8217f,0.0900f],left_rotation:[-0.1472f,-0.1039f,0.5825f,-0.7926f]}}
particle minecraft:cloud -9.46 71.32 62.14 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -9.46 71.12 62.14 0.028 0.02 0.057 1 0 force
particle minecraft:cloud -7.96 71.32 61.40 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -1477
scoreboard players set #gdx driftmountains -923
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 61299
scoreboard players set #gdz driftmountains 41
scoreboard players set #gr driftmountains 14122
scoreboard players set #gdr driftmountains -16
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.1781f,-0.4252f,-0.1463f,-0.8752f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.0551f,-0.8647f,0.2238f,0.4463f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.9733f,0.0127f,0.0030f,0.2294f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0030f,0.2294f,0.9733f,0.0127f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.4058f,0.8463f,0.2398f],left_rotation:[-0.0819f,-0.1658f,0.8621f,-0.4717f]}}
particle minecraft:cloud -1.29 71.32 62.90 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -1.29 71.12 62.90 0.035 0.02 0.043 1 0 force
particle minecraft:cloud 0.04 71.32 61.83 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains 4621
scoreboard players set #gdx driftmountains -1014
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 62851
scoreboard players set #gdz driftmountains 25
scoreboard players set #gr driftmountains 14810
scoreboard players set #gdr driftmountains 190
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.8874f,0.0367f,-0.4575f,-0.0431f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.4555f,0.0048f,0.8884f,0.0564f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.9733f,0.0127f,0.0030f,0.2294f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0030f,0.2294f,0.9733f,0.0127f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3945f,0.8280f,0.0925f],left_rotation:[-0.0678f,-0.1669f,0.9042f,-0.3872f]}}
particle minecraft:cloud 4.58 71.32 64.36 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 4.58 71.12 64.36 0.035 0.02 0.056 1 0 force
particle minecraft:cloud 6.00 71.32 63.48 0.35 0.18 0.35 0.02 3 force
