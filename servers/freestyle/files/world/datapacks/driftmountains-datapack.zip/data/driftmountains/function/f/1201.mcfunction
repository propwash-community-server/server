scoreboard players set #gx driftmountains -78252
scoreboard players set #gdx driftmountains 626
scoreboard players set #gy driftmountains 69334
scoreboard players set #gdy driftmountains -10
scoreboard players set #gz driftmountains -27473
scoreboard players set #gdz driftmountains -197
scoreboard players set #gr driftmountains -12537
scoreboard players set #gdr driftmountains -217
scoreboard players set #gp driftmountains 82
scoreboard players set #gdp driftmountains -2
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,0.0000f,0.0113f,0.9999f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.1107f,0.1065f,-0.0410f,-0.9873f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[-0.0625f,-0.9884f,0.1001f,-0.0954f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.3136f,0.0041f,-0.0124f,-0.9495f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0124f,-0.9495f,0.3136f,0.0041f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3827f,0.8659f,0.1073f],left_rotation:[0.1173f,-0.1513f,0.7860f,0.5877f]}}
particle minecraft:cloud -79.76 69.65 -27.42 0.35 0.18 0.35 0.02 2 force
particle minecraft:cloud -78.80 69.65 -26.06 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -78.80 69.45 -26.06 -0.032 0.02 0.023 1 0 force
scoreboard players set #gx driftmountains -84363
scoreboard players set #gdx driftmountains 595
scoreboard players set #gy driftmountains 69445
scoreboard players set #gdy driftmountains -13
scoreboard players set #gz driftmountains -27113
scoreboard players set #gdz driftmountains -133
scoreboard players set #gr driftmountains -7906
scoreboard players set #gdr driftmountains -259
scoreboard players set #gp driftmountains 116
scoreboard players set #gdp driftmountains -2
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0001f,-0.0152f,0.9999f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.8867f,-0.0073f,-0.1326f,-0.4429f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.0868f,-0.4314f,0.8923f,0.1005f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.3136f,0.0041f,-0.0124f,-0.9495f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0124f,-0.9495f,0.3136f,0.0041f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.4061f,0.8481f,0.2405f],left_rotation:[0.0756f,0.1695f,-0.8798f,0.4377f]}}
particle minecraft:cloud -85.54 69.76 -28.21 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -85.54 69.56 -28.21 -0.036 0.02 -0.007 1 0 force
particle minecraft:cloud -85.87 69.76 -26.53 0.35 0.18 0.35 0.02 2 force
scoreboard players set #gx driftmountains -87467
scoreboard players set #gdx driftmountains 145
scoreboard players set #gy driftmountains 69544
scoreboard players set #gdy driftmountains -4
scoreboard players set #gz driftmountains -25011
scoreboard players set #gdz driftmountains -80
scoreboard players set #gr driftmountains -7208
scoreboard players set #gdr driftmountains 10
scoreboard players set #gp driftmountains 103
scoreboard players set #gdp driftmountains -1
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.1553f,-0.3180f,-0.1094f,-0.9289f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.0124f,-0.9225f,0.1896f,0.3361f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.3136f,0.0041f,-0.0124f,-0.9495f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0124f,-0.9495f,0.3136f,0.0041f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3524f,0.8456f,0.0994f],left_rotation:[-0.1872f,0.0176f,-0.0590f,-0.9803f]}}
particle minecraft:cloud -88.41 69.86 -26.19 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -88.41 69.66 -26.19 -0.024 0.02 -0.008 1 0 force
particle minecraft:cloud -88.92 69.86 -24.60 0.35 0.18 0.35 0.02 3 force
