scoreboard players set #gx driftmountains -41577
scoreboard players set #gdx driftmountains 583
scoreboard players set #gy driftmountains 67564
scoreboard players set #gdy driftmountains -15
scoreboard players set #gz driftmountains -91036
scoreboard players set #gdz driftmountains -196
scoreboard players set #gr driftmountains -7326
scoreboard players set #gdr driftmountains 339
scoreboard players set #gp driftmountains 112
scoreboard players set #gdp driftmountains 5
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.2724f,-0.1844f,-0.1093f,-0.9380f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.0113f,-0.9317f,0.2933f,0.2140f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.9089f,0.0119f,-0.0055f,-0.4169f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0055f,-0.4169f,0.9089f,0.0119f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3954f,0.8586f,0.1045f],left_rotation:[-0.0670f,0.1762f,-0.9288f,-0.3189f]}}
particle minecraft:cloud -42.54 67.88 -92.20 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -42.54 67.68 -92.20 -0.036 0.02 -0.011 1 0 force
particle minecraft:cloud -43.02 67.88 -90.60 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -46088
scoreboard players set #gdx driftmountains 534
scoreboard players set #gy driftmountains 67669
scoreboard players set #gdy driftmountains -12
scoreboard players set #gz driftmountains -88645
scoreboard players set #gdz driftmountains -427
scoreboard players set #gr driftmountains -9349
scoreboard players set #gdr driftmountains 205
scoreboard players set #gp driftmountains 82
scoreboard players set #gdp driftmountains 2
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[0.0061f,0.0001f,-0.0220f,0.9997f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.3020f,-0.2151f,-0.1274f,-0.9200f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.0314f,-0.9116f,0.3262f,0.2480f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.9089f,0.0119f,-0.0055f,-0.4169f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0055f,-0.4169f,0.9089f,0.0119f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3670f,0.8704f,0.2492f],left_rotation:[-0.1161f,0.1526f,-0.7660f,-0.6136f]}}
particle minecraft:cloud -47.50 67.99 -89.42 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -47.50 67.79 -89.42 -0.033 0.02 0.002 1 0 force
particle minecraft:cloud -47.40 67.99 -87.71 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -49352
scoreboard players set #gdx driftmountains 412
scoreboard players set #gy driftmountains 67758
scoreboard players set #gdy driftmountains -11
scoreboard players set #gz driftmountains -84459
scoreboard players set #gdz driftmountains -560
scoreboard players set #gr driftmountains -11249
scoreboard players set #gdr driftmountains 134
scoreboard players set #gp driftmountains 80
scoreboard players set #gdp driftmountains -2
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0001f,-0.0194f,0.9998f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.7923f,-0.0935f,-0.2260f,-0.5590f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.1685f,-0.5383f,0.8065f,0.1772f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.9089f,0.0119f,-0.0055f,-0.4169f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0055f,-0.4169f,0.9089f,0.0119f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3837f,0.8656f,0.1072f],left_rotation:[-0.1142f,0.1535f,-0.7982f,-0.5711f]}}
particle minecraft:cloud -50.84 68.08 -84.75 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -50.84 67.88 -84.75 -0.042 0.02 0.018 1 0 force
particle minecraft:cloud -50.20 68.08 -83.21 0.35 0.18 0.35 0.02 3 force
