scoreboard players set #gx driftmountains 27517
scoreboard players set #gdx driftmountains -5
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 34385
scoreboard players set #gdz driftmountains 998
scoreboard players set #gr driftmountains 5373
scoreboard players set #gdr driftmountains 317
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[0.0027f,0.0001f,-0.0223f,0.9997f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.1567f,-0.3880f,-0.1257f,-0.8995f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.0318f,-0.8912f,0.1983f,0.4066f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.6276f,0.0082f,0.0102f,0.7784f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0102f,0.7784f,0.6276f,0.0082f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3711f,0.8216f,0.0900f],left_rotation:[-0.1455f,-0.1060f,0.5935f,-0.7844f]}}
particle minecraft:cloud 29.03 71.32 34.31 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 29.03 71.12 34.31 0.048 0.02 -0.036 1 0 force
particle minecraft:cloud 28.04 71.32 32.97 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains 27120
scoreboard players set #gdx driftmountains 251
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 26867
scoreboard players set #gdz driftmountains 845
scoreboard players set #gr driftmountains 3494
scoreboard players set #gdr driftmountains 349
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.7748f,-0.1572f,-0.3433f,-0.5071f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.2919f,-0.4738f,0.7956f,0.2395f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.6276f,0.0082f,0.0102f,0.7784f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0102f,0.7784f,0.6276f,0.0082f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3791f,0.8272f,0.2323f],left_rotation:[-0.1677f,-0.0603f,0.3329f,-0.9260f]}}
particle minecraft:cloud 28.60 71.32 26.24 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 28.60 71.12 26.24 0.033 0.02 -0.047 1 0 force
particle minecraft:cloud 27.20 71.32 25.26 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains 23732
scoreboard players set #gdx driftmountains 265
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 22593
scoreboard players set #gdz driftmountains 977
scoreboard players set #gr driftmountains 2067
scoreboard players set #gdr driftmountains 176
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[0.0045f,0.0001f,-0.0220f,0.9997f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.6988f,0.2435f,-0.1821f,0.6475f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.2512f,0.6702f,0.6770f,-0.1714f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.6276f,0.0082f,0.0102f,0.7784f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0102f,0.7784f,0.6276f,0.0082f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3582f,0.8586f,0.1045f],left_rotation:[-0.1765f,0.0734f,-0.3588f,-0.9136f]}}
particle minecraft:cloud 24.96 71.32 21.71 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 24.96 71.12 21.71 0.022 0.02 -0.057 1 0 force
particle minecraft:cloud 23.40 71.32 21.12 0.35 0.18 0.35 0.02 3 force
