scoreboard players set #gx driftmountains 5858
scoreboard players set #gdx driftmountains -1068
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 63012
scoreboard players set #gdz driftmountains 146
scoreboard players set #gr driftmountains 13947
scoreboard players set #gdr driftmountains 269
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[0.0061f,0.0001f,-0.0223f,0.9997f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.1527f,-0.4154f,-0.1304f,-0.8872f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.0379f,-0.8783f,0.1972f,0.4338f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.5568f,0.0073f,0.0109f,0.8305f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0109f,0.8305f,0.5568f,0.0073f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3846f,0.8222f,0.0902f],left_rotation:[-0.1075f,-0.1434f,0.7860f,-0.5916f]}}
particle minecraft:cloud 6.04 71.32 64.51 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 6.04 71.12 64.51 0.042 0.02 0.049 1 0 force
particle minecraft:cloud 7.31 71.32 63.43 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains 12728
scoreboard players set #gdx driftmountains -846
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 58567
scoreboard players set #gdz driftmountains 459
scoreboard players set #gr driftmountains 12105
scoreboard players set #gdr driftmountains 319
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.7438f,-0.1986f,-0.4061f,-0.4924f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.3566f,-0.4524f,0.7687f,0.2779f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.5568f,0.0073f,0.0109f,0.8305f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0109f,0.8305f,0.5568f,0.0073f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.4060f,0.8474f,0.2402f],left_rotation:[-0.0779f,-0.1682f,0.8735f,-0.4502f]}}
particle minecraft:cloud 13.46 71.32 60.00 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 13.46 71.12 60.00 0.049 0.02 0.030 1 0 force
particle minecraft:cloud 14.34 71.32 58.54 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains 18605
scoreboard players set #gdx driftmountains -782
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 56152
scoreboard players set #gdz driftmountains 773
scoreboard players set #gr driftmountains 10264
scoreboard players set #gdr driftmountains 254
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[-0.0018f,-0.0000f,-0.0223f,0.9997f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.6604f,0.3445f,-0.2921f,0.5999f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.3568f,0.6339f,0.6278f,-0.2770f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.5568f,0.0073f,0.0109f,0.8305f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0109f,0.8305f,0.5568f,0.0073f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3917f,0.8257f,0.0916f],left_rotation:[-0.0806f,-0.1606f,0.8728f,-0.4536f]}}
particle minecraft:cloud 19.65 71.32 57.24 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 19.65 71.12 57.24 0.064 0.02 0.014 1 0 force
particle minecraft:cloud 20.02 71.32 55.61 0.35 0.18 0.35 0.02 3 force
