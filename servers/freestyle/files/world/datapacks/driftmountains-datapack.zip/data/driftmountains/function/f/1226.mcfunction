scoreboard players set #gx driftmountains -62046
scoreboard players set #gdx driftmountains 524
scoreboard players set #gy driftmountains 69079
scoreboard players set #gdy driftmountains -13
scoreboard players set #gz driftmountains -33599
scoreboard players set #gdz driftmountains -281
scoreboard players set #gr driftmountains -15023
scoreboard players set #gdr driftmountains -274
scoreboard players set #gp driftmountains 104
scoreboard players set #gdp driftmountains 8
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[0.0061f,-0.0001f,0.0202f,0.9998f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.6486f,-0.1027f,0.1613f,0.7367f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[-0.0848f,0.7238f,0.6630f,0.1714f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.8009f,0.0105f,0.0078f,0.5987f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0078f,0.5987f,0.8009f,0.0105f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.4008f,0.8394f,0.0970f],left_rotation:[-0.0156f,-0.1822f,0.9762f,-0.1160f]}}
particle minecraft:cloud -63.40 69.40 -32.92 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud -61.95 69.40 -32.09 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -61.95 69.20 -32.09 -0.018 0.02 0.031 1 0 force
scoreboard players set #gx driftmountains -67954
scoreboard players set #gdx driftmountains 700
scoreboard players set #gy driftmountains 69184
scoreboard players set #gdy driftmountains -11
scoreboard players set #gz driftmountains -33018
scoreboard players set #gdz driftmountains -271
scoreboard players set #gr driftmountains -12110
scoreboard players set #gdr driftmountains -268
scoreboard players set #gp driftmountains 82
scoreboard players set #gdp driftmountains 3
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[0.0061f,-0.0000f,0.0061f,1.0000f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.0062f,0.0932f,-0.0520f,-0.9943f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[-0.0522f,-0.9943f,-0.0036f,-0.0930f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.8009f,0.0105f,0.0078f,0.5987f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0078f,0.5987f,0.8009f,0.0105f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3651f,0.8691f,0.2487f],left_rotation:[0.1222f,-0.1472f,0.7374f,0.6478f]}}
scoreboard players set #gx driftmountains -73231
scoreboard players set #gdx driftmountains 792
scoreboard players set #gy driftmountains 69260
scoreboard players set #gdy driftmountains -11
scoreboard players set #gz driftmountains -29539
scoreboard players set #gdz driftmountains -365
scoreboard players set #gr driftmountains -12066
scoreboard players set #gdr driftmountains 191
scoreboard players set #gp driftmountains 72
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,0.0000f,0.0036f,1.0000f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.5731f,-0.0149f,0.0745f,0.8160f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.0108f,0.8126f,0.5778f,0.0752f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.8009f,0.0105f,0.0078f,0.5987f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0078f,0.5987f,0.8009f,0.0105f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3629f,0.8625f,0.1060f],left_rotation:[0.1669f,-0.0948f,0.4748f,0.8588f]}}
