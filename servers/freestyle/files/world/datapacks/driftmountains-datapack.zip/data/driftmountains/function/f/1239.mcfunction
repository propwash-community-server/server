scoreboard players set #gx driftmountains -56849
scoreboard players set #gdx driftmountains 312
scoreboard players set #gy driftmountains 68856
scoreboard players set #gdy driftmountains -19
scoreboard players set #gz driftmountains -39172
scoreboard players set #gdz driftmountains -556
scoreboard players set #gr driftmountains 17735
scoreboard players set #gdr driftmountains -209
scoreboard players set #gp driftmountains 140
scoreboard players set #gdp driftmountains -1
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,0.0001f,0.0202f,0.9998f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.2100f,0.2273f,-0.0048f,-0.9509f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[-0.0951f,-0.9556f,0.1872f,-0.2065f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.8048f,0.0105f,-0.0078f,-0.5934f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0078f,-0.5934f,0.8048f,0.0105f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3923f,0.8261f,0.0917f],left_rotation:[-0.0781f,-0.1619f,0.8795f,-0.4406f]}}
particle minecraft:cloud -57.62 69.18 -37.87 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud -55.96 69.18 -37.95 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -55.96 68.98 -37.95 0.002 0.02 0.038 1 0 force
scoreboard players set #gx driftmountains -60801
scoreboard players set #gdx driftmountains 425
scoreboard players set #gy driftmountains 69003
scoreboard players set #gdy driftmountains -23
scoreboard players set #gz driftmountains -36573
scoreboard players set #gdz driftmountains -460
scoreboard players set #gr driftmountains -17179
scoreboard players set #gdr driftmountains -294
scoreboard players set #gp driftmountains 183
scoreboard players set #gdp driftmountains -17
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[-0.0039f,0.0001f,0.0220f,0.9998f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.3867f,0.1968f,0.0265f,-0.9006f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[-0.1213f,-0.9083f,0.3682f,-0.1572f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.8048f,0.0105f,-0.0078f,-0.5934f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0078f,-0.5934f,0.8048f,0.0105f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.4039f,0.8607f,0.2454f],left_rotation:[-0.0287f,-0.1873f,0.9646f,-0.1837f]}}
particle minecraft:cloud -61.84 69.32 -35.34 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud -60.15 69.32 -35.10 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -60.15 69.12 -35.10 -0.005 0.02 0.034 1 0 force
scoreboard players set #gx driftmountains -64835
scoreboard players set #gdx driftmountains 470
scoreboard players set #gy driftmountains 69134
scoreboard players set #gdy driftmountains -9
scoreboard players set #gz driftmountains -33095
scoreboard players set #gdz driftmountains -203
scoreboard players set #gr driftmountains -13647
scoreboard players set #gdr driftmountains -339
scoreboard players set #gp driftmountains 86
scoreboard players set #gdp driftmountains 3
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[0.0061f,-0.0001f,0.0143f,0.9999f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.9827f,0.0452f,0.1740f,0.0451f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[-0.1703f,0.0271f,0.9833f,0.0578f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.8048f,0.0105f,-0.0078f,-0.5934f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0078f,-0.5934f,0.8048f,0.0105f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.4013f,0.8444f,0.0989f],left_rotation:[0.0050f,-0.1842f,0.9828f,-0.0081f]}}
particle minecraft:cloud -66.31 69.45 -32.76 0.35 0.18 0.35 0.02 2 force
particle minecraft:cloud -65.10 69.45 -31.61 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -65.10 69.25 -31.61 -0.027 0.02 0.028 1 0 force
