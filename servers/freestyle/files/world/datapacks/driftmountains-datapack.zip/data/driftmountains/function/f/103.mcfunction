scoreboard players set #gx driftmountains -4994
scoreboard players set #gdx driftmountains 635
scoreboard players set #gy driftmountains 70361
scoreboard players set #gdy driftmountains 50
scoreboard players set #gz driftmountains -26800
scoreboard players set #gdz driftmountains 428
scoreboard players set #gr driftmountains -1002
scoreboard players set #gdr driftmountains 51
scoreboard players set #gp driftmountains -287
scoreboard players set #gdp driftmountains 56
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.5541f,-0.2505f,-0.2540f,-0.7522f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.1764f,-0.7296f,0.5834f,0.3101f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.7125f,0.0093f,0.0092f,0.7016f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0092f,0.7016f,0.7125f,0.0093f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3536f,0.8366f,0.0958f],left_rotation:[-0.1845f,-0.0193f,0.1375f,-0.9729f]}}
particle minecraft:cloud -4.39 70.68 -28.19 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -4.39 70.48 -28.19 -0.008 0.02 -0.045 1 0 force
particle minecraft:cloud -6.04 70.68 -27.90 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -8998
scoreboard players set #gdx driftmountains 760
scoreboard players set #gy driftmountains 69928
scoreboard players set #gdy driftmountains 65
scoreboard players set #gz driftmountains -29387
scoreboard players set #gdz driftmountains 195
scoreboard players set #gr driftmountains -3041
scoreboard players set #gdr driftmountains 339
scoreboard players set #gp driftmountains -304
scoreboard players set #gdp driftmountains -41
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.1217f,-0.3041f,-0.0950f,-0.9400f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[-0.0033f,-0.9352f,0.1543f,0.3186f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.7125f,0.0093f,0.0092f,0.7016f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0092f,0.7016f,0.7125f,0.0093f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3571f,0.8429f,0.2384f],left_rotation:[-0.1762f,0.0491f,-0.2265f,-0.9567f]}}
particle minecraft:cloud -8.95 70.25 -31.00 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -8.95 70.05 -31.00 -0.023 0.02 -0.040 1 0 force
particle minecraft:cloud -10.43 70.25 -30.13 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -14167
scoreboard players set #gdx driftmountains 792
scoreboard players set #gy driftmountains 69557
scoreboard players set #gdy driftmountains 55
scoreboard players set #gz driftmountains -29496
scoreboard players set #gdz driftmountains 64
scoreboard players set #gr driftmountains -4158
scoreboard players set #gdr driftmountains 156
scoreboard players set #gp driftmountains -283
scoreboard players set #gdp driftmountains -1
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[-0.0016f,-0.0000f,-0.0223f,0.9997f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.8971f,0.1521f,-0.3227f,0.2607f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.3519f,0.2961f,0.8860f,-0.0586f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.7125f,0.0093f,0.0092f,0.7016f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0092f,0.7016f,0.7125f,0.0093f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3536f,0.8366f,0.0958f],left_rotation:[-0.1845f,-0.0192f,0.1374f,-0.9729f]}}
particle minecraft:cloud -14.38 69.88 -30.99 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -14.38 69.68 -30.99 -0.034 0.02 -0.039 1 0 force
particle minecraft:cloud -15.63 69.88 -29.88 0.35 0.18 0.35 0.02 3 force
