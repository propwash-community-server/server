scoreboard players set #gx driftmountains -23050
scoreboard players set #gdx driftmountains -1103
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains -2
scoreboard players set #gz driftmountains 56559
scoreboard players set #gdz driftmountains -348
scoreboard players set #gr driftmountains 15398
scoreboard players set #gdr driftmountains 28
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 16
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.8629f,-0.0807f,-0.3866f,-0.3153f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.3556f,-0.2764f,0.8762f,0.1718f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.5012f,0.0066f,-0.0113f,-0.8653f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0113f,-0.8653f,0.5012f,0.0066f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3652f,0.8237f,0.0908f],left_rotation:[-0.1596f,-0.0855f,0.4868f,-0.8545f]}}
particle minecraft:cloud -23.25 71.32 58.06 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -23.25 71.12 58.06 0.030 0.02 0.062 1 0 force
particle minecraft:cloud -21.75 71.32 57.33 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -13846
scoreboard players set #gdx driftmountains -1020
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 59156
scoreboard players set #gdz driftmountains -274
scoreboard players set #gr driftmountains 15058
scoreboard players set #gdr driftmountains 7
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.8232f,0.2232f,-0.3167f,0.4150f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.3621f,0.4506f,0.8043f,-0.1379f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.5012f,0.0066f,-0.0113f,-0.8653f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0113f,-0.8653f,0.5012f,0.0066f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3841f,0.8273f,0.2323f],left_rotation:[-0.1605f,-0.0778f,0.4217f,-0.8891f]}}
particle minecraft:cloud -13.92 71.32 60.77 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -13.92 71.12 60.77 0.031 0.02 0.056 1 0 force
particle minecraft:cloud -12.43 71.32 59.93 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -9077
scoreboard players set #gdx driftmountains -1042
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 60610
scoreboard players set #gdz driftmountains -280
scoreboard players set #gr driftmountains 15329
scoreboard players set #gdr driftmountains -79
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.1963f,-0.3838f,-0.1432f,-0.8909f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.0504f,-0.8807f,0.2377f,0.4065f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.5012f,0.0066f,-0.0113f,-0.8653f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0113f,-0.8653f,0.5012f,0.0066f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3720f,0.8214f,0.0899f],left_rotation:[-0.1434f,-0.1087f,0.6072f,-0.7738f]}}
particle minecraft:cloud -9.26 71.32 62.11 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -9.26 71.12 62.11 0.029 0.02 0.059 1 0 force
particle minecraft:cloud -7.76 71.32 61.36 0.35 0.18 0.35 0.02 3 force
