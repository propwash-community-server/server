scoreboard players set #gx driftmountains -79498
scoreboard players set #gdx driftmountains 623
scoreboard players set #gy driftmountains 69354
scoreboard players set #gdy driftmountains -10
scoreboard players set #gz driftmountains -27143
scoreboard players set #gdz driftmountains -152
scoreboard players set #gr driftmountains -11325
scoreboard players set #gdr driftmountains -696
scoreboard players set #gp driftmountains 94
scoreboard players set #gdp driftmountains -7
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,0.0000f,0.0067f,1.0000f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.8824f,0.0320f,0.0515f,0.4666f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[-0.0027f,0.4637f,0.8839f,0.0605f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.2079f,0.0027f,0.0128f,0.9781f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0128f,0.9781f,0.2079f,0.0027f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3556f,0.8551f,0.1031f],left_rotation:[0.1816f,-0.0573f,0.2722f,0.9431f]}}
particle minecraft:cloud -80.99 69.67 -27.41 0.35 0.18 0.35 0.02 2 force
particle minecraft:cloud -80.33 69.67 -25.88 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -80.33 69.47 -25.88 -0.035 0.02 0.015 1 0 force
scoreboard players set #gx driftmountains -85465
scoreboard players set #gdx driftmountains 515
scoreboard players set #gy driftmountains 69472
scoreboard players set #gdy driftmountains -13
scoreboard players set #gz driftmountains -26764
scoreboard players set #gdz driftmountains -182
scoreboard players set #gr driftmountains -7761
scoreboard players set #gdr driftmountains -46
scoreboard players set #gp driftmountains 120
scoreboard players set #gdp driftmountains -1
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0001f,-0.0205f,0.9998f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.2183f,0.1764f,0.0143f,0.9597f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.0865f,0.9635f,0.2010f,-0.1544f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.2079f,0.0027f,0.0128f,0.9781f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0128f,0.9781f,0.2079f,0.0027f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3994f,0.8669f,0.2478f],left_rotation:[0.0001f,0.1913f,-0.9812f,0.0279f]}}
particle minecraft:cloud -86.62 69.79 -27.89 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -86.62 69.59 -27.89 -0.034 0.02 -0.008 1 0 force
particle minecraft:cloud -86.98 69.79 -26.22 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -88318
scoreboard players set #gdx driftmountains 495
scoreboard players set #gy driftmountains 69570
scoreboard players set #gdy driftmountains -15
scoreboard players set #gz driftmountains -24531
scoreboard players set #gdz driftmountains -281
scoreboard players set #gr driftmountains -7331
scoreboard players set #gdr driftmountains 98
scoreboard players set #gp driftmountains 105
scoreboard players set #gdp driftmountains -1
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.9322f,0.0834f,-0.3443f,0.0739f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.3539f,0.1105f,0.9286f,0.0142f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.2079f,0.0027f,0.0128f,0.9781f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0128f,0.9781f,0.2079f,0.0027f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3532f,0.8377f,0.0963f],left_rotation:[-0.1853f,-0.0146f,0.1129f,-0.9760f]}}
particle minecraft:cloud -89.29 69.89 -25.69 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -89.29 69.69 -25.69 -0.025 0.02 -0.007 1 0 force
particle minecraft:cloud -89.77 69.89 -24.09 0.35 0.18 0.35 0.02 3 force
