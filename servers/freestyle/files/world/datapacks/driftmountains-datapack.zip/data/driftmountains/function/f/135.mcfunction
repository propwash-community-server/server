scoreboard players set #gx driftmountains 12124
scoreboard players set #gdx driftmountains 452
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains -5168
scoreboard players set #gdz driftmountains 890
scoreboard players set #gr driftmountains 1108
scoreboard players set #gdr driftmountains 33
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.6414f,-0.1964f,-0.2561f,-0.6960f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.1843f,-0.6729f,0.6656f,0.2649f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.9817f,0.0129f,-0.0025f,-0.1901f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0025f,-0.1901f,0.9817f,0.0129f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3538f,0.8515f,0.1017f],left_rotation:[-0.1849f,0.0418f,-0.1885f,-0.9635f]}}
particle minecraft:cloud 13.19 71.32 -6.24 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 13.19 71.12 -6.24 0.011 0.02 -0.059 1 0 force
particle minecraft:cloud 11.55 71.32 -6.56 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains 9018
scoreboard players set #gdx driftmountains 435
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains -10793
scoreboard players set #gdz driftmountains 823
scoreboard players set #gr driftmountains 997
scoreboard players set #gdr driftmountains 8
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.9404f,0.0211f,-0.3244f,-0.0999f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.3157f,-0.0664f,0.9433f,0.0776f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.9817f,0.0129f,-0.0025f,-0.1901f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0025f,-0.1901f,0.9817f,0.0129f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3584f,0.8401f,0.2374f],left_rotation:[-0.1782f,0.0372f,-0.1655f,-0.9693f]}}
particle minecraft:cloud 10.10 71.32 -11.99 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 10.10 71.12 -11.99 0.010 0.02 -0.057 1 0 force
particle minecraft:cloud 8.41 71.32 -12.29 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains 6330
scoreboard players set #gdx driftmountains 442
scoreboard players set #gy driftmountains 70924
scoreboard players set #gdy driftmountains 38
scoreboard players set #gz driftmountains -15717
scoreboard players set #gdz driftmountains 797
scoreboard players set #gr driftmountains 1188
scoreboard players set #gdr driftmountains -72
scoreboard players set #gp driftmountains -206
scoreboard players set #gdp driftmountains 47
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.5171f,-0.2534f,-0.2340f,-0.7833f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.1530f,-0.7631f,0.5466f,0.3092f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.9817f,0.0129f,-0.0025f,-0.1901f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0025f,-0.1901f,0.9817f,0.0129f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3524f,0.8417f,0.0979f],left_rotation:[-0.1870f,0.0021f,0.0236f,-0.9820f]}}
particle minecraft:cloud 7.41 71.24 -16.78 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 7.41 71.04 -16.78 0.011 0.02 -0.051 1 0 force
particle minecraft:cloud 5.77 71.24 -17.12 0.35 0.18 0.35 0.02 3 force
