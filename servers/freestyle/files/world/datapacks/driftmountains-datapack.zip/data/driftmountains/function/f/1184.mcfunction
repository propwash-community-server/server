scoreboard players set #gx driftmountains -88088
scoreboard players set #gdx driftmountains 535
scoreboard players set #gy driftmountains 69558
scoreboard players set #gdy driftmountains -16
scoreboard players set #gz driftmountains -24905
scoreboard players set #gdz driftmountains -318
scoreboard players set #gr driftmountains -7667
scoreboard players set #gdr driftmountains 57
scoreboard players set #gp driftmountains 109
scoreboard players set #gdp driftmountains -2
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.1596f,0.3224f,0.0009f,0.9330f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.0972f,0.9381f,0.1266f,-0.3074f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.5135f,0.0067f,-0.0112f,-0.8580f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0112f,-0.8580f,0.5135f,0.0067f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3538f,0.8516f,0.1017f],left_rotation:[-0.1848f,0.0422f,-0.1910f,-0.9631f]}}
particle minecraft:cloud -89.12 69.88 -26.01 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -89.12 69.68 -26.01 -0.037 0.02 -0.009 1 0 force
particle minecraft:cloud -89.51 69.88 -24.38 0.35 0.18 0.35 0.02 3 force
playsound driftgen:grain.kaze.033 neutral @a -83.75 69.94 -26.59 12 1
scoreboard players set #gx driftmountains -93041
scoreboard players set #gdx driftmountains 525
scoreboard players set #gy driftmountains 69724
scoreboard players set #gdy driftmountains -19
scoreboard players set #gz driftmountains -21052
scoreboard players set #gdz driftmountains -537
scoreboard players set #gr driftmountains -9126
scoreboard players set #gdr driftmountains 162
scoreboard players set #gp driftmountains 104
scoreboard players set #gdp driftmountains 2
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.9118f,-0.0277f,-0.3407f,-0.2277f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.3186f,-0.1931f,0.9197f,0.1237f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.5135f,0.0067f,-0.0112f,-0.8580f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0112f,-0.8580f,0.5135f,0.0067f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3632f,0.8339f,0.2349f],left_rotation:[-0.1800f,0.0062f,-0.0062f,-0.9837f]}}
particle minecraft:cloud -94.42 70.04 -21.88 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -94.42 69.84 -21.88 -0.046 0.02 0.001 1 0 force
particle minecraft:cloud -94.39 70.04 -20.17 0.35 0.18 0.35 0.02 3 force
playsound driftgen:grain.onyx.033 neutral @a -88.94 70.08 -24.66 12 1
scoreboard players set #gx driftmountains -96093
scoreboard players set #gdx driftmountains 377
scoreboard players set #gy driftmountains 69846
scoreboard players set #gdy driftmountains -16
scoreboard players set #gz driftmountains -17111
scoreboard players set #gdz driftmountains -570
scoreboard players set #gr driftmountains -9766
scoreboard players set #gdr driftmountains 148
scoreboard players set #gp driftmountains 84
scoreboard players set #gdp driftmountains 3
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.7202f,0.2645f,-0.2311f,0.5983f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.2952f,0.6259f,0.6963f,-0.1903f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.5135f,0.0067f,-0.0112f,-0.8580f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0112f,-0.8580f,0.5135f,0.0067f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3529f,0.8389f,0.0968f],left_rotation:[-0.1860f,-0.0093f,0.0846f,-0.9788f]}}
particle minecraft:cloud -97.45 70.17 -17.77 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -97.45 69.97 -17.77 -0.046 0.02 0.006 1 0 force
particle minecraft:cloud -97.23 70.17 -16.12 0.35 0.18 0.35 0.02 3 force
playsound driftgen:grain.kaze.031 neutral @a -92.12 70.19 -21.80 12 1
