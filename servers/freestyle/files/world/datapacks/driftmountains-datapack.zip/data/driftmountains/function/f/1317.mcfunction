scoreboard players set #gx driftmountains -45087
scoreboard players set #gdx driftmountains 580
scoreboard players set #gy driftmountains 67649
scoreboard players set #gdy driftmountains -13
scoreboard players set #gz driftmountains -89150
scoreboard players set #gdz driftmountains -396
scoreboard players set #gr driftmountains -9055
scoreboard players set #gdr driftmountains 268
scoreboard players set #gp driftmountains 88
scoreboard players set #gdp driftmountains 1
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[0.0061f,0.0001f,-0.0214f,0.9998f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.0756f,0.2399f,0.0353f,0.9672f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.0662f,0.9688f,0.0508f,-0.2333f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.4302f,0.0056f,0.0118f,0.9027f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0118f,0.9027f,0.4302f,0.0056f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3846f,0.8654f,0.1071f],left_rotation:[-0.1113f,0.1554f,-0.8093f,-0.5553f]}}
particle minecraft:cloud -46.36 67.97 -89.97 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -46.36 67.77 -89.97 -0.043 0.02 0.000 1 0 force
particle minecraft:cloud -46.34 67.97 -88.30 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -48991
scoreboard players set #gdx driftmountains 498
scoreboard players set #gy driftmountains 67738
scoreboard players set #gdy driftmountains -12
scoreboard players set #gz driftmountains -85811
scoreboard players set #gdz driftmountains -552
scoreboard players set #gr driftmountains -10369
scoreboard players set #gdr driftmountains 162
scoreboard players set #gp driftmountains 75
scoreboard players set #gdp driftmountains 3
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[0.0061f,0.0001f,-0.0214f,0.9998f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.0273f,-0.2518f,-0.0613f,-0.9655f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[-0.0399f,-0.9643f,0.0540f,0.2560f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.4302f,0.0056f,0.0118f,0.9027f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0118f,0.9027f,0.4302f,0.0056f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3635f,0.8678f,0.2482f],left_rotation:[-0.1277f,0.1418f,-0.7093f,-0.6786f]}}
particle minecraft:cloud -50.52 68.06 -86.32 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -50.52 67.86 -86.32 -0.044 0.02 0.011 1 0 force
particle minecraft:cloud -50.12 68.06 -84.66 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -51714
scoreboard players set #gdx driftmountains 352
scoreboard players set #gy driftmountains 67833
scoreboard players set #gdy driftmountains -13
scoreboard players set #gz driftmountains -80662
scoreboard players set #gdz driftmountains -646
scoreboard players set #gr driftmountains -12169
scoreboard players set #gdr driftmountains 170
scoreboard players set #gp driftmountains 87
scoreboard players set #gdp driftmountains -4
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0001f,-0.0186f,0.9998f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.9623f,0.0207f,-0.2328f,-0.1391f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.2194f,-0.1154f,0.9654f,0.0804f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.4302f,0.0056f,0.0118f,0.9027f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0118f,0.9027f,0.4302f,0.0056f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3884f,0.8639f,0.1065f],left_rotation:[-0.0982f,0.1632f,-0.8534f,-0.4851f]}}
particle minecraft:cloud -53.22 68.15 -80.71 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -53.22 67.95 -80.71 -0.038 0.02 0.023 1 0 force
particle minecraft:cloud -52.35 68.15 -79.29 0.35 0.18 0.35 0.02 3 force
