scoreboard players set #gx driftmountains 35161
scoreboard players set #gdx driftmountains 1095
scoreboard players set #gy driftmountains 66422
scoreboard players set #gdy driftmountains -13
scoreboard players set #gz driftmountains -49236
scoreboard players set #gdz driftmountains 665
scoreboard players set #gr driftmountains -5813
scoreboard players set #gdr driftmountains 189
scoreboard players set #gp driftmountains 59
scoreboard players set #gdp driftmountains -1
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0000f,-0.0005f,1.0000f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.2061f,0.0101f,-0.0514f,-0.9771f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[-0.0511f,-0.9771f,0.2062f,0.0115f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.4437f,0.0058f,0.0117f,0.8961f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0117f,0.8961f,0.4437f,0.0058f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3523f,0.8427f,0.0982f],left_rotation:[0.1872f,-0.0058f,-0.0041f,0.9823f]}}
scoreboard players set #gx driftmountains 27213
scoreboard players set #gdx driftmountains 1025
scoreboard players set #gy driftmountains 66517
scoreboard players set #gdy driftmountains -14
scoreboard players set #gz driftmountains -53040
scoreboard players set #gdz driftmountains 760
scoreboard players set #gr driftmountains -5091
scoreboard players set #gdr driftmountains -73
scoreboard players set #gp driftmountains 65
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0000f,-0.0013f,1.0000f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.7810f,0.0256f,-0.0519f,-0.6219f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[-0.0132f,-0.6198f,0.7826f,0.0563f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.4437f,0.0058f,0.0117f,0.8961f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0117f,0.8961f,0.4437f,0.0058f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3730f,0.8284f,0.2327f],left_rotation:[0.1745f,0.0374f,-0.2164f,0.9599f]}}
scoreboard players set #gx driftmountains 17895
scoreboard players set #gdx driftmountains 1064
scoreboard players set #gy driftmountains 66642
scoreboard players set #gdy driftmountains -13
scoreboard players set #gz driftmountains -59661
scoreboard players set #gdz driftmountains 672
scoreboard players set #gr driftmountains -6014
scoreboard players set #gdr driftmountains 44
scoreboard players set #gp driftmountains 61
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.2400f,0.0319f,-0.0460f,-0.9691f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[-0.0556f,-0.9696f,0.2380f,-0.0068f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.4437f,0.0058f,0.0117f,0.8961f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0117f,0.8961f,0.4437f,0.0058f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3536f,0.8511f,0.1015f],left_rotation:[0.1852f,-0.0401f,0.1793f,0.9653f]}}
