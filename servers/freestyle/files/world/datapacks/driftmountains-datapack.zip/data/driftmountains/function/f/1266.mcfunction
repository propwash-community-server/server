scoreboard players set #gx driftmountains -54700
scoreboard players set #gdx driftmountains -151
scoreboard players set #gy driftmountains 68322
scoreboard players set #gdy driftmountains -14
scoreboard players set #gz driftmountains -57610
scoreboard players set #gdz driftmountains -725
scoreboard players set #gr driftmountains 15238
scoreboard players set #gdr driftmountains 379
scoreboard players set #gp driftmountains 103
scoreboard players set #gdp driftmountains -2
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,0.0000f,0.0097f,0.9999f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.0807f,-0.1298f,0.0636f,0.9862f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.0397f,0.9850f,0.0948f,0.1390f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.2144f,0.0028f,-0.0128f,-0.9767f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0128f,-0.9767f,0.2144f,0.0028f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3953f,0.8587f,0.1045f],left_rotation:[0.0679f,-0.1760f,0.9272f,0.3235f]}}
particle minecraft:cloud -54.86 68.64 -56.11 0.35 0.18 0.35 0.02 2 force
particle minecraft:cloud -53.38 68.64 -56.88 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -53.38 68.44 -56.88 0.021 0.02 0.039 1 0 force
scoreboard players set #gx driftmountains -54044
scoreboard players set #gdx driftmountains 94
scoreboard players set #gy driftmountains 68469
scoreboard players set #gdy driftmountains -26
scoreboard players set #gz driftmountains -51809
scoreboard players set #gdz driftmountains -723
scoreboard players set #gr driftmountains 15578
scoreboard players set #gdr driftmountains -500
scoreboard players set #gp driftmountains 179
scoreboard players set #gdp driftmountains -19
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[0.0061f,-0.0001f,0.0209f,0.9998f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.1451f,0.2153f,-0.0218f,-0.9655f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[-0.0796f,-0.9685f,0.1233f,-0.2012f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.2144f,0.0028f,-0.0128f,-0.9767f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0128f,-0.9767f,0.2144f,0.0028f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.4062f,0.8529f,0.2424f],left_rotation:[-0.0586f,-0.1777f,0.9195f,-0.3459f]}}
particle minecraft:cloud -54.26 68.79 -50.21 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud -52.70 68.79 -50.91 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -52.70 68.59 -50.91 0.018 0.02 0.039 1 0 force
scoreboard players set #gx driftmountains -55062
scoreboard players set #gdx driftmountains 135
scoreboard players set #gy driftmountains 68635
scoreboard players set #gdy driftmountains -19
scoreboard players set #gz driftmountains -46591
scoreboard players set #gdz driftmountains -639
scoreboard players set #gr driftmountains 16108
scoreboard players set #gdr driftmountains -54
scoreboard players set #gp driftmountains 143
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.5596f,0.2315f,0.0979f,-0.7897f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[-0.1814f,-0.8044f,0.5384f,-0.1740f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.2144f,0.0028f,-0.0128f,-0.9767f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0128f,-0.9767f,0.2144f,0.0028f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3822f,0.8215f,0.0899f],left_rotation:[-0.1150f,-0.1375f,0.7558f,-0.6298f]}}
particle minecraft:cloud -55.44 68.96 -45.13 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud -53.86 68.96 -45.67 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -53.86 68.76 -45.67 0.014 0.02 0.042 1 0 force
