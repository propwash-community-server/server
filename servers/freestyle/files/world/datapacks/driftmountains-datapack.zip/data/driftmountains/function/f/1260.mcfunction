scoreboard players set #gx driftmountains -53953
scoreboard players set #gdx driftmountains -90
scoreboard players set #gy driftmountains 68415
scoreboard players set #gdy driftmountains -18
scoreboard players set #gz driftmountains -53383
scoreboard players set #gdz driftmountains -692
scoreboard players set #gr driftmountains 14246
scoreboard players set #gdr driftmountains -153
scoreboard players set #gp driftmountains 138
scoreboard players set #gdp driftmountains -21
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,0.0001f,0.0194f,0.9998f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.1191f,0.1970f,-0.0296f,-0.9727f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[-0.0725f,-0.9749f,0.0990f,-0.1855f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.9797f,0.0128f,0.0026f,0.2000f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0026f,0.2000f,0.9797f,0.0128f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3998f,0.8361f,0.0956f],left_rotation:[-0.0298f,-0.1796f,0.9647f,-0.1903f]}}
particle minecraft:cloud -53.85 68.74 -51.87 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud -52.52 68.74 -52.89 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -52.52 68.54 -52.89 0.025 0.02 0.033 1 0 force
scoreboard players set #gx driftmountains -54696
scoreboard players set #gdx driftmountains 129
scoreboard players set #gy driftmountains 68571
scoreboard players set #gdy driftmountains -18
scoreboard players set #gz driftmountains -48756
scoreboard players set #gdz driftmountains -606
scoreboard players set #gr driftmountains 15754
scoreboard players set #gdr driftmountains -7
scoreboard players set #gp driftmountains 139
scoreboard players set #gdp driftmountains -3
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[-0.0028f,0.0001f,0.0210f,0.9998f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.9286f,-0.0156f,0.2919f,0.2286f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[-0.2695f,0.1991f,0.9354f,0.1133f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.9797f,0.0128f,0.0026f,0.2000f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0026f,0.2000f,0.9797f,0.0128f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3860f,0.8276f,0.2325f],left_rotation:[-0.1572f,-0.0845f,0.4557f,-0.8721f]}}
particle minecraft:cloud -54.96 68.89 -47.17 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud -53.38 68.89 -47.82 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -53.38 68.69 -47.82 0.017 0.02 0.042 1 0 force
scoreboard players set #gx driftmountains -56152
scoreboard players set #gdx driftmountains 240
scoreboard players set #gy driftmountains 68753
scoreboard players set #gdy driftmountains -21
scoreboard players set #gz driftmountains -42763
scoreboard players set #gdz driftmountains -663
scoreboard players set #gr driftmountains 16848
scoreboard players set #gdr driftmountains -173
scoreboard players set #gp driftmountains 144
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,0.0001f,0.0198f,0.9998f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.3215f,0.2236f,0.0213f,-0.9199f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[-0.1181f,-0.9272f,0.2998f,-0.1911f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.9797f,0.0128f,0.0026f,0.2000f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0026f,0.2000f,0.9797f,0.0128f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3933f,0.8269f,0.0920f],left_rotation:[-0.0737f,-0.1641f,0.8905f,-0.4178f]}}
particle minecraft:cloud -56.72 69.07 -41.36 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud -55.08 69.07 -41.69 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -55.08 68.87 -41.69 0.008 0.02 0.042 1 0 force
