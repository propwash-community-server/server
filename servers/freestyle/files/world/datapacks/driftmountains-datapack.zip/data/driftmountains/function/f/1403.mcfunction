scoreboard players set #gx driftmountains 19326
scoreboard players set #gdx driftmountains 991
scoreboard players set #gy driftmountains 66622
scoreboard players set #gdy driftmountains -13
scoreboard players set #gz driftmountains -58499
scoreboard players set #gdz driftmountains 627
scoreboard players set #gr driftmountains -5955
scoreboard players set #gdr driftmountains 50
scoreboard players set #gp driftmountains 62
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,0.0000f,0.0011f,1.0000f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.8370f,0.0521f,-0.0158f,-0.5444f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[-0.0413f,-0.5458f,0.8362f,0.0355f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.2850f,0.0037f,-0.0125f,-0.9584f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0125f,-0.9584f,0.2850f,0.0037f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3530f,0.8492f,0.1008f],left_rotation:[0.1862f,-0.0323f,0.1378f,0.9722f]}}
scoreboard players set #gx driftmountains 12172
scoreboard players set #gdx driftmountains 969
scoreboard players set #gy driftmountains 66714
scoreboard players set #gdy driftmountains -12
scoreboard players set #gz driftmountains -63211
scoreboard players set #gdz driftmountains 654
scoreboard players set #gr driftmountains -5786
scoreboard players set #gdr driftmountains -16
scoreboard players set #gp driftmountains 61
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[-0.0039f,0.0000f,0.0011f,1.0000f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.9919f,0.0501f,0.0225f,0.1147f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[-0.0106f,0.1130f,0.9921f,0.0539f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.2850f,0.0037f,-0.0125f,-0.9584f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0125f,-0.9584f,0.2850f,0.0037f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3587f,0.8394f,0.2371f],left_rotation:[0.1785f,-0.0342f,0.1500f,0.9718f]}}
scoreboard players set #gx driftmountains 3147
scoreboard players set #gdx driftmountains 939
scoreboard players set #gy driftmountains 66829
scoreboard players set #gdy driftmountains -12
scoreboard players set #gz driftmountains -69339
scoreboard players set #gdz driftmountains 621
scoreboard players set #gr driftmountains -5189
scoreboard players set #gdr driftmountains -31
scoreboard players set #gp driftmountains 61
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0000f,-0.0028f,1.0000f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.8529f,0.0238f,-0.0616f,-0.5179f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.0075f,-0.5143f,0.8550f,0.0657f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.2850f,0.0037f,-0.0125f,-0.9584f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0125f,-0.9584f,0.2850f,0.0037f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3592f,0.8279f,0.0924f],left_rotation:[0.1727f,0.0596f,-0.3510f,0.9183f]}}
