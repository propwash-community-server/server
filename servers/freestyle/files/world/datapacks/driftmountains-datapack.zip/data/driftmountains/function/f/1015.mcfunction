scoreboard players set #gx driftmountains 26161
scoreboard players set #gdx driftmountains -335
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 42263
scoreboard players set #gdz driftmountains 976
scoreboard players set #gr driftmountains 7273
scoreboard players set #gdr driftmountains 94
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.6941f,0.3165f,-0.2895f,0.5782f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.3519f,0.6118f,0.6646f,-0.2453f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.9908f,0.0130f,-0.0018f,-0.1350f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0018f,-0.1350f,0.9908f,0.0130f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3815f,0.8214f,0.0899f],left_rotation:[-0.1174f,-0.1354f,0.7453f,-0.6422f]}}
particle minecraft:cloud 27.61 71.32 42.69 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 27.61 71.12 42.69 0.059 0.02 -0.018 1 0 force
particle minecraft:cloud 27.12 71.32 41.09 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains 28452
scoreboard players set #gdx driftmountains -39
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 34624
scoreboard players set #gdz driftmountains 1007
scoreboard players set #gr driftmountains 6428
scoreboard players set #gdr driftmountains 348
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[0.0009f,0.0000f,-0.0223f,0.9998f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.0550f,0.4635f,0.0303f,0.8839f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.0624f,0.8855f,0.0066f,-0.4603f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.9908f,0.0130f,-0.0018f,-0.1350f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0018f,-0.1350f,0.9908f,0.0130f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.4061f,0.8534f,0.2426f],left_rotation:[-0.0566f,-0.1785f,0.9235f,-0.3350f]}}
particle minecraft:cloud 30.05 71.32 34.80 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 30.05 71.12 34.80 0.054 0.02 -0.026 1 0 force
particle minecraft:cloud 29.31 71.32 33.26 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains 26221
scoreboard players set #gdx driftmountains 287
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 30184
scoreboard players set #gdz driftmountains 951
scoreboard players set #gr driftmountains 3660
scoreboard players set #gdr driftmountains 317
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.8634f,-0.0721f,-0.4173f,-0.2744f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.3908f,-0.2320f,0.8757f,0.1632f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.9908f,0.0130f,-0.0018f,-0.1350f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0018f,-0.1350f,0.9908f,0.0130f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3788f,0.8210f,0.0897f],left_rotation:[-0.1253f,-0.1283f,0.7088f,-0.6821f]}}
particle minecraft:cloud 27.64 71.32 29.67 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 27.64 71.12 29.67 0.034 0.02 -0.046 1 0 force
particle minecraft:cloud 26.30 71.32 28.67 0.35 0.18 0.35 0.02 3 force
