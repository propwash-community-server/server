scoreboard players set #gx driftmountains -56383
scoreboard players set #gdx driftmountains 166
scoreboard players set #gy driftmountains 68023
scoreboard players set #gdy driftmountains -19
scoreboard players set #gz driftmountains -72839
scoreboard players set #gdz driftmountains -579
scoreboard players set #gr driftmountains -13219
scoreboard players set #gdr driftmountains 346
scoreboard players set #gp driftmountains 148
scoreboard players set #gdp driftmountains -4
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0001f,-0.0206f,0.9998f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.8771f,0.1298f,-0.1396f,0.4409f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.1867f,0.4580f,0.8683f,-0.0383f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.2510f,0.0033f,0.0127f,0.9679f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0127f,0.9679f,0.2510f,0.0033f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.4005f,0.8494f,0.1009f],left_rotation:[-0.0257f,0.1839f,-0.9774f,-0.1006f]}}
particle minecraft:cloud -57.88 68.34 -72.61 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -57.88 68.14 -72.61 -0.027 0.02 0.024 1 0 force
particle minecraft:cloud -56.76 68.34 -71.37 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -55813
scoreboard players set #gdx driftmountains -68
scoreboard players set #gy driftmountains 68146
scoreboard players set #gdy driftmountains -15
scoreboard players set #gz driftmountains -67969
scoreboard players set #gdz driftmountains -742
scoreboard players set #gr driftmountains -15436
scoreboard players set #gdr driftmountains 265
scoreboard players set #gp driftmountains 94
scoreboard players set #gdp driftmountains 2
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[0.0061f,0.0001f,-0.0191f,0.9998f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.8783f,-0.0537f,-0.2437f,-0.4079f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.2022f,-0.3845f,0.8887f,0.1463f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.2510f,0.0033f,0.0127f,0.9679f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0127f,0.9679f,0.2510f,0.0033f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3671f,0.8705f,0.2493f],left_rotation:[-0.1156f,0.1530f,-0.7683f,-0.6107f]}}
particle minecraft:cloud -57.17 68.47 -67.11 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -57.17 68.27 -67.11 -0.019 0.02 0.040 1 0 force
particle minecraft:cloud -55.63 68.47 -66.37 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -54667
scoreboard players set #gdx driftmountains -85
scoreboard players set #gy driftmountains 68265
scoreboard players set #gdy driftmountains -12
scoreboard players set #gz driftmountains -61241
scoreboard players set #gdz driftmountains -716
scoreboard players set #gr driftmountains 17493
scoreboard players set #gdr driftmountains 356
scoreboard players set #gp driftmountains 94
scoreboard players set #gdp driftmountains -1
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0000f,-0.0011f,1.0000f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.4014f,0.0125f,-0.0517f,-0.9143f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[-0.0441f,-0.9140f,0.4023f,0.0296f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.2510f,0.0033f,0.0127f,0.9679f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0127f,0.9679f,0.2510f,0.0033f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3528f,0.8391f,0.0968f],left_rotation:[0.1861f,0.0087f,-0.0813f,0.9791f]}}
