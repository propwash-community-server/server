$function driftmountains:f/$(t)
