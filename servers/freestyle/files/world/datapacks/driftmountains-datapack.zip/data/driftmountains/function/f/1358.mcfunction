scoreboard players set #gx driftmountains -18474
scoreboard players set #gdx driftmountains 721
scoreboard players set #gy driftmountains 67119
scoreboard players set #gdy driftmountains -10
scoreboard players set #gz driftmountains -83391
scoreboard players set #gdz driftmountains 443
scoreboard players set #gr driftmountains -3113
scoreboard players set #gdr driftmountains -44
scoreboard players set #gp driftmountains 63
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0001f,-0.0168f,0.9999f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.1270f,-0.2214f,-0.0835f,-0.9633f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[-0.0173f,-0.9598f,0.1510f,0.2360f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.5698f,0.0075f,0.0108f,0.8217f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0108f,0.8217f,0.5698f,0.0075f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3871f,0.8644f,0.1068f],left_rotation:[-0.1026f,0.1608f,-0.8394f,-0.5089f]}}
particle minecraft:cloud -18.41 67.44 -84.90 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -18.41 67.24 -84.90 -0.026 0.02 -0.043 1 0 force
particle minecraft:cloud -19.84 67.44 -84.04 0.35 0.18 0.35 0.02 2 force
scoreboard players set #gx driftmountains -24883
scoreboard players set #gdx driftmountains 672
scoreboard players set #gy driftmountains 67213
scoreboard players set #gdy driftmountains -11
scoreboard players set #gz driftmountains -86784
scoreboard players set #gdz driftmountains 377
scoreboard players set #gr driftmountains -3221
scoreboard players set #gdr driftmountains 31
scoreboard players set #gp driftmountains 69
scoreboard players set #gdp driftmountains -1
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0001f,-0.0175f,0.9998f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.3783f,-0.1946f,-0.1408f,-0.8940f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.0476f,-0.8841f,0.4008f,0.2354f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.5698f,0.0075f,0.0108f,0.8217f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0108f,0.8217f,0.5698f,0.0075f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3712f,0.8725f,0.2500f],left_rotation:[-0.1027f,0.1628f,-0.8204f,-0.5385f]}}
particle minecraft:cloud -24.89 67.53 -88.39 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -24.89 67.33 -88.39 -0.026 0.02 -0.041 1 0 force
particle minecraft:cloud -26.33 67.53 -87.48 0.35 0.18 0.35 0.02 2 force
scoreboard players set #gx driftmountains -31645
scoreboard players set #gdx driftmountains 649
scoreboard players set #gy driftmountains 67329
scoreboard players set #gdy driftmountains -11
scoreboard players set #gz driftmountains -90736
scoreboard players set #gdz driftmountains 267
scoreboard players set #gr driftmountains -3733
scoreboard players set #gdr driftmountains 74
scoreboard players set #gp driftmountains 83
scoreboard players set #gdp driftmountains -4
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0001f,-0.0189f,0.9998f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.8689f,-0.0561f,-0.2333f,-0.4330f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.1891f,-0.4108f,0.8796f,0.1477f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.5698f,0.0075f,0.0108f,0.8217f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0108f,0.8217f,0.5698f,0.0075f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3857f,0.8650f,0.1070f],left_rotation:[-0.1075f,0.1578f,-0.8227f,-0.5353f]}}
particle minecraft:cloud -31.75 67.65 -92.24 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -31.75 67.45 -92.24 -0.025 0.02 -0.033 1 0 force
particle minecraft:cloud -33.07 67.65 -91.23 0.35 0.18 0.35 0.02 3 force
