scoreboard players set #gx driftmountains -97329
scoreboard players set #gdx driftmountains -216
scoreboard players set #gy driftmountains 70034
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains -2235
scoreboard players set #gdz driftmountains -921
scoreboard players set #gr driftmountains -14368
scoreboard players set #gdr driftmountains 184
scoreboard players set #gp driftmountains -1
scoreboard players set #gdp driftmountains 4
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.9212f,0.0234f,-0.3798f,-0.0808f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.3734f,-0.0414f,0.9239f,0.0733f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.8303f,0.0109f,-0.0073f,-0.5571f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0073f,-0.5571f,0.8303f,0.0109f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3596f,0.8276f,0.0923f],left_rotation:[-0.1720f,-0.0614f,0.3600f,-0.9149f]}}
particle minecraft:cloud -98.75 70.35 -1.71 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -98.75 70.15 -1.71 -0.034 0.02 0.046 1 0 force
particle minecraft:cloud -97.40 70.35 -0.73 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -93878
scoreboard players set #gdx driftmountains -562
scoreboard players set #gy driftmountains 70006
scoreboard players set #gdy driftmountains 4
scoreboard players set #gz driftmountains 5398
scoreboard players set #gdz driftmountains -827
scoreboard players set #gr driftmountains -16836
scoreboard players set #gdr driftmountains 313
scoreboard players set #gp driftmountains -17
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.6953f,0.2776f,-0.2259f,0.6232f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.2927f,0.6504f,0.6700f,-0.2061f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.8303f,0.0109f,-0.0073f,-0.5571f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0073f,-0.5571f,0.8303f,0.0109f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3697f,0.8296f,0.2332f],left_rotation:[-0.1772f,-0.0241f,0.1486f,-0.9726f]}}
particle minecraft:cloud -94.99 70.33 6.56 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -94.99 70.13 6.56 -0.012 0.02 0.058 1 0 force
particle minecraft:cloud -93.32 70.33 6.91 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -90253
scoreboard players set #gdx driftmountains -661
scoreboard players set #gy driftmountains 69986
scoreboard players set #gdy driftmountains 3
scoreboard players set #gz driftmountains 9693
scoreboard players set #gdz driftmountains -759
scoreboard players set #gr driftmountains 17896
scoreboard players set #gdr driftmountains 103
scoreboard players set #gp driftmountains -10
scoreboard players set #gdp driftmountains -3
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.4362f,-0.2745f,-0.2068f,-0.8316f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.1206f,-0.8145f,0.4674f,0.3219f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.8303f,0.0109f,-0.0073f,-0.5571f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0073f,-0.5571f,0.8303f,0.0109f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3524f,0.8423f,0.0981f],left_rotation:[-0.1871f,0.0043f,0.0121f,-0.9822f]}}
particle minecraft:cloud -91.06 70.31 10.97 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -91.06 70.11 10.97 0.001 0.02 0.061 1 0 force
particle minecraft:cloud -89.39 70.31 10.94 0.35 0.18 0.35 0.02 3 force
