scoreboard players set #gx driftmountains -80740
scoreboard players set #gdx driftmountains 619
scoreboard players set #gy driftmountains 69376
scoreboard players set #gdy driftmountains -11
scoreboard players set #gz driftmountains -26922
scoreboard players set #gdz driftmountains -99
scoreboard players set #gr driftmountains -10109
scoreboard players set #gdr driftmountains -562
scoreboard players set #gp driftmountains 103
scoreboard players set #gdp driftmountains -4
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,0.0000f,0.0016f,1.0000f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.7286f,0.0178f,-0.0576f,-0.6823f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[-0.0138f,-0.6800f,0.7307f,0.0587f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.6727f,0.0088f,0.0097f,0.7398f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0097f,0.7398f,0.6727f,0.0088f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3563f,0.8312f,0.0937f],left_rotation:[0.1788f,0.0429f,-0.2625f,0.9472f]}}
scoreboard players set #gx driftmountains -86570
scoreboard players set #gdx driftmountains 525
scoreboard players set #gy driftmountains 69503
scoreboard players set #gdy driftmountains -15
scoreboard players set #gz driftmountains -26258
scoreboard players set #gdz driftmountains -261
scoreboard players set #gr driftmountains -7620
scoreboard players set #gdr driftmountains -60
scoreboard players set #gp driftmountains 110
scoreboard players set #gdp driftmountains 7
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.9659f,0.0452f,-0.2525f,-0.0342f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.2503f,-0.0079f,0.9665f,0.0561f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.6727f,0.0088f,0.0097f,0.7398f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0097f,0.7398f,0.6727f,0.0088f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3644f,0.8686f,0.2485f],left_rotation:[-0.1246f,0.1450f,-0.7258f,-0.6608f]}}
particle minecraft:cloud -87.69 69.82 -27.41 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -87.69 69.62 -27.41 -0.035 0.02 -0.009 1 0 force
particle minecraft:cloud -88.10 69.82 -25.75 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -89221
scoreboard players set #gdx driftmountains 525
scoreboard players set #gy driftmountains 69598
scoreboard players set #gdy driftmountains -17
scoreboard players set #gz driftmountains -23986
scoreboard players set #gdz driftmountains -323
scoreboard players set #gr driftmountains -7611
scoreboard players set #gdr driftmountains 175
scoreboard players set #gp driftmountains 106
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.0748f,-0.3430f,-0.0836f,-0.9326f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[-0.0140f,-0.9290f,0.1113f,0.3528f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.6727f,0.0088f,0.0097f,0.7398f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0097f,0.7398f,0.6727f,0.0088f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3531f,0.8382f,0.0965f],left_rotation:[-0.1856f,-0.0126f,0.1019f,-0.9772f]}}
particle minecraft:cloud -90.24 69.92 -25.10 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -90.24 69.72 -25.10 -0.040 0.02 -0.010 1 0 force
particle minecraft:cloud -90.64 69.92 -23.48 0.35 0.18 0.35 0.02 3 force
