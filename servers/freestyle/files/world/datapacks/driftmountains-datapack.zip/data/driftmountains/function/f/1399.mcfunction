scoreboard players set #gx driftmountains 15434
scoreboard players set #gdx driftmountains 959
scoreboard players set #gy driftmountains 66672
scoreboard players set #gdy driftmountains -12
scoreboard players set #gz driftmountains -60984
scoreboard players set #gdz driftmountains 623
scoreboard players set #gr driftmountains -5918
scoreboard players set #gdr driftmountains -43
scoreboard players set #gp driftmountains 61
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.0531f,-0.0097f,0.0529f,0.9971f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.0516f,0.9971f,0.0544f,0.0153f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.6946f,0.0091f,0.0094f,0.7193f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0094f,0.7193f,0.6946f,0.0091f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3528f,0.8481f,0.1004f],left_rotation:[0.1867f,-0.0279f,0.1140f,0.9753f]}}
scoreboard players set #gx driftmountains 8412
scoreboard players set #gdx driftmountains 918
scoreboard players set #gy driftmountains 66761
scoreboard players set #gdy driftmountains -12
scoreboard players set #gz driftmountains -65732
scoreboard players set #gdz driftmountains 612
scoreboard players set #gr driftmountains -5561
scoreboard players set #gdr driftmountains -70
scoreboard players set #gp driftmountains 61
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0000f,-0.0005f,1.0000f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.5945f,0.0276f,-0.0447f,-0.8024f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[-0.0394f,-0.8021f,0.5948f,0.0348f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.6946f,0.0091f,0.0094f,0.7193f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0094f,0.7193f,0.6946f,0.0091f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3649f,0.8325f,0.2344f],left_rotation:[0.1796f,0.0024f,-0.0377f,0.9830f]}}
scoreboard players set #gx driftmountains -463
scoreboard players set #gdx driftmountains 848
scoreboard players set #gy driftmountains 66875
scoreboard players set #gdy driftmountains -11
scoreboard players set #gz driftmountains -71730
scoreboard players set #gdz driftmountains 562
scoreboard players set #gr driftmountains -5066
scoreboard players set #gdr driftmountains -37
scoreboard players set #gp driftmountains 61
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0000f,-0.0036f,1.0000f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.0227f,0.0519f,0.0512f,0.9971f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.0533f,0.9972f,0.0173f,-0.0498f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.6946f,0.0091f,0.0094f,0.7193f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0094f,0.7193f,0.6946f,0.0091f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3628f,0.8251f,0.0913f],left_rotation:[0.1651f,0.0759f,-0.4362f,0.8813f]}}
