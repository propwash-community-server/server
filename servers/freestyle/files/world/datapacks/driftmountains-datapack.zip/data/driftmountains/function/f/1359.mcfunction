scoreboard players set #gx driftmountains -17753
scoreboard players set #gdx driftmountains 726
scoreboard players set #gy driftmountains 67108
scoreboard players set #gdy driftmountains -10
scoreboard players set #gz driftmountains -82948
scoreboard players set #gdz driftmountains 449
scoreboard players set #gr driftmountains -3156
scoreboard players set #gdr driftmountains -57
scoreboard players set #gp driftmountains 63
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0001f,-0.0163f,0.9999f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.8860f,0.1420f,-0.1833f,0.4015f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.2265f,0.4230f,0.8760f,-0.0497f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.9420f,0.0123f,-0.0044f,-0.3354f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0044f,-0.3354f,0.9420f,0.0123f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3891f,0.8635f,0.1064f],left_rotation:[-0.0954f,0.1647f,-0.8618f,-0.4700f]}}
particle minecraft:cloud -17.70 67.43 -84.46 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -17.70 67.23 -84.46 -0.027 0.02 -0.043 1 0 force
particle minecraft:cloud -19.12 67.43 -83.58 0.35 0.18 0.35 0.02 2 force
scoreboard players set #gx driftmountains -24211
scoreboard players set #gdx driftmountains 734
scoreboard players set #gy driftmountains 67202
scoreboard players set #gdy driftmountains -11
scoreboard players set #gz driftmountains -86406
scoreboard players set #gdz driftmountains 420
scoreboard players set #gr driftmountains -3189
scoreboard players set #gdr driftmountains 36
scoreboard players set #gp driftmountains 68
scoreboard players set #gdp driftmountains -1
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.6960f,0.2013f,-0.1298f,0.6769f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.2016f,0.6943f,0.6786f,-0.1293f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.9420f,0.0123f,-0.0044f,-0.3354f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0044f,-0.3354f,0.9420f,0.0123f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3714f,0.8726f,0.2501f],left_rotation:[-0.1018f,0.1634f,-0.8236f,-0.5336f]}}
particle minecraft:cloud -24.21 67.52 -88.02 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -24.21 67.32 -88.02 -0.025 0.02 -0.041 1 0 force
particle minecraft:cloud -25.66 67.52 -87.11 0.35 0.18 0.35 0.02 2 force
scoreboard players set #gx driftmountains -30996
scoreboard players set #gdx driftmountains 640
scoreboard players set #gy driftmountains 67317
scoreboard players set #gdy driftmountains -11
scoreboard players set #gz driftmountains -90470
scoreboard players set #gdz driftmountains 276
scoreboard players set #gr driftmountains -3659
scoreboard players set #gdr driftmountains 58
scoreboard players set #gp driftmountains 78
scoreboard players set #gdp driftmountains -2
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0001f,-0.0187f,0.9998f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.0757f,-0.2274f,-0.0718f,-0.9682f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[-0.0296f,-0.9660f,0.1001f,0.2366f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.9420f,0.0123f,-0.0044f,-0.3354f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0044f,-0.3354f,0.9420f,0.0123f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3863f,0.8648f,0.1069f],left_rotation:[-0.1054f,0.1591f,-0.8302f,-0.5237f]}}
particle minecraft:cloud -31.08 67.64 -91.98 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -31.08 67.44 -91.98 -0.025 0.02 -0.033 1 0 force
particle minecraft:cloud -32.42 67.64 -90.98 0.35 0.18 0.35 0.02 3 force
