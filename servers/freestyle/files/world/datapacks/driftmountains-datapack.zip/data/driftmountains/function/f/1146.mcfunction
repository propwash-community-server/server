scoreboard players set #gx driftmountains -96058
scoreboard players set #gdx driftmountains -383
scoreboard players set #gy driftmountains 70026
scoreboard players set #gdy driftmountains 3
scoreboard players set #gz driftmountains 1376
scoreboard players set #gdz driftmountains -879
scoreboard players set #gr driftmountains -15421
scoreboard players set #gdr driftmountains 279
scoreboard players set #gp driftmountains -13
scoreboard players set #gdp driftmountains 2
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.3916f,-0.3132f,-0.2083f,-0.8397f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.1212f,-0.8225f,0.4267f,0.3561f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.0771f,0.0010f,0.0131f,0.9969f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0131f,0.9969f,0.0771f,0.0010f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3581f,0.8290f,0.0929f],left_rotation:[-0.1750f,-0.0537f,0.3198f,-0.9296f]}}
particle minecraft:cloud -97.36 70.35 2.15 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -97.36 70.15 2.15 -0.025 0.02 0.052 1 0 force
particle minecraft:cloud -95.85 70.35 2.87 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -91357
scoreboard players set #gdx driftmountains -659
scoreboard players set #gy driftmountains 69990
scoreboard players set #gdy driftmountains 4
scoreboard players set #gz driftmountains 8573
scoreboard players set #gdz driftmountains -787
scoreboard players set #gr driftmountains -17936
scoreboard players set #gdr driftmountains 198
scoreboard players set #gp driftmountains -14
scoreboard players set #gdp driftmountains -2
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.8934f,-0.0518f,-0.3379f,-0.2915f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.3092f,-0.2576f,0.9037f,0.1460f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.0771f,0.0010f,0.0131f,0.9969f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0131f,0.9969f,0.0771f,0.0010f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3632f,0.8339f,0.2349f],left_rotation:[-0.1800f,0.0061f,-0.0056f,-0.9837f]}}
particle minecraft:cloud -92.23 70.31 9.93 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -92.23 70.11 9.93 -0.001 0.02 0.061 1 0 force
particle minecraft:cloud -90.52 70.31 9.95 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -87537
scoreboard players set #gdx driftmountains -634
scoreboard players set #gy driftmountains 69984
scoreboard players set #gdy driftmountains -1
scoreboard players set #gz driftmountains 12775
scoreboard players set #gdz driftmountains -715
scoreboard players set #gr driftmountains 17560
scoreboard players set #gdr driftmountains 65
scoreboard players set #gp driftmountains 8
scoreboard players set #gdp driftmountains -5
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.5052f,0.2974f,-0.1223f,0.8009f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.2072f,0.8181f,0.4767f,-0.2459f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.0771f,0.0010f,0.0131f,0.9969f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0131f,0.9969f,0.0771f,0.0010f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3539f,0.8519f,0.1019f],left_rotation:[-0.1846f,0.0437f,-0.1990f,-0.9614f]}}
particle minecraft:cloud -88.27 70.30 14.10 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -88.27 70.10 14.10 0.005 0.02 0.063 1 0 force
particle minecraft:cloud -86.61 70.30 13.97 0.35 0.18 0.35 0.02 3 force
