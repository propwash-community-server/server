scoreboard players set #gx driftmountains -68841
scoreboard players set #gdx driftmountains -981
scoreboard players set #gy driftmountains 70401
scoreboard players set #gdy driftmountains -24
scoreboard players set #gz driftmountains 34015
scoreboard players set #gdz driftmountains -1017
scoreboard players set #gr driftmountains -17995
scoreboard players set #gdr driftmountains -40
scoreboard players set #gp driftmountains 69
scoreboard players set #gdp driftmountains 4
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.7108f,0.2797f,-0.2455f,0.5968f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.3096f,0.6259f,0.6854f,-0.2065f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.9950f,0.0130f,0.0013f,0.0990f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0013f,0.0990f,0.9950f,0.0130f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3569f,0.8304f,0.0934f],left_rotation:[-0.1775f,-0.0467f,0.2828f,-0.9414f]}}
particle minecraft:cloud -69.68 70.72 35.27 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -69.68 70.52 35.27 -0.000 0.02 0.085 1 0 force
particle minecraft:cloud -68.01 70.72 35.28 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -60427
scoreboard players set #gdx driftmountains -1144
scoreboard players set #gy driftmountains 70516
scoreboard players set #gdy driftmountains -4
scoreboard players set #gz driftmountains 40808
scoreboard players set #gdz driftmountains -845
scoreboard players set #gr driftmountains 17364
scoreboard players set #gdr driftmountains 146
scoreboard players set #gp driftmountains 5
scoreboard players set #gdp driftmountains 10
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.0520f,0.3816f,0.0352f,0.9222f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.0616f,0.9236f,0.0122f,-0.3783f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.9950f,0.0130f,0.0013f,0.0990f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0013f,0.0990f,0.9950f,0.0130f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3820f,0.8272f,0.2323f],left_rotation:[-0.1638f,-0.0704f,0.3844f,-0.9058f]}}
particle minecraft:cloud -61.13 70.84 42.26 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -61.13 70.64 42.26 0.009 0.02 0.083 1 0 force
particle minecraft:cloud -59.43 70.84 42.07 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -56152
scoreboard players set #gdx driftmountains -1205
scoreboard players set #gy driftmountains 70504
scoreboard players set #gdy driftmountains 6
scoreboard players set #gz driftmountains 44073
scoreboard players set #gdz driftmountains -743
scoreboard players set #gr driftmountains 16843
scoreboard players set #gdr driftmountains 221
scoreboard players set #gp driftmountains -18
scoreboard players set #gdp driftmountains 4
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.8805f,-0.0602f,-0.3799f,-0.2772f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.3528f,-0.2388f,0.8916f,0.1531f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.9950f,0.0130f,0.0013f,0.0990f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0013f,0.0990f,0.9950f,0.0130f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3610f,0.8263f,0.0918f],left_rotation:[-0.1688f,-0.0684f,0.3969f,-0.8996f]}}
particle minecraft:cloud -56.72 70.82 45.47 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -56.72 70.62 45.47 0.017 0.02 0.083 1 0 force
particle minecraft:cloud -55.08 70.82 45.14 0.35 0.18 0.35 0.02 3 force
