scoreboard players set #gx driftmountains 13917
scoreboard players set #gdx driftmountains 443
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains -1553
scoreboard players set #gdz driftmountains 926
scoreboard players set #gr driftmountains 1208
scoreboard players set #gdr driftmountains 7
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.9239f,0.1233f,-0.2969f,0.2076f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.3204f,0.2400f,0.9160f,-0.0269f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.6481f,0.0085f,0.0100f,0.7615f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0100f,0.7615f,0.6481f,0.0085f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3540f,0.8520f,0.1019f],left_rotation:[-0.1845f,0.0439f,-0.2000f,-0.9612f]}}
particle minecraft:cloud 15.00 71.32 -2.61 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 15.00 71.12 -2.61 0.013 0.02 -0.060 1 0 force
particle minecraft:cloud 13.36 71.32 -2.96 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains 10818
scoreboard players set #gdx driftmountains 481
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains -7345
scoreboard players set #gdz driftmountains 945
scoreboard players set #gr driftmountains 1063
scoreboard players set #gdr driftmountains 22
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.5573f,0.2888f,-0.1419f,0.7655f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.2232f,0.7846f,0.5300f,-0.2318f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.6481f,0.0085f,0.0100f,0.7615f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0100f,0.7615f,0.6481f,0.0085f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3577f,0.8415f,0.2379f],left_rotation:[-0.1772f,0.0433f,-0.1970f,-0.9633f]}}
particle minecraft:cloud 11.91 71.32 -8.53 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 11.91 71.12 -8.53 0.011 0.02 -0.059 1 0 force
particle minecraft:cloud 10.23 71.32 -8.84 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains 8103
scoreboard players set #gdx driftmountains 420
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains -12502
scoreboard players set #gdz driftmountains 768
scoreboard players set #gr driftmountains 935
scoreboard players set #gdr driftmountains -20
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.9432f,0.0749f,-0.3185f,0.0576f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.3263f,0.0914f,0.9405f,0.0239f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.6481f,0.0085f,0.0100f,0.7615f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0100f,0.7615f,0.6481f,0.0085f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3531f,0.8496f,0.1009f],left_rotation:[-0.1860f,0.0339f,-0.1463f,-0.9709f]}}
particle minecraft:cloud 9.13 71.32 -13.61 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 9.13 71.12 -13.61 0.009 0.02 -0.056 1 0 force
particle minecraft:cloud 7.48 71.32 -13.88 0.35 0.18 0.35 0.02 3 force
