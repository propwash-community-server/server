scoreboard players set #gx driftmountains -34071
scoreboard players set #gdx driftmountains 652
scoreboard players set #gy driftmountains 67373
scoreboard players set #gdy driftmountains -13
scoreboard players set #gz driftmountains -91166
scoreboard players set #gdz driftmountains 191
scoreboard players set #gr driftmountains -4215
scoreboard players set #gdr driftmountains 178
scoreboard players set #gp driftmountains 92
scoreboard players set #gdp driftmountains -1
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0001f,-0.0200f,0.9998f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.9565f,0.0103f,-0.2101f,-0.2019f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.1900f,-0.1810f,0.9607f,0.0902f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.9207f,0.0121f,-0.0051f,-0.3901f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0051f,-0.3901f,0.9207f,0.0121f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3966f,0.8572f,0.1039f],left_rotation:[-0.0603f,0.1782f,-0.9404f,-0.2831f]}}
particle minecraft:cloud -34.30 67.69 -92.66 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -34.30 67.49 -92.66 -0.027 0.02 -0.030 1 0 force
particle minecraft:cloud -35.54 67.69 -91.54 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -39559
scoreboard players set #gdx driftmountains 607
scoreboard players set #gy driftmountains 67508
scoreboard players set #gdy driftmountains -18
scoreboard players set #gz driftmountains -91702
scoreboard players set #gdz driftmountains -29
scoreboard players set #gr driftmountains -5753
scoreboard players set #gdr driftmountains 487
scoreboard players set #gp driftmountains 128
scoreboard players set #gdp driftmountains 9
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.8433f,0.1503f,-0.1509f,0.4934f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.2036f,0.5119f,0.8322f,-0.0625f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.9207f,0.0121f,-0.0051f,-0.3901f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0051f,-0.3901f,0.9207f,0.0121f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3841f,0.8741f,0.2507f],left_rotation:[-0.0611f,0.1833f,-0.9315f,-0.3082f]}}
particle minecraft:cloud -40.25 67.83 -93.16 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -40.25 67.63 -93.16 -0.031 0.02 -0.019 1 0 force
particle minecraft:cloud -41.17 67.83 -91.71 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -44197
scoreboard players set #gdx driftmountains 575
scoreboard players set #gy driftmountains 67626
scoreboard players set #gdy driftmountains -14
scoreboard players set #gz driftmountains -90013
scoreboard players set #gdz driftmountains -421
scoreboard players set #gr driftmountains -9284
scoreboard players set #gdr driftmountains 292
scoreboard players set #gp driftmountains 91
scoreboard players set #gdp driftmountains 6
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[0.0061f,0.0001f,-0.0211f,0.9998f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.8212f,0.1643f,-0.1580f,0.5231f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.2139f,0.5426f,0.8085f,-0.0789f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.9207f,0.0121f,-0.0051f,-0.3901f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0051f,-0.3901f,0.9207f,0.0121f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3907f,0.8626f,0.1060f],left_rotation:[-0.0893f,0.1677f,-0.8789f,-0.4375f]}}
particle minecraft:cloud -45.50 67.95 -90.78 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -45.50 67.75 -90.78 -0.039 0.02 0.002 1 0 force
particle minecraft:cloud -45.41 67.95 -89.12 0.35 0.18 0.35 0.02 3 force
