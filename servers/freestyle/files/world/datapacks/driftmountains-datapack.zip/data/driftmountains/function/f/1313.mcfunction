scoreboard players set #gx driftmountains -47376
scoreboard players set #gdx driftmountains 568
scoreboard players set #gy driftmountains 67701
scoreboard players set #gdy driftmountains -13
scoreboard players set #gz driftmountains -87284
scoreboard players set #gdz driftmountains -505
scoreboard players set #gr driftmountains -9843
scoreboard players set #gdr driftmountains 170
scoreboard players set #gp driftmountains 81
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[0.0061f,0.0001f,-0.0207f,0.9998f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.8888f,-0.0481f,-0.2488f,-0.3819f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.2100f,-0.3578f,0.8988f,0.1418f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.9975f,0.0131f,0.0009f,0.0691f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0009f,0.0691f,0.9975f,0.0131f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3796f,0.8664f,0.1075f],left_rotation:[-0.1264f,0.1442f,-0.7467f,-0.6368f]}}
particle minecraft:cloud -48.74 68.02 -87.93 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -48.74 67.82 -87.93 -0.046 0.02 0.007 1 0 force
particle minecraft:cloud -48.50 68.02 -86.27 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -50889
scoreboard players set #gdx driftmountains 442
scoreboard players set #gy driftmountains 67788
scoreboard players set #gdy driftmountains -12
scoreboard players set #gz driftmountains -83416
scoreboard players set #gdz driftmountains -606
scoreboard players set #gr driftmountains -11038
scoreboard players set #gdr driftmountains 174
scoreboard players set #gp driftmountains 78
scoreboard players set #gdp driftmountains 1
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0001f,-0.0209f,0.9998f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.9627f,0.0293f,-0.2514f,-0.0957f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.2427f,-0.0698f,0.9649f,0.0717f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.9975f,0.0131f,0.0009f,0.0691f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0009f,0.0691f,0.9975f,0.0131f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3657f,0.8696f,0.2489f],left_rotation:[-0.1202f,0.1490f,-0.7472f,-0.6364f]}}
particle minecraft:cloud -52.47 68.11 -83.74 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -52.47 67.91 -83.74 -0.044 0.02 0.016 1 0 force
particle minecraft:cloud -51.87 68.11 -82.14 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -52961
scoreboard players set #gdx driftmountains 333
scoreboard players set #gy driftmountains 67884
scoreboard players set #gdy driftmountains -14
scoreboard players set #gz driftmountains -78096
scoreboard players set #gdz driftmountains -725
scoreboard players set #gr driftmountains -12565
scoreboard players set #gdr driftmountains 74
scoreboard players set #gp driftmountains 92
scoreboard players set #gdp driftmountains -6
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0001f,-0.0184f,0.9998f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.4989f,0.2294f,-0.0747f,0.8324f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.1626f,0.8448f,0.4776f,-0.1782f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.9975f,0.0131f,0.0009f,0.0691f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0009f,0.0691f,0.9975f,0.0131f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3851f,0.8652f,0.1071f],left_rotation:[-0.1094f,0.1566f,-0.8160f,-0.5454f]}}
particle minecraft:cloud -54.47 68.20 -78.04 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -54.47 68.00 -78.04 -0.034 0.02 0.025 1 0 force
particle minecraft:cloud -53.50 68.20 -76.68 0.35 0.18 0.35 0.02 3 force
