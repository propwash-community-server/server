scoreboard players set #gx driftmountains -64356
scoreboard players set #gdx driftmountains 607
scoreboard players set #gy driftmountains 69127
scoreboard players set #gdy driftmountains -11
scoreboard players set #gz driftmountains -32593
scoreboard players set #gdz driftmountains -238
scoreboard players set #gr driftmountains -13489
scoreboard players set #gdr driftmountains -449
scoreboard players set #gp driftmountains 88
scoreboard players set #gdp driftmountains 3
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[0.0061f,-0.0001f,0.0148f,0.9999f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.1273f,-0.1650f,0.0751f,0.9752f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.0269f,0.9726f,0.1454f,0.1793f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.9150f,0.0120f,-0.0053f,-0.4032f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0053f,-0.4032f,0.9150f,0.0120f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.4013f,0.8438f,0.0987f],left_rotation:[0.0024f,-0.1841f,0.9826f,-0.0219f]}}
particle minecraft:cloud -65.84 69.45 -32.30 0.35 0.18 0.35 0.02 2 force
particle minecraft:cloud -64.66 69.45 -31.11 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -64.66 69.25 -31.11 -0.028 0.02 0.028 1 0 force
scoreboard players set #gx driftmountains -70757
scoreboard players set #gdx driftmountains 734
scoreboard players set #gy driftmountains 69225
scoreboard players set #gdy driftmountains -10
scoreboard players set #gz driftmountains -31892
scoreboard players set #gdz driftmountains -307
scoreboard players set #gr driftmountains -11790
scoreboard players set #gdr driftmountains -5
scoreboard players set #gp driftmountains 75
scoreboard players set #gdp driftmountains 1
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[-0.0000f,0.0000f,0.0030f,1.0000f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.9675f,0.0657f,0.0470f,-0.2394f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[-0.0725f,-0.2457f,0.9660f,0.0357f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.9150f,0.0120f,-0.0053f,-0.4032f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0053f,-0.4032f,0.9150f,0.0120f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3569f,0.8581f,0.2444f],left_rotation:[0.1547f,-0.1064f,0.5237f,0.8310f]}}
scoreboard players set #gx driftmountains -75888
scoreboard players set #gdx driftmountains 600
scoreboard players set #gy driftmountains 69298
scoreboard players set #gdy driftmountains -9
scoreboard players set #gz driftmountains -28330
scoreboard players set #gdz driftmountains -264
scoreboard players set #gr driftmountains -12890
scoreboard players set #gdr driftmountains 176
scoreboard players set #gp driftmountains 74
scoreboard players set #gdp driftmountains -1
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,0.0000f,0.0094f,0.9999f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.6813f,0.1149f,0.0360f,-0.7221f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[-0.1121f,-0.7298f,0.6729f,-0.0439f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.9150f,0.0120f,-0.0053f,-0.4032f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0053f,-0.4032f,0.9150f,0.0120f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3857f,0.8650f,0.1070f],left_rotation:[0.1076f,-0.1578f,0.8224f,0.5357f]}}
particle minecraft:cloud -77.39 69.62 -28.19 0.35 0.18 0.35 0.02 2 force
particle minecraft:cloud -76.34 69.62 -26.89 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -76.34 69.42 -26.89 -0.034 0.02 0.027 1 0 force
