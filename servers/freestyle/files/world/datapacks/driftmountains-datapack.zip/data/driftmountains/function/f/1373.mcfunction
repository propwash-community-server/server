scoreboard players set #gx driftmountains -7120
scoreboard players set #gdx driftmountains 798
scoreboard players set #gy driftmountains 66963
scoreboard players set #gdy driftmountains -11
scoreboard players set #gz driftmountains -76167
scoreboard players set #gdz driftmountains 525
scoreboard players set #gr driftmountains -4574
scoreboard players set #gdr driftmountains -82
scoreboard players set #gp driftmountains 62
scoreboard players set #gdp driftmountains 1
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0000f,-0.0067f,1.0000f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.5469f,0.1065f,-0.0072f,0.8304f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.0945f,0.8357f,0.5387f,-0.0496f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.9767f,0.0128f,0.0028f,0.2140f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0028f,0.2140f,0.9767f,0.0128f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3807f,0.8213f,0.0898f],left_rotation:[0.1195f,0.1335f,-0.7357f,0.6531f]}}
particle minecraft:cloud -7.44 67.28 -77.64 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -7.44 67.08 -77.64 -0.041 0.02 -0.040 1 0 force
particle minecraft:cloud -8.61 67.28 -76.45 0.35 0.18 0.35 0.02 2 force
scoreboard players set #gx driftmountains -13921
scoreboard players set #gdx driftmountains 743
scoreboard players set #gy driftmountains 67051
scoreboard players set #gdy driftmountains -10
scoreboard players set #gz driftmountains -80100
scoreboard players set #gdz driftmountains 468
scoreboard players set #gr driftmountains -3635
scoreboard players set #gdr driftmountains -106
scoreboard players set #gp driftmountains 62
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0001f,-0.0131f,0.9999f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.1022f,-0.1786f,-0.0723f,-0.9759f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[-0.0299f,-0.9737f,0.1215f,0.1903f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.9767f,0.0128f,0.0028f,0.2140f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0028f,0.2140f,0.9767f,0.0128f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3934f,0.8713f,0.2496f],left_rotation:[-0.0271f,0.1906f,-0.9738f,-0.1210f]}}
particle minecraft:cloud -14.04 67.37 -81.71 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -14.04 67.17 -81.71 -0.033 0.02 -0.044 1 0 force
particle minecraft:cloud -15.42 67.37 -80.69 0.35 0.18 0.35 0.02 2 force
scoreboard players set #gx driftmountains -21527
scoreboard players set #gdx driftmountains 804
scoreboard players set #gy driftmountains 67166
scoreboard players set #gdy driftmountains -12
scoreboard players set #gz driftmountains -85516
scoreboard players set #gdz driftmountains 492
scoreboard players set #gr driftmountains -3031
scoreboard players set #gdr driftmountains 37
scoreboard players set #gp driftmountains 65
scoreboard players set #gdp driftmountains -1
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.5459f,0.2237f,-0.0870f,0.8027f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.1719f,0.8163f,0.5254f,-0.1675f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.9767f,0.0128f,0.0028f,0.2140f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0028f,0.2140f,0.9767f,0.0128f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3857f,0.8650f,0.1070f],left_rotation:[-0.1077f,0.1577f,-0.8223f,-0.5360f]}}
particle minecraft:cloud -21.44 67.49 -87.02 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -21.44 67.29 -87.02 -0.026 0.02 -0.044 1 0 force
particle minecraft:cloud -22.88 67.49 -86.18 0.35 0.18 0.35 0.02 2 force
