scoreboard players set #gx driftmountains -88649
scoreboard players set #gdx driftmountains -730
scoreboard players set #gy driftmountains 69983
scoreboard players set #gdy driftmountains 1
scoreboard players set #gz driftmountains 11554
scoreboard players set #gdz driftmountains -866
scoreboard players set #gr driftmountains 17780
scoreboard players set #gdr driftmountains 76
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains -5
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.4020f,-0.2688f,-0.1875f,-0.8550f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.0987f,-0.8400f,0.4325f,0.3126f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.1063f,0.0014f,0.0130f,0.9943f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0130f,0.9943f,0.1063f,0.0014f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3531f,0.8493f,0.1008f],left_rotation:[-0.1862f,0.0329f,-0.1407f,-0.9718f]}}
particle minecraft:cloud -89.43 70.30 12.85 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -89.43 70.10 12.85 0.003 0.02 0.068 1 0 force
particle minecraft:cloud -87.77 70.30 12.78 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -82490
scoreboard players set #gdx driftmountains -800
scoreboard players set #gy driftmountains 70045
scoreboard players set #gdy driftmountains -15
scoreboard players set #gz driftmountains 18895
scoreboard players set #gdz driftmountains -902
scoreboard players set #gr driftmountains 17388
scoreboard players set #gdr driftmountains 27
scoreboard players set #gp driftmountains 61
scoreboard players set #gdp driftmountains -6
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.9061f,-0.0402f,-0.3022f,-0.2934f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.2730f,-0.2632f,0.9153f,0.1356f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.1063f,0.0014f,0.0130f,0.9943f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0130f,0.9943f,0.1063f,0.0014f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3557f,0.8490f,0.2408f],left_rotation:[-0.1697f,0.0732f,-0.3515f,-0.9178f]}}
particle minecraft:cloud -83.19 70.37 20.34 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -83.19 70.17 20.34 0.008 0.02 0.073 1 0 force
particle minecraft:cloud -81.49 70.37 20.16 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -78262
scoreboard players set #gdx driftmountains -818
scoreboard players set #gy driftmountains 70136
scoreboard players set #gdy driftmountains -20
scoreboard players set #gz driftmountains 23114
scoreboard players set #gdz driftmountains -895
scoreboard players set #gr driftmountains 17678
scoreboard players set #gdr driftmountains -2
scoreboard players set #gp driftmountains 76
scoreboard players set #gdp driftmountains -3
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.5030f,0.3115f,-0.1312f,0.7955f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.2156f,0.8137f,0.4730f,-0.2603f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.1063f,0.0014f,0.0130f,0.9943f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0130f,0.9943f,0.1063f,0.0014f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3523f,0.8448f,0.0991f],left_rotation:[-0.1873f,0.0146f,-0.0431f,-0.9812f]}}
particle minecraft:cloud -79.02 70.46 24.42 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -79.02 70.26 24.42 0.004 0.02 0.074 1 0 force
particle minecraft:cloud -77.36 70.46 24.33 0.35 0.18 0.35 0.02 3 force
