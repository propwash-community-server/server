scoreboard players set #gx driftmountains -91506
scoreboard players set #gdx driftmountains -691
scoreboard players set #gy driftmountains 69992
scoreboard players set #gdy driftmountains 4
scoreboard players set #gz driftmountains 8152
scoreboard players set #gdz driftmountains -823
scoreboard players set #gr driftmountains -17884
scoreboard players set #gdr driftmountains 388
scoreboard players set #gp driftmountains -15
scoreboard players set #gdp driftmountains -1
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.9345f,0.0263f,-0.3459f,-0.0799f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.3394f,-0.0440f,0.9369f,0.0717f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.8136f,0.0107f,-0.0076f,-0.5812f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0076f,-0.5812f,0.8136f,0.0107f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3525f,0.8408f,0.0975f],left_rotation:[-0.1868f,-0.0015f,0.0431f,-0.9814f]}}
particle minecraft:cloud -92.37 70.31 9.39 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -92.37 70.11 9.39 -0.001 0.02 0.065 1 0 force
particle minecraft:cloud -90.70 70.31 9.43 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -85666
scoreboard players set #gdx driftmountains -737
scoreboard players set #gy driftmountains 69997
scoreboard players set #gdy driftmountains -6
scoreboard players set #gz driftmountains 15254
scoreboard players set #gdz driftmountains -859
scoreboard players set #gr driftmountains 17493
scoreboard players set #gdr driftmountains 14
scoreboard players set #gp driftmountains 31
scoreboard players set #gdp driftmountains -9
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.7067f,0.2430f,-0.1874f,0.6375f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.2554f,0.6607f,0.6851f,-0.1700f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.8136f,0.0107f,-0.0076f,-0.5812f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0076f,-0.5812f,0.8136f,0.0107f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3558f,0.8481f,0.2405f],left_rotation:[-0.1708f,0.0698f,-0.3339f,-0.9244f]}}
particle minecraft:cloud -86.40 70.32 16.69 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -86.40 70.12 16.69 0.006 0.02 0.068 1 0 force
particle minecraft:cloud -84.69 70.32 16.54 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -81499
scoreboard players set #gdx driftmountains -814
scoreboard players set #gy driftmountains 70060
scoreboard players set #gdy driftmountains -16
scoreboard players set #gz driftmountains 19558
scoreboard players set #gdz driftmountains -900
scoreboard players set #gr driftmountains 17420
scoreboard players set #gdr driftmountains 1
scoreboard players set #gp driftmountains 64
scoreboard players set #gdp driftmountains -5
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[0.0061f,0.0001f,-0.0222f,0.9997f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.4426f,-0.2477f,-0.1927f,-0.8400f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.1055f,-0.8244f,0.4711f,0.2956f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.8136f,0.0107f,-0.0076f,-0.5812f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0076f,-0.5812f,0.8136f,0.0107f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3555f,0.8551f,0.1031f],left_rotation:[-0.1816f,0.0571f,-0.2709f,-0.9435f]}}
particle minecraft:cloud -82.20 70.38 20.90 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -82.20 70.18 20.90 0.007 0.02 0.071 1 0 force
particle minecraft:cloud -80.54 70.38 20.73 0.35 0.18 0.35 0.02 3 force
