scoreboard players set #gx driftmountains -1773
scoreboard players set #gdx driftmountains 660
scoreboard players set #gy driftmountains 70520
scoreboard players set #gdy driftmountains 4
scoreboard players set #gz driftmountains -24597
scoreboard players set #gdz driftmountains 455
scoreboard players set #gr driftmountains -1042
scoreboard players set #gdr driftmountains 68
scoreboard players set #gp driftmountains -48
scoreboard players set #gdp driftmountains 61
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.7919f,-0.1460f,-0.3516f,-0.4774f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.3034f,-0.4431f,0.8116f,0.2300f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.8637f,0.0113f,0.0066f,0.5039f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0066f,0.5039f,0.8637f,0.0113f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3596f,0.8275f,0.0923f],left_rotation:[-0.1718f,-0.0617f,0.3618f,-0.9141f]}}
particle minecraft:cloud -1.18 70.84 -25.99 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -1.18 70.64 -25.99 -0.009 0.02 -0.047 1 0 force
particle minecraft:cloud -2.82 70.84 -25.69 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -5637
scoreboard players set #gdx driftmountains 764
scoreboard players set #gy driftmountains 70262
scoreboard players set #gdy driftmountains 75
scoreboard players set #gz driftmountains -28041
scoreboard players set #gdz driftmountains 489
scoreboard players set #gr driftmountains -1351
scoreboard players set #gdr driftmountains 292
scoreboard players set #gp driftmountains -349
scoreboard players set #gdp driftmountains 42
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.7320f,-0.1525f,-0.2702f,-0.6066f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.2080f,-0.5815f,0.7520f,0.2303f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.8637f,0.0113f,0.0066f,0.5039f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0066f,0.5039f,0.8637f,0.0113f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3561f,0.8465f,0.2399f],left_rotation:[-0.1726f,0.0638f,-0.3027f,-0.9352f]}}
particle minecraft:cloud -5.12 70.58 -29.57 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -5.12 70.38 -29.57 -0.010 0.02 -0.043 1 0 force
particle minecraft:cloud -6.79 70.58 -29.17 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -10048
scoreboard players set #gdx driftmountains 762
scoreboard players set #gy driftmountains 69856
scoreboard players set #gdy driftmountains 60
scoreboard players set #gz driftmountains -29005
scoreboard players set #gdz driftmountains 148
scoreboard players set #gr driftmountains -3268
scoreboard players set #gdr driftmountains 197
scoreboard players set #gp driftmountains -295
scoreboard players set #gdp driftmountains -14
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.8890f,0.1619f,-0.3097f,0.2958f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.3425f,0.3300f,0.8769f,-0.0693f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.8637f,0.0113f,0.0066f,0.5039f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0066f,0.5039f,0.8637f,0.0113f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3527f,0.8397f,0.0971f],left_rotation:[-0.1864f,-0.0061f,0.0673f,-0.9801f]}}
particle minecraft:cloud -10.02 70.18 -30.52 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -10.02 69.98 -30.52 -0.026 0.02 -0.041 1 0 force
particle minecraft:cloud -11.43 70.18 -29.61 0.35 0.18 0.35 0.02 3 force
