scoreboard players set #gx driftmountains 27474
scoreboard players set #gdx driftmountains 43
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 33376
scoreboard players set #gdz driftmountains 1009
scoreboard players set #gr driftmountains 5055
scoreboard players set #gdr driftmountains 318
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[0.0061f,0.0001f,-0.0223f,0.9997f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.9101f,0.0211f,-0.4058f,-0.0815f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.3995f,-0.0393f,0.9129f,0.0744f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.5875f,0.0077f,-0.0106f,-0.8092f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0106f,-0.8092f,0.5875f,0.0077f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3704f,0.8218f,0.0900f],left_rotation:[-0.1474f,-0.1036f,0.5812f,-0.7935f]}}
particle minecraft:cloud 28.98 71.32 33.22 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 28.98 71.12 33.22 0.047 0.02 -0.039 1 0 force
particle minecraft:cloud 27.92 71.32 31.93 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains 26791
scoreboard players set #gdx driftmountains 329
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 25896
scoreboard players set #gdz driftmountains 970
scoreboard players set #gr driftmountains 2797
scoreboard players set #gdr driftmountains 696
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0001f,-0.0223f,0.9997f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.6988f,0.2678f,-0.2150f,0.6275f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.2821f,0.6535f,0.6745f,-0.1959f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.5875f,0.0077f,-0.0106f,-0.8092f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0106f,-0.8092f,0.5875f,0.0077f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3638f,0.8334f,0.2347f],left_rotation:[-0.1799f,0.0031f,0.0096f,-0.9837f]}}
particle minecraft:cloud 28.19 71.32 25.09 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 28.19 71.12 25.09 0.026 0.02 -0.050 1 0 force
particle minecraft:cloud 26.68 71.32 24.29 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains 23469
scoreboard players set #gdx driftmountains 263
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 21658
scoreboard players set #gdz driftmountains 934
scoreboard players set #gr driftmountains 1842
scoreboard players set #gdr driftmountains 225
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[-0.0004f,-0.0000f,-0.0212f,0.9998f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.4495f,-0.2159f,-0.1759f,-0.8487f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.0877f,-0.8349f,0.4747f,0.2644f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.5875f,0.0077f,-0.0106f,-0.8092f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0106f,-0.8092f,0.5875f,0.0077f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3679f,0.8650f,0.1070f],left_rotation:[-0.1558f,0.1125f,-0.5717f,-0.7976f]}}
particle minecraft:cloud 24.66 71.32 20.73 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 24.66 71.12 20.73 0.020 0.02 -0.059 1 0 force
particle minecraft:cloud 23.07 71.32 20.20 0.35 0.18 0.35 0.02 3 force
