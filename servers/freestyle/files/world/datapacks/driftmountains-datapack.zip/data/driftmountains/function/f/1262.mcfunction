scoreboard players set #gx driftmountains -54156
scoreboard players set #gdx driftmountains -122
scoreboard players set #gy driftmountains 68381
scoreboard players set #gdy driftmountains -16
scoreboard players set #gz driftmountains -54770
scoreboard players set #gdz driftmountains -702
scoreboard players set #gr driftmountains 14222
scoreboard players set #gdr driftmountains 175
scoreboard players set #gp driftmountains 112
scoreboard players set #gdp driftmountains -2
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,0.0001f,0.0172f,0.9998f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.8912f,0.1317f,0.1615f,-0.4029f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[-0.2047f,-0.4221f,0.8823f,-0.0387f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.7452f,0.0098f,0.0087f,0.6667f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0087f,0.6667f,0.7452f,0.0098f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3980f,0.8324f,0.0942f],left_rotation:[-0.0460f,-0.1752f,0.9443f,-0.2744f]}}
particle minecraft:cloud -54.04 68.70 -53.26 0.35 0.18 0.35 0.02 2 force
particle minecraft:cloud -52.72 68.70 -54.29 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -52.72 68.50 -54.29 0.026 0.02 0.034 1 0 force
scoreboard players set #gx driftmountains -54513
scoreboard players set #gdx driftmountains 91
scoreboard players set #gy driftmountains 68545
scoreboard players set #gdy driftmountains -13
scoreboard players set #gz driftmountains -49622
scoreboard players set #gdz driftmountains -434
scoreboard players set #gr driftmountains 15743
scoreboard players set #gdr driftmountains -5
scoreboard players set #gp driftmountains 137
scoreboard players set #gdp driftmountains 1
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[0.0057f,-0.0001f,0.0211f,0.9998f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.4408f,0.2785f,0.0830f,-0.8493f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[-0.1727f,-0.8627f,0.4139f,-0.2337f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.7452f,0.0098f,0.0087f,0.6667f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0087f,0.6667f,0.7452f,0.0098f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3869f,0.8278f,0.2325f],left_rotation:[-0.1557f,-0.0874f,0.4702f,-0.8643f]}}
particle minecraft:cloud -54.78 68.86 -48.03 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud -53.20 68.86 -48.69 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -53.20 68.66 -48.69 0.006 0.02 0.015 1 0 force
scoreboard players set #gx driftmountains -55694
scoreboard players set #gdx driftmountains 194
scoreboard players set #gy driftmountains 68711
scoreboard players set #gdy driftmountains -21
scoreboard players set #gz driftmountains -44097
scoreboard players set #gdz driftmountains -679
scoreboard players set #gr driftmountains 16513
scoreboard players set #gdr driftmountains -155
scoreboard players set #gp driftmountains 144
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,0.0001f,0.0194f,0.9998f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.9492f,0.1017f,0.2051f,-0.2158f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[-0.2289f,-0.2385f,0.9438f,-0.0025f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.7452f,0.0098f,0.0087f,0.6667f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0087f,0.6667f,0.7452f,0.0098f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3917f,0.8257f,0.0916f],left_rotation:[-0.0807f,-0.1605f,0.8726f,-0.4541f]}}
particle minecraft:cloud -56.18 69.03 -42.67 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud -54.56 69.03 -43.09 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -54.56 68.83 -43.09 0.011 0.02 0.041 1 0 force
