scoreboard players set #gx driftmountains -27504
scoreboard players set #gdx driftmountains 673
scoreboard players set #gy driftmountains 67256
scoreboard players set #gdy driftmountains -11
scoreboard players set #gz driftmountains -88429
scoreboard players set #gdz driftmountains 336
scoreboard players set #gr driftmountains -3447
scoreboard players set #gdr driftmountains 24
scoreboard players set #gp driftmountains 73
scoreboard players set #gdp driftmountains -1
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0001f,-0.0179f,0.9998f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.0292f,-0.2366f,-0.0611f,-0.9692f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[-0.0405f,-0.9682f,0.0542f,0.2410f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.6216f,0.0081f,-0.0103f,-0.7832f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0103f,-0.7832f,0.6216f,0.0081f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3837f,0.8656f,0.1072f],left_rotation:[-0.1140f,0.1536f,-0.7991f,-0.5699f]}}
particle minecraft:cloud -27.53 67.58 -89.94 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -27.53 67.38 -89.94 -0.025 0.02 -0.037 1 0 force
particle minecraft:cloud -28.91 67.58 -89.00 0.35 0.18 0.35 0.02 2 force
scoreboard players set #gx driftmountains -33403
scoreboard players set #gdx driftmountains 587
scoreboard players set #gy driftmountains 67360
scoreboard players set #gdy driftmountains -12
scoreboard players set #gz driftmountains -90899
scoreboard players set #gdz driftmountains 216
scoreboard players set #gr driftmountains -3871
scoreboard players set #gdr driftmountains 203
scoreboard players set #gp driftmountains 91
scoreboard players set #gdp driftmountains -1
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0001f,-0.0197f,0.9998f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.8236f,0.1564f,-0.1458f,0.5253f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.2018f,0.5435f,0.8117f,-0.0707f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.6216f,0.0081f,-0.0103f,-0.7832f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0103f,-0.7832f,0.6216f,0.0081f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3837f,0.8742f,0.2507f],left_rotation:[-0.0624f,0.1829f,-0.9291f,-0.3153f]}}
particle minecraft:cloud -33.59 67.68 -92.50 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -33.59 67.48 -92.50 -0.025 0.02 -0.031 1 0 force
particle minecraft:cloud -34.92 67.68 -91.43 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -39242
scoreboard players set #gdx driftmountains 515
scoreboard players set #gy driftmountains 67496
scoreboard players set #gdy driftmountains -14
scoreboard players set #gz driftmountains -92338
scoreboard players set #gdz driftmountains -51
scoreboard players set #gr driftmountains -6201
scoreboard players set #gdr driftmountains 416
scoreboard players set #gp driftmountains 127
scoreboard players set #gdp driftmountains 3
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[-0.0033f,-0.0001f,-0.0219f,0.9998f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.3986f,-0.1245f,-0.1130f,-0.9016f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.0189f,-0.8947f,0.4139f,0.1670f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.6216f,0.0081f,-0.0103f,-0.7832f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0103f,-0.7832f,0.6216f,0.0081f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.4009f,0.8396f,0.0970f],left_rotation:[0.0149f,0.1823f,-0.9766f,0.1125f]}}
particle minecraft:cloud -39.96 67.82 -93.67 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -39.96 67.62 -93.67 -0.029 0.02 -0.015 1 0 force
particle minecraft:cloud -40.75 67.82 -92.19 0.35 0.18 0.35 0.02 3 force
