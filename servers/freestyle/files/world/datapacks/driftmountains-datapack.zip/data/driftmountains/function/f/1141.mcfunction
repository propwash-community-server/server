scoreboard players set #gx driftmountains -93496
scoreboard players set #gdx driftmountains -595
scoreboard players set #gy driftmountains 70004
scoreboard players set #gdy driftmountains 5
scoreboard players set #gz driftmountains 5672
scoreboard players set #gdz driftmountains -842
scoreboard players set #gr driftmountains -16956
scoreboard players set #gdr driftmountains 332
scoreboard players set #gp driftmountains -17
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.5992f,-0.2393f,-0.2745f,-0.7129f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.2011f,-0.6880f,0.6277f,0.3036f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.1716f,0.0022f,-0.0129f,-0.9851f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0129f,-0.9851f,0.1716f,0.0022f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3549f,0.8335f,0.0946f],left_rotation:[-0.1817f,-0.0326f,0.2080f,-0.9605f]}}
particle minecraft:cloud -94.55 70.32 6.76 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -94.55 70.12 6.76 -0.011 0.02 0.061 1 0 force
particle minecraft:cloud -92.90 70.32 7.06 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -87896
scoreboard players set #gdx driftmountains -680
scoreboard players set #gy driftmountains 69984
scoreboard players set #gdy driftmountains -1
scoreboard players set #gz driftmountains 12653
scoreboard players set #gdz driftmountains -794
scoreboard players set #gr driftmountains 17594
scoreboard players set #gdr driftmountains 73
scoreboard players set #gp driftmountains 7
scoreboard players set #gdp driftmountains -6
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[0.0061f,0.0001f,-0.0223f,0.9997f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.9476f,0.0389f,-0.3132f,-0.0493f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.3097f,-0.0167f,0.9487f,0.0605f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.1716f,0.0022f,-0.0129f,-0.9851f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0129f,-0.9851f,0.1716f,0.0022f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3567f,0.8442f,0.2389f],left_rotation:[-0.1750f,0.0544f,-0.2543f,-0.9496f]}}
particle minecraft:cloud -88.65 70.30 14.08 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -88.65 70.10 14.08 0.005 0.02 0.065 1 0 force
particle minecraft:cloud -86.95 70.30 13.95 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -83831
scoreboard players set #gdx driftmountains -740
scoreboard players set #gy driftmountains 70018
scoreboard players set #gdy driftmountains -11
scoreboard players set #gz driftmountains 16967
scoreboard players set #gdz driftmountains -834
scoreboard players set #gr driftmountains 17456
scoreboard players set #gdr driftmountains 18
scoreboard players set #gp driftmountains 47
scoreboard players set #gdp driftmountains -7
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[0.0061f,0.0001f,-0.0221f,0.9997f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.2811f,0.3088f,-0.0381f,0.9078f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.1337f,0.9168f,0.2502f,-0.2809f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.1716f,0.0022f,-0.0129f,-0.9851f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0129f,-0.9851f,0.1716f,0.0022f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3562f,0.8561f,0.1035f],left_rotation:[-0.1804f,0.0617f,-0.2956f,-0.9360f]}}
particle minecraft:cloud -84.54 70.34 18.30 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -84.54 70.14 18.30 0.006 0.02 0.068 1 0 force
particle minecraft:cloud -82.88 70.34 18.14 0.35 0.18 0.35 0.02 3 force
