scoreboard players set #gx driftmountains 25435
scoreboard players set #gdx driftmountains 1071
scoreboard players set #gy driftmountains 66544
scoreboard players set #gdy driftmountains -13
scoreboard players set #gz driftmountains -54799
scoreboard players set #gdz driftmountains 576
scoreboard players set #gr driftmountains -6009
scoreboard players set #gdr driftmountains 47
scoreboard players set #gp driftmountains 63
scoreboard players set #gdp driftmountains 1
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0000f,-0.0009f,1.0000f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.5460f,0.0467f,0.0320f,0.8359f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.0557f,0.8371f,0.5441f,0.0104f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.9542f,0.0125f,0.0039f,0.2990f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0039f,0.2990f,0.9542f,0.0125f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3545f,0.8343f,0.0949f],left_rotation:[0.1825f,0.0292f,-0.1902f,0.9641f]}}
scoreboard players set #gx driftmountains 18056
scoreboard players set #gdx driftmountains 945
scoreboard players set #gy driftmountains 66638
scoreboard players set #gdy driftmountains -12
scoreboard players set #gz driftmountains -59311
scoreboard players set #gdz driftmountains 612
scoreboard players set #gr driftmountains -5925
scoreboard players set #gdr driftmountains 36
scoreboard players set #gp driftmountains 61
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[-0.0039f,0.0000f,0.0013f,1.0000f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.1148f,0.0244f,-0.0499f,-0.9918f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[-0.0541f,-0.9921f,0.1129f,-0.0125f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.9542f,0.0125f,0.0039f,0.2990f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0039f,0.2990f,0.9542f,0.0125f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3583f,0.8402f,0.2374f],left_rotation:[0.1781f,-0.0375f,0.1669f,0.9690f]}}
scoreboard players set #gx driftmountains 8916
scoreboard players set #gdx driftmountains 975
scoreboard players set #gy driftmountains 66756
scoreboard players set #gdy driftmountains -12
scoreboard players set #gz driftmountains -65526
scoreboard players set #gdz driftmountains 644
scoreboard players set #gr driftmountains -5618
scoreboard players set #gdr driftmountains -83
scoreboard players set #gp driftmountains 60
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0000f,-0.0002f,1.0000f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.5167f,0.0296f,0.0432f,0.8546f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.0463f,0.8547f,0.5164f,0.0245f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.9542f,0.0125f,0.0039f,0.2990f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0039f,0.2990f,0.9542f,0.0125f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3524f,0.8417f,0.0978f],left_rotation:[0.1870f,-0.0020f,-0.0245f,0.9820f]}}
