scoreboard players set #gx driftmountains -54830
scoreboard players set #gdx driftmountains 279
scoreboard players set #gy driftmountains 67919
scoreboard players set #gdy driftmountains -13
scoreboard players set #gz driftmountains -76916
scoreboard players set #gdz driftmountains -590
scoreboard players set #gr driftmountains -12306
scoreboard players set #gdr driftmountains 66
scoreboard players set #gp driftmountains 96
scoreboard players set #gdp driftmountains -2
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0001f,-0.0196f,0.9998f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.9580f,0.0886f,-0.2344f,0.1393f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.2503f,0.1647f,0.9540f,0.0116f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.0251f,0.0003f,-0.0131f,-0.9996f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0131f,-0.9996f,0.0251f,0.0003f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3809f,0.8662f,0.1075f],left_rotation:[-0.1226f,0.1473f,-0.7635f,-0.6166f]}}
particle minecraft:cloud -56.34 68.24 -76.93 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -56.34 68.04 -76.93 -0.033 0.02 0.021 1 0 force
particle minecraft:cloud -55.43 68.24 -75.53 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -55881
scoreboard players set #gdx driftmountains 116
scoreboard players set #gy driftmountains 68040
scoreboard players set #gdy driftmountains -19
scoreboard players set #gz driftmountains -72340
scoreboard players set #gdz driftmountains -564
scoreboard players set #gr driftmountains -13500
scoreboard players set #gdr driftmountains 432
scoreboard players set #gp driftmountains 153
scoreboard players set #gdp driftmountains 5
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[-0.0028f,-0.0001f,-0.0219f,0.9998f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.7540f,-0.0821f,-0.1825f,-0.6256f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.1178f,-0.6099f,0.7668f,0.1618f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.0251f,0.0003f,-0.0131f,-0.9996f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0131f,-0.9996f,0.0251f,0.0003f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3901f,0.8727f,0.2501f],left_rotation:[-0.0398f,0.1888f,-0.9625f,-0.1909f]}}
particle minecraft:cloud -57.45 68.36 -71.98 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -57.45 68.16 -71.98 -0.028 0.02 0.028 1 0 force
particle minecraft:cloud -56.24 68.36 -70.77 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -55202
scoreboard players set #gdx driftmountains -57
scoreboard players set #gy driftmountains 68178
scoreboard players set #gdy driftmountains -13
scoreboard players set #gz driftmountains -66468
scoreboard players set #gdz driftmountains -726
scoreboard players set #gr driftmountains -16131
scoreboard players set #gdr driftmountains 264
scoreboard players set #gp driftmountains 92
scoreboard players set #gdp driftmountains 2
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[0.0061f,0.0001f,-0.0143f,0.9999f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.9071f,0.1205f,-0.1527f,0.3734f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.1928f,0.3915f,0.8994f,-0.0258f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.0251f,0.0003f,-0.0131f,-0.9996f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0131f,-0.9996f,0.0251f,0.0003f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.4000f,0.8511f,0.1015f],left_rotation:[-0.0326f,0.1833f,-0.9729f,-0.1370f]}}
particle minecraft:cloud -56.40 68.50 -65.54 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -56.40 68.30 -65.54 -0.014 0.02 0.041 1 0 force
particle minecraft:cloud -54.81 68.50 -65.01 0.35 0.18 0.35 0.02 2 force
