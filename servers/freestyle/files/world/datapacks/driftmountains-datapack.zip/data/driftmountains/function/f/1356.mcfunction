scoreboard players set #gx driftmountains -19903
scoreboard players set #gdx driftmountains 712
scoreboard players set #gy driftmountains 67140
scoreboard players set #gdy driftmountains -10
scoreboard players set #gz driftmountains -84258
scoreboard players set #gdz driftmountains 430
scoreboard players set #gr driftmountains -3103
scoreboard players set #gdr driftmountains 8
scoreboard players set #gp driftmountains 64
scoreboard players set #gdp driftmountains -1
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0001f,-0.0171f,0.9998f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.4568f,0.2315f,-0.0625f,0.8566f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.1528f,0.8679f,0.4350f,-0.1848f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.9064f,0.0119f,0.0055f,0.4223f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0055f,0.4223f,0.9064f,0.0119f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3858f,0.8650f,0.1070f],left_rotation:[-0.1073f,0.1579f,-0.8234f,-0.5343f]}}
particle minecraft:cloud -19.84 67.46 -85.77 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -19.84 67.26 -85.77 -0.026 0.02 -0.043 1 0 force
particle minecraft:cloud -21.27 67.46 -84.91 0.35 0.18 0.35 0.02 2 force
scoreboard players set #gx driftmountains -26273
scoreboard players set #gdx driftmountains 679
scoreboard players set #gy driftmountains 67235
scoreboard players set #gdy driftmountains -11
scoreboard players set #gz driftmountains -87544
scoreboard players set #gdz driftmountains 368
scoreboard players set #gr driftmountains -3280
scoreboard players set #gdr driftmountains 29
scoreboard players set #gp driftmountains 71
scoreboard players set #gdp driftmountains -1
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0001f,-0.0177f,0.9998f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.3468f,0.2403f,-0.0343f,0.9060f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.1297f,0.9146f,0.3234f,-0.2052f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.9064f,0.0119f,0.0055f,0.4223f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0055f,0.4223f,0.9064f,0.0119f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3700f,0.8720f,0.2499f],left_rotation:[-0.1063f,0.1602f,-0.8066f,-0.5590f]}}
particle minecraft:cloud -26.29 67.55 -89.15 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -26.29 67.35 -89.15 -0.025 0.02 -0.040 1 0 force
particle minecraft:cloud -27.73 67.55 -88.23 0.35 0.18 0.35 0.02 2 force
scoreboard players set #gx driftmountains -32896
scoreboard players set #gdx driftmountains 622
scoreboard players set #gy driftmountains 67353
scoreboard players set #gdy driftmountains -12
scoreboard players set #gz driftmountains -91206
scoreboard players set #gdz driftmountains 227
scoreboard players set #gr driftmountains -3874
scoreboard players set #gdr driftmountains 72
scoreboard players set #gp driftmountains 89
scoreboard players set #gdp driftmountains -2
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0001f,-0.0194f,0.9998f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[-0.0027f,-0.2360f,-0.0532f,-0.9703f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[-0.0485f,-0.9700f,0.0221f,0.2371f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.9064f,0.0119f,0.0055f,0.4223f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0055f,0.4223f,0.9064f,0.0119f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3848f,0.8653f,0.1071f],left_rotation:[-0.1105f,0.1559f,-0.8120f,-0.5514f]}}
particle minecraft:cloud -33.03 67.67 -92.71 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -33.03 67.47 -92.71 -0.025 0.02 -0.031 1 0 force
particle minecraft:cloud -34.34 67.67 -91.67 0.35 0.18 0.35 0.02 3 force
