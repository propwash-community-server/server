scoreboard players set #gx driftmountains -97990
scoreboard players set #gdx driftmountains -86
scoreboard players set #gy driftmountains 70026
scoreboard players set #gdy driftmountains -5
scoreboard players set #gz driftmountains -5868
scoreboard players set #gdz driftmountains -883
scoreboard players set #gr driftmountains -13729
scoreboard players set #gdr driftmountains 214
scoreboard players set #gp driftmountains 18
scoreboard players set #gdp driftmountains 7
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.5315f,0.3368f,-0.1669f,0.7591f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.2476f,0.7809f,0.4990f,-0.2828f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.8933f,0.0117f,0.0059f,0.4493f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0059f,0.4493f,0.8933f,0.0117f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3580f,0.8291f,0.0929f],left_rotation:[-0.1752f,-0.0533f,0.3174f,-0.9304f]}}
particle minecraft:cloud -99.46 70.35 -5.51 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -99.46 70.15 -5.51 -0.036 0.02 0.039 1 0 force
particle minecraft:cloud -98.23 70.35 -4.38 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -95874
scoreboard players set #gdx driftmountains -399
scoreboard players set #gy driftmountains 70023
scoreboard players set #gdy driftmountains 3
scoreboard players set #gz driftmountains 2055
scoreboard players set #gdz driftmountains -860
scoreboard players set #gr driftmountains -15629
scoreboard players set #gdr driftmountains 290
scoreboard players set #gp driftmountains -14
scoreboard players set #gdp driftmountains 2
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.1905f,-0.3455f,-0.1298f,-0.9097f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.0349f,-0.9010f,0.2278f,0.3674f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.8933f,0.0117f,0.0059f,0.4493f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0059f,0.4493f,0.8933f,0.0117f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3749f,0.8278f,0.2325f],left_rotation:[-0.1726f,-0.0448f,0.2542f,-0.9506f]}}
particle minecraft:cloud -97.21 70.34 2.96 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -97.21 70.14 2.96 -0.023 0.02 0.052 1 0 force
particle minecraft:cloud -95.64 70.34 3.65 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -92842
scoreboard players set #gdx driftmountains -625
scoreboard players set #gy driftmountains 69999
scoreboard players set #gdy driftmountains 4
scoreboard players set #gz driftmountains 6677
scoreboard players set #gdz driftmountains -790
scoreboard players set #gr driftmountains -17264
scoreboard players set #gdr driftmountains 251
scoreboard players set #gp driftmountains -16
scoreboard players set #gdp driftmountains -1
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.9293f,0.0409f,-0.3649f,-0.0391f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.3628f,-0.0010f,0.9301f,0.0566f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.8933f,0.0117f,0.0059f,0.4493f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0059f,0.4493f,0.8933f,0.0117f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3556f,0.8323f,0.0942f],left_rotation:[-0.1802f,-0.0380f,0.2368f,-0.9539f]}}
particle minecraft:cloud -93.83 70.32 7.82 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -93.83 70.12 7.82 -0.007 0.02 0.058 1 0 force
particle minecraft:cloud -92.18 70.32 8.03 0.35 0.18 0.35 0.02 3 force
