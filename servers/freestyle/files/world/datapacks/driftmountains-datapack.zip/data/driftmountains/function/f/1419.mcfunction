scoreboard players set #gx driftmountains 36256
scoreboard players set #gdx driftmountains 1098
scoreboard players set #gy driftmountains 66409
scoreboard players set #gdy driftmountains -13
scoreboard players set #gz driftmountains -48570
scoreboard players set #gdz driftmountains 674
scoreboard players set #gr driftmountains -5624
scoreboard players set #gdr driftmountains 240
scoreboard players set #gp driftmountains 58
scoreboard players set #gdp driftmountains -1
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0000f,-0.0014f,1.0000f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.8907f,0.0535f,0.0102f,0.4512f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.0372f,0.4527f,0.8900f,0.0398f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.9809f,0.0128f,-0.0025f,-0.1942f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0025f,-0.1942f,0.9809f,0.0128f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3535f,0.8368f,0.0959f],left_rotation:[0.1847f,0.0183f,-0.1323f,0.9736f]}}
scoreboard players set #gx driftmountains 28238
scoreboard players set #gdx driftmountains 1011
scoreboard players set #gy driftmountains 66502
scoreboard players set #gdy driftmountains -14
scoreboard players set #gz driftmountains -52280
scoreboard players set #gdz driftmountains 725
scoreboard players set #gr driftmountains -5165
scoreboard players set #gdr driftmountains -90
scoreboard players set #gp driftmountains 64
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0000f,-0.0014f,1.0000f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.3987f,0.0472f,0.0365f,0.9151f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.0594f,0.9163f,0.3959f,-0.0056f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.9809f,0.0128f,-0.0025f,-0.1942f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0025f,-0.1942f,0.9809f,0.0128f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3748f,0.8279f,0.2326f],left_rotation:[0.1727f,0.0443f,-0.2517f,0.9513f]}}
scoreboard players set #gx driftmountains 18959
scoreboard players set #gdx driftmountains 983
scoreboard players set #gy driftmountains 66629
scoreboard players set #gdy driftmountains -13
scoreboard players set #gz driftmountains -58988
scoreboard players set #gdz driftmountains 623
scoreboard players set #gr driftmountains -5971
scoreboard players set #gdr driftmountains 55
scoreboard players set #gp driftmountains 61
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,0.0000f,0.0012f,1.0000f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.8740f,0.0363f,0.0426f,0.4827f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.0079f,0.4809f,0.8750f,0.0554f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.9809f,0.0128f,-0.0025f,-0.1942f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0025f,-0.1942f,0.9809f,0.0128f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3536f,0.8510f,0.1015f],left_rotation:[0.1852f,-0.0398f,0.1781f,0.9656f]}}
