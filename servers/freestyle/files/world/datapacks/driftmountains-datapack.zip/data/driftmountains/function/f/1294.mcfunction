scoreboard players set #gx driftmountains -55095
scoreboard players set #gdx driftmountains 266
scoreboard players set #gy driftmountains 67932
scoreboard players set #gdy driftmountains -13
scoreboard players set #gz driftmountains -76327
scoreboard players set #gdz driftmountains -588
scoreboard players set #gr driftmountains -12369
scoreboard players set #gdr driftmountains 64
scoreboard players set #gp driftmountains 98
scoreboard players set #gdp driftmountains -2
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0001f,-0.0198f,0.9998f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.4217f,0.2449f,-0.0586f,0.8711f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.1504f,0.8820f,0.3983f,-0.2019f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.9715f,0.0127f,-0.0031f,-0.2368f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0031f,-0.2368f,0.9715f,0.0127f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3803f,0.8663f,0.1075f],left_rotation:[-0.1243f,0.1459f,-0.7561f,-0.6257f]}}
particle minecraft:cloud -56.61 68.25 -76.32 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -56.61 68.05 -76.32 -0.032 0.02 0.021 1 0 force
particle minecraft:cloud -55.68 68.25 -74.93 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -55960
scoreboard players set #gdx driftmountains 79
scoreboard players set #gy driftmountains 68061
scoreboard players set #gdy driftmountains -22
scoreboard players set #gz driftmountains -71690
scoreboard players set #gdz driftmountains -650
scoreboard players set #gr driftmountains -13937
scoreboard players set #gdr driftmountains 437
scoreboard players set #gp driftmountains 148
scoreboard players set #gdp driftmountains 5
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[0.0037f,0.0001f,-0.0219f,0.9998f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.9359f,0.1084f,-0.1705f,0.2884f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.2018f,0.3079f,0.9297f,-0.0106f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.9715f,0.0127f,-0.0031f,-0.2368f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0031f,-0.2368f,0.9715f,0.0127f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3893f,0.8730f,0.2503f],left_rotation:[-0.0430f,0.1882f,-0.9588f,-0.2085f]}}
particle minecraft:cloud -57.50 68.38 -71.21 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -57.50 68.18 -71.21 -0.023 0.02 0.026 1 0 force
particle minecraft:cloud -56.20 68.38 -70.10 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -55139
scoreboard players set #gdx driftmountains -63
scoreboard players set #gy driftmountains 68191
scoreboard players set #gdy driftmountains -13
scoreboard players set #gz driftmountains -65739
scoreboard players set #gdz driftmountains -729
scoreboard players set #gr driftmountains -16353
scoreboard players set #gdr driftmountains 222
scoreboard players set #gp driftmountains 91
scoreboard players set #gdp driftmountains 1
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[0.0061f,0.0001f,-0.0131f,0.9999f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.0837f,0.1770f,0.0382f,0.9799f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.0646f,0.9813f,0.0655f,-0.1692f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.9715f,0.0127f,-0.0031f,-0.2368f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0031f,-0.2368f,0.9715f,0.0127f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.4012f,0.8453f,0.0993f],left_rotation:[-0.0086f,0.1843f,-0.9827f,-0.0109f]}}
particle minecraft:cloud -56.30 68.51 -64.77 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -56.30 68.31 -64.77 -0.013 0.02 0.042 1 0 force
particle minecraft:cloud -54.70 68.51 -64.29 0.35 0.18 0.35 0.02 2 force
