scoreboard players set #gx driftmountains 53144
scoreboard players set #gdx driftmountains 1142
scoreboard players set #gy driftmountains 66220
scoreboard players set #gdy driftmountains -12
scoreboard players set #gz driftmountains -37698
scoreboard players set #gdz driftmountains 805
scoreboard players set #gr driftmountains -4399
scoreboard players set #gdr driftmountains -471
scoreboard players set #gp driftmountains 50
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0000f,-0.0067f,1.0000f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.9440f,0.0216f,-0.1017f,-0.3133f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.0693f,-0.3043f,0.9469f,0.0775f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.5863f,0.0077f,-0.0106f,-0.8100f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0106f,-0.8100f,0.5863f,0.0077f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3793f,0.8211f,0.0898f],left_rotation:[0.1238f,0.1297f,-0.7162f,0.6744f]}}
particle minecraft:cloud 52.87 66.54 -39.18 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke 52.87 66.34 -39.18 -0.058 0.02 -0.060 1 0 force
particle minecraft:cloud 51.67 66.54 -38.02 0.35 0.18 0.35 0.02 2 force
scoreboard players set #gx driftmountains 44699
scoreboard players set #gdx driftmountains 1183
scoreboard players set #gy driftmountains 66300
scoreboard players set #gdy driftmountains -13
scoreboard players set #gz driftmountains -41068
scoreboard players set #gdz driftmountains 716
scoreboard players set #gr driftmountains -3639
scoreboard players set #gdr driftmountains 25
scoreboard players set #gp driftmountains 49
scoreboard players set #gdp driftmountains -1
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0001f,-0.0136f,0.9999f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.9140f,0.1210f,-0.1667f,0.3496f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.2044f,0.3691f,0.9063f,-0.0256f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.5863f,0.0077f,-0.0106f,-0.8100f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0106f,-0.8100f,0.5863f,0.0077f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3874f,0.8735f,0.2505f],left_rotation:[-0.0495f,0.1867f,-0.9503f,-0.2444f]}}
particle minecraft:cloud 44.58 66.62 -42.67 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke 44.58 66.42 -42.67 -0.050 0.02 -0.067 1 0 force
particle minecraft:cloud 43.20 66.62 -41.66 0.35 0.18 0.35 0.02 2 force
scoreboard players set #gx driftmountains 34928
scoreboard players set #gdx driftmountains 1038
scoreboard players set #gy driftmountains 66422
scoreboard players set #gdy driftmountains -14
scoreboard players set #gz driftmountains -48848
scoreboard players set #gdz driftmountains 818
scoreboard players set #gr driftmountains -5107
scoreboard players set #gdr driftmountains 193
scoreboard players set #gp driftmountains 59
scoreboard players set #gdp driftmountains -1
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0000f,-0.0006f,1.0000f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.9592f,0.0504f,-0.0140f,-0.2777f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[-0.0151f,-0.2778f,0.9592f,0.0501f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.5863f,0.0077f,-0.0106f,-0.8100f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0106f,-0.8100f,0.5863f,0.0077f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3523f,0.8432f,0.0984f],left_rotation:[0.1873f,-0.0079f,0.0073f,0.9822f]}}
