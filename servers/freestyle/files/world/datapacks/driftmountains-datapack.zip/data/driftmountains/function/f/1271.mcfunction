scoreboard players set #gx driftmountains -55436
scoreboard players set #gdx driftmountains -138
scoreboard players set #gy driftmountains 68256
scoreboard players set #gdy driftmountains -13
scoreboard players set #gz driftmountains -61316
scoreboard players set #gdz driftmountains -765
scoreboard players set #gr driftmountains 17376
scoreboard players set #gdr driftmountains 428
scoreboard players set #gp driftmountains 95
scoreboard players set #gdp driftmountains -2
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0000f,-0.0025f,1.0000f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.4709f,0.0024f,-0.0581f,-0.8803f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[-0.0341f,-0.8790f,0.4732f,0.0471f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.0335f,0.0004f,0.0131f,0.9994f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0131f,0.9994f,0.0335f,0.0004f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3553f,0.8329f,0.0944f],left_rotation:[0.1810f,0.0352f,-0.2222f,0.9574f]}}
scoreboard players set #gx driftmountains -54068
scoreboard players set #gdx driftmountains -82
scoreboard players set #gy driftmountains 68368
scoreboard players set #gdy driftmountains -14
scoreboard players set #gz driftmountains -55443
scoreboard players set #gdz driftmountains -670
scoreboard players set #gr driftmountains 14564
scoreboard players set #gdr driftmountains 176
scoreboard players set #gp driftmountains 106
scoreboard players set #gdp driftmountains -3
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[-0.0039f,0.0001f,0.0171f,0.9998f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.9517f,0.0980f,0.1787f,-0.2296f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[-0.2038f,-0.2496f,0.9466f,0.0015f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.0335f,0.0004f,0.0131f,0.9994f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0131f,0.9994f,0.0335f,0.0004f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.4049f,0.8584f,0.2445f],left_rotation:[-0.0378f,-0.1850f,0.9540f,-0.2330f]}}
particle minecraft:cloud -54.00 68.69 -53.83 0.35 0.18 0.35 0.02 2 force
particle minecraft:cloud -52.59 68.69 -54.80 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -52.59 68.49 -54.80 0.023 0.02 0.033 1 0 force
scoreboard players set #gx driftmountains -54360
scoreboard players set #gdx driftmountains 77
scoreboard players set #gy driftmountains 68531
scoreboard players set #gdy driftmountains -12
scoreboard players set #gz driftmountains -50077
scoreboard players set #gdz driftmountains -374
scoreboard players set #gr driftmountains 15989
scoreboard players set #gdr driftmountains 57
scoreboard players set #gp driftmountains 145
scoreboard players set #gdp driftmountains 12
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.9655f,0.0577f,0.2536f,-0.0137f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[-0.2565f,-0.0404f,0.9647f,0.0434f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.0335f,0.0004f,0.0131f,0.9994f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0131f,0.9994f,0.0335f,0.0004f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3782f,0.8210f,0.0897f],left_rotation:[-0.1270f,-0.1267f,0.7003f,-0.6909f]}}
particle minecraft:cloud -54.71 68.85 -48.61 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud -53.14 68.85 -49.18 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -53.14 68.65 -49.18 0.012 0.02 0.032 1 0 force
