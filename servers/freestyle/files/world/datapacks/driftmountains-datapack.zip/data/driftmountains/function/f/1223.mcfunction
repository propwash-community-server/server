scoreboard players set #gx driftmountains -63749
scoreboard players set #gdx driftmountains 589
scoreboard players set #gy driftmountains 69116
scoreboard players set #gdy driftmountains -12
scoreboard players set #gz driftmountains -32831
scoreboard players set #gdz driftmountains -243
scoreboard players set #gr driftmountains -13938
scoreboard players set #gdr driftmountains -356
scoreboard players set #gp driftmountains 91
scoreboard players set #gdp driftmountains 3
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[0.0061f,-0.0001f,0.0168f,0.9998f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.8712f,-0.0403f,0.1946f,0.4488f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[-0.1485f,0.4309f,0.8803f,0.1320f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.1502f,0.0020f,0.0129f,0.9886f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0129f,0.9886f,0.1502f,0.0020f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3999f,0.8363f,0.0957f],left_rotation:[-0.0290f,-0.1798f,0.9655f,-0.1858f]}}
particle minecraft:cloud -65.20 69.44 -32.42 0.35 0.18 0.35 0.02 2 force
particle minecraft:cloud -63.94 69.44 -31.33 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -63.94 69.24 -31.33 -0.025 0.02 0.029 1 0 force
scoreboard players set #gx driftmountains -70023
scoreboard players set #gdx driftmountains 693
scoreboard players set #gy driftmountains 69214
scoreboard players set #gdy driftmountains -10
scoreboard players set #gz driftmountains -32199
scoreboard players set #gdz driftmountains -281
scoreboard players set #gr driftmountains -11795
scoreboard players set #gdr driftmountains -7
scoreboard players set #gp driftmountains 76
scoreboard players set #gdp driftmountains 1
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[0.0061f,-0.0000f,0.0034f,1.0000f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.1761f,0.0730f,-0.0402f,-0.9808f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[-0.0627f,-0.9820f,0.1694f,-0.0549f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.1502f,0.0020f,0.0129f,0.9886f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0129f,0.9886f,0.1502f,0.0020f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3574f,0.8595f,0.2449f],left_rotation:[0.1518f,-0.1111f,0.5483f,0.8148f]}}
scoreboard players set #gx driftmountains -75288
scoreboard players set #gdx driftmountains 779
scoreboard players set #gy driftmountains 69289
scoreboard players set #gdy driftmountains -11
scoreboard players set #gz driftmountains -28594
scoreboard players set #gdz driftmountains -355
scoreboard players set #gr driftmountains -12714
scoreboard players set #gdr driftmountains 199
scoreboard players set #gp driftmountains 73
scoreboard players set #gdp driftmountains -1
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,0.0000f,0.0080f,1.0000f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.3419f,-0.0722f,0.0825f,0.9333f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.0152f,0.9298f,0.3514f,0.1085f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.1502f,0.0020f,0.0129f,0.9886f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0129f,0.9886f,0.1502f,0.0020f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3804f,0.8663f,0.1075f],left_rotation:[0.1239f,-0.1462f,0.7578f,0.6236f]}}
particle minecraft:cloud -76.80 69.61 -28.50 0.35 0.18 0.35 0.02 2 force
particle minecraft:cloud -75.79 69.61 -27.17 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -75.79 69.41 -27.17 -0.035 0.02 0.027 1 0 force
