scoreboard players set #gx driftmountains 13025
scoreboard players set #gdx driftmountains 447
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains -3379
scoreboard players set #gdz driftmountains 908
scoreboard players set #gr driftmountains 1171
scoreboard players set #gdr driftmountains 25
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.9035f,-0.0420f,-0.3198f,-0.2821f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.2920f,-0.2500f,0.9129f,0.1372f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.9436f,0.0124f,0.0043f,0.3308f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0043f,0.3308f,0.9436f,0.0124f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3538f,0.8515f,0.1017f],left_rotation:[-0.1849f,0.0420f,-0.1897f,-0.9633f]}}
particle minecraft:cloud 14.10 71.32 -4.44 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 14.10 71.12 -4.44 0.012 0.02 -0.059 1 0 force
particle minecraft:cloud 12.46 71.32 -4.78 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains 9927
scoreboard players set #gdx driftmountains 434
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains -9068
scoreboard players set #gdz driftmountains 835
scoreboard players set #gr driftmountains 1022
scoreboard players set #gdr driftmountains 21
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.8651f,0.1795f,-0.2682f,0.3841f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.3101f,0.4144f,0.8510f,-0.0896f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.9436f,0.0124f,0.0043f,0.3308f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0043f,0.3308f,0.9436f,0.0124f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3579f,0.8411f,0.2377f],left_rotation:[-0.1775f,0.0416f,-0.1879f,-0.9651f]}}
particle minecraft:cloud 11.01 71.32 -10.26 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 11.01 71.12 -10.26 0.011 0.02 -0.058 1 0 force
particle minecraft:cloud 9.33 71.32 -10.56 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains 7209
scoreboard players set #gdx driftmountains 442
scoreboard players set #gy driftmountains 70990
scoreboard players set #gdy driftmountains 9
scoreboard players set #gz driftmountains -14125
scoreboard players set #gdz driftmountains 803
scoreboard players set #gr driftmountains 1043
scoreboard players set #gdr driftmountains -66
scoreboard players set #gp driftmountains -103
scoreboard players set #gdp driftmountains 82
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.8422f,-0.0989f,-0.3223f,-0.4207f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.2799f,-0.3891f,0.8573f,0.1880f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.9436f,0.0124f,0.0043f,0.3308f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0043f,0.3308f,0.9436f,0.0124f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3524f,0.8452f,0.0992f],left_rotation:[-0.1873f,0.0161f,-0.0508f,-0.9808f]}}
particle minecraft:cloud 8.26 71.31 -15.21 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 8.26 71.11 -15.21 0.010 0.02 -0.054 1 0 force
particle minecraft:cloud 6.62 71.31 -15.52 0.35 0.18 0.35 0.02 3 force
