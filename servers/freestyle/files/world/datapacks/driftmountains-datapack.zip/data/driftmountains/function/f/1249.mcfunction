scoreboard players set #gx driftmountains -54625
scoreboard players set #gdx driftmountains 115
scoreboard players set #gy driftmountains 68664
scoreboard players set #gdy driftmountains -20
scoreboard players set #gz driftmountains -45460
scoreboard players set #gdz driftmountains -701
scoreboard players set #gr driftmountains 15826
scoreboard players set #gdr driftmountains -128
scoreboard players set #gp driftmountains 139
scoreboard players set #gdp driftmountains -1
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,0.0001f,0.0193f,0.9998f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.4570f,-0.1770f,0.1552f,0.8577f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[-0.0660f,0.8461f,0.4782f,0.2260f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.4226f,0.0055f,-0.0119f,-0.9062f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0119f,-0.9062f,0.4226f,0.0055f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3892f,0.8241f,0.0909f],left_rotation:[-0.0911f,-0.1546f,0.8427f,-0.5075f]}}
particle minecraft:cloud -54.93 68.98 -43.98 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud -53.38 68.98 -44.60 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -53.38 68.78 -44.60 0.016 0.02 0.039 1 0 force
scoreboard players set #gx driftmountains -57062
scoreboard players set #gdx driftmountains 291
scoreboard players set #gy driftmountains 68798
scoreboard players set #gdy driftmountains -19
scoreboard players set #gz driftmountains -41533
scoreboard players set #gdz driftmountains -558
scoreboard players set #gr driftmountains 17350
scoreboard players set #gdr driftmountains -198
scoreboard players set #gp driftmountains 144
scoreboard players set #gdp driftmountains -1
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.6761f,0.1996f,0.1182f,-0.6994f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[-0.1924f,-0.7157f,0.6588f,-0.1297f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.4226f,0.0055f,-0.0119f,-0.9062f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0119f,-0.9062f,0.4226f,0.0055f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.4057f,0.8459f,0.2396f],left_rotation:[-0.0834f,-0.1650f,0.8578f,-0.4796f]}}
particle minecraft:cloud -57.76 69.12 -40.08 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud -56.06 69.12 -40.27 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -56.06 68.92 -40.27 0.004 0.02 0.038 1 0 force
scoreboard players set #gx driftmountains -59837
scoreboard players set #gdx driftmountains 382
scoreboard players set #gy driftmountains 68976
scoreboard players set #gdy driftmountains -21
scoreboard players set #gz driftmountains -36570
scoreboard players set #gdz driftmountains -507
scoreboard players set #gr driftmountains -17687
scoreboard players set #gdr driftmountains -73
scoreboard players set #gp driftmountains 155
scoreboard players set #gdp driftmountains -4
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.9367f,-0.0084f,0.2227f,0.2702f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[-0.1955f,0.2482f,0.9427f,0.1069f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.4226f,0.0055f,-0.0119f,-0.9062f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0119f,-0.9062f,0.4226f,0.0055f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3939f,0.8274f,0.0922f],left_rotation:[-0.0707f,-0.1655f,0.8974f,-0.4026f]}}
particle minecraft:cloud -60.74 69.30 -35.36 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud -59.07 69.30 -35.27 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -59.07 69.10 -35.27 -0.002 0.02 0.038 1 0 force
