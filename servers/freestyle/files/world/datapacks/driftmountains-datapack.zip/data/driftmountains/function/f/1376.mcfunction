scoreboard players set #gx driftmountains -4710
scoreboard players set #gdx driftmountains 814
scoreboard players set #gy driftmountains 66931
scoreboard players set #gdy driftmountains -11
scoreboard players set #gz driftmountains -74578
scoreboard players set #gdz driftmountains 540
scoreboard players set #gr driftmountains -4802
scoreboard players set #gdr driftmountains -54
scoreboard players set #gp driftmountains 62
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0000f,-0.0052f,1.0000f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.9754f,0.0659f,-0.0595f,0.2019f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.0810f,0.2093f,0.9738f,0.0363f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.8459f,0.0111f,-0.0070f,-0.5331f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0070f,-0.5331f,0.8459f,0.0111f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3712f,0.8216f,0.0899f],left_rotation:[0.1453f,0.1064f,-0.5953f,0.7830f]}}
scoreboard players set #gx driftmountains -11550
scoreboard players set #gdx driftmountains 739
scoreboard players set #gy driftmountains 67019
scoreboard players set #gdy driftmountains -10
scoreboard players set #gz driftmountains -78606
scoreboard players set #gdz driftmountains 466
scoreboard players set #gr driftmountains -3996
scoreboard players set #gdr driftmountains -125
scoreboard players set #gp driftmountains 62
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0000f,-0.0109f,0.9999f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.6199f,0.1530f,-0.0554f,0.7676f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.1364f,0.7777f,0.6072f,-0.0887f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.8459f,0.0111f,-0.0070f,-0.5331f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0070f,-0.5331f,0.8459f,0.0111f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.4035f,0.8616f,0.2458f],left_rotation:[0.0249f,0.1881f,-0.9682f,0.1631f]}}
particle minecraft:cloud -11.77 67.34 -80.20 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -11.77 67.14 -80.20 -0.036 0.02 -0.043 1 0 force
particle minecraft:cloud -13.08 67.34 -79.10 0.35 0.18 0.35 0.02 2 force
scoreboard players set #gx driftmountains -19271
scoreboard players set #gdx driftmountains 741
scoreboard players set #gy driftmountains 67132
scoreboard players set #gdy driftmountains -11
scoreboard players set #gz driftmountains -84115
scoreboard players set #gdz driftmountains 471
scoreboard players set #gr driftmountains -2962
scoreboard players set #gdr driftmountains -14
scoreboard players set #gp driftmountains 63
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0001f,-0.0171f,0.9998f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.9453f,0.1057f,-0.2162f,0.2204f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.2405f,0.2443f,0.9394f,-0.0069f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.8459f,0.0111f,-0.0070f,-0.5331f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0070f,-0.5331f,0.8459f,0.0111f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3854f,0.8651f,0.1070f],left_rotation:[-0.1085f,0.1572f,-0.8192f,-0.5407f]}}
particle minecraft:cloud -19.17 67.45 -85.62 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -19.17 67.25 -85.62 -0.026 0.02 -0.045 1 0 force
particle minecraft:cloud -20.62 67.45 -84.80 0.35 0.18 0.35 0.02 2 force
