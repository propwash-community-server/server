scoreboard players set #gx driftmountains 4537
scoreboard players set #gdx driftmountains 874
scoreboard players set #gy driftmountains 66811
scoreboard players set #gdy driftmountains -11
scoreboard players set #gz driftmountains -68359
scoreboard players set #gdz driftmountains 594
scoreboard players set #gr driftmountains -5166
scoreboard players set #gdr driftmountains -73
scoreboard players set #gp driftmountains 61
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0000f,-0.0025f,1.0000f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.0556f,0.0384f,0.0503f,0.9964f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.0541f,0.9966f,0.0519f,-0.0328f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.7154f,0.0094f,0.0091f,0.6986f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0091f,0.6986f,0.7154f,0.0094f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3578f,0.8294f,0.0930f],left_rotation:[0.1757f,0.0520f,-0.3106f,0.9327f]}}
scoreboard players set #gx driftmountains -2401
scoreboard players set #gdx driftmountains 834
scoreboard players set #gy driftmountains 66899
scoreboard players set #gdy driftmountains -11
scoreboard players set #gz driftmountains -72793
scoreboard players set #gdz driftmountains 536
scoreboard players set #gr driftmountains -5075
scoreboard players set #gdr driftmountains -38
scoreboard players set #gp driftmountains 62
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0000f,-0.0040f,1.0000f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.5914f,-0.0138f,-0.0753f,-0.8028f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[-0.0087f,-0.7993f,0.5961f,0.0760f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.7154f,0.0094f,0.0091f,0.6986f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0091f,0.6986f,0.7154f,0.0094f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3872f,0.8279f,0.2326f],left_rotation:[0.1551f,0.0885f,-0.4761f,0.8611f]}}
scoreboard players set #gx driftmountains -10728
scoreboard players set #gdx driftmountains 726
scoreboard players set #gy driftmountains 67011
scoreboard players set #gdy driftmountains -10
scoreboard players set #gz driftmountains -78539
scoreboard players set #gdz driftmountains 480
scoreboard players set #gr driftmountains -3935
scoreboard players set #gdr driftmountains -138
scoreboard players set #gp driftmountains 62
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0000f,-0.0105f,0.9999f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.0276f,0.1495f,0.0488f,0.9872f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.0547f,0.9875f,0.0120f,-0.1475f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.7154f,0.0094f,0.0091f,0.6986f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0091f,0.6986f,0.7154f,0.0094f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3994f,0.8350f,0.0952f],left_rotation:[0.0344f,0.1785f,-0.9596f,0.2144f]}}
particle minecraft:cloud -10.88 67.33 -80.04 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -10.88 67.13 -80.04 -0.037 0.02 -0.046 1 0 force
particle minecraft:cloud -12.17 67.33 -78.98 0.35 0.18 0.35 0.02 2 force
