scoreboard players set #gx driftmountains 50863
scoreboard players set #gdx driftmountains 1140
scoreboard players set #gy driftmountains 66245
scoreboard players set #gdy driftmountains -12
scoreboard players set #gz driftmountains -39274
scoreboard players set #gdz driftmountains 782
scoreboard players set #gr driftmountains -3608
scoreboard players set #gdr driftmountains -358
scoreboard players set #gp driftmountains 49
scoreboard players set #gdp driftmountains 1
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0000f,-0.0120f,0.9999f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.6515f,-0.0879f,-0.1483f,-0.7388f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.0715f,-0.7272f,0.6644f,0.1569f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.0979f,0.0013f,-0.0130f,-0.9951f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0130f,-0.9951f,0.0979f,0.0013f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.4012f,0.8415f,0.0978f],left_rotation:[0.0071f,0.1833f,-0.9804f,0.0716f]}}
particle minecraft:cloud 50.80 66.56 -40.78 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke 50.80 66.36 -40.78 -0.049 0.02 -0.067 1 0 force
particle minecraft:cloud 49.45 66.56 -39.80 0.35 0.18 0.35 0.02 2 force
scoreboard players set #gx driftmountains 42354
scoreboard players set #gdx driftmountains 1082
scoreboard players set #gy driftmountains 66326
scoreboard players set #gdy driftmountains -12
scoreboard players set #gz driftmountains -42527
scoreboard players set #gdz driftmountains 679
scoreboard players set #gr driftmountains -3880
scoreboard players set #gdr driftmountains 127
scoreboard players set #gp driftmountains 51
scoreboard players set #gdp driftmountains -1
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0000f,-0.0115f,0.9999f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.9717f,0.0257f,-0.1777f,-0.1535f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.1626f,-0.1357f,0.9743f,0.0763f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.0979f,0.0013f,-0.0130f,-0.9951f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0130f,-0.9951f,0.0979f,0.0013f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3985f,0.8677f,0.2482f],left_rotation:[-0.0044f,0.1915f,-0.9815f,0.0030f]}}
particle minecraft:cloud 42.16 66.65 -44.13 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke 42.16 66.45 -44.13 -0.052 0.02 -0.064 1 0 force
particle minecraft:cloud 40.83 66.65 -43.06 0.35 0.18 0.35 0.02 2 force
scoreboard players set #gx driftmountains 32843
scoreboard players set #gdx driftmountains 1039
scoreboard players set #gy driftmountains 66449
scoreboard players set #gdy driftmountains -14
scoreboard players set #gz driftmountains -50443
scoreboard players set #gdz driftmountains 784
scoreboard players set #gr driftmountains -5237
scoreboard players set #gdr driftmountains 29
scoreboard players set #gp driftmountains 61
scoreboard players set #gdp driftmountains -1
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0000f,-0.0006f,1.0000f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.6919f,0.0370f,-0.0371f,-0.7201f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[-0.0384f,-0.7202f,0.6918f,0.0355f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.0979f,0.0013f,-0.0130f,-0.9951f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0130f,-0.9951f,0.0979f,0.0013f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3523f,0.8434f,0.0985f],left_rotation:[0.1873f,-0.0087f,0.0112f,0.9822f]}}
