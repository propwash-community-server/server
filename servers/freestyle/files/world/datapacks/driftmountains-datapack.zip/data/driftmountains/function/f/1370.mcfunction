scoreboard players set #gx driftmountains -9484
scoreboard players set #gdx driftmountains 783
scoreboard players set #gy driftmountains 66994
scoreboard players set #gdy driftmountains -10
scoreboard players set #gz driftmountains -77709
scoreboard players set #gdz driftmountains 508
scoreboard players set #gr driftmountains -4245
scoreboard players set #gdr driftmountains -117
scoreboard players set #gp driftmountains 63
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0000f,-0.0090f,1.0000f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.1981f,-0.1111f,-0.0765f,-0.9708f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[-0.0251f,-0.9682f,0.2109f,0.1325f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.5455f,0.0071f,0.0110f,0.8380f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0110f,0.8380f,0.5455f,0.0071f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3932f,0.8269f,0.0920f],left_rotation:[0.0739f,0.1640f,-0.8899f,0.4190f]}}
particle minecraft:cloud -9.72 67.31 -79.20 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -9.72 67.11 -79.20 -0.038 0.02 -0.041 1 0 force
particle minecraft:cloud -10.95 67.31 -78.08 0.35 0.18 0.35 0.02 2 force
scoreboard players set #gx driftmountains -16226
scoreboard players set #gdx driftmountains 761
scoreboard players set #gy driftmountains 67084
scoreboard players set #gdy driftmountains -11
scoreboard players set #gz driftmountains -81551
scoreboard players set #gdz driftmountains 479
scoreboard players set #gr driftmountains -3317
scoreboard players set #gdr driftmountains -97
scoreboard players set #gp driftmountains 63
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0001f,-0.0151f,0.9999f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.7573f,-0.0919f,-0.1980f,-0.6156f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.1344f,-0.5981f,0.7711f,0.1720f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.5455f,0.0071f,0.0110f,0.8380f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0110f,0.8380f,0.5455f,0.0071f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3815f,0.8743f,0.2508f],left_rotation:[-0.0696f,0.1803f,-0.9147f,-0.3550f]}}
particle minecraft:cloud -16.26 67.40 -83.16 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -16.26 67.20 -83.16 -0.030 0.02 -0.045 1 0 force
particle minecraft:cloud -17.69 67.40 -82.23 0.35 0.18 0.35 0.02 2 force
scoreboard players set #gx driftmountains -23596
scoreboard players set #gdx driftmountains 714
scoreboard players set #gy driftmountains 67197
scoreboard players set #gdy driftmountains -11
scoreboard players set #gz driftmountains -86737
scoreboard players set #gdz driftmountains 413
scoreboard players set #gr driftmountains -3156
scoreboard players set #gdr driftmountains 52
scoreboard players set #gp driftmountains 67
scoreboard players set #gdp driftmountains -1
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0001f,-0.0175f,0.9998f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.0264f,-0.2313f,-0.0601f,-0.9707f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[-0.0416f,-0.9697f,0.0509f,0.2354f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.5455f,0.0071f,0.0110f,0.8380f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0110f,0.8380f,0.5455f,0.0071f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3861f,0.8648f,0.1069f],left_rotation:[-0.1062f,0.1587f,-0.8275f,-0.5279f]}}
particle minecraft:cloud -23.54 67.52 -88.25 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -23.54 67.32 -88.25 -0.026 0.02 -0.042 1 0 force
particle minecraft:cloud -24.97 67.52 -87.37 0.35 0.18 0.35 0.02 2 force
