scoreboard players set #gx driftmountains -64983
scoreboard players set #gdx driftmountains 626
scoreboard players set #gy driftmountains 69138
scoreboard players set #gdy driftmountains -11
scoreboard players set #gz driftmountains -32365
scoreboard players set #gdz driftmountains -228
scoreboard players set #gr driftmountains -13126
scoreboard players set #gdr driftmountains -363
scoreboard players set #gp driftmountains 85
scoreboard players set #gdp driftmountains 3
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[0.0061f,-0.0001f,0.0133f,0.9999f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.7451f,0.1469f,0.0887f,-0.6445f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[-0.1569f,-0.6574f,0.7338f,-0.0694f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.6282f,0.0082f,0.0102f,0.7780f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0102f,0.7780f,0.6282f,0.0082f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.4009f,0.8480f,0.1003f],left_rotation:[0.0199f,-0.1842f,0.9801f,0.0700f]}}
particle minecraft:cloud -66.48 69.46 -32.16 0.35 0.18 0.35 0.02 2 force
particle minecraft:cloud -65.38 69.46 -30.91 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -65.38 69.26 -30.91 -0.030 0.02 0.027 1 0 force
scoreboard players set #gx driftmountains -71429
scoreboard players set #gdx driftmountains 672
scoreboard players set #gy driftmountains 69234
scoreboard players set #gdy driftmountains -9
scoreboard players set #gz driftmountains -31602
scoreboard players set #gdz driftmountains -289
scoreboard players set #gr driftmountains -11802
scoreboard players set #gdr driftmountains 12
scoreboard players set #gp driftmountains 74
scoreboard players set #gdp driftmountains 1
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[-0.0036f,0.0000f,0.0027f,1.0000f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.6213f,-0.0108f,0.0756f,0.7798f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.0059f,0.7762f,0.6259f,0.0761f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.6282f,0.0082f,0.0102f,0.7780f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0102f,0.7780f,0.6282f,0.0082f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3562f,0.8557f,0.2435f],left_rotation:[0.1594f,-0.0977f,0.4782f,0.8582f]}}
scoreboard players set #gx driftmountains -76549
scoreboard players set #gdx driftmountains 661
scoreboard players set #gy driftmountains 69308
scoreboard players set #gdy driftmountains -10
scoreboard players set #gz driftmountains -28046
scoreboard players set #gdz driftmountains -284
scoreboard players set #gr driftmountains -13029
scoreboard players set #gdr driftmountains 140
scoreboard players set #gp driftmountains 75
scoreboard players set #gdp driftmountains -1
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,0.0000f,0.0107f,0.9999f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.9551f,0.0189f,0.1283f,0.2665f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[-0.1010f,0.2545f,0.9583f,0.0814f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.6282f,0.0082f,0.0102f,0.7780f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0102f,0.7780f,0.6282f,0.0082f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3898f,0.8631f,0.1062f],left_rotation:[0.0927f,-0.1660f,0.8695f,0.4558f]}}
particle minecraft:cloud -78.05 69.63 -27.87 0.35 0.18 0.35 0.02 2 force
particle minecraft:cloud -76.97 69.63 -26.59 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -76.97 69.43 -26.59 -0.032 0.02 0.028 1 0 force
