scoreboard players set #gx driftmountains -75736
scoreboard players set #gdx driftmountains 638
scoreboard players set #gy driftmountains 69296
scoreboard players set #gdy driftmountains -9
scoreboard players set #gz driftmountains -28357
scoreboard players set #gdz driftmountains -250
scoreboard players set #gr driftmountains -12520
scoreboard players set #gdr driftmountains 147
scoreboard players set #gp driftmountains 76
scoreboard players set #gdp driftmountains -1
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,0.0000f,0.0086f,1.0000f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.6959f,-0.0342f,0.1072f,0.7093f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[-0.0333f,0.7019f,0.7033f,0.1075f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.9810f,0.0128f,-0.0025f,-0.1935f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0025f,-0.1935f,0.9810f,0.0128f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3819f,0.8661f,0.1074f],left_rotation:[0.1195f,-0.1496f,0.7768f,0.5999f]}}
particle minecraft:cloud -77.25 69.62 -28.31 0.35 0.18 0.35 0.02 2 force
particle minecraft:cloud -76.28 69.62 -26.95 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -76.28 69.42 -26.95 -0.033 0.02 0.024 1 0 force
scoreboard players set #gx driftmountains -81918
scoreboard players set #gdx driftmountains 571
scoreboard players set #gy driftmountains 69395
scoreboard players set #gdy driftmountains -10
scoreboard players set #gz driftmountains -27584
scoreboard players set #gdz driftmountains -107
scoreboard players set #gr driftmountains -9446
scoreboard players set #gdr driftmountains -628
scoreboard players set #gp driftmountains 103
scoreboard players set #gdp driftmountains -2
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0000f,-0.0033f,1.0000f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.4838f,-0.0322f,-0.0779f,-0.8711f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[-0.0133f,-0.8677f,0.4899f,0.0832f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.9810f,0.0128f,-0.0025f,-0.1935f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0025f,-0.1935f,0.9810f,0.0128f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3916f,0.8293f,0.2331f],left_rotation:[0.1460f,0.1039f,-0.5536f,0.8133f]}}
scoreboard players set #gx driftmountains -86648
scoreboard players set #gdx driftmountains 370
scoreboard players set #gy driftmountains 69520
scoreboard players set #gdy driftmountains -11
scoreboard players set #gz driftmountains -25450
scoreboard players set #gdz driftmountains -171
scoreboard players set #gr driftmountains -7004
scoreboard players set #gdr driftmountains 54
scoreboard players set #gp driftmountains 103
scoreboard players set #gdp driftmountains 7
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.8844f,0.1644f,-0.2732f,0.3409f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.3105f,0.3715f,0.8720f,-0.0724f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.9810f,0.0128f,-0.0025f,-0.1935f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0025f,-0.1935f,0.9810f,0.0128f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3544f,0.8531f,0.1023f],left_rotation:[-0.1837f,0.0485f,-0.2244f,-0.9557f]}}
particle minecraft:cloud -87.55 69.84 -26.66 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -87.55 69.64 -26.66 -0.009 0.02 -0.003 1 0 force
particle minecraft:cloud -88.12 69.84 -25.10 0.35 0.18 0.35 0.02 3 force
