scoreboard players set #gx driftmountains -56431
scoreboard players set #gdx driftmountains -67
scoreboard players set #gy driftmountains 68143
scoreboard players set #gdy driftmountains -13
scoreboard players set #gz driftmountains -67884
scoreboard players set #gdz driftmountains -665
scoreboard players set #gr driftmountains -15627
scoreboard players set #gdr driftmountains 223
scoreboard players set #gp driftmountains 93
scoreboard players set #gdp driftmountains 2
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[0.0061f,0.0001f,-0.0183f,0.9998f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.0189f,-0.2289f,-0.0583f,-0.9715f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[-0.0435f,-0.9707f,0.0431f,0.2322f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.6989f,0.0091f,-0.0094f,-0.7151f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0094f,-0.7151f,0.6989f,0.0091f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3873f,0.8644f,0.1067f],left_rotation:[-0.1020f,0.1611f,-0.8414f,-0.5056f]}}
particle minecraft:cloud -57.70 68.46 -67.07 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -57.70 68.26 -67.07 -0.016 0.02 0.037 1 0 force
particle minecraft:cloud -56.17 68.46 -66.39 0.35 0.18 0.35 0.02 2 force
playsound driftgen:grain.kaze.032 neutral @a -56.38 68.52 -72.84 12 1
scoreboard players set #gx driftmountains -55018
scoreboard players set #gdx driftmountains -109
scoreboard players set #gy driftmountains 68253
scoreboard players set #gdy driftmountains -12
scoreboard players set #gz driftmountains -61824
scoreboard players set #gdz driftmountains -739
scoreboard players set #gr driftmountains 17756
scoreboard players set #gdr driftmountains 403
scoreboard players set #gp driftmountains 94
scoreboard players set #gdp driftmountains -1
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0000f,-0.0037f,1.0000f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.8497f,0.0208f,-0.0661f,-0.5227f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.0115f,-0.5187f,0.8522f,0.0684f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.6989f,0.0091f,-0.0094f,-0.7151f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0094f,-0.7151f,0.6989f,0.0091f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3825f,0.8272f,0.2323f],left_rotation:[0.1630f,0.0721f,-0.3929f,0.9022f]}}
playsound driftgen:grain.onyx.047 neutral @a -55.81 68.65 -67.97 12 1
scoreboard players set #gx driftmountains -53988
scoreboard players set #gdx driftmountains -71
scoreboard players set #gy driftmountains 68364
scoreboard players set #gdy driftmountains -13
scoreboard players set #gz driftmountains -55721
scoreboard players set #gdz driftmountains -672
scoreboard players set #gr driftmountains 15004
scoreboard players set #gdr driftmountains 174
scoreboard players set #gp driftmountains 106
scoreboard players set #gdp driftmountains -3
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,0.0001f,0.0149f,0.9999f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.5804f,-0.1129f,0.1486f,0.7927f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[-0.0661f,0.7814f,0.5955f,0.1745f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.6989f,0.0091f,-0.0094f,-0.7151f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0094f,-0.7151f,0.6989f,0.0091f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.4012f,0.8414f,0.0977f],left_rotation:[-0.0073f,-0.1833f,0.9803f,-0.0728f]}}
particle minecraft:cloud -54.08 68.68 -54.21 0.35 0.18 0.35 0.02 2 force
particle minecraft:cloud -52.64 68.68 -55.05 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -52.64 68.48 -55.05 0.019 0.02 0.034 1 0 force
playsound driftgen:grain.kaze.034 neutral @a -54.67 68.76 -61.24 12 1
