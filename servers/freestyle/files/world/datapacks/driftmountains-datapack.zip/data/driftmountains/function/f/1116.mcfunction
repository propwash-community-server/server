scoreboard players set #gx driftmountains -73703
scoreboard players set #gdx driftmountains -938
scoreboard players set #gy driftmountains 70272
scoreboard players set #gdy driftmountains -26
scoreboard players set #gz driftmountains 28854
scoreboard players set #gdz driftmountains -1030
scoreboard players set #gr driftmountains 17784
scoreboard players set #gdr driftmountains -16
scoreboard players set #gp driftmountains 82
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.8505f,0.1940f,-0.2826f,0.3989f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.3261f,0.4308f,0.8348f,-0.1057f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.9886f,0.0129f,-0.0020f,-0.1499f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0020f,-0.1499f,0.9886f,0.0129f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3523f,0.8427f,0.0982f],left_rotation:[-0.1872f,0.0059f,0.0034f,-0.9823f]}}
particle minecraft:cloud -74.49 70.59 30.14 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -74.49 70.39 30.14 0.003 0.02 0.084 1 0 force
particle minecraft:cloud -72.82 70.59 30.08 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -65735
scoreboard players set #gdx driftmountains -1011
scoreboard players set #gy driftmountains 70460
scoreboard players set #gdy driftmountains -20
scoreboard players set #gz driftmountains 36388
scoreboard players set #gdz driftmountains -965
scoreboard players set #gr driftmountains 17865
scoreboard players set #gdr driftmountains 5
scoreboard players set #gp driftmountains 55
scoreboard players set #gdp driftmountains 6
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.2895f,0.3689f,-0.0619f,0.8810f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.1549f,0.8924f,0.2524f,-0.3405f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.9886f,0.0129f,-0.0020f,-0.1499f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0020f,-0.1499f,0.9886f,0.0129f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3774f,0.8274f,0.2324f],left_rotation:[-0.1699f,-0.0539f,0.3006f,-0.9370f]}}
particle minecraft:cloud -66.56 70.78 37.77 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -66.56 70.58 37.77 0.002 0.02 0.083 1 0 force
particle minecraft:cloud -64.85 70.78 37.73 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -61838
scoreboard players set #gdx driftmountains -1010
scoreboard players set #gy driftmountains 70512
scoreboard players set #gdy driftmountains -8
scoreboard players set #gz driftmountains 40108
scoreboard players set #gdz driftmountains -855
scoreboard players set #gr driftmountains 17755
scoreboard players set #gdr driftmountains 138
scoreboard players set #gp driftmountains 16
scoreboard players set #gdp driftmountains 11
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[-0.0008f,-0.0000f,-0.0223f,0.9998f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.7789f,-0.1563f,-0.3509f,-0.4957f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.3007f,-0.4616f,0.7996f,0.2390f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.9886f,0.0129f,-0.0020f,-0.1499f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0020f,-0.1499f,0.9886f,0.0129f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3609f,0.8264f,0.0919f],left_rotation:[-0.1692f,-0.0676f,0.3927f,-0.9014f]}}
particle minecraft:cloud -62.62 70.83 41.40 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -62.62 70.63 41.40 0.003 0.02 0.081 1 0 force
particle minecraft:cloud -60.95 70.83 41.33 0.35 0.18 0.35 0.02 3 force
