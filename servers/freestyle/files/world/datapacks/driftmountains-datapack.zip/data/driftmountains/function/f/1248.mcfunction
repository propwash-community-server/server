scoreboard players set #gx driftmountains -54751
scoreboard players set #gdx driftmountains 126
scoreboard players set #gy driftmountains 68684
scoreboard players set #gdy driftmountains -20
scoreboard players set #gz driftmountains -44768
scoreboard players set #gdz driftmountains -692
scoreboard players set #gr driftmountains 15928
scoreboard players set #gdr driftmountains -102
scoreboard players set #gp driftmountains 139
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,0.0001f,0.0194f,0.9998f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.5271f,0.2161f,0.0753f,-0.8184f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[-0.1618f,-0.8308f,0.5073f,-0.1619f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.9851f,0.0129f,0.0022f,0.1712f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0022f,0.1712f,0.9851f,0.0129f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3917f,0.8257f,0.0916f],left_rotation:[-0.0806f,-0.1606f,0.8729f,-0.4535f]}}
particle minecraft:cloud -55.09 69.00 -43.29 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud -53.52 69.00 -43.88 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -53.52 68.80 -43.88 0.015 0.02 0.039 1 0 force
playsound driftgen:grain.kaze.035 neutral @a -54.01 69.02 -50.54 12 1
scoreboard players set #gx driftmountains -57381
scoreboard players set #gdx driftmountains 319
scoreboard players set #gy driftmountains 68818
scoreboard players set #gdy driftmountains -20
scoreboard players set #gz driftmountains -40972
scoreboard players set #gdz driftmountains -561
scoreboard players set #gr driftmountains 17555
scoreboard players set #gdr driftmountains -205
scoreboard players set #gp driftmountains 145
scoreboard players set #gdp driftmountains -1
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.9607f,0.0173f,0.2296f,0.1552f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[-0.2146f,0.1320f,0.9641f,0.0836f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.9851f,0.0129f,0.0022f,0.1712f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0022f,0.1712f,0.9851f,0.0129f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.4059f,0.8466f,0.2399f],left_rotation:[-0.0807f,-0.1666f,0.8656f,-0.4653f]}}
particle minecraft:cloud -58.13 69.14 -39.54 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud -56.42 69.14 -39.68 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -56.42 68.94 -39.68 0.003 0.02 0.038 1 0 force
playsound driftgen:grain.onyx.034 neutral @a -55.36 69.16 -45.92 12 1
scoreboard players set #gx driftmountains -60227
scoreboard players set #gdx driftmountains 391
scoreboard players set #gy driftmountains 68997
scoreboard players set #gdy driftmountains -21
scoreboard players set #gz driftmountains -36083
scoreboard players set #gdz driftmountains -487
scoreboard players set #gr driftmountains -17397
scoreboard players set #gdr driftmountains -291
scoreboard players set #gp driftmountains 159
scoreboard players set #gdp driftmountains -4
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.3328f,-0.1628f,0.1155f,0.9216f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[-0.0193f,0.9146f,0.3517f,0.1987f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.9851f,0.0129f,0.0022f,0.1712f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0022f,0.1712f,0.9851f,0.0129f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3998f,0.8359f,0.0956f],left_rotation:[-0.0306f,-0.1794f,0.9638f,-0.1946f]}}
particle minecraft:cloud -61.19 69.32 -34.92 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud -59.53 69.32 -34.74 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -59.53 69.12 -34.74 -0.004 0.02 0.037 1 0 force
playsound driftgen:grain.kaze.034 neutral @a -57.31 69.34 -40.27 12 1
