scoreboard players set #gx driftmountains 4790
scoreboard players set #gdx driftmountains -1060
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 63158
scoreboard players set #gdz driftmountains 87
scoreboard players set #gr driftmountains 14217
scoreboard players set #gdr driftmountains 260
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.8178f,0.2331f,-0.3667f,0.3774f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.4084f,0.4180f,0.7978f,-0.1484f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.9471f,0.0124f,-0.0042f,-0.3206f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0042f,-0.3206f,0.9471f,0.0124f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3841f,0.8220f,0.0901f],left_rotation:[-0.1089f,-0.1423f,0.7804f,-0.5989f]}}
particle minecraft:cloud 4.90 71.32 64.67 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 4.90 71.12 64.67 0.039 0.02 0.051 1 0 force
particle minecraft:cloud 6.22 71.32 63.64 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains 11882
scoreboard players set #gdx driftmountains -906
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 59026
scoreboard players set #gdz driftmountains 433
scoreboard players set #gr driftmountains 12424
scoreboard players set #gdr driftmountains 320
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[0.0019f,0.0000f,-0.0223f,0.9997f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.2833f,0.4416f,-0.0860f,0.8469f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.1755f,0.8607f,0.2385f,-0.4142f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.9471f,0.0124f,-0.0042f,-0.3206f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0042f,-0.3206f,0.9471f,0.0124f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.4059f,0.8464f,0.2398f],left_rotation:[-0.0816f,-0.1661f,0.8632f,-0.4698f]}}
particle minecraft:cloud 12.53 71.32 60.50 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 12.53 71.12 60.50 0.047 0.02 0.032 1 0 force
particle minecraft:cloud 13.49 71.32 59.09 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains 17823
scoreboard players set #gdx driftmountains -791
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 56926
scoreboard players set #gdz driftmountains 725
scoreboard players set #gr driftmountains 10517
scoreboard players set #gdr driftmountains 265
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[0.0061f,0.0001f,-0.0223f,0.9997f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.7493f,-0.1943f,-0.4104f,-0.4821f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.3620f,-0.4416f,0.7738f,0.2741f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.9471f,0.0124f,-0.0042f,-0.3206f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0042f,-0.3206f,0.9471f,0.0124f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3927f,0.8264f,0.0918f],left_rotation:[-0.0765f,-0.1627f,0.8834f,-0.4326f]}}
particle minecraft:cloud 18.82 71.32 58.06 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 18.82 71.12 58.06 0.063 0.02 0.017 1 0 force
particle minecraft:cloud 19.26 71.32 56.45 0.35 0.18 0.35 0.02 3 force
