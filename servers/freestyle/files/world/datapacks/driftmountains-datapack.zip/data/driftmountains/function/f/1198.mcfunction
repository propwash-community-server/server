scoreboard players set #gx driftmountains -80121
scoreboard players set #gdx driftmountains 622
scoreboard players set #gy driftmountains 69365
scoreboard players set #gdy driftmountains -11
scoreboard players set #gz driftmountains -27021
scoreboard players set #gdz driftmountains -122
scoreboard players set #gr driftmountains -10671
scoreboard players set #gdr driftmountains -654
scoreboard players set #gp driftmountains 100
scoreboard players set #gdp driftmountains -6
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,0.0000f,0.0041f,1.0000f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.1276f,0.0153f,0.0508f,0.9904f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.0530f,0.9905f,0.1267f,-0.0019f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.8898f,0.0116f,-0.0060f,-0.4561f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0060f,-0.4561f,0.8898f,0.0116f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3528f,0.8394f,0.0969f],left_rotation:[0.1862f,0.0075f,-0.0751f,0.9796f]}}
scoreboard players set #gx driftmountains -86045
scoreboard players set #gdx driftmountains 580
scoreboard players set #gy driftmountains 69488
scoreboard players set #gdy driftmountains -16
scoreboard players set #gz driftmountains -26519
scoreboard players set #gdz driftmountains -245
scoreboard players set #gr driftmountains -7680
scoreboard players set #gdr driftmountains -81
scoreboard players set #gp driftmountains 117
scoreboard players set #gdp driftmountains 3
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[0.0008f,0.0000f,-0.0223f,0.9998f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.5929f,-0.1286f,-0.1653f,-0.7776f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.0845f,-0.7645f,0.6096f,0.1916f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.8898f,0.0116f,-0.0060f,-0.4561f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0060f,-0.4561f,0.8898f,0.0116f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3858f,0.8739f,0.2506f],left_rotation:[-0.0553f,0.1851f,-0.9416f,-0.2760f]}}
particle minecraft:cloud -87.18 69.81 -27.66 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -87.18 69.61 -27.66 -0.035 0.02 -0.008 1 0 force
particle minecraft:cloud -87.57 69.81 -26.00 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -88696
scoreboard players set #gdx driftmountains 378
scoreboard players set #gy driftmountains 69582
scoreboard players set #gdy driftmountains -12
scoreboard players set #gz driftmountains -24309
scoreboard players set #gdz driftmountains -223
scoreboard players set #gr driftmountains -7436
scoreboard players set #gdr driftmountains 105
scoreboard players set #gp driftmountains 106
scoreboard players set #gdp driftmountains -1
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.6959f,0.2767f,-0.2250f,0.6233f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.2918f,0.6504f,0.6706f,-0.2051f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.8898f,0.0116f,-0.0060f,-0.4561f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0060f,-0.4561f,0.8898f,0.0116f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3535f,0.8366f,0.0959f],left_rotation:[-0.1846f,-0.0190f,0.1361f,-0.9731f]}}
particle minecraft:cloud -89.68 69.90 -25.45 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -89.68 69.70 -25.45 -0.035 0.02 -0.010 1 0 force
particle minecraft:cloud -90.13 69.90 -23.84 0.35 0.18 0.35 0.02 3 force
