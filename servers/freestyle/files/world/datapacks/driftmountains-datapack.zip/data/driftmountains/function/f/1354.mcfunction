scoreboard players set #gx driftmountains -21316
scoreboard players set #gdx driftmountains 704
scoreboard players set #gy driftmountains 67161
scoreboard players set #gdy driftmountains -10
scoreboard players set #gz driftmountains -85095
scoreboard players set #gdz driftmountains 415
scoreboard players set #gr driftmountains -3142
scoreboard players set #gdr driftmountains 25
scoreboard players set #gp driftmountains 65
scoreboard players set #gdp driftmountains -1
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.8878f,0.1438f,-0.1920f,0.3928f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.2343f,0.4151f,0.8776f,-0.0513f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.9956f,0.0130f,-0.0012f,-0.0924f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0012f,-0.0924f,0.9956f,0.0130f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3857f,0.8650f,0.1070f],left_rotation:[-0.1074f,0.1579f,-0.8231f,-0.5348f]}}
particle minecraft:cloud -21.26 67.48 -86.61 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -21.26 67.28 -86.61 -0.025 0.02 -0.042 1 0 force
particle minecraft:cloud -22.69 67.48 -85.73 0.35 0.18 0.35 0.02 2 force
scoreboard players set #gx driftmountains -27636
scoreboard players set #gdx driftmountains 676
scoreboard players set #gy driftmountains 67257
scoreboard players set #gdy driftmountains -11
scoreboard players set #gz driftmountains -88265
scoreboard players set #gdz driftmountains 354
scoreboard players set #gr driftmountains -3323
scoreboard players set #gdr driftmountains 19
scoreboard players set #gp driftmountains 73
scoreboard players set #gdp driftmountains -1
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0001f,-0.0179f,0.9998f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.8964f,0.1407f,-0.1996f,0.3700f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.2396f,0.3930f,0.8865f,-0.0473f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.9956f,0.0130f,-0.0012f,-0.0924f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0012f,-0.0924f,0.9956f,0.0130f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3694f,0.8717f,0.2497f],left_rotation:[-0.1083f,0.1588f,-0.7989f,-0.5700f]}}
particle minecraft:cloud -27.67 67.58 -89.88 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -27.67 67.38 -89.88 -0.025 0.02 -0.038 1 0 force
particle minecraft:cloud -29.10 67.58 -88.94 0.35 0.18 0.35 0.02 2 force
scoreboard players set #gx driftmountains -34112
scoreboard players set #gdx driftmountains 604
scoreboard players set #gy driftmountains 67376
scoreboard players set #gdy driftmountains -12
scoreboard players set #gz driftmountains -91610
scoreboard players set #gdz driftmountains 195
scoreboard players set #gr driftmountains -3986
scoreboard players set #gdr driftmountains 51
scoreboard players set #gp driftmountains 91
scoreboard players set #gdp driftmountains -1
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0001f,-0.0201f,0.9998f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.9042f,0.1368f,-0.2047f,0.3491f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.2425f,0.3725f,0.8948f,-0.0426f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.9956f,0.0130f,-0.0012f,-0.0924f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0012f,-0.0924f,0.9956f,0.0130f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3829f,0.8658f,0.1073f],left_rotation:[-0.1166f,0.1517f,-0.7886f,-0.5843f]}}
particle minecraft:cloud -34.28 67.70 -93.11 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -34.28 67.50 -93.11 -0.024 0.02 -0.029 1 0 force
particle minecraft:cloud -35.56 67.70 -92.04 0.35 0.18 0.35 0.02 3 force
