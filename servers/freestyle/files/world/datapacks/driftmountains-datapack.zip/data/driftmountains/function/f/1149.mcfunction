scoreboard players set #gx driftmountains -97076
scoreboard players set #gdx driftmountains -253
scoreboard players set #gy driftmountains 70033
scoreboard players set #gdy driftmountains 1
scoreboard players set #gz driftmountains -1309
scoreboard players set #gdz driftmountains -926
scoreboard players set #gr driftmountains -14564
scoreboard players set #gdr driftmountains 197
scoreboard players set #gp driftmountains -5
scoreboard players set #gdp driftmountains 4
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[0.0061f,0.0001f,-0.0223f,0.9997f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.3167f,0.3706f,-0.0748f,0.8699f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.1667f,0.8826f,0.2795f,-0.3393f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.7546f,0.0099f,0.0086f,0.6560f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0086f,0.6560f,0.7546f,0.0099f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3588f,0.8284f,0.0926f],left_rotation:[-0.1737f,-0.0571f,0.3376f,-0.9233f]}}
particle minecraft:cloud -98.48 70.35 -0.74 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -98.48 70.15 -0.74 -0.033 0.02 0.048 1 0 force
particle minecraft:cloud -97.10 70.35 0.20 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -93290
scoreboard players set #gdx driftmountains -587
scoreboard players set #gy driftmountains 70002
scoreboard players set #gdy driftmountains 4
scoreboard players set #gz driftmountains 6193
scoreboard players set #gdz driftmountains -795
scoreboard players set #gr driftmountains -17132
scoreboard players set #gdr driftmountains 296
scoreboard players set #gp driftmountains -17
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.4225f,-0.2882f,-0.2087f,-0.8336f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.1223f,-0.8163f,0.4551f,0.3341f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.7546f,0.0099f,0.0086f,0.6560f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0086f,0.6560f,0.7546f,0.0099f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3688f,0.8301f,0.2334f],left_rotation:[-0.1778f,-0.0201f,0.1283f,-0.9755f]}}
particle minecraft:cloud -94.34 70.32 7.41 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -94.34 70.12 7.41 -0.009 0.02 0.059 1 0 force
particle minecraft:cloud -92.65 70.32 7.67 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -89540
scoreboard players set #gdx driftmountains -713
scoreboard players set #gy driftmountains 69984
scoreboard players set #gdy driftmountains 2
scoreboard players set #gz driftmountains 10507
scoreboard players set #gdz driftmountains -814
scoreboard players set #gr driftmountains 17794
scoreboard players set #gdr driftmountains 102
scoreboard players set #gp driftmountains -6
scoreboard players set #gdp driftmountains -4
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.9187f,0.1271f,-0.3113f,0.2071f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.3348f,0.2410f,0.9104f,-0.0312f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.7546f,0.0099f,0.0086f,0.6560f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0086f,0.6560f,0.7546f,0.0099f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3524f,0.8456f,0.0994f],left_rotation:[-0.1872f,0.0178f,-0.0599f,-0.9803f]}}
particle minecraft:cloud -90.33 70.30 11.80 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -90.33 70.10 11.80 0.002 0.02 0.061 1 0 force
particle minecraft:cloud -88.66 70.30 11.74 0.35 0.18 0.35 0.02 3 force
