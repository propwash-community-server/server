scoreboard players set #gx driftmountains -37955
scoreboard players set #gdx driftmountains 636
scoreboard players set #gy driftmountains 67460
scoreboard players set #gdy driftmountains -19
scoreboard players set #gz driftmountains -91620
scoreboard players set #gdz driftmountains -12
scoreboard players set #gr driftmountains -5540
scoreboard players set #gdr driftmountains 84
scoreboard players set #gp driftmountains 137
scoreboard players set #gdp driftmountains -6
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0001f,-0.0220f,0.9998f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.8250f,-0.0712f,-0.2144f,-0.5180f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.1611f,-0.4983f,0.8370f,0.1584f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.4035f,0.0053f,0.0120f,0.9149f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0120f,0.9149f,0.4035f,0.0053f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3915f,0.8620f,0.1058f],left_rotation:[-0.0860f,0.1692f,-0.8875f,-0.4199f]}}
particle minecraft:cloud -38.52 67.78 -93.02 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -38.52 67.58 -93.02 -0.031 0.02 -0.022 1 0 force
particle minecraft:cloud -39.47 67.78 -91.65 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -42918
scoreboard players set #gdx driftmountains 395
scoreboard players set #gy driftmountains 67595
scoreboard players set #gdy driftmountains -10
scoreboard players set #gz driftmountains -90718
scoreboard players set #gdz driftmountains -180
scoreboard players set #gr driftmountains -7801
scoreboard players set #gdr driftmountains 226
scoreboard players set #gp driftmountains 102
scoreboard players set #gdp driftmountains 3
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.8123f,-0.0753f,-0.2106f,-0.5386f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.1552f,-0.5194f,0.8247f,0.1611f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.4035f,0.0053f,0.0120f,0.9149f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0120f,0.9149f,0.4035f,0.0053f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3789f,0.8742f,0.2507f],left_rotation:[-0.0781f,0.1767f,-0.8950f,-0.4021f]}}
particle minecraft:cloud -44.08 67.92 -91.84 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -44.08 67.72 -91.84 -0.034 0.02 -0.007 1 0 force
particle minecraft:cloud -44.43 67.92 -90.17 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -46628
scoreboard players set #gdx driftmountains 356
scoreboard players set #gy driftmountains 67686
scoreboard players set #gdy driftmountains -9
scoreboard players set #gz driftmountains -87785
scoreboard players set #gdz driftmountains -368
scoreboard players set #gr driftmountains -10351
scoreboard players set #gdr driftmountains 131
scoreboard players set #gp driftmountains 83
scoreboard players set #gdp driftmountains 1
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[0.0061f,0.0001f,-0.0202f,0.9998f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.6800f,-0.1308f,-0.2041f,-0.6919f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.1325f,-0.6743f,0.6975f,0.2030f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.4035f,0.0053f,0.0120f,0.9149f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0120f,0.9149f,0.4035f,0.0053f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3846f,0.8654f,0.1071f],left_rotation:[-0.1112f,0.1555f,-0.8096f,-0.5548f]}}
particle minecraft:cloud -48.05 68.01 -88.30 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -48.05 67.81 -88.30 -0.033 0.02 0.008 1 0 force
particle minecraft:cloud -47.66 68.01 -86.68 0.35 0.18 0.35 0.02 3 force
