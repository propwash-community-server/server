scoreboard players set #gx driftmountains 16393
scoreboard players set #gdx driftmountains 970
scoreboard players set #gy driftmountains 66659
scoreboard players set #gdy driftmountains -12
scoreboard players set #gz driftmountains -60361
scoreboard players set #gdz driftmountains 620
scoreboard players set #gr driftmountains -5961
scoreboard players set #gdr driftmountains -43
scoreboard players set #gp driftmountains 61
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,0.0000f,0.0015f,1.0000f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.9769f,0.0481f,0.0255f,0.2069f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[-0.0039f,0.2053f,0.9772f,0.0543f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.8757f,0.0115f,-0.0063f,-0.4826f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0063f,-0.4826f,0.8757f,0.0115f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3530f,0.8491f,0.1008f],left_rotation:[0.1863f,-0.0321f,0.1365f,0.9724f]}}
scoreboard players set #gx driftmountains 9330
scoreboard players set #gdx driftmountains 949
scoreboard players set #gy driftmountains 66750
scoreboard players set #gdy driftmountains -12
scoreboard players set #gz driftmountains -65120
scoreboard players set #gdz driftmountains 635
scoreboard players set #gr driftmountains -5630
scoreboard players set #gdr driftmountains -75
scoreboard players set #gp driftmountains 61
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[-0.0039f,0.0000f,0.0000f,1.0000f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.6209f,0.0307f,0.0424f,0.7821f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.0395f,0.7820f,0.6211f,0.0344f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.8757f,0.0115f,-0.0063f,-0.4826f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0063f,-0.4826f,0.8757f,0.0115f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3626f,0.8345f,0.2352f],left_rotation:[0.1800f,-0.0095f,0.0231f,0.9834f]}}
scoreboard players set #gx driftmountains 386
scoreboard players set #gdx driftmountains 923
scoreboard players set #gy driftmountains 66864
scoreboard players set #gdy driftmountains -12
scoreboard players set #gz driftmountains -71168
scoreboard players set #gdz driftmountains 611
scoreboard players set #gr driftmountains -5103
scoreboard players set #gdr driftmountains -32
scoreboard players set #gp driftmountains 61
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0000f,-0.0033f,1.0000f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.9691f,0.0622f,-0.0337f,0.2364f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.0588f,0.2412f,0.9679f,0.0394f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.8757f,0.0115f,-0.0063f,-0.4826f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0063f,-0.4826f,0.8757f,0.0115f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3616f,0.8259f,0.0916f],left_rotation:[0.1676f,0.0710f,-0.4104f,0.8935f]}}
