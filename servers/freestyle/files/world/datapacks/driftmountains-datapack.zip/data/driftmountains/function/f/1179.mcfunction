scoreboard players set #gx driftmountains -90819
scoreboard players set #gdx driftmountains 549
scoreboard players set #gy driftmountains 69647
scoreboard players set #gdy driftmountains -19
scoreboard players set #gz driftmountains -23003
scoreboard players set #gdz driftmountains -426
scoreboard players set #gr driftmountains -8444
scoreboard players set #gdr driftmountains 164
scoreboard players set #gp driftmountains 110
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.9420f,0.0729f,-0.3236f,0.0508f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.3307f,0.0851f,0.9395f,0.0257f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.7095f,0.0093f,-0.0092f,-0.7046f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0092f,-0.7046f,0.7095f,0.0093f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3527f,0.8476f,0.1002f],left_rotation:[-0.1868f,0.0259f,-0.1035f,-0.9765f]}}
particle minecraft:cloud -91.99 69.97 -23.96 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -91.99 69.77 -23.96 -0.042 0.02 -0.004 1 0 force
particle minecraft:cloud -92.15 69.97 -22.29 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -95541
scoreboard players set #gdx driftmountains 463
scoreboard players set #gy driftmountains 69822
scoreboard players set #gdy driftmountains -19
scoreboard players set #gz driftmountains -17983
scoreboard players set #gdz driftmountains -640
scoreboard players set #gr driftmountains -9700
scoreboard players set #gdr driftmountains 191
scoreboard players set #gp driftmountains 90
scoreboard players set #gdp driftmountains 3
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.7635f,-0.1557f,-0.3163f,-0.5411f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.2611f,-0.5109f,0.7841f,0.2368f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.7095f,0.0093f,-0.0092f,-0.7046f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0092f,-0.7046f,0.7095f,0.0093f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3674f,0.8309f,0.2337f],left_rotation:[-0.1786f,-0.0139f,0.0967f,-0.9791f]}}
particle minecraft:cloud -97.00 70.14 -18.67 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -97.00 69.94 -18.67 -0.047 0.02 0.006 1 0 force
particle minecraft:cloud -96.79 70.14 -16.97 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -97628
scoreboard players set #gdx driftmountains 194
scoreboard players set #gy driftmountains 69925
scoreboard players set #gdy driftmountains -13
scoreboard players set #gz driftmountains -13726
scoreboard players set #gdz driftmountains -610
scoreboard players set #gr driftmountains -11325
scoreboard players set #gdr driftmountains 270
scoreboard players set #gp driftmountains 70
scoreboard players set #gdp driftmountains 3
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.9370f,0.0641f,-0.3426f,0.0228f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.3469f,0.0590f,0.9354f,0.0340f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.7095f,0.0093f,-0.0092f,-0.7046f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0092f,-0.7046f,0.7095f,0.0093f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3526f,0.8401f,0.0972f],left_rotation:[-0.1865f,-0.0045f,0.0589f,-0.9806f]}}
particle minecraft:cloud -99.12 70.25 -14.00 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -99.12 70.05 -14.00 -0.040 0.02 0.017 1 0 force
particle minecraft:cloud -98.46 70.25 -12.46 0.35 0.18 0.35 0.02 3 force
