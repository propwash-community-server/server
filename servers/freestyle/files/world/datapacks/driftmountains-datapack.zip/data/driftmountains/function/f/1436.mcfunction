scoreboard players set #gx driftmountains 55429
scoreboard players set #gdx driftmountains 1143
scoreboard players set #gy driftmountains 66195
scoreboard players set #gdy driftmountains -12
scoreboard players set #gz driftmountains -36076
scoreboard players set #gdz driftmountains 829
scoreboard players set #gr driftmountains -5373
scoreboard players set #gdr driftmountains -459
scoreboard players set #gp driftmountains 51
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0000f,-0.0003f,1.0000f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.9771f,0.0509f,0.0121f,0.2062f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.0095f,0.2061f,0.9771f,0.0515f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.9147f,0.0120f,-0.0053f,-0.4038f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0053f,-0.4038f,0.9147f,0.0120f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3523f,0.8435f,0.0986f],left_rotation:[0.1873f,-0.0093f,0.0146f,0.9821f]}}
scoreboard players set #gx driftmountains 47078
scoreboard players set #gdx driftmountains 1218
scoreboard players set #gy driftmountains 66275
scoreboard players set #gdy driftmountains -13
scoreboard players set #gz driftmountains -39639
scoreboard players set #gdz driftmountains 716
scoreboard players set #gr driftmountains -3681
scoreboard players set #gdr driftmountains -168
scoreboard players set #gp driftmountains 48
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0001f,-0.0138f,0.9999f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.6165f,0.1895f,-0.0850f,0.7594f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.1653f,0.7725f,0.6000f,-0.1258f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.9147f,0.0120f,-0.0053f,-0.4038f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0053f,-0.4038f,0.9147f,0.0120f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3866f,0.8737f,0.2505f],left_rotation:[-0.0524f,0.1859f,-0.9460f,-0.2604f]}}
particle minecraft:cloud 46.94 66.59 -41.24 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke 46.94 66.39 -41.24 -0.051 0.02 -0.068 1 0 force
particle minecraft:cloud 45.58 66.59 -40.22 0.35 0.18 0.35 0.02 2 force
scoreboard players set #gx driftmountains 36970
scoreboard players set #gdx driftmountains 1125
scoreboard players set #gy driftmountains 66395
scoreboard players set #gdy driftmountains -14
scoreboard players set #gz driftmountains -47228
scoreboard players set #gdz driftmountains 901
scoreboard players set #gr driftmountains -4666
scoreboard players set #gdr driftmountains 326
scoreboard players set #gp driftmountains 57
scoreboard players set #gdp driftmountains -1
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0000f,-0.0028f,1.0000f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.9694f,0.0600f,-0.0248f,0.2369f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.0499f,0.2408f,0.9684f,0.0416f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.9147f,0.0120f,-0.0053f,-0.4038f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0053f,-0.4038f,0.9147f,0.0120f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3586f,0.8285f,0.0927f],left_rotation:[0.1740f,0.0565f,-0.3346f,0.9244f]}}
