scoreboard players set #gx driftmountains 27201
scoreboard players set #gdx driftmountains -205
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 38347
scoreboard players set #gdz driftmountains 982
scoreboard players set #gr driftmountains 6597
scoreboard players set #gdr driftmountains 258
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.8524f,-0.0890f,-0.4093f,-0.3130f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.3787f,-0.2717f,0.8664f,0.1791f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.3694f,0.0048f,-0.0122f,-0.9292f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0122f,-0.9292f,0.3694f,0.0048f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3765f,0.8210f,0.0897f],left_rotation:[-0.1316f,-0.1221f,0.6766f,-0.7141f]}}
particle minecraft:cloud 28.69 71.32 38.60 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 28.69 71.12 38.60 0.055 0.02 -0.024 1 0 force
particle minecraft:cloud 28.01 71.32 37.07 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains 28085
scoreboard players set #gdx driftmountains 170
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 30658
scoreboard players set #gdz driftmountains 989
scoreboard players set #gr driftmountains 4967
scoreboard players set #gdr driftmountains 404
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.7952f,0.2556f,-0.3815f,0.3959f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.4252f,0.4381f,0.7727f,-0.1735f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.3694f,0.0048f,-0.0122f,-0.9292f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0122f,-0.9292f,0.3694f,0.0048f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.4063f,0.8509f,0.2416f],left_rotation:[-0.0658f,-0.1745f,0.9041f,-0.3847f]}}
particle minecraft:cloud 29.68 71.32 30.43 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 29.68 71.12 30.43 0.045 0.02 -0.038 1 0 force
particle minecraft:cloud 28.57 71.32 29.12 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains 24919
scoreboard players set #gdx driftmountains 311
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 26536
scoreboard players set #gdz driftmountains 844
scoreboard players set #gr driftmountains 2501
scoreboard players set #gdr driftmountains 278
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.1969f,-0.3800f,-0.1424f,-0.8925f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.0494f,-0.8825f,0.2379f,0.4028f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.3694f,0.0048f,-0.0122f,-0.9292f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0122f,-0.9292f,0.3694f,0.0048f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3702f,0.8218f,0.0900f],left_rotation:[-0.1480f,-0.1028f,0.5771f,-0.7965f]}}
particle minecraft:cloud 26.21 71.32 25.75 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 26.21 71.12 25.75 0.025 0.02 -0.053 1 0 force
particle minecraft:cloud 24.70 71.32 25.04 0.35 0.18 0.35 0.02 3 force
