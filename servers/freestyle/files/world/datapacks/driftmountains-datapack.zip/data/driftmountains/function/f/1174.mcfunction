scoreboard players set #gx driftmountains -93510
scoreboard players set #gdx driftmountains 523
scoreboard players set #gy driftmountains 69743
scoreboard players set #gdy driftmountains -20
scoreboard players set #gz driftmountains -20481
scoreboard players set #gdz driftmountains -562
scoreboard players set #gr driftmountains -9236
scoreboard players set #gdr driftmountains 151
scoreboard players set #gp driftmountains 102
scoreboard players set #gdp driftmountains 2
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.6875f,-0.1909f,-0.2871f,-0.6392f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.2215f,-0.6125f,0.7113f,0.2642f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.8616f,0.0113f,-0.0066f,-0.5075f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0066f,-0.5075f,0.8616f,0.0113f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3524f,0.8418f,0.0979f],left_rotation:[-0.1870f,0.0025f,0.0216f,-0.9821f]}}
particle minecraft:cloud -94.80 70.06 -21.26 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -94.80 69.86 -21.26 -0.046 0.02 0.002 1 0 force
particle minecraft:cloud -94.73 70.06 -19.59 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -97325
scoreboard players set #gdx driftmountains 269
scoreboard players set #gy driftmountains 69907
scoreboard players set #gdy driftmountains -16
scoreboard players set #gz driftmountains -14580
scoreboard players set #gdz driftmountains -704
scoreboard players set #gr driftmountains -11105
scoreboard players set #gdr driftmountains 317
scoreboard players set #gp driftmountains 76
scoreboard players set #gdp driftmountains 3
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[-0.0016f,-0.0000f,-0.0223f,0.9997f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.4419f,-0.2559f,-0.1976f,-0.8368f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.1107f,-0.8207f,0.4712f,0.3037f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.8616f,0.0113f,-0.0066f,-0.5075f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0066f,-0.5075f,0.8616f,0.0113f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3580f,0.8409f,0.2377f],left_rotation:[-0.1777f,0.0406f,-0.1829f,-0.9661f]}}
particle minecraft:cloud -98.91 70.23 -14.89 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -98.91 70.03 -14.89 -0.042 0.02 0.016 1 0 force
particle minecraft:cloud -98.29 70.23 -13.29 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -98216
scoreboard players set #gdx driftmountains 57
scoreboard players set #gy driftmountains 69991
scoreboard players set #gdy driftmountains -11
scoreboard players set #gz driftmountains -9859
scoreboard players set #gdz driftmountains -785
scoreboard players set #gr driftmountains -12633
scoreboard players set #gdr driftmountains 216
scoreboard players set #gp driftmountains 49
scoreboard players set #gdp driftmountains 6
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.7806f,-0.1540f,-0.3479f,-0.4958f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.2977f,-0.4620f,0.8011f,0.2369f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.8616f,0.0113f,-0.0066f,-0.5075f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0066f,-0.5075f,0.8616f,0.0113f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3596f,0.8276f,0.0923f],left_rotation:[-0.1720f,-0.0613f,0.3599f,-0.9149f]}}
particle minecraft:cloud -99.73 70.31 -9.79 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -99.73 70.11 -9.79 -0.038 0.02 0.028 1 0 force
particle minecraft:cloud -98.74 70.31 -8.44 0.35 0.18 0.35 0.02 3 force
