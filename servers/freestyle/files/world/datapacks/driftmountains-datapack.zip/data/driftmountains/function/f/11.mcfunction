scoreboard players set #gx driftmountains -19488
scoreboard players set #gdx driftmountains -879
scoreboard players set #gy driftmountains 65446
scoreboard players set #gdy driftmountains 46
scoreboard players set #gz driftmountains 15271
scoreboard players set #gdz driftmountains -617
scoreboard players set #gr driftmountains 16576
scoreboard players set #gdr driftmountains 297
scoreboard players set #gp driftmountains -187
scoreboard players set #gdp driftmountains 15
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.0166f,0.3165f,0.0496f,0.9471f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.0496f,0.9471f,-0.0166f,-0.3165f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.0293f,0.0004f,-0.0131f,-0.9995f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0131f,-0.9995f,0.0293f,0.0004f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3542f,0.8524f,0.1021f],left_rotation:[-0.1842f,0.0458f,-0.2103f,-0.9590f]}}
particle minecraft:cloud -19.99 65.77 16.70 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -19.99 65.57 16.70 0.016 0.02 0.062 1 0 force
particle minecraft:cloud -18.37 65.77 16.29 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -13615
scoreboard players set #gdx driftmountains -1003
scoreboard players set #gy driftmountains 65143
scoreboard players set #gdy driftmountains 46
scoreboard players set #gz driftmountains 18314
scoreboard players set #gdz driftmountains -419
scoreboard players set #gr driftmountains 14074
scoreboard players set #gdr driftmountains 122
scoreboard players set #gp driftmountains -204
scoreboard players set #gdp driftmountains -14
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0001f,-0.0173f,0.9998f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.0123f,0.2341f,0.0509f,0.9708f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.0509f,0.9708f,-0.0123f,-0.2341f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.0293f,0.0004f,-0.0131f,-0.9995f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0131f,-0.9995f,0.0293f,0.0004f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3714f,0.8726f,0.2501f],left_rotation:[-0.1018f,0.1634f,-0.8234f,-0.5339f]}}
particle minecraft:cloud -13.41 65.46 19.91 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -13.41 65.26 19.91 0.041 0.02 0.050 1 0 force
particle minecraft:cloud -12.09 65.46 18.83 0.35 0.18 0.35 0.02 2 force
scoreboard players set #gx driftmountains -6454
scoreboard players set #gdx driftmountains -839
scoreboard players set #gy driftmountains 65000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 21413
scoreboard players set #gdz driftmountains -398
scoreboard players set #gr driftmountains 14366
scoreboard players set #gdr driftmountains -34
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0001f,-0.0174f,0.9998f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.0125f,0.2384f,0.0508f,0.9698f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.0508f,0.9698f,-0.0125f,-0.2384f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.0293f,0.0004f,-0.0131f,-0.9995f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0131f,-0.9995f,0.0293f,0.0004f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3840f,0.8655f,0.1072f],left_rotation:[-0.1131f,0.1542f,-0.8026f,-0.5650f]}}
particle minecraft:cloud -6.38 65.32 22.92 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -6.38 65.12 22.92 0.036 0.02 0.049 1 0 force
particle minecraft:cloud -5.04 65.32 21.93 0.35 0.18 0.35 0.02 2 force
