scoreboard players set #gx driftmountains 11017
scoreboard players set #gdx driftmountains -982
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 61413
scoreboard players set #gdz driftmountains 424
scoreboard players set #gr driftmountains 12346
scoreboard players set #gdr driftmountains 349
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.3780f,-0.3646f,-0.2322f,-0.8187f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.1474f,-0.7988f,0.4184f,0.4064f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.3344f,0.0044f,0.0123f,0.9423f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0123f,0.9423f,0.3344f,0.0044f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3831f,0.8217f,0.0900f],left_rotation:[-0.1124f,-0.1396f,0.7667f,-0.6164f]}}
particle minecraft:cloud 11.61 71.32 62.80 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 11.61 71.12 62.80 0.053 0.02 0.035 1 0 force
particle minecraft:cloud 12.53 71.32 61.41 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains 16813
scoreboard players set #gdx driftmountains -843
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 55629
scoreboard players set #gdz driftmountains 696
scoreboard players set #gr driftmountains 10905
scoreboard players set #gdr driftmountains 211
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.8397f,-0.0906f,-0.4551f,-0.2819f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.4280f,-0.2356f,0.8539f,0.1793f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.3344f,0.0044f,0.0123f,0.9423f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0123f,0.9423f,0.3344f,0.0044f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.4061f,0.8532f,0.2425f],left_rotation:[-0.0574f,-0.1782f,0.9219f,-0.3392f]}}
particle minecraft:cloud 17.82 71.32 56.88 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 17.82 71.12 56.88 0.059 0.02 0.020 1 0 force
particle minecraft:cloud 18.38 71.32 55.27 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains 22089
scoreboard players set #gdx driftmountains -647
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 51913
scoreboard players set #gdz driftmountains 903
scoreboard players set #gr driftmountains 9150
scoreboard players set #gdr driftmountains 207
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.4843f,0.4019f,-0.1889f,0.7538f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.2691f,0.7778f,0.4447f,-0.3533f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.3344f,0.0044f,0.0123f,0.9423f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0123f,0.9423f,0.3344f,0.0044f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3885f,0.8238f,0.0908f],left_rotation:[-0.0935f,-0.1531f,0.8350f,-0.5201f]}}
particle minecraft:cloud 23.33 71.32 52.78 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 23.33 71.12 52.78 0.066 0.02 0.002 1 0 force
particle minecraft:cloud 23.37 71.32 51.11 0.35 0.18 0.35 0.02 3 force
