scoreboard players set #gx driftmountains -70801
scoreboard players set #gdx driftmountains -979
scoreboard players set #gy driftmountains 70351
scoreboard players set #gdy driftmountains -26
scoreboard players set #gz driftmountains 31970
scoreboard players set #gdz driftmountains -1039
scoreboard players set #gr driftmountains 17898
scoreboard players set #gdr driftmountains -56
scoreboard players set #gp driftmountains 76
scoreboard players set #gdp driftmountains 4
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[-0.0028f,-0.0001f,-0.0223f,0.9997f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.3181f,0.3534f,-0.0686f,0.8770f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.1612f,0.8891f,0.2827f,-0.3220f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.8094f,0.0106f,0.0077f,0.5872f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0077f,0.5872f,0.8094f,0.0106f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3541f,0.8352f,0.0953f],left_rotation:[-0.1834f,-0.0252f,0.1688f,-0.9681f]}}
particle minecraft:cloud -71.61 70.67 33.24 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -71.61 70.47 33.24 0.002 0.02 0.085 1 0 force
particle minecraft:cloud -69.94 70.67 33.21 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -62623
scoreboard players set #gdx driftmountains -1067
scoreboard players set #gy driftmountains 70505
scoreboard players set #gdy driftmountains -12
scoreboard players set #gz driftmountains 39134
scoreboard players set #gdz driftmountains -896
scoreboard players set #gr driftmountains 17644
scoreboard players set #gdr driftmountains 115
scoreboard players set #gp driftmountains 27
scoreboard players set #gdp driftmountains 11
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.4177f,-0.3068f,-0.2181f,-0.8269f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.1324f,-0.8086f,0.4522f,0.3524f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.8094f,0.0106f,0.0077f,0.5872f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0077f,0.5872f,0.8094f,0.0106f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3786f,0.8273f,0.2323f],left_rotation:[-0.1684f,-0.0582f,0.3223f,-0.9297f]}}
particle minecraft:cloud -63.39 70.83 40.55 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -63.39 70.63 40.55 0.005 0.02 0.083 1 0 force
particle minecraft:cloud -61.68 70.83 40.44 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -58587
scoreboard players set #gdx driftmountains -1113
scoreboard players set #gy driftmountains 70514
scoreboard players set #gdy driftmountains 2
scoreboard players set #gz driftmountains 42522
scoreboard players set #gdz driftmountains -775
scoreboard players set #gr driftmountains 17270
scoreboard players set #gdr driftmountains 175
scoreboard players set #gp driftmountains -9
scoreboard players set #gdp driftmountains 6
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.8988f,0.1391f,-0.3650f,0.1992f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.3879f,0.2387f,0.8891f,-0.0454f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.8094f,0.0106f,0.0077f,0.5872f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0077f,0.5872f,0.8094f,0.0106f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3634f,0.8247f,0.0912f],left_rotation:[-0.1637f,-0.0784f,0.4496f,-0.8745f]}}
particle minecraft:cloud -59.26 70.83 43.88 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -59.26 70.63 43.88 0.010 0.02 0.082 1 0 force
particle minecraft:cloud -57.60 70.83 43.67 0.35 0.18 0.35 0.02 3 force
