scoreboard players set #gx driftmountains -40411
scoreboard players set #gdx driftmountains 596
scoreboard players set #gy driftmountains 67533
scoreboard players set #gdy driftmountains -17
scoreboard players set #gz driftmountains -91386
scoreboard players set #gdz driftmountains -114
scoreboard players set #gr driftmountains -6585
scoreboard players set #gdr driftmountains 356
scoreboard players set #gp driftmountains 123
scoreboard players set #gdp driftmountains 6
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0001f,-0.0223f,0.9997f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.9781f,0.0605f,-0.1960f,0.0351f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.2008f,0.0559f,0.9771f,0.0420f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.9951f,0.0130f,0.0013f,0.0983f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0013f,0.0983f,0.9951f,0.0130f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3979f,0.8553f,0.1032f],left_rotation:[-0.0513f,0.1803f,-0.9536f,-0.2355f]}}
particle minecraft:cloud -41.22 67.85 -92.66 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -41.22 67.65 -92.66 -0.033 0.02 -0.015 1 0 force
particle minecraft:cloud -41.90 67.85 -91.14 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -45071
scoreboard players set #gdx driftmountains 487
scoreboard players set #gy driftmountains 67646
scoreboard players set #gdy driftmountains -11
scoreboard players set #gz driftmountains -89431
scoreboard players set #gdz driftmountains -334
scoreboard players set #gr driftmountains -8906
scoreboard players set #gdr driftmountains 234
scoreboard players set #gp driftmountains 86
scoreboard players set #gdp driftmountains 1
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[0.0061f,0.0001f,-0.0223f,0.9997f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.9696f,0.0448f,-0.2377f,-0.0371f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.2351f,-0.0123f,0.9702f,0.0569f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.9951f,0.0130f,0.0013f,0.0983f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0013f,0.0983f,0.9951f,0.0130f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3704f,0.8722f,0.2499f],left_rotation:[-0.1051f,0.1611f,-0.8112f,-0.5522f]}}
particle minecraft:cloud -46.42 67.97 -90.31 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -46.42 67.77 -90.31 -0.041 0.02 -0.001 1 0 force
particle minecraft:cloud -46.45 67.97 -88.60 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -48422
scoreboard players set #gdx driftmountains 399
scoreboard players set #gy driftmountains 67733
scoreboard players set #gdy driftmountains -11
scoreboard players set #gz driftmountains -85695
scoreboard players set #gdz driftmountains -498
scoreboard players set #gr driftmountains -10961
scoreboard players set #gdr driftmountains 113
scoreboard players set #gp driftmountains 80
scoreboard players set #gdp driftmountains 2
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[0.0040f,0.0001f,-0.0197f,0.9998f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.9430f,0.1080f,-0.2205f,0.2248f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.2453f,0.2492f,0.9368f,-0.0095f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.9951f,0.0130f,0.0013f,0.0983f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0013f,0.0983f,0.9951f,0.0130f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3832f,0.8658f,0.1073f],left_rotation:[-0.1156f,0.1525f,-0.7928f,-0.5786f]}}
particle minecraft:cloud -49.89 68.05 -86.06 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -49.89 67.85 -86.06 -0.043 0.02 0.015 1 0 force
particle minecraft:cloud -49.33 68.05 -84.49 0.35 0.18 0.35 0.02 3 force
