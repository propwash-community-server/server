scoreboard players set #gx driftmountains 5691
scoreboard players set #gdx driftmountains 451
scoreboard players set #gy driftmountains 70860
scoreboard players set #gdy driftmountains 52
scoreboard players set #gz driftmountains -16702
scoreboard players set #gdz driftmountains 775
scoreboard players set #gr driftmountains 1273
scoreboard players set #gdr driftmountains -41
scoreboard players set #gp driftmountains -258
scoreboard players set #gdp driftmountains 36
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.2028f,-0.3318f,-0.1311f,-0.9119f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.0360f,-0.9031f,0.2388f,0.3550f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.7322f,0.0096f,-0.0089f,-0.6809f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0089f,-0.6809f,0.7322f,0.0096f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3536f,0.8366f,0.0958f],left_rotation:[-0.1845f,-0.0193f,0.1378f,-0.9729f]}}
particle minecraft:cloud 6.78 71.18 -17.75 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 6.78 70.98 -17.75 0.012 0.02 -0.052 1 0 force
particle minecraft:cloud 5.15 71.18 -18.11 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains 2672
scoreboard players set #gdx driftmountains 568
scoreboard players set #gy driftmountains 70491
scoreboard players set #gdy driftmountains 32
scoreboard players set #gz driftmountains -21600
scoreboard players set #gdz driftmountains 678
scoreboard players set #gr driftmountains 371
scoreboard players set #gdr driftmountains 340
scoreboard players set #gp driftmountains -87
scoreboard players set #gdp driftmountains -106
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.7328f,-0.1540f,-0.2735f,-0.6037f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.2115f,-0.5783f,0.7530f,0.2319f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.7322f,0.0096f,-0.0089f,-0.6809f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0089f,-0.6809f,0.7322f,0.0096f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3564f,0.8449f,0.2392f],left_rotation:[-0.1743f,0.0575f,-0.2702f,-0.9452f]}}
particle minecraft:cloud 3.61 70.81 -22.91 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 3.61 70.61 -22.91 0.003 0.02 -0.052 1 0 force
particle minecraft:cloud 1.91 70.81 -23.02 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -1209
scoreboard players set #gdx driftmountains 552
scoreboard players set #gy driftmountains 70524
scoreboard players set #gdy driftmountains -3
scoreboard players set #gz driftmountains -24446
scoreboard players set #gdz driftmountains 386
scoreboard players set #gr driftmountains -1079
scoreboard players set #gdr driftmountains 59
scoreboard players set #gp driftmountains -10
scoreboard players set #gdp driftmountains 47
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.3543f,0.3525f,-0.0842f,0.8621f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.1753f,0.8757f,0.3192f,-0.3172f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.7322f,0.0096f,-0.0089f,-0.6809f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0089f,-0.6809f,0.7322f,0.0096f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3546f,0.8342f,0.0949f],left_rotation:[-0.1824f,-0.0294f,0.1913f,-0.9639f]}}
particle minecraft:cloud -0.62 70.84 -25.84 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -0.62 70.64 -25.84 -0.009 0.02 -0.048 1 0 force
particle minecraft:cloud -2.27 70.84 -25.53 0.35 0.18 0.35 0.02 3 force
