scoreboard players set #gx driftmountains -54278
scoreboard players set #gdx driftmountains -134
scoreboard players set #gy driftmountains 68366
scoreboard players set #gdy driftmountains -15
scoreboard players set #gz driftmountains -55472
scoreboard players set #gdz driftmountains -707
scoreboard players set #gr driftmountains 14397
scoreboard players set #gdr driftmountains 211
scoreboard players set #gp driftmountains 110
scoreboard players set #gdp driftmountains -4
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,0.0001f,0.0157f,0.9999f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.0692f,0.1985f,-0.0394f,-0.9769f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[-0.0630f,-0.9781f,0.0488f,-0.1923f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.8382f,0.0110f,-0.0071f,-0.5452f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0071f,-0.5452f,0.8382f,0.0110f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3993f,0.8348f,0.0951f],left_rotation:[-0.0354f,-0.1782f,0.9585f,-0.2194f]}}
particle minecraft:cloud -54.21 68.69 -53.96 0.35 0.18 0.35 0.02 2 force
particle minecraft:cloud -52.86 68.69 -54.94 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -52.86 68.49 -54.94 0.025 0.02 0.035 1 0 force
scoreboard players set #gx driftmountains -54421
scoreboard players set #gdx driftmountains 86
scoreboard players set #gy driftmountains 68532
scoreboard players set #gdy driftmountains -13
scoreboard players set #gz driftmountains -50056
scoreboard players set #gdz driftmountains -404
scoreboard players set #gr driftmountains 15738
scoreboard players set #gdr driftmountains 36
scoreboard players set #gp driftmountains 139
scoreboard players set #gdp driftmountains 14
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[0.0061f,-0.0001f,0.0211f,0.9998f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.1740f,-0.2544f,0.1021f,0.9458f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[-0.0032f,0.9403f,0.2017f,0.2741f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.8382f,0.0110f,-0.0071f,-0.5452f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0071f,-0.5452f,0.8382f,0.0110f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3943f,0.8307f,0.2337f],left_rotation:[-0.1395f,-0.1133f,0.6006f,-0.7791f]}}
particle minecraft:cloud -54.69 68.85 -48.47 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud -53.11 68.85 -49.12 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -53.11 68.65 -49.12 0.010 0.02 0.024 1 0 force
scoreboard players set #gx driftmountains -55500
scoreboard players set #gdx driftmountains 105
scoreboard players set #gy driftmountains 68690
scoreboard players set #gdy driftmountains -12
scoreboard players set #gz driftmountains -44776
scoreboard players set #gdz driftmountains -397
scoreboard players set #gr driftmountains 16358
scoreboard players set #gdr driftmountains -79
scoreboard players set #gp driftmountains 145
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,0.0001f,0.0192f,0.9998f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.2704f,0.2319f,0.0112f,-0.9343f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[-0.1094f,-0.9407f,0.2475f,-0.2048f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.8382f,0.0110f,-0.0071f,-0.5452f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0071f,-0.5452f,0.8382f,0.0110f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3905f,0.8249f,0.0912f],left_rotation:[-0.0860f,-0.1576f,0.8579f,-0.4813f]}}
particle minecraft:cloud -55.94 69.01 -43.33 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud -54.34 69.01 -43.80 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -54.34 68.81 -43.80 0.012 0.02 0.041 1 0 force
