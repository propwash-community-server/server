scoreboard players set #gx driftmountains -1422
scoreboard players set #gdx driftmountains 835
scoreboard players set #gy driftmountains 66888
scoreboard players set #gdy driftmountains -11
scoreboard players set #gz driftmountains -72387
scoreboard players set #gdz driftmountains 561
scoreboard players set #gr driftmountains -4992
scoreboard players set #gdr driftmountains -37
scoreboard players set #gp driftmountains 61
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0000f,-0.0038f,1.0000f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.3123f,0.0665f,0.0333f,0.9471f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.0661f,0.9488f,0.3070f,-0.0340f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.8801f,0.0115f,0.0062f,0.4747f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0062f,0.4747f,0.8801f,0.0115f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3635f,0.8246f,0.0911f],left_rotation:[0.1634f,0.0790f,-0.4525f,0.8731f]}}
scoreboard players set #gx driftmountains -8365
scoreboard players set #gdx driftmountains 831
scoreboard players set #gy driftmountains 66976
scoreboard players set #gdy driftmountains -11
scoreboard players set #gz driftmountains -76594
scoreboard players set #gdz driftmountains 528
scoreboard players set #gr driftmountains -4527
scoreboard players set #gdr driftmountains -113
scoreboard players set #gp driftmountains 62
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0000f,-0.0075f,1.0000f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.3595f,-0.0796f,-0.0874f,-0.9256f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[-0.0094f,-0.9215f,0.3698f,0.1179f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.8801f,0.0115f,0.0062f,0.4747f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0062f,0.4747f,0.8801f,0.0115f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.4042f,0.8414f,0.2379f],left_rotation:[0.0987f,0.1546f,-0.8067f,0.5618f]}}
particle minecraft:cloud -8.73 67.30 -78.16 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -8.73 67.10 -78.16 -0.041 0.02 -0.041 1 0 force
particle minecraft:cloud -9.94 67.30 -76.95 0.35 0.18 0.35 0.02 2 force
scoreboard players set #gx driftmountains -16274
scoreboard players set #gdx driftmountains 769
scoreboard players set #gy driftmountains 67088
scoreboard players set #gdy driftmountains -11
scoreboard players set #gz driftmountains -82186
scoreboard players set #gdz driftmountains 503
scoreboard players set #gr driftmountains -3137
scoreboard players set #gdr driftmountains -87
scoreboard players set #gp driftmountains 62
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0001f,-0.0156f,0.9999f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.2820f,0.2234f,-0.0115f,0.9330f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.1096f,0.9393f,0.2601f,-0.1950f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.8801f,0.0115f,0.0062f,0.4747f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0062f,0.4747f,0.8801f,0.0115f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3923f,0.8614f,0.1056f],left_rotation:[-0.0824f,0.1707f,-0.8962f,-0.4011f]}}
particle minecraft:cloud -16.22 67.41 -83.70 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -16.22 67.21 -83.70 -0.029 0.02 -0.047 1 0 force
particle minecraft:cloud -17.64 67.41 -82.83 0.35 0.18 0.35 0.02 2 force
