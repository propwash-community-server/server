scoreboard players set #gx driftmountains -4271
scoreboard players set #gdx driftmountains -978
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 62084
scoreboard players set #gdz driftmountains -310
scoreboard players set #gr driftmountains 15941
scoreboard players set #gdr driftmountains -56
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.3108f,0.4298f,-0.0965f,0.8422f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.1856f,0.8570f,0.2673f,-0.3995f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.8865f,0.0116f,0.0061f,0.4626f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0061f,0.4626f,0.8865f,0.0116f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3869f,0.8230f,0.0905f],left_rotation:[-0.0995f,-0.1492f,0.8154f,-0.5504f]}}
particle minecraft:cloud -4.61 71.32 63.56 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -4.61 71.12 63.56 0.022 0.02 0.057 1 0 force
particle minecraft:cloud -3.05 71.32 62.97 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains 3302
scoreboard players set #gdx driftmountains -1002
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 61200
scoreboard players set #gdz driftmountains 24
scoreboard players set #gr driftmountains 14668
scoreboard players set #gdr driftmountains 72
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.3975f,-0.3764f,-0.2531f,-0.7976f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.1707f,-0.7754f,0.4392f,0.4203f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.8865f,0.0116f,0.0061f,0.4626f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0061f,0.4626f,0.8865f,0.0116f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.4061f,0.8482f,0.2405f],left_rotation:[-0.0754f,-0.1696f,0.8804f,-0.4365f]}}
particle minecraft:cloud 3.34 71.32 62.81 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 3.34 71.12 62.81 0.032 0.02 0.049 1 0 force
particle minecraft:cloud 4.77 71.32 61.87 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains 9818
scoreboard players set #gdx driftmountains -940
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 61891
scoreboard players set #gdz driftmountains 279
scoreboard players set #gr driftmountains 13398
scoreboard players set #gdr driftmountains 268
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.8677f,0.1541f,-0.4336f,0.1878f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.4557f,0.2345f,0.8563f,-0.0637f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.8865f,0.0116f,0.0061f,0.4626f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0061f,0.4626f,0.8865f,0.0116f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3949f,0.8284f,0.0926f],left_rotation:[-0.0656f,-0.1679f,0.9089f,-0.3760f]}}
particle minecraft:cloud 10.14 71.32 63.37 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 10.14 71.12 63.37 0.046 0.02 0.044 1 0 force
particle minecraft:cloud 11.30 71.32 62.17 0.35 0.18 0.35 0.02 3 force
