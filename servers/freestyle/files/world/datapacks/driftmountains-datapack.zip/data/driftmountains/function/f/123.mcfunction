scoreboard players set #gx driftmountains 6595
scoreboard players set #gdx driftmountains 454
scoreboard players set #gy driftmountains 70953
scoreboard players set #gdy driftmountains 31
scoreboard players set #gz driftmountains -15145
scoreboard players set #gdz driftmountains 790
scoreboard players set #gr driftmountains 1143
scoreboard players set #gdr driftmountains -71
scoreboard players set #gp driftmountains -171
scoreboard players set #gdp driftmountains 50
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.6327f,-0.2190f,-0.2769f,-0.6892f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.2060f,-0.6639f,0.6592f,0.2867f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.9757f,0.0128f,-0.0029f,-0.2188f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0029f,-0.2188f,0.9757f,0.0128f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3531f,0.8382f,0.0965f],left_rotation:[-0.1856f,-0.0125f,0.1016f,-0.9772f]}}
particle minecraft:cloud 7.66 71.27 -16.21 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 7.66 71.07 -16.21 0.011 0.02 -0.053 1 0 force
particle minecraft:cloud 6.03 71.27 -16.55 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains 3746
scoreboard players set #gdx driftmountains 486
scoreboard players set #gy driftmountains 70571
scoreboard players set #gdy driftmountains 60
scoreboard players set #gz driftmountains -20248
scoreboard players set #gdz driftmountains 715
scoreboard players set #gr driftmountains 973
scoreboard players set #gdr driftmountains 219
scoreboard players set #gp driftmountains -255
scoreboard players set #gdp driftmountains -48
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.9365f,0.0080f,-0.3217f,-0.1392f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.3088f,-0.1062f,0.9408f,0.0904f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.9757f,0.0128f,-0.0029f,-0.2188f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0029f,-0.2188f,0.9757f,0.0128f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3577f,0.8415f,0.2379f],left_rotation:[-0.1772f,0.0433f,-0.1969f,-0.9633f]}}
particle minecraft:cloud 4.82 70.89 -21.45 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 4.82 70.69 -21.45 0.009 0.02 -0.051 1 0 force
particle minecraft:cloud 3.13 70.89 -21.74 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -39
scoreboard players set #gdx driftmountains 699
scoreboard players set #gy driftmountains 70512
scoreboard players set #gdy driftmountains -14
scoreboard players set #gz driftmountains -23611
scoreboard players set #gdz driftmountains 535
scoreboard players set #gr driftmountains -866
scoreboard players set #gdr driftmountains 193
scoreboard players set #gp driftmountains 51
scoreboard players set #gdp driftmountains 20
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.2369f,-0.3158f,-0.1399f,-0.9081f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.0453f,-0.8984f,0.2714f,0.3425f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.9757f,0.0128f,-0.0029f,-0.2188f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0029f,-0.2188f,0.9757f,0.0128f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3524f,0.8415f,0.0978f],left_rotation:[-0.1870f,0.0012f,0.0286f,-0.9819f]}}
particle minecraft:cloud 0.60 70.83 -24.98 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 0.60 70.63 -24.98 -0.008 0.02 -0.050 1 0 force
particle minecraft:cloud -1.05 70.83 -24.73 0.35 0.18 0.35 0.02 3 force
