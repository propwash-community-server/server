scoreboard players set #gx driftmountains 25462
scoreboard players set #gdx driftmountains -396
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 44213
scoreboard players set #gdz driftmountains 969
scoreboard players set #gr driftmountains 7494
scoreboard players set #gdr driftmountains 131
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.3128f,0.4117f,-0.0899f,0.8512f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.1799f,0.8653f,0.2712f,-0.3811f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.9237f,0.0121f,0.0050f,0.3830f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0050f,0.3830f,0.9237f,0.0121f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3778f,0.8210f,0.0897f],left_rotation:[-0.1281f,-0.1256f,0.6947f,-0.6965f]}}
particle minecraft:cloud 26.90 71.32 44.69 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 26.90 71.12 44.69 0.060 0.02 -0.016 1 0 force
particle minecraft:cloud 26.46 71.32 43.08 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains 28315
scoreboard players set #gdx driftmountains -151
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 36639
scoreboard players set #gdz driftmountains 982
scoreboard players set #gr driftmountains 7126
scoreboard players set #gdr driftmountains 321
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[-0.0008f,-0.0000f,-0.0223f,0.9998f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.3936f,-0.3883f,-0.2590f,-0.7919f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.1772f,-0.7691f,0.4366f,0.4318f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.9237f,0.0121f,0.0050f,0.3830f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0050f,0.3830f,0.9237f,0.0121f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.4060f,0.8545f,0.2430f],left_rotation:[-0.0525f,-0.1801f,0.9311f,-0.3130f]}}
particle minecraft:cloud 29.88 71.32 37.01 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 29.88 71.12 37.01 0.057 0.02 -0.019 1 0 force
particle minecraft:cloud 29.33 71.32 35.39 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains 26744
scoreboard players set #gdx driftmountains 206
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 32033
scoreboard players set #gdz driftmountains 948
scoreboard players set #gr driftmountains 4312
scoreboard players set #gdr driftmountains 321
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.8833f,0.1470f,-0.4009f,0.1935f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.4235f,0.2367f,0.8727f,-0.0549f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.9237f,0.0121f,0.0050f,0.3830f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0050f,0.3830f,0.9237f,0.0121f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3805f,0.8212f,0.0898f],left_rotation:[-0.1202f,-0.1330f,0.7327f,-0.6565f]}}
particle minecraft:cloud 28.21 71.32 31.68 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 28.21 71.12 31.68 0.039 0.02 -0.042 1 0 force
particle minecraft:cloud 27.00 71.32 30.54 0.35 0.18 0.35 0.02 3 force
