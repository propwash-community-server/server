scoreboard players set #gx driftmountains -89378
scoreboard players set #gdx driftmountains -719
scoreboard players set #gy driftmountains 69983
scoreboard players set #gdy driftmountains 2
scoreboard players set #gz driftmountains 10688
scoreboard players set #gdz driftmountains -856
scoreboard players set #gr driftmountains 17856
scoreboard players set #gdr driftmountains 97
scoreboard players set #gp driftmountains -6
scoreboard players set #gdp driftmountains -4
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.7206f,0.2542f,-0.2153f,0.6081f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.2804f,0.6341f,0.6978f,-0.1799f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.9875f,0.0129f,0.0021f,0.1571f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0021f,0.1571f,0.9875f,0.0129f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3526f,0.8470f,0.0999f],left_rotation:[-0.1870f,0.0233f,-0.0893f,-0.9780f]}}
particle minecraft:cloud -90.18 70.30 11.97 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -90.18 70.10 11.97 0.002 0.02 0.067 1 0 force
particle minecraft:cloud -88.51 70.30 11.93 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -83290
scoreboard players set #gdx driftmountains -855
scoreboard players set #gy driftmountains 70031
scoreboard players set #gdy driftmountains -14
scoreboard players set #gz driftmountains 17993
scoreboard players set #gdz driftmountains -975
scoreboard players set #gr driftmountains 17416
scoreboard players set #gdr driftmountains 31
scoreboard players set #gp driftmountains 54
scoreboard players set #gdp driftmountains -7
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[0.0061f,0.0001f,-0.0217f,0.9997f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.0488f,0.3011f,0.0395f,0.9515f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.0603f,0.9526f,0.0174f,-0.2976f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.9875f,0.0129f,0.0021f,0.1571f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0021f,0.1571f,0.9875f,0.0129f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3557f,0.8495f,0.2411f],left_rotation:[-0.1690f,0.0753f,-0.3620f,-0.9136f]}}
particle minecraft:cloud -84.00 70.35 19.44 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -84.00 70.15 19.44 0.007 0.02 0.071 1 0 force
particle minecraft:cloud -82.30 70.35 19.26 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -79079
scoreboard players set #gdx driftmountains -816
scoreboard players set #gy driftmountains 70116
scoreboard players set #gdy driftmountains -20
scoreboard players set #gz driftmountains 22219
scoreboard players set #gdz driftmountains -895
scoreboard players set #gr driftmountains 17676
scoreboard players set #gdr driftmountains -98
scoreboard players set #gp driftmountains 74
scoreboard players set #gdp driftmountains -2
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.8988f,-0.0459f,-0.3341f,-0.2800f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.3065f,-0.2464f,0.9086f,0.1406f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.9875f,0.0129f,0.0021f,0.1571f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0021f,0.1571f,0.9875f,0.0129f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3524f,0.8452f,0.0992f],left_rotation:[-0.1873f,0.0160f,-0.0503f,-0.9808f]}}
particle minecraft:cloud -79.84 70.44 23.52 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -79.84 70.24 23.52 0.004 0.02 0.072 1 0 force
particle minecraft:cloud -78.17 70.44 23.43 0.35 0.18 0.35 0.02 3 force
