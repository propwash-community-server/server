scoreboard players set #gx driftmountains -87161
scoreboard players set #gdx driftmountains -748
scoreboard players set #gy driftmountains 69985
scoreboard players set #gdy driftmountains -2
scoreboard players set #gz driftmountains 13320
scoreboard players set #gdz driftmountains -888
scoreboard players set #gr driftmountains 17653
scoreboard players set #gdr driftmountains 51
scoreboard players set #gp driftmountains 13
scoreboard players set #gdp driftmountains -8
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[0.0061f,0.0001f,-0.0223f,0.9997f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.0791f,0.3172f,0.0288f,0.9446f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.0703f,0.9468f,0.0462f,-0.3106f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.5931f,0.0078f,0.0105f,0.8050f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0105f,0.8050f,0.5931f,0.0078f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3545f,0.8532f,0.1024f],left_rotation:[-0.1835f,0.0491f,-0.2279f,-0.9549f]}}
particle minecraft:cloud -87.92 70.31 14.63 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -87.92 70.11 14.63 0.004 0.02 0.070 1 0 force
particle minecraft:cloud -86.25 70.31 14.53 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -80821
scoreboard players set #gdx driftmountains -849
scoreboard players set #gy driftmountains 70081
scoreboard players set #gdy driftmountains -18
scoreboard players set #gz driftmountains 20756
scoreboard players set #gdz driftmountains -944
scoreboard players set #gr driftmountains 17381
scoreboard players set #gdr driftmountains -1
scoreboard players set #gp driftmountains 70
scoreboard players set #gdp driftmountains -5
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[0.0061f,0.0001f,-0.0219f,0.9997f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.6372f,-0.1883f,-0.2438f,-0.7065f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.1709f,-0.6847f,0.6605f,0.2563f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.5931f,0.0078f,0.0105f,0.8050f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0105f,0.8050f,0.5931f,0.0078f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3559f,0.8475f,0.2403f],left_rotation:[-0.1715f,0.0677f,-0.3227f,-0.9284f]}}
particle minecraft:cloud -81.52 70.40 22.21 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -81.52 70.20 22.21 0.008 0.02 0.075 1 0 force
particle minecraft:cloud -79.82 70.40 22.02 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -76582
scoreboard players set #gdx driftmountains -788
scoreboard players set #gy driftmountains 70180
scoreboard players set #gdy driftmountains -21
scoreboard players set #gz driftmountains 24951
scoreboard players set #gdz driftmountains -861
scoreboard players set #gr driftmountains 17664
scoreboard players set #gdr driftmountains 10
scoreboard players set #gp driftmountains 81
scoreboard players set #gdp driftmountains -2
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.8336f,0.2037f,-0.2686f,0.4376f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.3161f,0.4683f,0.8167f,-0.1173f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.5931f,0.0078f,0.0105f,0.8050f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0105f,0.8050f,0.5931f,0.0078f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3524f,0.8452f,0.0992f],left_rotation:[-0.1873f,0.0161f,-0.0510f,-0.9808f]}}
particle minecraft:cloud -77.34 70.50 26.26 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -77.34 70.30 26.26 0.004 0.02 0.074 1 0 force
particle minecraft:cloud -75.67 70.50 26.16 0.35 0.18 0.35 0.02 3 force
