scoreboard players set #gx driftmountains -16559
scoreboard players set #gdx driftmountains -1066
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 58540
scoreboard players set #gdz driftmountains -319
scoreboard players set #gr driftmountains 15271
scoreboard players set #gdr driftmountains 17
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.3155f,0.3838f,-0.0797f,0.8642f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.1709f,0.8773f,0.2769f,-0.3527f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.8725f,0.0114f,0.0064f,0.4884f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0064f,0.4884f,0.8725f,0.0114f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3640f,0.8244f,0.0910f],left_rotation:[-0.1624f,-0.0808f,0.4618f,-0.8682f]}}
particle minecraft:cloud -16.72 71.32 60.04 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -16.72 71.12 60.04 0.031 0.02 0.059 1 0 force
particle minecraft:cloud -15.24 71.32 59.28 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -7964
scoreboard players set #gdx driftmountains -939
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 60695
scoreboard players set #gdz driftmountains -239
scoreboard players set #gr driftmountains 15296
scoreboard players set #gdr driftmountains -31
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.4138f,-0.3210f,-0.2254f,-0.8215f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.1402f,-0.8023f,0.4499f,0.3663f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.8725f,0.0114f,0.0064f,0.4884f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0064f,0.4884f,0.8725f,0.0114f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3865f,0.8277f,0.2325f],left_rotation:[-0.1564f,-0.0861f,0.4636f,-0.8679f]}}
particle minecraft:cloud -8.11 71.32 62.30 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -8.11 71.12 62.30 0.026 0.02 0.051 1 0 force
particle minecraft:cloud -6.58 71.32 61.52 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -2857
scoreboard players set #gdx driftmountains -1018
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 62183
scoreboard players set #gdz driftmountains -231
scoreboard players set #gr driftmountains 15598
scoreboard players set #gdr driftmountains 3
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.8830f,0.1471f,-0.4015f,0.1934f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.4240f,0.2366f,0.8725f,-0.0551f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.8725f,0.0114f,0.0064f,0.4884f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0064f,0.4884f,0.8725f,0.0114f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3808f,0.8213f,0.0898f],left_rotation:[-0.1194f,-0.1337f,0.7365f,-0.6521f]}}
particle minecraft:cloud -3.11 71.32 63.67 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -3.11 71.12 63.67 0.026 0.02 0.059 1 0 force
particle minecraft:cloud -1.58 71.32 62.99 0.35 0.18 0.35 0.02 3 force
