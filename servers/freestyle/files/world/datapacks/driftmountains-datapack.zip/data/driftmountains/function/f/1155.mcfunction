scoreboard players set #gx driftmountains -98077
scoreboard players set #gdx driftmountains -49
scoreboard players set #gy driftmountains 70021
scoreboard players set #gdy driftmountains -7
scoreboard players set #gz driftmountains -6751
scoreboard players set #gdz driftmountains -872
scoreboard players set #gr driftmountains -13514
scoreboard players set #gdr driftmountains 216
scoreboard players set #gp driftmountains 25
scoreboard players set #gdp driftmountains 6
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.8720f,-0.0730f,-0.3656f,-0.3171f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.3342f,-0.2805f,0.8845f,0.1651f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.6670f,0.0087f,-0.0098f,-0.7449f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0098f,-0.7449f,0.6670f,0.0087f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3571f,0.8302f,0.0933f],left_rotation:[-0.1771f,-0.0479f,0.2889f,-0.9396f]}}
particle minecraft:cloud -99.56 70.34 -6.45 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -99.56 70.14 -6.45 -0.037 0.02 0.037 1 0 force
particle minecraft:cloud -98.37 70.34 -5.27 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -96273
scoreboard players set #gdx driftmountains -354
scoreboard players set #gy driftmountains 70026
scoreboard players set #gdy driftmountains 3
scoreboard players set #gz driftmountains 1194
scoreboard players set #gdz driftmountains -856
scoreboard players set #gr driftmountains -15339
scoreboard players set #gdr driftmountains 277
scoreboard players set #gp driftmountains -12
scoreboard players set #gdp driftmountains 2
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[0.0030f,0.0001f,-0.0223f,0.9997f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.8296f,0.2145f,-0.2995f,0.4196f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.3452f,0.4534f,0.8116f,-0.1285f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.6670f,0.0087f,-0.0098f,-0.7449f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0098f,-0.7449f,0.6670f,0.0087f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3746f,0.8279f,0.2326f],left_rotation:[-0.1730f,-0.0434f,0.2473f,-0.9524f]}}
particle minecraft:cloud -97.65 70.35 2.03 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -97.65 70.15 2.03 -0.025 0.02 0.050 1 0 force
particle minecraft:cloud -96.12 70.35 2.80 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -93467
scoreboard players set #gdx driftmountains -570
scoreboard players set #gy driftmountains 70004
scoreboard players set #gdy driftmountains 4
scoreboard players set #gz driftmountains 5887
scoreboard players set #gdz driftmountains -769
scoreboard players set #gr driftmountains -17013
scoreboard players set #gdr driftmountains 307
scoreboard players set #gp driftmountains -17
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.2027f,-0.3417f,-0.1339f,-0.9078f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.0392f,-0.8988f,0.2398f,0.3649f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.6670f,0.0087f,-0.0098f,-0.7449f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0098f,-0.7449f,0.6670f,0.0087f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3556f,0.8324f,0.0942f],left_rotation:[-0.1803f,-0.0377f,0.2352f,-0.9543f]}}
particle minecraft:cloud -94.51 70.32 6.99 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -94.51 70.12 6.99 -0.010 0.02 0.057 1 0 force
particle minecraft:cloud -92.86 70.32 7.27 0.35 0.18 0.35 0.02 3 force
