scoreboard players set #gx driftmountains -94091
scoreboard players set #gdx driftmountains -555
scoreboard players set #gy driftmountains 70009
scoreboard players set #gdy driftmountains 5
scoreboard players set #gz driftmountains 4830
scoreboard players set #gdz driftmountains -851
scoreboard players set #gr driftmountains -16624
scoreboard players set #gdr driftmountains 302
scoreboard players set #gp driftmountains -17
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.5333f,0.3284f,-0.1611f,0.7628f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.2422f,0.7839f,0.5017f,-0.2742f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.9061f,0.0119f,0.0055f,0.4229f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0055f,0.4229f,0.9061f,0.0119f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3553f,0.8328f,0.0944f],left_rotation:[-0.1809f,-0.0355f,0.2237f,-0.9570f]}}
particle minecraft:cloud -95.20 70.33 5.86 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -95.20 70.13 5.86 -0.015 0.02 0.060 1 0 force
particle minecraft:cloud -93.58 70.33 6.25 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -88576
scoreboard players set #gdx driftmountains -715
scoreboard players set #gy driftmountains 69983
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 11859
scoreboard players set #gdz driftmountains -838
scoreboard players set #gr driftmountains 17667
scoreboard players set #gdr driftmountains 92
scoreboard players set #gp driftmountains 1
scoreboard players set #gdp driftmountains -5
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.1971f,-0.2970f,-0.1196f,-0.9266f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.0228f,-0.9192f,0.2294f,0.3193f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.9061f,0.0119f,0.0055f,0.4229f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0055f,0.4229f,0.9061f,0.0119f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3574f,0.8422f,0.2382f],left_rotation:[-0.1767f,0.0462f,-0.2120f,-0.9601f]}}
particle minecraft:cloud -89.35 70.30 13.27 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -89.35 70.10 13.27 0.004 0.02 0.065 1 0 force
particle minecraft:cloud -87.64 70.30 13.17 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -84571
scoreboard players set #gdx driftmountains -737
scoreboard players set #gy driftmountains 70007
scoreboard players set #gdy driftmountains -9
scoreboard players set #gz driftmountains 16133
scoreboard players set #gdz driftmountains -835
scoreboard players set #gr driftmountains 17474
scoreboard players set #gdr driftmountains 18
scoreboard players set #gp driftmountains 40
scoreboard players set #gdp driftmountains -8
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.9493f,0.0431f,-0.3094f,-0.0367f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.3072f,-0.0043f,0.9500f,0.0564f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.9061f,0.0119f,0.0055f,0.4229f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0055f,0.4229f,0.9061f,0.0119f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3559f,0.8556f,0.1033f],left_rotation:[-0.1810f,0.0596f,-0.2845f,-0.9395f]}}
particle minecraft:cloud -85.29 70.33 17.46 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -85.29 70.13 17.46 0.006 0.02 0.066 1 0 force
particle minecraft:cloud -83.62 70.33 17.31 0.35 0.18 0.35 0.02 3 force
