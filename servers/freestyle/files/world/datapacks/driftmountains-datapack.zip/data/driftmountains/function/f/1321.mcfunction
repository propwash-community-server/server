scoreboard players set #gx driftmountains -42752
scoreboard players set #gdx driftmountains 588
scoreboard players set #gy driftmountains 67594
scoreboard players set #gdy driftmountains -15
scoreboard players set #gz driftmountains -90543
scoreboard players set #gdz driftmountains -264
scoreboard players set #gr driftmountains -7926
scoreboard players set #gdr driftmountains 318
scoreboard players set #gp driftmountains 106
scoreboard players set #gdp driftmountains 4
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[0.0061f,0.0001f,-0.0222f,0.9997f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.8044f,0.1692f,-0.1528f,0.5486f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.2113f,0.5677f,0.7910f,-0.0856f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.5747f,0.0075f,-0.0107f,-0.8183f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0107f,-0.8183f,0.5747f,0.0075f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3907f,0.8625f,0.1060f],left_rotation:[-0.0892f,0.1677f,-0.8790f,-0.4372f]}}
particle minecraft:cloud -43.83 67.91 -91.60 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -43.83 67.71 -91.60 -0.038 0.02 -0.007 1 0 force
particle minecraft:cloud -44.15 67.91 -89.96 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -47047
scoreboard players set #gdx driftmountains 532
scoreboard players set #gy driftmountains 67691
scoreboard players set #gdy driftmountains -12
scoreboard players set #gz driftmountains -87810
scoreboard players set #gdz driftmountains -475
scoreboard players set #gr driftmountains -9703
scoreboard players set #gdr driftmountains 197
scoreboard players set #gp driftmountains 79
scoreboard players set #gdp driftmountains 2
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[0.0061f,0.0001f,-0.0218f,0.9997f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.7783f,0.1918f,-0.1691f,0.5735f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.2303f,0.5945f,0.7624f,-0.1110f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.5747f,0.0075f,-0.0107f,-0.8183f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0107f,-0.8183f,0.5747f,0.0075f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3647f,0.8688f,0.2486f],left_rotation:[-0.1235f,0.1460f,-0.7311f,-0.6550f]}}
particle minecraft:cloud -48.51 68.01 -88.49 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -48.51 67.81 -88.49 -0.043 0.02 0.005 1 0 force
particle minecraft:cloud -48.30 68.01 -86.79 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -50250
scoreboard players set #gdx driftmountains 459
scoreboard players set #gy driftmountains 67785
scoreboard players set #gdy driftmountains -14
scoreboard players set #gz driftmountains -83142
scoreboard players set #gdz driftmountains -690
scoreboard players set #gr driftmountains -11570
scoreboard players set #gdr driftmountains 165
scoreboard players set #gp driftmountains 83
scoreboard players set #gdp driftmountains 1
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0001f,-0.0191f,0.9998f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.1056f,-0.2259f,-0.0789f,-0.9652f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[-0.0221f,-0.9622f,0.1299f,0.2383f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.5747f,0.0075f,-0.0107f,-0.8183f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0107f,-0.8183f,0.5747f,0.0075f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3860f,0.8649f,0.1069f],left_rotation:[-0.1066f,0.1584f,-0.8259f,-0.5305f]}}
particle minecraft:cloud -51.75 68.11 -83.35 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -51.75 67.91 -83.35 -0.041 0.02 0.020 1 0 force
particle minecraft:cloud -51.02 68.11 -81.84 0.35 0.18 0.35 0.02 3 force
