scoreboard players set #gx driftmountains -54666
scoreboard players set #gdx driftmountains -1197
scoreboard players set #gy driftmountains 70496
scoreboard players set #gdy driftmountains 7
scoreboard players set #gz driftmountains 44798
scoreboard players set #gdz driftmountains -629
scoreboard players set #gr driftmountains 16481
scoreboard players set #gdr driftmountains 189
scoreboard players set #gp driftmountains -20
scoreboard players set #gdp driftmountains 2
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.3886f,-0.3252f,-0.2139f,-0.8352f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.1273f,-0.8173f,0.4249f,0.3678f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.1932f,0.0025f,0.0128f,0.9811f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0128f,0.9811f,0.1932f,0.0025f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3629f,0.8250f,0.0913f],left_rotation:[-0.1649f,-0.0762f,0.4381f,-0.8803f]}}
particle minecraft:cloud -55.14 70.82 46.23 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -55.14 70.62 46.23 0.021 0.02 0.078 1 0 force
particle minecraft:cloud -53.53 70.82 45.80 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -44538
scoreboard players set #gdx driftmountains -1190
scoreboard players set #gy driftmountains 70478
scoreboard players set #gdy driftmountains -7
scoreboard players set #gz driftmountains 49134
scoreboard players set #gdz driftmountains -500
scoreboard players set #gr driftmountains 15574
scoreboard players set #gdr driftmountains 43
scoreboard players set #gp driftmountains 28
scoreboard players set #gdp driftmountains -12
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.8847f,-0.0590f,-0.3600f,-0.2902f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.3315f,-0.2539f,0.8958f,0.1523f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.1932f,0.0025f,0.0128f,0.9811f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0128f,0.9811f,0.1932f,0.0025f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3729f,0.8284f,0.2328f],left_rotation:[-0.1746f,-0.0369f,0.2142f,-0.9604f]}}
particle minecraft:cloud -44.76 70.80 50.73 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -44.76 70.60 50.73 0.032 0.02 0.072 1 0 force
particle minecraft:cloud -43.20 70.80 50.03 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -39911
scoreboard players set #gdx driftmountains -1219
scoreboard players set #gy driftmountains 70554
scoreboard players set #gdy driftmountains -28
scoreboard players set #gz driftmountains 51479
scoreboard players set #gdz driftmountains -451
scoreboard players set #gr driftmountains 15411
scoreboard players set #gdr driftmountains 36
scoreboard players set #gp driftmountains 96
scoreboard players set #gdp driftmountains -17
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.4984f,0.3374f,-0.1476f,0.7849f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.2309f,0.8047f,0.4657f,-0.2868f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.1932f,0.0025f,0.0128f,0.9811f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0128f,0.9811f,0.1932f,0.0025f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3559f,0.8319f,0.0940f],left_rotation:[-0.1797f,-0.0398f,0.2465f,-0.9515f]}}
particle minecraft:cloud -40.11 70.87 52.98 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -40.11 70.67 52.98 0.034 0.02 0.071 1 0 force
particle minecraft:cloud -38.61 70.87 52.25 0.35 0.18 0.35 0.02 3 force
