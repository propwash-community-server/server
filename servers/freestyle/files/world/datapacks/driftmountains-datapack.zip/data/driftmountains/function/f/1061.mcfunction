scoreboard players set #gx driftmountains -12357
scoreboard players set #gdx driftmountains -1041
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 59770
scoreboard players set #gdz driftmountains -301
scoreboard players set #gr driftmountains 15223
scoreboard players set #gdr driftmountains 3
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.9062f,0.1229f,-0.3722f,0.1588f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.3909f,0.1988f,0.8983f,-0.0283f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.8542f,0.0112f,-0.0068f,-0.5198f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0068f,-0.5198f,0.8542f,0.0112f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3639f,0.8244f,0.0910f],left_rotation:[-0.1624f,-0.0807f,0.4614f,-0.8684f]}}
particle minecraft:cloud -12.51 71.32 61.27 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -12.51 71.12 61.27 0.030 0.02 0.057 1 0 force
particle minecraft:cloud -11.03 71.32 60.50 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -4310
scoreboard players set #gdx driftmountains -827
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 61339
scoreboard players set #gdz driftmountains -68
scoreboard players set #gr driftmountains 14499
scoreboard players set #gdr driftmountains 238
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[0.0029f,0.0001f,-0.0223f,0.9997f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.5093f,0.3322f,-0.1500f,0.7796f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.2328f,0.7996f,0.4772f,-0.2805f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.8542f,0.0112f,-0.0068f,-0.5198f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0068f,-0.5198f,0.8542f,0.0112f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3727f,0.8284f,0.2328f],left_rotation:[-0.1747f,-0.0363f,0.2111f,-0.9610f]}}
particle minecraft:cloud -4.23 71.32 62.95 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -4.23 71.12 62.95 0.031 0.02 0.044 1 0 force
particle minecraft:cloud -2.83 71.32 61.97 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains 1379
scoreboard players set #gdx driftmountains -1039
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 62794
scoreboard players set #gdz driftmountains -94
scoreboard players set #gr driftmountains 15216
scoreboard players set #gdr driftmountains 93
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.6005f,-0.2909f,-0.3434f,-0.6609f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.2758f,-0.6285f,0.6344f,0.3556f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.8542f,0.0112f,-0.0068f,-0.5198f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0068f,-0.5198f,0.8542f,0.0112f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3911f,0.8252f,0.0914f],left_rotation:[-0.0835f,-0.1590f,0.8649f,-0.4686f]}}
particle minecraft:cloud 1.23 71.32 64.30 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 1.23 71.12 64.30 0.031 0.02 0.058 1 0 force
particle minecraft:cloud 2.71 71.32 63.52 0.35 0.18 0.35 0.02 3 force
