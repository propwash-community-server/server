scoreboard players set #gx driftmountains -55966
scoreboard players set #gdx driftmountains 257
scoreboard players set #gy driftmountains 68800
scoreboard players set #gdy driftmountains -19
scoreboard players set #gz driftmountains -40894
scoreboard players set #gdz driftmountains -608
scoreboard players set #gr driftmountains 17109
scoreboard players set #gdr driftmountains -212
scoreboard players set #gp driftmountains 138
scoreboard players set #gdp driftmountains -1
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.4093f,0.2152f,0.0405f,-0.8857f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[-0.1338f,-0.8948f,0.3890f,-0.1734f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.1568f,0.0021f,-0.0129f,-0.9875f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0129f,-0.9875f,0.1568f,0.0021f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3951f,0.8287f,0.0927f],left_rotation:[-0.0642f,-0.1684f,0.9117f,-0.3691f]}}
particle minecraft:cloud -56.60 69.12 -39.52 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud -54.95 69.12 -39.78 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -54.95 68.92 -39.78 0.006 0.02 0.039 1 0 force
scoreboard players set #gx driftmountains -59538
scoreboard players set #gdx driftmountains 374
scoreboard players set #gy driftmountains 68935
scoreboard players set #gdy driftmountains -19
scoreboard players set #gz driftmountains -38016
scoreboard players set #gdz driftmountains -458
scoreboard players set #gr driftmountains -17629
scoreboard players set #gdr driftmountains -68
scoreboard players set #gp driftmountains 152
scoreboard players set #gdp driftmountains -2
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[-0.0039f,0.0001f,0.0220f,0.9998f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.7734f,0.1977f,0.1745f,-0.5765f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[-0.2361f,-0.5980f,0.7568f,-0.1175f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.1568f,0.0021f,-0.0129f,-0.9875f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0129f,-0.9875f,0.1568f,0.0021f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3983f,0.8335f,0.2348f],left_rotation:[-0.1274f,-0.1281f,0.6753f,-0.7151f]}}
particle minecraft:cloud -60.48 69.25 -36.71 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud -58.77 69.25 -36.60 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -58.77 69.05 -36.60 -0.002 0.02 0.035 1 0 force
scoreboard players set #gx driftmountains -63270
scoreboard players set #gdx driftmountains 673
scoreboard players set #gy driftmountains 69103
scoreboard players set #gdy driftmountains -16
scoreboard players set #gz driftmountains -33816
scoreboard players set #gdz driftmountains -358
scoreboard players set #gr driftmountains -14782
scoreboard players set #gdr driftmountains -517
scoreboard players set #gp driftmountains 96
scoreboard players set #gdp driftmountains 9
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[0.0061f,-0.0001f,0.0190f,0.9998f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.8400f,-0.0552f,0.1961f,0.5028f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[-0.1443f,0.4850f,0.8505f,0.1437f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.1568f,0.0021f,-0.0129f,-0.9875f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0129f,-0.9875f,0.1568f,0.0021f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3990f,0.8342f,0.0949f],left_rotation:[-0.0378f,-0.1776f,0.9556f,-0.2318f]}}
particle minecraft:cloud -64.65 69.42 -33.19 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud -63.23 69.42 -32.31 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -63.23 69.22 -32.31 -0.021 0.02 0.034 1 0 force
