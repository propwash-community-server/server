scoreboard players set #gx driftmountains -39815
scoreboard players set #gdx driftmountains 609
scoreboard players set #gy driftmountains 67516
scoreboard players set #gdy driftmountains -18
scoreboard players set #gz driftmountains -91500
scoreboard players set #gdz driftmountains -78
scoreboard players set #gr driftmountains -6229
scoreboard players set #gdr driftmountains 364
scoreboard players set #gp driftmountains 129
scoreboard players set #gdp driftmountains 8
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.6195f,-0.1302f,-0.1763f,-0.7538f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.0981f,-0.7394f,0.6366f,0.1960f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.3548f,0.0046f,-0.0122f,-0.9349f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0122f,-0.9349f,0.3548f,0.0046f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3939f,0.8601f,0.1051f],left_rotation:[-0.0751f,0.1735f,-0.9129f,-0.3617f]}}
particle minecraft:cloud -40.54 67.84 -92.83 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -40.54 67.64 -92.83 -0.032 0.02 -0.017 1 0 force
particle minecraft:cloud -41.32 67.84 -91.35 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -44584
scoreboard players set #gdx driftmountains 635
scoreboard players set #gy driftmountains 67635
scoreboard players set #gdy driftmountains -14
scoreboard players set #gz driftmountains -89765
scoreboard players set #gdz driftmountains -400
scoreboard players set #gr driftmountains -8672
scoreboard players set #gdr driftmountains 309
scoreboard players set #gp driftmountains 87
scoreboard players set #gdp driftmountains 3
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.5845f,-0.1523f,-0.1821f,-0.7759f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.1015f,-0.7610f,0.6037f,0.2146f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.3548f,0.0046f,-0.0122f,-0.9349f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0122f,-0.9349f,0.3548f,0.0046f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3724f,0.8729f,0.2502f],left_rotation:[-0.0987f,0.1654f,-0.8344f,-0.5165f]}}
particle minecraft:cloud -45.90 67.95 -90.70 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -45.90 67.75 -90.70 -0.035 0.02 -0.002 1 0 force
particle minecraft:cloud -46.00 67.95 -88.99 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -48023
scoreboard players set #gdx driftmountains 536
scoreboard players set #gy driftmountains 67723
scoreboard players set #gdy driftmountains -14
scoreboard players set #gz driftmountains -86193
scoreboard players set #gdz driftmountains -643
scoreboard players set #gr driftmountains -10849
scoreboard players set #gdr driftmountains 184
scoreboard players set #gp driftmountains 82
scoreboard players set #gdp driftmountains 1
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[0.0061f,0.0001f,-0.0198f,0.9998f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.6083f,-0.1530f,-0.1926f,-0.7546f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.1144f,-0.7385f,0.6278f,0.2178f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.3548f,0.0046f,-0.0122f,-0.9349f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0122f,-0.9349f,0.3548f,0.0046f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3830f,0.8658f,0.1073f],left_rotation:[-0.1163f,0.1520f,-0.7901f,-0.5823f]}}
particle minecraft:cloud -49.48 68.04 -86.59 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -49.48 67.84 -86.59 -0.043 0.02 0.014 1 0 force
particle minecraft:cloud -48.95 68.04 -85.00 0.35 0.18 0.35 0.02 3 force
