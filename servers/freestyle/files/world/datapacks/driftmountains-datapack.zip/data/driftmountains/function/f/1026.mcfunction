scoreboard players set #gx driftmountains 20772
scoreboard players set #gdx driftmountains -666
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 52649
scoreboard players set #gdz driftmountains 890
scoreboard players set #gr driftmountains 8928
scoreboard players set #gdr driftmountains 186
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.3804f,-0.3560f,-0.2282f,-0.8225f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.1430f,-0.8031f,0.4199f,0.3979f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.3619f,0.0047f,0.0122f,0.9321f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0122f,0.9321f,0.3619f,0.0047f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3785f,0.8210f,0.0897f],left_rotation:[-0.1262f,-0.1274f,0.7043f,-0.6868f]}}
particle minecraft:cloud 22.04 71.32 53.47 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 22.04 71.12 53.47 0.066 0.02 -0.001 1 0 force
particle minecraft:cloud 22.02 71.32 51.80 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains 25243
scoreboard players set #gdx driftmountains -563
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 45441
scoreboard players set #gdz driftmountains 992
scoreboard players set #gr driftmountains 8852
scoreboard players set #gdr driftmountains 165
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.8405f,-0.0901f,-0.4537f,-0.2821f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.4265f,-0.2359f,0.8546f,0.1789f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.3619f,0.0047f,0.0122f,0.9321f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0122f,0.9321f,0.3619f,0.0047f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.4062f,0.8525f,0.2422f],left_rotation:[-0.0601f,-0.1770f,0.9164f,-0.3540f]}}
particle minecraft:cloud 26.63 71.32 46.26 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 26.63 71.12 46.26 0.066 0.02 -0.002 1 0 force
particle minecraft:cloud 26.59 71.32 44.55 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains 26930
scoreboard players set #gdx driftmountains -215
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 40469
scoreboard players set #gdz driftmountains 1017
scoreboard players set #gr driftmountains 6970
scoreboard players set #gdr driftmountains 187
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.4831f,0.4066f,-0.1919f,0.7513f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.2719f,0.7756f,0.4430f,-0.3581f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.3619f,0.0047f,0.0122f,0.9321f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0122f,0.9321f,0.3619f,0.0047f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3909f,0.8251f,0.0913f],left_rotation:[-0.0842f,-0.1586f,0.8631f,-0.4720f]}}
particle minecraft:cloud 28.40 71.32 40.82 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 28.40 71.12 40.82 0.054 0.02 -0.020 1 0 force
particle minecraft:cloud 27.82 71.32 39.25 0.35 0.18 0.35 0.02 3 force
