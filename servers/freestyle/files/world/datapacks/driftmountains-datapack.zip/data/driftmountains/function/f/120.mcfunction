scoreboard players set #gx driftmountains 5232
scoreboard players set #gdx driftmountains 458
scoreboard players set #gy driftmountains 70802
scoreboard players set #gdy driftmountains 58
scoreboard players set #gz driftmountains -17464
scoreboard players set #gdz driftmountains 762
scoreboard players set #gr driftmountains 1278
scoreboard players set #gdr driftmountains -5
scoreboard players set #gp driftmountains -288
scoreboard players set #gdp driftmountains 30
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.9341f,0.0409f,-0.3523f,-0.0400f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.3500f,-0.0032f,0.9350f,0.0571f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.8485f,0.0111f,0.0069f,0.5290f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0069f,0.5290f,0.8485f,0.0111f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3533f,0.8375f,0.0962f],left_rotation:[-0.1851f,-0.0155f,0.1174f,-0.9755f]}}
particle minecraft:cloud 6.33 71.12 -18.51 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 6.33 70.92 -18.51 0.012 0.02 -0.052 1 0 force
particle minecraft:cloud 4.70 71.12 -18.88 0.35 0.18 0.35 0.02 3 force
playsound driftgen:grain.kaze.056 neutral @a 8.90 71.50 -11.13 12 1
scoreboard players set #gx driftmountains 2095
scoreboard players set #gdx driftmountains 577
scoreboard players set #gy driftmountains 70482
scoreboard players set #gdy driftmountains 9
scoreboard players set #gz driftmountains -22212
scoreboard players set #gdz driftmountains 612
scoreboard players set #gr driftmountains 57
scoreboard players set #gdr driftmountains 314
scoreboard players set #gp driftmountains -8
scoreboard players set #gdp driftmountains -79
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.7762f,0.2243f,-0.2235f,0.5452f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.2820f,0.5717f,0.7569f,-0.1440f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.8485f,0.0111f,0.0069f,0.5290f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0069f,0.5290f,0.8485f,0.0111f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3568f,0.8437f,0.2388f],left_rotation:[-0.1754f,0.0525f,-0.2445f,-0.9522f]}}
particle minecraft:cloud 2.96 70.80 -23.57 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 2.96 70.60 -23.57 0.001 0.02 -0.052 1 0 force
particle minecraft:cloud 1.25 70.80 -23.59 0.35 0.18 0.35 0.02 3 force
playsound driftgen:grain.onyx.000 neutral @a 5.98 71.38 -16.51 12 1
scoreboard players set #gx driftmountains -1944
scoreboard players set #gdx driftmountains 735
scoreboard players set #gy driftmountains 70515
scoreboard players set #gdy driftmountains 10
scoreboard players set #gz driftmountains -24948
scoreboard players set #gdz driftmountains 502
scoreboard players set #gr driftmountains -1157
scoreboard players set #gdr driftmountains 78
scoreboard players set #gp driftmountains -69
scoreboard players set #gdp driftmountains 60
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.6811f,-0.2101f,-0.3107f,-0.6288f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.2463f,-0.5996f,0.7069f,0.2829f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.8485f,0.0111f,0.0069f,0.5290f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0069f,0.5290f,0.8485f,0.0111f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3578f,0.8294f,0.0930f],left_rotation:[-0.1757f,-0.0519f,0.3104f,-0.9327f]}}
particle minecraft:cloud -1.38 70.83 -26.35 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -1.38 70.63 -26.35 -0.010 0.02 -0.047 1 0 force
particle minecraft:cloud -3.02 70.83 -26.01 0.35 0.18 0.35 0.02 3 force
playsound driftgen:grain.kaze.065 neutral @a 3.03 71.02 -20.83 12 1
