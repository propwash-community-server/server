scoreboard players set #gx driftmountains -13322
scoreboard players set #gdx driftmountains 757
scoreboard players set #gy driftmountains 67046
scoreboard players set #gdy driftmountains -10
scoreboard players set #gz driftmountains -80169
scoreboard players set #gdz driftmountains 482
scoreboard players set #gr driftmountains -3645
scoreboard players set #gdr driftmountains -110
scoreboard players set #gp driftmountains 62
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0001f,-0.0129f,0.9999f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.4361f,-0.1379f,-0.1277f,-0.8801f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.0359f,-0.8715f,0.4530f,0.1845f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.3216f,0.0042f,0.0124f,0.9468f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0124f,0.9468f,0.3216f,0.0042f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.4008f,0.8483f,0.1004f],left_rotation:[-0.0210f,0.1842f,-0.9797f,-0.0757f]}}
particle minecraft:cloud -13.40 67.37 -81.68 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -13.40 67.17 -81.68 -0.032 0.02 -0.043 1 0 force
particle minecraft:cloud -14.74 67.37 -80.69 0.35 0.18 0.35 0.02 2 force
scoreboard players set #gx driftmountains -19947
scoreboard players set #gdx driftmountains 730
scoreboard players set #gy driftmountains 67138
scoreboard players set #gdy driftmountains -11
scoreboard players set #gz driftmountains -83873
scoreboard players set #gdz driftmountains 451
scoreboard players set #gr driftmountains -3056
scoreboard players set #gdr driftmountains -10
scoreboard players set #gp driftmountains 64
scoreboard players set #gdp driftmountains -1
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0001f,-0.0170f,0.9998f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.8771f,-0.0516f,-0.2345f,-0.4160f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.1921f,-0.3937f,0.8873f,0.1441f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.3216f,0.0042f,0.0124f,0.9468f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0124f,0.9468f,0.3216f,0.0042f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3712f,0.8725f,0.2500f],left_rotation:[-0.1026f,0.1628f,-0.8205f,-0.5384f]}}
particle minecraft:cloud -19.90 67.46 -85.48 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -19.90 67.26 -85.48 -0.026 0.02 -0.044 1 0 force
particle minecraft:cloud -21.38 67.46 -84.61 0.35 0.18 0.35 0.02 2 force
scoreboard players set #gx driftmountains -27097
scoreboard players set #gdx driftmountains 691
scoreboard players set #gy driftmountains 67252
scoreboard players set #gdy driftmountains -11
scoreboard players set #gz driftmountains -88631
scoreboard players set #gdz driftmountains 357
scoreboard players set #gr driftmountains -3364
scoreboard players set #gdr driftmountains 32
scoreboard players set #gp driftmountains 72
scoreboard players set #gdp driftmountains -1
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.2384f,0.2423f,-0.0058f,0.9404f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.1047f,0.9462f,0.2142f,-0.2186f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.3216f,0.0042f,0.0124f,0.9468f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0124f,0.9468f,0.3216f,0.0042f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3846f,0.8654f,0.1071f],left_rotation:[-0.1111f,0.1556f,-0.8100f,-0.5543f]}}
particle minecraft:cloud -27.10 67.57 -90.14 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -27.10 67.37 -90.14 -0.025 0.02 -0.038 1 0 force
particle minecraft:cloud -28.49 67.57 -89.22 0.35 0.18 0.35 0.02 2 force
