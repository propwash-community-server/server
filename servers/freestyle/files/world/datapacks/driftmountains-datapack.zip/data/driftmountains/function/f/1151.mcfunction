scoreboard players set #gx driftmountains -97544
scoreboard players set #gdx driftmountains -179
scoreboard players set #gy driftmountains 70034
scoreboard players set #gdy driftmountains -1
scoreboard players set #gz driftmountains -3156
scoreboard players set #gdz driftmountains -914
scoreboard players set #gr driftmountains -14183
scoreboard players set #gdr driftmountains 168
scoreboard players set #gp driftmountains 3
scoreboard players set #gdp driftmountains 5
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.1598f,-0.3652f,-0.1217f,-0.9090f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.0268f,-0.9012f,0.1990f,0.3840f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.3209f,0.0042f,0.0124f,0.9470f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0124f,0.9470f,0.3209f,0.0042f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3612f,0.8262f,0.0918f],left_rotation:[-0.1686f,-0.0689f,0.3995f,-0.8984f]}}
particle minecraft:cloud -98.98 70.35 -2.68 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -98.98 70.15 -2.68 -0.035 0.02 0.044 1 0 force
particle minecraft:cloud -97.67 70.35 -1.65 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -94439
scoreboard players set #gdx driftmountains -515
scoreboard players set #gy driftmountains 70011
scoreboard players set #gdy driftmountains 4
scoreboard players set #gz driftmountains 4571
scoreboard players set #gdz driftmountains -824
scoreboard players set #gr driftmountains -16523
scoreboard players set #gdr driftmountains 303
scoreboard players set #gp driftmountains -17
scoreboard players set #gdp driftmountains 1
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.7815f,-0.1471f,-0.3277f,-0.5102f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.2759f,-0.4785f,0.8012f,0.2300f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.3209f,0.0042f,0.0124f,0.9470f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0124f,0.9470f,0.3209f,0.0042f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3703f,0.8294f,0.2331f],left_rotation:[-0.1768f,-0.0265f,0.1608f,-0.9707f]}}
particle minecraft:cloud -95.61 70.33 5.67 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -95.61 70.13 5.67 -0.015 0.02 0.057 1 0 force
particle minecraft:cloud -93.96 70.33 6.11 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -90914
scoreboard players set #gdx driftmountains -651
scoreboard players set #gy driftmountains 69988
scoreboard players set #gdy driftmountains 3
scoreboard players set #gz driftmountains 8934
scoreboard players set #gdz driftmountains -749
scoreboard players set #gr driftmountains 17999
scoreboard players set #gdr driftmountains 153
scoreboard players set #gp driftmountains -13
scoreboard players set #gdp driftmountains -2
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.6896f,0.2732f,-0.2142f,0.6355f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.2822f,0.6616f,0.6647f,-0.2022f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.3209f,0.0042f,0.0124f,0.9470f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0124f,0.9470f,0.3209f,0.0042f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3525f,0.8408f,0.0975f],left_rotation:[-0.1867f,-0.0018f,0.0449f,-0.9813f]}}
particle minecraft:cloud -91.75 70.31 10.19 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -91.75 70.11 10.19 0.000 0.02 0.060 1 0 force
particle minecraft:cloud -90.08 70.31 10.19 0.35 0.18 0.35 0.02 3 force
