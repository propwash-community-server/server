scoreboard players set #gx driftmountains -8701
scoreboard players set #gdx driftmountains 788
scoreboard players set #gy driftmountains 66983
scoreboard players set #gdy driftmountains -10
scoreboard players set #gz driftmountains -77201
scoreboard players set #gdz driftmountains 514
scoreboard players set #gr driftmountains -4362
scoreboard players set #gdr driftmountains -106
scoreboard players set #gp driftmountains 62
scoreboard players set #gdp driftmountains -1
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0000f,-0.0081f,1.0000f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.8874f,0.0976f,-0.0775f,0.4438f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.1245f,0.4544f,0.8820f,-0.0049f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.9514f,0.0125f,-0.0040f,-0.3077f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0040f,-0.3077f,0.9514f,0.0125f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3892f,0.8241f,0.0909f],left_rotation:[0.0912f,0.1545f,-0.8425f,0.5079f]}}
particle minecraft:cloud -8.97 67.30 -78.69 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -8.97 67.10 -78.69 -0.039 0.02 -0.041 1 0 force
particle minecraft:cloud -10.17 67.30 -77.54 0.35 0.18 0.35 0.02 2 force
scoreboard players set #gx driftmountains -15464
scoreboard players set #gdx driftmountains 742
scoreboard players set #gy driftmountains 67073
scoreboard players set #gdy driftmountains -10
scoreboard players set #gz driftmountains -81071
scoreboard players set #gdz driftmountains 467
scoreboard players set #gr driftmountains -3414
scoreboard players set #gdr driftmountains -103
scoreboard players set #gp driftmountains 62
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0001f,-0.0145f,0.9999f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.3989f,0.2078f,-0.0343f,0.8925f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.1283f,0.9010f,0.3792f,-0.1670f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.9514f,0.0125f,-0.0040f,-0.3077f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0040f,-0.3077f,0.9514f,0.0125f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3853f,0.8740f,0.2506f],left_rotation:[-0.0572f,0.1846f,-0.9385f,-0.2864f]}}
particle minecraft:cloud -15.52 67.39 -82.68 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -15.52 67.19 -82.68 -0.030 0.02 -0.045 1 0 force
particle minecraft:cloud -16.94 67.39 -81.72 0.35 0.18 0.35 0.02 2 force
scoreboard players set #gx driftmountains -22882
scoreboard players set #gdx driftmountains 712
scoreboard players set #gy driftmountains 67186
scoreboard players set #gdy driftmountains -11
scoreboard players set #gz driftmountains -86324
scoreboard players set #gdz driftmountains 421
scoreboard players set #gr driftmountains -3104
scoreboard players set #gdr driftmountains 44
scoreboard players set #gp driftmountains 66
scoreboard players set #gdp driftmountains -1
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.9103f,0.1315f,-0.1996f,0.3380f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.2362f,0.3609f,0.9015f,-0.0366f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.9514f,0.0125f,-0.0040f,-0.3077f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0040f,-0.3077f,0.9514f,0.0125f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3861f,0.8648f,0.1069f],left_rotation:[-0.1062f,0.1587f,-0.8275f,-0.5280f]}}
particle minecraft:cloud -22.82 67.51 -87.83 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -22.82 67.31 -87.83 -0.026 0.02 -0.043 1 0 force
particle minecraft:cloud -24.25 67.51 -86.97 0.35 0.18 0.35 0.02 2 force
