scoreboard players set #gx driftmountains -97826
scoreboard players set #gdx driftmountains 149
scoreboard players set #gy driftmountains 69948
scoreboard players set #gdy driftmountains -14
scoreboard players set #gz driftmountains -12540
scoreboard players set #gdz driftmountains -757
scoreboard players set #gr driftmountains -12052
scoreboard players set #gdr driftmountains 321
scoreboard players set #gp driftmountains 66
scoreboard players set #gdp driftmountains 4
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.8449f,0.1998f,-0.2891f,0.4032f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.3330f,0.4358f,0.8286f,-0.1121f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.8463f,0.0111f,-0.0070f,-0.5325f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0070f,-0.5325f,0.8463f,0.0111f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3529f,0.8389f,0.0967f],left_rotation:[-0.1860f,-0.0096f,0.0860f,-0.9787f]}}
particle minecraft:cloud -99.34 70.27 -12.62 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -99.34 70.07 -12.62 -0.040 0.02 0.024 1 0 force
particle minecraft:cloud -98.49 70.27 -11.18 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -97937
scoreboard players set #gdx driftmountains -106
scoreboard players set #gy driftmountains 70030
scoreboard players set #gdy driftmountains -4
scoreboard players set #gz driftmountains -4959
scoreboard players set #gdz driftmountains -840
scoreboard players set #gr driftmountains -13846
scoreboard players set #gdr driftmountains 148
scoreboard players set #gp driftmountains 13
scoreboard players set #gdp driftmountains 5
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.6753f,0.2951f,-0.2315f,0.6351f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.2995f,0.6629f,0.6480f,-0.2257f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.8463f,0.0111f,-0.0070f,-0.5325f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0070f,-0.5325f,0.8463f,0.0111f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3779f,0.8273f,0.2323f],left_rotation:[-0.1693f,-0.0556f,0.3094f,-0.9341f]}}
particle minecraft:cloud -99.48 70.35 -4.50 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -99.48 70.15 -4.50 -0.034 0.02 0.038 1 0 force
particle minecraft:cloud -98.20 70.35 -3.37 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -96682
scoreboard players set #gdx driftmountains -335
scoreboard players set #gy driftmountains 70029
scoreboard players set #gdy driftmountains 2
scoreboard players set #gz driftmountains 307
scoreboard players set #gdz driftmountains -915
scoreboard players set #gr driftmountains -14988
scoreboard players set #gdr driftmountains 314
scoreboard players set #gp driftmountains -10
scoreboard players set #gdp driftmountains 3
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[-0.0028f,-0.0001f,-0.0223f,0.9997f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.4273f,-0.3086f,-0.2246f,-0.8196f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.1397f,-0.8005f,0.4621f,0.3552f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.8463f,0.0111f,-0.0070f,-0.5325f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0070f,-0.5325f,0.8463f,0.0111f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3600f,0.8272f,0.0921f],left_rotation:[-0.1711f,-0.0634f,0.3709f,-0.9105f]}}
particle minecraft:cloud -98.04 70.35 0.98 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -98.04 70.15 0.98 -0.027 0.02 0.047 1 0 force
particle minecraft:cloud -96.59 70.35 1.82 0.35 0.18 0.35 0.02 3 force
