scoreboard players set #gx driftmountains -57051
scoreboard players set #gdx driftmountains -1178
scoreboard players set #gy driftmountains 70509
scoreboard players set #gdy driftmountains 5
scoreboard players set #gz driftmountains 43510
scoreboard players set #gdz driftmountains -693
scoreboard players set #gr driftmountains 16873
scoreboard players set #gdr driftmountains 197
scoreboard players set #gp driftmountains -15
scoreboard players set #gdp driftmountains 4
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.7515f,-0.1786f,-0.3535f,-0.5276f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.3000f,-0.4934f,0.7744f,0.2586f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.3278f,0.0043f,-0.0124f,-0.9446f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0124f,-0.9446f,0.3278f,0.0043f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3657f,0.8234f,0.0907f],left_rotation:[-0.1585f,-0.0874f,0.4967f,-0.8488f]}}
particle minecraft:cloud -57.62 70.83 44.91 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -57.62 70.63 44.91 0.016 0.02 0.080 1 0 force
particle minecraft:cloud -55.99 70.83 44.58 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -47020
scoreboard players set #gdx driftmountains -1167
scoreboard players set #gy driftmountains 70468
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 48080
scoreboard players set #gdz driftmountains -513
scoreboard players set #gr driftmountains 15672
scoreboard players set #gdr driftmountains 68
scoreboard players set #gp driftmountains 5
scoreboard players set #gdp driftmountains -8
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.9122f,0.1284f,-0.3389f,0.1914f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.3609f,0.2281f,0.9037f,-0.0332f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.3278f,0.0043f,-0.0124f,-0.9446f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0124f,-0.9446f,0.3278f,0.0043f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3718f,0.8288f,0.2329f],left_rotation:[-0.1756f,-0.0324f,0.1911f,-0.9652f]}}
particle minecraft:cloud -47.27 70.79 49.67 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -47.27 70.59 49.67 0.032 0.02 0.075 1 0 force
particle minecraft:cloud -45.70 70.79 49.00 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -42375
scoreboard players set #gdx driftmountains -1221
scoreboard players set #gy driftmountains 70504
scoreboard players set #gdy driftmountains -16
scoreboard players set #gz driftmountains 50549
scoreboard players set #gdz driftmountains -483
scoreboard players set #gr driftmountains 15496
scoreboard players set #gdr driftmountains 42
scoreboard players set #gp driftmountains 59
scoreboard players set #gdp driftmountains -18
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.0391f,0.3636f,0.0409f,0.9299f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.0566f,0.9307f,0.0011f,-0.3614f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.3278f,0.0043f,-0.0124f,-0.9446f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0124f,-0.9446f,0.3278f,0.0043f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3553f,0.8328f,0.0944f],left_rotation:[-0.1809f,-0.0356f,0.2239f,-0.9570f]}}
particle minecraft:cloud -42.60 70.82 52.04 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -42.60 70.62 52.04 0.034 0.02 0.072 1 0 force
particle minecraft:cloud -41.09 70.82 51.34 0.35 0.18 0.35 0.02 3 force
