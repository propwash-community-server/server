scoreboard players set #gx driftmountains -50953
scoreboard players set #gdx driftmountains 458
scoreboard players set #gy driftmountains 67788
scoreboard players set #gdy driftmountains -12
scoreboard players set #gz driftmountains -83412
scoreboard players set #gdz driftmountains -572
scoreboard players set #gr driftmountains -10954
scoreboard players set #gdr driftmountains 170
scoreboard players set #gp driftmountains 79
scoreboard players set #gdp driftmountains 1
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0001f,-0.0199f,0.9998f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.2948f,0.2443f,-0.0214f,0.9236f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.1186f,0.9309f,0.2708f,-0.2146f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.9780f,0.0128f,-0.0027f,-0.2082f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0027f,-0.2082f,0.9780f,0.0128f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3834f,0.8657f,0.1073f],left_rotation:[-0.1151f,0.1528f,-0.7946f,-0.5762f]}}
particle minecraft:cloud -52.42 68.11 -83.78 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -52.42 67.91 -83.78 -0.041 0.02 0.015 1 0 force
particle minecraft:cloud -51.86 68.11 -82.20 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -53469
scoreboard players set #gdx driftmountains 313
scoreboard players set #gy driftmountains 67873
scoreboard players set #gdy driftmountains -12
scoreboard players set #gz driftmountains -78973
scoreboard players set #gdz driftmountains -642
scoreboard players set #gr driftmountains -12138
scoreboard players set #gdr driftmountains 109
scoreboard players set #gp driftmountains 84
scoreboard players set #gdp driftmountains -2
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0001f,-0.0202f,0.9998f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.1224f,0.2542f,0.0220f,0.9591f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.0786f,0.9621f,0.0964f,-0.2428f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.9780f,0.0128f,-0.0027f,-0.2082f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0027f,-0.2082f,0.9780f,0.0128f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3649f,0.8690f,0.2487f],left_rotation:[-0.1229f,0.1466f,-0.7344f,-0.6513f]}}
particle minecraft:cloud -55.08 68.19 -78.99 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -55.08 67.99 -78.99 -0.023 0.02 0.014 1 0 force
particle minecraft:cloud -54.19 68.19 -77.53 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -54771
scoreboard players set #gdx driftmountains 271
scoreboard players set #gy driftmountains 67993
scoreboard players set #gdy driftmountains -22
scoreboard players set #gz driftmountains -73579
scoreboard players set #gdz driftmountains -754
scoreboard players set #gr driftmountains -12842
scoreboard players set #gdr driftmountains 58
scoreboard players set #gp driftmountains 156
scoreboard players set #gdp driftmountains -35
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.2866f,-0.1841f,-0.1125f,-0.9334f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.0150f,-0.9268f,0.3075f,0.2153f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.9780f,0.0128f,-0.0027f,-0.2082f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0027f,-0.2082f,0.9780f,0.0128f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3950f,0.8591f,0.1046f],left_rotation:[-0.0695f,0.1755f,-0.9242f,-0.3320f]}}
particle minecraft:cloud -56.28 68.31 -73.45 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -56.28 68.11 -73.45 -0.031 0.02 0.024 1 0 force
particle minecraft:cloud -55.24 68.31 -72.14 0.35 0.18 0.35 0.02 3 force
