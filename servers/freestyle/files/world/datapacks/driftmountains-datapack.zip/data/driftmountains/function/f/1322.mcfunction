scoreboard players set #gx driftmountains -42164
scoreboard players set #gdx driftmountains 586
scoreboard players set #gy driftmountains 67579
scoreboard players set #gdy driftmountains -15
scoreboard players set #gz driftmountains -90806
scoreboard players set #gdz driftmountains -230
scoreboard players set #gr driftmountains -7608
scoreboard players set #gdr driftmountains 282
scoreboard players set #gp driftmountains 110
scoreboard players set #gdp driftmountains 2
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[0.0061f,0.0001f,-0.0223f,0.9997f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.9147f,-0.0236f,-0.2175f,-0.3397f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.1830f,-0.3187f,0.9223f,0.1199f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.6398f,0.0084f,0.0101f,0.7684f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0101f,0.7684f,0.6398f,0.0084f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3940f,0.8600f,0.1050f],left_rotation:[-0.0745f,0.1738f,-0.9141f,-0.3586f]}}
particle minecraft:cloud -43.19 67.90 -91.92 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -43.19 67.70 -91.92 -0.037 0.02 -0.009 1 0 force
particle minecraft:cloud -43.59 67.90 -90.30 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -46516
scoreboard players set #gdx driftmountains 427
scoreboard players set #gy driftmountains 67679
scoreboard players set #gdy driftmountains -10
scoreboard players set #gz driftmountains -88285
scoreboard players set #gdz driftmountains -360
scoreboard players set #gr driftmountains -9507
scoreboard players set #gdr driftmountains 158
scoreboard players set #gp driftmountains 80
scoreboard players set #gdp driftmountains 2
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[0.0061f,0.0001f,-0.0219f,0.9997f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.8826f,-0.0516f,-0.2462f,-0.3972f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.2058f,-0.3735f,0.8929f,0.1446f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.6398f,0.0084f,0.0101f,0.7684f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0101f,0.7684f,0.6398f,0.0084f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3663f,0.8700f,0.2491f],left_rotation:[-0.1182f,0.1508f,-0.7565f,-0.6254f]}}
particle minecraft:cloud -47.95 68.00 -89.02 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -47.95 67.80 -89.02 -0.042 0.02 0.004 1 0 force
particle minecraft:cloud -47.80 68.00 -87.31 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -49791
scoreboard players set #gdx driftmountains 439
scoreboard players set #gy driftmountains 67771
scoreboard players set #gdy driftmountains -13
scoreboard players set #gz driftmountains -83832
scoreboard players set #gdz driftmountains -627
scoreboard players set #gr driftmountains -11404
scoreboard players set #gdr driftmountains 155
scoreboard players set #gp driftmountains 83
scoreboard players set #gdp driftmountains -4
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0001f,-0.0193f,0.9998f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.8356f,0.1665f,-0.1763f,0.4929f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.2290f,0.5141f,0.8227f,-0.0796f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.6398f,0.0084f,0.0101f,0.7684f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0101f,0.7684f,0.6398f,0.0084f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3846f,0.8654f,0.1071f],left_rotation:[-0.1112f,0.1554f,-0.8094f,-0.5552f]}}
particle minecraft:cloud -51.28 68.09 -84.08 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -51.28 67.89 -84.08 -0.042 0.02 0.019 1 0 force
particle minecraft:cloud -50.60 68.09 -82.56 0.35 0.18 0.35 0.02 3 force
