scoreboard players set #gx driftmountains -55148
scoreboard players set #gdx driftmountains -146
scoreboard players set #gy driftmountains 68282
scoreboard players set #gdy driftmountains -13
scoreboard players set #gz driftmountains -59810
scoreboard players set #gdz driftmountains -749
scoreboard players set #gr driftmountains 16492
scoreboard players set #gdr driftmountains 494
scoreboard players set #gp driftmountains 98
scoreboard players set #gdp driftmountains -1
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,0.0000f,0.0024f,1.0000f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.3266f,-0.0235f,0.0636f,0.9427f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.0352f,0.9413f,0.3308f,0.0580f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.5328f,0.0070f,0.0111f,0.8461f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0111f,0.8461f,0.5328f,0.0070f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3589f,0.8593f,0.1047f],left_rotation:[0.1752f,-0.0769f,0.3781f,0.9057f]}}
scoreboard players set #gx driftmountains -53938
scoreboard players set #gdx driftmountains -63
scoreboard players set #gy driftmountains 68400
scoreboard players set #gdy driftmountains -17
scoreboard players set #gz driftmountains -54010
scoreboard players set #gdz driftmountains -763
scoreboard players set #gr driftmountains 14354
scoreboard players set #gdr driftmountains 38
scoreboard players set #gp driftmountains 114
scoreboard players set #gdp driftmountains -7
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[-0.0039f,0.0001f,0.0200f,0.9998f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.2150f,0.2014f,-0.0094f,-0.9556f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[-0.0910f,-0.9599f,0.1950f,-0.1799f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.5328f,0.0070f,0.0111f,0.8461f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0111f,0.8461f,0.5328f,0.0070f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.4045f,0.8594f,0.2449f],left_rotation:[-0.0340f,-0.1860f,0.9588f,-0.2123f]}}
particle minecraft:cloud -53.81 68.72 -52.40 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud -52.44 68.72 -53.42 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -52.44 68.52 -53.42 0.024 0.02 0.033 1 0 force
scoreboard players set #gx driftmountains -54632
scoreboard players set #gdx driftmountains 162
scoreboard players set #gy driftmountains 68572
scoreboard players set #gdy driftmountains -24
scoreboard players set #gz driftmountains -48711
scoreboard players set #gdz driftmountains -817
scoreboard players set #gr driftmountains 15946
scoreboard players set #gdr driftmountains 23
scoreboard players set #gp driftmountains 144
scoreboard players set #gdp driftmountains -4
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[0.0061f,-0.0001f,0.0193f,0.9998f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.3324f,0.2741f,0.0431f,-0.9014f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[-0.1381f,-0.9109f,0.3055f,-0.2406f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.5328f,0.0070f,0.0111f,0.8461f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0111f,0.8461f,0.5328f,0.0070f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3701f,0.8218f,0.0901f],left_rotation:[-0.1481f,-0.1027f,0.5762f,-0.7971f]}}
particle minecraft:cloud -54.97 68.89 -47.24 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud -53.41 68.89 -47.82 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -53.41 68.69 -47.82 0.016 0.02 0.042 1 0 force
