scoreboard players set #gx driftmountains -68338
scoreboard players set #gdx driftmountains 699
scoreboard players set #gy driftmountains 69191
scoreboard players set #gdy driftmountains -10
scoreboard players set #gz driftmountains -31204
scoreboard players set #gdz driftmountains -241
scoreboard players set #gr driftmountains -11619
scoreboard players set #gdr driftmountains -292
scoreboard players set #gp driftmountains 79
scoreboard players set #gdp driftmountains 2
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[0.0061f,-0.0000f,0.0044f,1.0000f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.1620f,-0.0594f,0.0630f,0.9830f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.0400f,0.9818f,0.1692f,0.0768f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.4166f,0.0055f,0.0119f,0.9090f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0119f,0.9090f,0.4166f,0.0055f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3684f,0.8652f,0.1070f],left_rotation:[0.1548f,-0.1139f,0.5795f,0.7919f]}}
scoreboard players set #gx driftmountains -74828
scoreboard players set #gdx driftmountains 663
scoreboard players set #gy driftmountains 69282
scoreboard players set #gdy driftmountains -9
scoreboard players set #gz driftmountains -30040
scoreboard players set #gdz driftmountains -312
scoreboard players set #gr driftmountains -12636
scoreboard players set #gdr driftmountains 222
scoreboard players set #gp driftmountains 72
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[-0.0039f,0.0000f,0.0069f,1.0000f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.9610f,0.0276f,0.1006f,0.2563f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[-0.0742f,0.2471f,0.9634f,0.0733f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.4166f,0.0055f,0.0119f,0.9090f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0119f,0.9090f,0.4166f,0.0055f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3641f,0.8683f,0.2484f],left_rotation:[0.1255f,-0.1440f,0.7208f,0.6663f]}}
particle minecraft:cloud -76.43 69.60 -29.92 0.35 0.18 0.35 0.02 2 force
particle minecraft:cloud -75.42 69.60 -28.54 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -75.42 69.40 -28.54 -0.035 0.02 0.026 1 0 force
scoreboard players set #gx driftmountains -79813
scoreboard players set #gdx driftmountains 567
scoreboard players set #gy driftmountains 69360
scoreboard players set #gdy driftmountains -10
scoreboard players set #gz driftmountains -26939
scoreboard players set #gdz driftmountains -146
scoreboard players set #gr driftmountains -11209
scoreboard players set #gdr driftmountains -655
scoreboard players set #gp driftmountains 97
scoreboard players set #gdp driftmountains -6
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,0.0000f,0.0055f,1.0000f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.7089f,0.0424f,-0.0316f,-0.7033f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[-0.0422f,-0.7039f,0.7083f,0.0319f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.4166f,0.0055f,0.0119f,0.9090f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0119f,0.9090f,0.4166f,0.0055f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3524f,0.8460f,0.0995f],left_rotation:[0.1872f,-0.0195f,0.0689f,0.9797f]}}
