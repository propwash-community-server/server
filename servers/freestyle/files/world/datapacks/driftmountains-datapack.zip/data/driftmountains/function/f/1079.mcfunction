scoreboard players set #gx driftmountains -32047
scoreboard players set #gdx driftmountains -1152
scoreboard players set #gy driftmountains 70807
scoreboard players set #gdy driftmountains -41
scoreboard players set #gz driftmountains 53657
scoreboard players set #gdz driftmountains -384
scoreboard players set #gr driftmountains 15553
scoreboard players set #gdr driftmountains -1
scoreboard players set #gp driftmountains 129
scoreboard players set #gdp driftmountains 4
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.1577f,-0.3802f,-0.1243f,-0.9028f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.0301f,-0.8947f,0.1986f,0.3989f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.4817f,0.0063f,0.0115f,0.8762f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0115f,0.8762f,0.4817f,0.0063f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3675f,0.8227f,0.0904f],left_rotation:[-0.1543f,-0.0938f,0.5301f,-0.8284f]}}
particle minecraft:cloud -32.29 71.13 55.15 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -32.29 70.93 55.15 0.030 0.02 0.066 1 0 force
particle minecraft:cloud -30.77 71.13 54.46 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -22331
scoreboard players set #gdx driftmountains -1075
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains -1
scoreboard players set #gz driftmountains 56796
scoreboard players set #gdz driftmountains -316
scoreboard players set #gr driftmountains 15197
scoreboard players set #gdr driftmountains 30
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 5
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.7714f,-0.1621f,-0.3507f,-0.5056f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.2995f,-0.4715f,0.7927f,0.2441f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.4817f,0.0063f,0.0115f,0.8762f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0115f,0.8762f,0.4817f,0.0063f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3835f,0.8273f,0.2323f],left_rotation:[-0.1614f,-0.0758f,0.4119f,-0.8936f]}}
particle minecraft:cloud -22.44 71.32 58.40 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -22.44 71.12 58.40 0.032 0.02 0.061 1 0 force
particle minecraft:cloud -20.93 71.32 57.60 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -17623
scoreboard players set #gdx driftmountains -1107
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 58285
scoreboard players set #gdz driftmountains -306
scoreboard players set #gr driftmountains 15138
scoreboard players set #gdr driftmountains 8
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.6784f,0.3037f,-0.2474f,0.6215f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.3141f,0.6510f,0.6502f,-0.2341f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.4817f,0.0063f,0.0115f,0.8762f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0115f,0.8762f,0.4817f,0.0063f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3639f,0.8244f,0.0911f],left_rotation:[-0.1626f,-0.0803f,0.4596f,-0.8694f]}}
particle minecraft:cloud -17.75 71.32 59.79 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -17.75 71.12 59.79 0.033 0.02 0.061 1 0 force
particle minecraft:cloud -16.29 71.32 58.99 0.35 0.18 0.35 0.02 3 force
