scoreboard players set #gx driftmountains -49015
scoreboard players set #gdx driftmountains 528
scoreboard players set #gy driftmountains 67740
scoreboard players set #gdy driftmountains -12
scoreboard players set #gz driftmountains -85667
scoreboard players set #gdz driftmountains -549
scoreboard players set #gr driftmountains -10347
scoreboard players set #gdr driftmountains 156
scoreboard players set #gp driftmountains 76
scoreboard players set #gdp driftmountains 3
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0001f,-0.0204f,0.9998f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.9637f,0.0324f,-0.2515f,-0.0837f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.2441f,-0.0577f,0.9656f,0.0687f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.6620f,0.0087f,0.0098f,0.7494f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0098f,0.7494f,0.6620f,0.0087f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3795f,0.8664f,0.1075f],left_rotation:[-0.1267f,0.1440f,-0.7452f,-0.6386f]}}
particle minecraft:cloud -50.43 68.06 -86.19 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -50.43 67.86 -86.19 -0.044 0.02 0.011 1 0 force
particle minecraft:cloud -50.05 68.06 -84.56 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -52109
scoreboard players set #gdx driftmountains 393
scoreboard players set #gy driftmountains 67824
scoreboard players set #gdy driftmountains -12
scoreboard players set #gz driftmountains -81544
scoreboard players set #gdz driftmountains -640
scoreboard players set #gr driftmountains -11565
scoreboard players set #gdr driftmountains 187
scoreboard players set #gp driftmountains 80
scoreboard players set #gdp driftmountains -3
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0001f,-0.0206f,0.9998f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.9513f,0.0987f,-0.2284f,0.1822f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.2488f,0.2072f,0.9461f,0.0007f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.6620f,0.0087f,0.0098f,0.7494f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0098f,0.7494f,0.6620f,0.0087f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3674f,0.8707f,0.2493f],left_rotation:[-0.1146f,0.1539f,-0.7728f,-0.6050f]}}
particle minecraft:cloud -53.71 68.14 -81.72 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -53.71 67.94 -81.72 -0.040 0.02 0.019 1 0 force
particle minecraft:cloud -52.97 68.14 -80.18 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -53782
scoreboard players set #gdx driftmountains 285
scoreboard players set #gy driftmountains 67925
scoreboard players set #gdy driftmountains -15
scoreboard players set #gz driftmountains -76183
scoreboard players set #gdz driftmountains -686
scoreboard players set #gr driftmountains -12690
scoreboard players set #gdr driftmountains 35
scoreboard players set #gp driftmountains 105
scoreboard players set #gdp driftmountains -4
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0001f,-0.0189f,0.9998f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.5064f,0.2362f,-0.0816f,0.8253f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.1688f,0.8384f,0.4843f,-0.1843f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.6620f,0.0087f,0.0098f,0.7494f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0098f,0.7494f,0.6620f,0.0087f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3812f,0.8662f,0.1074f],left_rotation:[-0.1217f,0.1480f,-0.7676f,-0.6116f]}}
particle minecraft:cloud -55.29 68.25 -76.09 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -55.29 68.05 -76.09 -0.032 0.02 0.024 1 0 force
particle minecraft:cloud -54.29 68.25 -74.76 0.35 0.18 0.35 0.02 3 force
