scoreboard players set #gx driftmountains 46312
scoreboard players set #gdx driftmountains 1136
scoreboard players set #gy driftmountains 66294
scoreboard players set #gdy driftmountains -12
scoreboard players set #gz driftmountains -42287
scoreboard players set #gdz driftmountains 737
scoreboard players set #gr driftmountains -3195
scoreboard players set #gdr driftmountains 53
scoreboard players set #gp driftmountains 48
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0001f,-0.0154f,0.9999f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.3135f,0.2186f,-0.0176f,0.9239f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.1148f,0.9308f,0.2923f,-0.1869f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.8185f,0.0107f,0.0075f,0.5744f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0075f,0.5744f,0.8185f,0.0107f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3938f,0.8602f,0.1051f],left_rotation:[-0.0753f,0.1735f,-0.9124f,-0.3630f]}}
particle minecraft:cloud 46.35 66.61 -43.80 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke 46.35 66.41 -43.80 -0.043 0.02 -0.069 1 0 force
particle minecraft:cloud 44.94 66.61 -42.91 0.35 0.18 0.35 0.02 2 force
scoreboard players set #gx driftmountains 37818
scoreboard players set #gdx driftmountains 1172
scoreboard players set #gy driftmountains 66379
scoreboard players set #gdy driftmountains -14
scoreboard players set #gz driftmountains -45521
scoreboard players set #gdz driftmountains 796
scoreboard players set #gr driftmountains -4767
scoreboard players set #gdr driftmountains 252
scoreboard players set #gp driftmountains 56
scoreboard players set #gdp driftmountains -1
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0000f,-0.0048f,1.0000f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.3619f,-0.0524f,-0.0768f,-0.9276f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[-0.0203f,-0.9246f,0.3694f,0.0907f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.8185f,0.0107f,0.0075f,0.5744f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0075f,0.5744f,0.8185f,0.0107f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3959f,0.8317f,0.2341f],left_rotation:[0.1349f,0.1193f,-0.6308f,0.7548f]}}
scoreboard players set #gx driftmountains 28778
scoreboard players set #gdx driftmountains 1016
scoreboard players set #gy driftmountains 66505
scoreboard players set #gdy driftmountains -14
scoreboard players set #gz driftmountains -53385
scoreboard players set #gdz driftmountains 711
scoreboard players set #gr driftmountains -5390
scoreboard players set #gdr driftmountains 206
scoreboard players set #gp driftmountains 65
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0000f,-0.0016f,1.0000f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.2769f,-0.0013f,0.0549f,0.9593f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.0457f,0.9589f,0.2786f,0.0305f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.8185f,0.0107f,0.0075f,0.5744f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0075f,0.5744f,0.8185f,0.0107f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3532f,0.8497f,0.1010f],left_rotation:[0.1860f,-0.0346f,0.1497f,0.9704f]}}
