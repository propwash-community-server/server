scoreboard players set #gx driftmountains -80827
scoreboard players set #gdx driftmountains -833
scoreboard players set #gy driftmountains 70081
scoreboard players set #gdy driftmountains -19
scoreboard players set #gz driftmountains 20815
scoreboard players set #gdz driftmountains -969
scoreboard players set #gr driftmountains 17576
scoreboard players set #gdr driftmountains 0
scoreboard players set #gp driftmountains 70
scoreboard players set #gdp driftmountains -5
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.7797f,-0.1314f,-0.2858f,-0.5414f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.2305f,-0.5143f,0.7979f,0.2141f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.3827f,0.0050f,-0.0121f,-0.9238f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0121f,-0.9238f,0.3827f,0.0050f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3554f,0.8548f,0.1030f],left_rotation:[-0.1820f,0.0559f,-0.2645f,-0.9454f]}}
particle minecraft:cloud -81.57 70.40 22.13 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -81.57 70.20 22.13 0.006 0.02 0.077 1 0 force
particle minecraft:cloud -79.90 70.40 22.01 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -73579
scoreboard players set #gdx driftmountains -949
scoreboard players set #gy driftmountains 70268
scoreboard players set #gdy driftmountains -26
scoreboard players set #gz driftmountains 28521
scoreboard players set #gdz driftmountains -992
scoreboard players set #gr driftmountains 17538
scoreboard players set #gdr driftmountains -15
scoreboard players set #gp driftmountains 84
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.9219f,0.1226f,-0.3114f,0.1952f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.3336f,0.2290f,0.9141f,-0.0264f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.3827f,0.0050f,-0.0121f,-0.9238f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0121f,-0.9238f,0.3827f,0.0050f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3609f,0.8364f,0.2359f],left_rotation:[-0.1798f,0.0196f,-0.0750f,-0.9807f]}}
particle minecraft:cloud -74.32 70.59 29.95 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -74.32 70.39 29.95 0.007 0.02 0.083 1 0 force
particle minecraft:cloud -72.62 70.59 29.81 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -69456
scoreboard players set #gdx driftmountains -881
scoreboard players set #gy driftmountains 70376
scoreboard players set #gdy driftmountains -23
scoreboard players set #gz driftmountains 32644
scoreboard players set #gdz driftmountains -943
scoreboard players set #gr driftmountains 17969
scoreboard players set #gdr driftmountains -73
scoreboard players set #gp driftmountains 74
scoreboard players set #gdp driftmountains 3
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[-0.0011f,-0.0000f,-0.0223f,0.9997f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.0390f,0.3628f,0.0410f,0.9301f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.0566f,0.9310f,0.0011f,-0.3607f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.3827f,0.0050f,-0.0121f,-0.9238f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0121f,-0.9238f,0.3827f,0.0050f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3552f,0.8331f,0.0945f],left_rotation:[-0.1812f,-0.0343f,0.2172f,-0.9585f]}}
particle minecraft:cloud -70.28 70.70 33.91 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -70.28 70.50 33.91 0.000 0.02 0.080 1 0 force
particle minecraft:cloud -68.61 70.70 33.90 0.35 0.18 0.35 0.02 3 force
