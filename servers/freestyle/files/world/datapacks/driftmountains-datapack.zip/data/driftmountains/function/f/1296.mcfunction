scoreboard players set #gx driftmountains -54551
scoreboard players set #gdx driftmountains 292
scoreboard players set #gy driftmountains 67906
scoreboard players set #gdy driftmountains -12
scoreboard players set #gz driftmountains -77506
scoreboard players set #gdz driftmountains -592
scoreboard players set #gr driftmountains -12240
scoreboard players set #gdr driftmountains 73
scoreboard players set #gp driftmountains 93
scoreboard players set #gdp driftmountains -3
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0001f,-0.0194f,0.9998f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.6452f,-0.1448f,-0.2016f,-0.7226f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.1267f,-0.7054f,0.6639f,0.2134f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.9583f,0.0125f,0.0037f,0.2853f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0037f,0.2853f,0.9583f,0.0125f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3820f,0.8660f,0.1074f],left_rotation:[-0.1193f,0.1498f,-0.7777f,-0.5987f]}}
particle minecraft:cloud -56.06 68.23 -77.54 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -56.06 68.03 -77.54 -0.033 0.02 0.021 1 0 force
particle minecraft:cloud -55.17 68.23 -76.13 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -55765
scoreboard players set #gdx driftmountains 193
scoreboard players set #gy driftmountains 68020
scoreboard players set #gdy driftmountains -24
scoreboard players set #gz driftmountains -72904
scoreboard players set #gdz driftmountains -711
scoreboard players set #gr driftmountains -13068
scoreboard players set #gdr driftmountains 292
scoreboard players set #gp driftmountains 158
scoreboard players set #gdp driftmountains -17
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0001f,-0.0219f,0.9998f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.1087f,0.2065f,0.0307f,0.9719f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.0713f,0.9740f,0.0876f,-0.1962f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.9583f,0.0125f,0.0037f,0.2853f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0037f,0.2853f,0.9583f,0.0125f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3861f,0.8738f,0.2506f],left_rotation:[-0.0541f,0.1855f,-0.9434f,-0.2698f]}}
particle minecraft:cloud -57.36 68.34 -72.66 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -57.36 68.14 -72.66 -0.030 0.02 0.026 1 0 force
particle minecraft:cloud -56.24 68.34 -71.37 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -55259
scoreboard players set #gdx driftmountains -50
scoreboard players set #gy driftmountains 68165
scoreboard players set #gdy driftmountains -14
scoreboard players set #gz driftmountains -67194
scoreboard players set #gdz driftmountains -763
scoreboard players set #gr driftmountains -15867
scoreboard players set #gdr driftmountains 275
scoreboard players set #gp driftmountains 94
scoreboard players set #gdp driftmountains 2
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[0.0061f,0.0001f,-0.0156f,0.9999f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.7545f,-0.0859f,-0.1880f,-0.6230f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.1235f,-0.6066f,0.7676f,0.1657f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.9583f,0.0125f,0.0037f,0.2853f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0037f,0.2853f,0.9583f,0.0125f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3975f,0.8559f,0.1034f],left_rotation:[-0.0540f,0.1797f,-0.9499f,-0.2499f]}}
particle minecraft:cloud -56.50 68.49 -66.32 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -56.50 68.29 -66.32 -0.016 0.02 0.040 1 0 force
particle minecraft:cloud -54.94 68.49 -65.72 0.35 0.18 0.35 0.02 2 force
