scoreboard players set #gx driftmountains 8965
scoreboard players set #gdx driftmountains 904
scoreboard players set #gy driftmountains 66754
scoreboard players set #gdy driftmountains -12
scoreboard players set #gz driftmountains -65346
scoreboard players set #gdz driftmountains 615
scoreboard players set #gr driftmountains -5554
scoreboard players set #gdr driftmountains -84
scoreboard players set #gp driftmountains 61
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0000f,-0.0001f,1.0000f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.3102f,0.0183f,0.0491f,0.9492f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.0504f,0.9493f,0.3099f,0.0142f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.8658f,0.0113f,0.0065f,0.5003f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0065f,0.5003f,0.8658f,0.0113f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3524f,0.8421f,0.0980f],left_rotation:[0.1871f,-0.0034f,-0.0170f,0.9821f]}}
playsound driftgen:grain.kaze.059 neutral @a 16.39 67.16 -60.36 12 1
scoreboard players set #gx driftmountains 1979
scoreboard players set #gdx driftmountains 902
scoreboard players set #gy driftmountains 66843
scoreboard players set #gdy driftmountains -11
scoreboard players set #gz driftmountains -69965
scoreboard players set #gdz driftmountains 588
scoreboard players set #gr driftmountains -5218
scoreboard players set #gdr driftmountains -18
scoreboard players set #gp driftmountains 61
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0000f,-0.0029f,1.0000f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.3645f,-0.0175f,-0.0632f,-0.9289f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[-0.0341f,-0.9274f,0.3684f,0.0560f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.8658f,0.0113f,0.0065f,0.5003f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0065f,0.5003f,0.8658f,0.0113f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3797f,0.8272f,0.2323f],left_rotation:[0.1670f,0.0623f,-0.3430f,0.9223f]}}
playsound driftgen:grain.onyx.062 neutral @a 9.33 67.25 -65.12 12 1
scoreboard players set #gx driftmountains -6655
scoreboard players set #gdx driftmountains 861
scoreboard players set #gy driftmountains 66956
scoreboard players set #gdy driftmountains -11
scoreboard players set #gz driftmountains -75838
scoreboard players set #gdz driftmountains 572
scoreboard players set #gr driftmountains -4586
scoreboard players set #gdr driftmountains -98
scoreboard players set #gp driftmountains 62
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0000f,-0.0064f,1.0000f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.2812f,0.1026f,0.0245f,0.9538f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.0756f,0.9565f,0.2720f,-0.0736f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.8658f,0.0113f,0.0065f,0.5003f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0065f,0.5003f,0.8658f,0.0113f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3801f,0.8212f,0.0898f],left_rotation:[0.1214f,0.1319f,-0.7271f,0.6627f]}}
particle minecraft:cloud -6.98 67.28 -77.31 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -6.98 67.08 -77.31 -0.044 0.02 -0.043 1 0 force
particle minecraft:cloud -8.14 67.28 -76.12 0.35 0.18 0.35 0.02 2 force
playsound driftgen:grain.kaze.060 neutral @a 0.39 67.36 -71.17 12 1
