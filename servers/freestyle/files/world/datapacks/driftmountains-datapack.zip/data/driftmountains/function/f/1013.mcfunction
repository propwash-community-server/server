scoreboard players set #gx driftmountains 26752
scoreboard players set #gdx driftmountains -280
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 40309
scoreboard players set #gdz driftmountains 978
scoreboard players set #gr driftmountains 7006
scoreboard players set #gdr driftmountains 171
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.8910f,0.1290f,-0.4071f,0.1539f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.4255f,0.1976f,0.8824f,-0.0360f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.7875f,0.0103f,-0.0081f,-0.6162f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0081f,-0.6162f,0.7875f,0.0103f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3805f,0.8212f,0.0898f],left_rotation:[-0.1202f,-0.1330f,0.7330f,-0.6562f]}}
particle minecraft:cloud 28.22 71.32 40.66 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 28.22 71.12 40.66 0.057 0.02 -0.021 1 0 force
particle minecraft:cloud 27.65 71.32 39.09 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains 28371
scoreboard players set #gdx driftmountains 67
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 32638
scoreboard players set #gdz driftmountains 992
scoreboard players set #gr driftmountains 5734
scoreboard players set #gdr driftmountains 353
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.4904f,0.4135f,-0.2035f,0.7397f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.2823f,0.7652f,0.4496f,-0.3642f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.7875f,0.0103f,-0.0081f,-0.6162f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0081f,-0.6162f,0.7875f,0.0103f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.4063f,0.8517f,0.2419f],left_rotation:[-0.0630f,-0.1757f,0.9102f,-0.3698f]}}
particle minecraft:cloud 29.98 71.32 32.62 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 29.98 71.12 32.62 0.051 0.02 -0.032 1 0 force
particle minecraft:cloud 29.06 71.32 31.18 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains 25596
scoreboard players set #gdx driftmountains 321
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 28374
scoreboard players set #gdz driftmountains 901
scoreboard players set #gr driftmountains 3034
scoreboard players set #gdr driftmountains 312
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.6129f,-0.2662f,-0.3209f,-0.6713f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.2521f,-0.6412f,0.6442f,0.3320f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.7875f,0.0103f,-0.0081f,-0.6162f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0081f,-0.6162f,0.7875f,0.0103f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3755f,0.8210f,0.0897f],left_rotation:[-0.1343f,-0.1192f,0.6620f,-0.7276f]}}
particle minecraft:cloud 26.95 71.32 27.71 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 26.95 71.12 27.71 0.029 0.02 -0.050 1 0 force
particle minecraft:cloud 25.51 71.32 26.86 0.35 0.18 0.35 0.02 3 force
