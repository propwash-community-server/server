scoreboard players set #gx driftmountains -13398
scoreboard players set #gdx driftmountains -1048
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 59470
scoreboard players set #gdz driftmountains -305
scoreboard players set #gr driftmountains 15226
scoreboard players set #gdr driftmountains 11
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.3882f,-0.3269f,-0.2147f,-0.8345f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.1282f,-0.8165f,0.4247f,0.3695f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.2786f,0.0036f,0.0126f,0.9603f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0126f,0.9603f,0.2786f,0.0036f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3636f,0.8246f,0.0911f],left_rotation:[-0.1632f,-0.0793f,0.4541f,-0.8722f]}}
particle minecraft:cloud -13.55 71.32 60.97 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -13.55 71.12 60.97 0.030 0.02 0.058 1 0 force
particle minecraft:cloud -12.07 71.32 60.20 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -5136
scoreboard players set #gdx driftmountains -997
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 61271
scoreboard players set #gdz driftmountains -141
scoreboard players set #gr driftmountains 14738
scoreboard players set #gdr driftmountains 387
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[-0.0025f,-0.0001f,-0.0223f,0.9997f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.8879f,-0.0564f,-0.3521f,-0.2907f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.3235f,-0.2553f,0.8987f,0.1500f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.2786f,0.0036f,0.0126f,0.9603f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0126f,0.9603f,0.2786f,0.0036f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3691f,0.8299f,0.2334f],left_rotation:[-0.1776f,-0.0216f,0.1361f,-0.9744f]}}
particle minecraft:cloud -5.12 71.32 62.88 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -5.12 71.12 62.88 0.029 0.02 0.046 1 0 force
particle minecraft:cloud -3.68 71.32 61.96 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains 340
scoreboard players set #gdx driftmountains -1111
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 62701
scoreboard players set #gdz driftmountains -141
scoreboard players set #gr driftmountains 15309
scoreboard players set #gdr driftmountains 98
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.4848f,0.4000f,-0.1876f,0.7549f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.2680f,0.7788f,0.4454f,-0.3512f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.2786f,0.0036f,0.0126f,0.9603f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0126f,0.9603f,0.2786f,0.0036f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3875f,0.8233f,0.0906f],left_rotation:[-0.0974f,-0.1506f,0.8224f,-0.5398f]}}
particle minecraft:cloud 0.17 71.32 64.20 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 0.17 71.12 64.20 0.029 0.02 0.058 1 0 force
particle minecraft:cloud 1.65 71.32 63.45 0.35 0.18 0.35 0.02 3 force
