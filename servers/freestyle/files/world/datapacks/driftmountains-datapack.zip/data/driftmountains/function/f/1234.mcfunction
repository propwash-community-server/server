scoreboard players set #gx driftmountains -58603
scoreboard players set #gdx driftmountains 363
scoreboard players set #gy driftmountains 68947
scoreboard players set #gdy driftmountains -18
scoreboard players set #gz driftmountains -36639
scoreboard players set #gdz driftmountains -480
scoreboard players set #gr driftmountains -17613
scoreboard players set #gdr driftmountains -118
scoreboard players set #gp driftmountains 141
scoreboard players set #gdp driftmountains -1
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,0.0001f,0.0207f,0.9998f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.9579f,0.0150f,0.2389f,0.1586f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[-0.2235f,0.1344f,0.9616f,0.0856f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.9264f,0.0121f,-0.0049f,-0.3762f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0049f,-0.3762f,0.9264f,0.0121f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3876f,0.8233f,0.0906f],left_rotation:[-0.0972f,-0.1507f,0.8231f,-0.5388f]}}
particle minecraft:cloud -59.52 69.27 -35.44 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud -57.86 69.27 -35.33 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -57.86 69.07 -35.33 -0.002 0.02 0.036 1 0 force
scoreboard players set #gx driftmountains -63051
scoreboard players set #gdx driftmountains 486
scoreboard players set #gy driftmountains 69092
scoreboard players set #gdy driftmountains -13
scoreboard players set #gz driftmountains -35009
scoreboard players set #gdz driftmountains -253
scoreboard players set #gr driftmountains -15042
scoreboard players set #gdr driftmountains -300
scoreboard players set #gp driftmountains 110
scoreboard players set #gdp driftmountains 8
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[0.0061f,-0.0001f,0.0206f,0.9998f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.9819f,0.0521f,0.1821f,0.0059f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[-0.1825f,-0.0132f,0.9818f,0.0508f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.9264f,0.0121f,-0.0049f,-0.3762f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0049f,-0.3762f,0.9264f,0.0121f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.4017f,0.8642f,0.2468f],left_rotation:[-0.0130f,-0.1901f,0.9768f,-0.0981f]}}
particle minecraft:cloud -64.47 69.41 -34.24 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud -62.98 69.41 -33.40 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -62.98 69.21 -33.40 -0.018 0.02 0.032 1 0 force
scoreboard players set #gx driftmountains -67476
scoreboard players set #gdx driftmountains 600
scoreboard players set #gy driftmountains 69178
scoreboard players set #gdy driftmountains -9
scoreboard players set #gz driftmountains -32010
scoreboard players set #gdz driftmountains -243
scoreboard players set #gr driftmountains -12330
scoreboard players set #gdr driftmountains -227
scoreboard players set #gp driftmountains 81
scoreboard players set #gdp driftmountains 2
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[0.0061f,-0.0000f,0.0068f,1.0000f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.4013f,-0.0677f,0.0873f,0.9093f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.0078f,0.9051f,0.4106f,0.1102f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.9264f,0.0121f,-0.0049f,-0.3762f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0049f,-0.3762f,0.9264f,0.0121f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3809f,0.8662f,0.1075f],left_rotation:[0.1226f,-0.1473f,0.7635f,0.6166f]}}
particle minecraft:cloud -68.99 69.50 -32.02 0.35 0.18 0.35 0.02 2 force
particle minecraft:cloud -68.07 69.50 -30.62 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -68.07 69.30 -30.62 -0.037 0.02 0.024 1 0 force
