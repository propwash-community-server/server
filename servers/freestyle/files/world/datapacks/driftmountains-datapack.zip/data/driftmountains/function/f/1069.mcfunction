scoreboard players set #gx driftmountains -20862
scoreboard players set #gdx driftmountains -1091
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 57239
scoreboard players set #gdz driftmountains -337
scoreboard players set #gr driftmountains 15345
scoreboard players set #gdr driftmountains 27
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.5902f,-0.2620f,-0.2935f,-0.7049f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.2210f,-0.6780f,0.6210f,0.3255f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.0035f,0.0000f,0.0131f,0.9999f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0131f,0.9999f,0.0035f,0.0000f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3646f,0.8240f,0.0909f],left_rotation:[-0.1610f,-0.0832f,0.4743f,-0.8614f]}}
particle minecraft:cloud -21.05 71.32 58.74 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -21.05 71.12 58.74 0.031 0.02 0.061 1 0 force
particle minecraft:cloud -19.55 71.32 57.99 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -11818
scoreboard players set #gdx driftmountains -1004
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 59695
scoreboard players set #gdz driftmountains -266
scoreboard players set #gr driftmountains 15075
scoreboard players set #gdr driftmountains -17
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.9188f,0.0347f,-0.3896f,-0.0523f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.3863f,-0.0116f,0.9202f,0.0617f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.0035f,0.0000f,0.0131f,0.9999f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0131f,0.9999f,0.0035f,0.0000f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3859f,0.8276f,0.2325f],left_rotation:[-0.1574f,-0.0842f,0.4543f,-0.8728f]}}
particle minecraft:cloud -11.90 71.32 61.30 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -11.90 71.12 61.30 0.030 0.02 0.054 1 0 force
particle minecraft:cloud -10.40 71.32 60.47 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -6985
scoreboard players set #gdx driftmountains -1045
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 61167
scoreboard players set #gdz driftmountains -277
scoreboard players set #gr driftmountains 15494
scoreboard players set #gdr driftmountains -79
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.2745f,0.4158f,-0.0716f,0.8641f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.1628f,0.8764f,0.2323f,-0.3892f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.0035f,0.0000f,0.0131f,0.9999f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0131f,0.9999f,0.0035f,0.0000f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3780f,0.8210f,0.0897f],left_rotation:[-0.1275f,-0.1262f,0.6980f,-0.6932f]}}
particle minecraft:cloud -7.21 71.32 62.66 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -7.21 71.12 62.66 0.027 0.02 0.058 1 0 force
particle minecraft:cloud -5.69 71.32 61.95 0.35 0.18 0.35 0.02 3 force
