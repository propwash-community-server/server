scoreboard players set #gx driftmountains -96977
scoreboard players set #gdx driftmountains 316
scoreboard players set #gy driftmountains 69888
scoreboard players set #gdy driftmountains -16
scoreboard players set #gz driftmountains -15421
scoreboard players set #gdz driftmountains -676
scoreboard players set #gr driftmountains -10741
scoreboard players set #gdr driftmountains 362
scoreboard players set #gp driftmountains 80
scoreboard players set #gdp driftmountains 3
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0001f,-0.0223f,0.9997f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.5834f,-0.2223f,-0.2453f,-0.7416f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.1687f,-0.7199f,0.6100f,0.2848f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.8797f,0.0115f,0.0062f,0.4753f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0062f,0.4753f,0.8797f,0.0115f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3527f,0.8479f,0.1003f],left_rotation:[-0.1867f,0.0270f,-0.1094f,-0.9759f]}}
particle minecraft:cloud -98.43 70.21 -15.84 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -98.43 70.01 -15.84 -0.043 0.02 0.013 1 0 force
particle minecraft:cloud -97.93 70.21 -14.25 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -98187
scoreboard players set #gdx driftmountains 9
scoreboard players set #gy driftmountains 70008
scoreboard players set #gdy driftmountains -9
scoreboard players set #gz driftmountains -8310
scoreboard players set #gdz driftmountains -838
scoreboard players set #gr driftmountains -13112
scoreboard players set #gdr driftmountains 186
scoreboard players set #gp driftmountains 36
scoreboard players set #gdp driftmountains 7
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.4377f,-0.2945f,-0.2209f,-0.8203f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.1359f,-0.8016f,0.4711f,0.3422f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.8797f,0.0115f,0.0062f,0.4753f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0062f,0.4753f,0.8797f,0.0115f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3745f,0.8279f,0.2326f],left_rotation:[-0.1731f,-0.0431f,0.2456f,-0.9529f]}}
particle minecraft:cloud -99.78 70.33 -8.06 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -99.78 70.13 -8.06 -0.037 0.02 0.032 1 0 force
particle minecraft:cloud -98.65 70.33 -6.77 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -97692
scoreboard players set #gdx driftmountains -174
scoreboard players set #gy driftmountains 70033
scoreboard players set #gdy driftmountains -1
scoreboard players set #gz driftmountains -3140
scoreboard players set #gdz driftmountains -910
scoreboard players set #gr driftmountains -14069
scoreboard players set #gdr driftmountains 174
scoreboard players set #gp driftmountains 3
scoreboard players set #gdp driftmountains 5
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.9199f,0.0399f,-0.3881f,-0.0401f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.3860f,0.0004f,0.9208f,0.0566f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.8797f,0.0115f,0.0062f,0.4753f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0062f,0.4753f,0.8797f,0.0115f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3632f,0.8248f,0.0912f],left_rotation:[-0.1641f,-0.0777f,0.4456f,-0.8766f]}}
particle minecraft:cloud -99.14 70.35 -2.69 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -99.14 70.15 -2.69 -0.033 0.02 0.041 1 0 force
particle minecraft:cloud -97.84 70.35 -1.64 0.35 0.18 0.35 0.02 3 force
