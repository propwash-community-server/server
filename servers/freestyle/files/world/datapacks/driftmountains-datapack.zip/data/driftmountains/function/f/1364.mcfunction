scoreboard players set #gx driftmountains -14073
scoreboard players set #gdx driftmountains 752
scoreboard players set #gy driftmountains 67056
scoreboard players set #gdy driftmountains -10
scoreboard players set #gz driftmountains -80645
scoreboard players set #gdz driftmountains 476
scoreboard players set #gr driftmountains -3548
scoreboard players set #gdr driftmountains -96
scoreboard players set #gp driftmountains 62
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0001f,-0.0136f,0.9999f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.9613f,0.0895f,-0.1753f,0.1926f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.1965f,0.2121f,0.9572f,0.0111f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.8299f,0.0109f,-0.0073f,-0.5577f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0073f,-0.5577f,0.8299f,0.0109f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3996f,0.8520f,0.1019f],left_rotation:[-0.0368f,0.1828f,-0.9695f,-0.1589f]}}
particle minecraft:cloud -14.12 67.38 -82.16 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -14.12 67.18 -82.16 -0.031 0.02 -0.043 1 0 force
particle minecraft:cloud -15.48 67.38 -81.19 0.35 0.18 0.35 0.02 2 force
scoreboard players set #gx driftmountains -20670
scoreboard players set #gdx driftmountains 723
scoreboard players set #gy driftmountains 67148
scoreboard players set #gdy driftmountains -11
scoreboard players set #gz driftmountains -84315
scoreboard players set #gdz driftmountains 442
scoreboard players set #gr driftmountains -3062
scoreboard players set #gdr driftmountains 6
scoreboard players set #gp driftmountains 64
scoreboard players set #gdp driftmountains -1
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0001f,-0.0171f,0.9998f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.6535f,0.2095f,-0.1180f,0.7177f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.1941f,0.7340f,0.6351f,-0.1420f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.8299f,0.0109f,-0.0073f,-0.5577f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0073f,-0.5577f,0.8299f,0.0109f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3710f,0.8724f,0.2500f],left_rotation:[-0.1031f,0.1625f,-0.8189f,-0.5408f]}}
particle minecraft:cloud -20.63 67.47 -85.93 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -20.63 67.27 -85.93 -0.026 0.02 -0.044 1 0 force
particle minecraft:cloud -22.10 67.47 -85.05 0.35 0.18 0.35 0.02 2 force
scoreboard players set #gx driftmountains -27692
scoreboard players set #gdx driftmountains 594
scoreboard players set #gy driftmountains 67262
scoreboard players set #gdy driftmountains -10
scoreboard players set #gz driftmountains -88933
scoreboard players set #gdz driftmountains 301
scoreboard players set #gr driftmountains -3398
scoreboard players set #gdr driftmountains 34
scoreboard players set #gp driftmountains 73
scoreboard players set #gdp driftmountains -1
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0001f,-0.0179f,0.9998f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.7611f,-0.1043f,-0.2188f,-0.6017f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.1567f,-0.5820f,0.7762f,0.1848f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.8299f,0.0109f,-0.0073f,-0.5577f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0073f,-0.5577f,0.8299f,0.0109f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3846f,0.8654f,0.1071f],left_rotation:[-0.1110f,0.1556f,-0.8101f,-0.5542f]}}
particle minecraft:cloud -27.70 67.58 -90.44 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -27.70 67.38 -90.44 -0.025 0.02 -0.037 1 0 force
particle minecraft:cloud -29.09 67.58 -89.51 0.35 0.18 0.35 0.02 2 force
