scoreboard players set #gx driftmountains -28839
scoreboard players set #gdx driftmountains 666
scoreboard players set #gy driftmountains 67278
scoreboard players set #gdy driftmountains -11
scoreboard players set #gz driftmountains -89074
scoreboard players set #gdz driftmountains 318
scoreboard players set #gr driftmountains -3506
scoreboard players set #gdr driftmountains 27
scoreboard players set #gp driftmountains 75
scoreboard players set #gdp driftmountains -1
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0001f,-0.0181f,0.9998f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.7434f,0.1937f,-0.1473f,0.6229f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.2136f,0.6419f,0.7272f,-0.1167f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.1419f,0.0019f,-0.0130f,-0.9898f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0130f,-0.9898f,0.1419f,0.0019f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3842f,0.8655f,0.1072f],left_rotation:[-0.1125f,0.1546f,-0.8046f,-0.5622f]}}
particle minecraft:cloud -28.88 67.60 -90.59 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -28.88 67.40 -90.59 -0.025 0.02 -0.036 1 0 force
particle minecraft:cloud -30.25 67.60 -89.63 0.35 0.18 0.35 0.02 2 force
scoreboard players set #gx driftmountains -34688
scoreboard players set #gdx driftmountains 662
scoreboard players set #gy driftmountains 67386
scoreboard players set #gdy driftmountains -13
scoreboard players set #gz driftmountains -91275
scoreboard players set #gdz driftmountains 178
scoreboard players set #gr driftmountains -4272
scoreboard players set #gdr driftmountains 190
scoreboard players set #gp driftmountains 93
scoreboard players set #gdp driftmountains -1
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0001f,-0.0205f,0.9998f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.8081f,-0.0694f,-0.1966f,-0.5509f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.1398f,-0.5333f,0.8198f,0.1547f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.1419f,0.0019f,-0.0130f,-0.9898f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0130f,-0.9898f,0.1419f,0.0019f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3863f,0.8738f,0.2506f],left_rotation:[-0.0537f,0.1856f,-0.9441f,-0.2673f]}}
particle minecraft:cloud -34.99 67.71 -92.86 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -34.99 67.51 -92.86 -0.026 0.02 -0.028 1 0 force
particle minecraft:cloud -36.24 67.71 -91.70 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -40289
scoreboard players set #gdx driftmountains 525
scoreboard players set #gy driftmountains 67524
scoreboard players set #gdy driftmountains -14
scoreboard players set #gz driftmountains -92106
scoreboard players set #gdz driftmountains -137
scoreboard players set #gr driftmountains -7046
scoreboard players set #gdr driftmountains 389
scoreboard players set #gp driftmountains 119
scoreboard players set #gdp driftmountains 4
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.8828f,0.1226f,-0.1288f,0.4348f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.1752f,0.4507f,0.8748f,-0.0305f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.1419f,0.0019f,-0.0130f,-0.9898f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0130f,-0.9898f,0.1419f,0.0019f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.4013f,0.8438f,0.0987f],left_rotation:[-0.0026f,0.1841f,-0.9826f,0.0206f]}}
particle minecraft:cloud -41.20 67.84 -93.31 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -41.20 67.64 -93.31 -0.031 0.02 -0.011 1 0 force
particle minecraft:cloud -41.76 67.84 -91.74 0.35 0.18 0.35 0.02 3 force
