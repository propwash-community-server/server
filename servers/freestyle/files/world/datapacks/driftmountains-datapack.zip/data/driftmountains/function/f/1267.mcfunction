scoreboard players set #gx driftmountains -54851
scoreboard players set #gdx driftmountains -149
scoreboard players set #gy driftmountains 68309
scoreboard players set #gdy driftmountains -13
scoreboard players set #gz driftmountains -58336
scoreboard players set #gdz driftmountains -733
scoreboard players set #gr driftmountains 15617
scoreboard players set #gdr driftmountains 440
scoreboard players set #gp driftmountains 101
scoreboard players set #gdp driftmountains -1
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,0.0000f,0.0074f,1.0000f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.9261f,0.0108f,0.1181f,0.3581f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[-0.0811f,0.3477f,0.9301f,0.0865f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.8868f,0.0116f,0.0060f,0.4620f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0060f,0.4620f,0.8868f,0.0116f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3848f,0.8653f,0.1071f],left_rotation:[0.1104f,-0.1560f,0.8125f,0.5507f]}}
particle minecraft:cloud -55.11 68.63 -56.85 0.35 0.18 0.35 0.02 2 force
particle minecraft:cloud -53.58 68.63 -57.52 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -53.58 68.43 -57.52 0.018 0.02 0.041 1 0 force
scoreboard players set #gx driftmountains -53950
scoreboard players set #gdx driftmountains 35
scoreboard players set #gy driftmountains 68442
scoreboard players set #gdy driftmountains -24
scoreboard players set #gz driftmountains -52532
scoreboard players set #gdz driftmountains -763
scoreboard players set #gr driftmountains 15078
scoreboard players set #gdr driftmountains -457
scoreboard players set #gp driftmountains 160
scoreboard players set #gdp driftmountains -25
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[0.0058f,-0.0001f,0.0208f,0.9998f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.7639f,-0.0802f,0.1852f,0.6129f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[-0.1218f,0.5969f,0.7766f,0.1609f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.8868f,0.0116f,0.0060f,0.4620f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0060f,0.4620f,0.8868f,0.0116f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.4046f,0.8593f,0.2449f],left_rotation:[-0.0343f,-0.1859f,0.9584f,-0.2140f]}}
particle minecraft:cloud -54.03 68.76 -50.92 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud -52.54 68.76 -51.76 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -52.54 68.56 -51.76 0.020 0.02 0.036 1 0 force
scoreboard players set #gx driftmountains -54927
scoreboard players set #gdx driftmountains 169
scoreboard players set #gy driftmountains 68616
scoreboard players set #gdy driftmountains -25
scoreboard players set #gz driftmountains -47230
scoreboard players set #gdz driftmountains -831
scoreboard players set #gr driftmountains 16054
scoreboard players set #gdr driftmountains -90
scoreboard players set #gp driftmountains 143
scoreboard players set #gdp driftmountains 1
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,0.0001f,0.0191f,0.9998f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.4702f,-0.1959f,0.1712f,0.8433f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[-0.0835f,0.8300f,0.4934f,0.2464f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.8868f,0.0116f,0.0060f,0.4620f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0060f,0.4620f,0.8868f,0.0116f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3782f,0.8210f,0.0897f],left_rotation:[-0.1270f,-0.1266f,0.7001f,-0.6911f]}}
particle minecraft:cloud -55.29 68.94 -45.76 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud -53.72 68.94 -46.32 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -53.72 68.74 -46.32 0.015 0.02 0.042 1 0 force
