scoreboard players set #gx driftmountains -54896
scoreboard players set #gdx driftmountains 145
scoreboard players set #gy driftmountains 68704
scoreboard players set #gdy driftmountains -20
scoreboard players set #gz driftmountains -44087
scoreboard players set #gdz driftmountains -681
scoreboard players set #gr driftmountains 16116
scoreboard players set #gdr driftmountains -188
scoreboard players set #gp driftmountains 139
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,0.0001f,0.0195f,0.9998f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.9731f,0.0421f,0.2207f,0.0510f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[-0.2165f,0.0281f,0.9740f,0.0599f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.0920f,0.0012f,0.0130f,0.9957f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0130f,0.9957f,0.0920f,0.0012f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3933f,0.8269f,0.0920f],left_rotation:[-0.0737f,-0.1641f,0.8903f,-0.4181f]}}
particle minecraft:cloud -55.28 69.02 -42.62 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud -53.70 69.02 -43.16 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -53.70 68.82 -43.16 0.013 0.02 0.039 1 0 force
scoreboard players set #gx driftmountains -57708
scoreboard players set #gdx driftmountains 327
scoreboard players set #gy driftmountains 68838
scoreboard players set #gdy driftmountains -19
scoreboard players set #gz driftmountains -40440
scoreboard players set #gdz driftmountains -531
scoreboard players set #gr driftmountains 17752
scoreboard players set #gdr driftmountains -197
scoreboard players set #gp driftmountains 146
scoreboard players set #gdp driftmountains -1
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[-0.0039f,0.0001f,0.0214f,0.9998f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.4384f,-0.1815f,0.1520f,0.8670f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[-0.0618f,0.8558f,0.4599f,0.2286f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.0920f,0.0012f,0.0130f,0.9957f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0130f,0.9957f,0.0920f,0.0012f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.4052f,0.8438f,0.2388f],left_rotation:[-0.0906f,-0.1603f,0.8351f,-0.5184f]}}
particle minecraft:cloud -58.50 69.16 -39.04 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud -56.79 69.16 -39.11 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -56.79 68.96 -39.11 0.002 0.02 0.038 1 0 force
scoreboard players set #gx driftmountains -60654
scoreboard players set #gdx driftmountains 427
scoreboard players set #gy driftmountains 69019
scoreboard players set #gdy driftmountains -22
scoreboard players set #gz driftmountains -35607
scoreboard players set #gdz driftmountains -475
scoreboard players set #gr driftmountains -17059
scoreboard players set #gdr driftmountains -338
scoreboard players set #gp driftmountains 170
scoreboard players set #gdp driftmountains -10
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,0.0001f,0.0210f,0.9998f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.5506f,0.1788f,0.0568f,-0.8134f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[-0.1426f,-0.8238f,0.5349f,-0.1219f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.0920f,0.0012f,0.0130f,0.9957f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0130f,0.9957f,0.0920f,0.0012f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.4011f,0.8410f,0.0976f],left_rotation:[-0.0091f,-0.1831f,0.9796f,-0.0820f]}}
particle minecraft:cloud -61.68 69.34 -34.50 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud -60.04 69.34 -34.23 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -60.04 69.14 -34.23 -0.006 0.02 0.034 1 0 force
