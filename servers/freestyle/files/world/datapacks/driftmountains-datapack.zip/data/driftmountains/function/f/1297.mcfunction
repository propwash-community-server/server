scoreboard players set #gx driftmountains -54258
scoreboard players set #gdx driftmountains 305
scoreboard players set #gy driftmountains 67894
scoreboard players set #gdy driftmountains -12
scoreboard players set #gz driftmountains -78098
scoreboard players set #gdz driftmountains -593
scoreboard players set #gr driftmountains -12167
scoreboard players set #gdr driftmountains 72
scoreboard players set #gp driftmountains 90
scoreboard players set #gdp driftmountains -3
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0001f,-0.0193f,0.9998f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.2570f,0.2459f,-0.0117f,0.9345f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.1100f,0.9409f,0.2326f,-0.2203f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.5257f,0.0069f,-0.0111f,-0.8506f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0111f,-0.8506f,0.5257f,0.0069f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3829f,0.8658f,0.1073f],left_rotation:[-0.1166f,0.1518f,-0.7887f,-0.5841f]}}
particle minecraft:cloud -55.77 68.21 -78.15 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -55.77 68.01 -78.15 -0.034 0.02 0.021 1 0 force
particle minecraft:cloud -54.89 68.21 -76.73 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -55572
scoreboard players set #gdx driftmountains 197
scoreboard players set #gy driftmountains 67996
scoreboard players set #gdy driftmountains -18
scoreboard players set #gz driftmountains -73615
scoreboard players set #gdz driftmountains -633
scoreboard players set #gr driftmountains -12775
scoreboard players set #gdr driftmountains 158
scoreboard players set #gp driftmountains 141
scoreboard players set #gdp driftmountains -24
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.8702f,0.1464f,-0.1716f,0.4381f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.2185f,0.4586f,0.8596f,-0.0558f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.5257f,0.0069f,-0.0111f,-0.8506f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0111f,-0.8506f,0.5257f,0.0069f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3780f,0.8741f,0.2507f],left_rotation:[-0.0810f,0.1753f,-0.8876f,-0.4183f]}}
particle minecraft:cloud -57.17 68.32 -73.46 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -57.17 68.12 -73.46 -0.031 0.02 0.024 1 0 force
particle minecraft:cloud -56.13 68.32 -72.10 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -55309
scoreboard players set #gdx driftmountains -33
scoreboard players set #gy driftmountains 68151
scoreboard players set #gdy driftmountains -12
scoreboard players set #gz driftmountains -67957
scoreboard players set #gdz driftmountains -623
scoreboard players set #gr driftmountains -15592
scoreboard players set #gdr driftmountains 222
scoreboard players set #gp driftmountains 96
scoreboard players set #gdp driftmountains 2
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[0.0061f,0.0001f,-0.0168f,0.9998f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.1780f,0.2181f,0.0140f,0.9595f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.0867f,0.9633f,0.1560f,-0.2005f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.5257f,0.0069f,-0.0111f,-0.8506f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0111f,-0.8506f,0.5257f,0.0069f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3941f,0.8599f,0.1050f],left_rotation:[-0.0740f,0.1739f,-0.9152f,-0.3559f]}}
particle minecraft:cloud -56.59 68.47 -67.15 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -56.59 68.27 -67.15 -0.017 0.02 0.039 1 0 force
particle minecraft:cloud -55.06 68.47 -66.47 0.35 0.18 0.35 0.02 2 force
