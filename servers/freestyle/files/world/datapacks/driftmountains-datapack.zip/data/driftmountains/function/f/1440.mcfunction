scoreboard players set #gx driftmountains 60007
scoreboard players set #gdx driftmountains 1150
scoreboard players set #gy driftmountains 66145
scoreboard players set #gdy driftmountains -13
scoreboard players set #gz driftmountains -32697
scoreboard players set #gdz driftmountains 868
scoreboard players set #gr driftmountains -6786
scoreboard players set #gdr driftmountains -164
scoreboard players set #gp driftmountains 48
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,0.0000f,0.0090f,1.0000f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.3008f,-0.1090f,0.0902f,0.9431f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.0084f,0.9388f,0.3139f,0.1413f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.8013f,0.0105f,0.0078f,0.5981f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0078f,0.5981f,0.8013f,0.0105f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3943f,0.8597f,0.1049f],left_rotation:[0.0730f,-0.1743f,0.9171f,0.3509f]}}
particle minecraft:cloud 59.15 66.46 -33.95 0.35 0.18 0.35 0.02 2 force
particle minecraft:cloud 58.53 66.46 -32.40 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke 58.53 66.26 -32.40 -0.080 0.02 -0.033 1 0 force
scoreboard players set #gx driftmountains 51930
scoreboard players set #gdx driftmountains 1244
scoreboard players set #gy driftmountains 66224
scoreboard players set #gdy driftmountains -13
scoreboard players set #gz driftmountains -36835
scoreboard players set #gdz driftmountains 702
scoreboard players set #gr driftmountains -4871
scoreboard players set #gdr driftmountains -480
scoreboard players set #gp driftmountains 50
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0000f,-0.0072f,1.0000f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.3595f,-0.0790f,-0.0872f,-0.9257f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[-0.0097f,-0.9216f,0.3698f,0.1173f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.8013f,0.0105f,0.0078f,0.5981f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0078f,0.5981f,0.8013f,0.0105f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.4041f,0.8412f,0.2378f],left_rotation:[0.0996f,0.1539f,-0.8034f,0.5666f]}}
particle minecraft:cloud 51.47 66.54 -38.38 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke 51.47 66.34 -38.38 -0.064 0.02 -0.056 1 0 force
particle minecraft:cloud 50.34 66.54 -37.09 0.35 0.18 0.35 0.02 2 force
scoreboard players set #gx driftmountains 41328
scoreboard players set #gdx driftmountains 1134
scoreboard players set #gy driftmountains 66341
scoreboard players set #gdy driftmountains -14
scoreboard players set #gz driftmountains -43755
scoreboard players set #gdz driftmountains 890
scoreboard players set #gr driftmountains -3411
scoreboard players set #gdr driftmountains 236
scoreboard players set #gp driftmountains 52
scoreboard players set #gdp driftmountains -1
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0000f,-0.0108f,0.9999f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.2822f,0.1645f,0.0062f,0.9451f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.0931f,0.9497f,0.2665f,-0.1357f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.8013f,0.0105f,0.0078f,0.5981f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0078f,0.5981f,0.8013f,0.0105f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.4005f,0.8381f,0.0964f],left_rotation:[0.0213f,0.1813f,-0.9723f,0.1459f]}}
particle minecraft:cloud 41.31 66.66 -45.27 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke 41.31 66.46 -45.27 -0.047 0.02 -0.069 1 0 force
particle minecraft:cloud 39.93 66.66 -44.33 0.35 0.18 0.35 0.02 2 force
