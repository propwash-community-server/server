scoreboard players set #gx driftmountains -16297
scoreboard players set #gdx driftmountains 736
scoreboard players set #gy driftmountains 67088
scoreboard players set #gdy driftmountains -10
scoreboard players set #gz driftmountains -82044
scoreboard players set #gdz driftmountains 461
scoreboard players set #gr driftmountains -3276
scoreboard players set #gdr driftmountains -85
scoreboard players set #gp driftmountains 62
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0001f,-0.0154f,0.9999f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.5419f,0.2079f,-0.0744f,0.8110f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.1601f,0.8232f,0.5230f,-0.1521f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.9826f,0.0129f,0.0024f,0.1853f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0024f,0.1853f,0.9826f,0.0129f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3933f,0.8606f,0.1053f],left_rotation:[-0.0777f,0.1726f,-0.9071f,-0.3759f]}}
particle minecraft:cloud -16.28 67.41 -83.55 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -16.28 67.21 -83.55 -0.028 0.02 -0.044 1 0 force
particle minecraft:cloud -17.68 67.41 -82.65 0.35 0.18 0.35 0.02 2 force
scoreboard players set #gx driftmountains -22811
scoreboard players set #gdx driftmountains 756
scoreboard players set #gy driftmountains 67181
scoreboard players set #gdy driftmountains -12
scoreboard players set #gz driftmountains -85598
scoreboard players set #gdz driftmountains 448
scoreboard players set #gr driftmountains -3119
scoreboard players set #gdr driftmountains 25
scoreboard players set #gp driftmountains 67
scoreboard players set #gdp driftmountains -1
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0001f,-0.0173f,0.9998f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.1032f,0.2375f,0.0288f,0.9655f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.0726f,0.9678f,0.0788f,-0.2280f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.9826f,0.0129f,0.0024f,0.1853f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0024f,0.1853f,0.9826f,0.0129f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3716f,0.8726f,0.2501f],left_rotation:[-0.1014f,0.1637f,-0.8251f,-0.5312f]}}
particle minecraft:cloud -22.79 67.50 -87.21 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -22.79 67.30 -87.21 -0.025 0.02 -0.042 1 0 force
particle minecraft:cloud -24.25 67.50 -86.32 0.35 0.18 0.35 0.02 2 force
scoreboard players set #gx driftmountains -29742
scoreboard players set #gdx driftmountains 708
scoreboard players set #gy driftmountains 67296
scoreboard players set #gdy driftmountains -12
scoreboard players set #gz driftmountains -89918
scoreboard players set #gdz driftmountains 330
scoreboard players set #gr driftmountains -3545
scoreboard players set #gdr driftmountains 65
scoreboard players set #gp driftmountains 76
scoreboard players set #gdp driftmountains -1
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0001f,-0.0183f,0.9998f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.8611f,-0.0602f,-0.2323f,-0.4483f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.1864f,-0.4264f,0.8721f,0.1511f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.9826f,0.0129f,0.0024f,0.1853f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0024f,0.1853f,0.9826f,0.0129f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3857f,0.8650f,0.1070f],left_rotation:[-0.1076f,0.1578f,-0.8227f,-0.5354f]}}
particle minecraft:cloud -29.79 67.62 -91.43 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -29.79 67.42 -91.43 -0.025 0.02 -0.035 1 0 force
particle minecraft:cloud -31.15 67.62 -90.46 0.35 0.18 0.35 0.02 3 force
