scoreboard players set #gx driftmountains 3254
scoreboard players set #gdx driftmountains 529
scoreboard players set #gy driftmountains 70548
scoreboard players set #gdy driftmountains 56
scoreboard players set #gz driftmountains -20328
scoreboard players set #gdz driftmountains 678
scoreboard players set #gr driftmountains 691
scoreboard players set #gdr driftmountains 257
scoreboard players set #gp driftmountains -234
scoreboard players set #gdp driftmountains -58
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.4272f,-0.2652f,-0.1967f,-0.8417f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.1094f,-0.8256f,0.4575f,0.3116f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.8777f,0.0115f,-0.0063f,-0.4790f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0063f,-0.4790f,0.8777f,0.0115f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3528f,0.8483f,0.1004f],left_rotation:[-0.1866f,0.0285f,-0.1173f,-0.9749f]}}
particle minecraft:cloud 4.23 70.87 -21.48 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 4.23 70.67 -21.48 0.006 0.02 -0.051 1 0 force
particle minecraft:cloud 2.58 70.87 -21.68 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -469
scoreboard players set #gdx driftmountains 658
scoreboard players set #gy driftmountains 70522
scoreboard players set #gdy driftmountains -11
scoreboard players set #gz driftmountains -24401
scoreboard players set #gdz driftmountains 504
scoreboard players set #gr driftmountains -867
scoreboard players set #gdr driftmountains 165
scoreboard players set #gp driftmountains 37
scoreboard players set #gdp driftmountains 21
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.7953f,-0.1351f,-0.3225f,-0.4952f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.2722f,-0.4640f,0.8139f,0.2194f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.8777f,0.0115f,-0.0063f,-0.4790f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0063f,-0.4790f,0.8777f,0.0115f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3662f,0.8316f,0.2340f],left_rotation:[-0.1792f,-0.0085f,0.0693f,-0.9814f]}}
particle minecraft:cloud 0.17 70.84 -25.88 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 0.17 70.64 -25.88 -0.007 0.02 -0.049 1 0 force
particle minecraft:cloud -1.52 70.84 -25.62 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -4539
scoreboard players set #gdx driftmountains 748
scoreboard players set #gy driftmountains 70389
scoreboard players set #gdy driftmountains 52
scoreboard players set #gz driftmountains -26718
scoreboard players set #gdz driftmountains 510
scoreboard players set #gr driftmountains -1103
scoreboard players set #gdr driftmountains 74
scoreboard players set #gp driftmountains -258
scoreboard players set #gdp driftmountains 56
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.6854f,0.2806f,-0.2207f,0.6347f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.2886f,0.6614f,0.6596f,-0.2101f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.8777f,0.0115f,-0.0063f,-0.4790f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0063f,-0.4790f,0.8777f,0.0115f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3536f,0.8365f,0.0958f],left_rotation:[-0.1845f,-0.0196f,0.1394f,-0.9727f]}}
particle minecraft:cloud -3.96 70.71 -28.11 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -3.96 70.51 -28.11 -0.008 0.02 -0.043 1 0 force
particle minecraft:cloud -5.60 70.71 -27.80 0.35 0.18 0.35 0.02 3 force
