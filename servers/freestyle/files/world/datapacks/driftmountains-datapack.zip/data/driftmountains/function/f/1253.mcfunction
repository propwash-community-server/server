scoreboard players set #gx driftmountains -54238
scoreboard players set #gdx driftmountains 77
scoreboard players set #gy driftmountains 68582
scoreboard players set #gdy driftmountains -21
scoreboard players set #gz driftmountains -48319
scoreboard players set #gdz driftmountains -736
scoreboard players set #gr driftmountains 15385
scoreboard players set #gdr driftmountains -8
scoreboard players set #gp driftmountains 140
scoreboard players set #gdp driftmountains 1
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,0.0001f,0.0196f,0.9998f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.9549f,0.0885f,0.2531f,-0.1273f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[-0.2679f,-0.1546f,0.9509f,0.0114f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.9969f,0.0131f,-0.0010f,-0.0774f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0010f,-0.0774f,0.9969f,0.0131f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3744f,0.8211f,0.0898f],left_rotation:[-0.1372f,-0.1160f,0.6452f,-0.7425f]}}
particle minecraft:cloud -54.43 68.90 -46.82 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud -52.93 68.90 -47.56 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -52.93 68.70 -47.56 0.019 0.02 0.040 1 0 force
scoreboard players set #gx driftmountains -56009
scoreboard players set #gdx driftmountains 257
scoreboard players set #gy driftmountains 68721
scoreboard players set #gdy driftmountains -23
scoreboard players set #gz driftmountains -43849
scoreboard players set #gdz driftmountains -731
scoreboard players set #gr driftmountains 16601
scoreboard players set #gdr driftmountains -217
scoreboard players set #gp driftmountains 142
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[-0.0039f,0.0001f,0.0210f,0.9998f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.0647f,-0.2266f,0.0690f,0.9694f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.0325f,0.9675f,0.0888f,0.2346f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.9969f,0.0131f,-0.0010f,-0.0774f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0010f,-0.0774f,0.9969f,0.0131f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.4051f,0.8437f,0.2388f],left_rotation:[-0.0908f,-0.1602f,0.8346f,-0.5193f]}}
particle minecraft:cloud -56.51 69.04 -42.32 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud -54.85 69.04 -42.73 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -54.85 68.84 -42.73 0.010 0.02 0.040 1 0 force
scoreboard players set #gx driftmountains -58342
scoreboard players set #gdx driftmountains 360
scoreboard players set #gy driftmountains 68896
scoreboard players set #gdy driftmountains -20
scoreboard players set #gz driftmountains -38630
scoreboard players set #gdz driftmountains -533
scoreboard players set #gr driftmountains -17911
scoreboard players set #gdr driftmountains -98
scoreboard players set #gp driftmountains 148
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,0.0001f,0.0205f,0.9998f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.8939f,0.1442f,0.2066f,-0.3708f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[-0.2467f,-0.3946f,0.8837f,-0.0510f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.9969f,0.0131f,-0.0010f,-0.0774f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0010f,-0.0774f,0.9969f,0.0131f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3820f,0.8215f,0.0899f],left_rotation:[-0.1157f,-0.1368f,0.7525f,-0.6337f]}}
particle minecraft:cloud -59.20 69.22 -37.38 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud -57.53 69.22 -37.36 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -57.53 69.02 -37.36 -0.001 0.02 0.039 1 0 force
