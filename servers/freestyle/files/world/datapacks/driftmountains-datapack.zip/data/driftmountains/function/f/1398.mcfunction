scoreboard players set #gx driftmountains 14485
scoreboard players set #gdx driftmountains 949
scoreboard players set #gy driftmountains 66684
scoreboard players set #gdy driftmountains -12
scoreboard players set #gz driftmountains -61609
scoreboard players set #gdz driftmountains 625
scoreboard players set #gr driftmountains -5865
scoreboard players set #gdr driftmountains -54
scoreboard players set #gp driftmountains 61
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,0.0000f,0.0014f,1.0000f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.9494f,0.0539f,-0.0035f,-0.3094f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[-0.0290f,-0.3107f,0.9490f,0.0456f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.5129f,0.0067f,-0.0112f,-0.8583f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0112f,-0.8583f,0.5129f,0.0067f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3528f,0.8485f,0.1005f],left_rotation:[0.1865f,-0.0293f,0.1218f,0.9744f]}}
scoreboard players set #gx driftmountains 7464
scoreboard players set #gdx driftmountains 948
scoreboard players set #gy driftmountains 66773
scoreboard players set #gdy driftmountains -12
scoreboard players set #gz driftmountains -66362
scoreboard players set #gdz driftmountains 630
scoreboard players set #gr driftmountains -5483
scoreboard players set #gdr driftmountains -78
scoreboard players set #gp driftmountains 61
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0000f,-0.0010f,1.0000f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.9290f,0.0531f,0.0080f,0.3661f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.0304f,0.3673f,0.9285f,0.0442f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.5129f,0.0067f,-0.0112f,-0.8583f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0112f,-0.8583f,0.5129f,0.0067f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3677f,0.8306f,0.2336f],left_rotation:[0.1784f,0.0156f,-0.1052f,0.9782f]}}
scoreboard players set #gx driftmountains -1419
scoreboard players set #gdx driftmountains 956
scoreboard players set #gy driftmountains 66888
scoreboard players set #gdy driftmountains -12
scoreboard players set #gz driftmountains -72363
scoreboard players set #gdz driftmountains 634
scoreboard players set #gr driftmountains -5017
scoreboard players set #gdr driftmountains -50
scoreboard players set #gp driftmountains 61
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0000f,-0.0038f,1.0000f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.9570f,0.0349f,-0.0675f,-0.2801f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.0384f,-0.2746f,0.9586f,0.0655f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.5129f,0.0067f,-0.0112f,-0.8583f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0112f,-0.8583f,0.5129f,0.0067f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3644f,0.8241f,0.0909f],left_rotation:[0.1615f,0.0824f,-0.4704f,0.8636f]}}
