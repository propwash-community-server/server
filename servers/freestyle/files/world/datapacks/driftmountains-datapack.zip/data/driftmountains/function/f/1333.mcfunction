scoreboard players set #gx driftmountains -35377
scoreboard players set #gdx driftmountains 653
scoreboard players set #gy driftmountains 67399
scoreboard players set #gdy driftmountains -13
scoreboard players set #gz driftmountains -91453
scoreboard players set #gdz driftmountains 126
scoreboard players set #gr driftmountains -4655
scoreboard players set #gdr driftmountains 233
scoreboard players set #gp driftmountains 89
scoreboard players set #gdp driftmountains 4
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0001f,-0.0208f,0.9998f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.2346f,-0.1802f,-0.0995f,-0.9501f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.0002f,-0.9448f,0.2548f,0.2058f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.5984f,0.0078f,-0.0105f,-0.8011f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0105f,-0.8011f,0.5984f,0.0078f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3978f,0.8555f,0.1033f],left_rotation:[-0.0525f,0.1801f,-0.9520f,-0.2418f]}}
particle minecraft:cloud -35.72 67.72 -92.93 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -35.72 67.52 -92.93 -0.029 0.02 -0.027 1 0 force
particle minecraft:cloud -36.87 67.72 -91.71 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -40709
scoreboard players set #gdx driftmountains 468
scoreboard players set #gy driftmountains 67539
scoreboard players set #gdy driftmountains -13
scoreboard players set #gz driftmountains -91517
scoreboard players set #gdz driftmountains -93
scoreboard players set #gr driftmountains -6489
scoreboard players set #gdr driftmountains 311
scoreboard players set #gp driftmountains 117
scoreboard players set #gdp driftmountains 4
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[-0.0030f,-0.0001f,-0.0223f,0.9997f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.6668f,-0.1003f,-0.1655f,-0.7197f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.0908f,-0.7062f,0.6810f,0.1709f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.5984f,0.0078f,-0.0105f,-0.8011f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0105f,-0.8011f,0.5984f,0.0078f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3931f,0.8714f,0.2496f],left_rotation:[-0.0285f,0.1905f,-0.9728f,-0.1289f]}}
particle minecraft:cloud -41.58 67.86 -92.87 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -41.58 67.66 -92.87 -0.032 0.02 -0.015 1 0 force
particle minecraft:cloud -42.31 67.86 -91.32 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -45017
scoreboard players set #gdx driftmountains 364
scoreboard players set #gy driftmountains 67646
scoreboard players set #gdy driftmountains -9
scoreboard players set #gz driftmountains -89347
scoreboard players set #gdz driftmountains -304
scoreboard players set #gr driftmountains -9697
scoreboard players set #gdr driftmountains 185
scoreboard players set #gp driftmountains 89
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[0.0061f,0.0001f,-0.0208f,0.9998f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.5300f,-0.1623f,-0.1697f,-0.8148f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.0850f,-0.8015f,0.5500f,0.2189f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.5984f,0.0078f,-0.0105f,-0.8011f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0105f,-0.8011f,0.5984f,0.0078f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3879f,0.8641f,0.1066f],left_rotation:[-0.0998f,0.1623f,-0.8483f,-0.4939f]}}
particle minecraft:cloud -46.37 67.97 -90.02 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -46.37 67.77 -90.02 -0.040 0.02 0.005 1 0 force
particle minecraft:cloud -46.17 67.97 -88.37 0.35 0.18 0.35 0.02 3 force
