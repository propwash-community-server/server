scoreboard players set #gx driftmountains 17930
scoreboard players set #gdx driftmountains -788
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 56121
scoreboard players set #gdz driftmountains 823
scoreboard players set #gr driftmountains 9745
scoreboard players set #gdr driftmountains 264
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[0.0008f,0.0000f,-0.0223f,0.9998f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.9000f,0.0191f,-0.4276f,-0.0819f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.4213f,-0.0375f,0.9030f,0.0754f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.6339f,0.0083f,-0.0101f,-0.7733f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0101f,-0.7733f,0.6339f,0.0083f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3810f,0.8213f,0.0898f],left_rotation:[-0.1187f,-0.1343f,0.7394f,-0.6489f]}}
particle minecraft:cloud 19.07 71.32 57.11 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 19.07 71.12 57.11 0.068 0.02 0.009 1 0 force
particle minecraft:cloud 19.29 71.32 55.46 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains 22834
scoreboard players set #gdx driftmountains -690
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 49193
scoreboard players set #gdz driftmountains 898
scoreboard players set #gr driftmountains 9538
scoreboard players set #gdr driftmountains 171
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.6659f,0.3453f,-0.3019f,0.5884f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.3654f,0.6234f,0.6333f,-0.2772f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.6339f,0.0083f,-0.0101f,-0.7733f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0101f,-0.7733f,0.6339f,0.0083f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.4063f,0.8506f,0.2415f],left_rotation:[-0.0668f,-0.1740f,0.9017f,-0.3903f]}}
particle minecraft:cloud 24.11 71.32 50.17 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 24.11 71.12 50.17 0.068 0.02 0.006 1 0 force
particle minecraft:cloud 24.27 71.32 48.47 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains 25911
scoreboard players set #gdx driftmountains -331
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 44355
scoreboard players set #gdz driftmountains 939
scoreboard players set #gr driftmountains 7578
scoreboard players set #gdr driftmountains 169
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.4107f,-0.3647f,-0.2537f,-0.7962f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.1714f,-0.7739f,0.4512f,0.4099f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.6339f,0.0083f,-0.0101f,-0.7733f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0101f,-0.7733f,0.6339f,0.0083f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3886f,0.8238f,0.0908f],left_rotation:[-0.0932f,-0.1532f,0.8360f,-0.5185f]}}
particle minecraft:cloud 27.34 71.32 44.86 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 27.34 71.12 44.86 0.059 0.02 -0.015 1 0 force
particle minecraft:cloud 26.93 71.32 43.24 0.35 0.18 0.35 0.02 3 force
