scoreboard players set #gx driftmountains -56590
scoreboard players set #gdx driftmountains -26
scoreboard players set #gy driftmountains 68103
scoreboard players set #gdy driftmountains -13
scoreboard players set #gz driftmountains -69840
scoreboard players set #gdz driftmountains -624
scoreboard players set #gr driftmountains -15010
scoreboard players set #gdr driftmountains 226
scoreboard players set #gp driftmountains 100
scoreboard players set #gdp driftmountains 7
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[0.0061f,0.0001f,-0.0202f,0.9998f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.2451f,-0.1964f,-0.1064f,-0.9434f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.0079f,-0.9374f,0.2671f,0.2233f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.0042f,0.0001f,0.0131f,0.9999f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0131f,0.9999f,0.0042f,0.0001f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3924f,0.8614f,0.1055f],left_rotation:[-0.0820f,0.1709f,-0.8972f,-0.3987f]}}
particle minecraft:cloud -57.94 68.42 -69.16 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -57.94 68.22 -69.16 -0.019 0.02 0.033 1 0 force
particle minecraft:cloud -56.49 68.42 -68.33 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -55341
scoreboard players set #gdx driftmountains -104
scoreboard players set #gy driftmountains 68215
scoreboard players set #gdy driftmountains -13
scoreboard players set #gz driftmountains -64098
scoreboard players set #gdz driftmountains -785
scoreboard players set #gr driftmountains -16946
scoreboard players set #gdr driftmountains 413
scoreboard players set #gp driftmountains 90
scoreboard players set #gdp driftmountains -1
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[-0.0033f,-0.0000f,-0.0111f,0.9999f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.6074f,-0.0861f,-0.1344f,-0.7782f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.0533f,-0.7684f,0.6198f,0.1504f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.0042f,0.0001f,0.0131f,0.9999f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0131f,0.9999f,0.0042f,0.0001f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.4041f,0.8603f,0.2453f],left_rotation:[0.0304f,0.1869f,-0.9628f,0.1927f]}}
particle minecraft:cloud -56.43 68.53 -62.91 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -56.43 68.33 -62.91 -0.009 0.02 0.046 1 0 force
particle minecraft:cloud -54.75 68.53 -62.60 0.35 0.18 0.35 0.02 2 force
scoreboard players set #gx driftmountains -54213
scoreboard players set #gdx driftmountains -89
scoreboard players set #gy driftmountains 68326
scoreboard players set #gdy driftmountains -12
scoreboard players set #gz driftmountains -57698
scoreboard players set #gdz driftmountains -681
scoreboard players set #gr driftmountains 15633
scoreboard players set #gdr driftmountains 306
scoreboard players set #gp driftmountains 99
scoreboard players set #gdp driftmountains -2
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,0.0000f,0.0100f,0.9999f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.4577f,-0.0935f,0.1083f,0.8775f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[-0.0167f,0.8710f,0.4700f,0.1422f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.0042f,0.0001f,0.0131f,0.9999f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0131f,0.9999f,0.0042f,0.0001f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3948f,0.8592f,0.1047f],left_rotation:[0.0702f,-0.1752f,0.9227f,0.3361f]}}
particle minecraft:cloud -54.47 68.65 -56.21 0.35 0.18 0.35 0.02 2 force
particle minecraft:cloud -52.94 68.65 -56.88 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -52.94 68.45 -56.88 0.016 0.02 0.037 1 0 force
