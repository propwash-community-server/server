scoreboard players set #gx driftmountains -85641
scoreboard players set #gdx driftmountains -764
scoreboard players set #gy driftmountains 69996
scoreboard players set #gdy driftmountains -6
scoreboard players set #gz driftmountains 15134
scoreboard players set #gdz driftmountains -913
scoreboard players set #gr driftmountains 17631
scoreboard players set #gdr driftmountains -3
scoreboard players set #gp driftmountains 30
scoreboard players set #gdp driftmountains -10
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[0.0061f,0.0001f,-0.0221f,0.9997f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.5415f,0.2850f,-0.1308f,0.7800f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.2135f,0.7981f,0.5145f,-0.2296f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.9181f,0.0120f,0.0052f,0.3962f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0052f,0.3962f,0.9181f,0.0120f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3556f,0.8551f,0.1031f],left_rotation:[-0.1815f,0.0575f,-0.2732f,-0.9429f]}}
particle minecraft:cloud -86.39 70.32 16.44 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -86.39 70.12 16.44 0.005 0.02 0.072 1 0 force
particle minecraft:cloud -84.73 70.32 16.34 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -79098
scoreboard players set #gdx driftmountains -869
scoreboard players set #gy driftmountains 70121
scoreboard players set #gdy driftmountains -21
scoreboard players set #gz driftmountains 22646
scoreboard players set #gdz driftmountains -950
scoreboard players set #gr driftmountains 17592
scoreboard players set #gdr driftmountains 2
scoreboard players set #gp driftmountains 75
scoreboard players set #gdp driftmountains -3
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.1959f,-0.3060f,-0.1215f,-0.9237f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.0251f,-0.9160f,0.2291f,0.3283f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.9181f,0.0120f,0.0052f,0.3962f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0052f,0.3962f,0.9181f,0.0120f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3594f,0.8385f,0.2367f],left_rotation:[-0.1791f,0.0296f,-0.1263f,-0.9753f]}}
particle minecraft:cloud -79.85 70.44 24.07 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -79.85 70.24 24.07 0.005 0.02 0.077 1 0 force
particle minecraft:cloud -78.15 70.44 23.95 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -74823
scoreboard players set #gdx driftmountains -853
scoreboard players set #gy driftmountains 70229
scoreboard players set #gdy driftmountains -24
scoreboard players set #gz driftmountains 26861
scoreboard players set #gdz driftmountains -926
scoreboard players set #gr driftmountains 17672
scoreboard players set #gdr driftmountains -17
scoreboard players set #gp driftmountains 83
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.9398f,0.0420f,-0.3369f,-0.0379f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.3348f,-0.0027f,0.9406f,0.0565f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.9181f,0.0120f,0.0052f,0.3962f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0052f,0.3962f,0.9181f,0.0120f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3523f,0.8442f,0.0988f],left_rotation:[-0.1873f,0.0119f,-0.0286f,-0.9818f]}}
particle minecraft:cloud -75.58 70.55 28.17 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -75.58 70.35 28.17 0.004 0.02 0.076 1 0 force
particle minecraft:cloud -73.92 70.55 28.07 0.35 0.18 0.35 0.02 3 force
