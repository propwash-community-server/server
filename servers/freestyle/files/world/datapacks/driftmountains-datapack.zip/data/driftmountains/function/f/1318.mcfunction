scoreboard players set #gx driftmountains -44507
scoreboard players set #gdx driftmountains 583
scoreboard players set #gy driftmountains 67636
scoreboard players set #gdy driftmountains -13
scoreboard players set #gz driftmountains -89546
scoreboard players set #gdz driftmountains -365
scoreboard players set #gr driftmountains -8787
scoreboard players set #gdr driftmountains 258
scoreboard players set #gp driftmountains 89
scoreboard players set #gdp driftmountains 2
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[0.0061f,0.0001f,-0.0215f,0.9997f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.8739f,0.1499f,-0.1859f,0.4234f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.2314f,0.4452f,0.8630f,-0.0588f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.9837f,0.0129f,-0.0023f,-0.1795f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0023f,-0.1795f,0.9837f,0.0129f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3862f,0.8648f,0.1069f],left_rotation:[-0.1059f,0.1588f,-0.8285f,-0.5263f]}}
particle minecraft:cloud -45.73 67.96 -90.43 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -45.73 67.76 -90.43 -0.042 0.02 -0.002 1 0 force
particle minecraft:cloud -45.80 67.96 -88.76 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -48494
scoreboard players set #gdx driftmountains 386
scoreboard players set #gy driftmountains 67726
scoreboard players set #gdy driftmountains -9
scoreboard players set #gz driftmountains -86363
scoreboard players set #gdz driftmountains -412
scoreboard players set #gr driftmountains -10207
scoreboard players set #gdr driftmountains 127
scoreboard players set #gp driftmountains 78
scoreboard players set #gdp driftmountains 1
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[0.0061f,0.0001f,-0.0215f,0.9998f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.8356f,0.1738f,-0.1918f,0.4846f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.2438f,0.5074f,0.8219f,-0.0869f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.9837f,0.0129f,-0.0023f,-0.1795f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0023f,-0.1795f,0.9837f,0.0129f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3636f,0.8679f,0.2482f],left_rotation:[-0.1274f,0.1422f,-0.7111f,-0.6767f]}}
particle minecraft:cloud -50.01 68.05 -86.91 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -50.01 67.85 -86.91 -0.042 0.02 0.009 1 0 force
particle minecraft:cloud -49.65 68.05 -85.24 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -51362
scoreboard players set #gdx driftmountains 382
scoreboard players set #gy driftmountains 67821
scoreboard players set #gdy driftmountains -13
scoreboard players set #gz driftmountains -81308
scoreboard players set #gdz driftmountains -660
scoreboard players set #gr driftmountains -11999
scoreboard players set #gdr driftmountains 168
scoreboard players set #gp driftmountains 83
scoreboard players set #gdp driftmountains -4
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0001f,-0.0187f,0.9998f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.3048f,-0.1999f,-0.1226f,-0.9231f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.0263f,-0.9153f,0.3275f,0.2331f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.9837f,0.0129f,-0.0023f,-0.1795f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0023f,-0.1795f,0.9837f,0.0129f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3880f,0.8640f,0.1066f],left_rotation:[-0.0995f,0.1625f,-0.8493f,-0.4922f]}}
particle minecraft:cloud -52.87 68.14 -81.40 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -52.87 67.94 -81.40 -0.038 0.02 0.022 1 0 force
particle minecraft:cloud -52.04 68.14 -79.95 0.35 0.18 0.35 0.02 3 force
