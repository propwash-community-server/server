scoreboard players set #gx driftmountains 20106
scoreboard players set #gdx driftmountains -695
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 53538
scoreboard players set #gdz driftmountains 877
scoreboard players set #gr driftmountains 9114
scoreboard players set #gdr driftmountains 189
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.6956f,0.3134f,-0.2858f,0.5799f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.3483f,0.6131f,0.6665f,-0.2420f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.9943f,0.0130f,-0.0014f,-0.1059f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0014f,-0.1059f,0.9943f,0.0130f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3791f,0.8211f,0.0898f],left_rotation:[-0.1244f,-0.1292f,0.7133f,-0.6775f]}}
particle minecraft:cloud 21.35 71.32 54.40 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 21.35 71.12 54.40 0.067 0.02 0.001 1 0 force
particle minecraft:cloud 21.38 71.32 52.73 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains 24680
scoreboard players set #gdx driftmountains -564
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 46433
scoreboard players set #gdz driftmountains 912
scoreboard players set #gr driftmountains 9017
scoreboard players set #gdr driftmountains 174
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.0548f,0.4576f,0.0307f,0.8870f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.0624f,0.8886f,0.0070f,-0.4543f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.9943f,0.0130f,-0.0014f,-0.1059f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0014f,-0.1059f,0.9943f,0.0130f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.4063f,0.8506f,0.2415f],left_rotation:[-0.0669f,-0.1739f,0.9015f,-0.3907f]}}
particle minecraft:cloud 26.04 71.32 47.29 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 26.04 71.12 47.29 0.067 0.02 0.000 1 0 force
particle minecraft:cloud 26.05 71.32 45.58 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains 26714
scoreboard players set #gdx driftmountains -235
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 41486
scoreboard players set #gdz driftmountains 948
scoreboard players set #gr driftmountains 7158
scoreboard players set #gdr driftmountains 132
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.8494f,-0.0809f,-0.4450f,-0.2719f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.4189f,-0.2266f,0.8626f,0.1706f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.9943f,0.0130f,-0.0014f,-0.1059f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0014f,-0.1059f,0.9943f,0.0130f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3920f,0.8259f,0.0916f],left_rotation:[-0.0796f,-0.1611f,0.8755f,-0.4484f]}}
particle minecraft:cloud 28.17 71.32 41.88 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 28.17 71.12 41.88 0.056 0.02 -0.019 1 0 force
particle minecraft:cloud 27.65 71.32 40.30 0.35 0.18 0.35 0.02 3 force
