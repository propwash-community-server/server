scoreboard players set #gx driftmountains -55709
scoreboard players set #gdx driftmountains 237
scoreboard players set #gy driftmountains 68781
scoreboard players set #gdy driftmountains -19
scoreboard players set #gz driftmountains -41502
scoreboard players set #gdz driftmountains -624
scoreboard players set #gr driftmountains 16897
scoreboard players set #gdr driftmountains -208
scoreboard players set #gp driftmountains 138
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.5214f,-0.1517f,0.1594f,0.8244f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[-0.0736f,0.8122f,0.5402f,0.2074f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.9123f,0.0119f,0.0054f,0.4093f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0054f,0.4093f,0.9123f,0.0119f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3948f,0.8283f,0.0926f],left_rotation:[-0.0660f,-0.1677f,0.9079f,-0.3783f]}}
particle minecraft:cloud -56.29 69.10 -40.11 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud -54.65 69.10 -40.42 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -54.65 68.90 -40.42 0.008 0.02 0.039 1 0 force
scoreboard players set #gx driftmountains -59164
scoreboard players set #gdx driftmountains 377
scoreboard players set #gy driftmountains 68916
scoreboard players set #gdy driftmountains -20
scoreboard players set #gz driftmountains -38474
scoreboard players set #gdz driftmountains -473
scoreboard players set #gr driftmountains -17697
scoreboard players set #gdr driftmountains -27
scoreboard players set #gp driftmountains 150
scoreboard players set #gdp driftmountains -1
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[-0.0039f,0.0001f,0.0219f,0.9998f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.0494f,0.2654f,-0.0407f,-0.9620f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[-0.0602f,-0.9630f,0.0218f,-0.2617f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.9123f,0.0119f,0.0054f,0.4093f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0054f,0.4093f,0.9123f,0.0119f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3965f,0.8321f,0.2342f],left_rotation:[-0.1331f,-0.1215f,0.6418f,-0.7454f]}}
particle minecraft:cloud -60.09 69.24 -37.16 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud -58.38 69.24 -37.07 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -58.38 69.04 -37.07 -0.002 0.02 0.035 1 0 force
scoreboard players set #gx driftmountains -62597
scoreboard players set #gdx driftmountains 554
scoreboard players set #gy driftmountains 69087
scoreboard players set #gdy driftmountains -15
scoreboard players set #gz driftmountains -34174
scoreboard players set #gdz driftmountains -328
scoreboard players set #gr driftmountains -15299
scoreboard players set #gdr driftmountains -265
scoreboard players set #gp driftmountains 106
scoreboard players set #gdp driftmountains 8
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[0.0061f,-0.0001f,0.0204f,0.9998f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.8830f,0.1287f,0.1434f,-0.4280f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[-0.1892f,-0.4454f,0.8743f,-0.0366f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.9123f,0.0119f,0.0054f,0.4093f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0054f,0.4093f,0.9123f,0.0119f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.4007f,0.8388f,0.0967f],left_rotation:[-0.0182f,-0.1818f,0.9745f,-0.1295f]}}
particle minecraft:cloud -63.91 69.41 -33.43 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud -62.42 69.41 -32.67 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -62.42 69.21 -32.67 -0.018 0.02 0.035 1 0 force
