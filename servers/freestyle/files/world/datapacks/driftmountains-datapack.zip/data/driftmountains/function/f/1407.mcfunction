scoreboard players set #gx driftmountains 23338
scoreboard players set #gdx driftmountains 1040
scoreboard players set #gy driftmountains 66571
scoreboard players set #gdy driftmountains -13
scoreboard players set #gz driftmountains -55987
scoreboard players set #gdz driftmountains 601
scoreboard players set #gr driftmountains -5966
scoreboard players set #gdr driftmountains -28
scoreboard players set #gp driftmountains 63
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,0.0000f,0.0002f,1.0000f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.8907f,0.0540f,0.0092f,0.4512f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.0381f,0.4527f,0.8900f,0.0393f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.9748f,0.0128f,-0.0029f,-0.2229f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0029f,-0.2229f,0.9748f,0.0128f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3536f,0.8364f,0.0958f],left_rotation:[0.1844f,0.0201f,-0.1419f,0.9723f]}}
scoreboard players set #gx driftmountains 16021
scoreboard players set #gdx driftmountains 1044
scoreboard players set #gy driftmountains 66664
scoreboard players set #gdy driftmountains -13
scoreboard players set #gz driftmountains -60636
scoreboard players set #gdz driftmountains 682
scoreboard players set #gr driftmountains -5902
scoreboard players set #gdr driftmountains -33
scoreboard players set #gp driftmountains 61
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.3967f,0.0068f,0.0541f,0.9163f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.0419f,0.9157f,0.3982f,0.0348f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.9748f,0.0128f,-0.0029f,-0.2229f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0029f,-0.2229f,0.9748f,0.0128f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3590f,0.8389f,0.2369f],left_rotation:[0.1788f,-0.0319f,0.1382f,0.9736f]}}
scoreboard players set #gx driftmountains 6946
scoreboard players set #gdx driftmountains 920
scoreboard players set #gy driftmountains 66781
scoreboard players set #gdy driftmountains -12
scoreboard players set #gz driftmountains -66828
scoreboard players set #gdz driftmountains 608
scoreboard players set #gr driftmountains -5437
scoreboard players set #gdr driftmountains -84
scoreboard players set #gp driftmountains 61
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0000f,-0.0013f,1.0000f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.8750f,0.0550f,0.0086f,0.4809f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.0419f,0.4827f,0.8740f,0.0367f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.9748f,0.0128f,-0.0029f,-0.2229f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0029f,-0.2229f,0.9748f,0.0128f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3541f,0.8353f,0.0953f],left_rotation:[0.1835f,0.0248f,-0.1669f,0.9684f]}}
