scoreboard players set #gx driftmountains -46236
scoreboard players set #gdx driftmountains 574
scoreboard players set #gy driftmountains 67676
scoreboard players set #gdy driftmountains -13
scoreboard players set #gz driftmountains -88269
scoreboard players set #gdz driftmountains -454
scoreboard players set #gr driftmountains -9473
scoreboard players set #gdr driftmountains 183
scoreboard players set #gp driftmountains 83
scoreboard players set #gdp driftmountains 3
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[0.0061f,0.0001f,-0.0210f,0.9998f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.8500f,0.1639f,-0.1875f,0.4642f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.2373f,0.4864f,0.8375f,-0.0754f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.8266f,0.0108f,0.0074f,0.5626f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0074f,0.5626f,0.8266f,0.0108f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3816f,0.8661f,0.1074f],left_rotation:[-0.1205f,0.1489f,-0.7728f,-0.6050f]}}
particle minecraft:cloud -47.56 68.00 -89.00 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -47.56 67.80 -89.00 -0.044 0.02 0.004 1 0 force
particle minecraft:cloud -47.42 68.00 -87.33 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -49984
scoreboard players set #gdx driftmountains 499
scoreboard players set #gy driftmountains 67763
scoreboard players set #gdy driftmountains -13
scoreboard players set #gz driftmountains -84622
scoreboard players set #gdz driftmountains -613
scoreboard players set #gr driftmountains -10697
scoreboard players set #gdr driftmountains 166
scoreboard players set #gp driftmountains 77
scoreboard players set #gdp driftmountains -2
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[-0.0012f,-0.0000f,-0.0212f,0.9998f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.6949f,0.2137f,-0.1433f,0.6715f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.2147f,0.6903f,0.6762f,-0.1419f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.8266f,0.0108f,0.0074f,0.5626f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0074f,0.5626f,0.8266f,0.0108f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3641f,0.8683f,0.2484f],left_rotation:[-0.1255f,0.1440f,-0.7208f,-0.6663f]}}
particle minecraft:cloud -51.54 68.08 -85.04 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -51.54 67.88 -85.04 -0.045 0.02 0.014 1 0 force
particle minecraft:cloud -51.04 68.08 -83.41 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -52359
scoreboard players set #gdx driftmountains 314
scoreboard players set #gy driftmountains 67858
scoreboard players set #gdy driftmountains -12
scoreboard players set #gz driftmountains -79385
scoreboard players set #gdz driftmountains -634
scoreboard players set #gr driftmountains -12406
scoreboard players set #gdr driftmountains 106
scoreboard players set #gp driftmountains 86
scoreboard players set #gdp driftmountains 1
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0001f,-0.0184f,0.9998f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.4460f,-0.1797f,-0.1534f,-0.8633f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.0635f,-0.8519f,0.4674f,0.2275f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.8266f,0.0108f,0.0074f,0.5626f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0074f,0.5626f,0.8266f,0.0108f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3873f,0.8644f,0.1067f],left_rotation:[-0.1020f,0.1611f,-0.8414f,-0.5056f]}}
particle minecraft:cloud -53.87 68.18 -79.37 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -53.87 67.98 -79.37 -0.035 0.02 0.024 1 0 force
particle minecraft:cloud -52.94 68.18 -77.99 0.35 0.18 0.35 0.02 3 force
