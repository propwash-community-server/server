scoreboard players set #gx driftmountains -96660
scoreboard players set #gdx driftmountains 363
scoreboard players set #gy driftmountains 69872
scoreboard players set #gdy driftmountains -17
scoreboard players set #gz driftmountains -16097
scoreboard players set #gdz driftmountains -660
scoreboard players set #gr driftmountains -10378
scoreboard players set #gdr driftmountains 313
scoreboard players set #gp driftmountains 82
scoreboard players set #gdp driftmountains 3
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.4185f,0.3224f,-0.0980f,0.8434f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.1872f,0.8584f,0.3869f,-0.2802f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.6885f,0.0090f,-0.0095f,-0.7251f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0095f,-0.7251f,0.6885f,0.0090f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3524f,0.8453f,0.0993f],left_rotation:[-0.1873f,0.0165f,-0.0532f,-0.9807f]}}
particle minecraft:cloud -98.08 70.19 -16.61 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -98.08 69.99 -16.61 -0.044 0.02 0.011 1 0 force
particle minecraft:cloud -97.69 70.19 -14.99 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -98178
scoreboard players set #gdx driftmountains 32
scoreboard players set #gy driftmountains 69999
scoreboard players set #gdy driftmountains -10
scoreboard players set #gz driftmountains -9148
scoreboard players set #gdz driftmountains -797
scoreboard players set #gr driftmountains -12927
scoreboard players set #gdr driftmountains 185
scoreboard players set #gp driftmountains 43
scoreboard players set #gdp driftmountains 8
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.6219f,0.3086f,-0.2022f,0.6907f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.2759f,0.7157f,0.5929f,-0.2450f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.6885f,0.0090f,-0.0095f,-0.7251f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0095f,-0.7251f,0.6885f,0.0090f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3749f,0.8279f,0.2325f],left_rotation:[-0.1727f,-0.0446f,0.2533f,-0.9508f]}}
particle minecraft:cloud -99.78 70.32 -8.95 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -99.78 70.12 -8.95 -0.038 0.02 0.031 1 0 force
particle minecraft:cloud -98.69 70.32 -7.62 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -97866
scoreboard players set #gdx driftmountains -135
scoreboard players set #gy driftmountains 70032
scoreboard players set #gdy driftmountains -2
scoreboard players set #gz driftmountains -4050
scoreboard players set #gdz driftmountains -850
scoreboard players set #gr driftmountains -13895
scoreboard players set #gdr driftmountains 140
scoreboard players set #gp driftmountains 7
scoreboard players set #gdp driftmountains 5
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.2011f,-0.3633f,-0.1394f,-0.8990f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.0457f,-0.8893f,0.2404f,0.3864f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.6885f,0.0090f,-0.0095f,-0.7251f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0095f,-0.7251f,0.6885f,0.0090f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3628f,0.8251f,0.0913f],left_rotation:[-0.1650f,-0.0760f,0.4370f,-0.8809f]}}
particle minecraft:cloud -99.32 70.35 -3.65 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -99.32 70.15 -3.65 -0.034 0.02 0.039 1 0 force
particle minecraft:cloud -98.06 70.35 -2.55 0.35 0.18 0.35 0.02 3 force
