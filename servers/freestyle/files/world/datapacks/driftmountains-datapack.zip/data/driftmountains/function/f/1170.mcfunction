scoreboard players set #gx driftmountains -95470
scoreboard players set #gdx driftmountains 460
scoreboard players set #gy driftmountains 69820
scoreboard players set #gdy driftmountains -18
scoreboard players set #gz driftmountains -18043
scoreboard players set #gdz driftmountains -624
scoreboard players set #gr driftmountains -9676
scoreboard players set #gdr driftmountains 181
scoreboard players set #gp driftmountains 90
scoreboard players set #gdp driftmountains 3
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.6478f,0.2917f,-0.2029f,0.6738f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.2748f,0.6989f,0.6207f,-0.2252f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.0185f,0.0002f,0.0131f,0.9997f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0131f,0.9997f,0.0185f,0.0002f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3534f,0.8372f,0.0961f],left_rotation:[-0.1850f,-0.0167f,0.1239f,-0.9747f]}}
particle minecraft:cloud -96.82 70.14 -18.72 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -96.82 69.94 -18.72 -0.046 0.02 0.005 1 0 force
particle minecraft:cloud -96.62 70.14 -17.07 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -97999
scoreboard players set #gdx driftmountains 113
scoreboard players set #gy driftmountains 69965
scoreboard players set #gdy driftmountains -13
scoreboard players set #gz driftmountains -11558
scoreboard players set #gdz driftmountains -780
scoreboard players set #gr driftmountains -12273
scoreboard players set #gdr driftmountains 187
scoreboard players set #gp driftmountains 60
scoreboard players set #gdp driftmountains 4
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.8684f,0.1820f,-0.3084f,0.3430f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.3462f,0.3773f,0.8541f,-0.0917f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.0185f,0.0002f,0.0131f,0.9997f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0131f,0.9997f,0.0185f,0.0002f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3698f,0.8296f,0.2332f],left_rotation:[-0.1771f,-0.0244f,0.1504f,-0.9723f]}}
particle minecraft:cloud -99.61 70.28 -11.54 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -99.61 70.08 -11.54 -0.040 0.02 0.025 1 0 force
particle minecraft:cloud -98.68 70.28 -10.10 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -98191
scoreboard players set #gdx driftmountains -49
scoreboard players set #gy driftmountains 70022
scoreboard players set #gdy driftmountains -6
scoreboard players set #gz driftmountains -6577
scoreboard players set #gdz driftmountains -835
scoreboard players set #gr driftmountains -13412
scoreboard players set #gdr driftmountains 212
scoreboard players set #gp driftmountains 23
scoreboard players set #gdp driftmountains 6
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.3757f,0.3673f,-0.1015f,0.8447f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.1909f,0.8601f,0.3392f,-0.3299f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.0185f,0.0002f,0.0131f,0.9997f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0131f,0.9997f,0.0185f,0.0002f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3598f,0.8274f,0.0922f],left_rotation:[-0.1715f,-0.0624f,0.3654f,-0.9127f]}}
particle minecraft:cloud -99.68 70.34 -6.30 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -99.68 70.14 -6.30 -0.035 0.02 0.034 1 0 force
particle minecraft:cloud -98.51 70.34 -5.10 0.35 0.18 0.35 0.02 3 force
