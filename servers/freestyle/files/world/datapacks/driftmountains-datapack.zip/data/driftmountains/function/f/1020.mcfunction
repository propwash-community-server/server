scoreboard players set #gx driftmountains 24177
scoreboard players set #gdx driftmountains -495
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 47100
scoreboard players set #gdz driftmountains 947
scoreboard players set #gr driftmountains 7935
scoreboard players set #gdr driftmountains 158
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.8264f,0.2239f,-0.3468f,0.3829f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.3890f,0.4215f,0.8074f,-0.1383f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.9267f,0.0121f,-0.0049f,-0.3755f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0049f,-0.3755f,0.9267f,0.0121f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3735f,0.8212f,0.0898f],left_rotation:[-0.1395f,-0.1134f,0.6317f,-0.7541f]}}
particle minecraft:cloud 25.57 71.32 47.69 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 25.57 71.12 47.69 0.063 0.02 -0.012 1 0 force
particle minecraft:cloud 25.26 71.32 46.05 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains 27693
scoreboard players set #gdx driftmountains -310
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 39583
scoreboard players set #gdz driftmountains 978
scoreboard players set #gr driftmountains 8013
scoreboard players set #gdr driftmountains 164
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.2807f,0.4662f,-0.0943f,0.8337f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.1824f,0.8482f,0.2332f,-0.4393f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.9267f,0.0121f,-0.0049f,-0.3755f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0049f,-0.3755f,0.9267f,0.0121f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.4048f,0.8587f,0.2447f],left_rotation:[-0.0366f,-0.1853f,0.9556f,-0.2263f]}}
particle minecraft:cloud 29.18 71.32 40.19 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 29.18 71.12 40.19 0.060 0.02 -0.010 1 0 force
particle minecraft:cloud 28.89 71.32 38.51 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains 27225
scoreboard players set #gdx driftmountains 73
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 34858
scoreboard players set #gdz driftmountains 1020
scoreboard players set #gr driftmountains 5275
scoreboard players set #gdr driftmountains 356
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.7591f,-0.1824f,-0.3919f,-0.4867f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.3429f,-0.4482f,0.7824f,0.2632f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.9267f,0.0121f,-0.0049f,-0.3755f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0049f,-0.3755f,0.9267f,0.0121f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3831f,0.8217f,0.0900f],left_rotation:[-0.1123f,-0.1396f,0.7668f,-0.6163f]}}
particle minecraft:cloud 28.73 71.32 34.76 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 28.73 71.12 34.76 0.045 0.02 -0.034 1 0 force
particle minecraft:cloud 27.72 71.32 33.43 0.35 0.18 0.35 0.02 3 force
