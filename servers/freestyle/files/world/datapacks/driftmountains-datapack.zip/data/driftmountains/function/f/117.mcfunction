scoreboard players set #gx driftmountains 3783
scoreboard players set #gdx driftmountains 501
scoreboard players set #gy driftmountains 70604
scoreboard players set #gdy driftmountains 67
scoreboard players set #gz driftmountains -19650
scoreboard players set #gdz driftmountains 708
scoreboard players set #gr driftmountains 948
scoreboard players set #gdr driftmountains 167
scoreboard players set #gp driftmountains -292
scoreboard players set #gdp driftmountains -19
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.6938f,0.2646f,-0.2060f,0.6373f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.2742f,0.6625f,0.6699f,-0.1931f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.2331f,0.0031f,0.0127f,0.9724f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0127f,0.9724f,0.2331f,0.0031f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3524f,0.8460f,0.0995f],left_rotation:[-0.1872f,0.0194f,-0.0685f,-0.9797f]}}
particle minecraft:cloud 4.81 70.92 -20.76 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 4.81 70.72 -20.76 0.009 0.02 -0.051 1 0 force
particle minecraft:cloud 3.17 70.92 -21.03 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains 189
scoreboard players set #gdx driftmountains 653
scoreboard players set #gy driftmountains 70512
scoreboard players set #gdy driftmountains -13
scoreboard players set #gz driftmountains -23896
scoreboard players set #gdz driftmountains 535
scoreboard players set #gr driftmountains -702
scoreboard players set #gdr driftmountains 207
scoreboard players set #gp driftmountains 58
scoreboard players set #gdp driftmountains 13
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.2243f,0.3380f,-0.0258f,0.9137f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.1220f,0.9214f,0.1900f,-0.3163f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.2331f,0.0031f,0.0127f,0.9724f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0127f,0.9724f,0.2331f,0.0031f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3622f,0.8349f,0.2353f],left_rotation:[-0.1800f,0.0115f,-0.0335f,-0.9831f]}}
particle minecraft:cloud 0.87 70.83 -25.36 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 0.87 70.63 -25.36 -0.006 0.02 -0.050 1 0 force
particle minecraft:cloud -0.83 70.83 -25.15 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -3791
scoreboard players set #gdx driftmountains 553
scoreboard players set #gy driftmountains 70441
scoreboard players set #gdy driftmountains 30
scoreboard players set #gz driftmountains -26208
scoreboard players set #gdz driftmountains 385
scoreboard players set #gr driftmountains -1028
scoreboard players set #gdr driftmountains -33
scoreboard players set #gp driftmountains -202
scoreboard players set #gdp driftmountains 39
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.8605f,-0.0856f,-0.3664f,-0.3436f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.3323f,-0.3069f,0.8742f,0.1765f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.2331f,0.0031f,0.0127f,0.9724f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0127f,0.9724f,0.2331f,0.0031f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3582f,0.8290f,0.0928f],left_rotation:[-0.1749f,-0.0540f,0.3213f,-0.9290f]}}
particle minecraft:cloud -3.19 70.76 -27.60 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -3.19 70.56 -27.60 -0.008 0.02 -0.044 1 0 force
particle minecraft:cloud -4.84 70.76 -27.30 0.35 0.18 0.35 0.02 3 force
