scoreboard players set #gx driftmountains 52003
scoreboard players set #gdx driftmountains 1141
scoreboard players set #gy driftmountains 66232
scoreboard players set #gdy driftmountains -12
scoreboard players set #gz driftmountains -38492
scoreboard players set #gdz driftmountains 794
scoreboard players set #gr driftmountains -3966
scoreboard players set #gdr driftmountains -433
scoreboard players set #gp driftmountains 49
scoreboard players set #gdp driftmountains 1
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0000f,-0.0096f,0.9999f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.5462f,0.1377f,-0.0278f,0.8258f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.1147f,0.8332f,0.5348f,-0.0810f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.9350f,0.0122f,0.0046f,0.3544f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0046f,0.3544f,0.9350f,0.0122f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3951f,0.8286f,0.0927f],left_rotation:[0.0644f,0.1684f,-0.9115f,0.3696f]}}
particle minecraft:cloud 51.84 66.55 -39.99 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke 51.84 66.35 -39.99 -0.053 0.02 -0.064 1 0 force
particle minecraft:cloud 50.56 66.55 -38.93 0.35 0.18 0.35 0.02 2 force
scoreboard players set #gx driftmountains 43435
scoreboard players set #gdx driftmountains 1264
scoreboard players set #gy driftmountains 66314
scoreboard players set #gdy driftmountains -14
scoreboard players set #gz driftmountains -41848
scoreboard players set #gdz driftmountains 780
scoreboard players set #gr driftmountains -3753
scoreboard players set #gdr driftmountains 113
scoreboard players set #gp driftmountains 50
scoreboard players set #gdp driftmountains -1
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0000f,-0.0126f,0.9999f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.1021f,-0.1795f,-0.0723f,-0.9758f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[-0.0298f,-0.9735f,0.1216f,0.1912f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.9350f,0.0122f,0.0046f,0.3544f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0046f,0.3544f,0.9350f,0.0122f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3931f,0.8714f,0.2496f],left_rotation:[-0.0285f,0.1905f,-0.9728f,-0.1287f]}}
particle minecraft:cloud 43.28 66.63 -43.45 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke 43.28 66.43 -43.45 -0.050 0.02 -0.065 1 0 force
particle minecraft:cloud 41.93 66.63 -42.41 0.35 0.18 0.35 0.02 2 force
scoreboard players set #gx driftmountains 33881
scoreboard players set #gdx driftmountains 1047
scoreboard players set #gy driftmountains 66435
scoreboard players set #gdy driftmountains -14
scoreboard players set #gz driftmountains -49659
scoreboard players set #gdz driftmountains 810
scoreboard players set #gr driftmountains -5209
scoreboard players set #gdr driftmountains 102
scoreboard players set #gp driftmountains 60
scoreboard players set #gdp driftmountains -1
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0000f,-0.0003f,1.0000f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.5163f,0.0222f,0.0477f,0.8548f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.0419f,0.8545f,0.5168f,0.0319f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.9350f,0.0122f,0.0046f,0.3544f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0046f,0.3544f,0.9350f,0.0122f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3524f,0.8453f,0.0993f],left_rotation:[0.1873f,-0.0165f,0.0530f,0.9807f]}}
