scoreboard players set #gx driftmountains 7049
scoreboard players set #gdx driftmountains 458
scoreboard players set #gy driftmountains 70984
scoreboard players set #gdy driftmountains 16
scoreboard players set #gz driftmountains -14356
scoreboard players set #gdz driftmountains 796
scoreboard players set #gr driftmountains 1072
scoreboard players set #gdr driftmountains -79
scoreboard players set #gp driftmountains -121
scoreboard players set #gdp driftmountains 121
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.5026f,0.3208f,-0.1377f,0.7909f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.2216f,0.8098f,0.4716f,-0.2697f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.0436f,0.0006f,-0.0131f,-0.9990f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0131f,-0.9990f,0.0436f,0.0006f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3527f,0.8399f,0.0971f],left_rotation:[-0.1864f,-0.0054f,0.0637f,-0.9803f]}}
particle minecraft:cloud 8.10 71.30 -15.44 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 8.10 71.10 -15.44 0.010 0.02 -0.054 1 0 force
particle minecraft:cloud 6.46 71.30 -15.75 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains 4231
scoreboard players set #gdx driftmountains 475
scoreboard players set #gy driftmountains 70631
scoreboard players set #gdy driftmountains 68
scoreboard players set #gz driftmountains -19533
scoreboard players set #gdz driftmountains 763
scoreboard players set #gr driftmountains 1192
scoreboard players set #gdr driftmountains 135
scoreboard players set #gp driftmountains -303
scoreboard players set #gdp driftmountains -6
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.1183f,-0.3156f,-0.0957f,-0.9366f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[-0.0023f,-0.9317f,0.1521f,0.3297f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.0436f,0.0006f,-0.0131f,-0.9990f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0131f,-0.9990f,0.0436f,0.0006f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3595f,0.8383f,0.2366f],left_rotation:[-0.1791f,0.0287f,-0.1218f,-0.9759f]}}
particle minecraft:cloud 5.35 70.95 -20.69 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 5.35 70.75 -20.69 0.011 0.02 -0.051 1 0 force
particle minecraft:cloud 3.68 70.95 -21.05 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains 660
scoreboard players set #gdx driftmountains 655
scoreboard players set #gy driftmountains 70498
scoreboard players set #gdy driftmountains -13
scoreboard players set #gz driftmountains -23076
scoreboard players set #gdz driftmountains 539
scoreboard players set #gr driftmountains -673
scoreboard players set #gdr driftmountains 264
scoreboard players set #gp driftmountains 72
scoreboard players set #gdp driftmountains -37
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.8071f,0.2181f,-0.2547f,0.4859f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.3072f,0.5154f,0.7887f,-0.1344f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.0436f,0.0006f,-0.0131f,-0.9990f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0131f,-0.9990f,0.0436f,0.0006f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3524f,0.8460f,0.0995f],left_rotation:[-0.1872f,0.0195f,-0.0690f,-0.9797f]}}
particle minecraft:cloud 1.34 70.82 -24.42 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 1.34 70.62 -24.42 -0.006 0.02 -0.051 1 0 force
particle minecraft:cloud -0.32 70.82 -24.23 0.35 0.18 0.35 0.02 3 force
