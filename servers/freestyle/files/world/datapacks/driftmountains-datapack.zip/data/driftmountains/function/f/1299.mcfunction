scoreboard players set #gx driftmountains -53636
scoreboard players set #gdx driftmountains 331
scoreboard players set #gy driftmountains 67870
scoreboard players set #gdy driftmountains -11
scoreboard players set #gz driftmountains -79287
scoreboard players set #gdz driftmountains -596
scoreboard players set #gr driftmountains -12018
scoreboard players set #gdr driftmountains 117
scoreboard players set #gp driftmountains 83
scoreboard players set #gdp driftmountains -1
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0001f,-0.0191f,0.9998f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.7264f,-0.1161f,-0.2124f,-0.6432f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.1460f,-0.6244f,0.7426f,0.1931f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.8829f,0.0116f,-0.0061f,-0.4694f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0061f,-0.4694f,0.8829f,0.0116f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3848f,0.8653f,0.1071f],left_rotation:[-0.1107f,0.1558f,-0.8114f,-0.5523f]}}
particle minecraft:cloud -55.14 68.19 -79.38 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -55.14 67.99 -79.38 -0.035 0.02 0.020 1 0 force
particle minecraft:cloud -54.31 68.19 -77.93 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -55129
scoreboard players set #gdx driftmountains 205
scoreboard players set #gy driftmountains 67960
scoreboard players set #gdy driftmountains -13
scoreboard players set #gz driftmountains -74966
scoreboard players set #gdz driftmountains -566
scoreboard players set #gr driftmountains -12509
scoreboard players set #gdr driftmountains 31
scoreboard players set #gp driftmountains 105
scoreboard players set #gdp driftmountains -2
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0001f,-0.0216f,0.9998f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.0895f,-0.2529f,-0.0780f,-0.9602f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[-0.0225f,-0.9573f,0.1166f,0.2637f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.8829f,0.0116f,-0.0061f,-0.4694f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0061f,-0.4694f,0.8829f,0.0116f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3616f,0.8660f,0.2475f],left_rotation:[-0.1344f,0.1347f,-0.6719f,-0.7158f]}}
particle minecraft:cloud -56.74 68.28 -74.88 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -56.74 68.08 -74.88 -0.031 0.02 0.022 1 0 force
particle minecraft:cloud -55.75 68.28 -73.48 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -55369
scoreboard players set #gdx driftmountains -9
scoreboard players set #gy driftmountains 68123
scoreboard players set #gdy driftmountains -14
scoreboard players set #gz driftmountains -69353
scoreboard players set #gdz driftmountains -637
scoreboard players set #gr driftmountains -15081
scoreboard players set #gdr driftmountains 164
scoreboard players set #gp driftmountains 104
scoreboard players set #gdp driftmountains 2
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[0.0061f,0.0001f,-0.0186f,0.9998f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.7510f,-0.0908f,-0.1927f,-0.6250f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.1281f,-0.6082f,0.7647f,0.1702f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.8829f,0.0116f,-0.0061f,-0.4694f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0061f,-0.4694f,0.8829f,0.0116f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3958f,0.8581f,0.1043f],left_rotation:[-0.0648f,0.1769f,-0.9327f,-0.3075f]}}
particle minecraft:cloud -56.71 68.44 -68.66 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -56.71 68.24 -68.66 -0.020 0.02 0.036 1 0 force
particle minecraft:cloud -55.26 68.44 -67.85 0.35 0.18 0.35 0.02 3 force
