scoreboard players set #gx driftmountains -33200
scoreboard players set #gdx driftmountains -1158
scoreboard players set #gy driftmountains 70766
scoreboard players set #gdy driftmountains -42
scoreboard players set #gz driftmountains 53273
scoreboard players set #gdz driftmountains -389
scoreboard players set #gr driftmountains 15552
scoreboard players set #gdr driftmountains -8
scoreboard players set #gp driftmountains 133
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.8317f,0.2180f,-0.3340f,0.3863f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.3765f,0.4235f,0.8133f,-0.1318f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.9716f,0.0127f,-0.0031f,-0.2361f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0031f,-0.2361f,0.9716f,0.0127f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3669f,0.8229f,0.0905f],left_rotation:[-0.1556f,-0.0919f,0.5202f,-0.8346f]}}
particle minecraft:cloud -33.44 71.09 54.77 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -33.44 70.89 54.77 0.030 0.02 0.067 1 0 force
particle minecraft:cloud -31.92 71.09 54.07 0.35 0.18 0.35 0.02 3 force
playsound driftgen:grain.kaze.018 neutral @a -42.61 71.00 49.95 12 1
scoreboard players set #gx driftmountains -23406
scoreboard players set #gdx driftmountains -1125
scoreboard players set #gy driftmountains 70999
scoreboard players set #gdy driftmountains -4
scoreboard players set #gz driftmountains 56480
scoreboard players set #gdz driftmountains -336
scoreboard players set #gr driftmountains 15227
scoreboard players set #gdr driftmountains 32
scoreboard players set #gp driftmountains 5
scoreboard players set #gdp driftmountains 21
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.2886f,0.3813f,-0.0660f,0.8757f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.1584f,0.8875f,0.2502f,-0.3531f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.9716f,0.0127f,-0.0031f,-0.2361f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0031f,-0.2361f,0.9716f,0.0127f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3839f,0.8273f,0.2323f],left_rotation:[-0.1609f,-0.0770f,0.4176f,-0.8910f]}}
particle minecraft:cloud -23.53 71.32 58.09 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -23.53 71.12 58.09 0.032 0.02 0.062 1 0 force
particle minecraft:cloud -22.01 71.32 57.29 0.35 0.18 0.35 0.02 3 force
playsound driftgen:grain.onyx.019 neutral @a -32.68 71.29 53.57 12 1
scoreboard players set #gx driftmountains -18730
scoreboard players set #gdx driftmountains -1199
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 57979
scoreboard players set #gdz driftmountains -333
scoreboard players set #gr driftmountains 15145
scoreboard players set #gdr driftmountains 10
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.7760f,-0.1603f,-0.3573f,-0.4944f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.3073f,-0.4596f,0.7971f,0.2428f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.9716f,0.0127f,-0.0031f,-0.2361f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0031f,-0.2361f,0.9716f,0.0127f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3638f,0.8244f,0.0911f],left_rotation:[-0.1627f,-0.0802f,0.4591f,-0.8696f]}}
particle minecraft:cloud -18.86 71.32 59.48 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -18.86 71.12 59.48 0.033 0.02 0.061 1 0 force
particle minecraft:cloud -17.39 71.32 58.69 0.35 0.18 0.35 0.02 3 force
playsound driftgen:grain.kaze.017 neutral @a -27.93 71.43 55.35 12 1
