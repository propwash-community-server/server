scoreboard players set #gx driftmountains 30802
scoreboard players set #gdx driftmountains 1083
scoreboard players set #gy driftmountains 66476
scoreboard players set #gdy driftmountains -14
scoreboard players set #gz driftmountains -51792
scoreboard players set #gdz driftmountains 628
scoreboard players set #gr driftmountains -5799
scoreboard players set #gdr driftmountains -42
scoreboard players set #gp driftmountains 63
scoreboard players set #gdp driftmountains -1
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0000f,-0.0012f,1.0000f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.7437f,0.0507f,0.0218f,0.6663f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.0481f,0.6677f,0.7424f,0.0271f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.9985f,0.0131f,0.0007f,0.0541f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0007f,0.0541f,0.9985f,0.0131f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3539f,0.8358f,0.0955f],left_rotation:[0.1839f,0.0225f,-0.1548f,0.9704f]}}
scoreboard players set #gx driftmountains 23168
scoreboard players set #gdx driftmountains 1018
scoreboard players set #gy driftmountains 66572
scoreboard players set #gdy driftmountains -14
scoreboard players set #gz driftmountains -55964
scoreboard players set #gdz driftmountains 696
scoreboard players set #gr driftmountains -5624
scoreboard players set #gdr driftmountains 155
scoreboard players set #gp driftmountains 63
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[-0.0039f,0.0000f,0.0002f,1.0000f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.1459f,-0.0091f,0.0542f,0.9878f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.0493f,0.9875f,0.1477f,0.0244f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.9985f,0.0131f,0.0007f,0.0541f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0007f,0.0541f,0.9985f,0.0131f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3587f,0.8396f,0.2371f],left_rotation:[0.1785f,-0.0347f,0.1528f,0.9714f]}}
scoreboard players set #gx driftmountains 13795
scoreboard players set #gdx driftmountains 1062
scoreboard players set #gy driftmountains 66694
scoreboard players set #gdy driftmountains -13
scoreboard players set #gz driftmountains -62300
scoreboard players set #gdz driftmountains 696
scoreboard players set #gr driftmountains -5880
scoreboard players set #gdr driftmountains -43
scoreboard players set #gp driftmountains 61
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,0.0000f,0.0013f,1.0000f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.7195f,0.0271f,0.0473f,0.6923f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.0252f,0.6912f,0.7206f,0.0484f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.9985f,0.0131f,0.0007f,0.0541f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0007f,0.0541f,0.9985f,0.0131f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3530f,0.8493f,0.1008f],left_rotation:[0.1862f,-0.0326f,0.1393f,0.9720f]}}
