scoreboard players set #gx driftmountains -61028
scoreboard players set #gdx driftmountains 458
scoreboard players set #gy driftmountains 69051
scoreboard players set #gdy driftmountains -16
scoreboard players set #gz driftmountains -34182
scoreboard players set #gdz driftmountains -335
scoreboard players set #gr driftmountains -15732
scoreboard players set #gdr driftmountains -489
scoreboard players set #gp driftmountains 126
scoreboard players set #gdp driftmountains 19
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[0.0035f,-0.0001f,0.0205f,0.9998f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.6212f,0.1591f,0.0609f,-0.7649f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[-0.1417f,-0.7755f,0.6079f,-0.0947f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.3897f,0.0051f,0.0121f,0.9208f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0121f,0.9208f,0.3897f,0.0051f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.4007f,0.8485f,0.1005f],left_rotation:[0.0220f,-0.1841f,0.9792f,0.0812f]}}
particle minecraft:cloud -62.28 69.37 -33.34 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud -60.74 69.37 -32.70 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -60.74 69.17 -32.70 -0.013 0.02 0.032 1 0 force
scoreboard players set #gx driftmountains -66653
scoreboard players set #gdx driftmountains 634
scoreboard players set #gy driftmountains 69163
scoreboard players set #gdy driftmountains -11
scoreboard players set #gz driftmountains -33521
scoreboard players set #gdz driftmountains -244
scoreboard players set #gr driftmountains -12636
scoreboard players set #gdr driftmountains -328
scoreboard players set #gp driftmountains 86
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[0.0061f,-0.0001f,0.0093f,0.9999f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.8673f,0.1081f,0.0867f,-0.4781f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[-0.1375f,-0.4899f,0.8607f,-0.0175f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.3897f,0.0051f,0.0121f,0.9208f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0121f,0.9208f,0.3897f,0.0051f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3802f,0.8743f,0.2508f],left_rotation:[0.0738f,-0.1786f,0.9052f,0.3785f]}}
particle minecraft:cloud -68.26 69.48 -33.40 0.35 0.18 0.35 0.02 2 force
particle minecraft:cloud -67.24 69.48 -32.02 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -67.24 69.28 -32.02 -0.033 0.02 0.024 1 0 force
scoreboard players set #gx driftmountains -71719
scoreboard players set #gdx driftmountains 695
scoreboard players set #gy driftmountains 69239
scoreboard players set #gdy driftmountains -10
scoreboard players set #gz driftmountains -30230
scoreboard players set #gdz driftmountains -306
scoreboard players set #gr driftmountains -11832
scoreboard players set #gdr driftmountains 21
scoreboard players set #gp driftmountains 73
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,0.0000f,0.0026f,1.0000f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.1837f,0.0557f,-0.0429f,-0.9805f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[-0.0599f,-0.9814f,0.1789f,-0.0367f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.3897f,0.0051f,0.0121f,0.9208f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0121f,0.9208f,0.3897f,0.0051f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3601f,0.8604f,0.1052f],left_rotation:[0.1728f,-0.0827f,0.4091f,0.8921f]}}
