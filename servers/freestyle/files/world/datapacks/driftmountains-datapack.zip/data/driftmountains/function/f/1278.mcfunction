scoreboard players set #gx driftmountains -56265
scoreboard players set #gdx driftmountains -88
scoreboard players set #gy driftmountains 68168
scoreboard players set #gdy driftmountains -13
scoreboard players set #gz driftmountains -66514
scoreboard players set #gdz driftmountains -692
scoreboard players set #gr driftmountains -16151
scoreboard players set #gdr driftmountains 285
scoreboard players set #gp driftmountains 91
scoreboard players set #gdp driftmountains 2
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[0.0061f,0.0001f,-0.0160f,0.9999f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.8585f,0.1459f,-0.1565f,0.4660f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.2064f,0.4850f,0.8479f,-0.0564f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.2429f,0.0032f,-0.0127f,-0.9700f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0127f,-0.9700f,0.2429f,0.0032f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3955f,0.8584f,0.1044f],left_rotation:[-0.0664f,0.1764f,-0.9299f,-0.3156f]}}
particle minecraft:cloud -57.46 68.49 -65.58 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -57.46 68.29 -65.58 -0.013 0.02 0.040 1 0 force
particle minecraft:cloud -55.87 68.49 -65.05 0.35 0.18 0.35 0.02 2 force
scoreboard players set #gx driftmountains -54790
scoreboard players set #gdx driftmountains -113
scoreboard players set #gy driftmountains 68278
scoreboard players set #gdy driftmountains -12
scoreboard players set #gz driftmountains -60329
scoreboard players set #gdz driftmountains -730
scoreboard players set #gr driftmountains 16864
scoreboard players set #gdr driftmountains 440
scoreboard players set #gp driftmountains 96
scoreboard players set #gdp driftmountains -1
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[-0.0039f,0.0000f,0.0015f,1.0000f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.1553f,0.0335f,-0.0477f,-0.9861f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[-0.0557f,-0.9866f,0.1526f,-0.0174f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.2429f,0.0032f,-0.0127f,-0.9700f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0127f,-0.9700f,0.2429f,0.0032f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3570f,0.8430f,0.2385f],left_rotation:[0.1760f,-0.0497f,0.2298f,0.9559f]}}
scoreboard players set #gx driftmountains -53885
scoreboard players set #gdx driftmountains -45
scoreboard players set #gy driftmountains 68390
scoreboard players set #gdy driftmountains -13
scoreboard players set #gz driftmountains -54463
scoreboard players set #gdz driftmountains -605
scoreboard players set #gr driftmountains 14754
scoreboard players set #gdr driftmountains 94
scoreboard players set #gp driftmountains 111
scoreboard players set #gdp driftmountains -3
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,0.0001f,0.0175f,0.9998f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.9456f,0.1004f,0.1616f,-0.2638f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[-0.1902f,-0.2823f,0.9403f,-0.0015f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.2429f,0.0032f,-0.0127f,-0.9700f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0127f,-0.9700f,0.2429f,0.0032f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.4009f,0.8399f,0.0971f],left_rotation:[-0.0137f,-0.1825f,0.9773f,-0.1063f]}}
particle minecraft:cloud -53.91 68.71 -52.95 0.35 0.18 0.35 0.02 2 force
particle minecraft:cloud -52.50 68.71 -53.85 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -52.50 68.51 -53.85 0.020 0.02 0.032 1 0 force
