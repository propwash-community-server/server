scoreboard players set #gx driftmountains 26326
scoreboard players set #gdx driftmountains 259
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 27296
scoreboard players set #gdz driftmountains 995
scoreboard players set #gr driftmountains 3089
scoreboard players set #gdr driftmountains 270
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.0803f,0.3590f,0.0252f,0.9295f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.0723f,0.9320f,0.0430f,-0.3525f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.8177f,0.0107f,0.0075f,0.5755f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0075f,0.5755f,0.8177f,0.0107f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3541f,0.8353f,0.0953f],left_rotation:[-0.1834f,-0.0249f,0.1673f,-0.9683f]}}
particle minecraft:cloud 27.69 71.32 26.64 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 27.69 71.12 26.64 0.032 0.02 -0.053 1 0 force
particle minecraft:cloud 26.26 71.32 25.79 0.35 0.18 0.35 0.02 3 force
playsound driftgen:grain.kaze.015 neutral @a 27.51 71.50 35.38 12 1
scoreboard players set #gx driftmountains 24047
scoreboard players set #gdx driftmountains 484
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 21004
scoreboard players set #gdz driftmountains 819
scoreboard players set #gr driftmountains 555
scoreboard players set #gdr driftmountains -10
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[0.0061f,0.0001f,-0.0217f,0.9997f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.6225f,-0.2276f,-0.2792f,-0.6948f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.2077f,-0.6693f,0.6499f,0.2943f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.8177f,0.0107f,0.0075f,0.5755f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0075f,0.5755f,0.8177f,0.0107f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3707f,0.8292f,0.2331f],left_rotation:[-0.1764f,-0.0283f,0.1701f,-0.9691f]}}
particle minecraft:cloud 25.03 71.32 19.73 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 25.03 71.12 19.73 0.005 0.02 -0.056 1 0 force
particle minecraft:cloud 23.33 71.32 19.56 0.35 0.18 0.35 0.02 3 force
playsound driftgen:grain.onyx.016 neutral @a 27.37 71.50 27.71 12 1
scoreboard players set #gx driftmountains 21222
scoreboard players set #gdx driftmountains 398
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 15751
scoreboard players set #gdz driftmountains 968
scoreboard players set #gr driftmountains 709
scoreboard players set #gdr driftmountains 80
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0001f,-0.0180f,0.9998f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.8533f,0.1660f,-0.1972f,0.4533f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.2459f,0.4765f,0.8405f,-0.0772f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.8177f,0.0107f,0.0075f,0.5755f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0075f,0.5755f,0.8177f,0.0107f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3775f,0.8666f,0.1076f],left_rotation:[-0.1321f,0.1393f,-0.7191f,-0.6678f]}}
particle minecraft:cloud 22.21 71.32 14.60 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke 22.21 71.12 14.60 0.008 0.02 -0.064 1 0 force
particle minecraft:cloud 20.55 71.32 14.40 0.35 0.18 0.35 0.02 2 force
playsound driftgen:grain.kaze.014 neutral @a 24.00 71.50 23.57 12 1
