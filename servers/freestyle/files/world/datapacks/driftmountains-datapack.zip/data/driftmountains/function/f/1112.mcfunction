scoreboard players set #gx driftmountains -69822
scoreboard players set #gdx driftmountains -979
scoreboard players set #gy driftmountains 70377
scoreboard players set #gdy driftmountains -25
scoreboard players set #gz driftmountains 32998
scoreboard players set #gdz driftmountains -1028
scoreboard players set #gr driftmountains 17965
scoreboard players set #gdr driftmountains -68
scoreboard players set #gp driftmountains 73
scoreboard players set #gdp driftmountains 3
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.7625f,-0.1615f,-0.3290f,-0.5331f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.2748f,-0.5015f,0.7837f,0.2426f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.3554f,0.0047f,-0.0122f,-0.9346f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0122f,-0.9346f,0.3554f,0.0047f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3555f,0.8326f,0.0943f],left_rotation:[-0.1806f,-0.0368f,0.2306f,-0.9554f]}}
particle minecraft:cloud -70.65 70.70 34.26 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -70.65 70.50 34.26 0.001 0.02 0.085 1 0 force
particle minecraft:cloud -68.98 70.70 34.25 0.35 0.18 0.35 0.02 3 force
playsound driftgen:grain.kaze.011 neutral @a -77.37 70.67 24.77 12 1
scoreboard players set #gx driftmountains -61571
scoreboard players set #gdx driftmountains -1052
scoreboard players set #gy driftmountains 70512
scoreboard players set #gdy driftmountains -7
scoreboard players set #gz driftmountains 39963
scoreboard players set #gdz driftmountains -829
scoreboard players set #gr driftmountains 17510
scoreboard players set #gdr driftmountains 134
scoreboard players set #gp driftmountains 15
scoreboard players set #gdp driftmountains 12
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.9058f,0.1319f,-0.3555f,0.1890f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.3773f,0.2274f,0.8970f,-0.0374f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.3554f,0.0047f,-0.0122f,-0.9346f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0122f,-0.9346f,0.3554f,0.0047f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3799f,0.8272f,0.2323f],left_rotation:[-0.1667f,-0.0631f,0.3472f,-0.9207f]}}
particle minecraft:cloud -62.31 70.83 41.40 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -62.31 70.63 41.40 0.007 0.02 0.083 1 0 force
particle minecraft:cloud -60.60 70.83 41.25 0.35 0.18 0.35 0.02 3 force
playsound driftgen:grain.onyx.023 neutral @a -69.68 70.87 32.51 12 1
scoreboard players set #gx driftmountains -57356
scoreboard players set #gdx driftmountains -1231
scoreboard players set #gy driftmountains 70510
scoreboard players set #gdy driftmountains 5
scoreboard players set #gz driftmountains 43330
scoreboard players set #gdz driftmountains -808
scoreboard players set #gr driftmountains 17064
scoreboard players set #gdr driftmountains 207
scoreboard players set #gp driftmountains -14
scoreboard players set #gdp driftmountains 5
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.0401f,0.3866f,0.0399f,0.9205f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.0566f,0.9214f,-0.0003f,-0.3846f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.3554f,0.0047f,-0.0122f,-0.9346f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0122f,-0.9346f,0.3554f,0.0047f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3626f,0.8252f,0.0914f],left_rotation:[-0.1654f,-0.0753f,0.4332f,-0.8828f]}}
particle minecraft:cloud -57.98 70.83 44.71 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -57.98 70.63 44.71 0.014 0.02 0.083 1 0 force
particle minecraft:cloud -56.33 70.83 44.44 0.35 0.18 0.35 0.02 3 force
playsound driftgen:grain.kaze.021 neutral @a -65.74 70.96 36.52 12 1
