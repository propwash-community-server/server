scoreboard players set #gx driftmountains -59730
scoreboard players set #gdx driftmountains 386
scoreboard players set #gy driftmountains 69000
scoreboard players set #gdy driftmountains -18
scoreboard players set #gz driftmountains -35285
scoreboard players set #gdz driftmountains -433
scoreboard players set #gr driftmountains -17012
scoreboard players set #gdr driftmountains -376
scoreboard players set #gp driftmountains 145
scoreboard players set #gdp driftmountains -1
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.9336f,0.1065f,0.1548f,-0.3050f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[-0.1877f,-0.3230f,0.9276f,-0.0090f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.9239f,0.0121f,0.0050f,0.3823f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0050f,0.3823f,0.9239f,0.0121f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.4011f,0.8409f,0.0975f],left_rotation:[-0.0096f,-0.1830f,0.9794f,-0.0847f]}}
particle minecraft:cloud -60.77 69.32 -34.19 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud -59.12 69.32 -33.90 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -59.12 69.12 -33.90 -0.006 0.02 0.034 1 0 force
scoreboard players set #gx driftmountains -64736
scoreboard players set #gdx driftmountains 567
scoreboard players set #gy driftmountains 69129
scoreboard players set #gdy driftmountains -11
scoreboard players set #gz driftmountains -34261
scoreboard players set #gdz driftmountains -235
scoreboard players set #gr driftmountains -13716
scoreboard players set #gdr driftmountains -421
scoreboard players set #gp driftmountains 91
scoreboard players set #gdp driftmountains 5
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[0.0061f,-0.0001f,0.0154f,0.9999f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.9277f,0.1100f,0.1549f,-0.3213f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[-0.1895f,-0.3393f,0.9213f,-0.0131f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.9239f,0.0121f,0.0050f,0.3823f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0050f,0.3823f,0.9239f,0.0121f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.4019f,0.8640f,0.2467f],left_rotation:[-0.0139f,-0.1900f,0.9763f,-0.1033f]}}
particle minecraft:cloud -66.29 69.45 -33.84 0.35 0.18 0.35 0.02 2 force
particle minecraft:cloud -65.04 69.45 -32.68 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -65.04 69.25 -32.68 -0.026 0.02 0.028 1 0 force
scoreboard players set #gx driftmountains -69575
scoreboard players set #gdx driftmountains 728
scoreboard players set #gy driftmountains 69209
scoreboard players set #gdy driftmountains -11
scoreboard players set #gz driftmountains -31154
scoreboard players set #gdz driftmountains -300
scoreboard players set #gr driftmountains -11852
scoreboard players set #gdr driftmountains -43
scoreboard players set #gp driftmountains 76
scoreboard players set #gdp driftmountains 1
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[0.0061f,-0.0000f,0.0036f,1.0000f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.2088f,-0.0474f,0.0638f,0.9747f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.0383f,0.9734f,0.2150f,0.0696f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.9239f,0.0121f,0.0050f,0.3823f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0050f,0.3823f,0.9239f,0.0121f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3647f,0.8636f,0.1064f],left_rotation:[0.1631f,-0.1014f,0.5110f,0.8378f]}}
