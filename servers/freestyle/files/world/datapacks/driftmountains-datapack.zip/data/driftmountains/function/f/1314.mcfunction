scoreboard players set #gx driftmountains -46807
scoreboard players set #gdx driftmountains 571
scoreboard players set #gy driftmountains 67688
scoreboard players set #gdy driftmountains -13
scoreboard players set #gz driftmountains -87789
scoreboard players set #gdz driftmountains -479
scoreboard players set #gr driftmountains -9673
scoreboard players set #gdr driftmountains 200
scoreboard players set #gp driftmountains 81
scoreboard players set #gdp driftmountains 2
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[0.0061f,0.0001f,-0.0208f,0.9998f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.0349f,-0.2442f,-0.0629f,-0.9671f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[-0.0384f,-0.9658f,0.0608f,0.2492f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.3272f,0.0043f,-0.0124f,-0.9449f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0124f,-0.9449f,0.3272f,0.0043f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3802f,0.8663f,0.1075f],left_rotation:[-0.1248f,0.1455f,-0.7540f,-0.6282f]}}
particle minecraft:cloud -48.16 68.01 -88.47 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -48.16 67.81 -88.47 -0.045 0.02 0.005 1 0 force
particle minecraft:cloud -47.96 68.01 -86.81 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -50448
scoreboard players set #gdx driftmountains 463
scoreboard players set #gy driftmountains 67775
scoreboard players set #gdy driftmountains -13
scoreboard players set #gz driftmountains -84022
scoreboard players set #gdz driftmountains -601
scoreboard players set #gr driftmountains -10865
scoreboard players set #gdr driftmountains 167
scoreboard players set #gp driftmountains 79
scoreboard players set #gdp driftmountains -2
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0001f,-0.0210f,0.9998f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.3629f,-0.2114f,-0.1439f,-0.8960f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.0506f,-0.8858f,0.3872f,0.2507f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.3272f,0.0043f,-0.0124f,-0.9449f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0124f,-0.9449f,0.3272f,0.0043f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3647f,0.8688f,0.2486f],left_rotation:[-0.1235f,0.1460f,-0.7310f,-0.6551f]}}
particle minecraft:cloud -52.01 68.10 -84.40 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -52.01 67.90 -84.40 -0.041 0.02 0.014 1 0 force
particle minecraft:cloud -51.47 68.10 -82.78 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -52628
scoreboard players set #gdx driftmountains 269
scoreboard players set #gy driftmountains 67869
scoreboard players set #gdy driftmountains -11
scoreboard players set #gz driftmountains -78820
scoreboard players set #gdz driftmountains -565
scoreboard players set #gr driftmountains -12491
scoreboard players set #gdr driftmountains 85
scoreboard players set #gp driftmountains 87
scoreboard players set #gdp driftmountains -1
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0001f,-0.0183f,0.9998f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.9706f,0.0465f,-0.2341f,-0.0305f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.2322f,-0.0061f,0.9711f,0.0553f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.3272f,0.0043f,-0.0124f,-0.9449f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0124f,-0.9449f,0.3272f,0.0043f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3863f,0.8648f,0.1069f],left_rotation:[-0.1057f,0.1589f,-0.8291f,-0.5253f]}}
particle minecraft:cloud -54.14 68.19 -78.78 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -54.14 67.99 -78.78 -0.035 0.02 0.024 1 0 force
particle minecraft:cloud -53.18 68.19 -77.41 0.35 0.18 0.35 0.02 2 force
