scoreboard players set #gx driftmountains -87909
scoreboard players set #gdx driftmountains -739
scoreboard players set #gy driftmountains 69983
scoreboard players set #gdy driftmountains -1
scoreboard players set #gz driftmountains 12431
scoreboard players set #gdz driftmountains -877
scoreboard players set #gr driftmountains 17705
scoreboard players set #gdr driftmountains 75
scoreboard players set #gp driftmountains 5
scoreboard players set #gdp driftmountains -5
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.9315f,0.1107f,-0.3032f,0.1676f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.3225f,0.2004f,0.9250f,-0.0134f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.9320f,0.0122f,-0.0047f,-0.3622f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0047f,-0.3622f,0.9320f,0.0122f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3537f,0.8514f,0.1017f],left_rotation:[-0.1849f,0.0416f,-0.1876f,-0.9637f]}}
particle minecraft:cloud -88.68 70.30 13.73 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -88.68 70.10 13.73 0.004 0.02 0.069 1 0 force
particle minecraft:cloud -87.01 70.30 13.65 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -81670
scoreboard players set #gdx driftmountains -820
scoreboard players set #gy driftmountains 70062
scoreboard players set #gdy driftmountains -17
scoreboard players set #gz driftmountains 19812
scoreboard players set #gdz driftmountains -918
scoreboard players set #gr driftmountains 17380
scoreboard players set #gdr driftmountains 8
scoreboard players set #gp driftmountains 65
scoreboard players set #gdp driftmountains -5
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[0.0061f,0.0001f,-0.0218f,0.9997f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.5177f,0.2824f,-0.1176f,0.7990f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.2022f,0.8157f,0.4909f,-0.2295f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.9320f,0.0122f,-0.0047f,-0.3622f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0047f,-0.3622f,0.9320f,0.0122f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3558f,0.8485f,0.2407f],left_rotation:[-0.1703f,0.0715f,-0.3424f,-0.9212f]}}
particle minecraft:cloud -82.37 70.38 21.26 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -82.37 70.18 21.26 0.008 0.02 0.075 1 0 force
particle minecraft:cloud -80.67 70.38 21.08 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -77370
scoreboard players set #gdx driftmountains -892
scoreboard players set #gy driftmountains 70159
scoreboard players set #gdy driftmountains -23
scoreboard players set #gz driftmountains 24090
scoreboard players set #gdz driftmountains -976
scoreboard players set #gr driftmountains 17674
scoreboard players set #gdr driftmountains 4
scoreboard players set #gp driftmountains 79
scoreboard players set #gdp driftmountains -2
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.6384f,-0.2069f,-0.2665f,-0.6918f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.1952f,-0.6677f,0.6637f,0.2751f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.9320f,0.0122f,-0.0047f,-0.3622f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0047f,-0.3622f,0.9320f,0.0122f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3524f,0.8451f,0.0992f],left_rotation:[-0.1873f,0.0158f,-0.0492f,-0.9809f]}}
particle minecraft:cloud -78.13 70.48 25.40 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -78.13 70.28 25.40 0.004 0.02 0.074 1 0 force
particle minecraft:cloud -76.46 70.48 25.30 0.35 0.18 0.35 0.02 3 force
