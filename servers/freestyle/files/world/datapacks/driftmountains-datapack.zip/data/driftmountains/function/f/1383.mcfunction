scoreboard players set #gx driftmountains 1099
scoreboard players set #gdx driftmountains 851
scoreboard players set #gy driftmountains 66855
scoreboard players set #gdy driftmountains -11
scoreboard players set #gz driftmountains -70690
scoreboard players set #gdz driftmountains 576
scoreboard players set #gr driftmountains -5083
scoreboard players set #gdr driftmountains -16
scoreboard players set #gp driftmountains 61
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0000f,-0.0031f,1.0000f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.8907f,0.0663f,-0.0151f,0.4495f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.0624f,0.4536f,0.8886f,0.0270f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.9600f,0.0126f,-0.0037f,-0.2796f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0037f,-0.2796f,0.9600f,0.0126f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3602f,0.8270f,0.0921f],left_rotation:[0.1706f,0.0644f,-0.3761f,0.9084f]}}
scoreboard players set #gx driftmountains -5843
scoreboard players set #gdx driftmountains 844
scoreboard players set #gy driftmountains 66943
scoreboard players set #gdy driftmountains -11
scoreboard players set #gz driftmountains -74991
scoreboard players set #gdz driftmountains 538
scoreboard players set #gr driftmountains -4835
scoreboard players set #gdr driftmountains -70
scoreboard players set #gp driftmountains 62
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0000f,-0.0056f,1.0000f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.4000f,0.0936f,0.0163f,0.9116f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.0795f,0.9149f,0.3924f,-0.0521f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.9600f,0.0126f,-0.0037f,-0.2796f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0037f,-0.2796f,0.9600f,0.0126f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3968f,0.8324f,0.2343f],left_rotation:[0.1322f,0.1226f,-0.6475f,0.7405f]}}
scoreboard players set #gx driftmountains -13941
scoreboard players set #gdx driftmountains 784
scoreboard players set #gy driftmountains 67055
scoreboard players set #gdy driftmountains -11
scoreboard players set #gz driftmountains -80657
scoreboard players set #gdz driftmountains 516
scoreboard players set #gr driftmountains -3447
scoreboard players set #gdr driftmountains -108
scoreboard players set #gp driftmountains 62
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0001f,-0.0136f,0.9999f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.8633f,0.1373f,-0.1428f,0.4642f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.1924f,0.4817f,0.8536f,-0.0473f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.9600f,0.0126f,-0.0037f,-0.2796f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0037f,-0.2796f,0.9600f,0.0126f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3994f,0.8525f,0.1021f],left_rotation:[-0.0390f,0.1825f,-0.9674f,-0.1707f]}}
particle minecraft:cloud -13.97 67.38 -82.17 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -13.97 67.18 -82.17 -0.032 0.02 -0.047 1 0 force
particle minecraft:cloud -15.34 67.38 -81.22 0.35 0.18 0.35 0.02 2 force
