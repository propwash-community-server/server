scoreboard players set #gx driftmountains 11670
scoreboard players set #gdx driftmountains 454
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains -6048
scoreboard players set #gdz driftmountains 880
scoreboard players set #gr driftmountains 1077
scoreboard players set #gdr driftmountains 31
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.8383f,0.1966f,-0.2561f,0.4394f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.3037f,0.4687f,0.8222f,-0.1096f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.4399f,0.0058f,0.0118f,0.8980f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0118f,0.8980f,0.4399f,0.0058f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3537f,0.8514f,0.1017f],left_rotation:[-0.1849f,0.0416f,-0.1874f,-0.9638f]}}
particle minecraft:cloud 12.73 71.32 -7.13 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 12.73 71.12 -7.13 0.011 0.02 -0.058 1 0 force
particle minecraft:cloud 11.09 71.32 -7.44 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains 8549
scoreboard players set #gdx driftmountains 468
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains -11674
scoreboard players set #gdz driftmountains 881
scoreboard players set #gr driftmountains 1010
scoreboard players set #gdr driftmountains -12
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.3397f,0.3217f,-0.0647f,0.8814f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.1577f,0.8931f,0.3078f,-0.2878f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.4399f,0.0058f,0.0118f,0.8980f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0118f,0.8980f,0.4399f,0.0058f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3591f,0.8389f,0.2369f],left_rotation:[-0.1788f,0.0316f,-0.1366f,-0.9739f]}}
particle minecraft:cloud 9.63 71.32 -12.87 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 9.63 71.12 -12.87 0.010 0.02 -0.056 1 0 force
particle minecraft:cloud 7.95 71.32 -13.17 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains 5905
scoreboard players set #gdx driftmountains 425
scoreboard players set #gy driftmountains 70877
scoreboard players set #gdy driftmountains 47
scoreboard players set #gz driftmountains -16479
scoreboard players set #gdz driftmountains 762
scoreboard players set #gr driftmountains 1251
scoreboard players set #gdr driftmountains -64
scoreboard players set #gp driftmountains -251
scoreboard players set #gdp driftmountains 44
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.8897f,0.1612f,-0.3077f,0.2963f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.3405f,0.3303f,0.8776f,-0.0686f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.4399f,0.0058f,0.0118f,0.8980f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0118f,0.8980f,0.4399f,0.0058f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3525f,0.8407f,0.0974f],left_rotation:[-0.1867f,-0.0022f,0.0469f,-0.9812f]}}
particle minecraft:cloud 6.99 71.20 -17.53 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 6.99 71.00 -17.53 0.011 0.02 -0.050 1 0 force
particle minecraft:cloud 5.36 71.20 -17.89 0.35 0.18 0.35 0.02 3 force
