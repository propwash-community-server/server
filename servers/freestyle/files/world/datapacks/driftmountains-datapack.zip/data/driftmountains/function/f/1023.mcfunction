scoreboard players set #gx driftmountains 22603
scoreboard players set #gdx driftmountains -582
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 49915
scoreboard players set #gdz driftmountains 921
scoreboard players set #gr driftmountains 8426
scoreboard players set #gdr driftmountains 167
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.8529f,-0.0886f,-0.4082f,-0.3131f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.3775f,-0.2720f,0.8669f,0.1787f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.3965f,0.0052f,-0.0120f,-0.9180f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0120f,-0.9180f,0.3965f,0.0052f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3759f,0.8210f,0.0897f],left_rotation:[-0.1332f,-0.1204f,0.6679f,-0.7222f]}}
particle minecraft:cloud 23.94 71.32 50.62 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 23.94 71.12 50.62 0.065 0.02 -0.007 1 0 force
particle minecraft:cloud 23.77 71.32 48.96 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains 26634
scoreboard players set #gdx driftmountains -424
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 42525
scoreboard players set #gdz driftmountains 974
scoreboard players set #gr driftmountains 8464
scoreboard players set #gdr driftmountains 116
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.7866f,0.2644f,-0.3991f,0.3901f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.4423f,0.4342f,0.7631f,-0.1832f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.3965f,0.0052f,-0.0120f,-0.9180f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0120f,-0.9180f,0.3965f,0.0052f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.4042f,0.8601f,0.2452f],left_rotation:[-0.0309f,-0.1868f,0.9623f,-0.1954f]}}
particle minecraft:cloud 28.07 71.32 43.25 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 28.07 71.12 43.25 0.064 0.02 -0.006 1 0 force
particle minecraft:cloud 27.91 71.32 41.55 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains 27283
scoreboard players set #gdx driftmountains -76
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 37699
scoreboard players set #gdz driftmountains 929
scoreboard players set #gr driftmountains 6232
scoreboard players set #gdr driftmountains 298
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0001f,-0.0223f,0.9997f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.1915f,-0.4124f,-0.1495f,-0.8780f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.0580f,-0.8671f,0.2359f,0.4348f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.3965f,0.0052f,-0.0120f,-0.9180f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0120f,-0.9180f,0.3965f,0.0052f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3861f,0.8227f,0.0904f],left_rotation:[-0.1023f,-0.1472f,0.8052f,-0.5652f]}}
particle minecraft:cloud 28.79 71.32 37.85 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 28.79 71.12 37.85 0.049 0.02 -0.026 1 0 force
particle minecraft:cloud 28.01 71.32 36.37 0.35 0.18 0.35 0.02 3 force
