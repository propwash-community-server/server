scoreboard players set #gx driftmountains -89174
scoreboard players set #gdx driftmountains 545
scoreboard players set #gy driftmountains 69592
scoreboard players set #gdy driftmountains -18
scoreboard players set #gz driftmountains -24211
scoreboard players set #gdz driftmountains -357
scoreboard players set #gr driftmountains -7966
scoreboard players set #gdr driftmountains 154
scoreboard players set #gp driftmountains 110
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.9275f,0.1107f,-0.3205f,0.1572f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.3388f,0.1917f,0.9210f,-0.0138f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.0108f,0.0001f,-0.0131f,-0.9999f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0131f,-0.9999f,0.0108f,0.0001f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3523f,0.8443f,0.0989f],left_rotation:[-0.1873f,0.0126f,-0.0323f,-0.9816f]}}
particle minecraft:cloud -90.26 69.91 -25.26 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -90.26 69.71 -25.26 -0.039 0.02 -0.007 1 0 force
particle minecraft:cloud -90.56 69.91 -23.62 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -94080
scoreboard players set #gdx driftmountains 511
scoreboard players set #gy driftmountains 69764
scoreboard players set #gdy driftmountains -20
scoreboard players set #gz driftmountains -19877
scoreboard players set #gdz driftmountains -596
scoreboard players set #gr driftmountains -9355
scoreboard players set #gdr driftmountains 100
scoreboard players set #gp driftmountains 98
scoreboard players set #gdp driftmountains 3
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[0.0061f,0.0001f,-0.0223f,0.9997f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.4523f,-0.2765f,-0.2163f,-0.8199f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.1313f,-0.8017f,0.4839f,0.3255f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.0108f,0.0001f,-0.0131f,-0.9999f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0131f,-0.9999f,0.0108f,0.0001f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3667f,0.8312f,0.2339f],left_rotation:[-0.1789f,-0.0111f,0.0823f,-0.9804f]}}
particle minecraft:cloud -95.50 70.08 -20.65 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -95.50 69.88 -20.65 -0.048 0.02 0.003 1 0 force
particle minecraft:cloud -95.39 70.08 -18.94 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -96881
scoreboard players set #gdx driftmountains 349
scoreboard players set #gy driftmountains 69882
scoreboard players set #gdy driftmountains -17
scoreboard players set #gz driftmountains -15701
scoreboard players set #gdz driftmountains -674
scoreboard players set #gr driftmountains -10420
scoreboard players set #gdr driftmountains 355
scoreboard players set #gp driftmountains 79
scoreboard players set #gdp driftmountains 3
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0001f,-0.0223f,0.9997f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.9295f,0.0070f,-0.3438f,-0.1332f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.3317f,-0.0978f,0.9339f,0.0907f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.0108f,0.0001f,-0.0131f,-0.9999f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0131f,-0.9999f,0.0108f,0.0001f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3524f,0.8422f,0.0980f],left_rotation:[-0.1871f,0.0041f,0.0134f,-0.9822f]}}
particle minecraft:cloud -98.31 70.20 -16.20 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -98.31 70.00 -16.20 -0.043 0.02 0.011 1 0 force
particle minecraft:cloud -97.90 70.20 -14.58 0.35 0.18 0.35 0.02 3 force
