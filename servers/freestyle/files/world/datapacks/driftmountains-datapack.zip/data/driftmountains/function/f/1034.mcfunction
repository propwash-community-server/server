scoreboard players set #gx driftmountains 14649
scoreboard players set #gdx driftmountains -871
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 59169
scoreboard players set #gdz driftmountains 647
scoreboard players set #gr driftmountains 10870
scoreboard players set #gdr driftmountains 352
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.5217f,0.3774f,-0.1954f,0.7398f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.2743f,0.7644f,0.4849f,-0.3246f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.9850f,0.0129f,0.0023f,0.1719f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0023f,0.1719f,0.9850f,0.0129f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3795f,0.8211f,0.0898f],left_rotation:[-0.1232f,-0.1303f,0.7190f,-0.6714f]}}
particle minecraft:cloud 15.57 71.32 60.36 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 15.57 71.12 60.36 0.062 0.02 0.021 1 0 force
particle minecraft:cloud 16.11 71.32 58.78 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains 19971
scoreboard players set #gdx driftmountains -808
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 52608
scoreboard players set #gdz driftmountains 838
scoreboard players set #gr driftmountains 10189
scoreboard players set #gdr driftmountains 174
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[0.0027f,0.0001f,-0.0223f,0.9997f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.1760f,-0.4380f,-0.1488f,-0.8689f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.0583f,-0.8581f,0.2230f,0.4589f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.9850f,0.0129f,0.0023f,0.1719f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0023f,0.1719f,0.9850f,0.0129f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.4062f,0.8525f,0.2422f],left_rotation:[-0.0600f,-0.1771f,0.9166f,-0.3535f]}}
particle minecraft:cloud 21.13 71.32 53.73 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 21.13 71.12 53.73 0.066 0.02 0.014 1 0 force
particle minecraft:cloud 21.48 71.32 52.05 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains 24319
scoreboard players set #gdx driftmountains -502
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 48174
scoreboard players set #gdz driftmountains 950
scoreboard players set #gr driftmountains 8320
scoreboard players set #gdr driftmountains 202
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.8988f,0.0378f,-0.4346f,-0.0421f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.4326f,0.0033f,0.8998f,0.0565f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.9850f,0.0129f,0.0023f,0.1719f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0023f,0.1719f,0.9850f,0.0129f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3850f,0.8223f,0.0902f],left_rotation:[-0.1062f,-0.1443f,0.7908f,-0.5851f]}}
particle minecraft:cloud 25.67 71.32 48.85 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 25.67 71.12 48.85 0.063 0.02 -0.008 1 0 force
particle minecraft:cloud 25.47 71.32 47.20 0.35 0.18 0.35 0.02 3 force
