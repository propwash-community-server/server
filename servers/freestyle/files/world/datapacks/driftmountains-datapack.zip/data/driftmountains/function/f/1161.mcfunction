scoreboard players set #gx driftmountains -97943
scoreboard players set #gdx driftmountains 116
scoreboard players set #gy driftmountains 69961
scoreboard players set #gdy driftmountains -14
scoreboard players set #gz driftmountains -11762
scoreboard players set #gdz driftmountains -777
scoreboard players set #gr driftmountains -12261
scoreboard players set #gdr driftmountains 208
scoreboard players set #gp driftmountains 62
scoreboard players set #gdp driftmountains 4
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.0390f,-0.3517f,-0.0707f,-0.9326f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[-0.0269f,-0.9303f,0.0762f,0.3577f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.7351f,0.0096f,0.0089f,0.6778f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0089f,0.6778f,0.7351f,0.0096f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3539f,0.8357f,0.0955f],left_rotation:[-0.1839f,-0.0228f,0.1561f,-0.9702f]}}
particle minecraft:cloud -99.45 70.28 -11.79 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -99.45 70.08 -11.79 -0.040 0.02 0.026 1 0 force
particle minecraft:cloud -98.55 70.28 -10.38 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -97805
scoreboard players set #gdx driftmountains -133
scoreboard players set #gy driftmountains 70032
scoreboard players set #gdy driftmountains -2
scoreboard players set #gz driftmountains -4101
scoreboard players set #gdz driftmountains -858
scoreboard players set #gr driftmountains -13981
scoreboard players set #gdr driftmountains 135
scoreboard players set #gp driftmountains 8
scoreboard players set #gdp driftmountains 5
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.4173f,-0.3084f,-0.2190f,-0.8263f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.1333f,-0.8079f,0.4520f,0.3540f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.7351f,0.0096f,0.0089f,0.6778f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0089f,0.6778f,0.7351f,0.0096f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3795f,0.8272f,0.2323f],left_rotation:[-0.1673f,-0.0615f,0.3391f,-0.9237f]}}
particle minecraft:cloud -99.34 70.35 -3.61 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -99.34 70.15 -3.61 -0.034 0.02 0.040 1 0 force
particle minecraft:cloud -98.03 70.35 -2.51 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -96330
scoreboard players set #gdx driftmountains -352
scoreboard players set #gy driftmountains 70027
scoreboard players set #gdy driftmountains 3
scoreboard players set #gz driftmountains 1141
scoreboard players set #gdz driftmountains -834
scoreboard players set #gr driftmountains -15265
scoreboard players set #gdr driftmountains 277
scoreboard players set #gp driftmountains -12
scoreboard players set #gdp driftmountains 2
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[0.0024f,0.0001f,-0.0223f,0.9997f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.9026f,0.1369f,-0.3553f,0.2007f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.3783f,0.2392f,0.8932f,-0.0428f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.7351f,0.0096f,0.0089f,0.6778f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0089f,0.6778f,0.7351f,0.0096f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3597f,0.8275f,0.0923f],left_rotation:[-0.1718f,-0.0617f,0.3619f,-0.9141f]}}
particle minecraft:cloud -97.65 70.35 1.88 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -97.65 70.15 1.88 -0.025 0.02 0.049 1 0 force
particle minecraft:cloud -96.17 70.35 2.64 0.35 0.18 0.35 0.02 3 force
