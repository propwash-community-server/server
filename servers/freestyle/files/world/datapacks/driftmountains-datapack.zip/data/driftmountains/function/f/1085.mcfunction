scoreboard players set #gx driftmountains -39046
scoreboard players set #gdx driftmountains -1184
scoreboard players set #gy driftmountains 70571
scoreboard players set #gdy driftmountains -30
scoreboard players set #gz driftmountains 51268
scoreboard players set #gdz driftmountains -426
scoreboard players set #gr driftmountains 15475
scoreboard players set #gdr driftmountains 6
scoreboard players set #gp driftmountains 104
scoreboard players set #gdp driftmountains -15
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.9108f,0.1209f,-0.3607f,0.1604f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.3795f,0.1992f,0.9031f,-0.0258f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.8832f,0.0116f,-0.0061f,-0.4688f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0061f,-0.4688f,0.8832f,0.0116f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3595f,0.8276f,0.0923f],left_rotation:[-0.1721f,-0.0611f,0.3588f,-0.9153f]}}
particle minecraft:cloud -39.26 70.89 52.76 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -39.26 70.69 52.76 0.032 0.02 0.068 1 0 force
particle minecraft:cloud -37.75 70.89 52.05 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -29109
scoreboard players set #gdx driftmountains -1213
scoreboard players set #gy driftmountains 70902
scoreboard players set #gdy driftmountains -37
scoreboard players set #gz driftmountains 54732
scoreboard players set #gdz driftmountains -389
scoreboard players set #gr driftmountains 15387
scoreboard players set #gdr driftmountains 33
scoreboard players set #gp driftmountains 108
scoreboard players set #gdp driftmountains 11
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.5048f,0.3542f,-0.1644f,0.7698f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.2462f,0.7914f,0.4704f,-0.3031f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.8832f,0.0116f,-0.0061f,-0.4688f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0061f,-0.4688f,0.8832f,0.0116f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3856f,0.8276f,0.2324f],left_rotation:[-0.1580f,-0.0830f,0.4482f,-0.8760f]}}
particle minecraft:cloud -29.28 71.22 56.33 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -29.28 71.02 56.33 0.032 0.02 0.066 1 0 force
particle minecraft:cloud -27.74 71.22 55.58 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -24428
scoreboard players set #gdx driftmountains -1166
scoreboard players set #gy driftmountains 70995
scoreboard players set #gdy driftmountains -12
scoreboard players set #gz driftmountains 56371
scoreboard players set #gdz driftmountains -338
scoreboard players set #gr driftmountains 15237
scoreboard players set #gdr driftmountains 20
scoreboard players set #gp driftmountains 25
scoreboard players set #gdp driftmountains 30
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.6211f,-0.2483f,-0.3045f,-0.6781f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.2349f,-0.6498f,0.6507f,0.3149f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.8832f,0.0116f,-0.0061f,-0.4688f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0061f,-0.4688f,0.8832f,0.0116f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3644f,0.8241f,0.0910f],left_rotation:[-0.1615f,-0.0823f,0.4699f,-0.8639f]}}
particle minecraft:cloud -24.58 71.32 57.87 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -24.58 71.12 57.87 0.033 0.02 0.064 1 0 force
particle minecraft:cloud -23.10 71.32 57.10 0.35 0.18 0.35 0.02 3 force
