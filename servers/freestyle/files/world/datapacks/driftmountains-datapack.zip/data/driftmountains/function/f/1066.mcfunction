scoreboard players set #gx driftmountains -17626
scoreboard players set #gdx driftmountains -1073
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 58222
scoreboard players set #gdz driftmountains -323
scoreboard players set #gr driftmountains 15287
scoreboard players set #gdr driftmountains 18
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.9163f,0.0224f,-0.3916f,-0.0811f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.3853f,-0.0404f,0.9190f,0.0738f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.6994f,0.0092f,-0.0094f,-0.7147f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0094f,-0.7147f,0.6994f,0.0092f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3641f,0.8243f,0.0910f],left_rotation:[-0.1621f,-0.0813f,0.4644f,-0.8668f]}}
particle minecraft:cloud -17.79 71.32 59.72 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -17.79 71.12 59.72 0.031 0.02 0.060 1 0 force
particle minecraft:cloud -16.31 71.32 58.96 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -8904
scoreboard players set #gdx driftmountains -954
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 60457
scoreboard players set #gdz driftmountains -249
scoreboard players set #gr driftmountains 15265
scoreboard players set #gdr driftmountains -73
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.6830f,0.3088f,-0.2608f,0.6084f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.3262f,0.6391f,0.6543f,-0.2387f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.6994f,0.0092f,-0.0094f,-0.7147f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0094f,-0.7147f,0.6994f,0.0092f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3922f,0.8296f,0.2332f],left_rotation:[-0.1447f,-0.1058f,0.5634f,-0.8065f]}}
particle minecraft:cloud -9.04 71.32 62.06 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -9.04 71.12 62.06 0.027 0.02 0.052 1 0 force
particle minecraft:cloud -7.52 71.32 61.28 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -3876
scoreboard players set #gdx driftmountains -1047
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 61951
scoreboard players set #gdz driftmountains -253
scoreboard players set #gr driftmountains 15601
scoreboard players set #gdr driftmountains 3
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.4153f,-0.3500f,-0.2461f,-0.8028f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.1631f,-0.7813f,0.4543f,0.3956f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.6994f,0.0092f,-0.0094f,-0.7147f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0094f,-0.7147f,0.6994f,0.0092f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3809f,0.8213f,0.0898f],left_rotation:[-0.1189f,-0.1341f,0.7385f,-0.6500f]}}
particle minecraft:cloud -4.13 71.32 63.44 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -4.13 71.12 63.44 0.026 0.02 0.058 1 0 force
particle minecraft:cloud -2.60 71.32 62.76 0.35 0.18 0.35 0.02 3 force
