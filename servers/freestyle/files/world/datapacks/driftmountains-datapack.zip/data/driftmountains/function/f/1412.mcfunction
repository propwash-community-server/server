scoreboard players set #gx driftmountains 28657
scoreboard players set #gdx driftmountains 1069
scoreboard players set #gy driftmountains 66503
scoreboard players set #gdy driftmountains -14
scoreboard players set #gz driftmountains -53041
scoreboard players set #gdz driftmountains 623
scoreboard players set #gr driftmountains -5746
scoreboard players set #gdr driftmountains 28
scoreboard players set #gp driftmountains 64
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0000f,-0.0017f,1.0000f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.9772f,0.0543f,-0.0038f,0.2053f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.0254f,0.2069f,0.9769f,0.0481f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.8895f,0.0116f,-0.0060f,-0.4567f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0060f,-0.4567f,0.8895f,0.0116f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3535f,0.8369f,0.0959f],left_rotation:[0.1847f,0.0180f,-0.1306f,0.9739f]}}
scoreboard players set #gx driftmountains 21035
scoreboard players set #gdx driftmountains 1107
scoreboard players set #gy driftmountains 66600
scoreboard players set #gdy driftmountains -14
scoreboard players set #gz driftmountains -57372
scoreboard players set #gdz driftmountains 726
scoreboard players set #gr driftmountains -5789
scoreboard players set #gdr driftmountains 43
scoreboard players set #gp driftmountains 62
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[-0.0039f,0.0000f,0.0007f,1.0000f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.6204f,0.0213f,0.0499f,0.7824f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.0320f,0.7815f,0.6216f,0.0438f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.8895f,0.0116f,-0.0060f,-0.4567f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0060f,-0.4567f,0.8895f,0.0116f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3592f,0.8386f,0.2368f],left_rotation:[0.1790f,-0.0304f,0.1305f,0.9747f]}}
scoreboard players set #gx driftmountains 11777
scoreboard players set #gdx driftmountains 1009
scoreboard players set #gy driftmountains 66720
scoreboard players set #gdy driftmountains -13
scoreboard players set #gz driftmountains -63634
scoreboard players set #gdz driftmountains 668
scoreboard players set #gr driftmountains -5832
scoreboard players set #gdr driftmountains -22
scoreboard players set #gp driftmountains 61
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,0.0000f,0.0011f,1.0000f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.9693f,0.0471f,0.0278f,0.2398f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[-0.0027f,0.2382f,0.9697f,0.0546f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.8895f,0.0116f,-0.0060f,-0.4567f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0060f,-0.4567f,0.8895f,0.0116f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3531f,0.8494f,0.1009f],left_rotation:[0.1861f,-0.0331f,0.1421f,0.9716f]}}
