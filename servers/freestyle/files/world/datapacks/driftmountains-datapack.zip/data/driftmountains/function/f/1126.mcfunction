scoreboard players set #gx driftmountains -82481
scoreboard players set #gdx driftmountains -810
scoreboard players set #gy driftmountains 70045
scoreboard players set #gdy driftmountains -15
scoreboard players set #gz driftmountains 18887
scoreboard players set #gdz driftmountains -950
scoreboard players set #gr driftmountains 17573
scoreboard players set #gdr driftmountains 16
scoreboard players set #gp driftmountains 60
scoreboard players set #gdp driftmountains -7
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.9467f,0.0293f,-0.3108f,-0.0789f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.3043f,-0.0466f,0.9489f,0.0700f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.7963f,0.0104f,-0.0079f,-0.6048f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0079f,-0.6048f,0.7963f,0.0104f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3559f,0.8557f,0.1033f],left_rotation:[-0.1809f,0.0599f,-0.2858f,-0.9391f]}}
particle minecraft:cloud -83.22 70.37 20.21 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -83.22 70.17 20.21 0.006 0.02 0.075 1 0 force
particle minecraft:cloud -81.55 70.37 20.08 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -75473
scoreboard players set #gdx driftmountains -942
scoreboard players set #gy driftmountains 70217
scoreboard players set #gdy driftmountains -26
scoreboard players set #gz driftmountains 26535
scoreboard players set #gdz driftmountains -997
scoreboard players set #gr driftmountains 17516
scoreboard players set #gdr driftmountains 11
scoreboard players set #gp driftmountains 84
scoreboard players set #gdp driftmountains -1
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[-0.0004f,-0.0000f,-0.0223f,0.9998f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.7018f,0.2589f,-0.2051f,0.6312f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.2726f,0.6562f,0.6784f,-0.1866f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.7963f,0.0104f,-0.0079f,-0.6048f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0079f,-0.6048f,0.7963f,0.0104f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3596f,0.8380f,0.2365f],left_rotation:[-0.1792f,0.0276f,-0.1163f,-0.9765f]}}
particle minecraft:cloud -76.21 70.54 27.97 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -76.21 70.34 27.97 0.007 0.02 0.082 1 0 force
particle minecraft:cloud -74.51 70.54 27.82 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -71272
scoreboard players set #gdx driftmountains -908
scoreboard players set #gy driftmountains 70328
scoreboard players set #gdy driftmountains -25
scoreboard players set #gz driftmountains 30698
scoreboard players set #gdz driftmountains -976
scoreboard players set #gr driftmountains 17821
scoreboard players set #gdr driftmountains -57
scoreboard players set #gp driftmountains 81
scoreboard players set #gdp driftmountains 2
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[0.0061f,0.0001f,-0.0223f,0.9997f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.4340f,-0.2831f,-0.2113f,-0.8287f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.1254f,-0.8111f,0.4661f,0.3303f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.7963f,0.0104f,-0.0079f,-0.6048f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0079f,-0.6048f,0.7963f,0.0104f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3531f,0.8381f,0.0964f],left_rotation:[-0.1855f,-0.0130f,0.1043f,-0.9770f]}}
particle minecraft:cloud -72.07 70.65 31.98 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -72.07 70.45 31.98 0.003 0.02 0.080 1 0 force
particle minecraft:cloud -70.40 70.65 31.93 0.35 0.18 0.35 0.02 3 force
