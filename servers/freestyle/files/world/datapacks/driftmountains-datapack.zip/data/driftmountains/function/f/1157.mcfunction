scoreboard players set #gx driftmountains -98143
scoreboard players set #gdx driftmountains 10
scoreboard players set #gy driftmountains 70007
scoreboard players set #gdy driftmountains -9
scoreboard players set #gz driftmountains -8481
scoreboard players set #gdz driftmountains -844
scoreboard players set #gr driftmountains -13108
scoreboard players set #gdr driftmountains 189
scoreboard players set #gp driftmountains 37
scoreboard players set #gdp driftmountains 8
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.9064f,0.1343f,-0.3468f,0.2004f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.3697f,0.2380f,0.8973f,-0.0398f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.9516f,0.0125f,-0.0040f,-0.3070f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0040f,-0.3070f,0.9516f,0.0125f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3569f,0.8305f,0.0935f],left_rotation:[-0.1777f,-0.0463f,0.2805f,-0.9421f]}}
particle minecraft:cloud -99.64 70.33 -8.28 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -99.64 70.13 -8.28 -0.038 0.02 0.034 1 0 force
particle minecraft:cloud -98.54 70.33 -7.02 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -96937
scoreboard players set #gdx driftmountains -287
scoreboard players set #gy driftmountains 70031
scoreboard players set #gdy driftmountains 2
scoreboard players set #gz driftmountains -524
scoreboard players set #gdz driftmountains -944
scoreboard players set #gr driftmountains -14773
scoreboard players set #gdr driftmountains 273
scoreboard players set #gp driftmountains -8
scoreboard players set #gdp driftmountains 3
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[0.0015f,0.0000f,-0.0223f,0.9997f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.5082f,0.3378f,-0.1536f,0.7772f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.2362f,0.7976f,0.4755f,-0.2862f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.9516f,0.0125f,-0.0040f,-0.3070f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0040f,-0.3070f,0.9516f,0.0125f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3759f,0.8276f,0.2325f],left_rotation:[-0.1716f,-0.0485f,0.2729f,-0.9454f]}}
particle minecraft:cloud -98.39 70.35 0.17 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -98.39 70.15 0.17 -0.029 0.02 0.046 1 0 force
particle minecraft:cloud -96.94 70.35 1.09 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -94568
scoreboard players set #gdx driftmountains -517
scoreboard players set #gy driftmountains 70012
scoreboard players set #gdy driftmountains 4
scoreboard players set #gz driftmountains 4342
scoreboard players set #gdz driftmountains -821
scoreboard players set #gr driftmountains -16420
scoreboard players set #gdr driftmountains 319
scoreboard players set #gp driftmountains -17
scoreboard players set #gdp driftmountains 1
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.6281f,-0.2323f,-0.2898f,-0.6837f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.2195f,-0.6571f,0.6560f,0.2996f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.9516f,0.0125f,-0.0040f,-0.3070f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0040f,-0.3070f,0.9516f,0.0125f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3567f,0.8307f,0.0935f],left_rotation:[-0.1780f,-0.0454f,0.2760f,-0.9434f]}}
particle minecraft:cloud -95.71 70.33 5.33 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -95.71 70.13 5.33 -0.015 0.02 0.055 1 0 force
particle minecraft:cloud -94.11 70.33 5.78 0.35 0.18 0.35 0.02 3 force
