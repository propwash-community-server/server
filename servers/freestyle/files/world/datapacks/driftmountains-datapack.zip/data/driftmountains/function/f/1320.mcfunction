scoreboard players set #gx driftmountains -43339
scoreboard players set #gdx driftmountains 587
scoreboard players set #gy driftmountains 67609
scoreboard players set #gdy driftmountains -15
scoreboard players set #gz driftmountains -90244
scoreboard players set #gdz driftmountains -299
scoreboard players set #gr driftmountains -8231
scoreboard players set #gdr driftmountains 305
scoreboard players set #gp driftmountains 99
scoreboard players set #gdp driftmountains 7
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[0.0061f,0.0001f,-0.0220f,0.9997f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.0039f,-0.2262f,-0.0546f,-0.9725f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[-0.0473f,-0.9721f,0.0277f,0.2279f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.9400f,0.0123f,0.0045f,0.3410f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0045f,0.3410f,0.9400f,0.0123f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3888f,0.8637f,0.1064f],left_rotation:[-0.0967f,0.1640f,-0.8579f,-0.4772f]}}
particle minecraft:cloud -44.48 67.93 -91.24 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -44.48 67.73 -91.24 -0.040 0.02 -0.005 1 0 force
particle minecraft:cloud -44.70 67.93 -89.58 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -47585
scoreboard players set #gdx driftmountains 538
scoreboard players set #gy driftmountains 67704
scoreboard players set #gdy driftmountains -13
scoreboard players set #gz driftmountains -87300
scoreboard players set #gdz driftmountains -510
scoreboard players set #gr driftmountains -9889
scoreboard players set #gdr driftmountains 186
scoreboard players set #gp driftmountains 79
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[0.0061f,0.0001f,-0.0216f,0.9997f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.1495f,-0.2401f,-0.0923f,-0.9547f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[-0.0075f,-0.9503f,0.1756f,0.2571f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.9400f,0.0123f,0.0045f,0.3410f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0045f,0.3410f,0.9400f,0.0123f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3642f,0.8684f,0.2484f],left_rotation:[-0.1254f,0.1442f,-0.7216f,-0.6654f]}}
particle minecraft:cloud -49.07 68.02 -87.93 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -49.07 67.82 -87.93 -0.044 0.02 0.007 1 0 force
particle minecraft:cloud -48.80 68.02 -86.24 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -50598
scoreboard players set #gdx driftmountains 348
scoreboard players set #gy driftmountains 67796
scoreboard players set #gdy driftmountains -11
scoreboard players set #gz driftmountains -82596
scoreboard players set #gdz driftmountains -546
scoreboard players set #gr driftmountains -11691
scoreboard players set #gdr driftmountains 121
scoreboard players set #gp driftmountains 80
scoreboard players set #gdp driftmountains 3
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0001f,-0.0190f,0.9998f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.9191f,-0.0238f,-0.2351f,-0.3153f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.2032f,-0.2923f,0.9267f,0.1205f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.9400f,0.0123f,0.0045f,0.3410f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0045f,0.3410f,0.9400f,0.0123f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3873f,0.8644f,0.1067f],left_rotation:[-0.1021f,0.1611f,-0.8411f,-0.5061f]}}
particle minecraft:cloud -52.10 68.12 -82.77 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -52.10 67.92 -82.77 -0.040 0.02 0.020 1 0 force
particle minecraft:cloud -51.34 68.12 -81.28 0.35 0.18 0.35 0.02 3 force
