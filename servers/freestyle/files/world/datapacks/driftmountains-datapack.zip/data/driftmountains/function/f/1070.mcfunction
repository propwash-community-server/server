scoreboard players set #gx driftmountains -21953
scoreboard players set #gdx driftmountains -1097
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 56902
scoreboard players set #gdz driftmountains -343
scoreboard players set #gr driftmountains 15372
scoreboard players set #gdr driftmountains 27
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.5281f,0.3517f,-0.1774f,0.7523f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.2574f,0.7751f,0.4940f,-0.2981f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.9661f,0.0126f,0.0034f,0.2578f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0034f,0.2578f,0.9661f,0.0126f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3648f,0.8239f,0.0909f],left_rotation:[-0.1606f,-0.0839f,0.4783f,-0.8592f]}}
particle minecraft:cloud -22.14 71.32 58.40 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -22.14 71.12 58.40 0.030 0.02 0.062 1 0 force
particle minecraft:cloud -20.65 71.32 57.66 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -12822
scoreboard players set #gdx driftmountains -1024
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 59429
scoreboard players set #gdz driftmountains -273
scoreboard players set #gr driftmountains 15058
scoreboard players set #gdr driftmountains -1
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.1877f,-0.3647f,-0.1338f,-0.9021f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.0397f,-0.8931f,0.2270f,0.3864f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.9661f,0.0126f,0.0034f,0.2578f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0034f,0.2578f,0.9661f,0.0126f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3846f,0.8274f,0.2324f],left_rotation:[-0.1597f,-0.0796f,0.4307f,-0.8847f]}}
particle minecraft:cloud -12.90 71.32 61.04 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -12.90 71.12 61.04 0.031 0.02 0.055 1 0 force
particle minecraft:cloud -11.41 71.32 60.20 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -8030
scoreboard players set #gdx driftmountains -1047
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 60890
scoreboard players set #gdz driftmountains -279
scoreboard players set #gr driftmountains 15415
scoreboard players set #gdr driftmountains -86
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.9083f,0.0387f,-0.4145f,-0.0413f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.4124f,0.0021f,0.9092f,0.0566f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.9661f,0.0126f,0.0034f,0.2578f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0034f,0.2578f,0.9661f,0.0126f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3752f,0.8210f,0.0897f],left_rotation:[-0.1351f,-0.1183f,0.6573f,-0.7318f]}}
particle minecraft:cloud -8.23 71.32 62.39 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -8.23 71.12 62.39 0.028 0.02 0.059 1 0 force
particle minecraft:cloud -6.73 71.32 61.66 0.35 0.18 0.35 0.02 3 force
