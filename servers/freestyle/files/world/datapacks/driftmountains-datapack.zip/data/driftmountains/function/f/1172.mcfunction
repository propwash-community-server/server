scoreboard players set #gx driftmountains -94525
scoreboard players set #gdx driftmountains 502
scoreboard players set #gy driftmountains 69783
scoreboard players set #gdy driftmountains -20
scoreboard players set #gz driftmountains -19282
scoreboard players set #gdz driftmountains -609
scoreboard players set #gr driftmountains -9408
scoreboard players set #gdr driftmountains 56
scoreboard players set #gp driftmountains 96
scoreboard players set #gdp driftmountains 3
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[-0.0008f,-0.0000f,-0.0223f,0.9998f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.0230f,-0.3475f,-0.0644f,-0.9352f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[-0.0335f,-0.9336f,0.0596f,0.3518f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.4881f,0.0064f,-0.0114f,-0.8727f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0114f,-0.8727f,0.4881f,0.0064f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3531f,0.8380f,0.0964f],left_rotation:[-0.1855f,-0.0132f,0.1051f,-0.9769f]}}
particle minecraft:cloud -95.84 70.10 -20.02 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -95.84 69.90 -20.02 -0.047 0.02 0.003 1 0 force
particle minecraft:cloud -95.72 70.10 -18.36 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -97742
scoreboard players set #gdx driftmountains 190
scoreboard players set #gy driftmountains 69937
scoreboard players set #gdy driftmountains -15
scoreboard players set #gz driftmountains -13107
scoreboard players set #gdz driftmountains -759
scoreboard players set #gr driftmountains -11798
scoreboard players set #gdr driftmountains 381
scoreboard players set #gp driftmountains 69
scoreboard players set #gdp driftmountains 4
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.3527f,0.3339f,-0.0752f,0.8709f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.1672f,0.8836f,0.3195f,-0.2987f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.4881f,0.0064f,-0.0114f,-0.8727f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0114f,-0.8727f,0.4881f,0.0064f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3634f,0.8338f,0.2349f],left_rotation:[-0.1800f,0.0053f,-0.0015f,-0.9837f]}}
particle minecraft:cloud -99.35 70.26 -13.22 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -99.35 70.06 -13.22 -0.041 0.02 0.022 1 0 force
particle minecraft:cloud -98.55 70.26 -11.71 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -98257
scoreboard players set #gdx driftmountains 9
scoreboard players set #gy driftmountains 70009
scoreboard players set #gdy driftmountains -8
scoreboard players set #gz driftmountains -8236
scoreboard players set #gdz driftmountains -830
scoreboard players set #gr driftmountains -13010
scoreboard players set #gdr driftmountains 189
scoreboard players set #gp driftmountains 34
scoreboard players set #gdp driftmountains 7
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.2442f,-0.3465f,-0.1533f,-0.8926f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.0604f,-0.8814f,0.2820f,0.3740f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.4881f,0.0064f,-0.0114f,-0.8727f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0114f,-0.8727f,0.4881f,0.0064f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3590f,0.8281f,0.0925f],left_rotation:[-0.1731f,-0.0586f,0.3452f,-0.9205f]}}
particle minecraft:cloud -99.76 70.33 -8.06 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -99.76 70.13 -8.06 -0.037 0.02 0.032 1 0 force
particle minecraft:cloud -98.68 70.33 -6.79 0.35 0.18 0.35 0.02 3 force
