scoreboard players set #gx driftmountains -55574
scoreboard players set #gdx driftmountains -133
scoreboard players set #gy driftmountains 68243
scoreboard players set #gdy driftmountains -13
scoreboard players set #gz driftmountains -62081
scoreboard players set #gdz driftmountains -770
scoreboard players set #gr driftmountains 17804
scoreboard players set #gdr driftmountains 481
scoreboard players set #gp driftmountains 94
scoreboard players set #gdp driftmountains -1
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[0.0028f,0.0000f,-0.0049f,1.0000f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.6296f,0.0784f,0.0038f,0.7729f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.0775f,0.7768f,0.6248f,-0.0127f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.9734f,0.0127f,0.0030f,0.2287f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0030f,0.2287f,0.9734f,0.0127f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3657f,0.8234f,0.0907f],left_rotation:[0.1584f,0.0875f,-0.4972f,0.8485f]}}
playsound driftgen:grain.kaze.046 neutral @a -56.43 68.64 -67.88 12 1
scoreboard players set #gx driftmountains -54150
scoreboard players set #gdx driftmountains -93
scoreboard players set #gy driftmountains 68354
scoreboard players set #gdy driftmountains -13
scoreboard players set #gz driftmountains -56112
scoreboard players set #gdz driftmountains -683
scoreboard players set #gr driftmountains 14740
scoreboard players set #gdr driftmountains 266
scoreboard players set #gp driftmountains 103
scoreboard players set #gdp driftmountains -1
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[-0.0039f,0.0001f,0.0154f,0.9999f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.3043f,0.1966f,0.0081f,-0.9320f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[-0.1061f,-0.9380f,0.2853f,-0.1657f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.9734f,0.0127f,0.0030f,0.2287f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0030f,0.2287f,0.9734f,0.0127f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.4036f,0.8614f,0.2457f],left_rotation:[-0.0257f,-0.1879f,0.9675f,-0.1673f]}}
particle minecraft:cloud -54.14 68.67 -54.50 0.35 0.18 0.35 0.02 2 force
particle minecraft:cloud -52.69 68.67 -55.42 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -52.69 68.47 -55.42 0.022 0.02 0.034 1 0 force
playsound driftgen:grain.onyx.046 neutral @a -55.02 68.75 -61.82 12 1
scoreboard players set #gx driftmountains -54283
scoreboard players set #gdx driftmountains 139
scoreboard players set #gy driftmountains 68519
scoreboard players set #gdy driftmountains -23
scoreboard players set #gz driftmountains -50451
scoreboard players set #gdz driftmountains -643
scoreboard players set #gr driftmountains 16046
scoreboard players set #gdr driftmountains 84
scoreboard players set #gp driftmountains 157
scoreboard players set #gdp driftmountains 25
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[0.0061f,-0.0001f,0.0192f,0.9998f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.8002f,0.1809f,0.1694f,-0.5461f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[-0.2277f,-0.5669f,0.7856f,-0.0978f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.9734f,0.0127f,0.0030f,0.2287f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0030f,0.2287f,0.9734f,0.0127f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3839f,0.8219f,0.0901f],left_rotation:[-0.1099f,-0.1416f,0.7767f,-0.6038f]}}
particle minecraft:cloud -54.65 68.84 -48.98 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud -53.07 68.84 -49.54 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -53.07 68.64 -49.54 0.008 0.02 0.022 1 0 force
playsound driftgen:grain.kaze.033 neutral @a -53.99 68.86 -55.72 12 1
