forceload add ~ ~
forceload add -201 -202 -74 -75
forceload add -201 -74 -74 53
forceload add -201 54 -74 165
forceload add -73 -202 54 -75
forceload add -73 -74 54 53
forceload add -73 54 54 165
forceload add 55 -202 182 -75
forceload add 55 -74 182 53
forceload add 55 54 182 165
forceload add 183 -202 207 -75
forceload add 183 -74 207 53
forceload add 183 54 207 165
tellraw @s {"text":"Building Drift Mountains v0 in this world, this takes about a minute …","color":"yellow"}
schedule function driftmountains:build/step0 100t
