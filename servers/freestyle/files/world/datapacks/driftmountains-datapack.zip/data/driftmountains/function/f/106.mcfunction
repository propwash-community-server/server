scoreboard players set #gx driftmountains -3085
scoreboard players set #gdx driftmountains 652
scoreboard players set #gy driftmountains 70483
scoreboard players set #gdy driftmountains 23
scoreboard players set #gz driftmountains -25483
scoreboard players set #gdz driftmountains 442
scoreboard players set #gr driftmountains -988
scoreboard players set #gdr driftmountains -78
scoreboard players set #gp driftmountains -141
scoreboard players set #gdp driftmountains 47
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.2499f,-0.3517f,-0.1578f,-0.8882f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.0653f,-0.8765f,0.2882f,0.3799f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.9999f,0.0131f,-0.0000f,-0.0003f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0000f,-0.0003f,0.9999f,0.0131f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3614f,0.8261f,0.0917f],left_rotation:[-0.1681f,-0.0699f,0.4050f,-0.8960f]}}
particle minecraft:cloud -2.48 70.80 -26.87 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -2.48 70.60 -26.87 -0.008 0.02 -0.046 1 0 force
particle minecraft:cloud -4.12 70.80 -26.58 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -6897
scoreboard players set #gdx driftmountains 681
scoreboard players set #gy driftmountains 70127
scoreboard players set #gdy driftmountains 75
scoreboard players set #gz driftmountains -28706
scoreboard players set #gdz driftmountains 335
scoreboard players set #gr driftmountains -1975
scoreboard players set #gdr driftmountains 379
scoreboard players set #gp driftmountains -384
scoreboard players set #gdp driftmountains -1
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[-0.0034f,-0.0001f,-0.0223f,0.9997f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.0233f,0.2848f,0.0477f,0.9571f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.0527f,0.9574f,-0.0065f,-0.2840f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.9999f,0.0131f,-0.0000f,-0.0003f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0000f,-0.0003f,0.9999f,0.0131f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3564f,0.8563f,0.2437f],left_rotation:[-0.1583f,0.0997f,-0.4890f,-0.8520f]}}
particle minecraft:cloud -6.55 70.45 -30.28 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -6.55 70.25 -30.28 -0.015 0.02 -0.042 1 0 force
particle minecraft:cloud -8.16 70.45 -29.70 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -11652
scoreboard players set #gdx driftmountains 820
scoreboard players set #gy driftmountains 69736
scoreboard players set #gdy driftmountains 60
scoreboard players set #gz driftmountains -29248
scoreboard players set #gdz driftmountains 114
scoreboard players set #gr driftmountains -3637
scoreboard players set #gdr driftmountains 187
scoreboard players set #gp driftmountains -285
scoreboard players set #gdp driftmountains -3
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.8662f,-0.0800f,-0.3554f,-0.3421f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.3214f,-0.3066f,0.8793f,0.1715f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.9999f,0.0131f,-0.0000f,-0.0003f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0000f,-0.0003f,0.9999f,0.0131f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3550f,0.8334f,0.0946f],left_rotation:[-0.1816f,-0.0329f,0.2096f,-0.9602f]}}
particle minecraft:cloud -11.73 70.06 -30.76 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -11.73 69.86 -30.76 -0.030 0.02 -0.040 1 0 force
particle minecraft:cloud -13.07 70.06 -29.77 0.35 0.18 0.35 0.02 3 force
