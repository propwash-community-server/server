scoreboard players set #gx driftmountains 12882
scoreboard players set #gdx driftmountains -916
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 60404
scoreboard players set #gdz driftmountains 531
scoreboard players set #gr driftmountains 11613
scoreboard players set #gdr driftmountains 356
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[0.0020f,0.0000f,-0.0223f,0.9997f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.0819f,0.4248f,0.0194f,0.9014f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.0752f,0.9043f,0.0377f,-0.4185f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.7640f,0.0100f,0.0084f,0.6451f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0084f,0.6451f,0.7640f,0.0100f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3796f,0.8211f,0.0898f],left_rotation:[-0.1228f,-0.1306f,0.7208f,-0.6694f]}}
particle minecraft:cloud 13.64 71.32 61.71 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 13.64 71.12 61.71 0.057 0.02 0.028 1 0 force
particle minecraft:cloud 14.38 71.32 60.21 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains 18382
scoreboard players set #gdx driftmountains -826
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 54211
scoreboard players set #gdz driftmountains 766
scoreboard players set #gr driftmountains 10536
scoreboard players set #gdr driftmountains 189
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.5864f,-0.3057f,-0.3487f,-0.6641f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.2808f,-0.6311f,0.6218f,0.3691f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.7640f,0.0100f,0.0084f,0.6451f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0084f,0.6451f,0.7640f,0.0100f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.4062f,0.8531f,0.2424f],left_rotation:[-0.0580f,-0.1779f,0.9208f,-0.3423f]}}
particle minecraft:cloud 19.47 71.32 55.40 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 19.47 71.12 55.40 0.063 0.02 0.017 1 0 force
particle minecraft:cloud 19.93 71.32 53.75 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains 23272
scoreboard players set #gdx driftmountains -577
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 50074
scoreboard players set #gdz driftmountains 931
scoreboard players set #gr driftmountains 8735
scoreboard players set #gdr driftmountains 206
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.7979f,0.2519f,-0.3611f,0.4118f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.4063f,0.4520f,0.7758f,-0.1694f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.7640f,0.0100f,0.0084f,0.6451f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0084f,0.6451f,0.7640f,0.0100f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3868f,0.8230f,0.0905f],left_rotation:[-0.0999f,-0.1489f,0.8139f,-0.5525f]}}
particle minecraft:cloud 24.57 71.32 50.85 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 24.57 71.12 50.85 0.066 0.02 -0.003 1 0 force
particle minecraft:cloud 24.49 71.32 49.18 0.35 0.18 0.35 0.02 3 force
