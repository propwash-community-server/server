scoreboard players set #gx driftmountains -53901
scoreboard players set #gdx driftmountains -52
scoreboard players set #gy driftmountains 68437
scoreboard players set #gdy driftmountains -22
scoreboard players set #gz driftmountains -52692
scoreboard players set #gdz driftmountains -691
scoreboard players set #gr driftmountains 14543
scoreboard players set #gdr driftmountains -297
scoreboard players set #gp driftmountains 166
scoreboard players set #gdp driftmountains -28
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[0.0008f,-0.0000f,0.0194f,0.9998f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.9001f,0.1250f,0.1556f,-0.3874f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[-0.1971f,-0.4059f,0.8919f,-0.0311f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.0628f,0.0008f,0.0131f,0.9979f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0131f,0.9979f,0.0628f,0.0008f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3998f,0.8359f,0.0956f],left_rotation:[-0.0305f,-0.1794f,0.9639f,-0.1940f]}}
particle minecraft:cloud -53.87 68.76 -51.18 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud -52.50 68.76 -52.13 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -52.50 68.56 -52.13 0.024 0.02 0.034 1 0 force
scoreboard players set #gx driftmountains -54851
scoreboard players set #gdx driftmountains 155
scoreboard players set #gy driftmountains 68593
scoreboard players set #gdy driftmountains -22
scoreboard players set #gz driftmountains -48032
scoreboard players set #gdz driftmountains -724
scoreboard players set #gr driftmountains 15810
scoreboard players set #gdr driftmountains -57
scoreboard players set #gp driftmountains 140
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[-0.0039f,0.0001f,0.0209f,0.9998f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.1822f,-0.2613f,0.1060f,0.9420f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[-0.0076f,0.9360f,0.2106f,0.2819f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.0628f,0.0008f,0.0131f,0.9979f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0131f,0.9979f,0.0628f,0.0008f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3909f,0.8290f,0.2330f],left_rotation:[-0.1477f,-0.1012f,0.5402f,-0.8223f]}}
particle minecraft:cloud -55.14 68.91 -46.45 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud -53.55 68.91 -47.08 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -53.55 68.71 -47.08 0.017 0.02 0.041 1 0 force
scoreboard players set #gx driftmountains -56416
scoreboard players set #gdx driftmountains 264
scoreboard players set #gy driftmountains 68774
scoreboard players set #gdy driftmountains -21
scoreboard players set #gz driftmountains -42108
scoreboard players set #gdz driftmountains -655
scoreboard players set #gr driftmountains 17037
scoreboard players set #gdr driftmountains -189
scoreboard players set #gp driftmountains 144
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.9602f,0.0900f,0.2067f,-0.1650f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[-0.2252f,-0.1877f,0.9560f,0.0105f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.0628f,0.0008f,0.0131f,0.9979f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0131f,0.9979f,0.0628f,0.0008f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3930f,0.8267f,0.0919f],left_rotation:[-0.0751f,-0.1635f,0.8871f,-0.4250f]}}
particle minecraft:cloud -57.03 69.09 -40.73 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud -55.38 69.09 -41.01 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -55.38 68.89 -41.01 0.007 0.02 0.041 1 0 force
