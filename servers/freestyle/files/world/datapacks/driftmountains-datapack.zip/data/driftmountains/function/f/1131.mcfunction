scoreboard players set #gx driftmountains -86405
scoreboard players set #gdx driftmountains -756
scoreboard players set #gy driftmountains 69989
scoreboard players set #gdy driftmountains -4
scoreboard players set #gz driftmountains 14220
scoreboard players set #gdz driftmountains -901
scoreboard players set #gr driftmountains 17628
scoreboard players set #gdr driftmountains 26
scoreboard players set #gp driftmountains 20
scoreboard players set #gdp driftmountains -8
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.8926f,-0.0536f,-0.3120f,-0.3210f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.2799f,-0.2900f,0.9032f,0.1477f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.6222f,0.0081f,-0.0102f,-0.7828f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0102f,-0.7828f,0.6222f,0.0081f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3549f,0.8540f,0.1027f],left_rotation:[-0.1828f,0.0525f,-0.2460f,-0.9504f]}}
particle minecraft:cloud -87.16 70.31 15.53 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -87.16 70.11 15.53 0.005 0.02 0.071 1 0 force
particle minecraft:cloud -85.49 70.31 15.42 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -79967
scoreboard players set #gdx driftmountains -854
scoreboard players set #gy driftmountains 70100
scoreboard players set #gdy driftmountains -20
scoreboard players set #gz driftmountains 21696
scoreboard players set #gdz driftmountains -940
scoreboard players set #gr driftmountains 17594
scoreboard players set #gdr driftmountains -212
scoreboard players set #gp driftmountains 72
scoreboard players set #gdp driftmountains -2
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.8421f,0.1957f,-0.2625f,0.4287f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.3090f,0.4586f,0.8261f,-0.1083f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.6222f,0.0081f,-0.0102f,-0.7828f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0102f,-0.7828f,0.6222f,0.0081f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3589f,0.8392f,0.2370f],left_rotation:[-0.1787f,0.0330f,-0.1439f,-0.9728f]}}
particle minecraft:cloud -80.72 70.42 23.12 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -80.72 70.22 23.12 0.005 0.02 0.077 1 0 force
particle minecraft:cloud -79.02 70.42 23.00 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -75676
scoreboard players set #gdx driftmountains -906
scoreboard players set #gy driftmountains 70205
scoreboard players set #gdy driftmountains -25
scoreboard players set #gz driftmountains 25936
scoreboard players set #gdz driftmountains -985
scoreboard players set #gr driftmountains 17655
scoreboard players set #gdr driftmountains 9
scoreboard players set #gp driftmountains 84
scoreboard players set #gdp driftmountains -3
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.2069f,-0.3128f,-0.1274f,-0.9182f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.0316f,-0.9099f,0.2409f,0.3363f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.6222f,0.0081f,-0.0102f,-0.7828f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0102f,-0.7828f,0.6222f,0.0081f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3523f,0.8449f,0.0991f],left_rotation:[-0.1873f,0.0151f,-0.0453f,-0.9811f]}}
particle minecraft:cloud -76.43 70.53 27.24 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -76.43 70.33 27.24 0.005 0.02 0.075 1 0 force
particle minecraft:cloud -74.77 70.53 27.14 0.35 0.18 0.35 0.02 3 force
