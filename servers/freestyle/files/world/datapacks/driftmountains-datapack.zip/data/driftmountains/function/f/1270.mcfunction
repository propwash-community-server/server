scoreboard players set #gx driftmountains -55294
scoreboard players set #gdx driftmountains -142
scoreboard players set #gy driftmountains 68269
scoreboard players set #gdy driftmountains -13
scoreboard players set #gz driftmountains -60559
scoreboard players set #gdz driftmountains -757
scoreboard players set #gr driftmountains 16986
scoreboard players set #gdr driftmountains 390
scoreboard players set #gp driftmountains 97
scoreboard players set #gdp driftmountains -1
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0000f,-0.0004f,1.0000f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.9951f,0.0518f,0.0081f,0.0838f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.0006f,0.0834f,0.9951f,0.0525f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.9559f,0.0125f,-0.0038f,-0.2933f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0038f,-0.2933f,0.9559f,0.0125f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3523f,0.8445f,0.0989f],left_rotation:[0.1873f,-0.0133f,0.0360f,0.9815f]}}
scoreboard players set #gx driftmountains -54000
scoreboard players set #gdx driftmountains -68
scoreboard players set #gy driftmountains 68383
scoreboard players set #gdy driftmountains -14
scoreboard players set #gz driftmountains -54773
scoreboard players set #gdz driftmountains -669
scoreboard players set #gr driftmountains 14392
scoreboard players set #gdr driftmountains 172
scoreboard players set #gp driftmountains 107
scoreboard players set #gdp driftmountains -1
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[-0.0039f,0.0001f,0.0187f,0.9998f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.6968f,-0.1018f,0.1793f,0.6870f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[-0.1081f,0.6720f,0.7113f,0.1756f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.9559f,0.0125f,-0.0038f,-0.2933f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0038f,-0.2933f,0.9559f,0.0125f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.4053f,0.8574f,0.2441f],left_rotation:[-0.0418f,-0.1838f,0.9485f,-0.2548f]}}
particle minecraft:cloud -53.89 68.70 -53.17 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud -52.51 68.70 -54.17 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -52.51 68.50 -54.17 0.024 0.02 0.033 1 0 force
scoreboard players set #gx driftmountains -54471
scoreboard players set #gdx driftmountains 110
scoreboard players set #gy driftmountains 68548
scoreboard players set #gdy driftmountains -16
scoreboard players set #gz driftmountains -49528
scoreboard players set #gdz driftmountains -550
scoreboard players set #gr driftmountains 15969
scoreboard players set #gdr driftmountains 20
scoreboard players set #gp driftmountains 140
scoreboard players set #gdp driftmountains 5
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.6501f,-0.1648f,0.2256f,0.7066f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[-0.1526f,0.6868f,0.6710f,0.2341f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.9559f,0.0125f,-0.0038f,-0.2933f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0038f,-0.2933f,0.9559f,0.0125f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3692f,0.8221f,0.0902f],left_rotation:[-0.1502f,-0.0998f,0.5611f,-0.8078f]}}
particle minecraft:cloud -54.82 68.87 -48.06 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud -53.25 68.87 -48.64 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -53.25 68.67 -48.64 0.015 0.02 0.041 1 0 force
