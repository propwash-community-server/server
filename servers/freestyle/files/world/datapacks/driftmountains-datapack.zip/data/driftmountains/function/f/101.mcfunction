scoreboard players set #gx driftmountains -6276
scoreboard players set #gdx driftmountains 647
scoreboard players set #gy driftmountains 70233
scoreboard players set #gdy driftmountains 68
scoreboard players set #gz driftmountains -27596
scoreboard players set #gdz driftmountains 382
scoreboard players set #gr driftmountains -1421
scoreboard players set #gdr driftmountains 287
scoreboard players set #gp driftmountains -382
scoreboard players set #gdp driftmountains 46
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.2115f,0.3204f,-0.0168f,0.9232f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.1139f,0.9301f,0.1790f,-0.3000f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.9690f,0.0127f,0.0032f,0.2466f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0032f,0.2466f,0.9690f,0.0127f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3541f,0.8522f,0.1020f],left_rotation:[-0.1844f,0.0450f,-0.2057f,-0.9600f]}}
particle minecraft:cloud -5.78 70.55 -29.02 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -5.78 70.35 -29.02 -0.011 0.02 -0.044 1 0 force
particle minecraft:cloud -7.40 70.55 -28.61 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -10526
scoreboard players set #gdx driftmountains 807
scoreboard players set #gy driftmountains 69812
scoreboard players set #gdy driftmountains 61
scoreboard players set #gz driftmountains -29674
scoreboard players set #gdz driftmountains 139
scoreboard players set #gr driftmountains -3450
scoreboard players set #gdr driftmountains 205
scoreboard players set #gp driftmountains -286
scoreboard players set #gdp driftmountains -5
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.5493f,0.3097f,-0.1550f,0.7605f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.2357f,0.7810f,0.5197f,-0.2537f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.9690f,0.0127f,0.0032f,0.2466f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0032f,0.2466f,0.9690f,0.0127f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3649f,0.8325f,0.2344f],left_rotation:[-0.1796f,-0.0023f,0.0371f,-0.9831f]}}
particle minecraft:cloud -10.59 70.13 -31.28 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -10.59 69.93 -31.28 -0.022 0.02 -0.033 1 0 force
particle minecraft:cloud -12.00 70.13 -30.31 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -15881
scoreboard players set #gdx driftmountains 857
scoreboard players set #gy driftmountains 69439
scoreboard players set #gdy driftmountains 58
scoreboard players set #gz driftmountains -29595
scoreboard players set #gdz driftmountains 43
scoreboard players set #gr driftmountains -4444
scoreboard players set #gdr driftmountains 134
scoreboard players set #gp driftmountains -283
scoreboard players set #gdp driftmountains 1
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.9035f,-0.0374f,-0.3481f,-0.2472f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.3241f,-0.2120f,0.9124f,0.1326f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.9690f,0.0127f,0.0032f,0.2466f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0032f,0.2466f,0.9690f,0.0127f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3528f,0.8394f,0.0970f],left_rotation:[-0.1862f,-0.0073f,0.0739f,-0.9796f]}}
particle minecraft:cloud -16.17 69.76 -31.08 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -16.17 69.56 -31.08 -0.036 0.02 -0.036 1 0 force
particle minecraft:cloud -17.36 69.76 -29.91 0.35 0.18 0.35 0.02 3 force
