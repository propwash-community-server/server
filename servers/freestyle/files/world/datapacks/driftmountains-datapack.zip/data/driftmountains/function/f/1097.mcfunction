scoreboard players set #gx driftmountains -53463
scoreboard players set #gdx driftmountains -1203
scoreboard players set #gy driftmountains 70489
scoreboard players set #gdy driftmountains 7
scoreboard players set #gz driftmountains 45399
scoreboard players set #gdz driftmountains -601
scoreboard players set #gr driftmountains 16309
scoreboard players set #gdr driftmountains 172
scoreboard players set #gp driftmountains -21
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.9085f,0.1219f,-0.3663f,0.1596f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.3851f,0.1990f,0.9007f,-0.0271f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.8966f,0.0117f,-0.0058f,-0.4427f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0058f,-0.4427f,0.8966f,0.0117f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3616f,0.8259f,0.0916f],left_rotation:[-0.1676f,-0.0709f,0.4101f,-0.8937f]}}
particle minecraft:cloud -53.90 70.81 46.85 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -53.90 70.61 46.85 0.023 0.02 0.077 1 0 force
particle minecraft:cloud -52.30 70.81 46.36 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -43307
scoreboard players set #gdx driftmountains -1232
scoreboard players set #gy driftmountains 70489
scoreboard players set #gdy driftmountains -11
scoreboard players set #gz driftmountains 49644
scoreboard players set #gdz driftmountains -509
scoreboard players set #gr driftmountains 15552
scoreboard players set #gdr driftmountains 22
scoreboard players set #gp driftmountains 43
scoreboard players set #gdp driftmountains -16
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.5093f,0.3321f,-0.1499f,0.7796f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.2327f,0.7997f,0.4772f,-0.2804f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.8966f,0.0117f,-0.0058f,-0.4427f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0058f,-0.4427f,0.8966f,0.0117f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3727f,0.8285f,0.2328f],left_rotation:[-0.1748f,-0.0360f,0.2094f,-0.9614f]}}
particle minecraft:cloud -43.52 70.81 51.24 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -43.52 70.61 51.24 0.032 0.02 0.071 1 0 force
particle minecraft:cloud -41.96 70.81 50.53 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -38680
scoreboard players set #gdx driftmountains -1231
scoreboard players set #gy driftmountains 70587
scoreboard players set #gdy driftmountains -33
scoreboard players set #gz driftmountains 51919
scoreboard players set #gdz driftmountains -440
scoreboard players set #gr driftmountains 15399
scoreboard players set #gdr driftmountains 13
scoreboard players set #gp driftmountains 110
scoreboard players set #gdp driftmountains -14
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.6275f,-0.2338f,-0.2912f,-0.6832f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.2210f,-0.6564f,0.6555f,0.3010f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.8966f,0.0117f,-0.0058f,-0.4427f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0058f,-0.4427f,0.8966f,0.0117f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3573f,0.8300f,0.0932f],left_rotation:[-0.1767f,-0.0491f,0.2952f,-0.9376f]}}
particle minecraft:cloud -38.88 70.91 53.42 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -38.88 70.71 53.42 0.034 0.02 0.070 1 0 force
particle minecraft:cloud -37.38 70.91 52.69 0.35 0.18 0.35 0.02 3 force
