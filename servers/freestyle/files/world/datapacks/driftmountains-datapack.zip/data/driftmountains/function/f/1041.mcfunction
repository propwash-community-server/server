scoreboard players set #gx driftmountains 7988
scoreboard players set #gdx driftmountains -1058
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 62534
scoreboard players set #gdz driftmountains 269
scoreboard players set #gr driftmountains 13305
scoreboard players set #gdr driftmountains 316
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.3110f,0.4275f,-0.0957f,0.8434f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.1849f,0.8581f,0.2678f,-0.3972f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.8996f,0.0118f,0.0057f,0.4365f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0057f,0.4365f,0.8996f,0.0118f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3858f,0.8226f,0.0903f],left_rotation:[-0.1033f,-0.1465f,0.8017f,-0.5702f]}}
particle minecraft:cloud 8.34 71.32 64.00 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 8.34 71.12 64.00 0.048 0.02 0.045 1 0 force
particle minecraft:cloud 9.48 71.32 62.78 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains 14362
scoreboard players set #gdx driftmountains -809
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 57527
scoreboard players set #gdz driftmountains 539
scoreboard players set #gr driftmountains 11567
scoreboard players set #gdr driftmountains 246
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.3962f,-0.3806f,-0.2552f,-0.7957f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.1730f,-0.7732f,0.4383f,0.4243f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.8996f,0.0118f,0.0057f,0.4365f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0057f,0.4365f,0.8996f,0.0118f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.4063f,0.8504f,0.2414f],left_rotation:[-0.0676f,-0.1736f,0.8999f,-0.3943f]}}
particle minecraft:cloud 15.22 71.32 58.89 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 15.22 71.12 58.89 0.053 0.02 0.026 1 0 force
particle minecraft:cloud 15.96 71.32 57.35 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains 20084
scoreboard players set #gdx driftmountains -740
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 54527
scoreboard players set #gdz driftmountains 841
scoreboard players set #gr driftmountains 9789
scoreboard players set #gdr driftmountains 234
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.8734f,0.1516f,-0.4220f,0.1899f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.4443f,0.2353f,0.8623f,-0.0606f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.8996f,0.0118f,0.0057f,0.4365f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0057f,0.4365f,0.8996f,0.0118f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3904f,0.8248f,0.0912f],left_rotation:[-0.0863f,-0.1574f,0.8570f,-0.4829f]}}
particle minecraft:cloud 21.22 71.32 55.53 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 21.22 71.12 55.53 0.066 0.02 0.009 1 0 force
particle minecraft:cloud 21.45 71.32 53.87 0.35 0.18 0.35 0.02 3 force
