scoreboard players set #gx driftmountains -54006
scoreboard players set #gdx driftmountains 70
scoreboard players set #gy driftmountains 68517
scoreboard players set #gdy driftmountains -27
scoreboard players set #gz driftmountains -50541
scoreboard players set #gdz driftmountains -730
scoreboard players set #gr driftmountains 15321
scoreboard players set #gdr driftmountains 13
scoreboard players set #gp driftmountains 156
scoreboard players set #gdp driftmountains 37
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.9131f,0.1300f,0.2015f,-0.3297f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[-0.2373f,-0.3527f,0.9045f,-0.0347f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.6557f,0.0086f,-0.0099f,-0.7549f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0099f,-0.7549f,0.6557f,0.0086f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3874f,0.8232f,0.0906f],left_rotation:[-0.0979f,-0.1502f,0.8206f,-0.5425f]}}
particle minecraft:cloud -54.18 68.84 -49.04 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud -52.69 68.84 -49.79 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -52.69 68.64 -49.79 0.020 0.02 0.040 1 0 force
scoreboard players set #gx driftmountains -55361
scoreboard players set #gdx driftmountains 178
scoreboard players set #gy driftmountains 68657
scoreboard players set #gdy driftmountains -21
scoreboard players set #gz driftmountains -45918
scoreboard players set #gdz driftmountains -688
scoreboard players set #gr driftmountains 16147
scoreboard players set #gdr driftmountains -137
scoreboard players set #gp driftmountains 141
scoreboard players set #gdp driftmountains -1
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.0500f,-0.2435f,0.0667f,0.9663f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.0345f,0.9646f,0.0759f,0.2501f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.6557f,0.0086f,-0.0099f,-0.7549f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0099f,-0.7549f,0.6557f,0.0086f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.4018f,0.8374f,0.2363f],left_rotation:[-0.1129f,-0.1428f,0.7482f,-0.6381f]}}
particle minecraft:cloud -55.74 68.98 -44.35 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud -54.12 68.98 -44.90 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -54.12 68.78 -44.90 0.013 0.02 0.040 1 0 force
scoreboard players set #gx driftmountains -57311
scoreboard players set #gdx driftmountains 333
scoreboard players set #gy driftmountains 68836
scoreboard players set #gdy driftmountains -22
scoreboard players set #gz driftmountains -40274
scoreboard players set #gdz driftmountains -628
scoreboard players set #gr driftmountains 17605
scoreboard players set #gdr driftmountains -198
scoreboard players set #gp driftmountains 146
scoreboard players set #gdp driftmountains -1
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,0.0001f,0.0201f,0.9998f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.9474f,0.1034f,0.2040f,-0.2240f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[-0.2287f,-0.2466f,0.9417f,-0.0044f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.6557f,0.0086f,-0.0099f,-0.7549f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0099f,-0.7549f,0.6557f,0.0086f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3918f,0.8257f,0.0916f],left_rotation:[-0.0804f,-0.1607f,0.8735f,-0.4523f]}}
particle minecraft:cloud -58.06 69.16 -38.96 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud -56.39 69.16 -39.07 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -56.39 68.96 -39.07 0.003 0.02 0.040 1 0 force
