scoreboard players set #gx driftmountains -15561
scoreboard players set #gdx driftmountains 741
scoreboard players set #gy driftmountains 67077
scoreboard players set #gdy driftmountains -10
scoreboard players set #gz driftmountains -81582
scoreboard players set #gdz driftmountains 466
scoreboard players set #gr driftmountains -3361
scoreboard players set #gdr driftmountains -85
scoreboard players set #gp driftmountains 62
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0001f,-0.0148f,0.9999f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.9253f,-0.0156f,-0.2127f,-0.3136f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.1809f,-0.2930f,0.9320f,0.1129f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.4355f,0.0057f,-0.0118f,-0.9001f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0118f,-0.9001f,0.4355f,0.0057f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3958f,0.8582f,0.1043f],left_rotation:[-0.0651f,0.1768f,-0.9321f,-0.3091f]}}
particle minecraft:cloud -15.56 67.40 -83.09 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -15.56 67.20 -83.09 -0.029 0.02 -0.044 1 0 force
particle minecraft:cloud -16.95 67.40 -82.17 0.35 0.18 0.35 0.02 2 force
scoreboard players set #gx driftmountains -22054
scoreboard players set #gdx driftmountains 662
scoreboard players set #gy driftmountains 67169
scoreboard players set #gdy driftmountains -10
scoreboard players set #gz driftmountains -85150
scoreboard players set #gdz driftmountains 397
scoreboard players set #gr driftmountains -3094
scoreboard players set #gdr driftmountains 19
scoreboard players set #gp driftmountains 66
scoreboard players set #gdp driftmountains -1
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.9486f,0.1023f,-0.2167f,0.2068f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.2397f,0.2307f,0.9430f,-0.0032f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.4355f,0.0057f,-0.0118f,-0.9001f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0118f,-0.9001f,0.4355f,0.0057f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3714f,0.8726f,0.2501f],left_rotation:[-0.1020f,0.1633f,-0.8228f,-0.5348f]}}
particle minecraft:cloud -22.02 67.49 -86.76 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -22.02 67.29 -86.76 -0.026 0.02 -0.043 1 0 force
particle minecraft:cloud -23.49 67.49 -85.88 0.35 0.18 0.35 0.02 2 force
scoreboard players set #gx driftmountains -29034
scoreboard players set #gdx driftmountains 599
scoreboard players set #gy driftmountains 67284
scoreboard players set #gdy driftmountains -10
scoreboard players set #gz driftmountains -89588
scoreboard players set #gdz driftmountains 288
scoreboard players set #gr driftmountains -3480
scoreboard players set #gdr driftmountains 34
scoreboard players set #gp driftmountains 75
scoreboard players set #gdp driftmountains -1
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0001f,-0.0182f,0.9998f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[-0.0091f,-0.2353f,-0.0517f,-0.9705f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[-0.0501f,-0.9704f,0.0156f,0.2357f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.4355f,0.0057f,-0.0118f,-0.9001f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0118f,-0.9001f,0.4355f,0.0057f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3853f,0.8652f,0.1070f],left_rotation:[-0.1090f,0.1569f,-0.8176f,-0.5431f]}}
particle minecraft:cloud -29.07 67.60 -91.10 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -29.07 67.40 -91.10 -0.025 0.02 -0.036 1 0 force
particle minecraft:cloud -30.44 67.60 -90.15 0.35 0.18 0.35 0.02 2 force
