scoreboard players set #gx driftmountains -54082
scoreboard players set #gdx driftmountains 75
scoreboard players set #gy driftmountains 68539
scoreboard players set #gdy driftmountains -22
scoreboard players set #gz driftmountains -49798
scoreboard players set #gdz driftmountains -743
scoreboard players set #gr driftmountains 15373
scoreboard players set #gdr driftmountains -52
scoreboard players set #gp driftmountains 138
scoreboard players set #gdp driftmountains 18
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[0.0061f,-0.0001f,0.0197f,0.9998f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.6961f,-0.1390f,0.2230f,0.6681f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[-0.1540f,0.6484f,0.7145f,0.2129f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.8999f,0.0118f,0.0057f,0.4358f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0057f,0.4358f,0.8999f,0.0118f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3769f,0.8210f,0.0897f],left_rotation:[-0.1304f,-0.1232f,0.6827f,-0.7082f]}}
particle minecraft:cloud -54.27 68.86 -48.30 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud -52.78 68.86 -49.04 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -52.78 68.66 -49.04 0.020 0.02 0.040 1 0 force
scoreboard players set #gx driftmountains -55549
scoreboard players set #gdx driftmountains 187
scoreboard players set #gy driftmountains 68677
scoreboard players set #gdy driftmountains -21
scoreboard players set #gz driftmountains -45248
scoreboard players set #gdz driftmountains -670
scoreboard players set #gr driftmountains 16230
scoreboard players set #gdr driftmountains -83
scoreboard players set #gp driftmountains 142
scoreboard players set #gdp driftmountains -1
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[-0.0039f,0.0001f,0.0206f,0.9998f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.8146f,0.1756f,0.1729f,-0.5250f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[-0.2291f,-0.5461f,0.8006f,-0.0910f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.8999f,0.0118f,0.0057f,0.4358f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0057f,0.4358f,0.8999f,0.0118f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.4034f,0.8397f,0.2372f],left_rotation:[-0.1046f,-0.1499f,0.7836f,-0.5938f]}}
particle minecraft:cloud -55.95 69.00 -43.69 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud -54.32 69.00 -44.21 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -54.32 68.80 -44.21 0.013 0.02 0.040 1 0 force
scoreboard players set #gx driftmountains -57647
scoreboard players set #gdx driftmountains 337
scoreboard players set #gy driftmountains 68856
scoreboard players set #gdy driftmountains -21
scoreboard players set #gz driftmountains -39692
scoreboard players set #gdz driftmountains -582
scoreboard players set #gr driftmountains 17807
scoreboard players set #gdr driftmountains -201
scoreboard players set #gp driftmountains 147
scoreboard players set #gdp driftmountains -1
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,0.0001f,0.0203f,0.9998f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.6892f,-0.1243f,0.2014f,0.6849f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[-0.1305f,0.6675f,0.7060f,0.1974f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.8999f,0.0118f,0.0057f,0.4358f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0057f,0.4358f,0.8999f,0.0118f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3887f,0.8238f,0.0908f],left_rotation:[-0.0930f,-0.1534f,0.8368f,-0.5172f]}}
particle minecraft:cloud -58.44 69.18 -38.40 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud -56.77 69.18 -38.46 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -56.77 68.98 -38.46 0.001 0.02 0.040 1 0 force
