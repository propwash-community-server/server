scoreboard players set #gx driftmountains 206
scoreboard players set #gdx driftmountains 649
scoreboard players set #gy driftmountains 70506
scoreboard players set #gdy driftmountains -15
scoreboard players set #gz driftmountains -23191
scoreboard players set #gdz driftmountains 507
scoreboard players set #gr driftmountains -695
scoreboard players set #gdr driftmountains 193
scoreboard players set #gp driftmountains 61
scoreboard players set #gdp driftmountains 9
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.4556f,-0.2763f,-0.2178f,-0.8177f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.1331f,-0.7993f,0.4871f,0.3257f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.9688f,0.0127f,-0.0032f,-0.2473f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0032f,-0.2473f,0.9688f,0.0127f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3529f,0.8387f,0.0967f],left_rotation:[-0.1859f,-0.0103f,0.0898f,-0.9784f]}}
particle minecraft:cloud 0.88 70.83 -24.54 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 0.88 70.63 -24.54 -0.006 0.02 -0.049 1 0 force
particle minecraft:cloud -0.78 70.83 -24.34 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -3650
scoreboard players set #gdx driftmountains 611
scoreboard players set #gy driftmountains 70432
scoreboard players set #gdy driftmountains 35
scoreboard players set #gz driftmountains -26698
scoreboard players set #gdz driftmountains 445
scoreboard players set #gr driftmountains -923
scoreboard players set #gdr driftmountains -6
scoreboard players set #gp driftmountains -212
scoreboard players set #gdp driftmountains 43
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.5685f,-0.2552f,-0.2687f,-0.7345f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.1929f,-0.7103f,0.5985f,0.3163f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.9688f,0.0127f,-0.0032f,-0.2473f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0032f,-0.2473f,0.9688f,0.0127f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3756f,0.8277f,0.2325f],left_rotation:[-0.1719f,-0.0474f,0.2677f,-0.9469f]}}
particle minecraft:cloud -3.03 70.75 -28.18 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -3.03 70.55 -28.18 -0.007 0.02 -0.044 1 0 force
particle minecraft:cloud -4.71 70.75 -27.91 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -7877
scoreboard players set #gdx driftmountains 760
scoreboard players set #gy driftmountains 70046
scoreboard players set #gdy driftmountains 82
scoreboard players set #gz driftmountains -28478
scoreboard players set #gdz driftmountains 287
scoreboard players set #gr driftmountains -2477
scoreboard players set #gdr driftmountains 437
scoreboard players set #gp driftmountains -386
scoreboard players set #gdp driftmountains -20
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[0.0036f,0.0001f,-0.0223f,0.9997f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.9520f,0.0503f,-0.3016f,-0.0145f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.3017f,0.0171f,0.9520f,0.0495f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.9688f,0.0127f,-0.0032f,-0.2473f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0032f,-0.2473f,0.9688f,0.0127f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3577f,0.8580f,0.1042f],left_rotation:[-0.1775f,0.0707f,-0.3441f,-0.9192f]}}
particle minecraft:cloud -7.65 70.37 -29.97 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -7.65 70.17 -29.97 -0.019 0.02 -0.041 1 0 force
particle minecraft:cloud -9.16 70.37 -29.27 0.35 0.18 0.35 0.02 3 force
