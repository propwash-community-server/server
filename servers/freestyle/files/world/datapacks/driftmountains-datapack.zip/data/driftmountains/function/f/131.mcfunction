scoreboard players set #gx driftmountains 10293
scoreboard players set #gdx driftmountains 462
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains -8632
scoreboard players set #gdz driftmountains 852
scoreboard players set #gr driftmountains 975
scoreboard players set #gdr driftmountains 33
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.2820f,0.3216f,-0.0426f,0.9029f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.1377f,0.9123f,0.2497f,-0.2938f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.3169f,0.0041f,-0.0124f,-0.9484f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0124f,-0.9484f,0.3169f,0.0041f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3535f,0.8508f,0.1014f],left_rotation:[-0.1854f,0.0388f,-0.1722f,-0.9666f]}}
particle minecraft:cloud 11.33 71.32 -9.73 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 11.33 71.12 -9.73 0.010 0.02 -0.057 1 0 force
particle minecraft:cloud 9.68 71.32 -10.02 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains 7241
scoreboard players set #gdx driftmountains 435
scoreboard players set #gy driftmountains 70989
scoreboard players set #gdy driftmountains 11
scoreboard players set #gz driftmountains -14128
scoreboard players set #gdz driftmountains 817
scoreboard players set #gr driftmountains 1164
scoreboard players set #gdr driftmountains -76
scoreboard players set #gp driftmountains -89
scoreboard players set #gdp driftmountains 89
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.3801f,-0.2868f,-0.1877f,-0.8591f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.0985f,-0.8441f,0.4124f,0.3283f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.3169f,0.0041f,-0.0124f,-0.9484f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0124f,-0.9484f,0.3169f,0.0041f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3636f,0.8336f,0.2348f],left_rotation:[-0.1799f,0.0044f,0.0031f,-0.9837f]}}
particle minecraft:cloud 8.35 71.31 -15.29 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 8.35 71.11 -15.29 0.011 0.02 -0.054 1 0 force
particle minecraft:cloud 6.68 71.31 -15.64 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains 4561
scoreboard players set #gdx driftmountains 513
scoreboard players set #gy driftmountains 70695
scoreboard players set #gdy driftmountains 73
scoreboard players set #gz driftmountains -18739
scoreboard players set #gdz driftmountains 827
scoreboard players set #gr driftmountains 1136
scoreboard players set #gdr driftmountains 117
scoreboard players set #gp driftmountains -309
scoreboard players set #gdp driftmountains 3
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.4992f,0.3102f,-0.1284f,0.7988f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.2131f,0.8167f,0.4693f,-0.2595f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.3169f,0.0041f,-0.0124f,-0.9484f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0124f,-0.9484f,0.3169f,0.0041f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3524f,0.8458f,0.0995f],left_rotation:[-0.1872f,0.0187f,-0.0645f,-0.9800f]}}
particle minecraft:cloud 5.63 71.01 -19.81 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 5.63 70.81 -19.81 0.010 0.02 -0.050 1 0 force
particle minecraft:cloud 3.99 71.01 -20.14 0.35 0.18 0.35 0.02 3 force
