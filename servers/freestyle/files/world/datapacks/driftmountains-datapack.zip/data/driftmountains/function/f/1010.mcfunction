scoreboard players set #gx driftmountains 27354
scoreboard players set #gdx driftmountains -153
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 37364
scoreboard players set #gdz driftmountains 984
scoreboard players set #gr driftmountains 6314
scoreboard players set #gdr driftmountains 283
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0001f,-0.0223f,0.9997f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.5242f,0.3677f,-0.1886f,0.7447f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.2679f,0.7686f,0.4884f,-0.3146f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.9934f,0.0130f,0.0015f,0.1139f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0015f,0.1139f,0.9934f,0.0130f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3737f,0.8212f,0.0898f],left_rotation:[-0.1390f,-0.1139f,0.6346f,-0.7516f]}}
particle minecraft:cloud 28.85 71.32 37.54 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 28.85 71.12 37.54 0.053 0.02 -0.027 1 0 force
particle minecraft:cloud 28.10 71.32 36.05 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains 27861
scoreboard players set #gdx driftmountains 224
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 29607
scoreboard players set #gdz driftmountains 1051
scoreboard players set #gr driftmountains 4628
scoreboard players set #gdr driftmountains 338
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.1776f,-0.4287f,-0.1470f,-0.8735f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.0560f,-0.8629f,0.2236f,0.4497f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.9934f,0.0130f,0.0015f,0.1139f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0015f,0.1139f,0.9934f,0.0130f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.4061f,0.8480f,0.2404f],left_rotation:[-0.0761f,-0.1692f,0.8785f,-0.4403f]}}
particle minecraft:cloud 29.44 71.32 29.28 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 29.44 71.12 29.28 0.043 0.02 -0.041 1 0 force
particle minecraft:cloud 28.26 71.32 28.05 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains 24557
scoreboard players set #gdx driftmountains 362
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 25489
scoreboard players set #gdz driftmountains 1047
scoreboard players set #gr driftmountains 2439
scoreboard players set #gdr driftmountains 62
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.9222f,0.0401f,-0.3826f,-0.0399f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.3806f,0.0001f,0.9230f,0.0566f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.9934f,0.0130f,0.0015f,0.1139f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0015f,0.1139f,0.9934f,0.0130f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3611f,0.8263f,0.0918f],left_rotation:[-0.1687f,-0.0686f,0.3981f,-0.8990f]}}
particle minecraft:cloud 25.84 71.32 24.69 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 25.84 71.12 24.69 0.024 0.02 -0.054 1 0 force
particle minecraft:cloud 24.32 71.32 24.00 0.35 0.18 0.35 0.02 3 force
