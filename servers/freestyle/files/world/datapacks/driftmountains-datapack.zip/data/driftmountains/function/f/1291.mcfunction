scoreboard players set #gx driftmountains -55816
scoreboard players set #gdx driftmountains 228
scoreboard players set #gy driftmountains 67973
scoreboard players set #gdy driftmountains -14
scoreboard players set #gz driftmountains -74576
scoreboard players set #gdz driftmountains -581
scoreboard players set #gr driftmountains -12570
scoreboard players set #gdr driftmountains 87
scoreboard players set #gp driftmountains 110
scoreboard players set #gdp driftmountains -5
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0001f,-0.0205f,0.9998f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.6479f,0.2076f,-0.1136f,0.7241f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.1903f,0.7400f,0.6296f,-0.1406f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.8582f,0.0112f,0.0067f,0.5132f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0067f,0.5132f,0.8582f,0.0112f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3871f,0.8644f,0.1068f],left_rotation:[-0.1026f,0.1608f,-0.8394f,-0.5089f]}}
particle minecraft:cloud -57.33 68.29 -74.52 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -57.33 68.09 -74.52 -0.030 0.02 0.022 1 0 force
particle minecraft:cloud -56.35 68.29 -73.16 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -55965
scoreboard players set #gdx driftmountains -27
scoreboard players set #gy driftmountains 68106
scoreboard players set #gdy driftmountains -13
scoreboard players set #gz driftmountains -69938
scoreboard players set #gdz driftmountains -589
scoreboard players set #gr driftmountains -14790
scoreboard players set #gdr driftmountains 180
scoreboard players set #gp driftmountains 101
scoreboard players set #gdp driftmountains 7
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[0.0061f,0.0001f,-0.0215f,0.9998f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.9412f,-0.0050f,-0.2360f,-0.2415f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.2119f,-0.2181f,0.9470f,0.1040f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.8582f,0.0112f,0.0067f,0.5132f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0067f,0.5132f,0.8582f,0.0112f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3730f,0.8731f,0.2503f],left_rotation:[-0.0968f,0.1666f,-0.8408f,-0.5059f]}}
particle minecraft:cloud -57.41 68.43 -69.24 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -57.41 68.23 -69.24 -0.016 0.02 0.026 1 0 force
particle minecraft:cloud -55.97 68.43 -68.33 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -54922
scoreboard players set #gdx driftmountains -74
scoreboard players set #gy driftmountains 68228
scoreboard players set #gdy driftmountains -12
scoreboard players set #gz driftmountains -63492
scoreboard players set #gdz driftmountains -726
scoreboard players set #gr driftmountains -17342
scoreboard players set #gdr driftmountains 367
scoreboard players set #gp driftmountains 91
scoreboard players set #gdp driftmountains -1
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[0.0060f,0.0000f,-0.0077f,1.0000f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.1381f,-0.0920f,-0.0660f,-0.9839f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[-0.0370f,-0.9824f,0.1485f,0.1070f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.8582f,0.0112f,0.0067f,0.5132f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0067f,0.5132f,0.8582f,0.0112f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3839f,0.8220f,0.0901f],left_rotation:[0.1096f,0.1418f,-0.7778f,0.6023f]}}
particle minecraft:cloud -55.90 68.55 -62.34 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -55.90 68.35 -62.34 -0.005 0.02 0.045 1 0 force
particle minecraft:cloud -54.24 68.55 -62.14 0.35 0.18 0.35 0.02 2 force
