scoreboard players set #gx driftmountains -67855
scoreboard players set #gdx driftmountains -986
scoreboard players set #gy driftmountains 70424
scoreboard players set #gdy driftmountains -23
scoreboard players set #gz driftmountains 35017
scoreboard players set #gdz driftmountains -1002
scoreboard players set #gr driftmountains -17954
scoreboard players set #gdr driftmountains -41
scoreboard players set #gp driftmountains 64
scoreboard players set #gdp driftmountains 5
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.3912f,-0.3148f,-0.2091f,-0.8391f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.1220f,-0.8218f,0.4265f,0.3577f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.1643f,0.0022f,0.0129f,0.9863f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0129f,0.9863f,0.1643f,0.0022f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3587f,0.8284f,0.0926f],left_rotation:[-0.1738f,-0.0568f,0.3361f,-0.9238f]}}
particle minecraft:cloud -68.70 70.74 36.27 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -68.70 70.54 36.27 -0.001 0.02 0.084 1 0 force
particle minecraft:cloud -67.03 70.74 36.28 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -59304
scoreboard players set #gdx driftmountains -1124
scoreboard players set #gy driftmountains 70516
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 41588
scoreboard players set #gdz driftmountains -780
scoreboard players set #gr driftmountains 17212
scoreboard players set #gdr driftmountains 152
scoreboard players set #gp driftmountains -4
scoreboard players set #gdp driftmountains 8
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.8761f,-0.0657f,-0.3805f,-0.2887f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.3522f,-0.2503f,0.8878f,0.1582f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.1643f,0.0022f,0.0129f,0.9863f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0129f,0.9863f,0.1643f,0.0022f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3834f,0.8273f,0.2323f],left_rotation:[-0.1616f,-0.0755f,0.4100f,-0.8945f]}}
particle minecraft:cloud -59.96 70.84 43.06 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -59.96 70.64 43.06 0.012 0.02 0.083 1 0 force
particle minecraft:cloud -58.27 70.84 42.82 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -54938
scoreboard players set #gdx driftmountains -1214
scoreboard players set #gy driftmountains 70497
scoreboard players set #gdy driftmountains 7
scoreboard players set #gz driftmountains 44780
scoreboard players set #gdz driftmountains -707
scoreboard players set #gr driftmountains 16643
scoreboard players set #gdr driftmountains 199
scoreboard players set #gp driftmountains -20
scoreboard players set #gdp driftmountains 2
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[0.0061f,0.0001f,-0.0223f,0.9997f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.4963f,0.3484f,-0.1546f,0.7800f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.2375f,0.8006f,0.4624f,-0.2981f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.1643f,0.0022f,0.0129f,0.9863f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0129f,0.9863f,0.1643f,0.0022f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3598f,0.8274f,0.0922f],left_rotation:[-0.1715f,-0.0625f,0.3658f,-0.9126f]}}
particle minecraft:cloud -55.45 70.82 46.20 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -55.45 70.62 46.20 0.020 0.02 0.083 1 0 force
particle minecraft:cloud -53.83 70.82 45.81 0.35 0.18 0.35 0.02 3 force
