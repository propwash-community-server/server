scoreboard players set #gx driftmountains -6322
scoreboard players set #gdx driftmountains 804
scoreboard players set #gy driftmountains 66952
scoreboard players set #gdy driftmountains -11
scoreboard players set #gz driftmountains -75643
scoreboard players set #gdz driftmountains 530
scoreboard players set #gr driftmountains -4656
scoreboard players set #gdr driftmountains -81
scoreboard players set #gp driftmountains 62
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0000f,-0.0062f,1.0000f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.9444f,0.0229f,-0.0979f,-0.3132f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.0655f,-0.3046f,0.9472f,0.0762f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.4617f,0.0060f,-0.0116f,-0.8869f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0116f,-0.8869f,0.4617f,0.0060f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3775f,0.8210f,0.0897f],left_rotation:[0.1288f,0.1249f,-0.6911f,0.7001f]}}
particle minecraft:cloud -6.66 67.27 -77.12 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -6.66 67.07 -77.12 -0.042 0.02 -0.040 1 0 force
particle minecraft:cloud -7.81 67.27 -75.90 0.35 0.18 0.35 0.02 2 force
scoreboard players set #gx driftmountains -13177
scoreboard players set #gdx driftmountains 789
scoreboard players set #gy driftmountains 67041
scoreboard players set #gdy driftmountains -11
scoreboard players set #gz driftmountains -79632
scoreboard players set #gdz driftmountains 497
scoreboard players set #gr driftmountains -3742
scoreboard players set #gdr driftmountains -126
scoreboard players set #gp driftmountains 62
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0000f,-0.0124f,0.9999f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.9176f,0.1127f,-0.1451f,0.3524f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.1830f,0.3696f,0.9109f,-0.0169f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.4617f,0.0060f,-0.0116f,-0.8869f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0116f,-0.8869f,0.4617f,0.0060f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3970f,0.8690f,0.2487f],left_rotation:[-0.0117f,0.1916f,-0.9808f,-0.0366f]}}
particle minecraft:cloud -13.33 67.36 -81.24 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -13.33 67.16 -81.24 -0.034 0.02 -0.044 1 0 force
particle minecraft:cloud -14.69 67.36 -80.20 0.35 0.18 0.35 0.02 2 force
scoreboard players set #gx driftmountains -20723
scoreboard players set #gdx driftmountains 759
scoreboard players set #gy driftmountains 67154
scoreboard players set #gdy driftmountains -11
scoreboard players set #gz driftmountains -85023
scoreboard players set #gdz driftmountains 472
scoreboard players set #gr driftmountains -2994
scoreboard players set #gdr driftmountains 21
scoreboard players set #gp driftmountains 64
scoreboard players set #gdp driftmountains -1
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0001f,-0.0173f,0.9998f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.9251f,-0.0197f,-0.2400f,-0.2937f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.2105f,-0.2700f,0.9322f,0.1170f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.4617f,0.0060f,-0.0116f,-0.8869f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0116f,-0.8869f,0.4617f,0.0060f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3853f,0.8651f,0.1070f],left_rotation:[-0.1089f,0.1570f,-0.8179f,-0.5426f]}}
particle minecraft:cloud -20.63 67.47 -86.53 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -20.63 67.27 -86.53 -0.026 0.02 -0.044 1 0 force
particle minecraft:cloud -22.08 67.47 -85.70 0.35 0.18 0.35 0.02 2 force
