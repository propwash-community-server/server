scoreboard players set #gx driftmountains -87553
scoreboard players set #gdx driftmountains 528
scoreboard players set #gy driftmountains 69541
scoreboard players set #gdy driftmountains -16
scoreboard players set #gz driftmountains -25223
scoreboard players set #gdz driftmountains -302
scoreboard players set #gr driftmountains -7611
scoreboard players set #gdr driftmountains 147
scoreboard players set #gp driftmountains 106
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.8438f,0.1886f,-0.2430f,0.4397f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.2906f,0.4677f,0.8286f,-0.1009f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.6941f,0.0091f,0.0094f,0.7198f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0094f,0.7198f,0.6941f,0.0091f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3571f,0.8574f,0.1040f],left_rotation:[-0.1786f,0.0676f,-0.3276f,-0.9253f]}}
particle minecraft:cloud -88.58 69.86 -26.34 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -88.58 69.66 -26.34 -0.036 0.02 -0.009 1 0 force
particle minecraft:cloud -88.98 69.86 -24.72 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -92517
scoreboard players set #gdx driftmountains 545
scoreboard players set #gy driftmountains 69705
scoreboard players set #gdy driftmountains -20
scoreboard players set #gz driftmountains -21589
scoreboard players set #gdz driftmountains -522
scoreboard players set #gr driftmountains -8964
scoreboard players set #gdr driftmountains 128
scoreboard players set #gp driftmountains 106
scoreboard players set #gdp driftmountains 2
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.1909f,-0.3165f,-0.1223f,-0.9211f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.0262f,-0.9133f,0.2252f,0.3383f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.6941f,0.0091f,0.0094f,0.7198f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0094f,0.7198f,0.6941f,0.0091f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3624f,0.8348f,0.2353f],left_rotation:[-0.1800f,0.0109f,-0.0302f,-0.9832f]}}
particle minecraft:cloud -93.88 70.02 -22.45 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -93.88 69.82 -22.45 -0.045 0.02 -0.000 1 0 force
particle minecraft:cloud -93.89 70.02 -20.74 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -95716
scoreboard players set #gdx driftmountains 457
scoreboard players set #gy driftmountains 69830
scoreboard players set #gdy driftmountains -18
scoreboard players set #gz driftmountains -17682
scoreboard players set #gdz driftmountains -637
scoreboard players set #gr driftmountains -9618
scoreboard players set #gdr driftmountains 203
scoreboard players set #gp driftmountains 86
scoreboard players set #gdp driftmountains 3
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.8321f,-0.1108f,-0.3418f,-0.4225f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.2993f,-0.3889f,0.8483f,0.1988f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.6941f,0.0091f,0.0094f,0.7198f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0094f,0.7198f,0.6941f,0.0091f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3540f,0.8355f,0.0954f],left_rotation:[-0.1837f,-0.0238f,0.1617f,-0.9693f]}}
particle minecraft:cloud -97.06 70.15 -18.38 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -97.06 69.95 -18.38 -0.046 0.02 0.005 1 0 force
particle minecraft:cloud -96.88 70.15 -16.72 0.35 0.18 0.35 0.02 3 force
