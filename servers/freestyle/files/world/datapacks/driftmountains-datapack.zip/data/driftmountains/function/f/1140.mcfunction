scoreboard players set #gx driftmountains -92860
scoreboard players set #gdx driftmountains -636
scoreboard players set #gy driftmountains 70000
scoreboard players set #gdy driftmountains 5
scoreboard players set #gz driftmountains 6502
scoreboard players set #gdz driftmountains -830
scoreboard players set #gr driftmountains -17223
scoreboard players set #gdr driftmountains 266
scoreboard players set #gp driftmountains -17
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.8442f,0.2025f,-0.3009f,0.3946f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.3440f,0.4284f,0.8276f,-0.1149f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.9957f,0.0130f,-0.0012f,-0.0917f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0012f,-0.0917f,0.9957f,0.0130f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3546f,0.8341f,0.0949f],left_rotation:[-0.1823f,-0.0299f,0.1939f,-0.9634f]}}
particle minecraft:cloud -93.86 70.32 7.64 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -93.86 70.12 7.64 -0.009 0.02 0.063 1 0 force
particle minecraft:cloud -92.20 70.32 7.86 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -87137
scoreboard players set #gdx driftmountains -759
scoreboard players set #gy driftmountains 69986
scoreboard players set #gdy driftmountains -3
scoreboard players set #gz driftmountains 13539
scoreboard players set #gdz driftmountains -885
scoreboard players set #gr driftmountains 17539
scoreboard players set #gdr driftmountains 55
scoreboard players set #gp driftmountains 14
scoreboard players set #gdp driftmountains -7
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[0.0061f,0.0001f,-0.0220f,0.9997f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.2930f,0.3092f,-0.0424f,0.9037f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.1377f,0.9132f,0.2622f,-0.2801f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.9957f,0.0130f,-0.0012f,-0.0917f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0012f,-0.0917f,0.9957f,0.0130f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3562f,0.8457f,0.2396f],left_rotation:[-0.1735f,0.0606f,-0.2861f,-0.9404f]}}
particle minecraft:cloud -87.88 70.31 14.97 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -87.88 70.11 14.97 0.005 0.02 0.067 1 0 force
particle minecraft:cloud -86.18 70.31 14.83 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -83048
scoreboard players set #gdx driftmountains -783
scoreboard players set #gy driftmountains 70031
scoreboard players set #gdy driftmountains -13
scoreboard players set #gz driftmountains 17843
scoreboard players set #gdz driftmountains -875
scoreboard players set #gr driftmountains 17434
scoreboard players set #gdr driftmountains 22
scoreboard players set #gp driftmountains 54
scoreboard players set #gdp driftmountains -7
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.8040f,-0.1170f,-0.2889f,-0.5065f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.2373f,-0.4789f,0.8207f,0.2021f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.9957f,0.0130f,-0.0012f,-0.0917f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0012f,-0.0917f,0.9957f,0.0130f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3560f,0.8559f,0.1034f],left_rotation:[-0.1807f,0.0607f,-0.2905f,-0.9376f]}}
particle minecraft:cloud -83.75 70.35 19.18 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -83.75 70.15 19.18 0.007 0.02 0.068 1 0 force
particle minecraft:cloud -82.09 70.35 19.01 0.35 0.18 0.35 0.02 3 force
