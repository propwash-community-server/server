scoreboard players set #gx driftmountains -72493
scoreboard players set #gdx driftmountains 670
scoreboard players set #gy driftmountains 69250
scoreboard players set #gdy driftmountains -9
scoreboard players set #gz driftmountains -29667
scoreboard players set #gdz driftmountains -267
scoreboard players set #gr driftmountains -11592
scoreboard players set #gdr driftmountains 52
scoreboard players set #gp driftmountains 74
scoreboard players set #gdp driftmountains 1
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,0.0000f,0.0024f,1.0000f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.2212f,0.0558f,-0.0410f,-0.9728f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[-0.0610f,-0.9738f,0.2166f,-0.0328f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.9028f,0.0118f,-0.0056f,-0.4298f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0056f,-0.4298f,0.9028f,0.0118f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3596f,0.8600f,0.1050f],left_rotation:[0.1738f,-0.0804f,0.3966f,0.8978f]}}
scoreboard players set #gx driftmountains -78731
scoreboard players set #gdx driftmountains 559
scoreboard players set #gy driftmountains 69340
scoreboard players set #gdy driftmountains -9
scoreboard players set #gz driftmountains -28397
scoreboard players set #gdz driftmountains -205
scoreboard players set #gr driftmountains -12689
scoreboard players set #gdr driftmountains -378
scoreboard players set #gp driftmountains 82
scoreboard players set #gdp driftmountains -4
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[-0.0039f,0.0000f,0.0107f,0.9999f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.9460f,0.0212f,0.1053f,0.3060f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[-0.0738f,0.2966f,0.9489f,0.0781f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.9028f,0.0118f,-0.0056f,-0.4298f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0056f,-0.4298f,0.9028f,0.0118f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3654f,0.8693f,0.2488f],left_rotation:[0.1212f,-0.1481f,0.7425f,0.6420f]}}
particle minecraft:cloud -80.34 69.66 -28.26 0.35 0.18 0.35 0.02 2 force
particle minecraft:cloud -79.31 69.66 -26.89 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -79.31 69.46 -26.89 -0.032 0.02 0.024 1 0 force
scoreboard players set #gx driftmountains -83798
scoreboard players set #gdx driftmountains 572
scoreboard players set #gy driftmountains 69439
scoreboard players set #gdy driftmountains -13
scoreboard players set #gz driftmountains -26341
scoreboard players set #gdz driftmountains -80
scoreboard players set #gr driftmountains -7523
scoreboard players set #gdr driftmountains -453
scoreboard players set #gp driftmountains 123
scoreboard players set #gdp driftmountains -3
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0001f,-0.0143f,0.9999f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.4945f,-0.0876f,-0.1115f,-0.8575f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.0220f,-0.8505f,0.5064f,0.1401f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.9028f,0.0118f,-0.0056f,-0.4298f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0056f,-0.4298f,0.9028f,0.0118f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3955f,0.8291f,0.0929f],left_rotation:[0.0620f,0.1694f,-0.9164f,0.3573f]}}
particle minecraft:cloud -84.80 69.76 -27.47 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -84.80 69.56 -27.47 -0.038 0.02 -0.010 1 0 force
particle minecraft:cloud -85.23 69.76 -25.85 0.35 0.18 0.35 0.02 2 force
