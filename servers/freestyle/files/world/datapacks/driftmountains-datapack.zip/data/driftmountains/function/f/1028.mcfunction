scoreboard players set #gx driftmountains 19411
scoreboard players set #gdx driftmountains -725
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 54415
scoreboard players set #gdz driftmountains 862
scoreboard players set #gr driftmountains 9303
scoreboard players set #gdr driftmountains 218
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.7396f,-0.1956f,-0.3776f,-0.5216f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.3249f,-0.4848f,0.7643f,0.2745f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.1575f,0.0021f,-0.0129f,-0.9874f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0129f,-0.9874f,0.1575f,0.0021f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3797f,0.8211f,0.0898f],left_rotation:[-0.1227f,-0.1307f,0.7213f,-0.6690f]}}
particle minecraft:cloud 20.62 71.32 55.32 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 20.62 71.12 55.32 0.067 0.02 0.004 1 0 force
particle minecraft:cloud 20.71 71.32 53.65 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains 24115
scoreboard players set #gdx driftmountains -626
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 47346
scoreboard players set #gdz driftmountains 935
scoreboard players set #gr driftmountains 9191
scoreboard players set #gdr driftmountains 173
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.8719f,0.1476f,-0.4320f,0.1770f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.4530f,0.2234f,0.8612f,-0.0568f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.1575f,0.0021f,-0.0129f,-0.9874f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0129f,-0.9874f,0.1575f,0.0021f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.4063f,0.8496f,0.2411f],left_rotation:[-0.0705f,-0.1722f,0.8930f,-0.4100f]}}
particle minecraft:cloud 25.45 71.32 48.25 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 25.45 71.12 48.25 0.067 0.02 0.002 1 0 force
particle minecraft:cloud 25.51 71.32 46.54 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains 26479
scoreboard players set #gdx driftmountains -253
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 42434
scoreboard players set #gdz driftmountains 914
scoreboard players set #gr driftmountains 7290
scoreboard players set #gdr driftmountains 122
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.0428f,0.4499f,0.0370f,0.8913f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.0564f,0.8923f,-0.0043f,-0.4479f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.1575f,0.0021f,-0.0129f,-0.9874f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0129f,-0.9874f,0.1575f,0.0021f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3916f,0.8256f,0.0915f],left_rotation:[-0.0811f,-0.1603f,0.8716f,-0.4560f]}}
particle minecraft:cloud 27.93 71.32 42.86 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 27.93 71.12 42.86 0.056 0.02 -0.017 1 0 force
particle minecraft:cloud 27.44 71.32 41.27 0.35 0.18 0.35 0.02 3 force
