scoreboard players set #gx driftmountains -76368
scoreboard players set #gdx driftmountains 633
scoreboard players set #gy driftmountains 69305
scoreboard players set #gdy driftmountains -9
scoreboard players set #gz driftmountains -28114
scoreboard players set #gdz driftmountains -243
scoreboard players set #gr driftmountains -12682
scoreboard players set #gdr driftmountains 162
scoreboard players set #gp driftmountains 76
scoreboard players set #gdp driftmountains -1
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,0.0000f,0.0099f,0.9999f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.2439f,0.1200f,-0.0239f,-0.9620f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[-0.0771f,-0.9648f,0.2326f,-0.0951f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.4430f,0.0058f,0.0117f,0.8964f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0117f,0.8964f,0.4430f,0.0058f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3866f,0.8647f,0.1068f],left_rotation:[0.1045f,-0.1597f,0.8332f,0.5189f]}}
particle minecraft:cloud -77.88 69.63 -28.03 0.35 0.18 0.35 0.02 2 force
particle minecraft:cloud -76.88 69.63 -26.69 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -76.88 69.43 -26.69 -0.032 0.02 0.024 1 0 force
scoreboard players set #gx driftmountains -82545
scoreboard players set #gdx driftmountains 626
scoreboard players set #gy driftmountains 69407
scoreboard players set #gdy driftmountains -12
scoreboard players set #gz driftmountains -27479
scoreboard players set #gdz driftmountains -105
scoreboard players set #gr driftmountains -8943
scoreboard players set #gdr driftmountains -504
scoreboard players set #gp driftmountains 107
scoreboard players set #gdp driftmountains -3
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0000f,-0.0063f,1.0000f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.9898f,0.0437f,-0.0866f,-0.1043f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.0761f,-0.0958f,0.9907f,0.0601f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.4430f,0.0058f,0.0117f,0.8964f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0117f,0.8964f,0.4430f,0.0058f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3976f,0.8330f,0.2346f],left_rotation:[0.1295f,0.1257f,-0.6631f,0.7265f]}}
particle minecraft:cloud -83.90 69.73 -28.35 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -83.90 69.53 -28.35 -0.038 0.02 -0.000 1 0 force
particle minecraft:cloud -83.92 69.73 -26.64 0.35 0.18 0.35 0.02 2 force
scoreboard players set #gx driftmountains -86793
scoreboard players set #gdx driftmountains 145
scoreboard players set #gy driftmountains 69524
scoreboard players set #gdy driftmountains -4
scoreboard players set #gz driftmountains -25374
scoreboard players set #gdz driftmountains -76
scoreboard players set #gr driftmountains -7049
scoreboard players set #gdr driftmountains 45
scoreboard players set #gp driftmountains 103
scoreboard players set #gdp driftmountains 1
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.7754f,0.2276f,-0.2288f,0.5429f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.2871f,0.5699f,0.7557f,-0.1473f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.4430f,0.0058f,0.0117f,0.8964f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0117f,0.8964f,0.4430f,0.0058f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3538f,0.8515f,0.1017f],left_rotation:[-0.1849f,0.0418f,-0.1887f,-0.9635f]}}
particle minecraft:cloud -87.70 69.84 -26.58 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -87.70 69.64 -26.58 -0.024 0.02 -0.009 1 0 force
particle minecraft:cloud -88.26 69.84 -25.01 0.35 0.18 0.35 0.02 3 force
