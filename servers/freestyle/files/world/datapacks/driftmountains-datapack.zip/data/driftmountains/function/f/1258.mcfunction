scoreboard players set #gx driftmountains -53890
scoreboard players set #gdx driftmountains -11
scoreboard players set #gy driftmountains 68462
scoreboard players set #gdy driftmountains -25
scoreboard players set #gz driftmountains -51988
scoreboard players set #gdz driftmountains -704
scoreboard players set #gr driftmountains 14918
scoreboard players set #gdr driftmountains -375
scoreboard players set #gp driftmountains 177
scoreboard players set #gdp driftmountains -11
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[0.0061f,-0.0001f,0.0195f,0.9998f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.7861f,-0.0745f,0.1900f,0.5834f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[-0.1297f,0.5667f,0.7983f,0.1575f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.9469f,0.0124f,-0.0042f,-0.3212f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0042f,-0.3212f,0.9469f,0.0124f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3990f,0.8341f,0.0949f],left_rotation:[-0.0384f,-0.1774f,0.9548f,-0.2351f]}}
particle minecraft:cloud -53.96 68.78 -50.48 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud -52.53 68.78 -51.33 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -52.53 68.58 -51.33 0.022 0.02 0.037 1 0 force
scoreboard players set #gx driftmountains -55015
scoreboard players set #gdx driftmountains 163
scoreboard players set #gy driftmountains 68615
scoreboard players set #gdy driftmountains -22
scoreboard players set #gz driftmountains -47311
scoreboard players set #gdz driftmountains -721
scoreboard players set #gr driftmountains 15916
scoreboard players set #gdr driftmountains -106
scoreboard players set #gp driftmountains 139
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[-0.0039f,0.0001f,0.0208f,0.9998f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.7679f,0.2056f,0.1825f,-0.5786f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[-0.2444f,-0.6010f,0.7505f,-0.1260f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.9469f,0.0124f,-0.0042f,-0.3212f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0042f,-0.3212f,0.9469f,0.0124f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3939f,0.8305f,0.2336f],left_rotation:[-0.1404f,-0.1120f,0.5946f,-0.7838f]}}
particle minecraft:cloud -55.33 68.93 -45.73 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud -53.73 68.93 -46.34 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -53.73 68.73 -46.34 0.016 0.02 0.041 1 0 force
scoreboard players set #gx driftmountains -56697
scoreboard players set #gdx driftmountains 281
scoreboard players set #gy driftmountains 68795
scoreboard players set #gdy driftmountains -21
scoreboard players set #gz driftmountains -41477
scoreboard players set #gdz driftmountains -630
scoreboard players set #gr driftmountains 17228
scoreboard players set #gdr driftmountains -191
scoreboard players set #gp driftmountains 145
scoreboard players set #gdp driftmountains -1
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,0.0001f,0.0200f,0.9998f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.6267f,-0.1325f,0.1813f,0.7462f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[-0.1039f,0.7313f,0.6440f,0.1991f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.9469f,0.0124f,-0.0042f,-0.3212f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0042f,-0.3212f,0.9469f,0.0124f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3933f,0.8269f,0.0920f],left_rotation:[-0.0735f,-0.1642f,0.8908f,-0.4171f]}}
particle minecraft:cloud -57.36 69.11 -40.12 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud -55.70 69.11 -40.34 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -55.70 68.91 -40.34 0.005 0.02 0.040 1 0 force
