scoreboard players set #gx driftmountains -6937
scoreboard players set #gdx driftmountains 660
scoreboard players set #gy driftmountains 70156
scoreboard players set #gdy driftmountains 77
scoreboard players set #gz driftmountains -27940
scoreboard players set #gdz driftmountains 343
scoreboard players set #gr driftmountains -1731
scoreboard players set #gdr driftmountains 310
scoreboard players set #gp driftmountains -412
scoreboard players set #gdp driftmountains 29
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0001f,-0.0223f,0.9997f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.7444f,-0.1459f,-0.2717f,-0.5922f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.2110f,-0.5669f,0.7639f,0.2250f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.0150f,0.0002f,0.0131f,0.9998f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0131f,0.9998f,0.0150f,0.0002f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3569f,0.8571f,0.1039f],left_rotation:[-0.1790f,0.0662f,-0.3200f,-0.9280f]}}
particle minecraft:cloud -6.51 70.48 -29.39 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -6.51 70.28 -29.39 -0.013 0.02 -0.042 1 0 force
particle minecraft:cloud -8.11 70.48 -28.89 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -11183
scoreboard players set #gdx driftmountains 657
scoreboard players set #gy driftmountains 69764
scoreboard players set #gdy driftmountains 48
scoreboard players set #gz driftmountains -29767
scoreboard players set #gdz driftmountains 93
scoreboard players set #gr driftmountains -3619
scoreboard players set #gdr driftmountains 169
scoreboard players set #gp driftmountains -283
scoreboard players set #gdp driftmountains -3
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.3304f,-0.3072f,-0.1757f,-0.8750f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.0847f,-0.8614f,0.3645f,0.3436f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.0150f,0.0002f,0.0131f,0.9998f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0131f,0.9998f,0.0150f,0.0002f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3679f,0.8305f,0.2336f],left_rotation:[-0.1783f,-0.0164f,0.1095f,-0.9777f]}}
particle minecraft:cloud -11.30 70.08 -31.37 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -11.30 69.88 -31.37 -0.030 0.02 -0.041 1 0 force
particle minecraft:cloud -12.68 70.08 -30.36 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -16723
scoreboard players set #gdx driftmountains 842
scoreboard players set #gy driftmountains 69382
scoreboard players set #gdy driftmountains 57
scoreboard players set #gz driftmountains -29624
scoreboard players set #gdz driftmountains 30
scoreboard players set #gr driftmountains -4563
scoreboard players set #gdr driftmountains 119
scoreboard players set #gp driftmountains -284
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.5030f,0.3192f,-0.1369f,0.7914f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.2208f,0.8102f,0.4722f,-0.2681f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.0150f,0.0002f,0.0131f,0.9998f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0131f,0.9998f,0.0150f,0.0002f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3525f,0.8407f,0.0974f],left_rotation:[-0.1867f,-0.0022f,0.0469f,-0.9812f]}}
particle minecraft:cloud -17.04 69.70 -31.10 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -17.04 69.50 -31.10 -0.036 0.02 -0.036 1 0 force
particle minecraft:cloud -18.21 69.70 -29.91 0.35 0.18 0.35 0.02 3 force
