scoreboard players set #gx driftmountains 27458
scoreboard players set #gdx driftmountains -104
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 36379
scoreboard players set #gdz driftmountains 985
scoreboard players set #gr driftmountains 6012
scoreboard players set #gdr driftmountains 301
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[0.0001f,0.0000f,-0.0223f,0.9998f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.5842f,-0.2760f,-0.3052f,-0.6996f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.2333f,-0.6714f,0.6164f,0.3389f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.1495f,0.0020f,0.0129f,0.9887f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0129f,0.9887f,0.1495f,0.0020f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3729f,0.8213f,0.0898f],left_rotation:[-0.1412f,-0.1114f,0.6212f,-0.7626f]}}
particle minecraft:cloud 28.97 71.32 36.48 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 28.97 71.12 36.48 0.052 0.02 -0.030 1 0 force
particle minecraft:cloud 28.13 71.32 35.03 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains 27652
scoreboard players set #gdx driftmountains 209
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 28738
scoreboard players set #gdz driftmountains 869
scoreboard players set #gr driftmountains 4277
scoreboard players set #gdr driftmountains 352
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.8927f,0.0314f,-0.4462f,-0.0544f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.4429f,-0.0078f,0.8944f,0.0623f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.1495f,0.0020f,0.0129f,0.9887f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0129f,0.9887f,0.1495f,0.0020f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.4056f,0.8451f,0.2393f],left_rotation:[-0.0859f,-0.1634f,0.8503f,-0.4929f]}}
particle minecraft:cloud 29.21 71.32 28.32 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 29.21 71.12 28.32 0.040 0.02 -0.044 1 0 force
particle minecraft:cloud 27.95 71.32 27.16 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains 24273
scoreboard players set #gdx driftmountains 284
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 24542
scoreboard players set #gdz driftmountains 947
scoreboard players set #gr driftmountains 2347
scoreboard players set #gdr driftmountains 92
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.2784f,0.3625f,-0.0548f,0.8878f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.1484f,0.8984f,0.2418f,-0.3352f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.1495f,0.0020f,0.0129f,0.9887f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0129f,0.9887f,0.1495f,0.0020f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3555f,0.8325f,0.0942f],left_rotation:[-0.1805f,-0.0369f,0.2312f,-0.9553f]}}
particle minecraft:cloud 25.54 71.32 23.72 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 25.54 71.12 23.72 0.024 0.02 -0.055 1 0 force
particle minecraft:cloud 24.01 71.32 23.05 0.35 0.18 0.35 0.02 3 force
