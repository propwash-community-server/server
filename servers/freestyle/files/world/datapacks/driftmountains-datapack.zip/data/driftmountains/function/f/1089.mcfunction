scoreboard players set #gx driftmountains -43801
scoreboard players set #gdx driftmountains -1200
scoreboard players set #gy driftmountains 70484
scoreboard players set #gdy driftmountains -9
scoreboard players set #gz driftmountains 49495
scoreboard players set #gdz driftmountains -464
scoreboard players set #gr driftmountains 15546
scoreboard players set #gdr driftmountains 28
scoreboard players set #gp driftmountains 36
scoreboard players set #gdp driftmountains -13
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.3168f,0.3692f,-0.0743f,0.8705f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.1662f,0.8831f,0.2798f,-0.3380f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.8424f,0.0110f,0.0071f,0.5387f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0071f,0.5387f,0.8424f,0.0110f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3583f,0.8288f,0.0928f],left_rotation:[-0.1747f,-0.0547f,0.3247f,-0.9279f]}}
particle minecraft:cloud -44.04 70.80 50.99 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -44.04 70.60 50.99 0.032 0.02 0.070 1 0 force
particle minecraft:cloud -42.52 70.80 50.29 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -33756
scoreboard players set #gdx driftmountains -1184
scoreboard players set #gy driftmountains 70747
scoreboard players set #gdy driftmountains -42
scoreboard players set #gz driftmountains 53204
scoreboard players set #gdz driftmountains -406
scoreboard players set #gr driftmountains 15458
scoreboard players set #gdr driftmountains 4
scoreboard players set #gp driftmountains 136
scoreboard players set #gdp driftmountains -1
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.4154f,-0.3153f,-0.2225f,-0.8237f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.1371f,-0.8049f,0.4508f,0.3607f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.8424f,0.0110f,0.0071f,0.5387f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0071f,0.5387f,0.8424f,0.0110f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3833f,0.8273f,0.2323f],left_rotation:[-0.1617f,-0.0751f,0.4079f,-0.8955f]}}
particle minecraft:cloud -33.94 71.07 54.80 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -33.94 70.87 54.80 0.032 0.02 0.067 1 0 force
particle minecraft:cloud -32.40 71.07 54.07 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -29103
scoreboard players set #gdx driftmountains -1182
scoreboard players set #gy driftmountains 70903
scoreboard players set #gdy driftmountains -35
scoreboard players set #gz driftmountains 54998
scoreboard players set #gdz driftmountains -357
scoreboard players set #gr driftmountains 15336
scoreboard players set #gdr driftmountains 29
scoreboard players set #gp driftmountains 107
scoreboard players set #gdp driftmountains 11
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.8969f,0.1401f,-0.3695f,0.1985f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.3924f,0.2385f,0.8871f,-0.0466f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.8424f,0.0110f,0.0071f,0.5387f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0071f,0.5387f,0.8424f,0.0110f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3653f,0.8236f,0.0908f],left_rotation:[-0.1593f,-0.0860f,0.4891f,-0.8532f]}}
particle minecraft:cloud -29.28 71.22 56.50 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -29.28 71.02 56.50 0.033 0.02 0.066 1 0 force
particle minecraft:cloud -27.79 71.22 55.75 0.35 0.18 0.35 0.02 3 force
