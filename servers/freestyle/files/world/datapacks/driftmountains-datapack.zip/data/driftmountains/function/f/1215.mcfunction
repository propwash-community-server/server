scoreboard players set #gx driftmountains -69049
scoreboard players set #gdx driftmountains 711
scoreboard players set #gy driftmountains 69202
scoreboard players set #gdy driftmountains -10
scoreboard players set #gz driftmountains -30958
scoreboard players set #gdz driftmountains -246
scoreboard players set #gr driftmountains -11543
scoreboard players set #gdr driftmountains -76
scoreboard players set #gp driftmountains 77
scoreboard players set #gdp driftmountains 2
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[0.0049f,-0.0000f,0.0038f,1.0000f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.8136f,0.0793f,0.0214f,-0.5755f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[-0.0820f,-0.5810f,0.8098f,0.0057f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.7687f,0.0101f,-0.0084f,-0.6395f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0084f,-0.6395f,0.7687f,0.0101f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3661f,0.8643f,0.1067f],left_rotation:[0.1600f,-0.1064f,0.5382f,0.8206f]}}
scoreboard players set #gx driftmountains -75480
scoreboard players set #gdx driftmountains 652
scoreboard players set #gy driftmountains 69291
scoreboard players set #gdy driftmountains -9
scoreboard players set #gz driftmountains -29739
scoreboard players set #gdz driftmountains -301
scoreboard players set #gr driftmountains -12794
scoreboard players set #gdr driftmountains 158
scoreboard players set #gp driftmountains 73
scoreboard players set #gdp driftmountains -1
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[-0.0039f,0.0000f,0.0083f,1.0000f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.2223f,-0.0881f,0.0742f,0.9681f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.0271f,0.9657f,0.2328f,0.1119f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.7687f,0.0101f,-0.0084f,-0.6395f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0084f,-0.6395f,0.7687f,0.0101f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3688f,0.8714f,0.2496f],left_rotation:[0.1101f,-0.1574f,0.7916f,0.5801f]}}
particle minecraft:cloud -77.08 69.61 -29.57 0.35 0.18 0.35 0.02 2 force
particle minecraft:cloud -76.03 69.61 -28.23 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -76.03 69.41 -28.23 -0.034 0.02 0.027 1 0 force
scoreboard players set #gx driftmountains -80568
scoreboard players set #gdx driftmountains 755
scoreboard players set #gy driftmountains 69374
scoreboard players set #gdy driftmountains -14
scoreboard players set #gz driftmountains -26783
scoreboard players set #gdz driftmountains -155
scoreboard players set #gr driftmountains -10438
scoreboard players set #gdr driftmountains -772
scoreboard players set #gp driftmountains 103
scoreboard players set #gdp driftmountains -6
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,0.0000f,0.0023f,1.0000f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.9701f,0.0575f,-0.0148f,0.2354f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.0396f,0.2383f,0.9694f,0.0442f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.7687f,0.0101f,-0.0084f,-0.6395f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0084f,-0.6395f,0.7687f,0.0101f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3559f,0.8319f,0.0940f],left_rotation:[0.1798f,0.0396f,-0.2452f,0.9518f]}}
