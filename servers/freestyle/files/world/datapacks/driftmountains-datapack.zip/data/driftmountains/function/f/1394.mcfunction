scoreboard players set #gx driftmountains 10779
scoreboard players set #gdx driftmountains 916
scoreboard players set #gy driftmountains 66731
scoreboard players set #gdy driftmountains -12
scoreboard players set #gz driftmountains -64113
scoreboard players set #gdz driftmountains 622
scoreboard players set #gr driftmountains -5718
scoreboard players set #gdr driftmountains -48
scoreboard players set #gp driftmountains 61
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,0.0000f,0.0008f,1.0000f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.2067f,0.0219f,-0.0489f,-0.9769f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[-0.0536f,-0.9772f,0.2055f,-0.0003f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.4954f,0.0065f,0.0114f,0.8686f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0114f,0.8686f,0.4954f,0.0065f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3527f,0.8477f,0.1002f],left_rotation:[0.1868f,-0.0260f,0.1040f,0.9765f]}}
scoreboard players set #gx driftmountains 3786
scoreboard players set #gdx driftmountains 914
scoreboard players set #gy driftmountains 66820
scoreboard players set #gdy driftmountains -12
scoreboard players set #gz driftmountains -68786
scoreboard players set #gdz driftmountains 599
scoreboard players set #gr driftmountains -5251
scoreboard players set #gdr driftmountains -34
scoreboard players set #gp driftmountains 61
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0000f,-0.0026f,1.0000f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.7804f,0.0189f,-0.0603f,-0.6221f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[-0.0047f,-0.6192f,0.7827f,0.0630f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.4954f,0.0065f,0.0114f,0.8686f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0114f,0.8686f,0.4954f,0.0065f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3779f,0.8273f,0.2323f],left_rotation:[0.1693f,0.0556f,-0.3093f,0.9342f]}}
scoreboard players set #gx driftmountains -4931
scoreboard players set #gdx driftmountains 871
scoreboard players set #gy driftmountains 66933
scoreboard players set #gdy driftmountains -11
scoreboard players set #gz driftmountains -74693
scoreboard players set #gdz driftmountains 578
scoreboard players set #gr driftmountains -4766
scoreboard players set #gdr driftmountains -73
scoreboard players set #gp driftmountains 62
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0000f,-0.0053f,1.0000f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.2345f,-0.0617f,-0.0690f,-0.9677f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[-0.0324f,-0.9658f,0.2423f,0.0867f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.4954f,0.0065f,0.0114f,0.8686f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0114f,0.8686f,0.4954f,0.0065f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3733f,0.8212f,0.0898f],left_rotation:[0.1401f,0.1127f,-0.6282f,0.7570f]}}
