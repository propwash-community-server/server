scoreboard players set #gx driftmountains -97723
scoreboard players set #gdx driftmountains -147
scoreboard players set #gy driftmountains 70032
scoreboard players set #gdy driftmountains -3
scoreboard players set #gz driftmountains -4069
scoreboard players set #gdz driftmountains -905
scoreboard players set #gr driftmountains -14015
scoreboard players set #gdr driftmountains 129
scoreboard players set #gp driftmountains 7
scoreboard players set #gdp driftmountains 6
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.8372f,0.2115f,-0.3200f,0.3899f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.3628f,0.4257f,0.8195f,-0.1247f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.9980f,0.0131f,-0.0008f,-0.0624f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0008f,-0.0624f,0.9980f,0.0131f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3607f,0.8266f,0.0919f],left_rotation:[-0.1696f,-0.0667f,0.3878f,-0.9035f]}}
particle minecraft:cloud -99.17 70.35 -3.64 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -99.17 70.15 -3.64 -0.035 0.02 0.043 1 0 force
particle minecraft:cloud -97.89 70.35 -2.57 0.35 0.18 0.35 0.02 3 force
playsound driftgen:grain.kaze.029 neutral @a -98.04 70.47 -10.97 12 1
scoreboard players set #gx driftmountains -94955
scoreboard players set #gdx driftmountains -479
scoreboard players set #gy driftmountains 70015
scoreboard players set #gdy driftmountains 4
scoreboard players set #gz driftmountains 3747
scoreboard players set #gdz driftmountains -842
scoreboard players set #gr driftmountains -16220
scoreboard players set #gdr driftmountains 291
scoreboard players set #gp driftmountains -16
scoreboard players set #gdp driftmountains 1
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.2903f,0.3586f,-0.0585f,0.8853f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.1519f,0.8963f,0.2542f,-0.3301f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.9980f,0.0131f,-0.0008f,-0.0624f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0008f,-0.0624f,0.9980f,0.0131f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3722f,0.8286f,0.2329f],left_rotation:[-0.1752f,-0.0341f,0.2000f,-0.9634f]}}
particle minecraft:cloud -96.19 70.34 4.79 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -96.19 70.14 4.79 -0.018 0.02 0.055 1 0 force
particle minecraft:cloud -94.56 70.34 5.31 0.35 0.18 0.35 0.02 3 force
playsound driftgen:grain.onyx.048 neutral @a -97.63 70.53 -3.18 12 1
scoreboard players set #gx driftmountains -91565
scoreboard players set #gdx driftmountains -670
scoreboard players set #gy driftmountains 69992
scoreboard players set #gdy driftmountains 4
scoreboard players set #gz driftmountains 8185
scoreboard players set #gdz driftmountains -779
scoreboard players set #gr driftmountains -17848
scoreboard players set #gdr driftmountains 285
scoreboard players set #gp driftmountains -15
scoreboard players set #gdp driftmountains -1
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.7901f,-0.1397f,-0.3248f,-0.5007f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.2740f,-0.4693f,0.8092f,0.2235f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.9980f,0.0131f,-0.0008f,-0.0624f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0008f,-0.0624f,0.9980f,0.0131f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3531f,0.8379f,0.0964f],left_rotation:[-0.1854f,-0.0135f,0.1066f,-0.9767f]}}
particle minecraft:cloud -92.43 70.31 9.42 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -92.43 70.11 9.42 -0.002 0.02 0.059 1 0 force
particle minecraft:cloud -90.76 70.31 9.47 0.35 0.18 0.35 0.02 3 force
playsound driftgen:grain.kaze.028 neutral @a -95.93 70.52 1.98 12 1
