scoreboard players set #gx driftmountains -71823
scoreboard players set #gdx driftmountains 680
scoreboard players set #gy driftmountains 69241
scoreboard players set #gdy driftmountains -9
scoreboard players set #gz driftmountains -29933
scoreboard players set #gdz driftmountains -261
scoreboard players set #gr driftmountains -11540
scoreboard players set #gdr driftmountains 33
scoreboard players set #gp driftmountains 74
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,0.0000f,0.0025f,1.0000f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.7593f,0.0099f,0.0692f,0.6470f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[-0.0016f,0.6433f,0.7624f,0.0699f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.1791f,0.0023f,0.0129f,0.9837f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0129f,0.9837f,0.1791f,0.0023f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3599f,0.8603f,0.1051f],left_rotation:[0.1731f,-0.0819f,0.4049f,0.8940f]}}
scoreboard players set #gx driftmountains -78172
scoreboard players set #gdx driftmountains 645
scoreboard players set #gy driftmountains 69331
scoreboard players set #gdy driftmountains -10
scoreboard players set #gz driftmountains -28602
scoreboard players set #gdz driftmountains -250
scoreboard players set #gr driftmountains -13067
scoreboard players set #gdr driftmountains -84
scoreboard players set #gp driftmountains 78
scoreboard players set #gdp driftmountains -2
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[-0.0039f,0.0000f,0.0122f,0.9999f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.7585f,0.1178f,0.0581f,-0.6383f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[-0.1255f,-0.6480f,0.7503f,-0.0387f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.1791f,0.0023f,0.0129f,0.9837f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0129f,0.9837f,0.1791f,0.0023f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3766f,0.8740f,0.2506f],left_rotation:[0.0854f,-0.1731f,0.8756f,0.4428f]}}
particle minecraft:cloud -79.76 69.65 -28.36 0.35 0.18 0.35 0.02 2 force
particle minecraft:cloud -78.65 69.65 -27.06 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -78.65 69.45 -27.06 -0.031 0.02 0.026 1 0 force
scoreboard players set #gx driftmountains -83226
scoreboard players set #gdx driftmountains 761
scoreboard players set #gy driftmountains 69426
scoreboard players set #gdy driftmountains -16
scoreboard players set #gz driftmountains -26421
scoreboard players set #gdz driftmountains -99
scoreboard players set #gr driftmountains -7977
scoreboard players set #gdr driftmountains -513
scoreboard players set #gp driftmountains 120
scoreboard players set #gdp driftmountains -7
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0000f,-0.0110f,0.9999f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.4478f,0.1260f,-0.0047f,0.8852f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.0978f,0.8906f,0.4370f,-0.0796f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.1791f,0.0023f,0.0129f,0.9837f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0129f,0.9837f,0.1791f,0.0023f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3898f,0.8244f,0.0911f],left_rotation:[0.0888f,0.1560f,-0.8497f,0.4957f]}}
particle minecraft:cloud -84.32 69.75 -27.47 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -84.32 69.55 -27.47 -0.039 0.02 -0.007 1 0 force
particle minecraft:cloud -84.61 69.75 -25.82 0.35 0.18 0.35 0.02 2 force
