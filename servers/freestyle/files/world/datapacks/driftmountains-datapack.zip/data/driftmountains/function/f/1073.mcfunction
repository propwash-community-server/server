scoreboard players set #gx driftmountains -25262
scoreboard players set #gdx driftmountains -1115
scoreboard players set #gy driftmountains 70989
scoreboard players set #gdy driftmountains -19
scoreboard players set #gz driftmountains 55859
scoreboard players set #gdz driftmountains -356
scoreboard players set #gr driftmountains 15446
scoreboard players set #gdr driftmountains 19
scoreboard players set #gp driftmountains 46
scoreboard players set #gdp driftmountains 34
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.9038f,0.1239f,-0.3778f,0.1581f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.3965f,0.1986f,0.8958f,-0.0296f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.8691f,0.0114f,-0.0065f,-0.4945f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0065f,-0.4945f,0.8691f,0.0114f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3664f,0.8231f,0.0906f],left_rotation:[-0.1569f,-0.0899f,0.5098f,-0.8410f]}}
particle minecraft:cloud -25.47 71.31 57.36 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -25.47 71.11 57.36 0.030 0.02 0.063 1 0 force
particle minecraft:cloud -23.97 71.31 56.64 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -15888
scoreboard players set #gdx driftmountains -1098
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 58605
scoreboard players set #gdz driftmountains -300
scoreboard players set #gr driftmountains 15078
scoreboard players set #gdr driftmountains 14
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.5055f,0.3513f,-0.1625f,0.7712f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.2444f,0.7925f,0.4713f,-0.3001f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.8691f,0.0114f,-0.0065f,-0.4945f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0065f,-0.4945f,0.8691f,0.0114f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3839f,0.8273f,0.2323f],left_rotation:[-0.1608f,-0.0771f,0.4181f,-0.8908f]}}
particle minecraft:cloud -15.97 71.32 60.21 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -15.97 71.12 60.21 0.032 0.02 0.057 1 0 force
particle minecraft:cloud -14.48 71.32 59.38 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -11179
scoreboard players set #gdx driftmountains -1077
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 60045
scoreboard players set #gdz driftmountains -291
scoreboard players set #gr driftmountains 15185
scoreboard players set #gdr driftmountains -42
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.6195f,-0.2520f,-0.3079f,-0.6767f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.2385f,-0.6481f,0.6494f,0.3185f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.8691f,0.0114f,-0.0065f,-0.4945f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0065f,-0.4945f,0.8691f,0.0114f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3665f,0.8231f,0.0905f],left_rotation:[-0.1566f,-0.0903f,0.5119f,-0.8398f]}}
particle minecraft:cloud -11.32 71.32 61.55 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -11.32 71.12 61.55 0.031 0.02 0.058 1 0 force
particle minecraft:cloud -9.85 71.32 60.76 0.35 0.18 0.35 0.02 3 force
