scoreboard players set #gx driftmountains -55258
scoreboard players set #gdx driftmountains 192
scoreboard players set #gy driftmountains 68743
scoreboard players set #gdy driftmountains -19
scoreboard players set #gz driftmountains -42765
scoreboard players set #gdz driftmountains -654
scoreboard players set #gr driftmountains 16480
scoreboard players set #gdr driftmountains -184
scoreboard players set #gp driftmountains 138
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,0.0001f,0.0199f,0.9998f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.5110f,0.2088f,0.0655f,-0.8313f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[-0.1532f,-0.8427f,0.4919f,-0.1562f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.5815f,0.0076f,0.0106f,0.8134f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0106f,0.8134f,0.5815f,0.0076f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3952f,0.8287f,0.0927f],left_rotation:[-0.0639f,-0.1686f,0.9124f,-0.3674f]}}
particle minecraft:cloud -55.73 69.06 -41.33 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud -54.12 69.06 -41.77 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -54.12 68.86 -41.77 0.011 0.02 0.039 1 0 force
scoreboard players set #gx driftmountains -58421
scoreboard players set #gdx driftmountains 314
scoreboard players set #gy driftmountains 68877
scoreboard players set #gdy driftmountains -17
scoreboard players set #gz driftmountains -39416
scoreboard players set #gdz driftmountains -430
scoreboard players set #gr driftmountains -17823
scoreboard players set #gdr driftmountains -190
scoreboard players set #gp driftmountains 149
scoreboard players set #gdp driftmountains -1
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[-0.0039f,0.0001f,0.0217f,0.9998f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.9521f,0.0970f,0.2339f,-0.1715f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[-0.2532f,-0.1970f,0.9471f,0.0025f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.5815f,0.0076f,0.0106f,0.8134f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0106f,0.8134f,0.5815f,0.0076f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.4016f,0.8371f,0.2362f],left_rotation:[-0.1139f,-0.1418f,0.7436f,-0.6435f]}}
particle minecraft:cloud -59.32 69.20 -38.08 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud -57.61 69.20 -38.03 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -57.61 69.00 -38.03 -0.001 0.02 0.036 1 0 force
scoreboard players set #gx driftmountains -61527
scoreboard players set #gdx driftmountains 462
scoreboard players set #gy driftmountains 69057
scoreboard players set #gdy driftmountains -18
scoreboard players set #gz driftmountains -34844
scoreboard players set #gdz driftmountains -367
scoreboard players set #gr driftmountains -15988
scoreboard players set #gdr driftmountains -582
scoreboard players set #gp driftmountains 130
scoreboard players set #gdp driftmountains 26
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[-0.0002f,0.0000f,0.0209f,0.9998f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.6821f,-0.0841f,0.1545f,0.7098f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[-0.0807f,0.6974f,0.6947f,0.1563f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.5815f,0.0076f,0.0106f,0.8134f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0106f,0.8134f,0.5815f,0.0076f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.4011f,0.8462f,0.0996f],left_rotation:[0.0122f,-0.1843f,0.9823f,0.0294f]}}
particle minecraft:cloud -62.74 69.38 -33.95 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud -61.18 69.38 -33.37 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -61.18 69.18 -33.37 -0.013 0.02 0.035 1 0 force
