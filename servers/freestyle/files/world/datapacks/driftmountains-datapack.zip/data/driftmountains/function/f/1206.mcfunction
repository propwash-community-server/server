scoreboard players set #gx driftmountains -75098
scoreboard players set #gdx driftmountains 641
scoreboard players set #gy driftmountains 69287
scoreboard players set #gdy driftmountains -9
scoreboard players set #gz driftmountains -28607
scoreboard players set #gdz driftmountains -261
scoreboard players set #gr driftmountains -12373
scoreboard players set #gdr driftmountains 172
scoreboard players set #gp driftmountains 74
scoreboard players set #gdp driftmountains -1
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,0.0000f,0.0073f,1.0000f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.9660f,0.0725f,0.0753f,-0.2364f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[-0.1006f,-0.2456f,0.9637f,0.0286f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.0694f,0.0009f,-0.0131f,-0.9975f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0131f,-0.9975f,0.0694f,0.0009f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3779f,0.8665f,0.1076f],left_rotation:[0.1312f,-0.1401f,0.7237f,0.6629f]}}
particle minecraft:cloud -76.61 69.61 -28.60 0.35 0.18 0.35 0.02 2 force
particle minecraft:cloud -75.68 69.61 -27.21 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -75.68 69.41 -27.21 -0.034 0.02 0.023 1 0 force
scoreboard players set #gx driftmountains -81348
scoreboard players set #gdx driftmountains 689
scoreboard players set #gy driftmountains 69384
scoreboard players set #gdy driftmountains -12
scoreboard players set #gz driftmountains -27691
scoreboard players set #gdz driftmountains -150
scoreboard players set #gr driftmountains -10075
scoreboard players set #gdr driftmountains -677
scoreboard players set #gp driftmountains 101
scoreboard players set #gdp driftmountains -3
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0000f,-0.0004f,1.0000f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.4372f,0.0603f,0.0289f,0.8969f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.0652f,0.8988f,0.4333f,-0.0146f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.0694f,0.0009f,-0.0131f,-0.9975f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0131f,-0.9975f,0.0694f,0.0009f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3807f,0.8272f,0.2323f],left_rotation:[0.1657f,0.0657f,-0.3607f,0.9155f]}}
scoreboard players set #gx driftmountains -86278
scoreboard players set #gdx driftmountains 557
scoreboard players set #gy driftmountains 69509
scoreboard players set #gdy driftmountains -17
scoreboard players set #gz driftmountains -25621
scoreboard players set #gdz driftmountains -227
scoreboard players set #gr driftmountains -6951
scoreboard players set #gdr driftmountains -37
scoreboard players set #gp driftmountains 110
scoreboard players set #gdp driftmountains 14
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.9295f,-0.0145f,-0.2908f,-0.2262f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.2687f,-0.1969f,0.9362f,0.1123f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.0694f,0.0009f,-0.0131f,-0.9975f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0131f,-0.9975f,0.0694f,0.0009f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3627f,0.8624f,0.1060f],left_rotation:[-0.1674f,0.0938f,-0.4698f,-0.8616f]}}
particle minecraft:cloud -87.17 69.83 -26.84 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -87.17 69.63 -26.84 -0.023 0.02 -0.009 1 0 force
particle minecraft:cloud -87.75 69.83 -25.28 0.35 0.18 0.35 0.02 3 force
