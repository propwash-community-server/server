scoreboard players set #gx driftmountains -77371
scoreboard players set #gdx driftmountains -882
scoreboard players set #gy driftmountains 70169
scoreboard players set #gdy driftmountains -24
scoreboard players set #gz driftmountains 24774
scoreboard players set #gdz driftmountains -1003
scoreboard players set #gr driftmountains 17793
scoreboard players set #gdr driftmountains 18
scoreboard players set #gp driftmountains 80
scoreboard players set #gdp driftmountains -2
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.0796f,0.3354f,0.0272f,0.9383f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.0712f,0.9406f,0.0448f,-0.3289f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.6164f,0.0081f,0.0103f,0.7873f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0103f,0.7873f,0.6164f,0.0081f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3524f,0.8455f,0.0993f],left_rotation:[-0.1873f,0.0173f,-0.0571f,-0.9804f]}}
particle minecraft:cloud -78.16 70.49 26.06 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -78.16 70.29 26.06 0.003 0.02 0.080 1 0 force
particle minecraft:cloud -76.49 70.49 26.00 0.35 0.18 0.35 0.02 3 force
playsound driftgen:grain.kaze.012 neutral @a -84.09 70.52 16.99 12 1
scoreboard players set #gx driftmountains -69684
scoreboard players set #gdx driftmountains -991
scoreboard players set #gy driftmountains 70372
scoreboard players set #gdy driftmountains -25
scoreboard players set #gz driftmountains 32510
scoreboard players set #gdz driftmountains -1004
scoreboard players set #gr driftmountains 17734
scoreboard players set #gdr driftmountains -69
scoreboard players set #gp driftmountains 75
scoreboard players set #gdp driftmountains 3
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.6233f,-0.2257f,-0.2774f,-0.6954f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.2058f,-0.6701f,0.6505f,0.2924f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.6164f,0.0081f,0.0103f,0.7873f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0103f,0.7873f,0.6164f,0.0081f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3696f,0.8297f,0.2333f],left_rotation:[-0.1773f,-0.0234f,0.1453f,-0.9731f]}}
particle minecraft:cloud -70.48 70.69 33.91 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -70.48 70.49 33.91 0.004 0.02 0.083 1 0 force
particle minecraft:cloud -68.77 70.69 33.83 0.35 0.18 0.35 0.02 3 force
playsound driftgen:grain.onyx.012 neutral @a -77.33 70.67 24.56 12 1
scoreboard players set #gx driftmountains -65741
scoreboard players set #gdx driftmountains -958
scoreboard players set #gy driftmountains 70462
scoreboard players set #gdy driftmountains -19
scoreboard players set #gz driftmountains 36520
scoreboard players set #gdz driftmountains -974
scoreboard players set #gr driftmountains -17891
scoreboard players set #gdr driftmountains 7
scoreboard players set #gp driftmountains 54
scoreboard players set #gdp driftmountains 6
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.8200f,0.2241f,-0.3075f,0.4276f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.3541f,0.4622f,0.8010f,-0.1391f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.6164f,0.0081f,0.0103f,0.7873f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0103f,0.7873f,0.6164f,0.0081f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3596f,0.8276f,0.0923f],left_rotation:[-0.1720f,-0.0612f,0.3593f,-0.9151f]}}
particle minecraft:cloud -66.60 70.78 37.76 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -66.60 70.58 37.76 -0.001 0.02 0.079 1 0 force
particle minecraft:cloud -64.93 70.78 37.80 0.35 0.18 0.35 0.02 3 force
playsound driftgen:grain.kaze.012 neutral @a -73.07 70.78 28.76 12 1
