scoreboard players set #gx driftmountains 27512
scoreboard players set #gdx driftmountains -55
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 35383
scoreboard players set #gdz driftmountains 996
scoreboard players set #gr driftmountains 5691
scoreboard players set #gdr driftmountains 322
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[0.0024f,0.0001f,-0.0223f,0.9997f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.8274f,0.2228f,-0.3445f,0.3835f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.3867f,0.4219f,0.8085f,-0.1371f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.9153f,0.0120f,-0.0053f,-0.4026f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0053f,-0.4026f,0.9153f,0.0120f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3723f,0.8214f,0.0899f],left_rotation:[-0.1427f,-0.1096f,0.6120f,-0.7701f]}}
particle minecraft:cloud 29.02 71.32 35.39 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 29.02 71.12 35.39 0.050 0.02 -0.033 1 0 force
particle minecraft:cloud 28.11 71.32 34.00 0.35 0.18 0.35 0.02 3 force
playsound driftgen:grain.kaze.016 neutral @a 25.83 71.50 43.24 12 1
scoreboard players set #gx driftmountains 27371
scoreboard players set #gdx driftmountains 281
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 27712
scoreboard players set #gdz driftmountains 1026
scoreboard players set #gr driftmountains 3842
scoreboard players set #gdr driftmountains 434
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.2865f,0.4082f,-0.0749f,0.8635f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.1661f,0.8761f,0.2451f,-0.3804f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.9153f,0.0120f,-0.0053f,-0.4026f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0053f,-0.4026f,0.9153f,0.0120f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3968f,0.8324f,0.2343f],left_rotation:[-0.1321f,-0.1226f,0.6477f,-0.7403f]}}
particle minecraft:cloud 28.89 71.32 27.17 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 28.89 71.12 27.17 0.036 0.02 -0.046 1 0 force
particle minecraft:cloud 27.55 71.32 26.11 0.35 0.18 0.35 0.02 3 force
playsound driftgen:grain.onyx.017 neutral @a 28.41 71.50 35.63 12 1
scoreboard players set #gx driftmountains 23997
scoreboard players set #gdx driftmountains 275
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 23569
scoreboard players set #gdz driftmountains 972
scoreboard players set #gr driftmountains 2243
scoreboard players set #gdr driftmountains 105
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[0.0061f,0.0001f,-0.0223f,0.9997f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.7967f,-0.1292f,-0.3082f,-0.5035f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.2570f,-0.4739f,0.8147f,0.2136f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.9153f,0.0120f,-0.0053f,-0.4026f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0053f,-0.4026f,0.9153f,0.0120f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3525f,0.8465f,0.0997f],left_rotation:[-0.1871f,0.0214f,-0.0793f,-0.9789f]}}
particle minecraft:cloud 25.25 71.32 22.72 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 25.25 71.12 22.72 0.023 0.02 -0.056 1 0 force
particle minecraft:cloud 23.71 71.32 22.09 0.35 0.18 0.35 0.02 3 force
playsound driftgen:grain.kaze.015 neutral @a 26.51 71.50 31.13 12 1
