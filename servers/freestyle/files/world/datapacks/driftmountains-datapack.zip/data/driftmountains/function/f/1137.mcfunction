scoreboard players set #gx driftmountains -90807
scoreboard players set #gdx driftmountains -700
scoreboard players set #gy driftmountains 69988
scoreboard players set #gdy driftmountains 3
scoreboard players set #gz driftmountains 8986
scoreboard players set #gdz driftmountains -835
scoreboard players set #gr driftmountains -17949
scoreboard players set #gdr driftmountains 65
scoreboard players set #gp driftmountains -13
scoreboard players set #gdp driftmountains -2
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.3191f,0.3410f,-0.0641f,0.8819f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.1572f,0.8935f,0.2850f,-0.3094f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.7736f,0.0101f,0.0083f,0.6336f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0083f,0.6336f,0.7736f,0.0101f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3525f,0.8408f,0.0975f],left_rotation:[-0.1868f,-0.0016f,0.0436f,-0.9814f]}}
particle minecraft:cloud -91.65 70.31 10.24 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -91.65 70.11 10.24 -0.001 0.02 0.066 1 0 force
particle minecraft:cloud -89.98 70.31 10.25 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -84867
scoreboard players set #gdx driftmountains -799
scoreboard players set #gy driftmountains 70006
scoreboard players set #gdy driftmountains -9
scoreboard players set #gz driftmountains 16185
scoreboard players set #gdz driftmountains -931
scoreboard players set #gr driftmountains 17475
scoreboard players set #gdr driftmountains 18
scoreboard players set #gp driftmountains 40
scoreboard players set #gdp driftmountains -9
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.4333f,-0.2420f,-0.1853f,-0.8482f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.0971f,-0.8334f,0.4611f,0.2889f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.7736f,0.0101f,0.0083f,0.6336f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0083f,0.6336f,0.7736f,0.0101f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3557f,0.8490f,0.2408f],left_rotation:[-0.1696f,0.0733f,-0.3520f,-0.9176f]}}
particle minecraft:cloud -85.59 70.33 17.62 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -85.59 70.13 17.62 0.006 0.02 0.070 1 0 force
particle minecraft:cloud -83.89 70.33 17.47 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -80699
scoreboard players set #gdx driftmountains -800
scoreboard players set #gy driftmountains 70078
scoreboard players set #gdy driftmountains -17
scoreboard players set #gz driftmountains 20441
scoreboard players set #gdz driftmountains -883
scoreboard players set #gr driftmountains 17464
scoreboard players set #gdr driftmountains -44
scoreboard players set #gp driftmountains 69
scoreboard players set #gdp driftmountains -4
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.9245f,0.1231f,-0.2936f,0.2095f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.3173f,0.2415f,0.9167f,-0.0266f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.7736f,0.0101f,0.0083f,0.6336f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0083f,0.6336f,0.7736f,0.0101f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3545f,0.8533f,0.1024f],left_rotation:[-0.1835f,0.0493f,-0.2291f,-0.9546f]}}
particle minecraft:cloud -81.41 70.40 21.77 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -81.41 70.20 21.77 0.007 0.02 0.071 1 0 force
particle minecraft:cloud -79.75 70.40 21.62 0.35 0.18 0.35 0.02 3 force
