scoreboard players set #gx driftmountains 9024
scoreboard players set #gdx driftmountains -1035
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 62211
scoreboard players set #gdz driftmountains 324
scoreboard players set #gr driftmountains 12990
scoreboard players set #gdr driftmountains 315
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.7341f,-0.2031f,-0.3882f,-0.5187f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.3359f,-0.4808f,0.7595f,0.2814f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.1863f,0.0024f,-0.0129f,-0.9824f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0129f,-0.9824f,0.1863f,0.0024f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3859f,0.8226f,0.0903f],left_rotation:[-0.1032f,-0.1466f,0.8021f,-0.5695f]}}
particle minecraft:cloud 9.45 71.32 63.66 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 9.45 71.12 63.66 0.050 0.02 0.042 1 0 force
particle minecraft:cloud 10.53 71.32 62.38 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains 15207
scoreboard players set #gdx driftmountains -845
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 56917
scoreboard players set #gdz driftmountains 610
scoreboard players set #gr driftmountains 11322
scoreboard players set #gdr driftmountains 244
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.8693f,0.1487f,-0.4372f,0.1761f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.4581f,0.2230f,0.8585f,-0.0581f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.1863f,0.0024f,-0.0129f,-0.9824f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0129f,-0.9824f,0.1863f,0.0024f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.4062f,0.8521f,0.2421f],left_rotation:[-0.0614f,-0.1765f,0.9137f,-0.3609f]}}
particle minecraft:cloud 16.12 71.32 58.24 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 16.12 71.12 58.24 0.056 0.02 0.024 1 0 force
particle minecraft:cloud 16.80 71.32 56.67 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains 20768
scoreboard players set #gdx driftmountains -684
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 53694
scoreboard players set #gdz driftmountains 833
scoreboard players set #gr driftmountains 9571
scoreboard players set #gdr driftmountains 218
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.0426f,0.4454f,0.0373f,0.8935f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.0564f,0.8945f,-0.0040f,-0.4434f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.1863f,0.0024f,-0.0129f,-0.9824f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0129f,-0.9824f,0.1863f,0.0024f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3898f,0.8244f,0.0911f],left_rotation:[-0.0887f,-0.1560f,0.8500f,-0.4953f]}}
particle minecraft:cloud 21.94 71.32 54.65 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 21.94 71.12 54.65 0.066 0.02 0.007 1 0 force
particle minecraft:cloud 22.11 71.32 52.99 0.35 0.18 0.35 0.02 3 force
