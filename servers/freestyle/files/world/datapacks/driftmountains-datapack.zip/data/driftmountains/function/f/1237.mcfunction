scoreboard players set #gx driftmountains -57529
scoreboard players set #gdx driftmountains 348
scoreboard players set #gy driftmountains 68893
scoreboard players set #gdy driftmountains -18
scoreboard players set #gz driftmountains -38118
scoreboard players set #gdz driftmountains -518
scoreboard players set #gr driftmountains -17886
scoreboard players set #gdr driftmountains -137
scoreboard players set #gp driftmountains 140
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,0.0001f,0.0204f,0.9998f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.8314f,-0.0739f,0.2266f,0.5020f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[-0.1750f,0.4809f,0.8438f,0.1617f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.3958f,0.0052f,-0.0120f,-0.9182f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0120f,-0.9182f,0.3958f,0.0052f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3880f,0.8235f,0.0907f],left_rotation:[-0.0956f,-0.1517f,0.8284f,-0.5305f]}}
particle minecraft:cloud -58.39 69.21 -36.87 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud -56.72 69.21 -36.84 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -56.72 69.01 -36.84 -0.001 0.02 0.037 1 0 force
scoreboard players set #gx driftmountains -61631
scoreboard players set #gdx driftmountains 445
scoreboard players set #gy driftmountains 69047
scoreboard players set #gdy driftmountains -23
scoreboard players set #gz driftmountains -35837
scoreboard players set #gdz driftmountains -365
scoreboard players set #gr driftmountains -16196
scoreboard players set #gdr driftmountains -597
scoreboard players set #gp driftmountains 166
scoreboard players set #gdp driftmountains 26
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[-0.0037f,0.0001f,0.0218f,0.9998f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.8304f,-0.0479f,0.1746f,0.5269f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[-0.1202f,0.5114f,0.8400f,0.1354f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.3958f,0.0052f,-0.0120f,-0.9182f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0120f,-0.9182f,0.3958f,0.0052f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3991f,0.8672f,0.2480f],left_rotation:[0.0014f,-0.1914f,0.9813f,-0.0194f]}}
particle minecraft:cloud -62.87 69.37 -34.80 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud -61.24 69.37 -34.27 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -61.24 69.17 -34.27 -0.010 0.02 0.032 1 0 force
scoreboard players set #gx driftmountains -65863
scoreboard players set #gdx driftmountains 421
scoreboard players set #gy driftmountains 69152
scoreboard players set #gdy driftmountains -7
scoreboard players set #gz driftmountains -32668
scoreboard players set #gdz driftmountains -174
scoreboard players set #gr driftmountains -13050
scoreboard players set #gdr driftmountains -222
scoreboard players set #gp driftmountains 84
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[0.0061f,-0.0001f,0.0111f,0.9999f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.1294f,0.1473f,-0.0339f,-0.9800f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[-0.0689f,-0.9818f,0.1146f,-0.1345f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.3958f,0.0052f,-0.0120f,-0.9182f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0120f,-0.9182f,0.3958f,0.0052f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3972f,0.8564f,0.1036f],left_rotation:[0.0563f,-0.1792f,0.9465f,0.2621f]}}
particle minecraft:cloud -67.36 69.47 -32.48 0.35 0.18 0.35 0.02 2 force
particle minecraft:cloud -66.28 69.47 -31.21 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -66.28 69.27 -31.21 -0.022 0.02 0.019 1 0 force
