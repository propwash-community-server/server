scoreboard players set #gx driftmountains -66954
scoreboard players set #gdx driftmountains 672
scoreboard players set #gy driftmountains 69170
scoreboard players set #gdy driftmountains -11
scoreboard players set #gz driftmountains -31679
scoreboard players set #gdz driftmountains -230
scoreboard players set #gr driftmountains -12135
scoreboard players set #gdr driftmountains -309
scoreboard players set #gp driftmountains 83
scoreboard players set #gdp driftmountains 1
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[0.0061f,-0.0000f,0.0077f,1.0000f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.7178f,0.1118f,0.0408f,-0.6860f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[-0.1131f,-0.6941f,0.7100f,-0.0369f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.0986f,0.0013f,-0.0130f,-0.9950f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0130f,-0.9950f,0.0986f,0.0013f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3850f,0.8652f,0.1071f],left_rotation:[0.1098f,-0.1564f,0.8146f,0.5476f]}}
particle minecraft:cloud -68.46 69.49 -31.74 0.35 0.18 0.35 0.02 2 force
particle minecraft:cloud -67.60 69.49 -30.31 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -67.60 69.29 -30.31 -0.037 0.02 0.022 1 0 force
scoreboard players set #gx driftmountains -73490
scoreboard players set #gdx driftmountains 666
scoreboard players set #gy driftmountains 69263
scoreboard players set #gdy driftmountains -9
scoreboard players set #gz driftmountains -30666
scoreboard players set #gdz driftmountains -308
scoreboard players set #gr driftmountains -12155
scoreboard players set #gdr driftmountains 197
scoreboard players set #gp driftmountains 72
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[-0.0039f,0.0000f,0.0041f,1.0000f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.3867f,-0.0385f,0.0731f,0.9185f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.0230f,0.9158f,0.3929f,0.0794f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.0986f,0.0013f,-0.0130f,-0.9950f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0130f,-0.9950f,0.0986f,0.0013f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3573f,0.8591f,0.2448f],left_rotation:[0.1526f,-0.1100f,0.5422f,0.8189f]}}
scoreboard players set #gx driftmountains -78544
scoreboard players set #gdx driftmountains 652
scoreboard players set #gy driftmountains 69339
scoreboard players set #gdy driftmountains -10
scoreboard players set #gz driftmountains -27297
scoreboard players set #gdz driftmountains -226
scoreboard players set #gr driftmountains -12638
scoreboard players set #gdr driftmountains -422
scoreboard players set #gp driftmountains 83
scoreboard players set #gdp driftmountains -4
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,0.0000f,0.0111f,0.9999f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.9493f,0.0222f,0.1057f,0.2953f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[-0.0752f,0.2859f,0.9522f,0.0775f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.0986f,0.0013f,-0.0130f,-0.9950f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0130f,-0.9950f,0.0986f,0.0013f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3796f,0.8664f,0.1075f],left_rotation:[0.1263f,-0.1443f,0.7472f,0.6362f]}}
particle minecraft:cloud -80.05 69.66 -27.22 0.35 0.18 0.35 0.02 2 force
particle minecraft:cloud -79.06 69.66 -25.88 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -79.06 69.46 -25.88 -0.034 0.02 0.025 1 0 force
