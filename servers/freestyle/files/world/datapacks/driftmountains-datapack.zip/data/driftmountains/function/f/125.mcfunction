scoreboard players set #gx driftmountains 7506
scoreboard players set #gdx driftmountains 462
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains -13560
scoreboard players set #gdz driftmountains 802
scoreboard players set #gr driftmountains 992
scoreboard players set #gdr driftmountains -61
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.8965f,-0.0480f,-0.3391f,-0.2811f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.3114f,-0.2470f,0.9065f,0.1425f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.9529f,0.0125f,0.0040f,0.3030f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0040f,0.3030f,0.9529f,0.0125f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3523f,0.8428f,0.0983f],left_rotation:[-0.1872f,0.0065f,0.0001f,-0.9822f]}}
particle minecraft:cloud 8.55 71.32 -14.66 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 8.55 71.12 -14.66 0.010 0.02 -0.055 1 0 force
particle minecraft:cloud 6.90 71.32 -14.94 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains 4707
scoreboard players set #gdx driftmountains 422
scoreboard players set #gy driftmountains 70699
scoreboard players set #gdy driftmountains 62
scoreboard players set #gz driftmountains -18770
scoreboard players set #gdz driftmountains 720
scoreboard players set #gr driftmountains 1327
scoreboard players set #gdr driftmountains 86
scoreboard players set #gp driftmountains -309
scoreboard players set #gdp driftmountains 5
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.8663f,0.1816f,-0.2865f,0.3667f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.3266f,0.3988f,0.8520f,-0.0915f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.9529f,0.0125f,0.0040f,0.3030f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0040f,0.3030f,0.9529f,0.0125f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3623f,0.8348f,0.2353f],left_rotation:[-0.1800f,0.0111f,-0.0315f,-0.9831f]}}
particle minecraft:cloud 5.85 71.02 -19.90 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 5.85 70.82 -19.90 0.012 0.02 -0.050 1 0 force
particle minecraft:cloud 4.19 71.02 -20.30 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains 1315
scoreboard players set #gdx driftmountains 604
scoreboard players set #gy driftmountains 70485
scoreboard players set #gdy driftmountains -3
scoreboard players set #gz driftmountains -22536
scoreboard players set #gdz driftmountains 544
scoreboard players set #gr driftmountains -409
scoreboard players set #gdr driftmountains 264
scoreboard players set #gp driftmountains 35
scoreboard players set #gdp driftmountains -42
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.6970f,-0.1764f,-0.2744f,-0.6386f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.2088f,-0.6132f,0.7194f,0.2506f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.9529f,0.0125f,0.0040f,0.3030f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0040f,0.3030f,0.9529f,0.0125f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3533f,0.8500f,0.1011f],left_rotation:[-0.1858f,0.0357f,-0.1558f,-0.9695f]}}
particle minecraft:cloud 2.06 70.81 -23.85 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 2.06 70.61 -23.85 -0.004 0.02 -0.051 1 0 force
particle minecraft:cloud 0.39 70.81 -23.73 0.35 0.18 0.35 0.02 3 force
