scoreboard players set #gx driftmountains -34357
scoreboard players set #gdx driftmountains -1164
scoreboard players set #gy driftmountains 70724
scoreboard players set #gdy driftmountains -41
scoreboard players set #gz driftmountains 52883
scoreboard players set #gdz driftmountains -394
scoreboard players set #gr driftmountains 15544
scoreboard players set #gdr driftmountains -8
scoreboard players set #gp driftmountains 133
scoreboard players set #gdp driftmountains -1
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.5890f,-0.2647f,-0.2958f,-0.7039f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.2234f,-0.6767f,0.6201f,0.3281f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.0258f,0.0003f,-0.0131f,-0.9996f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0131f,-0.9996f,0.0258f,0.0003f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3661f,0.8233f,0.0906f],left_rotation:[-0.1576f,-0.0888f,0.5041f,-0.8444f]}}
particle minecraft:cloud -34.59 71.04 54.38 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -34.59 70.84 54.38 0.031 0.02 0.067 1 0 force
particle minecraft:cloud -33.07 71.04 53.68 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -24531
scoreboard players set #gdx driftmountains -1125
scoreboard players set #gy driftmountains 70995
scoreboard players set #gdy driftmountains -12
scoreboard players set #gz driftmountains 56144
scoreboard players set #gdz driftmountains -340
scoreboard players set #gr driftmountains 15259
scoreboard players set #gdr driftmountains 26
scoreboard players set #gp driftmountains 26
scoreboard players set #gdp driftmountains 34
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.9202f,0.0349f,-0.3863f,-0.0522f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.3830f,-0.0119f,0.9216f,0.0616f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.0258f,0.0003f,-0.0131f,-0.9996f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0131f,-0.9996f,0.0258f,0.0003f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3843f,0.8274f,0.2324f],left_rotation:[-0.1601f,-0.0786f,0.4256f,-0.8872f]}}
particle minecraft:cloud -24.66 71.32 57.75 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -24.66 71.12 57.75 0.033 0.02 0.063 1 0 force
particle minecraft:cloud -23.14 71.32 56.96 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -19929
scoreboard players set #gdx driftmountains -1056
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 57645
scoreboard players set #gdz driftmountains -295
scoreboard players set #gr driftmountains 15156
scoreboard players set #gdr driftmountains 15
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.2768f,0.3865f,-0.0624f,0.8776f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.1549f,0.8889f,0.2377f,-0.3596f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.0258f,0.0003f,-0.0131f,-0.9996f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0131f,-0.9996f,0.0258f,0.0003f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3638f,0.8245f,0.0911f],left_rotation:[-0.1628f,-0.0800f,0.4580f,-0.8702f]}}
particle minecraft:cloud -20.06 71.32 59.15 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -20.06 71.12 59.15 0.034 0.02 0.062 1 0 force
particle minecraft:cloud -18.60 71.32 58.36 0.35 0.18 0.35 0.02 3 force
