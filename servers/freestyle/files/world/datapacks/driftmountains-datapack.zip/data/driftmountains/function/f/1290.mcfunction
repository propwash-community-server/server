scoreboard players set #gx driftmountains -56026
scoreboard players set #gdx driftmountains 210
scoreboard players set #gy driftmountains 67988
scoreboard players set #gdy driftmountains -15
scoreboard players set #gz driftmountains -73996
scoreboard players set #gdz driftmountains -580
scoreboard players set #gr driftmountains -12748
scoreboard players set #gdr driftmountains 178
scoreboard players set #gp driftmountains 124
scoreboard players set #gdp driftmountains -13
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.1972f,-0.1950f,-0.0949f,-0.9561f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[-0.0051f,-0.9514f,0.2188f,0.2168f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.2712f,0.0036f,-0.0126f,-0.9624f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0126f,-0.9624f,0.2712f,0.0036f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3946f,0.8594f,0.1048f],left_rotation:[-0.0712f,0.1749f,-0.9209f,-0.3410f]}}
particle minecraft:cloud -57.53 68.31 -73.89 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -57.53 68.11 -73.89 -0.029 0.02 0.022 1 0 force
particle minecraft:cloud -56.52 68.31 -72.57 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -55935
scoreboard players set #gdx driftmountains -30
scoreboard players set #gy driftmountains 68117
scoreboard players set #gdy driftmountains -11
scoreboard players set #gz driftmountains -69429
scoreboard players set #gdz driftmountains -509
scoreboard players set #gr driftmountains -14932
scoreboard players set #gdr driftmountains 142
scoreboard players set #gp driftmountains 99
scoreboard players set #gdp driftmountains 2
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[0.0061f,0.0001f,-0.0210f,0.9998f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.8436f,0.1646f,-0.1812f,0.4779f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.2324f,0.4996f,0.8310f,-0.0768f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.2712f,0.0036f,-0.0126f,-0.9624f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0126f,-0.9624f,0.2712f,0.0036f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3691f,0.8716f,0.2497f],left_rotation:[-0.1091f,0.1582f,-0.7957f,-0.5744f]}}
particle minecraft:cloud -57.37 68.44 -68.69 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -57.37 68.24 -68.69 -0.022 0.02 0.037 1 0 force
particle minecraft:cloud -55.90 68.44 -67.82 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -54841
scoreboard players set #gdx driftmountains -81
scoreboard players set #gy driftmountains 68240
scoreboard players set #gdy driftmountains -12
scoreboard players set #gz driftmountains -62740
scoreboard players set #gdz driftmountains -752
scoreboard players set #gr driftmountains -17732
scoreboard players set #gdr driftmountains 390
scoreboard players set #gp driftmountains 91
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[-0.0012f,-0.0000f,-0.0055f,1.0000f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.9545f,0.0304f,-0.0815f,-0.2852f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.0520f,-0.2782f,0.9566f,0.0698f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.2712f,0.0036f,-0.0126f,-0.9624f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0126f,-0.9624f,0.2712f,0.0036f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3703f,0.8218f,0.0900f],left_rotation:[0.1476f,0.1033f,-0.5796f,0.7947f]}}
