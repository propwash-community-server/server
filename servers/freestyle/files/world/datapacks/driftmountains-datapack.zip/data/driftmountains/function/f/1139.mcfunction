scoreboard players set #gx driftmountains -92197
scoreboard players set #gdx driftmountains -663
scoreboard players set #gy driftmountains 69996
scoreboard players set #gdy driftmountains 4
scoreboard players set #gz driftmountains 7329
scoreboard players set #gdz driftmountains -827
scoreboard players set #gr driftmountains -17495
scoreboard players set #gdr driftmountains 272
scoreboard players set #gp driftmountains -16
scoreboard players set #gdp driftmountains -1
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.1623f,-0.3458f,-0.1183f,-0.9166f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.0226f,-0.9092f,0.1996f,0.3648f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.3485f,0.0046f,0.0123f,0.9372f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0123f,0.9372f,0.3485f,0.0046f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3552f,0.8330f,0.0944f],left_rotation:[-0.1811f,-0.0349f,0.2204f,-0.9578f]}}
particle minecraft:cloud -93.14 70.32 8.51 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -93.14 70.12 8.51 -0.006 0.02 0.064 1 0 force
particle minecraft:cloud -91.48 70.32 8.66 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -86403
scoreboard players set #gdx driftmountains -734
scoreboard players set #gy driftmountains 69990
scoreboard players set #gdy driftmountains -4
scoreboard players set #gz driftmountains 14395
scoreboard players set #gdz driftmountains -856
scoreboard players set #gr driftmountains 17507
scoreboard players set #gdr driftmountains 32
scoreboard players set #gp driftmountains 22
scoreboard players set #gdp driftmountains -8
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[0.0061f,0.0001f,-0.0218f,0.9997f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.7978f,-0.1197f,-0.2856f,-0.5173f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.2328f,-0.4901f,0.8148f,0.2042f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.3485f,0.0046f,0.0123f,0.9372f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0123f,0.9372f,0.3485f,0.0046f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3560f,0.8468f,0.2400f],left_rotation:[-0.1723f,0.0649f,-0.3085f,-0.9333f]}}
particle minecraft:cloud -87.14 70.31 15.83 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -87.14 70.11 15.83 0.006 0.02 0.067 1 0 force
particle minecraft:cloud -85.43 70.31 15.68 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -82312
scoreboard players set #gdx driftmountains -735
scoreboard players set #gy driftmountains 70044
scoreboard players set #gdy driftmountains -14
scoreboard players set #gz driftmountains 18659
scoreboard players set #gdz driftmountains -816
scoreboard players set #gr driftmountains 17421
scoreboard players set #gdr driftmountains 13
scoreboard players set #gp driftmountains 59
scoreboard players set #gdp driftmountains -5
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.6971f,0.2496f,-0.1886f,0.6452f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.2575f,0.6686f,0.6747f,-0.1777f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.3485f,0.0046f,0.0123f,0.9372f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0123f,0.9372f,0.3485f,0.0046f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3558f,0.8554f,0.1032f],left_rotation:[-0.1812f,0.0588f,-0.2803f,-0.9408f]}}
particle minecraft:cloud -83.02 70.36 20.00 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -83.02 70.16 20.00 0.007 0.02 0.069 1 0 force
particle minecraft:cloud -81.35 70.36 19.83 0.35 0.18 0.35 0.02 3 force
