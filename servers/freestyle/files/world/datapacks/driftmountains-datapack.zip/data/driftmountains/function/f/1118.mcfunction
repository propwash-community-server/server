scoreboard players set #gx driftmountains -75565
scoreboard players set #gdx driftmountains -911
scoreboard players set #gy driftmountains 70220
scoreboard players set #gdy driftmountains -26
scoreboard players set #gz driftmountains 26800
scoreboard players set #gdz driftmountains -1016
scoreboard players set #gr driftmountains 17762
scoreboard players set #gdr driftmountains 8
scoreboard players set #gp driftmountains 83
scoreboard players set #gdp driftmountains -1
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.5379f,0.3054f,-0.1450f,0.7723f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.2270f,0.7918f,0.5087f,-0.2506f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.9293f,0.0122f,0.0048f,0.3691f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0048f,0.3691f,0.9293f,0.0122f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3523f,0.8448f,0.0991f],left_rotation:[-0.1873f,0.0145f,-0.0421f,-0.9812f]}}
particle minecraft:cloud -76.35 70.54 28.09 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -76.35 70.34 28.09 0.003 0.02 0.082 1 0 force
particle minecraft:cloud -74.68 70.54 28.02 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -67714
scoreboard players set #gdx driftmountains -985
scoreboard players set #gy driftmountains 70419
scoreboard players set #gdy driftmountains -23
scoreboard players set #gz driftmountains 34477
scoreboard players set #gdz driftmountains -977
scoreboard players set #gr driftmountains 17839
scoreboard players set #gdr driftmountains -45
scoreboard players set #gp driftmountains 67
scoreboard players set #gdp driftmountains 4
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.1906f,-0.3446f,-0.1296f,-0.9100f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.0347f,-0.9014f,0.2279f,0.3666f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.9293f,0.0122f,0.0048f,0.3691f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0048f,0.3691f,0.9293f,0.0122f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3745f,0.8279f,0.2326f],left_rotation:[-0.1730f,-0.0432f,0.2461f,-0.9527f]}}
particle minecraft:cloud -68.53 70.74 35.87 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -68.53 70.54 35.87 0.002 0.02 0.082 1 0 force
particle minecraft:cloud -66.82 70.74 35.82 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -63843
scoreboard players set #gdx driftmountains -963
scoreboard players set #gy driftmountains 70493
scoreboard players set #gdy driftmountains -15
scoreboard players set #gz driftmountains 38356
scoreboard players set #gdz driftmountains -914
scoreboard players set #gr driftmountains -17983
scoreboard players set #gdr driftmountains 62
scoreboard players set #gp driftmountains 38
scoreboard players set #gdp driftmountains 9
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0001f,-0.0223f,0.9997f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.9235f,0.0403f,-0.3794f,-0.0398f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.3773f,-0.0001f,0.9244f,0.0566f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.9293f,0.0122f,0.0048f,0.3691f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0048f,0.3691f,0.9293f,0.0122f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3599f,0.8273f,0.0922f],left_rotation:[-0.1712f,-0.0631f,0.3690f,-0.9113f]}}
particle minecraft:cloud -64.68 70.81 39.61 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -64.68 70.61 39.61 -0.000 0.02 0.080 1 0 force
particle minecraft:cloud -63.01 70.81 39.62 0.35 0.18 0.35 0.02 3 force
