scoreboard players set #gx driftmountains 27241
scoreboard players set #gdx driftmountains 140
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 31342
scoreboard players set #gdz driftmountains 1021
scoreboard players set #gr driftmountains 4368
scoreboard players set #gdr driftmountains 358
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[0.0061f,0.0001f,-0.0223f,0.9997f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.7482f,-0.1835f,-0.3603f,-0.5260f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.3070f,-0.4910f,0.7716f,0.2631f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.0993f,0.0013f,-0.0130f,-0.9950f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0130f,-0.9950f,0.0993f,0.0013f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3695f,0.8220f,0.0901f],left_rotation:[-0.1496f,-0.1006f,0.5654f,-0.8048f]}}
particle minecraft:cloud 28.72 71.32 31.01 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 28.72 71.12 31.01 0.043 0.02 -0.045 1 0 force
particle minecraft:cloud 27.51 71.32 29.85 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains 26039
scoreboard players set #gdx driftmountains 424
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 24299
scoreboard players set #gdz driftmountains 820
scoreboard players set #gr driftmountains 1472
scoreboard players set #gdr driftmountains 586
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[0.0012f,0.0000f,-0.0223f,0.9997f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.9327f,0.1154f,-0.2775f,0.1995f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.3000f,0.2298f,0.9257f,-0.0180f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.0993f,0.0013f,-0.0130f,-0.9950f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0130f,-0.9950f,0.0993f,0.0013f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3557f,0.8510f,0.2416f],left_rotation:[-0.1670f,0.0806f,-0.3894f,-0.9023f]}}
particle minecraft:cloud 27.21 71.32 23.20 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 27.21 71.12 23.20 0.014 0.02 -0.053 1 0 force
particle minecraft:cloud 25.56 71.32 22.76 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains 22805
scoreboard players set #gdx driftmountains 339
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 19644
scoreboard players set #gdz driftmountains 974
scoreboard players set #gr driftmountains 1224
scoreboard players set #gdr driftmountains 319
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0001f,-0.0200f,0.9998f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.0341f,0.2540f,0.0452f,0.9655f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.0561f,0.9661f,0.0076f,-0.2518f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.0993f,0.0013f,-0.0130f,-0.9950f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0130f,-0.9950f,0.0993f,0.0013f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3774f,0.8666f,0.1076f],left_rotation:[-0.1324f,0.1390f,-0.7177f,-0.6693f]}}
particle minecraft:cloud 23.89 71.32 18.59 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 23.89 71.12 18.59 0.013 0.02 -0.061 1 0 force
particle minecraft:cloud 22.26 71.32 18.24 0.35 0.18 0.35 0.02 3 force
