scoreboard players set #gx driftmountains -22714
scoreboard players set #gdx driftmountains 697
scoreboard players set #gy driftmountains 67182
scoreboard players set #gdy driftmountains -11
scoreboard players set #gz driftmountains -85899
scoreboard players set #gdz driftmountains 398
scoreboard players set #gr driftmountains -3203
scoreboard players set #gdr driftmountains 31
scoreboard players set #gp driftmountains 66
scoreboard players set #gdp driftmountains -1
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.9301f,-0.0153f,-0.2384f,-0.2788f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.2104f,-0.2553f,0.9369f,0.1131f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.8132f,0.0106f,-0.0076f,-0.5818f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0076f,-0.5818f,0.8132f,0.0106f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3862f,0.8648f,0.1069f],left_rotation:[-0.1060f,0.1587f,-0.8280f,-0.5272f]}}
particle minecraft:cloud -22.67 67.50 -87.41 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -22.67 67.30 -87.41 -0.025 0.02 -0.041 1 0 force
particle minecraft:cloud -24.09 67.50 -86.52 0.35 0.18 0.35 0.02 2 force
playsound driftgen:grain.kaze.034 neutral @a -17.03 67.60 -82.50 12 1
scoreboard players set #gx driftmountains -28974
scoreboard players set #gdx driftmountains 667
scoreboard players set #gy driftmountains 67279
scoreboard players set #gdy driftmountains -11
scoreboard players set #gz driftmountains -88946
scoreboard players set #gdz driftmountains 336
scoreboard players set #gr driftmountains -3378
scoreboard players set #gdr driftmountains 26
scoreboard players set #gp driftmountains 75
scoreboard players set #gdp driftmountains -1
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0001f,-0.0182f,0.9998f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.8557f,-0.0641f,-0.2343f,-0.4570f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.1876f,-0.4349f,0.8671f,0.1543f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.8132f,0.0106f,-0.0076f,-0.5818f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0076f,-0.5818f,0.8132f,0.0106f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3699f,0.8720f,0.2498f],left_rotation:[-0.1065f,0.1601f,-0.8059f,-0.5600f]}}
particle minecraft:cloud -29.02 67.60 -90.56 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -29.02 67.40 -90.56 -0.024 0.02 -0.037 1 0 force
particle minecraft:cloud -30.44 67.60 -89.61 0.35 0.18 0.35 0.02 2 force
playsound driftgen:grain.onyx.045 neutral @a -23.48 67.69 -85.99 12 1
scoreboard players set #gx driftmountains -35276
scoreboard players set #gdx driftmountains 655
scoreboard players set #gy driftmountains 67399
scoreboard players set #gdy driftmountains -13
scoreboard players set #gz driftmountains -91945
scoreboard players set #gdz driftmountains 181
scoreboard players set #gr driftmountains -4133
scoreboard players set #gdr driftmountains 81
scoreboard players set #gp driftmountains 89
scoreboard players set #gdp driftmountains 2
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0001f,-0.0206f,0.9998f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.5938f,-0.1470f,-0.1812f,-0.7700f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.1013f,-0.7552f,0.6126f,0.2102f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.8132f,0.0106f,-0.0076f,-0.5818f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0076f,-0.5818f,0.8132f,0.0106f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3885f,0.8638f,0.1065f],left_rotation:[-0.0977f,0.1635f,-0.8550f,-0.4824f]}}
particle minecraft:cloud -35.48 67.72 -93.44 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -35.48 67.52 -93.44 -0.024 0.02 -0.027 1 0 force
particle minecraft:cloud -36.74 67.72 -92.34 0.35 0.18 0.35 0.02 3 force
playsound driftgen:grain.kaze.043 neutral @a -30.36 67.81 -90.19 12 1
