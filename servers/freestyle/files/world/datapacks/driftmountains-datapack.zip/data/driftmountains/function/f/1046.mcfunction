scoreboard players set #gx driftmountains 2681
scoreboard players set #gdx driftmountains -1035
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 63275
scoreboard players set #gdz driftmountains -8
scoreboard players set #gr driftmountains 14657
scoreboard players set #gdr driftmountains 116
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.5212f,0.3790f,-0.1966f,0.7389f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.2754f,0.7637f,0.4843f,-0.3263f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.9796f,0.0128f,0.0026f,0.2007f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0026f,0.2007f,0.9796f,0.0128f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3805f,0.8212f,0.0898f],left_rotation:[-0.1203f,-0.1329f,0.7324f,-0.6568f]}}
particle minecraft:cloud 2.68 71.32 64.79 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 2.68 71.12 64.79 0.034 0.02 0.052 1 0 force
particle minecraft:cloud 4.07 71.32 63.87 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains 10121
scoreboard players set #gdx driftmountains -932
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 59816
scoreboard players set #gdz driftmountains 332
scoreboard players set #gr driftmountains 13041
scoreboard players set #gdr driftmountains 286
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.1776f,-0.4286f,-0.1470f,-0.8736f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.0560f,-0.8629f,0.2236f,0.4497f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.9796f,0.0128f,0.0026f,0.2007f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0026f,0.2007f,0.9796f,0.0128f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.4061f,0.8479f,0.2404f],left_rotation:[-0.0762f,-0.1691f,0.8783f,-0.4408f]}}
particle minecraft:cloud 10.61 71.32 61.35 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 10.61 71.12 61.35 0.045 0.02 0.038 1 0 force
particle minecraft:cloud 11.71 71.32 60.05 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains 16234
scoreboard players set #gdx driftmountains -762
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 58331
scoreboard players set #gdz driftmountains 590
scoreboard players set #gr driftmountains 11041
scoreboard players set #gdr driftmountains 289
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.8892f,0.0368f,-0.4541f,-0.0429f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.4521f,0.0045f,0.8902f,0.0564f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.9796f,0.0128f,0.0026f,0.2007f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0026f,0.2007f,0.9796f,0.0128f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3932f,0.8269f,0.0920f],left_rotation:[-0.0738f,-0.1641f,0.8901f,-0.4187f]}}
particle minecraft:cloud 17.12 71.32 59.55 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 17.12 71.12 59.55 0.059 0.02 0.022 1 0 force
particle minecraft:cloud 17.71 71.32 57.99 0.35 0.18 0.35 0.02 3 force
