scoreboard players set #gx driftmountains 10755
scoreboard players set #gdx driftmountains 459
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains -7780
scoreboard players set #gdz driftmountains 861
scoreboard players set #gr driftmountains 1007
scoreboard players set #gdr driftmountains 34
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.9455f,0.0422f,-0.3206f,-0.0386f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.3183f,-0.0051f,0.9463f,0.0570f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.8327f,0.0109f,0.0072f,0.5536f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0072f,0.5536f,0.8327f,0.0109f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3537f,0.8512f,0.1016f],left_rotation:[-0.1851f,0.0407f,-0.1824f,-0.9647f]}}
particle minecraft:cloud 11.80 71.32 -8.87 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 11.80 71.12 -8.87 0.010 0.02 -0.057 1 0 force
particle minecraft:cloud 10.15 71.32 -9.17 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains 7676
scoreboard players set #gdx driftmountains 440
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains -13311
scoreboard players set #gdz driftmountains 824
scoreboard players set #gr driftmountains 1087
scoreboard players set #gdr driftmountains -51
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.7328f,0.2519f,-0.2239f,0.5911f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.2873f,0.6179f,0.7104f,-0.1763f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.8327f,0.0109f,0.0072f,0.5536f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0072f,0.5536f,0.8327f,0.0109f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3616f,0.8355f,0.2356f],left_rotation:[-0.1799f,0.0151f,-0.0521f,-0.9822f]}}
particle minecraft:cloud 8.77 71.32 -14.49 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 8.77 71.12 -14.49 0.011 0.02 -0.055 1 0 force
particle minecraft:cloud 7.09 71.32 -14.81 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains 5074
scoreboard players set #gdx driftmountains 386
scoreboard players set #gy driftmountains 70768
scoreboard players set #gdy driftmountains 53
scoreboard players set #gz driftmountains -17913
scoreboard players set #gdz driftmountains 656
scoreboard players set #gr driftmountains 1253
scoreboard players set #gdr driftmountains 1
scoreboard players set #gp driftmountains -306
scoreboard players set #gdp driftmountains 27
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.9077f,-0.0333f,-0.3413f,-0.2416f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.3178f,-0.2071f,0.9162f,0.1289f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.8327f,0.0109f,0.0072f,0.5536f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0072f,0.5536f,0.8327f,0.0109f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3523f,0.8426f,0.0982f],left_rotation:[-0.1872f,0.0057f,0.0046f,-0.9822f]}}
particle minecraft:cloud 6.16 71.09 -18.96 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 6.16 70.89 -18.96 0.011 0.02 -0.050 1 0 force
particle minecraft:cloud 4.53 71.09 -19.32 0.35 0.18 0.35 0.02 3 force
