scoreboard players set #gx driftmountains -97249
scoreboard players set #gdx driftmountains 272
scoreboard players set #gy driftmountains 69904
scoreboard players set #gdy driftmountains -16
scoreboard players set #gz driftmountains -14733
scoreboard players set #gdz driftmountains -687
scoreboard players set #gr driftmountains -11054
scoreboard players set #gdr driftmountains 314
scoreboard players set #gp driftmountains 77
scoreboard players set #gdp driftmountains 3
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[-0.0035f,-0.0001f,-0.0223f,0.9997f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.9239f,0.1218f,-0.3034f,0.1988f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.3260f,0.2317f,0.9162f,-0.0254f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.2290f,0.0030f,-0.0127f,-0.9733f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0127f,-0.9733f,0.2290f,0.0030f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3532f,0.8497f,0.1010f],left_rotation:[-0.1860f,0.0343f,-0.1485f,-0.9706f]}}
particle minecraft:cloud -98.72 70.22 -15.07 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -98.72 70.02 -15.07 -0.041 0.02 0.016 1 0 force
particle minecraft:cloud -98.14 70.22 -13.51 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -98170
scoreboard players set #gdx driftmountains -17
scoreboard players set #gy driftmountains 70015
scoreboard players set #gdy driftmountains -7
scoreboard players set #gz driftmountains -7483
scoreboard players set #gdz driftmountains -827
scoreboard players set #gr driftmountains -13298
scoreboard players set #gdr driftmountains 186
scoreboard players set #gp driftmountains 30
scoreboard players set #gdp driftmountains 6
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.9194f,0.1098f,-0.3514f,0.1386f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.3679f,0.1763f,0.9129f,-0.0138f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.2290f,0.0030f,-0.0127f,-0.9733f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0127f,-0.9733f,0.2290f,0.0030f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3745f,0.8279f,0.2326f],left_rotation:[-0.1731f,-0.0431f,0.2458f,-0.9528f]}}
particle minecraft:cloud -99.75 70.34 -7.18 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -99.75 70.14 -7.18 -0.036 0.02 0.034 1 0 force
particle minecraft:cloud -98.59 70.34 -5.93 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -97508
scoreboard players set #gdx driftmountains -184
scoreboard players set #gy driftmountains 70034
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains -2329
scoreboard players set #gdz driftmountains -812
scoreboard players set #gr driftmountains -14236
scoreboard players set #gdr driftmountains 166
scoreboard players set #gp driftmountains -1
scoreboard players set #gdp driftmountains 3
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[0.0061f,0.0001f,-0.0223f,0.9997f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.2770f,0.3827f,-0.0611f,0.8792f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.1539f,0.8905f,0.2383f,-0.3557f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.2290f,0.0030f,-0.0127f,-0.9733f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0127f,-0.9733f,0.2290f,0.0030f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3622f,0.8255f,0.0915f],left_rotation:[-0.1663f,-0.0734f,0.4232f,-0.8875f]}}
particle minecraft:cloud -98.94 70.35 -1.84 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -98.94 70.15 -1.84 -0.033 0.02 0.043 1 0 force
particle minecraft:cloud -97.62 70.35 -0.82 0.35 0.18 0.35 0.02 3 force
