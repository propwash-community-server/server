scoreboard players set #gx driftmountains -49525
scoreboard players set #gdx driftmountains 510
scoreboard players set #gy driftmountains 67752
scoreboard players set #gdy driftmountains -12
scoreboard players set #gz driftmountains -85111
scoreboard players set #gdz driftmountains -556
scoreboard players set #gr driftmountains -10497
scoreboard players set #gdr driftmountains 150
scoreboard players set #gp driftmountains 76
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0001f,-0.0202f,0.9998f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.4797f,0.2408f,-0.0753f,0.8404f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.1640f,0.8529f,0.4570f,-0.1917f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.5504f,0.0072f,-0.0109f,-0.8348f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0109f,-0.8348f,0.5504f,0.0072f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3801f,0.8664f,0.1075f],left_rotation:[-0.1250f,0.1454f,-0.7531f,-0.6293f]}}
particle minecraft:cloud -50.96 68.07 -85.59 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -50.96 67.87 -85.59 -0.044 0.02 0.012 1 0 force
particle minecraft:cloud -50.53 68.07 -83.98 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -52496
scoreboard players set #gdx driftmountains 388
scoreboard players set #gy driftmountains 67837
scoreboard players set #gdy driftmountains -13
scoreboard players set #gz driftmountains -80868
scoreboard players set #gdz driftmountains -676
scoreboard players set #gr driftmountains -11753
scoreboard players set #gdr driftmountains 188
scoreboard players set #gp driftmountains 82
scoreboard players set #gdp driftmountains -2
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0001f,-0.0204f,0.9998f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.2492f,0.2487f,-0.0104f,0.9359f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.1088f,0.9422f,0.2244f,-0.2239f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.5504f,0.0072f,-0.0109f,-0.8348f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0109f,-0.8348f,0.5504f,0.0072f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3674f,0.8706f,0.2493f],left_rotation:[-0.1147f,0.1538f,-0.7723f,-0.6057f]}}
particle minecraft:cloud -54.10 68.16 -81.00 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -54.10 67.96 -81.00 -0.039 0.02 0.020 1 0 force
particle minecraft:cloud -53.31 68.16 -79.48 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -54016
scoreboard players set #gdx driftmountains 234
scoreboard players set #gy driftmountains 67939
scoreboard players set #gdy driftmountains -14
scoreboard players set #gz driftmountains -75601
scoreboard players set #gdz driftmountains -582
scoreboard players set #gr driftmountains -12717
scoreboard players set #gdr driftmountains 27
scoreboard players set #gp driftmountains 109
scoreboard players set #gdp driftmountains -5
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0001f,-0.0191f,0.9998f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.4328f,-0.1976f,-0.1593f,-0.8650f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.0693f,-0.8531f,0.4559f,0.2442f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.5504f,0.0072f,-0.0109f,-0.8348f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0109f,-0.8348f,0.5504f,0.0072f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3794f,0.8664f,0.1075f],left_rotation:[-0.1270f,0.1437f,-0.7438f,-0.6403f]}}
particle minecraft:cloud -55.52 68.26 -75.51 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -55.52 68.06 -75.51 -0.032 0.02 0.024 1 0 force
particle minecraft:cloud -54.52 68.26 -74.17 0.35 0.18 0.35 0.02 3 force
