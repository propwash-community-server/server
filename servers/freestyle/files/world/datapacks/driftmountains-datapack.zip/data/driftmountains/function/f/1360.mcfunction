scoreboard players set #gx driftmountains -17027
scoreboard players set #gdx driftmountains 731
scoreboard players set #gy driftmountains 67098
scoreboard players set #gdy driftmountains -10
scoreboard players set #gz driftmountains -82499
scoreboard players set #gdz driftmountains 455
scoreboard players set #gr driftmountains -3213
scoreboard players set #gdr driftmountains -63
scoreboard players set #gp driftmountains 62
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0001f,-0.0159f,0.9999f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.6342f,-0.1321f,-0.1840f,-0.7392f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.1074f,-0.7240f,0.6516f,0.1995f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.0778f,0.0010f,0.0130f,0.9969f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0130f,0.9969f,0.0778f,0.0010f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3912f,0.8622f,0.1059f],left_rotation:[-0.0870f,0.1687f,-0.8847f,-0.4256f]}}
particle minecraft:cloud -16.99 67.42 -84.01 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -16.99 67.22 -84.01 -0.027 0.02 -0.044 1 0 force
particle minecraft:cloud -18.40 67.42 -83.12 0.35 0.18 0.35 0.02 2 force
scoreboard players set #gx driftmountains -23477
scoreboard players set #gdx driftmountains 667
scoreboard players set #gy driftmountains 67191
scoreboard players set #gdy driftmountains -10
scoreboard players set #gz driftmountains -85986
scoreboard players set #gdz driftmountains 388
scoreboard players set #gr driftmountains -3153
scoreboard players set #gdr driftmountains 33
scoreboard players set #gp driftmountains 67
scoreboard players set #gdp driftmountains -1
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0001f,-0.0174f,0.9998f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.8732f,-0.0536f,-0.2333f,-0.4245f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.1899f,-0.4024f,0.8836f,0.1456f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.0778f,0.0010f,0.0130f,0.9969f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0130f,0.9969f,0.0778f,0.0010f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3715f,0.8726f,0.2501f],left_rotation:[-0.1015f,0.1636f,-0.8247f,-0.5319f]}}
particle minecraft:cloud -23.46 67.51 -87.60 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -23.46 67.31 -87.60 -0.026 0.02 -0.042 1 0 force
particle minecraft:cloud -24.92 67.51 -86.70 0.35 0.18 0.35 0.02 2 force
scoreboard players set #gx driftmountains -30357
scoreboard players set #gdx driftmountains 615
scoreboard players set #gy driftmountains 67307
scoreboard players set #gdy driftmountains -10
scoreboard players set #gz driftmountains -90194
scoreboard players set #gdz driftmountains 275
scoreboard players set #gr driftmountains -3601
scoreboard players set #gdr driftmountains 56
scoreboard players set #gp driftmountains 77
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0001f,-0.0185f,0.9998f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.8038f,0.1752f,-0.1626f,0.5447f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.2208f,0.5648f,0.7898f,-0.0917f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.0778f,0.0010f,0.0130f,0.9969f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0130f,0.9969f,0.0778f,0.0010f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3861f,0.8649f,0.1069f],left_rotation:[-0.1063f,0.1586f,-0.8270f,-0.5287f]}}
particle minecraft:cloud -30.42 67.63 -91.70 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -30.42 67.43 -91.70 -0.025 0.02 -0.034 1 0 force
particle minecraft:cloud -31.77 67.63 -90.72 0.35 0.18 0.35 0.02 3 force
