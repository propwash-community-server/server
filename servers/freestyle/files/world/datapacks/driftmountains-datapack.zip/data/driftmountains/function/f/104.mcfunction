scoreboard players set #gx driftmountains -4359
scoreboard players set #gdx driftmountains 634
scoreboard players set #gy driftmountains 70411
scoreboard players set #gdy driftmountains 40
scoreboard players set #gz driftmountains -26372
scoreboard players set #gdz driftmountains 442
scoreboard players set #gr driftmountains -950
scoreboard players set #gdr driftmountains 39
scoreboard players set #gp driftmountains -231
scoreboard players set #gdp driftmountains 45
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.4624f,0.3493f,-0.1360f,0.8035f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.2212f,0.8222f,0.4283f,-0.3026f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.8633f,0.0113f,-0.0066f,-0.5045f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0066f,-0.5045f,0.8633f,0.0113f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3577f,0.8295f,0.0930f],left_rotation:[-0.1759f,-0.0515f,0.3082f,-0.9334f]}}
particle minecraft:cloud -3.74 70.73 -27.75 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -3.74 70.53 -27.75 -0.008 0.02 -0.046 1 0 force
particle minecraft:cloud -5.39 70.73 -27.48 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -8238
scoreboard players set #gdx driftmountains 569
scoreboard players set #gy driftmountains 69993
scoreboard players set #gdy driftmountains 55
scoreboard players set #gz driftmountains -29192
scoreboard players set #gdz driftmountains 185
scoreboard players set #gr driftmountains -2701
scoreboard players set #gdr driftmountains 272
scoreboard players set #gp driftmountains -345
scoreboard players set #gdp driftmountains -24
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.7551f,0.2253f,-0.2028f,0.5814f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.2650f,0.6059f,0.7355f,-0.1472f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.8633f,0.0113f,-0.0066f,-0.5045f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0066f,-0.5045f,0.8633f,0.0113f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3557f,0.8498f,0.2411f],left_rotation:[-0.1686f,0.0762f,-0.3668f,-0.9117f]}}
particle minecraft:cloud -8.10 70.31 -30.80 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -8.10 70.11 -30.80 -0.019 0.02 -0.037 1 0 force
particle minecraft:cloud -9.62 70.31 -30.02 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -13376
scoreboard players set #gdx driftmountains 895
scoreboard players set #gy driftmountains 69612
scoreboard players set #gdy driftmountains 64
scoreboard players set #gz driftmountains -29433
scoreboard players set #gdz driftmountains 87
scoreboard players set #gr driftmountains -4002
scoreboard players set #gdr driftmountains 188
scoreboard players set #gp driftmountains -284
scoreboard players set #gdp driftmountains -1
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[0.0042f,0.0001f,-0.0223f,0.9997f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.5000f,-0.2707f,-0.2383f,-0.7874f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.1569f,-0.7666f,0.5312f,0.3248f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.8633f,0.0113f,-0.0066f,-0.5045f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0066f,-0.5045f,0.8633f,0.0113f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3542f,0.8349f,0.0952f],left_rotation:[-0.1831f,-0.0263f,0.1748f,-0.9670f]}}
particle minecraft:cloud -13.55 69.93 -30.93 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -13.55 69.73 -30.93 -0.033 0.02 -0.039 1 0 force
particle minecraft:cloud -14.83 69.93 -29.86 0.35 0.18 0.35 0.02 3 force
