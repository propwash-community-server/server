scoreboard players set #gx driftmountains -98133
scoreboard players set #gdx driftmountains 35
scoreboard players set #gy driftmountains 69997
scoreboard players set #gdy driftmountains -11
scoreboard players set #gz driftmountains -9325
scoreboard players set #gdz driftmountains -829
scoreboard players set #gr driftmountains -12919
scoreboard players set #gdr driftmountains 197
scoreboard players set #gp driftmountains 45
scoreboard players set #gdp driftmountains 8
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.4721f,-0.2878f,-0.2354f,-0.7993f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.1527f,-0.7790f,0.5049f,0.3390f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.0478f,0.0006f,0.0131f,0.9988f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0131f,0.9988f,0.0478f,0.0006f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3569f,0.8305f,0.0935f],left_rotation:[-0.1777f,-0.0462f,0.2800f,-0.9422f]}}
particle minecraft:cloud -99.64 70.32 -9.18 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -99.64 70.12 -9.18 -0.039 0.02 0.032 1 0 force
particle minecraft:cloud -98.58 70.32 -7.88 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -97223
scoreboard players set #gdx driftmountains -211
scoreboard players set #gy driftmountains 70033
scoreboard players set #gdy driftmountains 1
scoreboard players set #gz driftmountains -1468
scoreboard players set #gdz driftmountains -816
scoreboard players set #gr driftmountains -14500
scoreboard players set #gdr driftmountains 173
scoreboard players set #gp driftmountains -4
scoreboard players set #gdp driftmountains 4
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[0.0061f,0.0001f,-0.0223f,0.9997f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.8816f,-0.0615f,-0.3676f,-0.2896f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.3392f,-0.2526f,0.8929f,0.1545f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.0478f,0.0006f,0.0131f,0.9988f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0131f,0.9988f,0.0478f,0.0006f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3767f,0.8275f,0.2324f],left_rotation:[-0.1707f,-0.0514f,0.2879f,-0.9410f]}}
particle minecraft:cloud -98.71 70.35 -0.84 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -98.71 70.15 -0.84 -0.031 0.02 0.044 1 0 force
particle minecraft:cloud -97.31 70.35 0.14 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -95085
scoreboard players set #gdx driftmountains -462
scoreboard players set #gy driftmountains 70016
scoreboard players set #gdy driftmountains 4
scoreboard players set #gz driftmountains 3521
scoreboard players set #gdz driftmountains -802
scoreboard players set #gr driftmountains -16101
scoreboard players set #gdr driftmountains 275
scoreboard players set #gp driftmountains -16
scoreboard players set #gdp driftmountains 1
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.4970f,0.3444f,-0.1521f,0.7818f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.2351f,0.8021f,0.4636f,-0.2941f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.0478f,0.0006f,0.0131f,0.9988f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0131f,0.9988f,0.0478f,0.0006f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3583f,0.8289f,0.0928f],left_rotation:[-0.1747f,-0.0545f,0.3238f,-0.9282f]}}
particle minecraft:cloud -96.28 70.34 4.44 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -96.28 70.14 4.44 -0.018 0.02 0.054 1 0 force
particle minecraft:cloud -94.71 70.34 4.98 0.35 0.18 0.35 0.02 3 force
