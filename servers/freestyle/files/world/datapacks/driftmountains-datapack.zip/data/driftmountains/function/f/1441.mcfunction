scoreboard players set #gx driftmountains 61157
scoreboard players set #gdx driftmountains 1153
scoreboard players set #gy driftmountains 66132
scoreboard players set #gdy driftmountains -13
scoreboard players set #gz driftmountains -31829
scoreboard players set #gdz driftmountains 876
scoreboard players set #gr driftmountains -6950
scoreboard players set #gdr driftmountains -176
scoreboard players set #gp driftmountains 48
scoreboard players set #gdp driftmountains -1
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,0.0000f,0.0102f,0.9999f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.9867f,0.0596f,0.1441f,-0.0455f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[-0.1497f,-0.0609f,0.9859f,0.0438f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.7867f,0.0103f,-0.0081f,-0.6173f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0081f,-0.6173f,0.7867f,0.0103f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3984f,0.8545f,0.1029f],left_rotation:[0.0479f,-0.1810f,0.9579f,0.2175f]}}
particle minecraft:cloud 60.27 66.45 -33.05 0.35 0.18 0.35 0.02 2 force
particle minecraft:cloud 59.68 66.45 -31.49 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke 59.68 66.25 -31.49 -0.081 0.02 -0.030 1 0 force
scoreboard players set #gx driftmountains 53175
scoreboard players set #gdx driftmountains 1259
scoreboard players set #gy driftmountains 66212
scoreboard players set #gdy driftmountains -13
scoreboard players set #gz driftmountains -36133
scoreboard players set #gdz driftmountains 706
scoreboard players set #gr driftmountains -5350
scoreboard players set #gdr driftmountains -518
scoreboard players set #gp driftmountains 50
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0000f,-0.0044f,1.0000f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.8026f,0.0803f,-0.0206f,0.5907f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.0828f,0.5961f,0.7986f,0.0036f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.7867f,0.0103f,-0.0081f,-0.6173f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0081f,-0.6173f,0.7867f,0.0103f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3909f,0.8291f,0.2330f],left_rotation:[0.1476f,0.1014f,-0.5408f,0.8219f]}}
scoreboard players set #gx driftmountains 42462
scoreboard players set #gdx driftmountains 1031
scoreboard players set #gy driftmountains 66327
scoreboard players set #gdy driftmountains -12
scoreboard players set #gz driftmountains -42864
scoreboard players set #gdz driftmountains 802
scoreboard players set #gr driftmountains -3175
scoreboard players set #gdr driftmountains 149
scoreboard players set #gp driftmountains 51
scoreboard players set #gdp driftmountains -1
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0000f,-0.0124f,0.9999f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.9820f,0.0479f,-0.1804f,-0.0291f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.1784f,-0.0103f,0.9824f,0.0551f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.7867f,0.0103f,-0.0081f,-0.6173f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0081f,-0.6173f,0.7867f,0.0103f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.4009f,0.8477f,0.1002f],left_rotation:[-0.0187f,0.1843f,-0.9806f,-0.0635f]}}
particle minecraft:cloud 42.51 66.65 -44.37 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke 42.51 66.45 -44.37 -0.044 0.02 -0.071 1 0 force
particle minecraft:cloud 41.09 66.65 -43.50 0.35 0.18 0.35 0.02 2 force
