scoreboard players set #gx driftmountains -74641
scoreboard players set #gdx driftmountains -924
scoreboard players set #gy driftmountains 70245
scoreboard players set #gdy driftmountains -26
scoreboard players set #gz driftmountains 27824
scoreboard players set #gdz driftmountains -1024
scoreboard players set #gr driftmountains 17768
scoreboard players set #gdr driftmountains -7
scoreboard players set #gp driftmountains 83
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.6061f,-0.2210f,-0.2590f,-0.7188f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.1849f,-0.6956f,0.6326f,0.2859f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.1135f,0.0015f,-0.0130f,-0.9934f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0130f,-0.9934f,0.1135f,0.0015f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3523f,0.8437f,0.0986f],left_rotation:[-0.1873f,0.0101f,-0.0188f,-0.9820f]}}
particle minecraft:cloud -75.42 70.57 29.12 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -75.42 70.37 29.12 0.003 0.02 0.083 1 0 force
particle minecraft:cloud -73.76 70.57 29.05 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -66745
scoreboard players set #gdx driftmountains -969
scoreboard players set #gy driftmountains 70440
scoreboard players set #gdy driftmountains -21
scoreboard players set #gz driftmountains 35423
scoreboard players set #gdz driftmountains -946
scoreboard players set #gr driftmountains 17869
scoreboard players set #gdr driftmountains -31
scoreboard players set #gp driftmountains 61
scoreboard players set #gdp driftmountains 7
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.9269f,0.0358f,-0.3700f,-0.0516f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.3667f,-0.0130f,0.9282f,0.0614f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.1135f,0.0015f,-0.0130f,-0.9934f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0130f,-0.9934f,0.1135f,0.0015f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3762f,0.8276f,0.2324f],left_rotation:[-0.1712f,-0.0497f,0.2792f,-0.9436f]}}
particle minecraft:cloud -67.57 70.76 36.81 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -67.57 70.56 36.81 0.002 0.02 0.082 1 0 force
particle minecraft:cloud -65.86 70.76 36.77 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -62848
scoreboard players set #gdx driftmountains -995
scoreboard players set #gy driftmountains 70505
scoreboard players set #gdy driftmountains -11
scoreboard players set #gz driftmountains 39253
scoreboard players set #gdz driftmountains -897
scoreboard players set #gr driftmountains 17893
scoreboard players set #gdr driftmountains 123
scoreboard players set #gp driftmountains 27
scoreboard players set #gdp driftmountains 11
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[-0.0036f,-0.0001f,-0.0223f,0.9997f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.2774f,0.3774f,-0.0595f,0.8815f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.1525f,0.8926f,0.2393f,-0.3504f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.1135f,0.0015f,-0.0130f,-0.9934f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0130f,-0.9934f,0.1135f,0.0015f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3601f,0.8271f,0.0921f],left_rotation:[-0.1708f,-0.0641f,0.3744f,-0.9091f]}}
particle minecraft:cloud -63.66 70.82 40.53 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -63.66 70.62 40.53 0.001 0.02 0.080 1 0 force
particle minecraft:cloud -61.99 70.82 40.50 0.35 0.18 0.35 0.02 3 force
