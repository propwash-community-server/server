scoreboard players set #gx driftmountains -26831
scoreboard players set #gdx driftmountains 677
scoreboard players set #gy driftmountains 67246
scoreboard players set #gdy driftmountains -11
scoreboard players set #gz driftmountains -88093
scoreboard players set #gdz driftmountains 344
scoreboard players set #gr driftmountains -3423
scoreboard players set #gdr driftmountains 27
scoreboard players set #gp driftmountains 72
scoreboard players set #gdp driftmountains -1
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0001f,-0.0178f,0.9998f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.8667f,0.1546f,-0.1877f,0.4355f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.2345f,0.4577f,0.8552f,-0.0644f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.5936f,0.0078f,0.0105f,0.8046f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0105f,0.8046f,0.5936f,0.0078f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3843f,0.8655f,0.1072f],left_rotation:[-0.1122f,0.1548f,-0.8056f,-0.5606f]}}
particle minecraft:cloud -26.85 67.57 -89.60 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -26.85 67.37 -89.60 -0.026 0.02 -0.038 1 0 force
particle minecraft:cloud -28.23 67.57 -88.67 0.35 0.18 0.35 0.02 2 force
scoreboard players set #gx driftmountains -32816
scoreboard players set #gdx driftmountains 673
scoreboard players set #gy driftmountains 67348
scoreboard players set #gdy driftmountains -13
scoreboard players set #gz driftmountains -90683
scoreboard players set #gdz driftmountains 276
scoreboard players set #gr driftmountains -3668
scoreboard players set #gdr driftmountains 84
scoreboard players set #gp driftmountains 90
scoreboard players set #gdp driftmountains -4
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0001f,-0.0195f,0.9998f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.8829f,-0.0421f,-0.2153f,-0.4153f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.1729f,-0.3949f,0.8921f,0.1351f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.5936f,0.0078f,0.0105f,0.8046f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0105f,0.8046f,0.5936f,0.0078f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3810f,0.8743f,0.2508f],left_rotation:[-0.0714f,0.1796f,-0.9108f,-0.3649f]}}
particle minecraft:cloud -32.95 67.67 -92.29 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -32.95 67.47 -92.29 -0.024 0.02 -0.032 1 0 force
particle minecraft:cloud -34.32 67.67 -91.27 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -38727
scoreboard players set #gdx driftmountains 593
scoreboard players set #gy driftmountains 67482
scoreboard players set #gdy driftmountains -16
scoreboard players set #gz driftmountains -92389
scoreboard players set #gdz driftmountains -14
scoreboard players set #gr driftmountains -5785
scoreboard players set #gdr driftmountains 400
scoreboard players set #gp driftmountains 130
scoreboard players set #gdp driftmountains -2
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0001f,-0.0218f,0.9998f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.3917f,0.1683f,-0.0151f,0.9044f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.1102f,0.9110f,0.3762f,-0.1280f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.5936f,0.0078f,0.0105f,0.8046f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0105f,0.8046f,0.5936f,0.0078f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.4009f,0.8400f,0.0972f],left_rotation:[0.0134f,0.1825f,-0.9775f,0.1044f]}}
particle minecraft:cloud -39.35 67.80 -93.77 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -39.35 67.60 -93.77 -0.028 0.02 -0.018 1 0 force
particle minecraft:cloud -40.24 67.80 -92.35 0.35 0.18 0.35 0.02 3 force
