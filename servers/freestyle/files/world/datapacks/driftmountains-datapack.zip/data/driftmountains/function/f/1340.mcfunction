scoreboard players set #gx driftmountains -30817
scoreboard players set #gdx driftmountains 657
scoreboard players set #gy driftmountains 67312
scoreboard players set #gdy driftmountains -11
scoreboard players set #gz driftmountains -89967
scoreboard players set #gdz driftmountains 286
scoreboard players set #gr driftmountains -3641
scoreboard players set #gdr driftmountains 40
scoreboard players set #gp driftmountains 77
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0001f,-0.0186f,0.9998f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.6535f,0.2123f,-0.1207f,0.7165f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.1966f,0.7331f,0.6348f,-0.1447f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.7958f,0.0104f,-0.0079f,-0.6054f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0079f,-0.6054f,0.7958f,0.0104f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3838f,0.8656f,0.1072f],left_rotation:[-0.1137f,0.1538f,-0.8002f,-0.5683f]}}
particle minecraft:cloud -30.89 67.63 -91.48 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -30.89 67.43 -91.48 -0.025 0.02 -0.034 1 0 force
particle minecraft:cloud -32.24 67.63 -90.49 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -36502
scoreboard players set #gdx driftmountains 606
scoreboard players set #gy driftmountains 67421
scoreboard players set #gdy driftmountains -12
scoreboard players set #gz driftmountains -91597
scoreboard players set #gdz driftmountains 84
scoreboard players set #gr driftmountains -4770
scoreboard players set #gdr driftmountains 138
scoreboard players set #gp driftmountains 102
scoreboard players set #gdp driftmountains -12
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0001f,-0.0216f,0.9998f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.5972f,-0.1498f,-0.1851f,-0.7659f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.1056f,-0.7507f,0.6163f,0.2134f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.7958f,0.0104f,-0.0079f,-0.6054f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0079f,-0.6054f,0.7958f,0.0104f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3721f,0.8728f,0.2502f],left_rotation:[-0.0998f,0.1648f,-0.8307f,-0.5224f]}}
particle minecraft:cloud -36.94 67.74 -93.15 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -36.94 67.54 -93.15 -0.027 0.02 -0.025 1 0 force
particle minecraft:cloud -38.09 67.74 -91.88 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -41974
scoreboard players set #gdx driftmountains 533
scoreboard players set #gy driftmountains 67569
scoreboard players set #gdy driftmountains -14
scoreboard players set #gz driftmountains -91430
scoreboard players set #gdz driftmountains -254
scoreboard players set #gr driftmountains -8087
scoreboard players set #gdr driftmountains 304
scoreboard players set #gp driftmountains 107
scoreboard players set #gdp driftmountains 2
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[0.0061f,0.0001f,-0.0220f,0.9997f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.9662f,0.0218f,-0.2090f,-0.1492f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.1945f,-0.1280f,0.9692f,0.0796f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.7958f,0.0104f,-0.0079f,-0.6054f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0079f,-0.6054f,0.7958f,0.0104f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3966f,0.8571f,0.1039f],left_rotation:[-0.0599f,0.1783f,-0.9409f,-0.2814f]}}
particle minecraft:cloud -43.09 67.89 -92.45 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -43.09 67.69 -92.45 -0.029 0.02 -0.005 1 0 force
particle minecraft:cloud -43.35 67.89 -90.81 0.35 0.18 0.35 0.02 3 force
