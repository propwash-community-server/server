scoreboard players set #gx driftmountains -30901
scoreboard players set #gdx driftmountains -1146
scoreboard players set #gy driftmountains 70846
scoreboard players set #gdy driftmountains -39
scoreboard players set #gz driftmountains 54036
scoreboard players set #gdz driftmountains -379
scoreboard players set #gr driftmountains 15552
scoreboard players set #gdr driftmountains 1
scoreboard players set #gp driftmountains 121
scoreboard players set #gdp driftmountains 8
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.9124f,0.0216f,-0.4006f,-0.0813f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.3942f,-0.0397f,0.9152f,0.0742f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.7200f,0.0094f,-0.0091f,-0.6938f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0091f,-0.6938f,0.7200f,0.0094f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3680f,0.8225f,0.0903f],left_rotation:[-0.1532f,-0.0956f,0.5393f,-0.8225f]}}
particle minecraft:cloud -31.14 71.17 55.53 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -31.14 70.97 55.53 0.030 0.02 0.066 1 0 force
particle minecraft:cloud -29.62 71.17 54.84 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -21218
scoreboard players set #gdx driftmountains -1113
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 57118
scoreboard players set #gdz driftmountains -322
scoreboard players set #gr driftmountains 15166
scoreboard players set #gdr driftmountains 30
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.6880f,0.2968f,-0.2473f,0.6143f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.3133f,0.6437f,0.6606f,-0.2261f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.7200f,0.0094f,-0.0091f,-0.6938f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0091f,-0.6938f,0.7200f,0.0094f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3835f,0.8273f,0.2323f],left_rotation:[-0.1614f,-0.0759f,0.4120f,-0.8936f]}}
particle minecraft:cloud -21.32 71.32 58.73 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -21.32 71.12 58.73 0.033 0.02 0.060 1 0 force
particle minecraft:cloud -19.82 71.32 57.91 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -16592
scoreboard players set #gdx driftmountains -1031
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 58569
scoreboard players set #gdz driftmountains -284
scoreboard players set #gr driftmountains 15131
scoreboard players set #gdr driftmountains 6
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.4248f,-0.3177f,-0.2294f,-0.8161f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.1448f,-0.7965f,0.4605f,0.3641f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.7200f,0.0094f,-0.0091f,-0.6938f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0091f,-0.6938f,0.7200f,0.0094f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3639f,0.8244f,0.0911f],left_rotation:[-0.1625f,-0.0805f,0.4603f,-0.8690f]}}
particle minecraft:cloud -16.72 71.32 60.08 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -16.72 71.12 60.08 0.033 0.02 0.060 1 0 force
particle minecraft:cloud -15.25 71.32 59.27 0.35 0.18 0.35 0.02 3 force
