scoreboard players set #gx driftmountains 40678
scoreboard players set #gdx driftmountains 1119
scoreboard players set #gy driftmountains 66357
scoreboard players set #gdy driftmountains -13
scoreboard players set #gz driftmountains -45840
scoreboard players set #gdz driftmountains 696
scoreboard players set #gr driftmountains -4385
scoreboard players set #gdr driftmountains 318
scoreboard players set #gp driftmountains 54
scoreboard players set #gdp driftmountains -1
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0000f,-0.0087f,1.0000f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.0598f,0.1252f,0.0453f,0.9893f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.0585f,0.9900f,0.0470f,-0.1196f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.6512f,0.0085f,0.0099f,0.7588f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0099f,0.7588f,0.6512f,0.0085f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3926f,0.8263f,0.0918f],left_rotation:[0.0770f,0.1625f,-0.8823f,0.4349f]}}
particle minecraft:cloud 40.41 66.68 -47.33 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke 40.41 66.48 -47.33 -0.055 0.02 -0.057 1 0 force
particle minecraft:cloud 39.20 66.68 -46.17 0.35 0.18 0.35 0.02 2 force
scoreboard players set #gx driftmountains 32422
scoreboard players set #gdx driftmountains 1111
scoreboard players set #gy driftmountains 66446
scoreboard players set #gdy driftmountains -14
scoreboard players set #gz driftmountains -49317
scoreboard players set #gdz driftmountains 783
scoreboard players set #gr driftmountains -5416
scoreboard players set #gdr driftmountains -4
scoreboard players set #gp driftmountains 61
scoreboard players set #gdp driftmountains -1
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0000f,-0.0004f,1.0000f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.5944f,0.0267f,-0.0454f,-0.8024f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[-0.0387f,-0.8021f,0.5949f,0.0356f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.6512f,0.0085f,0.0099f,0.7588f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0099f,0.7588f,0.6512f,0.0085f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3653f,0.8322f,0.2343f],left_rotation:[0.1795f,0.0043f,-0.0474f,0.9826f]}}
scoreboard players set #gx driftmountains 23232
scoreboard players set #gdx driftmountains 1126
scoreboard players set #gy driftmountains 66574
scoreboard players set #gdy driftmountains -14
scoreboard players set #gz driftmountains -56335
scoreboard players set #gdz driftmountains 580
scoreboard players set #gr driftmountains -6158
scoreboard players set #gdr driftmountains -195
scoreboard players set #gp driftmountains 62
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[0.0061f,-0.0000f,0.0002f,1.0000f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.0217f,0.0338f,0.0516f,0.9979f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.0530f,0.9979f,0.0183f,-0.0317f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.6512f,0.0085f,0.0099f,0.7588f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0099f,0.7588f,0.6512f,0.0085f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3571f,0.8303f,0.0934f],left_rotation:[0.1773f,0.0474f,-0.2866f,0.9403f]}}
