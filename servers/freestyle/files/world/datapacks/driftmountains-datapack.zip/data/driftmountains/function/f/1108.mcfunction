scoreboard players set #gx driftmountains -65860
scoreboard players set #gdx driftmountains -1002
scoreboard players set #gy driftmountains 70465
scoreboard players set #gdy driftmountains -19
scoreboard players set #gz driftmountains 36967
scoreboard players set #gdz driftmountains -964
scoreboard players set #gr driftmountains -17974
scoreboard players set #gdr driftmountains 43
scoreboard players set #gp driftmountains 52
scoreboard players set #gdp driftmountains 5
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.0809f,0.3834f,0.0231f,0.9198f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.0734f,0.9224f,0.0411f,-0.3770f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.6393f,0.0084f,0.0101f,0.7689f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0101f,0.7689f,0.6393f,0.0084f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3609f,0.8265f,0.0919f],left_rotation:[-0.1692f,-0.0675f,0.3921f,-0.9016f]}}
particle minecraft:cloud -66.70 70.78 38.22 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -66.70 70.58 38.22 -0.000 0.02 0.083 1 0 force
particle minecraft:cloud -65.03 70.78 38.23 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -56938
scoreboard players set #gdx driftmountains -1186
scoreboard players set #gy driftmountains 70509
scoreboard players set #gdy driftmountains 5
scoreboard players set #gz driftmountains 43090
scoreboard players set #gdz driftmountains -730
scoreboard players set #gr driftmountains 16856
scoreboard players set #gdr driftmountains 184
scoreboard players set #gp driftmountains -15
scoreboard players set #gdp driftmountains 5
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.6149f,-0.2460f,-0.2956f,-0.6885f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.2248f,-0.6612f,0.6441f,0.3120f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.6393f,0.0084f,0.0101f,0.7689f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0101f,0.7689f,0.6393f,0.0084f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3826f,0.8272f,0.2323f],left_rotation:[-0.1628f,-0.0727f,0.3959f,-0.9009f]}}
particle minecraft:cloud -57.51 70.83 44.60 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -57.51 70.63 44.60 0.017 0.02 0.083 1 0 force
particle minecraft:cloud -55.83 70.83 44.26 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -52448
scoreboard players set #gdx driftmountains -1234
scoreboard players set #gy driftmountains 70482
scoreboard players set #gdy driftmountains 7
scoreboard players set #gz driftmountains 46121
scoreboard players set #gdz driftmountains -647
scoreboard players set #gr driftmountains 16264
scoreboard players set #gdr driftmountains 183
scoreboard players set #gp driftmountains -19
scoreboard players set #gdp driftmountains -1
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.8225f,0.2206f,-0.3008f,0.4294f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.3476f,0.4634f,0.8038f,-0.1354f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.6393f,0.0084f,0.0101f,0.7689f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0101f,0.7689f,0.6393f,0.0084f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3572f,0.8301f,0.0933f],left_rotation:[-0.1770f,-0.0484f,0.2915f,-0.9388f]}}
particle minecraft:cloud -52.87 70.80 47.57 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -52.87 70.60 47.57 0.025 0.02 0.081 1 0 force
particle minecraft:cloud -51.27 70.80 47.07 0.35 0.18 0.35 0.02 3 force
