scoreboard players set #gx driftmountains 24379
scoreboard players set #gdx driftmountains 1057
scoreboard players set #gy driftmountains 66558
scoreboard players set #gdy driftmountains -13
scoreboard players set #gz driftmountains -55386
scoreboard players set #gdz driftmountains 587
scoreboard players set #gr driftmountains -5994
scoreboard players set #gdr driftmountains -15
scoreboard players set #gp driftmountains 63
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0000f,-0.0003f,1.0000f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.6660f,0.0174f,-0.0547f,-0.7438f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[-0.0232f,-0.7421f,0.6678f,0.0525f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.0394f,0.0005f,-0.0131f,-0.9991f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0131f,-0.9991f,0.0394f,0.0005f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3549f,0.8335f,0.0946f],left_rotation:[0.1817f,0.0324f,-0.2069f,0.9607f]}}
playsound driftgen:grain.kaze.001 neutral @a 32.97 66.95 -50.53 12 1
scoreboard players set #gx driftmountains 17066
scoreboard players set #gdx driftmountains 990
scoreboard players set #gy driftmountains 66651
scoreboard players set #gdy driftmountains -13
scoreboard players set #gz driftmountains -59954
scoreboard players set #gdz driftmountains 643
scoreboard players set #gr driftmountains -5936
scoreboard players set #gdr driftmountains 11
scoreboard players set #gp driftmountains 61
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[-0.0039f,0.0000f,0.0015f,1.0000f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.9878f,0.0544f,0.0098f,-0.1459f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[-0.0252f,-0.1477f,0.9875f,0.0492f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.0394f,0.0005f,-0.0131f,-0.9991f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0131f,-0.9991f,0.0394f,0.0005f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3585f,0.8399f,0.2373f],left_rotation:[0.1783f,-0.0360f,0.1594f,0.9703f]}}
playsound driftgen:grain.onyx.005 neutral @a 25.19 67.05 -54.55 12 1
scoreboard players set #gx driftmountains 7866
scoreboard players set #gdx driftmountains 1050
scoreboard players set #gy driftmountains 66769
scoreboard players set #gdy driftmountains -13
scoreboard players set #gz driftmountains -66220
scoreboard players set #gdz driftmountains 694
scoreboard players set #gr driftmountains -5521
scoreboard players set #gdr driftmountains -96
scoreboard players set #gp driftmountains 61
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0000f,-0.0008f,1.0000f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.6914f,0.0279f,-0.0458f,-0.7205f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[-0.0297f,-0.7197f,0.6922f,0.0446f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.0394f,0.0005f,-0.0131f,-0.9991f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0131f,-0.9991f,0.0394f,0.0005f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3531f,0.8382f,0.0965f],left_rotation:[0.1856f,0.0124f,-0.1008f,0.9773f]}}
playsound driftgen:grain.kaze.003 neutral @a 15.81 67.17 -60.99 12 1
