scoreboard players set #gx driftmountains 54286
scoreboard players set #gdx driftmountains 1142
scoreboard players set #gy driftmountains 66207
scoreboard players set #gdy driftmountains -12
scoreboard players set #gz driftmountains -36893
scoreboard players set #gdz driftmountains 817
scoreboard players set #gr driftmountains -4870
scoreboard players set #gdr driftmountains -504
scoreboard players set #gp driftmountains 51
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0000f,-0.0036f,1.0000f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.0561f,0.0483f,0.0497f,0.9960f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.0547f,0.9963f,0.0514f,-0.0427f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.6287f,0.0082f,0.0102f,0.7775f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0102f,0.7775f,0.6287f,0.0082f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3609f,0.8264f,0.0918f],left_rotation:[0.1691f,0.0678f,-0.3938f,0.9009f]}}
scoreboard players set #gx driftmountains 45883
scoreboard players set #gdx driftmountains 1195
scoreboard players set #gy driftmountains 66288
scoreboard players set #gdy driftmountains -13
scoreboard players set #gz driftmountains -40351
scoreboard players set #gdz driftmountains 713
scoreboard players set #gr driftmountains -3614
scoreboard players set #gdr driftmountains -67
scoreboard players set #gp driftmountains 49
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0001f,-0.0140f,0.9999f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.5734f,-0.1338f,-0.1629f,-0.7917f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.0806f,-0.7789f,0.5907f,0.1948f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.6287f,0.0082f,0.0102f,0.7775f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0102f,0.7775f,0.6287f,0.0082f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3852f,0.8740f,0.2506f],left_rotation:[-0.0575f,0.1845f,-0.9379f,-0.2883f]}}
particle minecraft:cloud 45.77 66.61 -41.96 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke 45.77 66.41 -41.96 -0.049 0.02 -0.067 1 0 force
particle minecraft:cloud 44.39 66.61 -40.95 0.35 0.18 0.35 0.02 2 force
scoreboard players set #gx driftmountains 35966
scoreboard players set #gdx driftmountains 1005
scoreboard players set #gy driftmountains 66408
scoreboard players set #gdy driftmountains -13
scoreboard players set #gz driftmountains -48030
scoreboard players set #gdz driftmountains 802
scoreboard players set #gr driftmountains -4914
scoreboard players set #gdr driftmountains 247
scoreboard players set #gp driftmountains 58
scoreboard players set #gdp driftmountains -1
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0000f,-0.0015f,1.0000f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.0208f,0.0164f,0.0520f,0.9983f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.0526f,0.9983f,0.0192f,-0.0143f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.6287f,0.0082f,0.0102f,0.7775f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0102f,0.7775f,0.6287f,0.0082f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3535f,0.8367f,0.0959f],left_rotation:[0.1846f,0.0187f,-0.1348f,0.9733f]}}
