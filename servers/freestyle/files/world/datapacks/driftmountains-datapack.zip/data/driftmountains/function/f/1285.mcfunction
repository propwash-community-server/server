scoreboard players set #gx driftmountains -56612
scoreboard players set #gdx driftmountains 37
scoreboard players set #gy driftmountains 68075
scoreboard players set #gdy driftmountains -16
scoreboard players set #gz driftmountains -71074
scoreboard players set #gdz driftmountains -595
scoreboard players set #gr driftmountains -14432
scoreboard players set #gdr driftmountains 312
scoreboard players set #gp driftmountains 123
scoreboard players set #gdp driftmountains 16
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[0.0061f,0.0001f,-0.0205f,0.9998f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.9818f,0.0528f,-0.1825f,-0.0024f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.1833f,0.0168f,0.9816f,0.0501f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.5006f,0.0066f,-0.0113f,-0.8656f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0113f,-0.8656f,0.5006f,0.0066f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.4006f,0.8492f,0.1008f],left_rotation:[-0.0246f,0.1840f,-0.9780f,-0.0949f]}}
particle minecraft:cloud -58.03 68.40 -70.54 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -58.03 68.20 -70.54 -0.021 0.02 0.029 1 0 force
particle minecraft:cloud -56.67 68.40 -69.56 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -55548
scoreboard players set #gdx driftmountains -94
scoreboard players set #gy driftmountains 68188
scoreboard players set #gdy driftmountains -13
scoreboard players set #gz driftmountains -65682
scoreboard players set #gdz driftmountains -751
scoreboard players set #gr driftmountains -16265
scoreboard players set #gdr driftmountains 236
scoreboard players set #gp driftmountains 90
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[0.0061f,0.0001f,-0.0150f,0.9999f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.9690f,0.0254f,-0.2055f,-0.1347f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.1925f,-0.1139f,0.9717f,0.0763f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.5006f,0.0066f,-0.0113f,-0.8656f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0113f,-0.8656f,0.5006f,0.0066f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3869f,0.8737f,0.2505f],left_rotation:[-0.0514f,0.1862f,-0.9476f,-0.2547f]}}
particle minecraft:cloud -56.77 68.51 -64.63 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -56.77 68.31 -64.63 -0.014 0.02 0.045 1 0 force
particle minecraft:cloud -55.14 68.51 -64.12 0.35 0.18 0.35 0.02 2 force
scoreboard players set #gx driftmountains -54393
scoreboard players set #gdx driftmountains -89
scoreboard players set #gy driftmountains 68301
scoreboard players set #gdy driftmountains -12
scoreboard players set #gz driftmountains -59077
scoreboard players set #gdz driftmountains -693
scoreboard players set #gr driftmountains 16310
scoreboard players set #gdr driftmountains 375
scoreboard players set #gp driftmountains 97
scoreboard players set #gdp driftmountains -1
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,0.0000f,0.0058f,1.0000f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.5303f,0.0969f,-0.0011f,-0.8422f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[-0.0875f,-0.8468f,0.5231f,-0.0417f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.5006f,0.0066f,-0.0113f,-0.8656f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0113f,-0.8656f,0.5006f,0.0066f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3739f,0.8664f,0.1075f],left_rotation:[0.1417f,-0.1298f,0.6668f,0.7200f]}}
