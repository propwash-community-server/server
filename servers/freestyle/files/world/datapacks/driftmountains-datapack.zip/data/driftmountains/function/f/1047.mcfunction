scoreboard players set #gx driftmountains 1646
scoreboard players set #gdx driftmountains -1019
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 63268
scoreboard players set #gdz driftmountains -56
scoreboard players set #gr driftmountains 14773
scoreboard players set #gdr driftmountains 260
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.8534f,-0.0882f,-0.4071f,-0.3133f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.3764f,-0.2722f,0.8674f,0.1784f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.4496f,0.0059f,-0.0117f,-0.8931f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0117f,-0.8931f,0.4496f,0.0059f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3754f,0.8210f,0.0897f],left_rotation:[-0.1347f,-0.1187f,0.6594f,-0.7300f]}}
particle minecraft:cloud 1.61 71.32 64.78 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 1.61 71.12 64.78 0.033 0.02 0.052 1 0 force
particle minecraft:cloud 3.02 71.32 63.89 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains 9189
scoreboard players set #gdx driftmountains -956
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 60148
scoreboard players set #gdz driftmountains 290
scoreboard players set #gr driftmountains 13327
scoreboard players set #gdr driftmountains 250
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.7975f,0.2533f,-0.3768f,0.3974f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.4206f,0.4392f,0.7753f,-0.1708f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.4496f,0.0059f,-0.0117f,-0.8931f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0117f,-0.8931f,0.4496f,0.0059f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.4062f,0.8483f,0.2406f],left_rotation:[-0.0748f,-0.1699f,0.8819f,-0.4333f]}}
particle minecraft:cloud 9.60 71.32 61.71 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 9.60 71.12 61.71 0.043 0.02 0.041 1 0 force
particle minecraft:cloud 10.77 71.32 60.46 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains 15472
scoreboard players set #gdx driftmountains -951
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 58921
scoreboard players set #gdz driftmountains 679
scoreboard players set #gr driftmountains 11330
scoreboard players set #gdr driftmountains 318
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.1889f,-0.4277f,-0.1528f,-0.8707f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.0621f,-0.8594f,0.2349f,0.4499f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.4496f,0.0059f,-0.0117f,-0.8931f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0117f,-0.8931f,0.4496f,0.0059f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3927f,0.8264f,0.0919f],left_rotation:[-0.0763f,-0.1628f,0.8839f,-0.4316f]}}
particle minecraft:cloud 16.30 71.32 60.19 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 16.30 71.12 60.19 0.057 0.02 0.025 1 0 force
particle minecraft:cloud 16.96 71.32 58.65 0.35 0.18 0.35 0.02 3 force
