scoreboard players set #gx driftmountains -97677
scoreboard players set #gdx driftmountains 195
scoreboard players set #gy driftmountains 69934
scoreboard players set #gdy driftmountains -15
scoreboard players set #gz driftmountains -13297
scoreboard players set #gdz driftmountains -732
scoreboard players set #gr driftmountains -11732
scoreboard players set #gdr driftmountains 365
scoreboard players set #gp driftmountains 70
scoreboard players set #gdp driftmountains 4
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.7176f,-0.1769f,-0.2963f,-0.6049f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.2343f,-0.5771f,0.7402f,0.2533f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.2930f,0.0038f,0.0125f,0.9560f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0125f,0.9560f,0.2930f,0.0038f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3524f,0.8417f,0.0978f],left_rotation:[-0.1870f,0.0019f,0.0250f,-0.9820f]}}
particle minecraft:cloud -99.18 70.25 -13.46 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -99.18 70.05 -13.46 -0.041 0.02 0.021 1 0 force
particle minecraft:cloud -98.41 70.25 -11.98 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -98044
scoreboard players set #gdx driftmountains -79
scoreboard players set #gy driftmountains 70026
scoreboard players set #gdy driftmountains -5
scoreboard players set #gz driftmountains -5800
scoreboard players set #gdz driftmountains -843
scoreboard players set #gr driftmountains -13698
scoreboard players set #gdr driftmountains 192
scoreboard players set #gp driftmountains 18
scoreboard players set #gdp driftmountains 6
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.8130f,-0.1282f,-0.3497f,-0.4475f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.3046f,-0.4132f,0.8310f,0.2143f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.2930f,0.0038f,0.0125f,0.9560f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0125f,0.9560f,0.2930f,0.0038f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3766f,0.8275f,0.2324f],left_rotation:[-0.1708f,-0.0510f,0.2857f,-0.9416f]}}
particle minecraft:cloud -99.60 70.35 -5.39 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -99.60 70.15 -5.39 -0.034 0.02 0.037 1 0 force
particle minecraft:cloud -98.35 70.35 -4.22 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -97017
scoreboard players set #gdx driftmountains -243
scoreboard players set #gy driftmountains 70032
scoreboard players set #gdy driftmountains 1
scoreboard players set #gz driftmountains -609
scoreboard players set #gdz driftmountains -789
scoreboard players set #gr driftmountains -14673
scoreboard players set #gdr driftmountains 229
scoreboard players set #gp driftmountains -7
scoreboard players set #gdp driftmountains 3
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[-0.0032f,-0.0001f,-0.0223f,0.9997f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.6806f,0.2980f,-0.2412f,0.6243f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.3081f,0.6531f,0.6531f,-0.2281f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.2930f,0.0038f,0.0125f,0.9560f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0125f,0.9560f,0.2930f,0.0038f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3606f,0.8267f,0.0919f],left_rotation:[-0.1698f,-0.0663f,0.3861f,-0.9042f]}}
particle minecraft:cloud -98.41 70.35 -0.01 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -98.41 70.15 -0.01 -0.030 0.02 0.045 1 0 force
particle minecraft:cloud -97.01 70.35 0.90 0.35 0.18 0.35 0.02 3 force
