scoreboard players set #gx driftmountains 56571
scoreboard players set #gdx driftmountains 1143
scoreboard players set #gy driftmountains 66182
scoreboard players set #gdy driftmountains -12
scoreboard players set #gz driftmountains -35247
scoreboard players set #gdz driftmountains 840
scoreboard players set #gr driftmountains -5833
scoreboard players set #gdr driftmountains -389
scoreboard players set #gp driftmountains 50
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,0.0000f,0.0027f,1.0000f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.4536f,0.0633f,-0.0265f,-0.8885f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[-0.0667f,-0.8907f,0.4495f,-0.0160f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.1509f,0.0020f,0.0129f,0.9885f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0129f,0.9885f,0.1509f,0.0020f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3593f,0.8597f,0.1049f],left_rotation:[0.1744f,-0.0789f,0.3886f,0.9012f]}}
scoreboard players set #gx driftmountains 48296
scoreboard players set #gdx driftmountains 1188
scoreboard players set #gy driftmountains 66262
scoreboard players set #gdy driftmountains -12
scoreboard players set #gz driftmountains -38923
scoreboard players set #gdz driftmountains 690
scoreboard players set #gr driftmountains -3849
scoreboard players set #gdr driftmountains -256
scoreboard players set #gp driftmountains 48
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0001f,-0.0130f,0.9999f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.8956f,-0.0281f,-0.1939f,-0.3994f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.1530f,-0.3812f,0.9035f,0.1224f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.1509f,0.0020f,0.0129f,0.9885f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0129f,0.9885f,0.1509f,0.0020f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3920f,0.8719f,0.2498f],left_rotation:[-0.0326f,0.1900f,-0.9696f,-0.1512f]}}
particle minecraft:cloud 48.12 66.58 -40.52 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke 48.12 66.38 -40.52 -0.052 0.02 -0.066 1 0 force
particle minecraft:cloud 46.78 66.58 -39.46 0.35 0.18 0.35 0.02 2 force
scoreboard players set #gx driftmountains 38095
scoreboard players set #gdx driftmountains 989
scoreboard players set #gy driftmountains 66381
scoreboard players set #gdy driftmountains -12
scoreboard players set #gz driftmountains -46326
scoreboard players set #gdz driftmountains 791
scoreboard players set #gr driftmountains -4341
scoreboard players set #gdr driftmountains 322
scoreboard players set #gp driftmountains 56
scoreboard players set #gdp driftmountains -1
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0000f,-0.0048f,1.0000f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.4775f,-0.0355f,-0.0792f,-0.8743f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[-0.0123f,-0.8708f,0.4839f,0.0859f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.1509f,0.0020f,0.0129f,0.9885f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0129f,0.9885f,0.1509f,0.0020f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3702f,0.8218f,0.0900f],left_rotation:[0.1479f,0.1030f,-0.5776f,0.7961f]}}
