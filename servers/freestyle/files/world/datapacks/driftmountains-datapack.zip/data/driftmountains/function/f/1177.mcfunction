scoreboard players set #gx driftmountains -91912
scoreboard players set #gdx driftmountains 545
scoreboard players set #gy driftmountains 69685
scoreboard players set #gdy driftmountains -19
scoreboard players set #gz driftmountains -22076
scoreboard players set #gdz driftmountains -476
scoreboard players set #gr driftmountains -8764
scoreboard players set #gdr driftmountains 147
scoreboard players set #gp driftmountains 108
scoreboard players set #gdp driftmountains 1
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.5414f,-0.2336f,-0.2309f,-0.7739f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.1509f,-0.7539f,0.5689f,0.2918f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.2574f,0.0034f,-0.0126f,-0.9662f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0126f,-0.9662f,0.2574f,0.0034f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3530f,0.8490f,0.1007f],left_rotation:[-0.1863f,0.0316f,-0.1339f,-0.9728f]}}
particle minecraft:cloud -93.14 70.01 -22.96 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -93.14 69.81 -22.96 -0.044 0.02 -0.002 1 0 force
particle minecraft:cloud -93.21 70.01 -21.29 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -96377
scoreboard players set #gdx driftmountains 406
scoreboard players set #gy driftmountains 69858
scoreboard players set #gdy driftmountains -18
scoreboard players set #gz driftmountains -16661
scoreboard players set #gdz driftmountains -669
scoreboard players set #gr driftmountains -10097
scoreboard players set #gdr driftmountains 223
scoreboard players set #gp driftmountains 84
scoreboard players set #gdp driftmountains 3
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.1630f,-0.3159f,-0.1118f,-0.9280f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.0149f,-0.9213f,0.1971f,0.3348f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.2574f,0.0034f,-0.0126f,-0.9662f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0126f,-0.9662f,0.2574f,0.0034f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3610f,0.8362f,0.2358f],left_rotation:[-0.1798f,0.0187f,-0.0703f,-0.9810f]}}
particle minecraft:cloud -97.88 70.18 -17.24 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -97.88 69.98 -17.24 -0.045 0.02 0.009 1 0 force
particle minecraft:cloud -97.55 70.18 -15.56 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -97961
scoreboard players set #gdx driftmountains 135
scoreboard players set #gy driftmountains 69954
scoreboard players set #gdy driftmountains -13
scoreboard players set #gz driftmountains -12183
scoreboard players set #gdz driftmountains -732
scoreboard players set #gr driftmountains -11988
scoreboard players set #gdr driftmountains 257
scoreboard players set #gp driftmountains 62
scoreboard players set #gdp driftmountains 4
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.5691f,-0.2499f,-0.2636f,-0.7377f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.1875f,-0.7141f,0.5985f,0.3110f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.2574f,0.0034f,-0.0126f,-0.9662f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0126f,-0.9662f,0.2574f,0.0034f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3547f,0.8339f,0.0948f],left_rotation:[-0.1821f,-0.0308f,0.1988f,-0.9624f]}}
particle minecraft:cloud -99.47 70.27 -12.28 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -99.47 70.07 -12.28 -0.039 0.02 0.023 1 0 force
particle minecraft:cloud -98.64 70.27 -10.83 0.35 0.18 0.35 0.02 3 force
