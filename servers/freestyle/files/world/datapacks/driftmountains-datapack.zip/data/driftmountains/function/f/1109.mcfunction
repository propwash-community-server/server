scoreboard players set #gx driftmountains -66863
scoreboard players set #gdx driftmountains -992
scoreboard players set #gy driftmountains 70446
scoreboard players set #gdy driftmountains -21
scoreboard players set #gz driftmountains 36002
scoreboard players set #gdz driftmountains -985
scoreboard players set #gr driftmountains -17932
scoreboard players set #gdr driftmountains -22
scoreboard players set #gp driftmountains 58
scoreboard players set #gdp driftmountains 7
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.9102f,0.1212f,-0.3623f,0.1602f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.3811f,0.1991f,0.9025f,-0.0262f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.9092f,0.0119f,-0.0054f,-0.4162f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0054f,-0.4162f,0.9092f,0.0119f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3601f,0.8271f,0.0921f],left_rotation:[-0.1709f,-0.0639f,0.3734f,-0.9095f]}}
particle minecraft:cloud -67.71 70.77 37.25 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -67.71 70.57 37.25 -0.001 0.02 0.084 1 0 force
particle minecraft:cloud -66.04 70.77 37.27 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -58124
scoreboard players set #gdx driftmountains -1180
scoreboard players set #gy driftmountains 70514
scoreboard players set #gdy driftmountains 2
scoreboard players set #gz driftmountains 42360
scoreboard players set #gdz driftmountains -772
scoreboard players set #gr driftmountains 17040
scoreboard players set #gdr driftmountains 173
scoreboard players set #gp driftmountains -11
scoreboard players set #gdp driftmountains 7
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.5055f,0.3509f,-0.1622f,0.7714f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.2442f,0.7927f,0.4715f,-0.2997f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.9092f,0.0119f,-0.0054f,-0.4162f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0054f,-0.4162f,0.9092f,0.0119f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3836f,0.8273f,0.2323f],left_rotation:[-0.1612f,-0.0762f,0.4136f,-0.8928f]}}
particle minecraft:cloud -58.74 70.83 43.85 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -58.74 70.63 43.85 0.014 0.02 0.083 1 0 force
particle minecraft:cloud -57.05 70.83 43.56 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -53682
scoreboard players set #gdx driftmountains -1256
scoreboard players set #gy driftmountains 70489
scoreboard players set #gdy driftmountains 7
scoreboard players set #gz driftmountains 45474
scoreboard players set #gdz driftmountains -694
scoreboard players set #gr driftmountains 16447
scoreboard players set #gdr driftmountains 196
scoreboard players set #gp driftmountains -21
scoreboard players set #gdp driftmountains 1
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[-0.0028f,-0.0001f,-0.0223f,0.9997f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.6263f,-0.2367f,-0.2938f,-0.6822f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.2238f,-0.6551f,0.6546f,0.3038f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.9092f,0.0119f,-0.0054f,-0.4162f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0054f,-0.4162f,0.9092f,0.0119f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3585f,0.8286f,0.0927f],left_rotation:[-0.1742f,-0.0558f,0.3306f,-0.9258f]}}
particle minecraft:cloud -54.15 70.81 46.91 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -54.15 70.61 46.91 0.023 0.02 0.082 1 0 force
particle minecraft:cloud -52.54 70.81 46.46 0.35 0.18 0.35 0.02 3 force
