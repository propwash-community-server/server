scoreboard players set #gx driftmountains -56550
scoreboard players set #gdx driftmountains -40
scoreboard players set #gy driftmountains 68117
scoreboard players set #gdy driftmountains -13
scoreboard players set #gz driftmountains -69201
scoreboard players set #gdz driftmountains -638
scoreboard players set #gr driftmountains -15140
scoreboard players set #gdr driftmountains 130
scoreboard players set #gp driftmountains 99
scoreboard players set #gdp driftmountains 1
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[0.0061f,0.0001f,-0.0198f,0.9998f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.9065f,-0.0322f,-0.2317f,-0.3514f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.1960f,-0.3290f,0.9149f,0.1276f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.9641f,0.0126f,-0.0035f,-0.2652f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0035f,-0.2652f,0.9641f,0.0126f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3883f,0.8639f,0.1065f],left_rotation:[-0.0985f,0.1631f,-0.8525f,-0.4868f]}}
particle minecraft:cloud -57.89 68.44 -68.49 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -57.89 68.24 -68.49 -0.019 0.02 0.034 1 0 force
particle minecraft:cloud -56.42 68.44 -67.70 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -55238
scoreboard players set #gdx driftmountains -103
scoreboard players set #gy driftmountains 68227
scoreboard players set #gdy driftmountains -13
scoreboard players set #gz driftmountains -63349
scoreboard players set #gdz driftmountains -749
scoreboard players set #gr driftmountains -17347
scoreboard players set #gdr driftmountains 400
scoreboard players set #gp driftmountains 92
scoreboard players set #gdp driftmountains -1
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0000f,-0.0089f,1.0000f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.9569f,0.0819f,-0.1002f,0.2601f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.1281f,0.2721f,0.9535f,0.0183f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.9641f,0.0126f,-0.0035f,-0.2652f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0035f,-0.2652f,0.9641f,0.0126f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.4059f,0.8465f,0.2399f],left_rotation:[0.0811f,0.1664f,-0.8647f,0.4671f]}}
particle minecraft:cloud -56.24 68.55 -62.09 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -56.24 68.35 -62.09 -0.005 0.02 0.047 1 0 force
particle minecraft:cloud -54.54 68.55 -61.90 0.35 0.18 0.35 0.02 2 force
scoreboard players set #gx driftmountains -54131
scoreboard players set #gdx driftmountains -82
scoreboard players set #gy driftmountains 68338
scoreboard players set #gdy driftmountains -13
scoreboard players set #gz driftmountains -57026
scoreboard players set #gdz driftmountains -673
scoreboard players set #gr driftmountains 15377
scoreboard players set #gdr driftmountains 256
scoreboard players set #gp driftmountains 101
scoreboard players set #gdp driftmountains -2
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,0.0000f,0.0119f,0.9999f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.5046f,0.1596f,0.0334f,-0.8478f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[-0.1226f,-0.8560f,0.4906f,-0.1075f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.9641f,0.0126f,-0.0035f,-0.2652f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0035f,-0.2652f,0.9641f,0.0126f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3998f,0.8517f,0.1017f],left_rotation:[0.0352f,-0.1830f,0.9708f,0.1507f]}}
particle minecraft:cloud -54.32 68.66 -55.53 0.35 0.18 0.35 0.02 2 force
particle minecraft:cloud -52.83 68.66 -56.26 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -52.83 68.46 -56.26 0.018 0.02 0.036 1 0 force
