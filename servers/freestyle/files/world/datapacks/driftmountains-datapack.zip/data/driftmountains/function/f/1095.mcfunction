scoreboard players set #gx driftmountains -51045
scoreboard players set #gdx driftmountains -1210
scoreboard players set #gy driftmountains 70476
scoreboard players set #gdy driftmountains 6
scoreboard players set #gz driftmountains 46528
scoreboard players set #gdz driftmountains -552
scoreboard players set #gr driftmountains 15984
scoreboard players set #gdr driftmountains 159
scoreboard players set #gp driftmountains -16
scoreboard players set #gdp driftmountains -2
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.8698f,-0.0749f,-0.3708f,-0.3167f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.3396f,-0.2795f,0.8825f,0.1668f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.5510f,0.0072f,-0.0109f,-0.8344f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0109f,-0.8344f,0.5510f,0.0072f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3588f,0.8283f,0.0926f],left_rotation:[-0.1735f,-0.0576f,0.3402f,-0.9224f]}}
particle minecraft:cloud -51.40 70.80 48.00 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -51.40 70.60 48.00 0.027 0.02 0.075 1 0 force
particle minecraft:cloud -49.83 70.80 47.42 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -40815
scoreboard players set #gdx driftmountains -1290
scoreboard players set #gy driftmountains 70529
scoreboard players set #gdy driftmountains -24
scoreboard players set #gz driftmountains 50647
scoreboard players set #gdz driftmountains -512
scoreboard players set #gr driftmountains 15480
scoreboard players set #gdr driftmountains 46
scoreboard players set #gp driftmountains 82
scoreboard players set #gdp driftmountains -22
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.8313f,0.2121f,-0.2948f,0.4208f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.3407f,0.4541f,0.8136f,-0.1259f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.5510f,0.0072f,-0.0109f,-0.8344f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0109f,-0.8344f,0.5510f,0.0072f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3721f,0.8286f,0.2329f],left_rotation:[-0.1753f,-0.0339f,0.1988f,-0.9637f]}}
particle minecraft:cloud -41.01 70.85 52.25 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -41.01 70.65 52.25 0.033 0.02 0.069 1 0 force
particle minecraft:cloud -39.46 70.85 51.52 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -36229
scoreboard players set #gdx driftmountains -1293
scoreboard players set #gy driftmountains 70664
scoreboard players set #gdy driftmountains -42
scoreboard players set #gz driftmountains 52755
scoreboard players set #gdz driftmountains -435
scoreboard players set #gr driftmountains 15406
scoreboard players set #gdr driftmountains -1
scoreboard players set #gp driftmountains 128
scoreboard players set #gdp driftmountains -8
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.2002f,-0.3588f,-0.1377f,-0.9012f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.0437f,-0.8917f,0.2390f,0.3818f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.5510f,0.0072f,-0.0109f,-0.8344f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0109f,-0.8344f,0.5510f,0.0072f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3609f,0.8264f,0.0918f],left_rotation:[-0.1690f,-0.0679f,0.3944f,-0.9006f]}}
particle minecraft:cloud -36.43 70.98 54.25 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -36.43 70.78 54.25 0.034 0.02 0.069 1 0 force
particle minecraft:cloud -34.93 70.98 53.52 0.35 0.18 0.35 0.02 3 force
