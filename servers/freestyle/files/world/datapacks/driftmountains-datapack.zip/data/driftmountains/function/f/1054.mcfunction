scoreboard players set #gx driftmountains -5249
scoreboard players set #gdx driftmountains -990
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 61774
scoreboard players set #gdz driftmountains -297
scoreboard players set #gr driftmountains 15885
scoreboard players set #gdr driftmountains -233
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.8914f,0.0175f,-0.4453f,-0.0823f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.4391f,-0.0360f,0.8945f,0.0761f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.6781f,0.0089f,-0.0096f,-0.7349f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0096f,-0.7349f,0.6781f,0.0089f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3892f,0.8241f,0.0909f],left_rotation:[-0.0910f,-0.1547f,0.8431f,-0.5069f]}}
particle minecraft:cloud -5.57 71.32 63.25 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -5.57 71.12 63.25 0.022 0.02 0.058 1 0 force
particle minecraft:cloud -4.02 71.32 62.65 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains 2299
scoreboard players set #gdx driftmountains -908
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 61224
scoreboard players set #gdz driftmountains 0
scoreboard players set #gr driftmountains 14740
scoreboard players set #gdr driftmountains -5
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.6627f,0.3513f,-0.3087f,0.5848f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.3719f,0.6205f,0.6295f,-0.2836f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.6781f,0.0089f,-0.0096f,-0.7349f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0096f,-0.7349f,0.6781f,0.0089f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.4059f,0.8550f,0.2432f],left_rotation:[-0.0510f,-0.1807f,0.9339f,-0.3044f]}}
particle minecraft:cloud 2.31 71.32 62.83 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 2.31 71.12 62.83 0.031 0.02 0.048 1 0 force
particle minecraft:cloud 3.76 71.32 61.91 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains 8878
scoreboard players set #gdx driftmountains -1032
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 62171
scoreboard players set #gdz driftmountains 253
scoreboard players set #gr driftmountains 13667
scoreboard players set #gdr driftmountains 294
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.4056f,-0.3804f,-0.2618f,-0.7888f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.1803f,-0.7657f,0.4478f,0.4251f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.6781f,0.0089f,-0.0096f,-0.7349f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0096f,-0.7349f,0.6781f,0.0089f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3954f,0.8290f,0.0928f],left_rotation:[-0.0627f,-0.1691f,0.9149f,-0.3610f]}}
particle minecraft:cloud 9.13 71.32 63.66 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 9.13 71.12 63.66 0.044 0.02 0.047 1 0 force
particle minecraft:cloud 10.35 71.32 62.51 0.35 0.18 0.35 0.02 3 force
