scoreboard players set #gx driftmountains 8898
scoreboard players set #gdx driftmountains 466
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains -11133
scoreboard players set #gdz driftmountains 825
scoreboard players set #gr driftmountains 900
scoreboard players set #gdr driftmountains 16
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.4382f,-0.2613f,-0.1993f,-0.8367f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.1125f,-0.8203f,0.4680f,0.3088f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.8914f,0.0117f,-0.0059f,-0.4530f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0059f,-0.4530f,0.8914f,0.0117f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3530f,0.8489f,0.1007f],left_rotation:[-0.1863f,0.0313f,-0.1323f,-0.9730f]}}
particle minecraft:cloud 9.92 71.32 -12.25 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 9.92 71.12 -12.25 0.009 0.02 -0.056 1 0 force
particle minecraft:cloud 8.27 71.32 -12.51 0.35 0.18 0.35 0.02 3 force
playsound driftgen:grain.kaze.057 neutral @a 12.58 71.50 -4.28 12 1
scoreboard players set #gx driftmountains 5975
scoreboard players set #gdx driftmountains 418
scoreboard players set #gy driftmountains 70878
scoreboard players set #gdy driftmountains 48
scoreboard players set #gz driftmountains -16512
scoreboard players set #gdz driftmountains 786
scoreboard players set #gr driftmountains 1398
scoreboard players set #gdr driftmountains -65
scoreboard players set #gp driftmountains -249
scoreboard players set #gdp driftmountains 42
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.8732f,-0.0731f,-0.3434f,-0.3380f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.3097f,-0.3038f,0.8857f,0.1652f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.8914f,0.0117f,-0.0059f,-0.4530f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0059f,-0.4530f,0.8914f,0.0117f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3668f,0.8312f,0.2339f],left_rotation:[-0.1789f,-0.0112f,0.0827f,-0.9803f]}}
particle minecraft:cloud 7.13 71.20 -17.63 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 7.13 71.00 -17.63 0.013 0.02 -0.051 1 0 force
particle minecraft:cloud 5.48 71.20 -18.04 0.35 0.18 0.35 0.02 3 force
playsound driftgen:grain.onyx.001 neutral @a 9.45 71.50 -9.97 12 1
scoreboard players set #gx driftmountains 3031
scoreboard players set #gdx driftmountains 583
scoreboard players set #gy driftmountains 70521
scoreboard players set #gdy driftmountains 52
scoreboard players set #gz driftmountains -20825
scoreboard players set #gdz driftmountains 722
scoreboard players set #gr driftmountains 480
scoreboard players set #gdr driftmountains 299
scoreboard players set #gp driftmountains -190
scoreboard players set #gdp driftmountains -68
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.1211f,-0.3027f,-0.0945f,-0.9406f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[-0.0038f,-0.9359f,0.1536f,0.3171f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.8914f,0.0117f,-0.0059f,-0.4530f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0059f,-0.4530f,0.8914f,0.0117f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3548f,0.8538f,0.1026f],left_rotation:[-0.1830f,0.0514f,-0.2403f,-0.9519f]}}
particle minecraft:cloud 3.97 70.84 -22.01 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 3.97 70.64 -22.01 0.004 0.02 -0.051 1 0 force
particle minecraft:cloud 2.30 70.84 -22.15 0.35 0.18 0.35 0.02 3 force
playsound driftgen:grain.kaze.066 neutral @a 6.77 71.46 -14.92 12 1
