scoreboard players set #gx driftmountains 13472
scoreboard players set #gdx driftmountains 445
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains -2470
scoreboard players set #gdz driftmountains 917
scoreboard players set #gr driftmountains 1196
scoreboard players set #gdr driftmountains 12
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.0386f,0.3193f,0.0422f,0.9459f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.0570f,0.9467f,0.0052f,-0.3170f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.5658f,0.0074f,-0.0108f,-0.8245f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0108f,-0.8245f,0.5658f,0.0074f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3539f,0.8517f,0.1018f],left_rotation:[-0.1847f,0.0429f,-0.1943f,-0.9624f]}}
particle minecraft:cloud 14.55 71.32 -3.53 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 14.55 71.12 -3.53 0.013 0.02 -0.060 1 0 force
particle minecraft:cloud 12.92 71.32 -3.88 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains 10361
scoreboard players set #gdx driftmountains 457
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains -8233
scoreboard players set #gdz driftmountains 887
scoreboard players set #gr driftmountains 1043
scoreboard players set #gdr driftmountains 20
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.5950f,-0.2122f,-0.2425f,-0.7363f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.1664f,-0.7149f,0.6206f,0.2759f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.5658f,0.0074f,-0.0108f,-0.8245f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0108f,-0.8245f,0.5658f,0.0074f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3578f,0.8413f,0.2378f],left_rotation:[-0.1774f,0.0425f,-0.1927f,-0.9642f]}}
particle minecraft:cloud 11.45 71.32 -9.42 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 11.45 71.12 -9.42 0.011 0.02 -0.058 1 0 force
particle minecraft:cloud 9.77 71.32 -9.73 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains 7652
scoreboard players set #gdx driftmountains 451
scoreboard players set #gy driftmountains 70999
scoreboard players set #gdy driftmountains 1
scoreboard players set #gz driftmountains -13322
scoreboard players set #gdz driftmountains 820
scoreboard players set #gr driftmountains 977
scoreboard players set #gdr driftmountains -43
scoreboard players set #gp driftmountains -20
scoreboard players set #gdp driftmountains 20
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.1884f,0.3320f,-0.0111f,0.9242f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.1083f,0.9305f,0.1546f,-0.3140f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.5658f,0.0074f,-0.0108f,-0.8245f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0108f,-0.8245f,0.5658f,0.0074f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3526f,0.8474f,0.1001f],left_rotation:[-0.1869f,0.0251f,-0.0990f,-0.9770f]}}
particle minecraft:cloud 8.69 71.32 -14.42 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 8.69 71.12 -14.42 0.009 0.02 -0.055 1 0 force
particle minecraft:cloud 7.04 71.32 -14.71 0.35 0.18 0.35 0.02 3 force
