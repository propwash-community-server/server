scoreboard players set #gx driftmountains 22319
scoreboard players set #gdx driftmountains 1019
scoreboard players set #gy driftmountains 66584
scoreboard players set #gdy driftmountains -13
scoreboard players set #gz driftmountains -56609
scoreboard players set #gdz driftmountains 622
scoreboard players set #gr driftmountains -5871
scoreboard players set #gdr driftmountains -95
scoreboard players set #gp driftmountains 62
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,0.0000f,0.0004f,1.0000f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.2057f,0.0028f,-0.0529f,-0.9772f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[-0.0495f,-0.9770f,0.2065f,0.0188f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.4697f,0.0061f,0.0116f,0.8827f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0116f,0.8827f,0.4697f,0.0061f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3527f,0.8396f,0.0970f],left_rotation:[0.1863f,0.0067f,-0.0707f,0.9799f]}}
scoreboard players set #gx driftmountains 15082
scoreboard players set #gdx driftmountains 939
scoreboard players set #gy driftmountains 66676
scoreboard players set #gdy driftmountains -12
scoreboard players set #gz driftmountains -61256
scoreboard players set #gdz driftmountains 620
scoreboard players set #gr driftmountains -5867
scoreboard players set #gdr driftmountains -35
scoreboard players set #gp driftmountains 61
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[-0.0039f,0.0000f,0.0014f,1.0000f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.7824f,0.0499f,-0.0213f,-0.6204f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[-0.0437f,-0.6216f,0.7815f,0.0321f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.4697f,0.0061f,0.0116f,0.8827f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0116f,0.8827f,0.4697f,0.0061f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3593f,0.8386f,0.2368f],left_rotation:[0.1790f,-0.0302f,0.1295f,0.9749f]}}
scoreboard players set #gx driftmountains 5982
scoreboard players set #gdx driftmountains 964
scoreboard players set #gy driftmountains 66793
scoreboard players set #gdy driftmountains -12
scoreboard players set #gz driftmountains -67465
scoreboard players set #gdz driftmountains 637
scoreboard players set #gr driftmountains -5354
scoreboard players set #gdr driftmountains -82
scoreboard players set #gp driftmountains 61
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0000f,-0.0018f,1.0000f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.2376f,-0.0130f,-0.0571f,-0.9696f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[-0.0445f,-0.9689f,0.2403f,0.0380f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.4697f,0.0061f,0.0116f,0.8827f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0116f,0.8827f,0.4697f,0.0061f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3555f,0.8326f,0.0943f],left_rotation:[0.1806f,0.0368f,-0.2302f,0.9555f]}}
