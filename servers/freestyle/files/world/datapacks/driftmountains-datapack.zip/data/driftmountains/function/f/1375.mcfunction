scoreboard players set #gx driftmountains -5519
scoreboard players set #gdx driftmountains 809
scoreboard players set #gy driftmountains 66941
scoreboard players set #gdy driftmountains -11
scoreboard players set #gz driftmountains -75113
scoreboard players set #gdz driftmountains 535
scoreboard players set #gr driftmountains -4737
scoreboard players set #gdr driftmountains -65
scoreboard players set #gp driftmountains 62
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0000f,-0.0056f,1.0000f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.0577f,0.0809f,0.0479f,0.9939f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.0563f,0.9943f,0.0495f,-0.0753f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.7356f,0.0096f,0.0089f,0.6773f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0089f,0.6773f,0.7356f,0.0096f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3741f,0.8211f,0.0898f],left_rotation:[0.1380f,0.1150f,-0.6404f,0.7467f]}}
scoreboard players set #gx driftmountains -12388
scoreboard players set #gdx driftmountains 839
scoreboard players set #gy driftmountains 67030
scoreboard players set #gdy driftmountains -11
scoreboard players set #gz driftmountains -79134
scoreboard players set #gdz driftmountains 529
scoreboard players set #gr driftmountains -3868
scoreboard players set #gdr driftmountains -128
scoreboard players set #gp driftmountains 62
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0000f,-0.0117f,0.9999f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.5795f,-0.1022f,-0.1400f,-0.7964f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.0570f,-0.7860f,0.5934f,0.1636f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.7356f,0.0096f,0.0089f,0.6773f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0089f,0.6773f,0.7356f,0.0096f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.4006f,0.8656f,0.2474f],left_rotation:[0.0065f,0.1908f,-0.9796f,0.0626f]}}
particle minecraft:cloud -12.57 67.35 -80.73 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -12.57 67.15 -80.73 -0.035 0.02 -0.044 1 0 force
particle minecraft:cloud -13.91 67.35 -79.67 0.35 0.18 0.35 0.02 2 force
scoreboard players set #gx driftmountains -19964
scoreboard players set #gdx driftmountains 693
scoreboard players set #gy driftmountains 67142
scoreboard players set #gdy driftmountains -10
scoreboard players set #gz driftmountains -84551
scoreboard players set #gdz driftmountains 436
scoreboard players set #gr driftmountains -2973
scoreboard players set #gdr driftmountains 12
scoreboard players set #gp driftmountains 64
scoreboard players set #gdp driftmountains -1
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0001f,-0.0172f,0.9998f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.0353f,0.2368f,0.0453f,0.9699f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.0564f,0.9704f,0.0106f,-0.2344f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.7356f,0.0096f,0.0089f,0.6773f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0089f,0.6773f,0.7356f,0.0096f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3852f,0.8652f,0.1070f],left_rotation:[-0.1092f,0.1568f,-0.8167f,-0.5444f]}}
particle minecraft:cloud -19.86 67.46 -86.06 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -19.86 67.26 -86.06 -0.026 0.02 -0.045 1 0 force
particle minecraft:cloud -21.31 67.46 -85.23 0.35 0.18 0.35 0.02 2 force
