scoreboard players set #gx driftmountains -56242
scoreboard players set #gdx driftmountains 276
scoreboard players set #gy driftmountains 68819
scoreboard players set #gdy driftmountains -19
scoreboard players set #gz driftmountains -40303
scoreboard players set #gdz driftmountains -591
scoreboard players set #gr driftmountains 17320
scoreboard players set #gdr driftmountains -210
scoreboard players set #gp driftmountains 139
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.9650f,0.0847f,0.1993f,-0.1478f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[-0.2159f,-0.1696f,0.9614f,0.0163f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.9942f,0.0130f,-0.0014f,-0.1066f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0014f,-0.1066f,0.9942f,0.0130f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3959f,0.8295f,0.0930f],left_rotation:[-0.0601f,-0.1701f,0.9200f,-0.3477f]}}
particle minecraft:cloud -56.92 69.14 -38.95 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud -55.26 69.14 -39.15 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -55.26 68.94 -39.15 0.005 0.02 0.039 1 0 force
scoreboard players set #gx driftmountains -59995
scoreboard players set #gdx driftmountains 457
scoreboard players set #gy driftmountains 68959
scoreboard players set #gdy driftmountains -24
scoreboard players set #gz driftmountains -37474
scoreboard players set #gdz driftmountains -542
scoreboard players set #gr driftmountains -17559
scoreboard players set #gdr driftmountains -70
scoreboard players set #gp driftmountains 160
scoreboard players set #gdp driftmountains -8
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[-0.0039f,0.0001f,0.0220f,0.9997f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.9421f,-0.0039f,0.2473f,0.2263f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[-0.2249f,0.2016f,0.9477f,0.1030f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.9942f,0.0130f,-0.0014f,-0.1066f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0014f,-0.1066f,0.9942f,0.0130f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.4032f,0.8394f,0.2371f],left_rotation:[-0.1059f,-0.1489f,0.7786f,-0.6004f]}}
particle minecraft:cloud -60.95 69.28 -36.18 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud -59.25 69.28 -36.05 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -59.25 69.08 -36.05 -0.003 0.02 0.035 1 0 force
scoreboard players set #gx driftmountains -63771
scoreboard players set #gdx driftmountains 501
scoreboard players set #gy driftmountains 69114
scoreboard players set #gdy driftmountains -11
scoreboard players set #gz driftmountains -33572
scoreboard players set #gdz driftmountains -245
scoreboard players set #gr driftmountains -14394
scoreboard players set #gdr driftmountains -389
scoreboard players set #gp driftmountains 93
scoreboard players set #gdp driftmountains 4
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[0.0061f,-0.0001f,0.0175f,0.9998f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.0221f,-0.1934f,0.0577f,0.9792f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.0449f,0.9785f,0.0425f,0.1968f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.9942f,0.0130f,-0.0014f,-0.1066f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0014f,-0.1066f,0.9942f,0.0130f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3994f,0.8350f,0.0952f],left_rotation:[-0.0345f,-0.1784f,0.9596f,-0.2147f]}}
particle minecraft:cloud -65.19 69.43 -33.04 0.35 0.18 0.35 0.02 2 force
particle minecraft:cloud -63.84 69.43 -32.06 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -63.84 69.23 -32.06 -0.021 0.02 0.029 1 0 force
