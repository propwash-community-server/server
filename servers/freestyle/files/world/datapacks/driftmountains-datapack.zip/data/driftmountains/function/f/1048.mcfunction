scoreboard players set #gx driftmountains 627
scoreboard players set #gdx driftmountains -998
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 63212
scoreboard players set #gdz driftmountains -124
scoreboard players set #gr driftmountains 15033
scoreboard players set #gdr driftmountains 315
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.0814f,0.4049f,0.0212f,0.9105f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.0744f,0.9133f,0.0393f,-0.3986f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.7447f,0.0097f,0.0087f,0.6673f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0087f,0.6673f,0.7447f,0.0097f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3700f,0.8219f,0.0901f],left_rotation:[-0.1483f,-0.1024f,0.5745f,-0.7983f]}}
particle minecraft:cloud 0.53 71.32 64.72 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 0.53 71.12 64.72 0.030 0.02 0.053 1 0 force
particle minecraft:cloud 1.98 71.32 63.89 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains 8233
scoreboard players set #gdx driftmountains -990
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 60438
scoreboard players set #gdz driftmountains 251
scoreboard players set #gr driftmountains 13577
scoreboard players set #gdr driftmountains 256
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.5900f,-0.2988f,-0.3425f,-0.6673f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.2743f,-0.6350f,0.6247f,0.3625f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.7447f,0.0097f,0.0087f,0.6673f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0087f,0.6673f,0.7447f,0.0097f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.4062f,0.8486f,0.2407f],left_rotation:[-0.0738f,-0.1704f,0.8845f,-0.4281f]}}
particle minecraft:cloud 8.57 71.32 62.01 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 8.57 71.12 62.01 0.042 0.02 0.043 1 0 force
particle minecraft:cloud 9.80 71.32 60.82 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains 14520
scoreboard players set #gdx driftmountains -940
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 59600
scoreboard players set #gdz driftmountains 597
scoreboard players set #gr driftmountains 11648
scoreboard players set #gdr driftmountains 386
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.7925f,0.2578f,-0.3726f,0.4081f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.4176f,0.4495f,0.7698f,-0.1759f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.7447f,0.0097f,0.0087f,0.6673f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0087f,0.6673f,0.7447f,0.0097f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3923f,0.8261f,0.0917f],left_rotation:[-0.0781f,-0.1619f,0.8794f,-0.4408f]}}
particle minecraft:cloud 15.28 71.32 60.91 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 15.28 71.12 60.91 0.056 0.02 0.028 1 0 force
particle minecraft:cloud 16.02 71.32 59.41 0.35 0.18 0.35 0.02 3 force
