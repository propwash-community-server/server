scoreboard players set #gx driftmountains -96781
scoreboard players set #gdx driftmountains -295
scoreboard players set #gy driftmountains 70031
scoreboard players set #gdy driftmountains 2
scoreboard players set #gz driftmountains -394
scoreboard players set #gdz driftmountains -915
scoreboard players set #gr driftmountains -14851
scoreboard players set #gdr driftmountains 287
scoreboard players set #gp driftmountains -8
scoreboard players set #gdp driftmountains 2
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0001f,-0.0223f,0.9997f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.7585f,-0.1679f,-0.3382f,-0.5312f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.2842f,-0.4985f,0.7803f,0.2486f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.4361f,0.0057f,-0.0118f,-0.8998f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0118f,-0.8998f,0.4361f,0.0057f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3586f,0.8285f,0.0927f],left_rotation:[-0.1741f,-0.0562f,0.3330f,-0.9249f]}}
particle minecraft:cloud -98.15 70.35 0.24 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -98.15 70.15 0.24 -0.030 0.02 0.049 1 0 force
particle minecraft:cloud -96.73 70.35 1.12 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -92666
scoreboard players set #gdx driftmountains -625
scoreboard players set #gy driftmountains 69998
scoreboard players set #gdy driftmountains 4
scoreboard players set #gz driftmountains 6994
scoreboard players set #gdz driftmountains -800
scoreboard players set #gr driftmountains -17366
scoreboard players set #gdr driftmountains 234
scoreboard players set #gp driftmountains -16
scoreboard players set #gdp driftmountains -1
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.9133f,0.1278f,-0.3358f,0.1918f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.3578f,0.2282f,0.9049f,-0.0325f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.4361f,0.0057f,-0.0118f,-0.8998f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0118f,-0.8998f,0.4361f,0.0057f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3703f,0.8293f,0.2331f],left_rotation:[-0.1767f,-0.0266f,0.1615f,-0.9706f]}}
particle minecraft:cloud -93.67 70.32 8.26 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -93.67 70.12 8.26 -0.007 0.02 0.061 1 0 force
particle minecraft:cloud -91.97 70.32 8.44 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -88914
scoreboard players set #gdx driftmountains -626
scoreboard players set #gy driftmountains 69983
scoreboard players set #gdy driftmountains 1
scoreboard players set #gz driftmountains 11218
scoreboard players set #gdz driftmountains -711
scoreboard players set #gr driftmountains 17709
scoreboard players set #gdr driftmountains 85
scoreboard players set #gp driftmountains -3
scoreboard players set #gdp driftmountains -4
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.0375f,0.3282f,0.0424f,0.9429f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.0565f,0.9437f,0.0032f,-0.3260f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.4361f,0.0057f,-0.0118f,-0.8998f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0118f,-0.8998f,0.4361f,0.0057f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3527f,0.8480f,0.1003f],left_rotation:[-0.1867f,0.0273f,-0.1109f,-0.9757f]}}
particle minecraft:cloud -89.68 70.30 12.52 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -89.68 70.10 12.52 0.003 0.02 0.062 1 0 force
particle minecraft:cloud -88.02 70.30 12.43 0.35 0.18 0.35 0.02 3 force
