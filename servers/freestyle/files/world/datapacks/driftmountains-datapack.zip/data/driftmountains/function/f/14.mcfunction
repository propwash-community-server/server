scoreboard players set #gx driftmountains -22078
scoreboard players set #gdx driftmountains -840
scoreboard players set #gy driftmountains 65565
scoreboard players set #gdy driftmountains 30
scoreboard players set #gz driftmountains 13320
scoreboard players set #gdz driftmountains -704
scoreboard players set #gr driftmountains 17238
scoreboard players set #gdr driftmountains 136
scoreboard players set #gp driftmountains -119
scoreboard players set #gdp driftmountains 14
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.6764f,0.2757f,-0.2061f,0.6511f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.2757f,0.6764f,0.6511f,-0.2061f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.6807f,0.0089f,0.0096f,0.7325f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0096f,0.7325f,0.6807f,0.0089f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3524f,0.8420f,0.0980f],left_rotation:[-0.1871f,0.0034f,0.0171f,-0.9821f]}}
particle minecraft:cloud -22.74 65.88 14.68 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -22.74 65.68 14.68 0.009 0.02 0.065 1 0 force
particle minecraft:cloud -21.08 65.88 14.46 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -16631
scoreboard players set #gdx driftmountains -990
scoreboard players set #gy driftmountains 65289
scoreboard players set #gdy driftmountains 52
scoreboard players set #gz driftmountains 16999
scoreboard players set #gdz driftmountains -480
scoreboard players set #gr driftmountains 15004
scoreboard players set #gdr driftmountains 459
scoreboard players set #gp driftmountains -222
scoreboard players set #gdp driftmountains 7
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0001f,-0.0213f,0.9998f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.6900f,0.2261f,-0.1548f,0.6700f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.2261f,0.6900f,0.6700f,-0.1548f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.6807f,0.0089f,0.0096f,0.7325f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0096f,0.7325f,0.6807f,0.0089f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3590f,0.8625f,0.2461f],left_rotation:[-0.1446f,0.1220f,-0.6051f,-0.7734f]}}
particle minecraft:cloud -16.69 65.61 18.61 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -16.69 65.41 18.61 0.034 0.02 0.059 1 0 force
particle minecraft:cloud -15.21 65.61 17.76 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -9200
scoreboard players set #gdx driftmountains -1072
scoreboard players set #gy driftmountains 65000
scoreboard players set #gdy driftmountains 24
scoreboard players set #gz driftmountains 20109
scoreboard players set #gdz driftmountains -494
scoreboard players set #gr driftmountains 14203
scoreboard players set #gdr driftmountains -48
scoreboard players set #gp driftmountains -33
scoreboard players set #gdp driftmountains -95
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0001f,-0.0165f,0.9999f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.6944f,0.2051f,-0.1332f,0.6767f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.2051f,0.6944f,0.6767f,-0.1332f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.6807f,0.0089f,0.0096f,0.7325f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0096f,0.7325f,0.6807f,0.0089f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3837f,0.8657f,0.1072f],left_rotation:[-0.1142f,0.1534f,-0.7980f,-0.5713f]}}
particle minecraft:cloud -9.08 65.32 21.62 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -9.08 65.12 21.62 0.039 0.02 0.050 1 0 force
particle minecraft:cloud -7.77 65.32 20.59 0.35 0.18 0.35 0.02 2 force
