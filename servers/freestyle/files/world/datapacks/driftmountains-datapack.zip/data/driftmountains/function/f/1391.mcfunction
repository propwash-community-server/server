scoreboard players set #gx driftmountains 8068
scoreboard players set #gdx driftmountains 898
scoreboard players set #gy driftmountains 66766
scoreboard players set #gdy driftmountains -11
scoreboard players set #gz driftmountains -65957
scoreboard players set #gdz driftmountains 611
scoreboard players set #gr driftmountains -5468
scoreboard players set #gdr driftmountains -86
scoreboard players set #gp driftmountains 61
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0000f,-0.0007f,1.0000f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.8364f,0.0387f,-0.0365f,-0.5456f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[-0.0206f,-0.5447f,0.8369f,0.0490f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.2568f,0.0034f,-0.0127f,-0.9664f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0127f,-0.9664f,0.2568f,0.0034f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3528f,0.8390f,0.0968f],left_rotation:[0.1860f,0.0089f,-0.0825f,0.9790f]}}
scoreboard players set #gx driftmountains 1086
scoreboard players set #gdx driftmountains 894
scoreboard players set #gy driftmountains 66854
scoreboard players set #gdy driftmountains -11
scoreboard players set #gz driftmountains -70546
scoreboard players set #gdz driftmountains 581
scoreboard players set #gr driftmountains -5202
scoreboard players set #gdr driftmountains -16
scoreboard players set #gp driftmountains 61
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0000f,-0.0031f,1.0000f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.9915f,0.0567f,-0.0356f,0.1116f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.0475f,0.1159f,0.9910f,0.0472f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.2568f,0.0034f,-0.0127f,-0.9664f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0127f,-0.9664f,0.2568f,0.0034f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3807f,0.8272f,0.2323f],left_rotation:[0.1655f,0.0660f,-0.3620f,0.9150f]}}
scoreboard players set #gx driftmountains -7500
scoreboard players set #gdx driftmountains 845
scoreboard players set #gy driftmountains 66967
scoreboard players set #gdy driftmountains -11
scoreboard players set #gz driftmountains -76400
scoreboard players set #gdz driftmountains 562
scoreboard players set #gr driftmountains -4475
scoreboard players set #gdr driftmountains -111
scoreboard players set #gp driftmountains 62
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0000f,-0.0071f,1.0000f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.8476f,-0.0076f,-0.1132f,-0.5184f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.0593f,-0.5094f,0.8530f,0.0967f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.2568f,0.0034f,-0.0127f,-0.9664f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0127f,-0.9664f,0.2568f,0.0034f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3841f,0.8220f,0.0901f],left_rotation:[0.1092f,0.1420f,-0.7792f,0.6005f]}}
particle minecraft:cloud -7.79 67.29 -77.88 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -7.79 67.09 -77.88 -0.043 0.02 -0.043 1 0 force
particle minecraft:cloud -8.98 67.29 -76.71 0.35 0.18 0.35 0.02 2 force
