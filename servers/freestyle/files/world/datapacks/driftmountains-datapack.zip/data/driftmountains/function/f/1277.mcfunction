scoreboard players set #gx driftmountains -56167
scoreboard players set #gdx driftmountains -99
scoreboard players set #gy driftmountains 68180
scoreboard players set #gdy driftmountains -12
scoreboard players set #gz driftmountains -65809
scoreboard players set #gdz driftmountains -705
scoreboard players set #gr driftmountains -16409
scoreboard players set #gdr driftmountains 258
scoreboard players set #gp driftmountains 90
scoreboard players set #gdp driftmountains 1
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[0.0061f,0.0001f,-0.0147f,0.9999f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.0160f,0.1940f,0.0502f,0.9796f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.0525f,0.9797f,-0.0043f,-0.1933f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.9997f,0.0131f,-0.0002f,-0.0188f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0002f,-0.0188f,0.9997f,0.0131f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3990f,0.8534f,0.1024f],left_rotation:[-0.0430f,0.1819f,-0.9635f,-0.1916f]}}
particle minecraft:cloud -57.31 68.50 -64.83 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -57.31 68.30 -64.83 -0.012 0.02 0.041 1 0 force
particle minecraft:cloud -55.71 68.50 -64.37 0.35 0.18 0.35 0.02 2 force
scoreboard players set #gx driftmountains -54676
scoreboard players set #gdx driftmountains -114
scoreboard players set #gy driftmountains 68290
scoreboard players set #gdy driftmountains -12
scoreboard players set #gz driftmountains -59605
scoreboard players set #gdz driftmountains -724
scoreboard players set #gr driftmountains 16457
scoreboard players set #gdr driftmountains 407
scoreboard players set #gp driftmountains 97
scoreboard players set #gdp driftmountains -1
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[-0.0039f,0.0000f,0.0040f,1.0000f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.9502f,0.0674f,0.0390f,-0.3017f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[-0.0710f,-0.3075f,0.9484f,0.0321f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.9997f,0.0131f,-0.0002f,-0.0188f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0002f,-0.0188f,0.9997f,0.0131f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3564f,0.8566f,0.2438f],left_rotation:[0.1578f,-0.1008f,0.4942f,0.8490f]}}
scoreboard players set #gx driftmountains -53851
scoreboard players set #gdx driftmountains -34
scoreboard players set #gy driftmountains 68406
scoreboard players set #gdy driftmountains -16
scoreboard players set #gz driftmountains -53793
scoreboard players set #gdz driftmountains -670
scoreboard players set #gr driftmountains 14821
scoreboard players set #gdr driftmountains -67
scoreboard players set #gp driftmountains 123
scoreboard players set #gdp driftmountains -12
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,0.0001f,0.0185f,0.9998f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.7625f,-0.0697f,0.1699f,0.6204f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[-0.1057f,0.6060f,0.7740f,0.1502f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.9997f,0.0131f,-0.0002f,-0.0188f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0002f,-0.0188f,0.9997f,0.0131f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.4013f,0.8427f,0.0982f],left_rotation:[-0.0019f,-0.1838f,0.9819f,-0.0447f]}}
particle minecraft:cloud -53.90 68.73 -52.28 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud -52.48 68.73 -53.16 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -52.48 68.53 -53.16 0.020 0.02 0.032 1 0 force
