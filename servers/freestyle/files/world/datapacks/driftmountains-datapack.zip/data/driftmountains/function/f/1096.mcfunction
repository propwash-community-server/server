scoreboard players set #gx driftmountains -52256
scoreboard players set #gdx driftmountains -1207
scoreboard players set #gy driftmountains 70482
scoreboard players set #gdy driftmountains 7
scoreboard players set #gz driftmountains 45975
scoreboard players set #gdz driftmountains -576
scoreboard players set #gr driftmountains 16143
scoreboard players set #gdr driftmountains 166
scoreboard players set #gp driftmountains -19
scoreboard players set #gdp driftmountains -2
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.0809f,0.3814f,0.0233f,0.9206f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.0734f,0.9232f,0.0412f,-0.3750f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.6615f,0.0087f,0.0098f,0.7498f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0098f,0.7498f,0.6615f,0.0087f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3602f,0.8271f,0.0921f],left_rotation:[-0.1707f,-0.0642f,0.3748f,-0.9090f]}}
particle minecraft:cloud -52.65 70.80 47.44 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -52.65 70.60 47.44 0.025 0.02 0.076 1 0 force
particle minecraft:cloud -51.06 70.80 46.90 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -42105
scoreboard players set #gdx driftmountains -1202
scoreboard players set #gy driftmountains 70505
scoreboard players set #gdy driftmountains -16
scoreboard players set #gz driftmountains 50134
scoreboard players set #gdz driftmountains -491
scoreboard players set #gr driftmountains 15526
scoreboard players set #gdr driftmountains 26
scoreboard players set #gp driftmountains 60
scoreboard players set #gdp driftmountains -17
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.6214f,-0.2304f,-0.2816f,-0.6939f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.2103f,-0.6681f,0.6490f,0.2970f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.6615f,0.0087f,0.0098f,0.7498f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0098f,0.7498f,0.6615f,0.0087f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3724f,0.8285f,0.2328f],left_rotation:[-0.1750f,-0.0351f,0.2050f,-0.9624f]}}
particle minecraft:cloud -42.31 70.83 51.73 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -42.31 70.63 51.73 0.033 0.02 0.071 1 0 force
particle minecraft:cloud -40.76 70.83 51.02 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -37522
scoreboard players set #gdx driftmountains -1158
scoreboard players set #gy driftmountains 70621
scoreboard players set #gdy driftmountains -35
scoreboard players set #gz driftmountains 52320
scoreboard players set #gdz driftmountains -401
scoreboard players set #gr driftmountains 15405
scoreboard players set #gdr driftmountains -6
scoreboard players set #gp driftmountains 120
scoreboard players set #gdp driftmountains -10
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.8204f,0.2235f,-0.3064f,0.4279f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.3531f,0.4624f,0.8015f,-0.1385f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.6615f,0.0087f,0.0098f,0.7498f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0098f,0.7498f,0.6615f,0.0087f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3591f,0.8280f,0.0925f],left_rotation:[-0.1729f,-0.0592f,0.3486f,-0.9192f]}}
particle minecraft:cloud -37.72 70.94 53.82 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -37.72 70.74 53.82 0.034 0.02 0.070 1 0 force
particle minecraft:cloud -36.22 70.94 53.09 0.35 0.18 0.35 0.02 3 force
