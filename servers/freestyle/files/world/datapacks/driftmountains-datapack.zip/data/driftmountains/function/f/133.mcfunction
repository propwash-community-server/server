scoreboard players set #gx driftmountains 11214
scoreboard players set #gdx driftmountains 457
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains -6919
scoreboard players set #gdz driftmountains 871
scoreboard players set #gr driftmountains 1041
scoreboard players set #gdr driftmountains 35
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.2074f,-0.2985f,-0.1237f,-0.9233f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.0273f,-0.9154f,0.2399f,0.3220f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.7519f,0.0098f,-0.0086f,-0.6592f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0086f,-0.6592f,0.7519f,0.0098f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3537f,0.8513f,0.1016f],left_rotation:[-0.1850f,0.0410f,-0.1844f,-0.9644f]}}
particle minecraft:cloud 12.26 71.32 -8.01 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 12.26 71.12 -8.01 0.011 0.02 -0.058 1 0 force
particle minecraft:cloud 10.62 71.32 -8.31 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains 8116
scoreboard players set #gdx driftmountains 434
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains -12487
scoreboard players set #gdz driftmountains 813
scoreboard players set #gr driftmountains 1036
scoreboard players set #gdr driftmountains -26
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.7621f,-0.1484f,-0.2976f,-0.5556f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.2409f,-0.5273f,0.7818f,0.2293f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.7519f,0.0098f,-0.0086f,-0.6592f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0086f,-0.6592f,0.7519f,0.0098f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3603f,0.8372f,0.2362f],left_rotation:[-0.1796f,0.0234f,-0.0945f,-0.9789f]}}
particle minecraft:cloud 9.20 71.32 -13.68 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 9.20 71.12 -13.68 0.010 0.02 -0.055 1 0 force
particle minecraft:cloud 7.52 71.32 -13.98 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains 5461
scoreboard players set #gdx driftmountains 444
scoreboard players set #gy driftmountains 70821
scoreboard players set #gdy driftmountains 56
scoreboard players set #gz driftmountains -17257
scoreboard players set #gdz driftmountains 778
scoreboard players set #gr driftmountains 1253
scoreboard players set #gdr driftmountains -2
scoreboard players set #gp driftmountains -279
scoreboard players set #gdp driftmountains 28
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.0400f,-0.3382f,-0.0702f,-0.9376f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[-0.0280f,-0.9354f,0.0758f,0.3443f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.7519f,0.0098f,-0.0086f,-0.6592f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0086f,-0.6592f,0.7519f,0.0098f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3524f,0.8415f,0.0978f],left_rotation:[-0.1870f,0.0012f,0.0287f,-0.9819f]}}
particle minecraft:cloud 6.55 71.14 -18.31 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 6.55 70.94 -18.31 0.011 0.02 -0.049 1 0 force
particle minecraft:cloud 4.92 71.14 -18.67 0.35 0.18 0.35 0.02 3 force
