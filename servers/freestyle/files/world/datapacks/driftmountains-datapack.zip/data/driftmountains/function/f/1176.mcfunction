scoreboard players set #gx driftmountains -92453
scoreboard players set #gdx driftmountains 541
scoreboard players set #gy driftmountains 69704
scoreboard players set #gdy driftmountains -19
scoreboard players set #gz driftmountains -21574
scoreboard players set #gdz driftmountains -502
scoreboard players set #gr driftmountains -8921
scoreboard players set #gdr driftmountains 157
scoreboard players set #gp driftmountains 106
scoreboard players set #gdp driftmountains 2
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.9351f,0.0989f,-0.3153f,0.1277f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.3305f,0.1615f,0.9299f,-0.0012f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.9999f,0.0131f,-0.0001f,-0.0038f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0001f,-0.0038f,0.9999f,0.0131f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3528f,0.8482f,0.1004f],left_rotation:[-0.1866f,0.0281f,-0.1151f,-0.9752f]}}
particle minecraft:cloud -93.70 70.02 -22.43 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -93.70 69.82 -22.43 -0.045 0.02 -0.001 1 0 force
particle minecraft:cloud -93.72 70.02 -20.76 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -96736
scoreboard players set #gdx driftmountains 360
scoreboard players set #gy driftmountains 69875
scoreboard players set #gdy driftmountains -17
scoreboard players set #gz driftmountains -15989
scoreboard players set #gdz driftmountains -672
scoreboard players set #gr driftmountains -10433
scoreboard players set #gdr driftmountains 336
scoreboard players set #gp driftmountains 81
scoreboard players set #gdp driftmountains 3
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.9161f,-0.0238f,-0.3321f,-0.2232f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.3105f,-0.1895f,0.9237f,0.1203f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.9999f,0.0131f,-0.0001f,-0.0038f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0001f,-0.0038f,0.9999f,0.0131f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3604f,0.8370f,0.2361f],left_rotation:[-0.1796f,0.0227f,-0.0908f,-0.9793f]}}
particle minecraft:cloud -98.27 70.20 -16.48 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -98.27 70.00 -16.48 -0.045 0.02 0.011 1 0 force
particle minecraft:cloud -97.85 70.20 -14.82 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -98082
scoreboard players set #gdx driftmountains 121
scoreboard players set #gy driftmountains 69968
scoreboard players set #gdy driftmountains -14
scoreboard players set #gz driftmountains -11340
scoreboard players set #gdz driftmountains -843
scoreboard players set #gr driftmountains -12191
scoreboard players set #gdr driftmountains 203
scoreboard players set #gp driftmountains 58
scoreboard players set #gdp driftmountains 4
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.9047f,0.1369f,-0.3465f,0.2066f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.3702f,0.2442f,0.8953f,-0.0426f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.9999f,0.0131f,-0.0001f,-0.0038f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0001f,-0.0038f,0.9999f,0.0131f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3571f,0.8303f,0.0934f],left_rotation:[-0.1773f,-0.0475f,0.2872f,-0.9401f]}}
particle minecraft:cloud -99.59 70.29 -11.38 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -99.59 70.09 -11.38 -0.040 0.02 0.025 1 0 force
particle minecraft:cloud -98.71 70.29 -9.97 0.35 0.18 0.35 0.02 3 force
