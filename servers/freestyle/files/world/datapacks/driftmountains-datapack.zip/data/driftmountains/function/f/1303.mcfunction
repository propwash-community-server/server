scoreboard players set #gx driftmountains -52212
scoreboard players set #gdx driftmountains 401
scoreboard players set #gy driftmountains 67823
scoreboard players set #gdy driftmountains -12
scoreboard players set #gz driftmountains -81664
scoreboard players set #gdz driftmountains -587
scoreboard players set #gr driftmountains -11443
scoreboard players set #gdr driftmountains 166
scoreboard players set #gp driftmountains 81
scoreboard players set #gdp driftmountains -4
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0001f,-0.0195f,0.9998f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.1903f,0.2389f,0.0071f,0.9522f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.0929f,0.9567f,0.1662f,-0.2202f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.8428f,0.0110f,0.0070f,0.5381f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0070f,0.5381f,0.8428f,0.0110f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3861f,0.8649f,0.1069f],left_rotation:[-0.1062f,0.1586f,-0.8274f,-0.5281f]}}
particle minecraft:cloud -53.70 68.14 -81.90 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -53.70 67.94 -81.90 -0.039 0.02 0.018 1 0 force
particle minecraft:cloud -53.01 68.14 -80.38 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -54205
scoreboard players set #gdx driftmountains 263
scoreboard players set #gy driftmountains 67906
scoreboard players set #gdy driftmountains -13
scoreboard players set #gz driftmountains -77340
scoreboard players set #gdz driftmountains -604
scoreboard players set #gr driftmountains -12329
scoreboard players set #gdr driftmountains 63
scoreboard players set #gp driftmountains 93
scoreboard players set #gdp driftmountains -3
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0001f,-0.0206f,0.9998f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.5419f,0.2432f,-0.0996f,0.7983f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.1840f,0.8132f,0.5193f,-0.1875f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.8428f,0.0110f,0.0070f,0.5381f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0070f,0.5381f,0.8428f,0.0110f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3623f,0.8666f,0.2477f],left_rotation:[-0.1321f,0.1372f,-0.6851f,-0.7032f]}}
particle minecraft:cloud -55.82 68.23 -77.31 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -55.82 68.03 -77.31 -0.033 0.02 0.022 1 0 force
particle minecraft:cloud -54.88 68.23 -75.88 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -55282
scoreboard players set #gdx driftmountains 121
scoreboard players set #gy driftmountains 68063
scoreboard players set #gdy driftmountains -22
scoreboard players set #gz driftmountains -71762
scoreboard players set #gdz driftmountains -586
scoreboard players set #gr driftmountains -13849
scoreboard players set #gdr driftmountains 423
scoreboard players set #gp driftmountains 171
scoreboard players set #gdp driftmountains 9
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.0945f,-0.1653f,-0.0693f,-0.9792f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[-0.0332f,-0.9774f,0.1124f,0.1762f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.8428f,0.0110f,0.0070f,0.5381f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0070f,0.5381f,0.8428f,0.0110f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.4013f,0.8445f,0.0989f],left_rotation:[-0.0053f,0.1842f,-0.9828f,0.0064f]}}
particle minecraft:cloud -56.74 68.38 -71.37 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -56.74 68.18 -71.37 -0.026 0.02 0.029 1 0 force
particle minecraft:cloud -55.49 68.38 -70.26 0.35 0.18 0.35 0.02 3 force
