scoreboard players set #gx driftmountains 16115
scoreboard players set #gdx driftmountains 427
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 3167
scoreboard players set #gdz driftmountains 974
scoreboard players set #gr driftmountains 1273
scoreboard players set #gdr driftmountains 47
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.9500f,0.0427f,-0.3069f,-0.0380f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.3046f,-0.0060f,0.9507f,0.0569f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.8161f,0.0107f,0.0076f,0.5778f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0076f,0.5778f,0.8161f,0.0107f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3565f,0.8565f,0.1037f],left_rotation:[-0.1798f,0.0637f,-0.3067f,-0.9324f]}}
particle minecraft:cloud 17.21 71.32 2.12 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 17.21 71.12 2.12 0.014 0.02 -0.062 1 0 force
particle minecraft:cloud 15.58 71.32 1.75 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains 13112
scoreboard players set #gdx driftmountains 458
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains -2760
scoreboard players set #gdz driftmountains 938
scoreboard players set #gr driftmountains 1149
scoreboard players set #gdr driftmountains 2
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.7363f,0.2424f,-0.2121f,0.5951f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.2758f,0.6206f,0.7149f,-0.1664f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.8161f,0.0107f,0.0076f,0.5778f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0076f,0.5778f,0.8161f,0.0107f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3577f,0.8414f,0.2378f],left_rotation:[-0.1773f,0.0427f,-0.1938f,-0.9640f]}}
particle minecraft:cloud 14.22 71.32 -3.93 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 14.22 71.12 -3.93 0.013 0.02 -0.062 1 0 force
particle minecraft:cloud 12.55 71.32 -4.27 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains 10356
scoreboard players set #gdx driftmountains 501
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains -8296
scoreboard players set #gdz driftmountains 975
scoreboard players set #gr driftmountains 997
scoreboard players set #gdr driftmountains 35
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.9298f,-0.0079f,-0.3161f,-0.1886f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.2980f,-0.1564f,0.9357f,0.1057f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.8161f,0.0107f,0.0076f,0.5778f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0076f,0.5778f,0.8161f,0.0107f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3550f,0.8541f,0.1027f],left_rotation:[-0.1826f,0.0531f,-0.2494f,-0.9495f]}}
particle minecraft:cloud 11.40 71.32 -9.39 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 11.40 71.12 -9.39 0.010 0.02 -0.060 1 0 force
particle minecraft:cloud 9.75 71.32 -9.68 0.35 0.18 0.35 0.02 3 force
