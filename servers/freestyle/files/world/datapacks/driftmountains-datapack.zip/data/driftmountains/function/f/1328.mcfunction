scoreboard players set #gx driftmountains -38584
scoreboard players set #gdx driftmountains 629
scoreboard players set #gy driftmountains 67479
scoreboard players set #gdy driftmountains -19
scoreboard players set #gz driftmountains -91609
scoreboard players set #gdz driftmountains -11
scoreboard players set #gr driftmountains -5502
scoreboard players set #gdr driftmountains -38
scoreboard players set #gp driftmountains 144
scoreboard players set #gdp driftmountains -7
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0001f,-0.0221f,0.9997f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.9018f,0.1314f,-0.1786f,0.3708f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.2186f,0.3916f,0.8930f,-0.0373f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.7777f,0.0102f,-0.0082f,-0.6285f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0082f,-0.6285f,0.7777f,0.0102f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3930f,0.8609f,0.1054f],left_rotation:[-0.0793f,0.1719f,-0.9035f,-0.3844f]}}
particle minecraft:cloud -39.14 67.80 -93.02 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -39.14 67.60 -93.02 -0.031 0.02 -0.022 1 0 force
particle minecraft:cloud -40.10 67.80 -91.65 0.35 0.18 0.35 0.02 3 force
playsound driftgen:grain.kaze.033 neutral @a -33.42 67.86 -90.98 12 1
scoreboard players set #gx driftmountains -43410
scoreboard players set #gdx driftmountains 492
scoreboard players set #gy driftmountains 67608
scoreboard players set #gdy driftmountains -12
scoreboard players set #gz driftmountains -90470
scoreboard players set #gdz driftmountains -249
scoreboard players set #gr driftmountains -8071
scoreboard players set #gdr driftmountains 270
scoreboard players set #gp driftmountains 97
scoreboard players set #gdp driftmountains 5
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.9319f,0.1158f,-0.1980f,0.2808f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.2286f,0.3032f,0.9249f,-0.0184f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.7777f,0.0102f,-0.0082f,-0.6285f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0082f,-0.6285f,0.7777f,0.0102f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3762f,0.8739f,0.2506f],left_rotation:[-0.0869f,0.1724f,-0.8716f,-0.4506f]}}
particle minecraft:cloud -44.62 67.93 -91.53 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -44.62 67.73 -91.53 -0.037 0.02 -0.006 1 0 force
particle minecraft:cloud -44.90 67.93 -89.85 0.35 0.18 0.35 0.02 3 force
playsound driftgen:grain.onyx.034 neutral @a -38.95 67.99 -91.73 12 1
scoreboard players set #gx driftmountains -47061
scoreboard players set #gdx driftmountains 434
scoreboard players set #gy driftmountains 67697
scoreboard players set #gdy driftmountains -11
scoreboard players set #gz driftmountains -87316
scoreboard players set #gdz driftmountains -468
scoreboard players set #gr driftmountains -10507
scoreboard players set #gdr driftmountains 156
scoreboard players set #gp driftmountains 82
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[0.0061f,0.0001f,-0.0201f,0.9998f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.9682f,0.0659f,-0.2363f,0.0489f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.2427f,0.0740f,0.9666f,0.0355f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.7777f,0.0102f,-0.0082f,-0.6285f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0082f,-0.6285f,0.7777f,0.0102f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3833f,0.8657f,0.1073f],left_rotation:[-0.1153f,0.1527f,-0.7940f,-0.5770f]}}
particle minecraft:cloud -48.50 68.02 -87.80 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -48.50 67.82 -87.80 -0.042 0.02 0.011 1 0 force
particle minecraft:cloud -48.06 68.02 -86.18 0.35 0.18 0.35 0.02 3 force
playsound driftgen:grain.kaze.031 neutral @a -43.62 68.11 -90.43 12 1
