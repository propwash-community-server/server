scoreboard players set #gx driftmountains 1951
scoreboard players set #gdx driftmountains 857
scoreboard players set #gy driftmountains 66844
scoreboard players set #gdy driftmountains -11
scoreboard players set #gz driftmountains -70114
scoreboard players set #gdz driftmountains 581
scoreboard players set #gr driftmountains -5098
scoreboard players set #gdr driftmountains -21
scoreboard players set #gp driftmountains 61
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0000f,-0.0030f,1.0000f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.6649f,0.0040f,-0.0667f,-0.7440f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[-0.0112f,-0.7411f,0.6681f,0.0659f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.0192f,0.0003f,0.0131f,0.9997f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0131f,0.9997f,0.0192f,0.0003f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3596f,0.8275f,0.0923f],left_rotation:[0.1719f,0.0614f,-0.3604f,0.9147f]}}
playsound driftgen:grain.kaze.060 neutral @a 8.97 67.25 -65.35 12 1
scoreboard players set #gx driftmountains -4998
scoreboard players set #gdx driftmountains 867
scoreboard players set #gy driftmountains 66932
scoreboard players set #gdy driftmountains -11
scoreboard players set #gz driftmountains -74454
scoreboard players set #gdz driftmountains 553
scoreboard players set #gr driftmountains -4904
scoreboard players set #gdr driftmountains -67
scoreboard players set #gp driftmountains 62
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0000f,-0.0052f,1.0000f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.9846f,0.0410f,-0.0795f,-0.1502f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.0641f,-0.1427f,0.9857f,0.0623f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.0192f,0.0003f,0.0131f,0.9997f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0131f,0.9997f,0.0192f,0.0003f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3942f,0.8307f,0.2337f],left_rotation:[0.1395f,0.1132f,-0.6003f,0.7793f]}}
playsound driftgen:grain.onyx.061 neutral @a 1.98 67.34 -69.97 12 1
scoreboard players set #gx driftmountains -13157
scoreboard players set #gdx driftmountains 798
scoreboard players set #gy driftmountains 67044
scoreboard players set #gdy driftmountains -11
scoreboard players set #gz driftmountains -80141
scoreboard players set #gdz driftmountains 526
scoreboard players set #gr driftmountains -3554
scoreboard players set #gdr driftmountains -115
scoreboard players set #gp driftmountains 62
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0001f,-0.0129f,0.9999f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.6734f,-0.0954f,-0.1630f,-0.7147f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.0888f,-0.7015f,0.6871f,0.1667f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.0192f,0.0003f,0.0131f,0.9997f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0131f,0.9997f,0.0192f,0.0003f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.4007f,0.8487f,0.1006f],left_rotation:[-0.0227f,0.1841f,-0.9789f,-0.0848f]}}
particle minecraft:cloud -13.21 67.36 -81.65 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -13.21 67.16 -81.65 -0.033 0.02 -0.046 1 0 force
particle minecraft:cloud -14.57 67.36 -80.68 0.35 0.18 0.35 0.02 2 force
playsound driftgen:grain.kaze.059 neutral @a -6.66 67.46 -75.84 12 1
