scoreboard players set #gx driftmountains -92987
scoreboard players set #gdx driftmountains 534
scoreboard players set #gy driftmountains 69724
scoreboard players set #gdy driftmountains -19
scoreboard players set #gz driftmountains -21043
scoreboard players set #gdz driftmountains -531
scoreboard players set #gr driftmountains -9085
scoreboard players set #gdr driftmountains 164
scoreboard players set #gp driftmountains 104
scoreboard players set #gdp driftmountains 2
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.2940f,0.3325f,-0.0508f,0.8947f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.1452f,0.9049f,0.2606f,-0.3034f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.2649f,0.0035f,0.0126f,0.9642f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0126f,0.9642f,0.2649f,0.0035f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3524f,0.8456f,0.0994f],left_rotation:[-0.1872f,0.0176f,-0.0587f,-0.9804f]}}
particle minecraft:cloud -94.26 70.04 -21.86 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -94.26 69.84 -21.86 -0.046 0.02 0.001 1 0 force
particle minecraft:cloud -94.23 70.04 -20.19 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -97056
scoreboard players set #gdx driftmountains 320
scoreboard players set #gy driftmountains 69892
scoreboard players set #gdy driftmountains -17
scoreboard players set #gz driftmountains -15284
scoreboard players set #gdz driftmountains -705
scoreboard players set #gr driftmountains -10788
scoreboard players set #gdr driftmountains 355
scoreboard players set #gp driftmountains 79
scoreboard players set #gdp driftmountains 3
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0001f,-0.0223f,0.9997f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.5727f,0.2884f,-0.1500f,0.7526f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.2299f,0.7725f,0.5456f,-0.2298f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.2649f,0.0035f,0.0126f,0.9642f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0126f,0.9642f,0.2649f,0.0035f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3583f,0.8401f,0.2374f],left_rotation:[-0.1781f,0.0373f,-0.1662f,-0.9692f]}}
particle minecraft:cloud -98.62 70.21 -15.68 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -98.62 70.01 -15.68 -0.043 0.02 0.014 1 0 force
particle minecraft:cloud -98.09 70.21 -14.05 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -98159
scoreboard players set #gdx driftmountains 77
scoreboard players set #gy driftmountains 69979
scoreboard players set #gdy driftmountains -11
scoreboard players set #gz driftmountains -10644
scoreboard players set #gdz driftmountains -696
scoreboard players set #gr driftmountains -12417
scoreboard players set #gdr driftmountains 226
scoreboard players set #gp driftmountains 55
scoreboard players set #gdp driftmountains 3
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.1599f,0.3792f,-0.0092f,0.9113f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.1050f,0.9173f,0.1209f,-0.3645f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.2649f,0.0035f,0.0126f,0.9642f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0126f,0.9642f,0.2649f,0.0035f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3592f,0.8279f,0.0924f],left_rotation:[-0.1728f,-0.0593f,0.3492f,-0.9190f]}}
particle minecraft:cloud -99.67 70.30 -10.63 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -99.67 70.10 -10.63 -0.039 0.02 0.026 1 0 force
particle minecraft:cloud -98.73 70.30 -9.25 0.35 0.18 0.35 0.02 3 force
