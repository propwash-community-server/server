scoreboard players set #gx driftmountains -62591
scoreboard players set #gdx driftmountains 545
scoreboard players set #gy driftmountains 69092
scoreboard players set #gdy driftmountains -13
scoreboard players set #gz driftmountains -33329
scoreboard players set #gdz driftmountains -270
scoreboard players set #gr driftmountains -14782
scoreboard players set #gdr driftmountains -242
scoreboard players set #gp driftmountains 99
scoreboard players set #gdp driftmountains 6
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[0.0061f,-0.0001f,0.0199f,0.9998f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.1750f,0.2046f,-0.0171f,-0.9629f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[-0.0840f,-0.9664f,0.1544f,-0.1874f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.3687f,0.0048f,-0.0122f,-0.9294f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0122f,-0.9294f,0.3687f,0.0048f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3987f,0.8336f,0.0947f],left_rotation:[-0.0407f,-0.1768f,0.9519f,-0.2469f]}}
particle minecraft:cloud -63.97 69.41 -32.71 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud -62.56 69.41 -31.82 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -62.56 69.21 -31.82 -0.020 0.02 0.031 1 0 force
scoreboard players set #gx driftmountains -68666
scoreboard players set #gdx driftmountains 712
scoreboard players set #gy driftmountains 69195
scoreboard players set #gdy driftmountains -11
scoreboard players set #gz driftmountains -32741
scoreboard players set #gdz driftmountains -276
scoreboard players set #gr driftmountains -11874
scoreboard players set #gdr driftmountains -236
scoreboard players set #gp driftmountains 79
scoreboard players set #gdp driftmountains 3
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[0.0061f,-0.0000f,0.0045f,1.0000f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.8862f,0.0808f,0.0426f,-0.4542f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[-0.0906f,-0.4612f,0.8826f,0.0119f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.3687f,0.0048f,-0.0122f,-0.9294f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0122f,-0.9294f,0.3687f,0.0048f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3596f,0.8633f,0.2465f],left_rotation:[0.1424f,-0.1250f,0.6206f,0.7609f]}}
scoreboard players set #gx driftmountains -73838
scoreboard players set #gdx driftmountains 607
scoreboard players set #gy driftmountains 69269
scoreboard players set #gdy driftmountains -9
scoreboard players set #gz driftmountains -29260
scoreboard players set #gdz driftmountains -279
scoreboard players set #gr driftmountains -12289
scoreboard players set #gdr driftmountains 223
scoreboard players set #gp driftmountains 72
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,0.0000f,0.0050f,1.0000f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.5088f,0.0846f,-0.0108f,-0.8567f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[-0.0792f,-0.8603f,0.5027f,-0.0315f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.3687f,0.0048f,-0.0122f,-0.9294f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0122f,-0.9294f,0.3687f,0.0048f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3677f,0.8649f,0.1069f],left_rotation:[0.1564f,-0.1117f,0.5674f,0.8006f]}}
