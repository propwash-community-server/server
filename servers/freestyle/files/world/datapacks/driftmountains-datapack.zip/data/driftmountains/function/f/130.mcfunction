scoreboard players set #gx driftmountains 9829
scoreboard players set #gdx driftmountains 464
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains -9475
scoreboard players set #gdz driftmountains 842
scoreboard players set #gr driftmountains 939
scoreboard players set #gdr driftmountains 36
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.7990f,-0.1247f,-0.3002f,-0.5060f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.2487f,-0.4772f,0.8165f,0.2094f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.9982f,0.0131f,0.0008f,0.0583f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0008f,0.0583f,0.9982f,0.0131f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3534f,0.8505f,0.1013f],left_rotation:[-0.1856f,0.0376f,-0.1663f,-0.9677f]}}
particle minecraft:cloud 10.86 71.32 -10.58 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 10.86 71.12 -10.58 0.009 0.02 -0.057 1 0 force
particle minecraft:cloud 9.21 71.32 -10.85 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains 6815
scoreboard players set #gdx driftmountains 426
scoreboard players set #gy driftmountains 70963
scoreboard players set #gdy driftmountains 26
scoreboard players set #gz driftmountains -14932
scoreboard players set #gdz driftmountains 804
scoreboard players set #gr driftmountains 1243
scoreboard players set #gdr driftmountains -79
scoreboard players set #gp driftmountains -157
scoreboard players set #gdp driftmountains 68
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.9267f,0.1078f,-0.3299f,0.1443f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.3469f,0.1798f,0.9204f,-0.0110f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.9982f,0.0131f,0.0008f,0.0583f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0008f,0.0583f,0.9982f,0.0131f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3652f,0.8323f,0.2343f],left_rotation:[-0.1796f,-0.0037f,0.0446f,-0.9828f]}}
particle minecraft:cloud 7.94 71.28 -16.08 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 7.94 71.08 -16.08 0.012 0.02 -0.053 1 0 force
particle minecraft:cloud 6.27 71.28 -16.45 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains 4087
scoreboard players set #gdx driftmountains 474
scoreboard players set #gy driftmountains 70630
scoreboard players set #gdy driftmountains 65
scoreboard players set #gz driftmountains -19449
scoreboard players set #gdz driftmountains 710
scoreboard players set #gr driftmountains 998
scoreboard players set #gdr driftmountains 138
scoreboard players set #gp driftmountains -306
scoreboard players set #gdp driftmountains -3
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.6192f,-0.2085f,-0.2544f,-0.7130f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.1808f,-0.6902f,0.6446f,0.2747f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.9982f,0.0131f,0.0008f,0.0583f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0008f,0.0583f,0.9982f,0.0131f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3529f,0.8488f,0.1006f],left_rotation:[-0.1864f,0.0309f,-0.1300f,-0.9733f]}}
particle minecraft:cloud 5.13 70.95 -20.55 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 5.13 70.75 -20.55 0.009 0.02 -0.050 1 0 force
particle minecraft:cloud 3.48 70.95 -20.83 0.35 0.18 0.35 0.02 3 force
