scoreboard players set #gx driftmountains -50018
scoreboard players set #gdx driftmountains 493
scoreboard players set #gy driftmountains 67764
scoreboard players set #gdy driftmountains -12
scoreboard players set #gz driftmountains -84550
scoreboard players set #gdz driftmountains -561
scoreboard players set #gr driftmountains -10633
scoreboard players set #gdr driftmountains 136
scoreboard players set #gp driftmountains 79
scoreboard players set #gdp driftmountains -3
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0001f,-0.0201f,0.9998f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.5541f,-0.1693f,-0.1840f,-0.7940f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.1015f,-0.7791f,0.5749f,0.2285f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.9496f,0.0124f,0.0041f,0.3133f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0041f,0.3133f,0.9496f,0.0124f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3812f,0.8662f,0.1074f],left_rotation:[-0.1219f,0.1479f,-0.7669f,-0.6125f]}}
particle minecraft:cloud -51.46 68.08 -85.00 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -51.46 67.88 -85.00 -0.043 0.02 0.013 1 0 force
particle minecraft:cloud -50.99 68.08 -83.39 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -52826
scoreboard players set #gdx driftmountains 330
scoreboard players set #gy driftmountains 67849
scoreboard players set #gdy driftmountains -12
scoreboard players set #gz driftmountains -80257
scoreboard players set #gdz driftmountains -610
scoreboard players set #gr driftmountains -11893
scoreboard players set #gdr driftmountains 140
scoreboard players set #gp driftmountains 82
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.7200f,-0.1232f,-0.2178f,-0.6473f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.1509f,-0.6280f,0.7369f,0.1996f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.9496f,0.0124f,0.0041f,0.3133f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0041f,0.3133f,0.9496f,0.0124f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3669f,0.8703f,0.2492f],left_rotation:[-0.1165f,0.1523f,-0.7645f,-0.6154f]}}
particle minecraft:cloud -54.43 68.17 -80.35 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -54.43 67.97 -80.35 -0.038 0.02 0.021 1 0 force
particle minecraft:cloud -53.61 68.17 -78.85 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -54257
scoreboard players set #gdx driftmountains 241
scoreboard players set #gy driftmountains 67954
scoreboard players set #gdy driftmountains -15
scoreboard players set #gz driftmountains -74982
scoreboard players set #gdz driftmountains -619
scoreboard players set #gr driftmountains -12747
scoreboard players set #gdr driftmountains 30
scoreboard players set #gp driftmountains 113
scoreboard players set #gdp driftmountains -3
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0001f,-0.0193f,0.9998f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.9610f,0.0257f,-0.2526f,-0.1093f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.2425f,-0.0833f,0.9636f,0.0752f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.9496f,0.0124f,0.0041f,0.3133f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0041f,0.3133f,0.9496f,0.0124f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3794f,0.8664f,0.1075f],left_rotation:[-0.1270f,0.1437f,-0.7436f,-0.6405f]}}
particle minecraft:cloud -55.76 68.27 -74.88 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -55.76 68.07 -74.88 -0.031 0.02 0.024 1 0 force
particle minecraft:cloud -54.75 68.27 -73.55 0.35 0.18 0.35 0.02 3 force
