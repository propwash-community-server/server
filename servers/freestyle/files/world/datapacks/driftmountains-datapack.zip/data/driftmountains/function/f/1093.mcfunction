scoreboard players set #gx driftmountains -48623
scoreboard players set #gdx driftmountains -1211
scoreboard players set #gy driftmountains 70468
scoreboard players set #gdy driftmountains 3
scoreboard players set #gz driftmountains 47573
scoreboard players set #gdz driftmountains -514
scoreboard players set #gr driftmountains 15741
scoreboard players set #gdr driftmountains 108
scoreboard players set #gp driftmountains -6
scoreboard players set #gdp driftmountains -7
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.5964f,-0.2467f,-0.2807f,-0.7104f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.2076f,-0.6848f,0.6256f,0.3108f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.0551f,0.0007f,-0.0131f,-0.9984f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0131f,-0.9984f,0.0551f,0.0007f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3574f,0.8299f,0.0932f],left_rotation:[-0.1766f,-0.0495f,0.2975f,-0.9369f]}}
particle minecraft:cloud -48.91 70.79 49.06 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -48.91 70.59 49.06 0.030 0.02 0.073 1 0 force
particle minecraft:cloud -47.37 70.79 48.42 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -38505
scoreboard players set #gdx driftmountains -1190
scoreboard players set #gy driftmountains 70588
scoreboard players set #gdy driftmountains -32
scoreboard players set #gz driftmountains 51525
scoreboard players set #gdz driftmountains -446
scoreboard players set #gr driftmountains 15454
scoreboard players set #gdr driftmountains 4
scoreboard players set #gp driftmountains 111
scoreboard players set #gdp driftmountains -14
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.9273f,0.0359f,-0.3690f,-0.0515f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.3656f,-0.0130f,0.9287f,0.0614f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.0551f,0.0007f,-0.0131f,-0.9984f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0131f,-0.9984f,0.0551f,0.0007f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3757f,0.8277f,0.2325f],left_rotation:[-0.1718f,-0.0477f,0.2692f,-0.9464f]}}
particle minecraft:cloud -38.69 70.91 53.12 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -38.69 70.71 53.12 0.033 0.02 0.069 1 0 force
particle minecraft:cloud -37.15 70.91 52.39 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -33904
scoreboard players set #gdx driftmountains -1116
scoreboard players set #gy driftmountains 70745
scoreboard players set #gdy driftmountains -39
scoreboard players set #gz driftmountains 53514
scoreboard players set #gdz driftmountains -361
scoreboard players set #gr driftmountains 15394
scoreboard players set #gdr driftmountains 5
scoreboard players set #gp driftmountains 134
scoreboard players set #gdp driftmountains -1
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.2769f,0.3848f,-0.0618f,0.8783f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.1545f,0.8897f,0.2380f,-0.3578f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.0551f,0.0007f,-0.0131f,-0.9984f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0131f,-0.9984f,0.0551f,0.0007f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3630f,0.8249f,0.0913f],left_rotation:[-0.1645f,-0.0770f,0.4421f,-0.8783f]}}
particle minecraft:cloud -34.10 71.06 55.01 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -34.10 70.86 55.01 0.033 0.02 0.067 1 0 force
particle minecraft:cloud -32.60 71.06 54.28 0.35 0.18 0.35 0.02 3 force
