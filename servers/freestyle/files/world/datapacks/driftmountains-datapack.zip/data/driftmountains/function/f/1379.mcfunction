scoreboard players set #gx driftmountains -2252
scoreboard players set #gdx driftmountains 830
scoreboard players set #gy driftmountains 66899
scoreboard players set #gdy driftmountains -11
scoreboard players set #gz driftmountains -72942
scoreboard players set #gdz driftmountains 556
scoreboard players set #gr driftmountains -4953
scoreboard players set #gdr driftmountains -39
scoreboard players set #gp driftmountains 62
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0000f,-0.0041f,1.0000f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.8337f,0.0128f,-0.0761f,-0.5468f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.0190f,-0.5418f,0.8370f,0.0748f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.2283f,0.0030f,-0.0127f,-0.9735f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0127f,-0.9735f,0.2283f,0.0030f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3650f,0.8238f,0.0908f],left_rotation:[0.1600f,0.0848f,-0.4832f,0.8565f]}}
scoreboard players set #gx driftmountains -9189
scoreboard players set #gdx driftmountains 825
scoreboard players set #gy driftmountains 66987
scoreboard players set #gdy driftmountains -11
scoreboard players set #gz driftmountains -77117
scoreboard players set #gdz driftmountains 522
scoreboard players set #gr driftmountains -4402
scoreboard players set #gdr driftmountains -125
scoreboard players set #gp driftmountains 62
scoreboard players set #gdp driftmountains -1
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0000f,-0.0084f,1.0000f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.9859f,0.0651f,-0.1111f,0.1069f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.1230f,0.1192f,0.9845f,0.0382f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.2283f,0.0030f,-0.0127f,-0.9735f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0127f,-0.9735f,0.2283f,0.0030f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.4058f,0.8462f,0.2398f],left_rotation:[0.0821f,0.1657f,-0.8616f,0.4727f]}}
particle minecraft:cloud -9.52 67.31 -78.69 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -9.52 67.11 -78.69 -0.040 0.02 -0.042 1 0 force
particle minecraft:cloud -10.75 67.31 -77.50 0.35 0.18 0.35 0.02 2 force
scoreboard players set #gx driftmountains -17043
scoreboard players set #gdx driftmountains 769
scoreboard players set #gy driftmountains 67099
scoreboard players set #gdy driftmountains -11
scoreboard players set #gz driftmountains -82685
scoreboard players set #gdz driftmountains 500
scoreboard players set #gr driftmountains -3070
scoreboard players set #gdr driftmountains -67
scoreboard players set #gp driftmountains 62
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0001f,-0.0161f,0.9999f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.8268f,-0.0721f,-0.2179f,-0.5135f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.1651f,-0.4934f,0.8390f,0.1594f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.2283f,0.0030f,-0.0127f,-0.9735f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0127f,-0.9735f,0.2283f,0.0030f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3901f,0.8629f,0.1062f],left_rotation:[-0.0917f,0.1665f,-0.8722f,-0.4505f]}}
particle minecraft:cloud -16.97 67.42 -84.20 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -16.97 67.22 -84.20 -0.028 0.02 -0.047 1 0 force
particle minecraft:cloud -18.40 67.42 -83.34 0.35 0.18 0.35 0.02 2 force
