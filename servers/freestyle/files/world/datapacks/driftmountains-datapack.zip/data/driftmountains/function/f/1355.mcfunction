scoreboard players set #gx driftmountains -20612
scoreboard players set #gdx driftmountains 708
scoreboard players set #gy driftmountains 67150
scoreboard players set #gdy driftmountains -10
scoreboard players set #gz driftmountains -84680
scoreboard players set #gdz driftmountains 422
scoreboard players set #gr driftmountains -3117
scoreboard players set #gdr driftmountains 14
scoreboard players set #gp driftmountains 64
scoreboard players set #gdp driftmountains -1
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0001f,-0.0172f,0.9998f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.6646f,-0.1337f,-0.1994f,-0.7075f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.1262f,-0.6905f,0.6823f,0.2043f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.1709f,0.0022f,-0.0129f,-0.9852f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0129f,-0.9852f,0.1709f,0.0022f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3856f,0.8650f,0.1070f],left_rotation:[-0.1078f,0.1577f,-0.8219f,-0.5366f]}}
particle minecraft:cloud -20.55 67.47 -86.19 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -20.55 67.27 -86.19 -0.026 0.02 -0.042 1 0 force
particle minecraft:cloud -21.98 67.47 -85.33 0.35 0.18 0.35 0.02 2 force
scoreboard players set #gx driftmountains -26960
scoreboard players set #gdx driftmountains 687
scoreboard players set #gy driftmountains 67246
scoreboard players set #gdy driftmountains -11
scoreboard players set #gz driftmountains -87910
scoreboard players set #gdz driftmountains 366
scoreboard players set #gr driftmountains -3304
scoreboard players set #gdr driftmountains 24
scoreboard players set #gp driftmountains 72
scoreboard players set #gdp driftmountains -1
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0001f,-0.0178f,0.9998f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.7026f,-0.1245f,-0.2090f,-0.6687f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.1399f,-0.6504f,0.7196f,0.1991f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.1709f,0.0022f,-0.0129f,-0.9852f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0129f,-0.9852f,0.1709f,0.0022f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3698f,0.8719f,0.2498f],left_rotation:[-0.1071f,0.1597f,-0.8037f,-0.5631f]}}
particle minecraft:cloud -26.99 67.57 -89.52 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -26.99 67.37 -89.52 -0.025 0.02 -0.039 1 0 force
particle minecraft:cloud -28.42 67.57 -88.59 0.35 0.18 0.35 0.02 2 force
scoreboard players set #gx driftmountains -33508
scoreboard players set #gdx driftmountains 611
scoreboard players set #gy driftmountains 67364
scoreboard players set #gdy driftmountains -12
scoreboard players set #gz driftmountains -91416
scoreboard players set #gdz driftmountains 209
scoreboard players set #gr driftmountains -3935
scoreboard players set #gdr driftmountains 61
scoreboard players set #gp driftmountains 90
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0001f,-0.0197f,0.9998f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.8046f,-0.0887f,-0.2287f,-0.5408f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.1731f,-0.5197f,0.8184f,0.1738f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.1709f,0.0022f,-0.0129f,-0.9852f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0129f,-0.9852f,0.1709f,0.0022f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3833f,0.8657f,0.1073f],left_rotation:[-0.1153f,0.1527f,-0.7939f,-0.5771f]}}
particle minecraft:cloud -33.66 67.68 -92.92 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -33.66 67.48 -92.92 -0.024 0.02 -0.030 1 0 force
particle minecraft:cloud -34.95 67.68 -91.86 0.35 0.18 0.35 0.02 3 force
