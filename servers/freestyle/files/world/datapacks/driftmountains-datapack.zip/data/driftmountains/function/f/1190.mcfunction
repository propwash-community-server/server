scoreboard players set #gx driftmountains -84886
scoreboard players set #gdx driftmountains 562
scoreboard players set #gy driftmountains 69464
scoreboard players set #gdy driftmountains -14
scoreboard players set #gz driftmountains -26374
scoreboard players set #gdz driftmountains -125
scoreboard players set #gr driftmountains -7449
scoreboard players set #gdr driftmountains -53
scoreboard players set #gp driftmountains 129
scoreboard players set #gdp driftmountains -5
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0001f,-0.0183f,0.9998f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.7460f,-0.0579f,-0.1476f,-0.6467f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.0805f,-0.6348f,0.7562f,0.1367f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.8504f,0.0111f,0.0069f,0.5260f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0069f,0.5260f,0.8504f,0.0111f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3996f,0.8355f,0.0954f],left_rotation:[0.0321f,0.1790f,-0.9622f,0.2023f]}}
particle minecraft:cloud -85.88 69.78 -27.52 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -85.88 69.58 -27.52 -0.033 0.02 -0.009 1 0 force
particle minecraft:cloud -86.32 69.78 -25.91 0.35 0.18 0.35 0.02 2 force
scoreboard players set #gx driftmountains -89831
scoreboard players set #gdx driftmountains 541
scoreboard players set #gy driftmountains 69609
scoreboard players set #gdy driftmountains -19
scoreboard players set #gz driftmountains -23964
scoreboard players set #gdz driftmountains -429
scoreboard players set #gr driftmountains -8382
scoreboard players set #gdr driftmountains 108
scoreboard players set #gp driftmountains 109
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.8640f,-0.0820f,-0.3390f,-0.3631f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.3027f,-0.3295f,0.8774f,0.1733f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.8504f,0.0111f,0.0069f,0.5260f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0069f,0.5260f,0.8504f,0.0111f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3659f,0.8318f,0.2341f],left_rotation:[-0.1793f,-0.0070f,0.0612f,-0.9819f]}}
particle minecraft:cloud -91.10 69.93 -24.96 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -91.10 69.73 -24.96 -0.041 0.02 -0.004 1 0 force
particle minecraft:cloud -91.28 69.93 -23.26 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -93235
scoreboard players set #gdx driftmountains 553
scoreboard players set #gy driftmountains 69735
scoreboard players set #gdy driftmountains -20
scoreboard players set #gz driftmountains -20717
scoreboard players set #gdz driftmountains -559
scoreboard players set #gr driftmountains -9000
scoreboard players set #gdr driftmountains 173
scoreboard players set #gp driftmountains 101
scoreboard players set #gdp driftmountains 2
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[0.0061f,0.0001f,-0.0223f,0.9997f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.9322f,0.0183f,-0.3471f,-0.1014f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.3383f,-0.0655f,0.9354f,0.0796f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.8504f,0.0111f,0.0069f,0.5260f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0069f,0.5260f,0.8504f,0.0111f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3526f,0.8406f,0.0974f],left_rotation:[-0.1867f,-0.0026f,0.0488f,-0.9812f]}}
particle minecraft:cloud -94.50 70.05 -21.55 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -94.50 69.85 -21.55 -0.047 0.02 0.000 1 0 force
particle minecraft:cloud -94.50 70.05 -19.88 0.35 0.18 0.35 0.02 3 force
