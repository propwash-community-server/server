scoreboard players set #gx driftmountains 7969
scoreboard players set #gdx driftmountains 464
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains -12758
scoreboard players set #gdz driftmountains 809
scoreboard players set #gr driftmountains 931
scoreboard players set #gdr driftmountains -21
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.0393f,0.3350f,0.0416f,0.9405f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.0570f,0.9413f,0.0043f,-0.3327f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.5414f,0.0071f,-0.0110f,-0.8407f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0110f,-0.8407f,0.5414f,0.0071f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3524f,0.8450f,0.0991f],left_rotation:[-0.1873f,0.0154f,-0.0472f,-0.9810f]}}
particle minecraft:cloud 9.00 71.32 -13.87 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 9.00 71.12 -13.87 0.009 0.02 -0.055 1 0 force
particle minecraft:cloud 7.35 71.32 -14.14 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains 5129
scoreboard players set #gdx driftmountains 429
scoreboard players set #gy driftmountains 70761
scoreboard players set #gdy driftmountains 62
scoreboard players set #gz driftmountains -18050
scoreboard players set #gdz driftmountains 769
scoreboard players set #gr driftmountains 1412
scoreboard players set #gdr driftmountains 8
scoreboard players set #gp driftmountains -304
scoreboard players set #gdp driftmountains 24
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.5889f,-0.2301f,-0.2569f,-0.7309f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.1815f,-0.7079f,0.6164f,0.2932f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.5414f,0.0071f,-0.0110f,-0.8407f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0110f,-0.8407f,0.5414f,0.0071f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3643f,0.8330f,0.2346f],left_rotation:[-0.1798f,0.0005f,0.0231f,-0.9835f]}}
particle minecraft:cloud 6.29 71.08 -19.17 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 6.29 70.88 -19.17 0.013 0.02 -0.050 1 0 force
particle minecraft:cloud 4.63 71.08 -19.58 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains 1919
scoreboard players set #gdx driftmountains 598
scoreboard players set #gy driftmountains 70482
scoreboard players set #gdy driftmountains 10
scoreboard players set #gz driftmountains -21993
scoreboard players set #gdz driftmountains 594
scoreboard players set #gr driftmountains -145
scoreboard players set #gdr driftmountains 327
scoreboard players set #gp driftmountains -8
scoreboard players set #gdp driftmountains -92
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.4149f,0.3075f,-0.0884f,0.8518f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.1784f,0.8658f,0.3848f,-0.2655f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.5414f,0.0071f,-0.0110f,-0.8407f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0110f,-0.8407f,0.5414f,0.0071f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3542f,0.8526f,0.1021f],left_rotation:[-0.1840f,0.0467f,-0.2147f,-0.9580f]}}
particle minecraft:cloud 2.72 70.80 -23.27 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 2.72 70.60 -23.27 -0.001 0.02 -0.051 1 0 force
particle minecraft:cloud 1.05 70.80 -23.23 0.35 0.18 0.35 0.02 3 force
