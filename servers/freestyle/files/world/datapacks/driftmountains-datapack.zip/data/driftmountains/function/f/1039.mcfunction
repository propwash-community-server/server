scoreboard players set #gx driftmountains 10034
scoreboard players set #gdx driftmountains -1010
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 61837
scoreboard players set #gdz driftmountains 374
scoreboard players set #gr driftmountains 12695
scoreboard players set #gdr driftmountains 295
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.6921f,0.3203f,-0.2941f,0.5761f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.3563f,0.6101f,0.6623f,-0.2493f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.9970f,0.0131f,-0.0010f,-0.0767f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0010f,-0.0767f,0.9970f,0.0131f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3843f,0.8221f,0.0901f],left_rotation:[-0.1084f,-0.1427f,0.7826f,-0.5961f]}}
particle minecraft:cloud 10.54 71.32 63.26 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 10.54 71.12 63.26 0.052 0.02 0.039 1 0 force
particle minecraft:cloud 11.54 71.32 61.93 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains 15970
scoreboard players set #gdx driftmountains -763
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 56326
scoreboard players set #gdz driftmountains 592
scoreboard players set #gr driftmountains 11116
scoreboard players set #gdr driftmountains 206
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.0549f,0.4622f,0.0304f,0.8846f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.0624f,0.8863f,0.0067f,-0.4589f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.9970f,0.0131f,-0.0010f,-0.0767f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0010f,-0.0767f,0.9970f,0.0131f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.4062f,0.8528f,0.2423f],left_rotation:[-0.0590f,-0.1775f,0.9187f,-0.3479f]}}
particle minecraft:cloud 16.93 71.32 57.62 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 16.93 71.12 57.62 0.058 0.02 0.022 1 0 force
particle minecraft:cloud 17.55 71.32 56.02 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains 21442
scoreboard players set #gdx driftmountains -674
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 52816
scoreboard players set #gdz driftmountains 878
scoreboard players set #gr driftmountains 9358
scoreboard players set #gdr driftmountains 213
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.8528f,-0.0788f,-0.4384f,-0.2725f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.4122f,-0.2280f,0.8658f,0.1689f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.9970f,0.0131f,-0.0010f,-0.0767f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0010f,-0.0767f,0.9970f,0.0131f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3891f,0.8241f,0.0909f],left_rotation:[-0.0913f,-0.1544f,0.8420f,-0.5087f]}}
particle minecraft:cloud 22.65 71.32 53.73 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 22.65 71.12 53.73 0.067 0.02 0.004 1 0 force
particle minecraft:cloud 22.75 71.32 52.06 0.35 0.18 0.35 0.02 3 force
