scoreboard players set #gx driftmountains 48585
scoreboard players set #gdx driftmountains 1139
scoreboard players set #gy driftmountains 66269
scoreboard players set #gdy driftmountains -12
scoreboard players set #gz driftmountains -40803
scoreboard players set #gdz driftmountains 759
scoreboard players set #gr driftmountains -3197
scoreboard players set #gdr driftmountains -165
scoreboard players set #gp driftmountains 48
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0001f,-0.0150f,0.9999f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.1911f,-0.1915f,-0.0927f,-0.9582f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[-0.0075f,-0.9538f,0.2123f,0.2126f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.4172f,0.0055f,0.0119f,0.9087f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0119f,0.9087f,0.4172f,0.0055f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3959f,0.8581f,0.1043f],left_rotation:[-0.0644f,0.1770f,-0.9335f,-0.3051f]}}
particle minecraft:cloud 48.63 66.59 -42.31 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke 48.63 66.39 -42.31 -0.043 0.02 -0.069 1 0 force
particle minecraft:cloud 47.21 66.59 -41.43 0.35 0.18 0.35 0.02 2 force
scoreboard players set #gx driftmountains 40046
scoreboard players set #gdx driftmountains 1152
scoreboard players set #gy driftmountains 66352
scoreboard players set #gdy driftmountains -13
scoreboard players set #gz driftmountains -44021
scoreboard players set #gdz driftmountains 754
scoreboard players set #gr driftmountains -4289
scoreboard players set #gdr driftmountains 226
scoreboard players set #gp driftmountains 54
scoreboard players set #gdp driftmountains -1
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0000f,-0.0084f,1.0000f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.7714f,-0.0389f,-0.1324f,-0.6212f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.0679f,-0.6107f,0.7798f,0.1202f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.4172f,0.0055f,0.0119f,0.9087f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0119f,0.9087f,0.4172f,0.0055f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.4063f,0.8506f,0.2415f],left_rotation:[0.0669f,0.1739f,-0.9014f,0.3909f]}}
particle minecraft:cloud 39.74 66.67 -45.60 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke 39.74 66.47 -45.60 -0.056 0.02 -0.060 1 0 force
particle minecraft:cloud 38.49 66.67 -44.44 0.35 0.18 0.35 0.02 2 force
scoreboard players set #gx driftmountains 30796
scoreboard players set #gdx driftmountains 1017
scoreboard players set #gy driftmountains 66477
scoreboard players set #gdy driftmountains -14
scoreboard players set #gz driftmountains -51946
scoreboard players set #gdz driftmountains 742
scoreboard players set #gr driftmountains -5212
scoreboard players set #gdr driftmountains -15
scoreboard players set #gp driftmountains 63
scoreboard players set #gdp driftmountains -1
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0000f,-0.0012f,1.0000f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.2387f,0.0059f,-0.0524f,-0.9697f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[-0.0492f,-0.9695f,0.2394f,0.0191f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.4172f,0.0055f,0.0119f,0.9087f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0119f,0.9087f,0.4172f,0.0055f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3526f,0.8401f,0.0972f],left_rotation:[0.1865f,0.0044f,-0.0584f,0.9807f]}}
