scoreboard players set #gx driftmountains -70454
scoreboard players set #gdx driftmountains 698
scoreboard players set #gy driftmountains 69222
scoreboard players set #gdy driftmountains -10
scoreboard players set #gz driftmountains -30453
scoreboard players set #gdz driftmountains -255
scoreboard players set #gr driftmountains -11507
scoreboard players set #gdr driftmountains -19
scoreboard players set #gp driftmountains 75
scoreboard players set #gdp driftmountains 1
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,0.0000f,0.0029f,1.0000f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.0666f,0.0606f,-0.0485f,-0.9948f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[-0.0558f,-0.9951f,0.0606f,-0.0539f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.3413f,0.0045f,-0.0123f,-0.9399f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0123f,-0.9399f,0.3413f,0.0045f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3637f,0.8631f,0.1062f],left_rotation:[0.1651f,-0.0979f,0.4922f,0.8490f]}}
scoreboard players set #gx driftmountains -76783
scoreboard players set #gdx driftmountains 649
scoreboard players set #gy driftmountains 69310
scoreboard players set #gdy driftmountains -9
scoreboard players set #gz driftmountains -29161
scoreboard players set #gdz driftmountains -285
scoreboard players set #gr driftmountains -13113
scoreboard players set #gdr driftmountains 130
scoreboard players set #gp driftmountains 74
scoreboard players set #gdp driftmountains -1
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[-0.0039f,0.0000f,0.0109f,0.9999f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.9317f,0.0076f,0.1339f,0.3377f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[-0.0992f,0.3255f,0.9360f,0.0903f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.3413f,0.0045f,-0.0123f,-0.9399f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0123f,-0.9399f,0.3413f,0.0045f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3780f,0.8741f,0.2507f],left_rotation:[0.0810f,-0.1753f,0.8876f,0.4182f]}}
particle minecraft:cloud -78.37 69.63 -28.91 0.35 0.18 0.35 0.02 2 force
particle minecraft:cloud -77.25 69.63 -27.62 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -77.25 69.43 -27.62 -0.032 0.02 0.028 1 0 force
scoreboard players set #gx driftmountains -81795
scoreboard players set #gdx driftmountains 564
scoreboard players set #gy driftmountains 69397
scoreboard players set #gdy driftmountains -11
scoreboard players set #gz driftmountains -26595
scoreboard players set #gdz driftmountains -76
scoreboard players set #gr driftmountains -9010
scoreboard players set #gdr driftmountains -719
scoreboard players set #gp driftmountains 107
scoreboard players set #gdp driftmountains -1
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0000f,-0.0039f,1.0000f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.6267f,-0.0310f,-0.0928f,-0.7731f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.0120f,-0.7676f,0.6334f,0.0971f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.3413f,0.0045f,-0.0123f,-0.9399f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0123f,-0.9399f,0.3413f,0.0045f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3761f,0.8210f,0.0897f],left_rotation:[0.1327f,0.1209f,-0.6706f,0.7197f]}}
