scoreboard players set #gx driftmountains -57883
scoreboard players set #gdx driftmountains 353
scoreboard players set #gy driftmountains 68911
scoreboard players set #gdy driftmountains -18
scoreboard players set #gz driftmountains -37613
scoreboard players set #gdz driftmountains -505
scoreboard players set #gr driftmountains -17829
scoreboard players set #gdr driftmountains -57
scoreboard players set #gp driftmountains 140
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,0.0001f,0.0205f,0.9998f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.0923f,-0.2346f,0.0766f,0.9646f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.0243f,0.9619f,0.1175f,0.2456f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.9897f,0.0130f,0.0019f,0.1423f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0019f,0.1423f,0.9897f,0.0130f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3843f,0.8221f,0.0901f],left_rotation:[-0.1084f,-0.1427f,0.7824f,-0.5964f]}}
particle minecraft:cloud -58.75 69.23 -36.38 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud -57.09 69.23 -36.33 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -57.09 69.03 -36.33 -0.001 0.02 0.037 1 0 force
scoreboard players set #gx driftmountains -62013
scoreboard players set #gdx driftmountains 382
scoreboard players set #gy driftmountains 69062
scoreboard players set #gdy driftmountains -15
scoreboard players set #gz driftmountains -35578
scoreboard players set #gdz driftmountains -259
scoreboard players set #gr driftmountains -15723
scoreboard players set #gdr driftmountains -473
scoreboard players set #gp driftmountains 136
scoreboard players set #gdp driftmountains 30
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[-0.0009f,0.0000f,0.0216f,0.9998f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.1570f,-0.1591f,0.0795f,0.9715f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.0222f,0.9685f,0.1745f,0.1765f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.9897f,0.0130f,0.0019f,0.1423f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0019f,0.1423f,0.9897f,0.0130f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3980f,0.8682f,0.2484f],left_rotation:[0.0070f,-0.1916f,0.9814f,0.0111f]}}
particle minecraft:cloud -63.33 69.38 -34.65 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud -61.75 69.38 -33.99 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -61.75 69.18 -33.99 -0.013 0.02 0.031 1 0 force
scoreboard players set #gx driftmountains -66302
scoreboard players set #gdx driftmountains 439
scoreboard players set #gy driftmountains 69159
scoreboard players set #gdy driftmountains -7
scoreboard players set #gz driftmountains -32487
scoreboard players set #gdz driftmountains -181
scoreboard players set #gr driftmountains -12835
scoreboard players set #gdr driftmountains -214
scoreboard players set #gp driftmountains 84
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[0.0061f,-0.0001f,0.0098f,0.9999f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.7409f,0.1246f,0.0610f,-0.6572f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[-0.1304f,-0.6672f,0.7318f,-0.0475f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.9897f,0.0130f,0.0019f,0.1423f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0019f,0.1423f,0.9897f,0.0130f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3933f,0.8606f,0.1053f],left_rotation:[0.0777f,-0.1726f,0.9071f,0.3758f]}}
particle minecraft:cloud -67.81 69.48 -32.36 0.35 0.18 0.35 0.02 2 force
particle minecraft:cloud -66.77 69.48 -31.05 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -66.77 69.28 -31.05 -0.029 0.02 0.023 1 0 force
