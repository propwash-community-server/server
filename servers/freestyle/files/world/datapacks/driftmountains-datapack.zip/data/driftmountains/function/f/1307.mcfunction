scoreboard players set #gx driftmountains -50495
scoreboard players set #gdx driftmountains 477
scoreboard players set #gy driftmountains 67776
scoreboard players set #gdy driftmountains -12
scoreboard players set #gz driftmountains -83984
scoreboard players set #gdz driftmountains -566
scoreboard players set #gr driftmountains -10784
scoreboard players set #gdr driftmountains 151
scoreboard players set #gp driftmountains 80
scoreboard players set #gdp driftmountains -2
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0001f,-0.0200f,0.9998f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.9571f,0.0908f,-0.2306f,0.1501f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.2476f,0.1752f,0.9528f,0.0093f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.0544f,0.0007f,-0.0131f,-0.9984f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0131f,-0.9984f,0.0544f,0.0007f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3822f,0.8660f,0.1074f],left_rotation:[-0.1188f,0.1502f,-0.7797f,-0.5960f]}}
particle minecraft:cloud -51.95 68.10 -84.39 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -51.95 67.90 -84.39 -0.042 0.02 0.014 1 0 force
particle minecraft:cloud -51.44 68.10 -82.80 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -53156
scoreboard players set #gdx driftmountains 330
scoreboard players set #gy driftmountains 67861
scoreboard players set #gdy driftmountains -12
scoreboard players set #gz driftmountains -79614
scoreboard players set #gdz driftmountains -643
scoreboard players set #gr driftmountains -12029
scoreboard players set #gdr driftmountains 136
scoreboard players set #gp driftmountains 81
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0001f,-0.0203f,0.9998f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.9033f,0.1389f,-0.2110f,0.3469f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.2486f,0.3710f,0.8936f,-0.0447f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.0544f,0.0007f,-0.0131f,-0.9984f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0131f,-0.9984f,0.0544f,0.0007f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3659f,0.8697f,0.2489f],left_rotation:[-0.1196f,0.1496f,-0.7502f,-0.6329f]}}
particle minecraft:cloud -54.77 68.18 -79.66 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -54.77 67.98 -79.66 -0.037 0.02 0.022 1 0 force
particle minecraft:cloud -53.90 68.18 -78.19 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -54500
scoreboard players set #gdx driftmountains 243
scoreboard players set #gy driftmountains 67971
scoreboard players set #gdy driftmountains -16
scoreboard players set #gz driftmountains -74333
scoreboard players set #gdz driftmountains -649
scoreboard players set #gr driftmountains -12784
scoreboard players set #gdr driftmountains 38
scoreboard players set #gp driftmountains 121
scoreboard players set #gdp driftmountains -8
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0001f,-0.0195f,0.9998f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.6192f,0.2146f,-0.1079f,0.7476f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.1870f,0.7630f,0.6001f,-0.1507f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.0544f,0.0007f,-0.0131f,-0.9984f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0131f,-0.9984f,0.0544f,0.0007f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3856f,0.8650f,0.1070f],left_rotation:[-0.1080f,0.1575f,-0.8212f,-0.5377f]}}
particle minecraft:cloud -56.01 68.29 -74.22 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -56.01 68.09 -74.22 -0.031 0.02 0.024 1 0 force
particle minecraft:cloud -54.98 68.29 -72.90 0.35 0.18 0.35 0.02 3 force
