scoreboard players set #gx driftmountains 27581
scoreboard players set #gdx driftmountains 1075
scoreboard players set #gy driftmountains 66517
scoreboard players set #gdy driftmountains -14
scoreboard players set #gz driftmountains -53639
scoreboard players set #gdz driftmountains 598
scoreboard players set #gr driftmountains -5896
scoreboard players set #gdr driftmountains 150
scoreboard players set #gp driftmountains 64
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0000f,-0.0015f,1.0000f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.0543f,0.0120f,0.0518f,0.9971f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.0528f,0.9972f,0.0533f,-0.0064f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.6732f,0.0088f,0.0097f,0.7393f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0097f,0.7393f,0.6732f,0.0088f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3528f,0.8392f,0.0968f],left_rotation:[0.1861f,0.0084f,-0.0798f,0.9792f]}}
scoreboard players set #gx driftmountains 20091
scoreboard players set #gdx driftmountains 944
scoreboard players set #gy driftmountains 66612
scoreboard players set #gdy driftmountains -12
scoreboard players set #gz driftmountains -57990
scoreboard players set #gdz driftmountains 618
scoreboard players set #gr driftmountains -5837
scoreboard players set #gdr driftmountains 48
scoreboard players set #gp driftmountains 62
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[-0.0039f,0.0000f,0.0009f,1.0000f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.5952f,0.0432f,-0.0331f,-0.8017f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[-0.0510f,-0.8027f,0.5940f,0.0191f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.6732f,0.0088f,0.0097f,0.7393f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0097f,0.7393f,0.6732f,0.0088f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3591f,0.8388f,0.2369f],left_rotation:[0.1789f,-0.0314f,0.1356f,0.9740f]}}
scoreboard players set #gx driftmountains 10801
scoreboard players set #gdx driftmountains 976
scoreboard players set #gy driftmountains 66732
scoreboard players set #gdy driftmountains -12
scoreboard players set #gz driftmountains -64280
scoreboard players set #gdz driftmountains 646
scoreboard players set #gr driftmountains -5781
scoreboard players set #gdr driftmountains -51
scoreboard players set #gp driftmountains 60
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,0.0000f,0.0008f,1.0000f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.0194f,-0.0105f,0.0526f,0.9984f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.0521f,0.9983f,0.0206f,0.0126f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.6732f,0.0088f,0.0097f,0.7393f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0097f,0.7393f,0.6732f,0.0088f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3527f,0.8477f,0.1002f],left_rotation:[0.1868f,-0.0263f,0.1055f,0.9763f]}}
