scoreboard players set #gx driftmountains -66282
scoreboard players set #gdx driftmountains 657
scoreboard players set #gy driftmountains 69160
scoreboard players set #gdy driftmountains -11
scoreboard players set #gz driftmountains -31909
scoreboard players set #gdz driftmountains -230
scoreboard players set #gr driftmountains -12445
scoreboard players set #gdr driftmountains -322
scoreboard players set #gp driftmountains 84
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[0.0061f,-0.0001f,0.0094f,0.9999f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.2398f,-0.1082f,0.0814f,0.9613f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.0192f,0.9581f,0.2525f,0.1340f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.9347f,0.0122f,0.0046f,0.3551f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0046f,0.3551f,0.9347f,0.0122f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3921f,0.8616f,0.1056f],left_rotation:[0.0834f,-0.1703f,0.8939f,0.4061f]}}
particle minecraft:cloud -67.79 69.48 -31.89 0.35 0.18 0.35 0.02 2 force
particle minecraft:cloud -66.85 69.48 -30.51 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -66.85 69.28 -30.51 -0.035 0.02 0.024 1 0 force
scoreboard players set #gx driftmountains -72824
scoreboard players set #gdx driftmountains 706
scoreboard players set #gy driftmountains 69254
scoreboard players set #gdy driftmountains -10
scoreboard players set #gz driftmountains -30974
scoreboard players set #gdz driftmountains -323
scoreboard players set #gr driftmountains -11958
scoreboard players set #gdr driftmountains 109
scoreboard players set #gp driftmountains 72
scoreboard players set #gdp driftmountains 1
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[-0.0039f,0.0000f,0.0029f,1.0000f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.9964f,0.0502f,0.0555f,0.0397f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[-0.0516f,0.0340f,0.9966f,0.0542f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.9347f,0.0122f,0.0046f,0.3551f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0046f,0.3551f,0.9347f,0.0122f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3560f,0.8548f,0.2431f],left_rotation:[0.1610f,-0.0945f,0.4619f,0.8671f]}}
scoreboard players set #gx driftmountains -77891
scoreboard players set #gdx driftmountains 669
scoreboard players set #gy driftmountains 69328
scoreboard players set #gdy driftmountains -10
scoreboard players set #gz driftmountains -27523
scoreboard players set #gdz driftmountains -250
scoreboard players set #gr driftmountains -13060
scoreboard players set #gdr driftmountains -15
scoreboard players set #gp driftmountains 79
scoreboard players set #gdp driftmountains -1
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,0.0000f,0.0127f,0.9999f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.7319f,0.1229f,0.0565f,-0.6678f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[-0.1270f,-0.6774f,0.7230f,-0.0467f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.9347f,0.0122f,0.0046f,0.3551f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0046f,0.3551f,0.9347f,0.0122f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3920f,0.8616f,0.1057f],left_rotation:[0.0835f,-0.1702f,0.8935f,0.4070f]}}
particle minecraft:cloud -79.39 69.65 -27.34 0.35 0.18 0.35 0.02 2 force
particle minecraft:cloud -78.30 69.65 -26.07 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -78.30 69.45 -26.07 -0.032 0.02 0.027 1 0 force
