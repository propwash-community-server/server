scoreboard players set #gx driftmountains -35521
scoreboard players set #gdx driftmountains -1170
scoreboard players set #gy driftmountains 70683
scoreboard players set #gdy driftmountains -40
scoreboard players set #gz driftmountains 52489
scoreboard players set #gdz driftmountains -400
scoreboard players set #gr driftmountains 15536
scoreboard players set #gdr driftmountains -11
scoreboard players set #gp driftmountains 131
scoreboard players set #gdp driftmountains -7
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.5278f,0.3527f,-0.1781f,0.7518f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.2581f,0.7747f,0.4937f,-0.2992f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.9581f,0.0125f,0.0037f,0.2860f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0037f,0.2860f,0.9581f,0.0125f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3653f,0.8236f,0.0908f],left_rotation:[-0.1594f,-0.0860f,0.4890f,-0.8532f]}}
particle minecraft:cloud -35.76 71.00 53.98 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -35.76 70.80 53.98 0.031 0.02 0.067 1 0 force
particle minecraft:cloud -34.24 71.00 53.29 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -25656
scoreboard players set #gdx driftmountains -1067
scoreboard players set #gy driftmountains 70983
scoreboard players set #gdy driftmountains -21
scoreboard players set #gz driftmountains 55804
scoreboard players set #gdz driftmountains -326
scoreboard players set #gr driftmountains 15285
scoreboard players set #gdr driftmountains 27
scoreboard players set #gp driftmountains 60
scoreboard players set #gdp driftmountains 23
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.1876f,-0.3650f,-0.1339f,-0.9020f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.0398f,-0.8929f,0.2270f,0.3867f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.9581f,0.0125f,0.0037f,0.2860f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0037f,0.2860f,0.9581f,0.0125f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3848f,0.8274f,0.2324f],left_rotation:[-0.1594f,-0.0801f,0.4333f,-0.8835f]}}
particle minecraft:cloud -25.79 71.30 57.41 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -25.79 71.10 57.41 0.032 0.02 0.063 1 0 force
particle minecraft:cloud -24.27 71.30 56.63 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -20986
scoreboard players set #gdx driftmountains -1135
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 57350
scoreboard players set #gdz driftmountains -320
scoreboard players set #gr driftmountains 15171
scoreboard players set #gdr driftmountains 20
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.9193f,0.0398f,-0.3895f,-0.0402f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.3874f,0.0005f,0.9202f,0.0566f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.9581f,0.0125f,0.0037f,0.2860f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0037f,0.2860f,0.9581f,0.0125f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3638f,0.8245f,0.0911f],left_rotation:[-0.1628f,-0.0800f,0.4579f,-0.8703f]}}
particle minecraft:cloud -21.12 71.32 58.86 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -21.12 71.12 58.86 0.033 0.02 0.062 1 0 force
particle minecraft:cloud -19.65 71.32 58.06 0.35 0.18 0.35 0.02 3 force
