scoreboard players set #gx driftmountains -60570
scoreboard players set #gdx driftmountains 430
scoreboard players set #gy driftmountains 69035
scoreboard players set #gdy driftmountains -18
scoreboard players set #gz driftmountains -34517
scoreboard players set #gdz driftmountains -368
scoreboard players set #gr driftmountains -16222
scoreboard players set #gdr driftmountains -420
scoreboard players set #gp driftmountains 144
scoreboard players set #gdp driftmountains 7
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[-0.0029f,0.0001f,0.0206f,0.9998f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.1624f,-0.1495f,0.0787f,0.9721f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.0230f,0.9692f,0.1791f,0.1674f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.9907f,0.0130f,-0.0018f,-0.1357f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0018f,-0.1357f,0.9907f,0.0130f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.4006f,0.8492f,0.1008f],left_rotation:[0.0246f,-0.1840f,0.9780f,0.0950f]}}
particle minecraft:cloud -61.75 69.36 -33.57 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud -60.16 69.36 -33.06 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -60.16 69.16 -33.06 -0.010 0.02 0.032 1 0 force
scoreboard players set #gx driftmountains -66018
scoreboard players set #gdx driftmountains 675
scoreboard players set #gy driftmountains 69152
scoreboard players set #gdy driftmountains -12
scoreboard players set #gz driftmountains -33765
scoreboard players set #gdz driftmountains -259
scoreboard players set #gr driftmountains -12964
scoreboard players set #gdr driftmountains -359
scoreboard players set #gp driftmountains 87
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[0.0061f,-0.0001f,0.0114f,0.9999f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.0547f,0.1509f,-0.0446f,-0.9860f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[-0.0588f,-0.9868f,0.0391f,-0.1459f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.9907f,0.0130f,-0.0018f,-0.1357f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0018f,-0.1357f,0.9907f,0.0130f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3894f,0.8730f,0.2502f],left_rotation:[0.0425f,-0.1883f,0.9594f,0.2058f]}}
particle minecraft:cloud -67.61 69.47 -33.55 0.35 0.18 0.35 0.02 2 force
particle minecraft:cloud -66.52 69.47 -32.24 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -66.52 69.27 -32.24 -0.031 0.02 0.026 1 0 force
scoreboard players set #gx driftmountains -71024
scoreboard players set #gdx driftmountains 726
scoreboard players set #gy driftmountains 69229
scoreboard players set #gdy driftmountains -10
scoreboard players set #gz driftmountains -30536
scoreboard players set #gdz driftmountains -313
scoreboard players set #gr driftmountains -11811
scoreboard players set #gdr driftmountains -11
scoreboard players set #gp driftmountains 74
scoreboard players set #gdp driftmountains 1
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[-0.0033f,0.0000f,0.0028f,1.0000f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.8314f,0.0145f,0.0731f,0.5507f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[-0.0156f,0.5460f,0.8344f,0.0728f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.9907f,0.0130f,-0.0018f,-0.1357f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0018f,-0.1357f,0.9907f,0.0130f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3622f,0.8620f,0.1058f],left_rotation:[0.1685f,-0.0917f,0.4584f,0.8677f]}}
