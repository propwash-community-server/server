scoreboard players set #gx driftmountains 12576
scoreboard players set #gdx driftmountains 449
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains -4278
scoreboard players set #gdz driftmountains 899
scoreboard players set #gr driftmountains 1142
scoreboard players set #gdr driftmountains 29
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.5063f,0.2981f,-0.1234f,0.7997f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.2081f,0.8171f,0.4778f,-0.2465f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.0729f,0.0010f,-0.0131f,-0.9973f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0131f,-0.9973f,0.0729f,0.0010f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3538f,0.8515f,0.1017f],left_rotation:[-0.1849f,0.0420f,-0.1894f,-0.9634f]}}
particle minecraft:cloud 13.64 71.32 -5.35 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 13.64 71.12 -5.35 0.012 0.02 -0.059 1 0 force
particle minecraft:cloud 12.01 71.32 -5.68 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains 9453
scoreboard players set #gdx driftmountains 474
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains -9970
scoreboard players set #gdz driftmountains 902
scoreboard players set #gr driftmountains 1005
scoreboard players set #gdr driftmountains 17
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.1470f,-0.3065f,-0.1041f,-0.9347f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.0065f,-0.9289f,0.1800f,0.3236f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.0729f,0.0010f,-0.0131f,-0.9973f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0131f,-0.9973f,0.0729f,0.0010f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3581f,0.8407f,0.2376f],left_rotation:[-0.1778f,0.0399f,-0.1792f,-0.9668f]}}
particle minecraft:cloud 10.53 71.32 -11.16 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 10.53 71.12 -11.16 0.010 0.02 -0.057 1 0 force
particle minecraft:cloud 8.85 71.32 -11.46 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains 6772
scoreboard players set #gdx driftmountains 438
scoreboard players set #gy driftmountains 70963
scoreboard players set #gdy driftmountains 27
scoreboard players set #gz driftmountains -14920
scoreboard players set #gdz driftmountains 795
scoreboard players set #gr driftmountains 1116
scoreboard players set #gdr driftmountains -73
scoreboard players set #gp driftmountains -159
scoreboard players set #gdp driftmountains 56
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.6233f,0.2898f,-0.1826f,0.7030f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.2575f,0.7260f,0.5962f,-0.2259f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.0729f,0.0010f,-0.0131f,-0.9973f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0131f,-0.9973f,0.0729f,0.0010f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3523f,0.8428f,0.0983f],left_rotation:[-0.1872f,0.0064f,0.0009f,-0.9823f]}}
particle minecraft:cloud 7.83 71.28 -15.99 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 7.83 71.08 -15.99 0.010 0.02 -0.053 1 0 force
particle minecraft:cloud 6.20 71.28 -16.32 0.35 0.18 0.35 0.02 3 force
