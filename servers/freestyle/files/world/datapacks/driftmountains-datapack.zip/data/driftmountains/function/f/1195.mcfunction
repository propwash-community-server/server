scoreboard players set #gx driftmountains -81963
scoreboard players set #gdx driftmountains 610
scoreboard players set #gy driftmountains 69399
scoreboard players set #gdy driftmountains -11
scoreboard players set #gz driftmountains -26778
scoreboard players set #gdz driftmountains -60
scoreboard players set #gr driftmountains -8791
scoreboard players set #gdr driftmountains -709
scoreboard players set #gp driftmountains 106
scoreboard players set #gdp driftmountains -2
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0000f,-0.0043f,1.0000f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.4452f,0.0921f,0.0126f,0.8906f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.0809f,0.8942f,0.4379f,-0.0458f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.9539f,0.0125f,0.0039f,0.2997f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0039f,0.2997f,0.9539f,0.0125f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3735f,0.8212f,0.0898f],left_rotation:[0.1395f,0.1133f,-0.6315f,0.7541f]}}
scoreboard players set #gx driftmountains -87610
scoreboard players set #gdx driftmountains 523
scoreboard players set #gy driftmountains 69535
scoreboard players set #gdy driftmountains -16
scoreboard players set #gz driftmountains -25614
scoreboard players set #gdz driftmountains -343
scoreboard players set #gr driftmountains -7876
scoreboard players set #gdr driftmountains 164
scoreboard players set #gp driftmountains 104
scoreboard players set #gdp driftmountains 1
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.2051f,-0.2866f,-0.1197f,-0.9281f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.0228f,-0.9207f,0.2364f,0.3098f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.9539f,0.0125f,0.0039f,0.2997f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0039f,0.2997f,0.9539f,0.0125f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3561f,0.8464f,0.2398f],left_rotation:[-0.1728f,0.0633f,-0.2999f,-0.9361f]}}
particle minecraft:cloud -88.78 69.86 -26.72 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -88.78 69.66 -26.72 -0.037 0.02 -0.007 1 0 force
particle minecraft:cloud -89.12 69.86 -25.04 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -90362
scoreboard players set #gdx driftmountains 574
scoreboard players set #gy driftmountains 69635
scoreboard players set #gdy driftmountains -19
scoreboard players set #gz driftmountains -23217
scoreboard players set #gdz driftmountains -399
scoreboard players set #gr driftmountains -7998
scoreboard players set #gdr driftmountains 187
scoreboard players set #gp driftmountains 107
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.7895f,0.2281f,-0.2495f,0.5123f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.3047f,0.5413f,0.7699f,-0.1463f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.9539f,0.0125f,0.0039f,0.2997f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0039f,0.2997f,0.9539f,0.0125f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3523f,0.8448f,0.0991f],left_rotation:[-0.1873f,0.0146f,-0.0430f,-0.9812f]}}
particle minecraft:cloud -91.46 69.95 -24.26 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -91.46 69.75 -24.26 -0.042 0.02 -0.007 1 0 force
particle minecraft:cloud -91.75 69.95 -22.61 0.35 0.18 0.35 0.02 3 force
