scoreboard players set #gx driftmountains 15681
scoreboard players set #gdx driftmountains 434
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 2204
scoreboard players set #gdz driftmountains 963
scoreboard players set #gr driftmountains 1246
scoreboard players set #gdr driftmountains 27
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.2826f,0.3085f,-0.0385f,0.9075f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.1340f,0.9165f,0.2517f,-0.2805f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.3446f,0.0045f,-0.0123f,-0.9387f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0123f,-0.9387f,0.3446f,0.0045f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3563f,0.8562f,0.1035f],left_rotation:[-0.1803f,0.0621f,-0.2981f,-0.9352f]}}
particle minecraft:cloud 16.77 71.32 1.15 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 16.77 71.12 1.15 0.014 0.02 -0.062 1 0 force
particle minecraft:cloud 15.14 71.32 0.79 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains 12649
scoreboard players set #gdx driftmountains 463
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains -3702
scoreboard players set #gdz driftmountains 942
scoreboard players set #gr driftmountains 1137
scoreboard players set #gdr driftmountains 12
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.3842f,-0.2677f,-0.1793f,-0.8652f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.0893f,-0.8511f,0.4145f,0.3095f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.3446f,0.0045f,-0.0123f,-0.9387f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0123f,-0.9387f,0.3446f,0.0045f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3578f,0.8413f,0.2378f],left_rotation:[-0.1773f,0.0426f,-0.1931f,-0.9641f]}}
particle minecraft:cloud 13.76 71.32 -4.87 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 13.76 71.12 -4.87 0.012 0.02 -0.061 1 0 force
particle minecraft:cloud 12.08 71.32 -5.21 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains 9891
scoreboard players set #gdx driftmountains 464
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains -9185
scoreboard players set #gdz driftmountains 889
scoreboard players set #gr driftmountains 962
scoreboard players set #gdr driftmountains 34
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.4227f,0.3039f,-0.0898f,0.8490f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.1795f,0.8632f,0.3931f,-0.2612f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.3446f,0.0045f,-0.0123f,-0.9387f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0123f,-0.9387f,0.3446f,0.0045f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3548f,0.8538f,0.1026f],left_rotation:[-0.1829f,0.0518f,-0.2426f,-0.9513f]}}
particle minecraft:cloud 10.92 71.32 -10.29 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 10.92 71.12 -10.29 0.010 0.02 -0.059 1 0 force
particle minecraft:cloud 9.28 71.32 -10.57 0.35 0.18 0.35 0.02 3 force
