scoreboard players set #gx driftmountains -37866
scoreboard players set #gdx driftmountains -1180
scoreboard players set #gy driftmountains 70606
scoreboard players set #gdy driftmountains -34
scoreboard players set #gz driftmountains 51683
scoreboard players set #gdz driftmountains -415
scoreboard players set #gr driftmountains 15498
scoreboard players set #gdr driftmountains -24
scoreboard players set #gp driftmountains 115
scoreboard players set #gdp driftmountains -11
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.0810f,0.3856f,0.0229f,0.9188f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.0735f,0.9215f,0.0409f,-0.3792f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.6832f,0.0089f,0.0096f,0.7301f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0096f,0.7301f,0.6832f,0.0089f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3617f,0.8258f,0.0916f],left_rotation:[-0.1674f,-0.0712f,0.4118f,-0.8929f]}}
particle minecraft:cloud -38.09 70.93 53.18 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -38.09 70.73 53.18 0.032 0.02 0.068 1 0 force
particle minecraft:cloud -36.58 70.93 52.47 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -27969
scoreboard players set #gdx driftmountains -1140
scoreboard players set #gy driftmountains 70933
scoreboard players set #gdy driftmountains -31
scoreboard players set #gz driftmountains 55091
scoreboard players set #gdz driftmountains -359
scoreboard players set #gr driftmountains 15348
scoreboard players set #gdr driftmountains 40
scoreboard players set #gp driftmountains 97
scoreboard players set #gdp driftmountains 11
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.6132f,-0.2500f,-0.2991f,-0.6871f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.2286f,-0.6594f,0.6428f,0.3158f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.6832f,0.0089f,0.0096f,0.7301f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0096f,0.7301f,0.6832f,0.0089f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3853f,0.8275f,0.2324f],left_rotation:[-0.1585f,-0.0819f,0.4426f,-0.8788f]}}
particle minecraft:cloud -28.12 71.25 56.69 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -28.12 71.05 56.69 0.033 0.02 0.065 1 0 force
particle minecraft:cloud -26.59 71.25 55.93 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -23278
scoreboard players set #gdx driftmountains -1150
scoreboard players set #gy driftmountains 70999
scoreboard players set #gdy driftmountains -4
scoreboard players set #gz driftmountains 56702
scoreboard players set #gdz driftmountains -331
scoreboard players set #gr driftmountains 15213
scoreboard players set #gdr driftmountains 23
scoreboard players set #gp driftmountains 6
scoreboard players set #gdp driftmountains 18
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.8160f,0.2295f,-0.3179f,0.4247f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.3643f,0.4604f,0.7964f,-0.1450f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.6832f,0.0089f,0.0096f,0.7301f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0096f,0.7301f,0.6832f,0.0089f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3640f,0.8243f,0.0910f],left_rotation:[-0.1623f,-0.0809f,0.4627f,-0.8677f]}}
particle minecraft:cloud -23.43 71.32 58.21 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -23.43 71.12 58.21 0.034 0.02 0.064 1 0 force
particle minecraft:cloud -21.95 71.32 57.43 0.35 0.18 0.35 0.02 3 force
