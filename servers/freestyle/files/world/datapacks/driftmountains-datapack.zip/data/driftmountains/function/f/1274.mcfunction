scoreboard players set #gx driftmountains -55832
scoreboard players set #gdx driftmountains -118
scoreboard players set #gy driftmountains 68218
scoreboard players set #gdy driftmountains -13
scoreboard players set #gz driftmountains -63611
scoreboard players set #gdz driftmountains -746
scoreboard players set #gr driftmountains -17279
scoreboard players set #gdr driftmountains 391
scoreboard players set #gp driftmountains 91
scoreboard players set #gdp driftmountains -1
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[0.0061f,0.0001f,-0.0100f,0.9999f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.1433f,-0.1225f,-0.0713f,-0.9795f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[-0.0313f,-0.9774f,0.1570f,0.1382f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.7253f,0.0095f,0.0090f,0.6883f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0090f,0.6883f,0.7253f,0.0095f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3955f,0.8291f,0.0929f],left_rotation:[0.0621f,0.1693f,-0.9161f,0.3580f]}}
particle minecraft:cloud -56.82 68.54 -62.47 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -56.82 68.34 -62.47 -0.006 0.02 0.045 1 0 force
particle minecraft:cloud -55.16 68.54 -62.26 0.35 0.18 0.35 0.02 2 force
scoreboard players set #gx driftmountains -54344
scoreboard players set #gdx driftmountains -108
scoreboard players set #gy driftmountains 68328
scoreboard players set #gdy driftmountains -13
scoreboard players set #gz driftmountains -57491
scoreboard players set #gdz driftmountains -695
scoreboard players set #gr driftmountains 15293
scoreboard players set #gdr driftmountains 335
scoreboard players set #gp driftmountains 100
scoreboard players set #gdp driftmountains -1
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[-0.0039f,0.0000f,0.0113f,0.9999f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.9649f,0.0830f,0.1312f,-0.2119f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[-0.1542f,-0.2269f,0.9615f,0.0180f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.7253f,0.0095f,0.0090f,0.6883f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0090f,0.6883f,0.7253f,0.0095f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3884f,0.8733f,0.2504f],left_rotation:[0.0461f,-0.1875f,0.9550f,0.2253f]}}
particle minecraft:cloud -54.48 68.65 -55.89 0.35 0.18 0.35 0.02 2 force
particle minecraft:cloud -52.96 68.65 -56.66 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -52.96 68.45 -56.66 0.019 0.02 0.038 1 0 force
scoreboard players set #gx driftmountains -53998
scoreboard players set #gdx driftmountains 97
scoreboard players set #gy driftmountains 68470
scoreboard players set #gdy driftmountains -24
scoreboard players set #gz driftmountains -51775
scoreboard players set #gdz driftmountains -675
scoreboard players set #gr driftmountains 15959
scoreboard players set #gdr driftmountains -461
scoreboard players set #gp driftmountains 186
scoreboard players set #gdp driftmountains -21
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[0.0061f,-0.0001f,0.0190f,0.9998f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.8785f,-0.0396f,0.2019f,0.4312f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[-0.1577f,0.4124f,0.8875f,0.1322f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.7253f,0.0095f,0.0090f,0.6883f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0090f,0.6883f,0.7253f,0.0095f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3986f,0.8334f,0.0946f],left_rotation:[-0.0414f,-0.1766f,0.9510f,-0.2504f]}}
particle minecraft:cloud -54.34 68.79 -50.30 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud -52.78 68.79 -50.88 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -52.78 68.59 -50.88 0.014 0.02 0.038 1 0 force
