scoreboard players set #gx driftmountains -78875
scoreboard players set #gdx driftmountains 624
scoreboard players set #gy driftmountains 69344
scoreboard players set #gdy driftmountains -10
scoreboard players set #gz driftmountains -27295
scoreboard players set #gdz driftmountains -178
scoreboard players set #gr driftmountains -12021
scoreboard players set #gdr driftmountains -516
scoreboard players set #gp driftmountains 87
scoreboard players set #gdp driftmountains -5
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,0.0000f,0.0093f,0.9999f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.8833f,0.0789f,0.0378f,-0.4607f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[-0.0864f,-0.4672f,0.8798f,0.0135f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.9984f,0.0131f,0.0007f,0.0548f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0007f,0.0548f,0.9984f,0.0131f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3689f,0.8653f,0.1071f],left_rotation:[0.1537f,-0.1155f,0.5879f,0.7857f]}}
particle minecraft:cloud -80.38 69.66 -27.38 0.35 0.18 0.35 0.02 2 force
particle minecraft:cloud -79.54 69.66 -25.94 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -79.54 69.46 -25.94 -0.033 0.02 0.019 1 0 force
scoreboard players set #gx driftmountains -84951
scoreboard players set #gdx driftmountains 587
scoreboard players set #gy driftmountains 69459
scoreboard players set #gdy driftmountains -14
scoreboard players set #gz driftmountains -26946
scoreboard players set #gdz driftmountains -167
scoreboard players set #gr driftmountains -7807
scoreboard players set #gdr driftmountains -98
scoreboard players set #gp driftmountains 119
scoreboard players set #gdp driftmountains -3
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0001f,-0.0181f,0.9998f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.8884f,0.1121f,-0.1098f,0.4314f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.1557f,0.4453f,0.8815f,-0.0194f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.9984f,0.0131f,0.0007f,0.0548f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0007f,0.0548f,0.9984f,0.0131f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.4046f,0.8591f,0.2448f],left_rotation:[0.0349f,0.1858f,-0.9576f,0.2175f]}}
particle minecraft:cloud -86.11 69.78 -28.06 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -86.11 69.58 -28.06 -0.035 0.02 -0.007 1 0 force
particle minecraft:cloud -86.46 69.78 -26.39 0.35 0.18 0.35 0.02 2 force
scoreboard players set #gx driftmountains -87824
scoreboard players set #gdx driftmountains 357
scoreboard players set #gy driftmountains 69555
scoreboard players set #gdy driftmountains -11
scoreboard players set #gz driftmountains -24812
scoreboard players set #gdz driftmountains -199
scoreboard players set #gr driftmountains -7233
scoreboard players set #gdr driftmountains 25
scoreboard players set #gp driftmountains 104
scoreboard players set #gdp driftmountains -1
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.6781f,-0.1940f,-0.2828f,-0.6500f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.2161f,-0.6238f,0.7023f,0.2664f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.9984f,0.0131f,0.0007f,0.0548f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0007f,0.0548f,0.9984f,0.0131f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3523f,0.8426f,0.0982f],left_rotation:[-0.1872f,0.0057f,0.0048f,-0.9822f]}}
particle minecraft:cloud -88.77 69.87 -25.99 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -88.77 69.67 -25.99 -0.032 0.02 -0.010 1 0 force
particle minecraft:cloud -89.28 69.87 -24.40 0.35 0.18 0.35 0.02 3 force
