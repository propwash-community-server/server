scoreboard players set #gx driftmountains -11035
scoreboard players set #gdx driftmountains 773
scoreboard players set #gy driftmountains 67015
scoreboard players set #gdy driftmountains -10
scoreboard players set #gz driftmountains -78709
scoreboard players set #gdz driftmountains 497
scoreboard players set #gr driftmountains -3976
scoreboard players set #gdr driftmountains -130
scoreboard players set #gp driftmountains 62
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0000f,-0.0107f,0.9999f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.3140f,0.1585f,0.0027f,0.9361f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.0957f,0.9410f,0.2991f,-0.1264f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.8936f,0.0117f,0.0059f,0.4487f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0059f,0.4487f,0.8936f,0.0117f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3996f,0.8355f,0.0954f],left_rotation:[0.0322f,0.1790f,-0.9622f,0.2025f]}}
particle minecraft:cloud -11.20 67.33 -80.21 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -11.20 67.13 -80.21 -0.035 0.02 -0.042 1 0 force
particle minecraft:cloud -12.48 67.33 -79.14 0.35 0.18 0.35 0.02 2 force
scoreboard players set #gx driftmountains -17741
scoreboard players set #gdx driftmountains 747
scoreboard players set #gy driftmountains 67105
scoreboard players set #gdy driftmountains -11
scoreboard players set #gz driftmountains -82502
scoreboard players set #gdz driftmountains 468
scoreboard players set #gr driftmountains -3157
scoreboard players set #gdr driftmountains -74
scoreboard players set #gp driftmountains 63
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0001f,-0.0161f,0.9999f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.3463f,-0.1908f,-0.1301f,-0.9093f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.0353f,-0.9006f,0.3683f,0.2282f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.8936f,0.0117f,0.0059f,0.4487f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0059f,0.4487f,0.8936f,0.0117f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3754f,0.8737f,0.2505f],left_rotation:[-0.0892f,0.1711f,-0.8648f,-0.4636f]}}
particle minecraft:cloud -17.73 67.43 -84.11 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -17.73 67.23 -84.11 -0.028 0.02 -0.045 1 0 force
particle minecraft:cloud -19.18 67.43 -83.22 0.35 0.18 0.35 0.02 2 force
scoreboard players set #gx driftmountains -25013
scoreboard players set #gdx driftmountains 704
scoreboard players set #gy driftmountains 67219
scoreboard players set #gdy driftmountains -11
scoreboard players set #gz driftmountains -87529
scoreboard players set #gdz driftmountains 389
scoreboard players set #gr driftmountains -3248
scoreboard players set #gdr driftmountains 45
scoreboard players set #gp driftmountains 69
scoreboard players set #gdp driftmountains -1
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0001f,-0.0176f,0.9998f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.5964f,0.2177f,-0.1013f,0.7659f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.1824f,0.7808f,0.5768f,-0.1562f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.8936f,0.0117f,0.0059f,0.4487f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0059f,0.4487f,0.8936f,0.0117f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3856f,0.8650f,0.1070f],left_rotation:[-0.1078f,0.1576f,-0.8217f,-0.5369f]}}
particle minecraft:cloud -24.99 67.54 -89.04 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -24.99 67.34 -89.04 -0.026 0.02 -0.040 1 0 force
particle minecraft:cloud -26.39 67.54 -88.14 0.35 0.18 0.35 0.02 2 force
