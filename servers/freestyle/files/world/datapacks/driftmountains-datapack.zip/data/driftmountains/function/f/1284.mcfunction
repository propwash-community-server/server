scoreboard players set #gx driftmountains -56616
scoreboard players set #gdx driftmountains 4
scoreboard players set #gy driftmountains 68090
scoreboard players set #gdy driftmountains -15
scoreboard players set #gz driftmountains -70464
scoreboard players set #gdz driftmountains -610
scoreboard players set #gr driftmountains -14784
scoreboard players set #gdr driftmountains 352
scoreboard players set #gp driftmountains 108
scoreboard players set #gdp driftmountains 15
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[0.0061f,0.0001f,-0.0204f,0.9998f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.6078f,0.1906f,-0.0829f,0.7664f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.1640f,0.7793f,0.5911f,-0.1277f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.9663f,0.0126f,0.0034f,0.2571f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0034f,0.2571f,0.9663f,0.0126f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3972f,0.8563f,0.1036f],left_rotation:[-0.0560f,0.1793f,-0.9470f,-0.2606f]}}
particle minecraft:cloud -57.99 68.41 -69.84 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -57.99 68.21 -69.84 -0.020 0.02 0.031 1 0 force
particle minecraft:cloud -56.58 68.41 -68.95 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -55446
scoreboard players set #gdx driftmountains -103
scoreboard players set #gy driftmountains 68202
scoreboard players set #gdy driftmountains -14
scoreboard players set #gz driftmountains -64883
scoreboard players set #gdz driftmountains -799
scoreboard players set #gr driftmountains -16533
scoreboard players set #gdr driftmountains 268
scoreboard players set #gp driftmountains 89
scoreboard players set #gdp driftmountains 1
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[0.0013f,0.0000f,-0.0135f,0.9999f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.4977f,0.1839f,-0.0464f,0.8463f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.1356f,0.8559f,0.4811f,-0.1326f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.9663f,0.0126f,0.0034f,0.2571f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0034f,0.2571f,0.9663f,0.0126f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3947f,0.8706f,0.2493f],left_rotation:[-0.0220f,0.1911f,-0.9769f,-0.0929f]}}
particle minecraft:cloud -56.62 68.52 -63.78 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -56.62 68.32 -63.78 -0.012 0.02 0.046 1 0 force
particle minecraft:cloud -54.96 68.52 -63.35 0.35 0.18 0.35 0.02 2 force
scoreboard players set #gx driftmountains -54302
scoreboard players set #gdx driftmountains -92
scoreboard players set #gy driftmountains 68313
scoreboard players set #gdy driftmountains -12
scoreboard players set #gz driftmountains -58380
scoreboard players set #gdz driftmountains -698
scoreboard players set #gr driftmountains 15938
scoreboard players set #gdr driftmountains 372
scoreboard players set #gp driftmountains 98
scoreboard players set #gdp driftmountains -1
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,0.0000f,0.0080f,1.0000f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.9913f,0.0470f,0.1117f,0.0510f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[-0.1069f,0.0395f,0.9918f,0.0570f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.9663f,0.0126f,0.0034f,0.2571f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0034f,0.2571f,0.9663f,0.0126f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3860f,0.8649f,0.1069f],left_rotation:[0.1064f,-0.1585f,0.8266f,0.5294f]}}
particle minecraft:cloud -54.64 68.63 -56.91 0.35 0.18 0.35 0.02 2 force
particle minecraft:cloud -53.08 68.63 -57.49 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -53.08 68.43 -57.49 0.015 0.02 0.039 1 0 force
