scoreboard players set #gx driftmountains -37319
scoreboard players set #gdx driftmountains 643
scoreboard players set #gy driftmountains 67442
scoreboard players set #gdy driftmountains -17
scoreboard players set #gz driftmountains -91632
scoreboard players set #gdz driftmountains 23
scoreboard players set #gr driftmountains -5456
scoreboard players set #gdr driftmountains 372
scoreboard players set #gp driftmountains 131
scoreboard players set #gdp driftmountains -23
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0001f,-0.0217f,0.9998f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.0472f,-0.2205f,-0.0645f,-0.9721f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[-0.0374f,-0.9707f,0.0706f,0.2267f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.9885f,0.0129f,-0.0020f,-0.1506f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0020f,-0.1506f,0.9885f,0.0129f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3900f,0.8630f,0.1062f],left_rotation:[-0.0921f,0.1663f,-0.8712f,-0.4526f]}}
particle minecraft:cloud -37.86 67.76 -93.04 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -37.86 67.56 -93.04 -0.031 0.02 -0.022 1 0 force
particle minecraft:cloud -38.83 67.76 -91.68 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -42523
scoreboard players set #gdx driftmountains 587
scoreboard players set #gy driftmountains 67586
scoreboard players set #gdy driftmountains -15
scoreboard players set #gz driftmountains -90898
scoreboard players set #gdz driftmountains -238
scoreboard players set #gr driftmountains -7575
scoreboard players set #gdr driftmountains 321
scoreboard players set #gp driftmountains 105
scoreboard players set #gdp driftmountains 2
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.3255f,-0.1812f,-0.1209f,-0.9201f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.0249f,-0.9124f,0.3464f,0.2164f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.9885f,0.0129f,-0.0020f,-0.1506f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0020f,-0.1506f,0.9885f,0.0129f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3817f,0.8743f,0.2508f],left_rotation:[-0.0689f,0.1805f,-0.9161f,-0.3514f]}}
particle minecraft:cloud -43.64 67.91 -92.06 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -43.64 67.71 -92.06 -0.025 0.02 -0.006 1 0 force
particle minecraft:cloud -44.06 67.91 -90.41 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -46272
scoreboard players set #gdx driftmountains 378
scoreboard players set #gy driftmountains 67677
scoreboard players set #gdy driftmountains -9
scoreboard players set #gz driftmountains -88153
scoreboard players set #gdz driftmountains -378
scoreboard players set #gr driftmountains -10220
scoreboard players set #gdr driftmountains 139
scoreboard players set #gp driftmountains 84
scoreboard players set #gdp driftmountains 2
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[0.0061f,0.0001f,-0.0203f,0.9998f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.0134f,-0.2335f,-0.0571f,-0.9706f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[-0.0446f,-0.9699f,0.0380f,0.2362f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.9885f,0.0129f,-0.0020f,-0.1506f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0020f,-0.1506f,0.9885f,0.0129f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3855f,0.8651f,0.1070f],left_rotation:[-0.1082f,0.1574f,-0.8204f,-0.5389f]}}
particle minecraft:cloud -47.68 68.00 -88.70 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -47.68 67.80 -88.70 -0.030 0.02 0.006 1 0 force
particle minecraft:cloud -47.33 68.00 -87.07 0.35 0.18 0.35 0.02 3 force
