scoreboard players set #gx driftmountains -24153
scoreboard players set #gdx driftmountains -1109
scoreboard players set #gy driftmountains 70998
scoreboard players set #gdy driftmountains -8
scoreboard players set #gz driftmountains 56212
scoreboard players set #gdz driftmountains -353
scoreboard players set #gr driftmountains 15426
scoreboard players set #gdr driftmountains 20
scoreboard players set #gp driftmountains 16
scoreboard players set #gdp driftmountains 29
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.0812f,0.3957f,0.0220f,0.9145f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.0740f,0.9172f,0.0401f,-0.3894f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.7043f,0.0092f,0.0093f,0.7098f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0093f,0.7098f,0.7043f,0.0092f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3658f,0.8234f,0.0907f],left_rotation:[-0.1582f,-0.0879f,0.4992f,-0.8473f]}}
particle minecraft:cloud -24.36 71.32 57.71 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -24.36 71.12 57.71 0.030 0.02 0.063 1 0 force
particle minecraft:cloud -22.85 71.32 56.98 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -14866
scoreboard players set #gdx driftmountains -1022
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 58882
scoreboard players set #gdz driftmountains -277
scoreboard players set #gr driftmountains 15064
scoreboard players set #gdr driftmountains 14
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.6141f,-0.2478f,-0.2972f,-0.6878f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.2266f,-0.6604f,0.6435f,0.3137f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.7043f,0.0092f,0.0093f,0.7098f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0093f,0.7098f,0.7043f,0.0092f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3839f,0.8273f,0.2323f],left_rotation:[-0.1609f,-0.0770f,0.4177f,-0.8909f]}}
particle minecraft:cloud -14.94 71.32 60.49 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -14.94 71.12 60.49 0.031 0.02 0.056 1 0 force
particle minecraft:cloud -13.45 71.32 59.65 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -10119
scoreboard players set #gdx driftmountains -1060
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 60331
scoreboard players set #gdz driftmountains -286
scoreboard players set #gr driftmountains 15250
scoreboard players set #gdr driftmountains -65
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.8121f,0.2347f,-0.3279f,0.4218f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.3741f,0.4586f,0.7919f,-0.1507f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.7043f,0.0092f,0.0093f,0.7098f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0093f,0.7098f,0.7043f,0.0092f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3690f,0.8222f,0.0902f],left_rotation:[-0.1508f,-0.0989f,0.5567f,-0.8109f]}}
particle minecraft:cloud -10.28 71.32 61.83 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -10.28 71.12 61.83 0.030 0.02 0.058 1 0 force
particle minecraft:cloud -8.80 71.32 61.06 0.35 0.18 0.35 0.02 3 force
