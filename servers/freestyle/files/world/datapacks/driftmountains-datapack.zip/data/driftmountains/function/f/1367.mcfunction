scoreboard players set #gx driftmountains -11802
scoreboard players set #gdx driftmountains 768
scoreboard players set #gy driftmountains 67025
scoreboard players set #gdy driftmountains -10
scoreboard players set #gz driftmountains -79201
scoreboard players set #gdz driftmountains 492
scoreboard players set #gr driftmountains -3860
scoreboard players set #gdr driftmountains -115
scoreboard players set #gp driftmountains 62
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0000f,-0.0115f,0.9999f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.8212f,-0.0444f,-0.1628f,-0.5451f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.1064f,-0.5310f,0.8304f,0.1310f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.1997f,0.0026f,-0.0128f,-0.9798f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0128f,-0.9798f,0.1997f,0.0026f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.4009f,0.8399f,0.0971f],left_rotation:[0.0138f,0.1825f,-0.9773f,0.1067f]}}
particle minecraft:cloud -11.94 67.35 -80.71 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -11.94 67.15 -80.71 -0.034 0.02 -0.043 1 0 force
particle minecraft:cloud -13.24 67.35 -79.66 0.35 0.18 0.35 0.02 2 force
scoreboard players set #gx driftmountains -18482
scoreboard players set #gdx driftmountains 741
scoreboard players set #gy driftmountains 67116
scoreboard players set #gdy driftmountains -11
scoreboard players set #gz driftmountains -82965
scoreboard players set #gdz driftmountains 463
scoreboard players set #gr driftmountains -3100
scoreboard players set #gdr driftmountains -57
scoreboard players set #gp driftmountains 63
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0001f,-0.0165f,0.9999f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.9668f,0.0768f,-0.2229f,0.0988f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.2345f,0.1228f,0.9640f,0.0244f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.1997f,0.0026f,-0.0128f,-0.9798f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0128f,-0.9798f,0.1997f,0.0026f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3732f,0.8732f,0.2503f],left_rotation:[-0.0963f,0.1669f,-0.8424f,-0.5033f]}}
particle minecraft:cloud -18.45 67.44 -84.58 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -18.45 67.24 -84.58 -0.027 0.02 -0.045 1 0 force
particle minecraft:cloud -19.92 67.44 -83.70 0.35 0.18 0.35 0.02 2 force
scoreboard players set #gx driftmountains -25712
scoreboard players set #gdx driftmountains 699
scoreboard players set #gy driftmountains 67230
scoreboard players set #gdy driftmountains -11
scoreboard players set #gz driftmountains -87907
scoreboard players set #gdz driftmountains 378
scoreboard players set #gr driftmountains -3292
scoreboard players set #gdr driftmountains 44
scoreboard players set #gp driftmountains 70
scoreboard players set #gdp driftmountains -1
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0001f,-0.0177f,0.9998f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.4974f,-0.1742f,-0.1667f,-0.8333f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.0800f,-0.8204f,0.5184f,0.2275f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.1997f,0.0026f,-0.0128f,-0.9798f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0128f,-0.9798f,0.1997f,0.0026f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3852f,0.8652f,0.1070f],left_rotation:[-0.1093f,0.1567f,-0.8164f,-0.5448f]}}
particle minecraft:cloud -25.70 67.55 -89.42 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -25.70 67.35 -89.42 -0.026 0.02 -0.040 1 0 force
particle minecraft:cloud -27.10 67.55 -88.51 0.35 0.18 0.35 0.02 2 force
