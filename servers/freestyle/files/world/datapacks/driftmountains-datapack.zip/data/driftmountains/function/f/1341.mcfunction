scoreboard players set #gx driftmountains -30160
scoreboard players set #gdx driftmountains 659
scoreboard players set #gy driftmountains 67301
scoreboard players set #gdy driftmountains -11
scoreboard players set #gz driftmountains -89682
scoreboard players set #gdz driftmountains 298
scoreboard players set #gr driftmountains -3600
scoreboard players set #gdr driftmountains 59
scoreboard players set #gp driftmountains 77
scoreboard players set #gdp driftmountains -1
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0001f,-0.0184f,0.9998f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.9400f,-0.0063f,-0.2429f,-0.2396f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.2190f,-0.2154f,0.9458f,0.1051f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.3765f,0.0049f,0.0121f,0.9263f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0121f,0.9263f,0.3765f,0.0049f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3844f,0.8654f,0.1071f],left_rotation:[-0.1119f,0.1550f,-0.8068f,-0.5589f]}}
particle minecraft:cloud -30.23 67.62 -91.19 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -30.23 67.42 -91.19 -0.025 0.02 -0.035 1 0 force
particle minecraft:cloud -31.58 67.62 -90.21 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -35896
scoreboard players set #gdx driftmountains 615
scoreboard players set #gy driftmountains 67409
scoreboard players set #gdy driftmountains -12
scoreboard players set #gz driftmountains -91513
scoreboard players set #gdz driftmountains 108
scoreboard players set #gr driftmountains -4631
scoreboard players set #gdr driftmountains 171
scoreboard players set #gp driftmountains 90
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0001f,-0.0213f,0.9998f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.2514f,0.2232f,-0.0041f,0.9418f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.1031f,0.9474f,0.2293f,-0.1980f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.3765f,0.0049f,0.0121f,0.9263f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0121f,0.9263f,0.3765f,0.0049f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3791f,0.8742f,0.2507f],left_rotation:[-0.0774f,0.1770f,-0.8967f,-0.3984f]}}
particle minecraft:cloud -36.29 67.73 -93.07 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -36.29 67.53 -93.07 -0.027 0.02 -0.026 1 0 force
particle minecraft:cloud -37.47 67.73 -91.84 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -41441
scoreboard players set #gdx driftmountains 612
scoreboard players set #gy driftmountains 67555
scoreboard players set #gdy driftmountains -16
scoreboard players set #gz driftmountains -91684
scoreboard players set #gdz driftmountains -245
scoreboard players set #gr driftmountains -7783
scoreboard players set #gdr driftmountains 409
scoreboard players set #gp driftmountains 110
scoreboard players set #gdp driftmountains 5
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[0.0061f,0.0001f,-0.0221f,0.9997f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.5058f,-0.1355f,-0.1439f,-0.8397f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.0564f,-0.8292f,0.5229f,0.1894f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.3765f,0.0049f,0.0121f,0.9263f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0121f,0.9263f,0.3765f,0.0049f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3995f,0.8523f,0.1020f],left_rotation:[-0.0382f,0.1826f,-0.9682f,-0.1663f]}}
particle minecraft:cloud -42.50 67.87 -92.77 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -42.50 67.67 -92.77 -0.034 0.02 -0.007 1 0 force
particle minecraft:cloud -42.85 67.87 -91.13 0.35 0.18 0.35 0.02 3 force
