scoreboard players set #gx driftmountains 16331
scoreboard players set #gdx driftmountains -830
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 57730
scoreboard players set #gdz driftmountains 744
scoreboard players set #gr driftmountains 10259
scoreboard players set #gdr driftmountains 315
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.8202f,0.2306f,-0.3613f,0.3789f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.4031f,0.4190f,0.8005f,-0.1457f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.9373f,0.0123f,-0.0046f,-0.3482f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0046f,-0.3482f,0.9373f,0.0123f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3813f,0.8214f,0.0899f],left_rotation:[-0.1178f,-0.1350f,0.7434f,-0.6443f]}}
particle minecraft:cloud 17.38 71.32 58.82 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 17.38 71.12 58.82 0.066 0.02 0.015 1 0 force
particle minecraft:cloud 17.74 71.32 57.19 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains 21394
scoreboard players set #gdx driftmountains -700
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 51008
scoreboard players set #gdz driftmountains 808
scoreboard players set #gr driftmountains 9883
scoreboard players set #gdr driftmountains 152
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.2822f,0.4525f,-0.0897f,0.8412f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.1786f,0.8552f,0.2362f,-0.4253f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.9373f,0.0123f,-0.0046f,-0.3482f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0046f,-0.3482f,0.9373f,0.0123f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.4063f,0.8519f,0.2420f],left_rotation:[-0.0622f,-0.1761f,0.9120f,-0.3654f]}}
particle minecraft:cloud 22.61 71.32 52.06 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 22.61 71.12 52.06 0.067 0.02 0.010 1 0 force
particle minecraft:cloud 22.87 71.32 50.37 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains 25183
scoreboard players set #gdx driftmountains -403
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 46302
scoreboard players set #gdz driftmountains 918
scoreboard players set #gr driftmountains 7933
scoreboard players set #gdr driftmountains 188
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.7571f,-0.1850f,-0.3958f,-0.4858f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.3470f,-0.4468f,0.7807f,0.2655f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.9373f,0.0123f,-0.0046f,-0.3482f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0046f,-0.3482f,0.9373f,0.0123f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3853f,0.8224f,0.0903f],left_rotation:[-0.1052f,-0.1451f,0.7948f,-0.5797f]}}
particle minecraft:cloud 26.58 71.32 46.89 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 26.58 71.12 46.89 0.062 0.02 -0.012 1 0 force
particle minecraft:cloud 26.27 71.32 45.25 0.35 0.18 0.35 0.02 3 force
