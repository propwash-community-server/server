scoreboard players set #gx driftmountains -55348
scoreboard players set #gdx driftmountains 253
scoreboard players set #gy driftmountains 67945
scoreboard players set #gdy driftmountains -13
scoreboard players set #gz driftmountains -75741
scoreboard players set #gdz driftmountains -586
scoreboard players set #gr driftmountains -12433
scoreboard players set #gdr driftmountains 63
scoreboard players set #gp driftmountains 102
scoreboard players set #gdp driftmountains -4
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0001f,-0.0201f,0.9998f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.4762f,-0.1856f,-0.1668f,-0.8432f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.0790f,-0.8303f,0.4983f,0.2366f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.4823f,0.0063f,0.0115f,0.8759f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0115f,0.8759f,0.4823f,0.0063f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3814f,0.8662f,0.1074f],left_rotation:[-0.1211f,0.1484f,-0.7701f,-0.6084f]}}
particle minecraft:cloud -56.86 68.26 -75.72 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -56.86 68.06 -75.72 -0.031 0.02 0.022 1 0 force
particle minecraft:cloud -55.92 68.26 -74.34 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -55994
scoreboard players set #gdx driftmountains 33
scoreboard players set #gy driftmountains 68079
scoreboard players set #gdy driftmountains -18
scoreboard players set #gz driftmountains -71102
scoreboard players set #gdz driftmountains -588
scoreboard players set #gr driftmountains -14286
scoreboard players set #gdr driftmountains 349
scoreboard players set #gp driftmountains 125
scoreboard players set #gdp driftmountains 22
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[0.0061f,0.0001f,-0.0218f,0.9997f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.3860f,0.2036f,-0.0293f,0.8993f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.1239f,0.9073f,0.3667f,-0.1641f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.4823f,0.0063f,0.0115f,0.8759f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0115f,0.8759f,0.4823f,0.0063f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3876f,0.8735f,0.2504f],left_rotation:[-0.0490f,0.1868f,-0.9510f,-0.2417f]}}
particle minecraft:cloud -57.50 68.40 -70.53 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -57.50 68.20 -70.53 -0.021 0.02 0.027 1 0 force
particle minecraft:cloud -56.14 68.40 -69.50 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -55073
scoreboard players set #gdx driftmountains -67
scoreboard players set #gy driftmountains 68203
scoreboard players set #gdy driftmountains -12
scoreboard players set #gz driftmountains -65004
scoreboard players set #gdz driftmountains -735
scoreboard players set #gr driftmountains -16590
scoreboard players set #gdr driftmountains 237
scoreboard players set #gp driftmountains 90
scoreboard players set #gdp driftmountains 1
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[0.0061f,0.0001f,-0.0119f,0.9999f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.8420f,-0.0368f,-0.1622f,-0.5131f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.1092f,-0.4989f,0.8505f,0.1255f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.4823f,0.0063f,0.0115f,0.8759f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0115f,0.8759f,0.4823f,0.0063f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.4007f,0.8388f,0.0967f],left_rotation:[0.0181f,0.1818f,-0.9746f,0.1291f]}}
particle minecraft:cloud -56.19 68.52 -63.98 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -56.19 68.32 -63.98 -0.011 0.02 0.043 1 0 force
particle minecraft:cloud -54.57 68.52 -63.58 0.35 0.18 0.35 0.02 2 force
