scoreboard players set #gx driftmountains -57181
scoreboard players set #gdx driftmountains 332
scoreboard players set #gy driftmountains 68875
scoreboard players set #gdy driftmountains -18
scoreboard players set #gz driftmountains -38636
scoreboard players set #gdz driftmountains -536
scoreboard players set #gr driftmountains 17976
scoreboard players set #gdr driftmountains -241
scoreboard players set #gp driftmountains 140
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,0.0001f,0.0203f,0.9998f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.8958f,0.1378f,0.1882f,-0.3784f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[-0.2290f,-0.4003f,0.8862f,-0.0444f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.7830f,0.0102f,0.0081f,0.6219f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0081f,0.6219f,0.7830f,0.0102f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3901f,0.8246f,0.0911f],left_rotation:[-0.0876f,-0.1567f,0.8532f,-0.4897f]}}
particle minecraft:cloud -58.01 69.19 -37.37 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud -56.34 69.19 -37.38 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -56.34 68.99 -37.38 0.000 0.02 0.038 1 0 force
scoreboard players set #gx driftmountains -61186
scoreboard players set #gdx driftmountains 385
scoreboard players set #gy driftmountains 69024
scoreboard players set #gdy driftmountains -22
scoreboard players set #gz driftmountains -36203
scoreboard players set #gdz driftmountains -371
scoreboard players set #gr driftmountains -16793
scoreboard players set #gdr driftmountains -386
scoreboard players set #gp driftmountains 192
scoreboard players set #gdp driftmountains -9
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[-0.0039f,0.0001f,0.0219f,0.9998f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.9383f,0.1046f,0.1586f,-0.2890f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[-0.1899f,-0.3072f,0.9325f,-0.0065f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.7830f,0.0102f,0.0081f,0.6219f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0081f,0.6219f,0.7830f,0.0102f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.4019f,0.8640f,0.2467f],left_rotation:[-0.0141f,-0.1900f,0.9762f,-0.1040f]}}
particle minecraft:cloud -62.31 69.34 -35.05 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud -60.64 69.34 -34.69 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -60.64 69.14 -34.69 -0.007 0.02 0.034 1 0 force
scoreboard players set #gx driftmountains -65442
scoreboard players set #gdx driftmountains 608
scoreboard players set #gy driftmountains 69145
scoreboard players set #gdy driftmountains -10
scoreboard players set #gz driftmountains -32842
scoreboard players set #gdz driftmountains -254
scoreboard players set #gr driftmountains -13272
scoreboard players set #gdr driftmountains -375
scoreboard players set #gp driftmountains 84
scoreboard players set #gdp driftmountains 2
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[0.0061f,-0.0001f,0.0124f,0.9999f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.5150f,-0.1041f,0.1258f,0.8415f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[-0.0381f,0.8329f,0.5288f,0.1588f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.7830f,0.0102f,0.0081f,0.6219f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0081f,0.6219f,0.7830f,0.0102f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3998f,0.8516f,0.1017f],left_rotation:[0.0348f,-0.1831f,0.9712f,0.1483f]}}
particle minecraft:cloud -66.93 69.46 -32.60 0.35 0.18 0.35 0.02 2 force
particle minecraft:cloud -65.80 69.46 -31.37 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -65.80 69.26 -31.37 -0.020 0.02 0.018 1 0 force
