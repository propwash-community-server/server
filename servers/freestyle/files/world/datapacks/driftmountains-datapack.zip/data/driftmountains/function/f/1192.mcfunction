scoreboard players set #gx driftmountains -83747
scoreboard players set #gdx driftmountains 587
scoreboard players set #gy driftmountains 69436
scoreboard players set #gdy driftmountains -13
scoreboard players set #gz driftmountains -26587
scoreboard players set #gdz driftmountains -71
scoreboard players set #gr driftmountains -7679
scoreboard players set #gdr driftmountains -340
scoreboard players set #gp driftmountains 120
scoreboard players set #gdp driftmountains -4
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0000f,-0.0126f,0.9999f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.7747f,0.1056f,-0.0475f,0.6217f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.1131f,0.6301f,0.7679f,-0.0247f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.4691f,0.0061f,0.0116f,0.8830f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0116f,0.8830f,0.4691f,0.0061f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3852f,0.8223f,0.0902f],left_rotation:[0.1056f,0.1448f,-0.7933f,0.5818f]}}
particle minecraft:cloud -84.78 69.76 -27.69 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -84.78 69.56 -27.69 -0.034 0.02 -0.008 1 0 force
particle minecraft:cloud -85.16 69.76 -26.06 0.35 0.18 0.35 0.02 2 force
playsound driftgen:grain.kaze.034 neutral @a -78.88 69.84 -27.29 12 1
scoreboard players set #gx driftmountains -88943
scoreboard players set #gdx driftmountains 262
scoreboard players set #gy driftmountains 69579
scoreboard players set #gdy driftmountains -9
scoreboard players set #gz driftmountains -24659
scoreboard players set #gdz driftmountains -196
scoreboard players set #gr driftmountains -8187
scoreboard players set #gdr driftmountains 74
scoreboard players set #gp driftmountains 109
scoreboard players set #gdp driftmountains -1
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.4401f,0.3303f,-0.1125f,0.8274f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.2001f,0.8438f,0.4078f,-0.2859f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.4691f,0.0061f,0.0116f,0.8830f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0116f,0.8830f,0.4691f,0.0061f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3659f,0.8318f,0.2341f],left_rotation:[-0.1793f,-0.0072f,0.0624f,-0.9818f]}}
particle minecraft:cloud -90.17 69.90 -25.70 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -90.17 69.70 -25.70 -0.026 0.02 -0.004 1 0 force
particle minecraft:cloud -90.42 69.90 -24.01 0.35 0.18 0.35 0.02 3 force
playsound driftgen:grain.onyx.034 neutral @a -84.95 69.96 -26.95 12 1
scoreboard players set #gx driftmountains -92123
scoreboard players set #gdx driftmountains 618
scoreboard players set #gy driftmountains 69695
scoreboard players set #gdy driftmountains -21
scoreboard players set #gz driftmountains -21800
scoreboard players set #gdz driftmountains -536
scoreboard players set #gr driftmountains -8648
scoreboard players set #gdr driftmountains 210
scoreboard players set #gp driftmountains 105
scoreboard players set #gdp driftmountains 1
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.7136f,0.2562f,-0.2116f,0.6168f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.2776f,0.6424f,0.6906f,-0.1826f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.4691f,0.0061f,0.0116f,0.8830f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0116f,0.8830f,0.4691f,0.0061f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3526f,0.8474f,0.1001f],left_rotation:[-0.1869f,0.0249f,-0.0979f,-0.9771f]}}
particle minecraft:cloud -93.33 70.01 -22.71 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -93.33 69.81 -22.71 -0.046 0.02 -0.003 1 0 force
particle minecraft:cloud -93.43 70.01 -21.04 0.35 0.18 0.35 0.02 3 force
playsound driftgen:grain.kaze.032 neutral @a -87.82 70.05 -24.81 12 1
