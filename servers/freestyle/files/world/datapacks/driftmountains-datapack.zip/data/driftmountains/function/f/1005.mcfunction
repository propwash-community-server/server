scoreboard players set #gx driftmountains 27382
scoreboard players set #gdx driftmountains 92
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 32363
scoreboard players set #gdz driftmountains 1013
scoreboard players set #gr driftmountains 4726
scoreboard players set #gdr driftmountains 330
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[0.0041f,0.0001f,-0.0223f,0.9997f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.3145f,0.3945f,-0.0836f,0.8593f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.1743f,0.8729f,0.2748f,-0.3636f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.9345f,0.0122f,0.0047f,0.3557f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0047f,0.3557f,0.9345f,0.0122f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3689f,0.8222f,0.0902f],left_rotation:[-0.1509f,-0.0989f,0.5563f,-0.8111f]}}
particle minecraft:cloud 28.87 71.32 32.12 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 28.87 71.12 32.12 0.045 0.02 -0.042 1 0 force
particle minecraft:cloud 27.74 71.32 30.89 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains 26463
scoreboard players set #gdx driftmountains 329
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 25118
scoreboard players set #gdz driftmountains 778
scoreboard players set #gr driftmountains 2058
scoreboard players set #gdr driftmountains 739
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[-0.0034f,-0.0001f,-0.0223f,0.9997f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.4305f,-0.2547f,-0.1917f,-0.8444f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.1040f,-0.8289f,0.4596f,0.3013f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.9345f,0.0122f,0.0047f,0.3557f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0047f,0.3557f,0.9345f,0.0122f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3571f,0.8428f,0.2384f],left_rotation:[-0.1762f,0.0487f,-0.2249f,-0.9571f]}}
particle minecraft:cloud 27.74 71.32 24.14 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 27.74 71.12 24.14 0.019 0.02 -0.052 1 0 force
particle minecraft:cloud 26.14 71.32 23.54 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains 23144
scoreboard players set #gdx driftmountains 325
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 20618
scoreboard players set #gdz driftmountains 1041
scoreboard players set #gr driftmountains 1543
scoreboard players set #gdr driftmountains 299
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0001f,-0.0206f,0.9998f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.9413f,0.1096f,-0.2345f,0.2169f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.2586f,0.2427f,0.9349f,-0.0112f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.9345f,0.0122f,0.0047f,0.3557f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0047f,0.3557f,0.9345f,0.0122f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3770f,0.8666f,0.1076f],left_rotation:[-0.1335f,0.1380f,-0.7119f,-0.6755f]}}
particle minecraft:cloud 24.28 71.32 19.63 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 24.28 71.12 19.63 0.017 0.02 -0.060 1 0 force
particle minecraft:cloud 22.67 71.32 19.18 0.35 0.18 0.35 0.02 3 force
