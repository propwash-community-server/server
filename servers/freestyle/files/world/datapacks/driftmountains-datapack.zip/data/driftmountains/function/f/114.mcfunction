scoreboard players set #gx driftmountains 2106
scoreboard players set #gdx driftmountains 589
scoreboard players set #gy driftmountains 70484
scoreboard players set #gdy driftmountains 21
scoreboard players set #gz driftmountains -21579
scoreboard players set #gdz driftmountains 606
scoreboard players set #gr driftmountains 53
scoreboard players set #gdr driftmountains 343
scoreboard players set #gp driftmountains -41
scoreboard players set #gdp driftmountains -116
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.1036f,0.3280f,0.0195f,0.9388f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.0791f,0.9419f,0.0697f,-0.3189f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.5165f,0.0068f,-0.0112f,-0.8562f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0112f,-0.8562f,0.5165f,0.0068f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3530f,0.8490f,0.1007f],left_rotation:[-0.1863f,0.0314f,-0.1329f,-0.9729f]}}
particle minecraft:cloud 2.95 70.80 -22.83 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 2.95 70.60 -22.83 0.000 0.02 -0.051 1 0 force
particle minecraft:cloud 1.28 70.80 -22.85 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -1773
scoreboard players set #gdx driftmountains 649
scoreboard players set #gy driftmountains 70514
scoreboard players set #gdy driftmountains 10
scoreboard players set #gz driftmountains -25351
scoreboard players set #gdz driftmountains 465
scoreboard players set #gr driftmountains -1032
scoreboard players set #gdr driftmountains 90
scoreboard players set #gp driftmountains -74
scoreboard players set #gdp driftmountains 48
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.2840f,-0.3337f,-0.1665f,-0.8833f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.0745f,-0.8707f,0.3207f,0.3654f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.5165f,0.0068f,-0.0112f,-0.8562f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0112f,-0.8562f,0.5165f,0.0068f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3768f,0.8275f,0.2324f],left_rotation:[-0.1706f,-0.0517f,0.2896f,-0.9404f]}}
particle minecraft:cloud -1.18 70.83 -26.85 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -1.18 70.63 -26.85 -0.008 0.02 -0.047 1 0 force
particle minecraft:cloud -2.86 70.83 -26.54 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -5831
scoreboard players set #gdx driftmountains 723
scoreboard players set #gy driftmountains 70270
scoreboard players set #gdy driftmountains 71
scoreboard players set #gz driftmountains -27538
scoreboard players set #gdz driftmountains 445
scoreboard players set #gr driftmountains -1400
scoreboard players set #gdr driftmountains 234
scoreboard players set #gp driftmountains -358
scoreboard players set #gdp driftmountains 52
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.9310f,-0.0044f,-0.3195f,-0.1763f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.3028f,-0.1437f,0.9366f,0.1023f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.5165f,0.0068f,-0.0112f,-0.8562f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0112f,-0.8562f,0.5165f,0.0068f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3543f,0.8528f,0.1022f],left_rotation:[-0.1839f,0.0473f,-0.2179f,-0.9573f]}}
particle minecraft:cloud -5.33 70.59 -28.96 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -5.33 70.39 -28.96 -0.011 0.02 -0.043 1 0 force
particle minecraft:cloud -6.95 70.59 -28.56 0.35 0.18 0.35 0.02 3 force
