scoreboard players set #gx driftmountains 12617
scoreboard players set #gdx driftmountains 930
scoreboard players set #gy driftmountains 66708
scoreboard players set #gdy driftmountains -12
scoreboard players set #gz driftmountains -62865
scoreboard players set #gdz driftmountains 628
scoreboard players set #gr driftmountains -5793
scoreboard players set #gdr driftmountains -25
scoreboard players set #gp driftmountains 61
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,0.0000f,0.0012f,1.0000f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.6676f,0.0461f,-0.0289f,-0.7425f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[-0.0490f,-0.7436f,0.6664f,0.0238f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.0101f,0.0001f,-0.0131f,-0.9999f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0131f,-0.9999f,0.0101f,0.0001f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3530f,0.8491f,0.1008f],left_rotation:[0.1863f,-0.0321f,0.1363f,0.9724f]}}
scoreboard players set #gx driftmountains 5616
scoreboard players set #gdx driftmountains 931
scoreboard players set #gy driftmountains 66797
scoreboard players set #gdy driftmountains -12
scoreboard players set #gz driftmountains -67584
scoreboard players set #gdz driftmountains 614
scoreboard players set #gr driftmountains -5345
scoreboard players set #gdr driftmountains -73
scoreboard players set #gp driftmountains 61
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0000f,-0.0019f,1.0000f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.9873f,0.0480f,-0.0331f,-0.1481f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.0177f,-0.1454f,0.9876f,0.0555f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.0101f,0.0001f,-0.0131f,-0.9999f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0131f,-0.9999f,0.0101f,0.0001f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3734f,0.8282f,0.2327f],left_rotation:[0.1741f,0.0391f,-0.2251f,0.9579f]}}
scoreboard players set #gx driftmountains -3268
scoreboard players set #gdx driftmountains 992
scoreboard players set #gy driftmountains 66912
scoreboard players set #gdy driftmountains -13
scoreboard players set #gz driftmountains -73589
scoreboard players set #gdz driftmountains 658
scoreboard players set #gr driftmountains -4906
scoreboard players set #gdr driftmountains -62
scoreboard players set #gp driftmountains 62
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0000f,-0.0045f,1.0000f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.6880f,-0.0103f,-0.0823f,-0.7210f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.0070f,-0.7163f,0.6928f,0.0827f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.0101f,0.0001f,-0.0131f,-0.9999f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0131f,-0.9999f,0.0101f,0.0001f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3681f,0.8224f,0.0903f],left_rotation:[0.1528f,0.0962f,-0.5423f,0.8205f]}}
