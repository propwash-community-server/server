scoreboard players set #gx driftmountains 17142
scoreboard players set #gdx driftmountains -811
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 56944
scoreboard players set #gdz driftmountains 786
scoreboard players set #gr driftmountains 10009
scoreboard players set #gdr driftmountains 250
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[0.0061f,0.0001f,-0.0223f,0.9997f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.1536f,-0.4092f,-0.1293f,-0.8901f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.0365f,-0.8814f,0.1975f,0.4276f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.5809f,0.0076f,0.0107f,0.8138f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0107f,0.8138f,0.5809f,0.0076f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3816f,0.8214f,0.0899f],left_rotation:[-0.1171f,-0.1357f,0.7465f,-0.6407f]}}
particle minecraft:cloud 18.24 71.32 57.99 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 18.24 71.12 57.99 0.067 0.02 0.012 1 0 force
particle minecraft:cloud 18.53 71.32 56.34 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains 22144
scoreboard players set #gdx driftmountains -750
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 50091
scoreboard players set #gdz driftmountains 917
scoreboard players set #gr driftmountains 9709
scoreboard players set #gdr driftmountains 174
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.7401f,-0.2030f,-0.4127f,-0.4906f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.3635f,-0.4499f,0.7655f,0.2819f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.5809f,0.0076f,0.0107f,0.8138f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0107f,0.8138f,0.5809f,0.0076f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.4063f,0.8512f,0.2417f],left_rotation:[-0.0646f,-0.1750f,0.9068f,-0.3781f]}}
particle minecraft:cloud 23.39 71.32 51.11 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 23.39 71.12 51.11 0.068 0.02 0.008 1 0 force
particle minecraft:cloud 23.60 71.32 49.41 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains 25581
scoreboard players set #gdx driftmountains -398
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 45294
scoreboard players set #gdz driftmountains 1008
scoreboard players set #gr driftmountains 7746
scoreboard players set #gdr driftmountains 187
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.6643f,0.3363f,-0.2831f,0.6045f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.3482f,0.6376f,0.6326f,-0.2683f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.5809f,0.0076f,0.0107f,0.8138f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0107f,0.8138f,0.5809f,0.0076f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3865f,0.8228f,0.0904f],left_rotation:[-0.1010f,-0.1481f,0.8099f,-0.5584f]}}
particle minecraft:cloud 26.99 71.32 45.84 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 26.99 71.12 45.84 0.060 0.02 -0.013 1 0 force
particle minecraft:cloud 26.63 71.32 44.21 0.35 0.18 0.35 0.02 3 force
