scoreboard players set #gx driftmountains -86498
scoreboard players set #gdx driftmountains 532
scoreboard players set #gy driftmountains 69510
scoreboard players set #gdy driftmountains -16
scoreboard players set #gz driftmountains -25798
scoreboard players set #gdz driftmountains -229
scoreboard players set #gr driftmountains -7306
scoreboard players set #gdr driftmountains -12
scoreboard players set #gp driftmountains 111
scoreboard players set #gdp driftmountains 12
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.2618f,-0.2380f,-0.1236f,-0.9271f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.0268f,-0.9192f,0.2883f,0.2668f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.2365f,0.0031f,0.0127f,0.9715f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0127f,0.9715f,0.2365f,0.0031f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3726f,0.8662f,0.1075f],left_rotation:[-0.1447f,0.1265f,-0.6484f,-0.7366f]}}
particle minecraft:cloud -87.46 69.83 -26.96 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -87.46 69.63 -26.96 -0.034 0.02 -0.010 1 0 force
particle minecraft:cloud -87.95 69.83 -25.37 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -91437
scoreboard players set #gdx driftmountains 539
scoreboard players set #gy driftmountains 69666
scoreboard players set #gdy driftmountains -19
scoreboard players set #gz driftmountains -22601
scoreboard players set #gdz driftmountains -476
scoreboard players set #gr driftmountains -8743
scoreboard players set #gdr driftmountains 126
scoreboard players set #gp driftmountains 108
scoreboard players set #gdp driftmountains 1
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.8598f,-0.0854f,-0.3324f,-0.3781f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.2945f,-0.3452f,0.8735f,0.1762f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.2365f,0.0031f,0.0127f,0.9715f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0127f,0.9715f,0.2365f,0.0031f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3637f,0.8335f,0.2348f],left_rotation:[-0.1799f,0.0037f,0.0069f,-0.9837f]}}
particle minecraft:cloud -92.76 69.99 -23.52 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -92.76 69.79 -23.52 -0.043 0.02 -0.002 1 0 force
particle minecraft:cloud -92.84 69.99 -21.81 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -94777
scoreboard players set #gdx driftmountains 497
scoreboard players set #gy driftmountains 69793
scoreboard players set #gdy driftmountains -19
scoreboard players set #gz driftmountains -18938
scoreboard players set #gdz driftmountains -603
scoreboard players set #gr driftmountains -9278
scoreboard players set #gdr driftmountains 59
scoreboard players set #gp driftmountains 92
scoreboard players set #gdp driftmountains 3
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.8888f,0.1609f,-0.3277f,0.2769f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.3586f,0.3129f,0.8768f,-0.0684f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.2365f,0.0031f,0.0127f,0.9715f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0127f,0.9715f,0.2365f,0.0031f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3551f,0.8331f,0.0945f],left_rotation:[-0.1813f,-0.0342f,0.2166f,-0.9586f]}}
particle minecraft:cloud -96.08 70.11 -19.71 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -96.08 69.91 -19.71 -0.047 0.02 0.002 1 0 force
particle minecraft:cloud -95.99 70.11 -18.04 0.35 0.18 0.35 0.02 3 force
