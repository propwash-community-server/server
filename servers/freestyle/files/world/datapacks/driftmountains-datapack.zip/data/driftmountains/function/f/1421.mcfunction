scoreboard players set #gx driftmountains 38456
scoreboard players set #gdx driftmountains 1108
scoreboard players set #gy driftmountains 66383
scoreboard players set #gdy driftmountains -13
scoreboard players set #gz driftmountains -47215
scoreboard players set #gdz driftmountains 685
scoreboard players set #gr driftmountains -5071
scoreboard players set #gdr driftmountains 357
scoreboard players set #gp driftmountains 56
scoreboard players set #gdp driftmountains -1
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0000f,-0.0046f,1.0000f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.5469f,0.0827f,0.0085f,0.8331f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.0791f,0.8368f,0.5412f,-0.0257f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.9450f,0.0124f,0.0043f,0.3269f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0043f,0.3269f,0.9450f,0.0124f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3682f,0.8224f,0.0903f],left_rotation:[0.1526f,0.0964f,-0.5434f,0.8198f]}}
scoreboard players set #gx driftmountains 30337
scoreboard players set #gdx driftmountains 1056
scoreboard players set #gy driftmountains 66474
scoreboard players set #gdy driftmountains -14
scoreboard players set #gz driftmountains -50784
scoreboard players set #gdz driftmountains 744
scoreboard players set #gr driftmountains -5314
scoreboard players set #gdr driftmountains -59
scoreboard players set #gp driftmountains 63
scoreboard players set #gdp driftmountains -1
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0000f,-0.0010f,1.0000f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.1129f,-0.0112f,-0.0540f,-0.9921f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[-0.0500f,-0.9919f,0.1147f,0.0231f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.9450f,0.0124f,0.0043f,0.3269f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0043f,0.3269f,0.9450f,0.0124f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3699f,0.8296f,0.2332f],left_rotation:[0.1771f,0.0246f,-0.1515f,0.9722f]}}
scoreboard players set #gx driftmountains 21022
scoreboard players set #gdx driftmountains 1056
scoreboard players set #gy driftmountains 66602
scoreboard players set #gdy driftmountains -14
scoreboard players set #gz driftmountains -57674
scoreboard players set #gdz driftmountains 662
scoreboard players set #gr driftmountains -5869
scoreboard players set #gdr driftmountains -66
scoreboard players set #gp driftmountains 62
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[-0.0028f,0.0000f,0.0008f,1.0000f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.5166f,0.0272f,0.0447f,0.8546f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.0449f,0.8547f,0.5166f,0.0269f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.9450f,0.0124f,0.0043f,0.3269f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0043f,0.3269f,0.9450f,0.0124f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3523f,0.8429f,0.0983f],left_rotation:[0.1872f,-0.0067f,0.0009f,0.9822f]}}
