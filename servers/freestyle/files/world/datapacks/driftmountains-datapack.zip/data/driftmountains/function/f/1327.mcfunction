scoreboard players set #gx driftmountains -39205
scoreboard players set #gdx driftmountains 621
scoreboard players set #gy driftmountains 67498
scoreboard players set #gdy driftmountains -19
scoreboard players set #gz driftmountains -91578
scoreboard players set #gdz driftmountains -31
scoreboard players set #gr driftmountains -5866
scoreboard players set #gdr driftmountains 364
scoreboard players set #gp driftmountains 137
scoreboard players set #gdp driftmountains 6
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.2328f,0.2235f,0.0003f,0.9465f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.0992f,0.9517f,0.2106f,-0.2002f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.8098f,0.0106f,0.0077f,0.5866f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0077f,0.5866f,0.8098f,0.0106f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3924f,0.8614f,0.1056f],left_rotation:[-0.0820f,0.1708f,-0.8971f,-0.3990f]}}
particle minecraft:cloud -39.85 67.82 -92.95 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -39.85 67.62 -92.95 -0.032 0.02 -0.019 1 0 force
particle minecraft:cloud -40.72 67.82 -91.52 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -43950
scoreboard players set #gdx driftmountains 539
scoreboard players set #gy driftmountains 67620
scoreboard players set #gdy driftmountains -13
scoreboard players set #gz driftmountains -90165
scoreboard players set #gdz driftmountains -304
scoreboard players set #gr driftmountains -8363
scoreboard players set #gdr driftmountains 292
scoreboard players set #gp driftmountains 90
scoreboard players set #gdp driftmountains 7
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.3319f,0.2300f,-0.0263f,0.9145f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.1226f,0.9223f,0.3095f,-0.1964f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.8098f,0.0106f,0.0077f,0.5866f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0077f,0.5866f,0.8098f,0.0106f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3751f,0.8737f,0.2505f],left_rotation:[-0.0901f,0.1706f,-0.8620f,-0.4688f]}}
particle minecraft:cloud -45.21 67.94 -91.17 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -45.21 67.74 -91.17 -0.039 0.02 -0.004 1 0 force
particle minecraft:cloud -45.40 67.94 -89.47 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -47487
scoreboard players set #gdx driftmountains 426
scoreboard players set #gy driftmountains 67708
scoreboard players set #gdy driftmountains -11
scoreboard players set #gz driftmountains -86835
scoreboard players set #gdz driftmountains -481
scoreboard players set #gr driftmountains -10664
scoreboard players set #gdr driftmountains 157
scoreboard players set #gp driftmountains 83
scoreboard players set #gdp driftmountains -1
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[0.0061f,0.0001f,-0.0199f,0.9998f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.4094f,0.2397f,-0.0522f,0.8788f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.1448f,0.8891f,0.3865f,-0.1979f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.8098f,0.0106f,0.0077f,0.5866f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0077f,0.5866f,0.8098f,0.0106f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3833f,0.8657f,0.1073f],left_rotation:[-0.1153f,0.1527f,-0.7941f,-0.5768f]}}
particle minecraft:cloud -48.93 68.03 -87.27 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -48.93 67.83 -87.27 -0.043 0.02 0.013 1 0 force
particle minecraft:cloud -48.46 68.03 -85.67 0.35 0.18 0.35 0.02 3 force
