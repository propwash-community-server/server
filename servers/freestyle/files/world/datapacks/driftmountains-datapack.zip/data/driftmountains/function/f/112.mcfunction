scoreboard players set #gx driftmountains 855
scoreboard players set #gdx driftmountains 635
scoreboard players set #gy driftmountains 70491
scoreboard players set #gdy driftmountains -9
scoreboard players set #gz driftmountains -22684
scoreboard players set #gdz driftmountains 536
scoreboard players set #gr driftmountains -501
scoreboard players set #gdr driftmountains 276
scoreboard players set #gp driftmountains 70
scoreboard players set #gdp driftmountains -56
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.6296f,0.2872f,-0.1841f,0.6980f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.2585f,0.7212f,0.6029f,-0.2226f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.0143f,0.0002f,-0.0131f,-0.9998f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0131f,-0.9998f,0.0143f,0.0002f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3523f,0.8434f,0.0985f],left_rotation:[-0.1873f,0.0090f,-0.0130f,-0.9821f]}}
particle minecraft:cloud 1.58 70.81 -24.01 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 1.58 70.61 -24.01 -0.004 0.02 -0.049 1 0 force
particle minecraft:cloud -0.09 70.81 -23.87 0.35 0.18 0.35 0.02 3 force
playsound driftgen:grain.kaze.055 neutral @a 5.23 71.30 -17.46 12 1
scoreboard players set #gx driftmountains -3040
scoreboard players set #gdx driftmountains 625
scoreboard players set #gy driftmountains 70467
scoreboard players set #gdy driftmountains 27
scoreboard players set #gz driftmountains -26253
scoreboard players set #gdz driftmountains 450
scoreboard players set #gr driftmountains -929
scoreboard players set #gdr driftmountains -87
scoreboard players set #gp driftmountains -169
scoreboard players set #gdp driftmountains 48
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.4298f,0.3554f,-0.1224f,0.8210f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.2094f,0.8384f,0.3948f,-0.3122f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.0143f,0.0002f,-0.0131f,-0.9998f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0131f,-0.9998f,0.0143f,0.0002f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3783f,0.8273f,0.2323f],left_rotation:[-0.1688f,-0.0572f,0.3175f,-0.9314f]}}
particle minecraft:cloud -2.42 70.79 -27.74 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -2.42 70.59 -27.74 -0.007 0.02 -0.045 1 0 force
particle minecraft:cloud -4.10 70.79 -27.46 0.35 0.18 0.35 0.02 3 force
playsound driftgen:grain.onyx.044 neutral @a 2.10 70.98 -22.21 12 1
scoreboard players set #gx driftmountains -7116
scoreboard players set #gdx driftmountains 672
scoreboard players set #gy driftmountains 70128
scoreboard players set #gdy driftmountains 76
scoreboard players set #gz driftmountains -28191
scoreboard players set #gdz driftmountains 317
scoreboard players set #gr driftmountains -2040
scoreboard players set #gdr driftmountains 357
scoreboard players set #gp driftmountains -406
scoreboard players set #gdp driftmountains 11
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[-0.0026f,-0.0001f,-0.0223f,0.9997f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.4140f,-0.2419f,-0.1773f,-0.8594f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.0880f,-0.8455f,0.4417f,0.2867f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.0143f,0.0002f,-0.0131f,-0.9998f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0131f,-0.9998f,0.0143f,0.0002f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3595f,0.8599f,0.1050f],left_rotation:[-0.1739f,0.0801f,-0.3955f,-0.8983f]}}
particle minecraft:cloud -6.77 70.45 -29.66 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -6.77 70.25 -29.66 -0.015 0.02 -0.041 1 0 force
particle minecraft:cloud -8.34 70.45 -29.08 0.35 0.18 0.35 0.02 3 force
playsound driftgen:grain.kaze.066 neutral @a -1.94 71.01 -24.95 12 1
