scoreboard players set #gx driftmountains 26472
scoreboard players set #gdx driftmountains -311
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 41287
scoreboard players set #gdz driftmountains 976
scoreboard players set #gr driftmountains 7177
scoreboard players set #gdr driftmountains 96
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.3783f,-0.3634f,-0.2316f,-0.8193f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.1468f,-0.7994f,0.4186f,0.4052f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.3891f,0.0051f,0.0121f,0.9211f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0121f,0.9211f,0.3891f,0.0051f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3824f,0.8216f,0.0900f],left_rotation:[-0.1144f,-0.1379f,0.7581f,-0.6270f]}}
particle minecraft:cloud 27.93 71.32 41.69 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 27.93 71.12 41.69 0.058 0.02 -0.019 1 0 force
particle minecraft:cloud 27.41 71.32 40.10 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains 28438
scoreboard players set #gdx driftmountains 13
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 33630
scoreboard players set #gdz driftmountains 994
scoreboard players set #gr driftmountains 6087
scoreboard players set #gdr driftmountains 341
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.8400f,-0.0904f,-0.4547f,-0.2820f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.4276f,-0.2357f,0.8541f,0.1792f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.3891f,0.0051f,0.0121f,0.9211f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0121f,0.9211f,0.3891f,0.0051f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.4062f,0.8530f,0.2424f],left_rotation:[-0.0582f,-0.1779f,0.9204f,-0.3434f]}}
particle minecraft:cloud 30.05 71.32 33.71 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 30.05 71.12 33.71 0.052 0.02 -0.029 1 0 force
particle minecraft:cloud 29.21 71.32 32.22 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains 25917
scoreboard players set #gdx driftmountains 304
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 29275
scoreboard players set #gdz driftmountains 909
scoreboard players set #gr driftmountains 3346
scoreboard players set #gdr driftmountains 314
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.4889f,0.3825f,-0.1764f,0.7639f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.2577f,0.7866f,0.4514f,-0.3332f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.3891f,0.0051f,0.0121f,0.9211f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0121f,0.9211f,0.3891f,0.0051f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3777f,0.8210f,0.0897f],left_rotation:[-0.1285f,-0.1252f,0.6929f,-0.6983f]}}
particle minecraft:cloud 27.31 71.32 28.68 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 27.31 71.12 28.68 0.031 0.02 -0.048 1 0 force
particle minecraft:cloud 25.91 71.32 27.76 0.35 0.18 0.35 0.02 3 force
