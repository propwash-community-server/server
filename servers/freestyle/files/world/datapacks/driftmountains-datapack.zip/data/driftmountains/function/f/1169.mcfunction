scoreboard players set #gx driftmountains -95897
scoreboard players set #gdx driftmountains 427
scoreboard players set #gy driftmountains 69838
scoreboard players set #gdy driftmountains -18
scoreboard players set #gz driftmountains -17404
scoreboard players set #gdz driftmountains -638
scoreboard players set #gr driftmountains -9863
scoreboard players set #gdr driftmountains 187
scoreboard players set #gp driftmountains 87
scoreboard players set #gdp driftmountains 3
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.3606f,-0.2927f,-0.1821f,-0.8667f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.0920f,-0.8523f,0.3934f,0.3322f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.9602f,0.0126f,-0.0037f,-0.2790f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0037f,-0.2790f,0.9602f,0.0126f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3524f,0.8418f,0.0979f],left_rotation:[-0.1870f,0.0025f,0.0216f,-0.9821f]}}
particle minecraft:cloud -97.27 70.16 -18.04 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -97.27 69.96 -18.04 -0.045 0.02 0.007 1 0 force
particle minecraft:cloud -97.02 70.16 -16.39 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -98086
scoreboard players set #gdx driftmountains 87
scoreboard players set #gy driftmountains 69977
scoreboard players set #gdy driftmountains -13
scoreboard players set #gz driftmountains -10769
scoreboard players set #gdz driftmountains -789
scoreboard players set #gr driftmountains -12513
scoreboard players set #gdr driftmountains 240
scoreboard players set #gp driftmountains 57
scoreboard players set #gdp driftmountains 4
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[-0.0147f,-0.3639f,-0.0504f,-0.9299f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[-0.0470f,-0.9298f,0.0235f,0.3644f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.9602f,0.0126f,-0.0037f,-0.2790f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0037f,-0.2790f,0.9602f,0.0126f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3741f,0.8280f,0.2326f],left_rotation:[-0.1734f,-0.0417f,0.2386f,-0.9546f]}}
particle minecraft:cloud -99.69 70.30 -10.68 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -99.69 70.10 -10.68 -0.039 0.02 0.028 1 0 force
particle minecraft:cloud -98.71 70.30 -9.28 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -98111
scoreboard players set #gdx driftmountains -80
scoreboard players set #gy driftmountains 70026
scoreboard players set #gdy driftmountains -5
scoreboard players set #gz driftmountains -5747
scoreboard players set #gdz driftmountains -830
scoreboard players set #gr driftmountains -13604
scoreboard players set #gdr driftmountains 192
scoreboard players set #gp driftmountains 17
scoreboard players set #gdp driftmountains 6
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.6742f,-0.2178f,-0.3155f,-0.6312f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.2509f,-0.6015f,0.7008f,0.2899f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.9602f,0.0126f,-0.0037f,-0.2790f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0037f,-0.2790f,0.9602f,0.0126f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3606f,0.8267f,0.0919f],left_rotation:[-0.1698f,-0.0663f,0.3860f,-0.9043f]}}
particle minecraft:cloud -99.59 70.35 -5.42 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -99.59 70.15 -5.42 -0.035 0.02 0.037 1 0 force
particle minecraft:cloud -98.38 70.35 -4.26 0.35 0.18 0.35 0.02 3 force
