scoreboard players set #gx driftmountains -28627
scoreboard players set #gdx driftmountains -1134
scoreboard players set #gy driftmountains 70915
scoreboard players set #gdy driftmountains -33
scoreboard players set #gz driftmountains 54778
scoreboard players set #gdz driftmountains -369
scoreboard players set #gr driftmountains 15516
scoreboard players set #gdr driftmountains 28
scoreboard players set #gp driftmountains 102
scoreboard players set #gdp driftmountains 11
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.7496f,-0.1814f,-0.3574f,-0.5267f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.3040f,-0.4920f,0.7728f,0.2612f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.2719f,0.0036f,-0.0126f,-0.9622f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0126f,-0.9622f,0.2719f,0.0036f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3678f,0.8226f,0.0903f],left_rotation:[-0.1535f,-0.0950f,0.5364f,-0.8244f]}}
particle minecraft:cloud -28.86 71.23 56.27 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -28.86 71.03 56.27 0.030 0.02 0.065 1 0 force
particle minecraft:cloud -27.34 71.23 55.57 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -19138
scoreboard players set #gdx driftmountains -988
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 57708
scoreboard players set #gdz driftmountains -278
scoreboard players set #gr driftmountains 15124
scoreboard players set #gdr driftmountains 17
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.9029f,0.1334f,-0.3628f,0.1880f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.3845f,0.2271f,0.8939f,-0.0392f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.2719f,0.0036f,-0.0126f,-0.9622f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0126f,-0.9622f,0.2719f,0.0036f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3836f,0.8273f,0.2323f],left_rotation:[-0.1612f,-0.0762f,0.4137f,-0.8928f]}}
particle minecraft:cloud -19.23 71.32 59.32 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -19.23 71.12 59.32 0.032 0.02 0.059 1 0 force
particle minecraft:cloud -17.73 71.32 58.49 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -14409
scoreboard players set #gdx driftmountains -1083
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 59167
scoreboard players set #gdz driftmountains -296
scoreboard players set #gr driftmountains 15121
scoreboard players set #gdr driftmountains 4
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.0402f,0.3897f,0.0398f,0.9192f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.0566f,0.9201f,-0.0005f,-0.3876f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.2719f,0.0036f,-0.0126f,-0.9622f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0126f,-0.9622f,0.2719f,0.0036f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3639f,0.8244f,0.0911f],left_rotation:[-0.1626f,-0.0803f,0.4596f,-0.8693f]}}
particle minecraft:cloud -14.53 71.32 60.67 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -14.53 71.12 60.67 0.033 0.02 0.060 1 0 force
particle minecraft:cloud -13.07 71.32 59.87 0.35 0.18 0.35 0.02 3 force
