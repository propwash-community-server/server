scoreboard players set #gx driftmountains -79124
scoreboard players set #gdx driftmountains -858
scoreboard players set #gy driftmountains 70123
scoreboard players set #gdy driftmountains -22
scoreboard players set #gz driftmountains 22778
scoreboard players set #gdz driftmountains -985
scoreboard players set #gr driftmountains 17821
scoreboard players set #gdr driftmountains 3
scoreboard players set #gp driftmountains 75
scoreboard players set #gdp driftmountains -3
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.4001f,-0.2773f,-0.1915f,-0.8522f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.1030f,-0.8368f,0.4314f,0.3209f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.1354f,0.0018f,0.0130f,0.9907f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0130f,0.9907f,0.1354f,0.0018f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3524f,0.8453f,0.0992f],left_rotation:[-0.1873f,0.0163f,-0.0522f,-0.9807f]}}
particle minecraft:cloud -79.92 70.44 24.06 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -79.92 70.24 24.06 0.002 0.02 0.079 1 0 force
particle minecraft:cloud -78.25 70.44 24.01 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -71584
scoreboard players set #gdx driftmountains -1031
scoreboard players set #gy driftmountains 70322
scoreboard players set #gdy driftmountains -28
scoreboard players set #gz driftmountains 30579
scoreboard players set #gdz driftmountains -1057
scoreboard players set #gr driftmountains 17600
scoreboard players set #gdr driftmountains -41
scoreboard players set #gp driftmountains 82
scoreboard players set #gdp driftmountains 1
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.8923f,-0.0527f,-0.3407f,-0.2914f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.3119f,-0.2572f,0.9028f,0.1468f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.1354f,0.0018f,0.0130f,0.9907f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0130f,0.9907f,0.1354f,0.0018f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3643f,0.8330f,0.2346f],left_rotation:[-0.1798f,0.0007f,0.0218f,-0.9835f]}}
particle minecraft:cloud -72.34 70.64 32.00 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -72.34 70.44 32.00 0.006 0.02 0.084 1 0 force
particle minecraft:cloud -70.64 70.64 31.88 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -67569
scoreboard players set #gdx driftmountains -965
scoreboard players set #gy driftmountains 70423
scoreboard players set #gdy driftmountains -23
scoreboard players set #gz driftmountains 34642
scoreboard players set #gdz driftmountains -1017
scoreboard players set #gr driftmountains -17913
scoreboard players set #gdr driftmountains -53
scoreboard players set #gp driftmountains 66
scoreboard players set #gdp driftmountains 5
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.4973f,0.3432f,-0.1513f,0.7823f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.2344f,0.8025f,0.4639f,-0.2928f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.1354f,0.0018f,0.0130f,0.9907f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0130f,0.9907f,0.1354f,0.0018f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3578f,0.8294f,0.0930f],left_rotation:[-0.1757f,-0.0519f,0.3101f,-0.9328f]}}
particle minecraft:cloud -68.42 70.74 35.89 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -68.42 70.54 35.89 -0.001 0.02 0.080 1 0 force
particle minecraft:cloud -66.75 70.74 35.91 0.35 0.18 0.35 0.02 3 force
