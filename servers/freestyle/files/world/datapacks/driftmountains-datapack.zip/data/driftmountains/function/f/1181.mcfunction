scoreboard players set #gx driftmountains -89721
scoreboard players set #gdx driftmountains 547
scoreboard players set #gy driftmountains 69610
scoreboard players set #gdy driftmountains -18
scoreboard players set #gz driftmountains -23831
scoreboard players set #gdz driftmountains -380
scoreboard players set #gr driftmountains -8128
scoreboard players set #gdr driftmountains 162
scoreboard players set #gp driftmountains 110
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.3804f,0.3230f,-0.0819f,0.8627f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.1730f,0.8761f,0.3485f,-0.2848f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.9680f,0.0127f,-0.0033f,-0.2507f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0033f,-0.2507f,0.9680f,0.0127f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3526f,0.8469f,0.0999f],left_rotation:[-0.1870f,0.0231f,-0.0885f,-0.9780f]}}
particle minecraft:cloud -90.84 69.93 -24.85 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -90.84 69.73 -24.85 -0.040 0.02 -0.006 1 0 force
particle minecraft:cloud -91.09 69.93 -23.20 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -94588
scoreboard players set #gdx driftmountains 509
scoreboard players set #gy driftmountains 69784
scoreboard players set #gdy driftmountains -20
scoreboard players set #gz driftmountains -19252
scoreboard players set #gdz driftmountains -625
scoreboard players set #gr driftmountains -9413
scoreboard players set #gdr driftmountains 58
scoreboard players set #gp driftmountains 95
scoreboard players set #gdp driftmountains 3
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[0.0050f,0.0001f,-0.0223f,0.9997f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.9272f,0.1014f,-0.3390f,0.1232f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.3538f,0.1595f,0.9216f,-0.0045f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.9680f,0.0127f,-0.0033f,-0.2507f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0033f,-0.2507f,0.9680f,0.0127f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3679f,0.8305f,0.2336f],left_rotation:[-0.1783f,-0.0163f,0.1091f,-0.9778f]}}
particle minecraft:cloud -96.01 70.10 -20.01 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -96.01 69.90 -20.01 -0.048 0.02 0.003 1 0 force
particle minecraft:cloud -95.89 70.10 -18.30 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -97149
scoreboard players set #gdx driftmountains 268
scoreboard players set #gy driftmountains 69896
scoreboard players set #gdy driftmountains -14
scoreboard players set #gz driftmountains -15102
scoreboard players set #gdz driftmountains -600
scoreboard players set #gr driftmountains -10709
scoreboard players set #gdr driftmountains 289
scoreboard players set #gp driftmountains 76
scoreboard players set #gdp driftmountains 2
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[-0.0036f,-0.0001f,-0.0223f,0.9997f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.5267f,0.3073f,-0.1405f,0.7800f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.2233f,0.7991f,0.4973f,-0.2537f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.9680f,0.0127f,-0.0033f,-0.2507f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0033f,-0.2507f,0.9680f,0.0127f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3523f,0.8449f,0.0991f],left_rotation:[-0.1873f,0.0147f,-0.0436f,-0.9812f]}}
particle minecraft:cloud -98.60 70.22 -15.53 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -98.60 70.02 -15.53 -0.042 0.02 0.013 1 0 force
particle minecraft:cloud -98.11 70.22 -13.93 0.35 0.18 0.35 0.02 3 force
