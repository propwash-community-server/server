scoreboard players set #gx driftmountains -72750
scoreboard players set #gdx driftmountains -953
scoreboard players set #gy driftmountains 70298
scoreboard players set #gdy driftmountains -27
scoreboard players set #gz driftmountains 29890
scoreboard players set #gdz driftmountains -1036
scoreboard players set #gr driftmountains 17801
scoreboard players set #gdr driftmountains -17
scoreboard players set #gp driftmountains 82
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.1647f,-0.3274f,-0.1150f,-0.9233f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.0186f,-0.9163f,0.2000f,0.3465f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.4029f,0.0053f,0.0120f,0.9152f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0120f,0.9152f,0.4029f,0.0053f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3525f,0.8408f,0.0975f],left_rotation:[-0.1868f,-0.0017f,0.0439f,-0.9814f]}}
particle minecraft:cloud -73.54 70.62 31.18 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -73.54 70.42 31.18 0.003 0.02 0.085 1 0 force
particle minecraft:cloud -71.87 70.62 31.12 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -64721
scoreboard players set #gdx driftmountains -1014
scoreboard players set #gy driftmountains 70478
scoreboard players set #gdy driftmountains -18
scoreboard players set #gz driftmountains 37323
scoreboard players set #gdz driftmountains -936
scoreboard players set #gr driftmountains 17830
scoreboard players set #gdr driftmountains 34
scoreboard players set #gp driftmountains 48
scoreboard players set #gdp driftmountains 7
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.7756f,-0.1559f,-0.3413f,-0.5075f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.2898f,-0.4744f,0.7963f,0.2383f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.4029f,0.0053f,0.0120f,0.9152f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0120f,0.9152f,0.4029f,0.0053f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3780f,0.8273f,0.2323f],left_rotation:[-0.1692f,-0.0560f,0.3114f,-0.9335f]}}
particle minecraft:cloud -65.54 70.80 38.71 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -65.54 70.60 38.71 0.002 0.02 0.083 1 0 force
particle minecraft:cloud -63.83 70.80 38.66 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -60782
scoreboard players set #gdx driftmountains -1056
scoreboard players set #gy driftmountains 70516
scoreboard players set #gdy driftmountains -4
scoreboard players set #gz driftmountains 40944
scoreboard players set #gdz driftmountains -836
scoreboard players set #gr driftmountains 17605
scoreboard players set #gdr driftmountains 151
scoreboard players set #gp driftmountains 6
scoreboard players set #gdp driftmountains 10
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.6796f,0.3008f,-0.2442f,0.6230f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.3110f,0.6521f,0.6517f,-0.2310f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.4029f,0.0053f,0.0120f,0.9152f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0120f,0.9152f,0.4029f,0.0053f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3621f,0.8255f,0.0915f],left_rotation:[-0.1664f,-0.0732f,0.4221f,-0.8881f]}}
particle minecraft:cloud -61.53 70.84 42.26 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -61.53 70.64 42.26 0.006 0.02 0.081 1 0 force
particle minecraft:cloud -59.86 70.84 42.14 0.35 0.18 0.35 0.02 3 force
