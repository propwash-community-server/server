scoreboard players set #gx driftmountains 23682
scoreboard players set #gdx driftmountains -524
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 48046
scoreboard players set #gdz driftmountains 939
scoreboard players set #gr driftmountains 8092
scoreboard players set #gdr driftmountains 168
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.5835f,-0.2776f,-0.3065f,-0.6990f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.2347f,-0.6706f,0.6159f,0.3404f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.1205f,0.0016f,0.0130f,0.9926f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0130f,0.9926f,0.1205f,0.0016f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3739f,0.8211f,0.0898f],left_rotation:[-0.1387f,-0.1143f,0.6367f,-0.7498f]}}
particle minecraft:cloud 25.06 71.32 48.67 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 25.06 71.12 48.67 0.064 0.02 -0.010 1 0 force
particle minecraft:cloud 24.79 71.32 47.02 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains 27382
scoreboard players set #gdx driftmountains -354
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 40561
scoreboard players set #gdz driftmountains 981
scoreboard players set #gr driftmountains 8177
scoreboard players set #gdr driftmountains 174
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.8754f,0.0293f,-0.4794f,-0.0555f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.4762f,-0.0054f,0.8771f,0.0625f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.1205f,0.0016f,0.0130f,0.9926f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0130f,0.9926f,0.1205f,0.0016f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.4039f,0.8608f,0.2455f],left_rotation:[-0.0280f,-0.1874f,0.9653f,-0.1800f]}}
particle minecraft:cloud 28.86 71.32 41.21 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 28.86 71.12 41.21 0.061 0.02 -0.009 1 0 force
particle minecraft:cloud 28.61 71.32 39.52 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains 27298
scoreboard players set #gdx driftmountains 14
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 35878
scoreboard players set #gdz driftmountains 906
scoreboard players set #gr driftmountains 5631
scoreboard players set #gdr driftmountains 308
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.2734f,0.4284f,-0.0756f,0.8579f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.1662f,0.8706f,0.2299f,-0.4021f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.1205f,0.0016f,0.0130f,0.9926f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0130f,0.9926f,0.1205f,0.0016f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3844f,0.8221f,0.0902f],left_rotation:[-0.1081f,-0.1429f,0.7837f,-0.5946f]}}
particle minecraft:cloud 28.81 71.32 35.87 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 28.81 71.12 35.87 0.046 0.02 -0.031 1 0 force
particle minecraft:cloud 27.88 71.32 34.48 0.35 0.18 0.35 0.02 3 force
