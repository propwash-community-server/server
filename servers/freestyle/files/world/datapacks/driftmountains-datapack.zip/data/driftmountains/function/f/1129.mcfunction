scoreboard players set #gx driftmountains -84871
scoreboard players set #gdx driftmountains -771
scoreboard players set #gy driftmountains 70005
scoreboard players set #gdy driftmountains -9
scoreboard players set #gz driftmountains 16060
scoreboard players set #gdz driftmountains -926
scoreboard players set #gr driftmountains 17626
scoreboard players set #gdr driftmountains 5
scoreboard players set #gp driftmountains 39
scoreboard players set #gdp driftmountains -9
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[0.0061f,0.0001f,-0.0220f,0.9997f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.6137f,-0.1989f,-0.2404f,-0.7253f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.1654f,-0.7040f,0.6380f,0.2645f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.1426f,0.0019f,-0.0130f,-0.9897f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0130f,-0.9897f,0.1426f,0.0019f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3560f,0.8558f,0.1034f],left_rotation:[-0.1808f,0.0603f,-0.2881f,-0.9384f]}}
particle minecraft:cloud -85.62 70.33 17.37 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -85.62 70.13 17.37 0.005 0.02 0.073 1 0 force
particle minecraft:cloud -83.96 70.33 17.26 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -78225
scoreboard players set #gdx driftmountains -873
scoreboard players set #gy driftmountains 70143
scoreboard players set #gdy driftmountains -22
scoreboard players set #gz driftmountains 23594
scoreboard players set #gdz driftmountains -948
scoreboard players set #gr driftmountains 17578
scoreboard players set #gdr driftmountains 15
scoreboard players set #gp driftmountains 78
scoreboard players set #gdp driftmountains -3
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.9428f,0.0381f,-0.3274f,-0.0499f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.3240f,-0.0157f,0.9440f,0.0608f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.1426f,0.0019f,-0.0130f,-0.9897f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0130f,-0.9897f,0.1426f,0.0019f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3595f,0.8383f,0.2366f],left_rotation:[-0.1791f,0.0289f,-0.1226f,-0.9758f]}}
particle minecraft:cloud -78.98 70.46 25.02 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -78.98 70.26 25.02 0.006 0.02 0.078 1 0 force
particle minecraft:cloud -77.27 70.46 24.89 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -73956
scoreboard players set #gdx driftmountains -867
scoreboard players set #gy driftmountains 70253
scoreboard players set #gdy driftmountains -24
scoreboard players set #gz driftmountains 27802
scoreboard players set #gdz driftmountains -940
scoreboard players set #gr driftmountains 17694
scoreboard players set #gdr driftmountains -22
scoreboard players set #gp driftmountains 83
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.2798f,0.3380f,-0.0471f,0.8974f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.1417f,0.9072f,0.2458f,-0.3105f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.1426f,0.0019f,-0.0130f,-0.9897f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0130f,-0.9897f,0.1426f,0.0019f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3523f,0.8434f,0.0985f],left_rotation:[-0.1873f,0.0087f,-0.0111f,-0.9822f]}}
particle minecraft:cloud -74.72 70.57 29.10 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -74.72 70.37 29.10 0.004 0.02 0.078 1 0 force
particle minecraft:cloud -73.05 70.57 29.02 0.35 0.18 0.35 0.02 3 force
