scoreboard players set #gx driftmountains 18686
scoreboard players set #gdx driftmountains -757
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 55277
scoreboard players set #gdz driftmountains 844
scoreboard players set #gr driftmountains 9522
scoreboard players set #gdr driftmountains 223
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.3122f,0.4167f,-0.0917f,0.8488f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.1814f,0.8631f,0.2702f,-0.3862f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.9120f,0.0119f,0.0054f,0.4099f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0054f,0.4099f,0.9120f,0.0119f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3804f,0.8212f,0.0898f],left_rotation:[-0.1207f,-0.1325f,0.7305f,-0.6588f]}}
particle minecraft:cloud 19.86 71.32 56.22 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 19.86 71.12 56.22 0.068 0.02 0.006 1 0 force
particle minecraft:cloud 20.02 71.32 54.56 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains 23489
scoreboard players set #gdx driftmountains -655
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 48281
scoreboard players set #gdz driftmountains 912
scoreboard players set #gr driftmountains 9364
scoreboard players set #gdr driftmountains 174
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.3965f,-0.3794f,-0.2546f,-0.7962f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.1723f,-0.7739f,0.4386f,0.4232f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.9120f,0.0119f,0.0054f,0.4099f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0054f,0.4099f,0.9120f,0.0119f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.4063f,0.8497f,0.2411f],left_rotation:[-0.0698f,-0.1725f,0.8945f,-0.4065f]}}
particle minecraft:cloud 24.80 71.32 49.22 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 24.80 71.12 49.22 0.068 0.02 0.004 1 0 force
particle minecraft:cloud 24.91 71.32 47.51 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains 26226
scoreboard players set #gdx driftmountains -315
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 43348
scoreboard players set #gdz driftmountains 1007
scoreboard players set #gr driftmountains 7412
scoreboard players set #gdr driftmountains 166
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.8731f,0.1517f,-0.4226f,0.1898f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.4449f,0.2352f,0.8620f,-0.0608f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.9120f,0.0119f,0.0054f,0.4099f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0054f,0.4099f,0.9120f,0.0119f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3906f,0.8250f,0.0913f],left_rotation:[-0.0853f,-0.1580f,0.8600f,-0.4775f]}}
particle minecraft:cloud 27.67 71.32 43.81 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 27.67 71.12 43.81 0.058 0.02 -0.016 1 0 force
particle minecraft:cloud 27.21 71.32 42.20 0.35 0.18 0.35 0.02 3 force
