scoreboard players set #gx driftmountains -19191
scoreboard players set #gdx driftmountains 717
scoreboard players set #gy driftmountains 67129
scoreboard players set #gdy driftmountains -10
scoreboard players set #gz driftmountains -83828
scoreboard players set #gdz driftmountains 437
scoreboard players set #gr driftmountains -3096
scoreboard players set #gdr driftmountains -17
scoreboard players set #gp driftmountains 63
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0001f,-0.0170f,0.9998f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.9564f,0.0127f,-0.2386f,-0.1681f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.2223f,-0.1440f,0.9603f,0.0877f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.6443f,0.0084f,-0.0100f,-0.7646f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0100f,-0.7646f,0.6443f,0.0084f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3861f,0.8648f,0.1069f],left_rotation:[-0.1061f,0.1587f,-0.8278f,-0.5275f]}}
particle minecraft:cloud -19.12 67.45 -85.34 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -19.12 67.25 -85.34 -0.026 0.02 -0.043 1 0 force
particle minecraft:cloud -20.56 67.45 -84.48 0.35 0.18 0.35 0.02 2 force
scoreboard players set #gx driftmountains -25594
scoreboard players set #gdx driftmountains 711
scoreboard players set #gy driftmountains 67224
scoreboard players set #gdy driftmountains -11
scoreboard players set #gz driftmountains -87176
scoreboard players set #gdz driftmountains 392
scoreboard players set #gr driftmountains -3251
scoreboard players set #gdr driftmountains 30
scoreboard players set #gp driftmountains 70
scoreboard players set #gdp driftmountains -1
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0001f,-0.0176f,0.9998f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.9699f,0.0604f,-0.2342f,0.0271f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.2384f,0.0519f,0.9689f,0.0412f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.6443f,0.0084f,-0.0100f,-0.7646f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0100f,-0.7646f,0.6443f,0.0084f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3704f,0.8722f,0.2499f],left_rotation:[-0.1051f,0.1611f,-0.8112f,-0.5523f]}}
particle minecraft:cloud -25.61 67.54 -88.79 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -25.61 67.34 -88.79 -0.025 0.02 -0.040 1 0 force
particle minecraft:cloud -27.05 67.54 -87.87 0.35 0.18 0.35 0.02 2 force
scoreboard players set #gx driftmountains -32274
scoreboard players set #gdx driftmountains 629
scoreboard players set #gy driftmountains 67341
scoreboard players set #gdy driftmountains -12
scoreboard players set #gz driftmountains -90980
scoreboard players set #gdz driftmountains 244
scoreboard players set #gr driftmountains -3802
scoreboard players set #gdr driftmountains 69
scoreboard players set #gp driftmountains 87
scoreboard players set #gdp driftmountains -5
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0001f,-0.0192f,0.9998f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.8201f,0.1714f,-0.1703f,0.5188f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.2257f,0.5395f,0.8066f,-0.0862f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.6443f,0.0084f,-0.0100f,-0.7646f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0100f,-0.7646f,0.6443f,0.0084f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3850f,0.8653f,0.1071f],left_rotation:[-0.1100f,0.1563f,-0.8139f,-0.5485f]}}
particle minecraft:cloud -32.39 67.66 -92.49 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -32.39 67.46 -92.49 -0.025 0.02 -0.032 1 0 force
particle minecraft:cloud -33.71 67.66 -91.46 0.35 0.18 0.35 0.02 3 force
