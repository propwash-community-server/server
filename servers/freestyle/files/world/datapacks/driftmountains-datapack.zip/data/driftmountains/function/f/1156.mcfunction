scoreboard players set #gx driftmountains -98126
scoreboard players set #gdx driftmountains -17
scoreboard players set #gy driftmountains 70014
scoreboard players set #gdy driftmountains -8
scoreboard players set #gz driftmountains -7623
scoreboard players set #gdz driftmountains -858
scoreboard players set #gr driftmountains -13298
scoreboard players set #gdr driftmountains 190
scoreboard players set #gp driftmountains 31
scoreboard players set #gdp driftmountains 6
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.0709f,0.3703f,0.0281f,0.9258f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.0690f,0.9279f,0.0323f,-0.3648f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.5449f,0.0071f,0.0110f,0.8384f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0110f,0.8384f,0.5449f,0.0071f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3567f,0.8307f,0.0935f],left_rotation:[-0.1780f,-0.0453f,0.2753f,-0.9436f]}}
particle minecraft:cloud -99.62 70.33 -7.37 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -99.62 70.13 -7.37 -0.038 0.02 0.035 1 0 force
particle minecraft:cloud -98.48 70.33 -6.15 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -96627
scoreboard players set #gdx driftmountains -310
scoreboard players set #gy driftmountains 70029
scoreboard players set #gdy driftmountains 2
scoreboard players set #gz driftmountains 339
scoreboard players set #gdz driftmountains -863
scoreboard players set #gr driftmountains -15062
scoreboard players set #gdr driftmountains 289
scoreboard players set #gp driftmountains -10
scoreboard players set #gdp driftmountains 3
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[-0.0028f,-0.0001f,-0.0223f,0.9997f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.6197f,-0.2344f,-0.2853f,-0.6925f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.2140f,-0.6664f,0.6478f,0.3009f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.5449f,0.0071f,0.0110f,0.8384f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0110f,0.8384f,0.5449f,0.0071f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3750f,0.8278f,0.2325f],left_rotation:[-0.1725f,-0.0450f,0.2556f,-0.9502f]}}
particle minecraft:cloud -98.04 70.35 1.11 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -98.04 70.15 1.11 -0.027 0.02 0.048 1 0 force
particle minecraft:cloud -96.55 70.35 1.95 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -94037
scoreboard players set #gdx driftmountains -531
scoreboard players set #gy driftmountains 70008
scoreboard players set #gdy driftmountains 4
scoreboard players set #gz driftmountains 5118
scoreboard players set #gdz driftmountains -776
scoreboard players set #gr driftmountains -16706
scoreboard players set #gdr driftmountains 286
scoreboard players set #gp driftmountains -17
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.8236f,0.2190f,-0.2978f,0.4302f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.3446f,0.4639f,0.8051f,-0.1336f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.5449f,0.0071f,0.0110f,0.8384f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0110f,0.8384f,0.5449f,0.0071f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3562f,0.8314f,0.0938f],left_rotation:[-0.1790f,-0.0423f,0.2593f,-0.9481f]}}
particle minecraft:cloud -95.13 70.33 6.16 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -95.13 70.13 6.16 -0.013 0.02 0.056 1 0 force
particle minecraft:cloud -93.51 70.33 6.53 0.35 0.18 0.35 0.02 3 force
