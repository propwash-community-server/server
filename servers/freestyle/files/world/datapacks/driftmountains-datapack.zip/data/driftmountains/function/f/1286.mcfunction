scoreboard players set #gx driftmountains -56575
scoreboard players set #gdx driftmountains 73
scoreboard players set #gy driftmountains 68059
scoreboard players set #gdy driftmountains -18
scoreboard players set #gz driftmountains -71669
scoreboard players set #gdz driftmountains -587
scoreboard players set #gr driftmountains -14120
scoreboard players set #gdr driftmountains 404
scoreboard players set #gp driftmountains 139
scoreboard players set #gdp driftmountains 4
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[-0.0015f,-0.0000f,-0.0205f,0.9998f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.6214f,-0.1008f,-0.1508f,-0.7622f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.0715f,-0.7505f,0.6354f,0.1667f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.7048f,0.0092f,0.0093f,0.7093f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0093f,0.7093f,0.7048f,0.0092f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.4012f,0.8454f,0.0993f],left_rotation:[-0.0092f,0.1843f,-0.9827f,-0.0136f]}}
particle minecraft:cloud -58.01 68.38 -71.21 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -58.01 68.18 -71.21 -0.022 0.02 0.028 1 0 force
particle minecraft:cloud -56.71 68.38 -70.16 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -55642
scoreboard players set #gdx driftmountains -94
scoreboard players set #gy driftmountains 68175
scoreboard players set #gdy driftmountains -15
scoreboard players set #gz driftmountains -66433
scoreboard players set #gdz driftmountains -800
scoreboard players set #gr driftmountains -16029
scoreboard players set #gdr driftmountains 319
scoreboard players set #gp driftmountains 90
scoreboard players set #gdp driftmountains 1
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[0.0061f,0.0001f,-0.0163f,0.9998f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.2566f,-0.1940f,-0.1085f,-0.9406f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.0102f,-0.9344f,0.2784f,0.2221f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.7048f,0.0092f,0.0093f,0.7093f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0093f,0.7093f,0.7048f,0.0092f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3796f,0.8743f,0.2507f],left_rotation:[-0.0760f,0.1776f,-0.9002f,-0.3903f]}}
particle minecraft:cloud -56.91 68.49 -65.44 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -56.91 68.29 -65.44 -0.016 0.02 0.044 1 0 force
particle minecraft:cloud -55.30 68.49 -64.86 0.35 0.18 0.35 0.02 2 force
scoreboard players set #gx driftmountains -54482
scoreboard players set #gdx driftmountains -95
scoreboard players set #gy driftmountains 68289
scoreboard players set #gdy driftmountains -12
scoreboard players set #gz driftmountains -59770
scoreboard players set #gdz driftmountains -746
scoreboard players set #gr driftmountains 16685
scoreboard players set #gdr driftmountains 421
scoreboard players set #gp driftmountains 96
scoreboard players set #gdp driftmountains -1
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,0.0000f,0.0036f,1.0000f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.4951f,-0.0209f,0.0724f,0.8655f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.0182f,0.8627f,0.5001f,0.0731f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.7048f,0.0092f,0.0093f,0.7093f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0093f,0.7093f,0.7048f,0.0092f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3626f,0.8623f,0.1059f],left_rotation:[0.1676f,-0.0935f,0.4677f,0.8627f]}}
