scoreboard players set #gx driftmountains -90270
scoreboard players set #gdx driftmountains 549
scoreboard players set #gy driftmountains 69628
scoreboard players set #gdy driftmountains -18
scoreboard players set #gz driftmountains -23429
scoreboard players set #gdz driftmountains -402
scoreboard players set #gr driftmountains -8279
scoreboard players set #gdr driftmountains 152
scoreboard players set #gp driftmountains 110
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.5277f,-0.2407f,-0.2294f,-0.7817f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.1485f,-0.7619f,0.5559f,0.2975f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.4948f,0.0065f,0.0114f,0.8689f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0114f,0.8689f,0.4948f,0.0065f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3526f,0.8473f,0.1000f],left_rotation:[-0.1869f,0.0245f,-0.0958f,-0.9773f]}}
particle minecraft:cloud -91.41 69.95 -24.42 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -91.41 69.75 -24.42 -0.041 0.02 -0.005 1 0 force
particle minecraft:cloud -91.62 69.95 -22.76 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -95077
scoreboard players set #gdx driftmountains 489
scoreboard players set #gy driftmountains 69803
scoreboard players set #gdy driftmountains -19
scoreboard players set #gz driftmountains -18623
scoreboard players set #gdz driftmountains -629
scoreboard players set #gr driftmountains -9509
scoreboard players set #gdr driftmountains 96
scoreboard players set #gp driftmountains 92
scoreboard players set #gdp driftmountains 3
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[-0.0035f,-0.0001f,-0.0223f,0.9997f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.2201f,0.3559f,-0.0287f,0.9078f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.1243f,0.9158f,0.1839f,-0.3348f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.4948f,0.0065f,0.0114f,0.8689f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0114f,0.8689f,0.4948f,0.0065f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3693f,0.8298f,0.2333f],left_rotation:[-0.1774f,-0.0225f,0.1405f,-0.9738f]}}
particle minecraft:cloud -96.51 70.12 -19.35 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -96.51 69.92 -19.35 -0.047 0.02 0.004 1 0 force
particle minecraft:cloud -96.36 70.12 -17.65 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -97435
scoreboard players set #gdx driftmountains 286
scoreboard players set #gy driftmountains 69913
scoreboard players set #gdy driftmountains -17
scoreboard players set #gz driftmountains -14336
scoreboard players set #gdz driftmountains -766
scoreboard players set #gr driftmountains -11056
scoreboard players set #gdr driftmountains 347
scoreboard players set #gp driftmountains 73
scoreboard players set #gdp driftmountains 3
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[0.0011f,0.0000f,-0.0223f,0.9997f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.4550f,-0.2665f,-0.2108f,-0.8231f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.1255f,-0.8055f,0.4855f,0.3158f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.4948f,0.0065f,0.0114f,0.8689f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0114f,0.8689f,0.4948f,0.0065f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3523f,0.8440f,0.0988f],left_rotation:[-0.1873f,0.0114f,-0.0258f,-0.9818f]}}
particle minecraft:cloud -98.91 70.23 -14.68 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -98.91 70.03 -14.68 -0.041 0.02 0.015 1 0 force
particle minecraft:cloud -98.32 70.23 -13.11 0.35 0.18 0.35 0.02 3 force
