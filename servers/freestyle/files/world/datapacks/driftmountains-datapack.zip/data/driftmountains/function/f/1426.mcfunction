scoreboard players set #gx driftmountains 44047
scoreboard players set #gdx driftmountains 1131
scoreboard players set #gy driftmountains 66319
scoreboard players set #gdy driftmountains -13
scoreboard players set #gz driftmountains -43731
scoreboard players set #gdz driftmountains 717
scoreboard players set #gr driftmountains -3534
scoreboard players set #gdr driftmountains 183
scoreboard players set #gp driftmountains 50
scoreboard players set #gdp driftmountains -1
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0001f,-0.0137f,0.9999f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.7362f,0.1653f,-0.1072f,0.6474f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.1759f,0.6623f,0.7229f,-0.0888f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.9964f,0.0130f,0.0011f,0.0833f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0011f,0.0833f,0.9964f,0.0130f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3996f,0.8521f,0.1019f],left_rotation:[-0.0371f,0.1828f,-0.9692f,-0.1606f]}}
particle minecraft:cloud 44.00 66.64 -45.24 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke 44.00 66.44 -45.24 -0.046 0.02 -0.065 1 0 force
particle minecraft:cloud 42.64 66.64 -44.28 0.35 0.18 0.35 0.02 2 force
scoreboard players set #gx driftmountains 35693
scoreboard players set #gdx driftmountains 1023
scoreboard players set #gy driftmountains 66404
scoreboard players set #gdy driftmountains -13
scoreboard players set #gz driftmountains -47004
scoreboard players set #gdz driftmountains 719
scoreboard players set #gr driftmountains -5210
scoreboard players set #gdr driftmountains 187
scoreboard players set #gp driftmountains 58
scoreboard players set #gdp driftmountains -1
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0000f,-0.0016f,1.0000f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.1482f,0.0344f,0.0478f,0.9872f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.0557f,0.9876f,0.1454f,-0.0190f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.9964f,0.0130f,0.0011f,0.0833f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0011f,0.0833f,0.9964f,0.0130f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3740f,0.8281f,0.2326f],left_rotation:[0.1735f,0.0413f,-0.2365f,0.9551f]}}
scoreboard players set #gx driftmountains 26609
scoreboard players set #gdx driftmountains 1061
scoreboard players set #gy driftmountains 66533
scoreboard players set #gdy driftmountains -14
scoreboard players set #gz driftmountains -54662
scoreboard players set #gdz driftmountains 583
scoreboard players set #gr driftmountains -6095
scoreboard players set #gdr driftmountains 360
scoreboard players set #gp driftmountains 64
scoreboard players set #gdp driftmountains 1
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[0.0061f,0.0000f,-0.0012f,1.0000f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.7194f,0.0252f,0.0493f,0.6924f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.0232f,0.6910f,0.7207f,0.0502f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.9964f,0.0130f,0.0011f,0.0833f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0011f,0.0833f,0.9964f,0.0130f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3534f,0.8503f,0.1012f],left_rotation:[0.1856f,-0.0370f,0.1628f,0.9683f]}}
