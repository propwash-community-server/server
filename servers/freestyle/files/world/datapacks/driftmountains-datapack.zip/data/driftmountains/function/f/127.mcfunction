scoreboard players set #gx driftmountains 8433
scoreboard players set #gdx driftmountains 465
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains -11949
scoreboard players set #gdz driftmountains 817
scoreboard players set #gr driftmountains 911
scoreboard players set #gdr driftmountains -11
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.9204f,0.1257f,-0.3075f,0.2062f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.3309f,0.2397f,0.9123f,-0.0296f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.6701f,0.0088f,0.0097f,0.7421f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0097f,0.7421f,0.6701f,0.0088f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3526f,0.8474f,0.1001f],left_rotation:[-0.1869f,0.0250f,-0.0986f,-0.9771f]}}
particle minecraft:cloud 9.46 71.32 -13.06 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 9.46 71.12 -13.06 0.009 0.02 -0.055 1 0 force
particle minecraft:cloud 7.81 71.32 -13.33 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains 5557
scoreboard players set #gdx driftmountains 418
scoreboard players set #gy driftmountains 70823
scoreboard players set #gdy driftmountains 55
scoreboard players set #gz driftmountains -17281
scoreboard players set #gdz driftmountains 770
scoreboard players set #gr driftmountains 1420
scoreboard players set #gdr driftmountains -21
scoreboard players set #gp driftmountains -280
scoreboard players set #gdp driftmountains 31
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.5527f,0.3117f,-0.1587f,0.7564f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.2390f,0.7773f,0.5230f,-0.2553f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.6701f,0.0088f,0.0097f,0.7421f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0097f,0.7421f,0.6701f,0.0088f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3662f,0.8316f,0.2340f],left_rotation:[-0.1792f,-0.0087f,0.0699f,-0.9813f]}}
particle minecraft:cloud 6.72 71.14 -18.39 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 6.72 70.94 -18.39 0.013 0.02 -0.051 1 0 force
particle minecraft:cloud 5.06 71.14 -18.81 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains 2518
scoreboard players set #gdx driftmountains 514
scoreboard players set #gy driftmountains 70492
scoreboard players set #gdy driftmountains 29
scoreboard players set #gz driftmountains -21398
scoreboard players set #gdz driftmountains 573
scoreboard players set #gr driftmountains 182
scoreboard players set #gdr driftmountains 298
scoreboard players set #gp driftmountains -99
scoreboard players set #gdp driftmountains -91
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.9359f,0.0036f,-0.3163f,-0.1546f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.3018f,-0.1223f,0.9407f,0.0948f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.6701f,0.0088f,0.0097f,0.7421f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0097f,0.7421f,0.6701f,0.0088f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3550f,0.8541f,0.1027f],left_rotation:[-0.1827f,0.0528f,-0.2476f,-0.9500f]}}
particle minecraft:cloud 3.39 70.81 -22.63 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 3.39 70.61 -22.63 0.002 0.02 -0.051 1 0 force
particle minecraft:cloud 1.72 70.81 -22.68 0.35 0.18 0.35 0.02 3 force
