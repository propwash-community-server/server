scoreboard players set #gx driftmountains -19777
scoreboard players set #gdx driftmountains -1085
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 57571
scoreboard players set #gdz driftmountains -332
scoreboard players set #gr driftmountains 15324
scoreboard players set #gdr driftmountains 21
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.8338f,0.2155f,-0.3287f,0.3877f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.3712f,0.4244f,0.8157f,-0.1291f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.9643f,0.0126f,-0.0035f,-0.2645f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0035f,-0.2645f,0.9643f,0.0126f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3644f,0.8241f,0.0909f],left_rotation:[-0.1614f,-0.0825f,0.4707f,-0.8634f]}}
particle minecraft:cloud -19.96 71.32 59.07 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -19.96 71.12 59.07 0.031 0.02 0.061 1 0 force
particle minecraft:cloud -18.46 71.32 58.32 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -10829
scoreboard players set #gdx driftmountains -989
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 59955
scoreboard players set #gdz driftmountains -260
scoreboard players set #gr driftmountains 15119
scoreboard players set #gdr driftmountains -44
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.2880f,0.3894f,-0.0687f,0.8722f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.1607f,0.8842f,0.2487f,-0.3613f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.9643f,0.0126f,-0.0035f,-0.2645f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0035f,-0.2645f,0.9643f,0.0126f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3881f,0.8281f,0.2326f],left_rotation:[-0.1535f,-0.0915f,0.4911f,-0.8526f]}}
particle minecraft:cloud -10.92 71.32 61.56 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -10.92 71.12 61.56 0.029 0.02 0.053 1 0 force
particle minecraft:cloud -9.42 71.32 60.74 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -5961
scoreboard players set #gdx driftmountains -1024
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 61434
scoreboard players set #gdz driftmountains -267
scoreboard players set #gr driftmountains 15544
scoreboard players set #gdr driftmountains -50
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.7621f,-0.1786f,-0.3860f,-0.4881f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.3368f,-0.4503f,0.7851f,0.2597f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.9643f,0.0126f,-0.0035f,-0.2645f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0035f,-0.2645f,0.9643f,0.0126f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3797f,0.8211f,0.0898f],left_rotation:[-0.1227f,-0.1307f,0.7213f,-0.6689f]}}
particle minecraft:cloud -6.20 71.32 62.93 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -6.20 71.12 62.93 0.027 0.02 0.059 1 0 force
particle minecraft:cloud -4.68 71.32 62.23 0.35 0.18 0.35 0.02 3 force
