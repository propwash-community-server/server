scoreboard players set #gx driftmountains -48487
scoreboard players set #gdx driftmountains 547
scoreboard players set #gy driftmountains 67728
scoreboard players set #gdy driftmountains -13
scoreboard players set #gz driftmountains -86216
scoreboard players set #gdz driftmountains -541
scoreboard players set #gr driftmountains -10191
scoreboard players set #gdr driftmountains 167
scoreboard players set #gp driftmountains 80
scoreboard players set #gdp driftmountains 2
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0001f,-0.0205f,0.9998f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.3177f,-0.2161f,-0.1324f,-0.9137f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.0370f,-0.9048f,0.3421f,0.2507f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.8963f,0.0117f,-0.0058f,-0.4433f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0058f,-0.4433f,0.8963f,0.0117f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3796f,0.8664f,0.1075f],left_rotation:[-0.1265f,0.1441f,-0.7462f,-0.6374f]}}
particle minecraft:cloud -49.89 68.05 -86.77 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -49.89 67.85 -86.77 -0.045 0.02 0.009 1 0 force
particle minecraft:cloud -49.55 68.05 -85.14 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -51716
scoreboard players set #gdx driftmountains 394
scoreboard players set #gy driftmountains 67811
scoreboard players set #gdy driftmountains -12
scoreboard players set #gz driftmountains -82184
scoreboard players set #gdz driftmountains -605
scoreboard players set #gr driftmountains -11378
scoreboard players set #gdr driftmountains 166
scoreboard players set #gp driftmountains 76
scoreboard players set #gdp driftmountains -1
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0001f,-0.0207f,0.9998f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.5775f,-0.1630f,-0.1883f,-0.7775f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.1076f,-0.7620f,0.5978f,0.2246f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.8963f,0.0117f,-0.0058f,-0.4433f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0058f,-0.4433f,0.8963f,0.0117f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3673f,0.8706f,0.2493f],left_rotation:[-0.1150f,0.1536f,-0.7712f,-0.6070f]}}
particle minecraft:cloud -53.31 68.13 -82.42 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -53.31 67.93 -82.42 -0.041 0.02 0.018 1 0 force
particle minecraft:cloud -52.62 68.13 -80.85 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -53497
scoreboard players set #gdx driftmountains 249
scoreboard players set #gy driftmountains 67910
scoreboard players set #gdy driftmountains -13
scoreboard players set #gz driftmountains -76869
scoreboard players set #gdz driftmountains -581
scoreboard players set #gr driftmountains -12655
scoreboard players set #gdr driftmountains 37
scoreboard players set #gp driftmountains 101
scoreboard players set #gdp driftmountains -4
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0001f,-0.0186f,0.9998f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.9690f,0.0503f,-0.2416f,-0.0147f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.2414f,0.0106f,0.9690f,0.0513f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.8963f,0.0117f,-0.0058f,-0.4433f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0058f,-0.4433f,0.8963f,0.0117f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3826f,0.8659f,0.1073f],left_rotation:[-0.1174f,0.1512f,-0.7855f,-0.5884f]}}
particle minecraft:cloud -55.01 68.23 -76.79 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -55.01 68.03 -76.79 -0.033 0.02 0.025 1 0 force
particle minecraft:cloud -54.01 68.23 -75.45 0.35 0.18 0.35 0.02 3 force
