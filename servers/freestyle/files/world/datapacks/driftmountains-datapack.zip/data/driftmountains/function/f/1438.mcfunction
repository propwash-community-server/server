scoreboard players set #gx driftmountains 57715
scoreboard players set #gdx driftmountains 1145
scoreboard players set #gy driftmountains 66170
scoreboard players set #gdy driftmountains -13
scoreboard players set #gz driftmountains -34407
scoreboard players set #gdz driftmountains 850
scoreboard players set #gr driftmountains -6221
scoreboard players set #gdr driftmountains -341
scoreboard players set #gp driftmountains 50
scoreboard players set #gdp driftmountains -1
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,0.0000f,0.0053f,1.0000f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.7380f,-0.0145f,0.0943f,0.6681f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[-0.0246f,0.6618f,0.7436f,0.0922f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.9936f,0.0130f,0.0015f,0.1125f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0015f,0.1125f,0.9936f,0.0130f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3731f,0.8663f,0.1075f],left_rotation:[0.1437f,-0.1277f,0.6549f,0.7308f]}}
scoreboard players set #gx driftmountains 49484
scoreboard players set #gdx driftmountains 1245
scoreboard players set #gy driftmountains 66250
scoreboard players set #gdy driftmountains -13
scoreboard players set #gz driftmountains -38233
scoreboard players set #gdz driftmountains 715
scoreboard players set #gr driftmountains -4105
scoreboard players set #gdr driftmountains -358
scoreboard players set #gp driftmountains 49
scoreboard players set #gdp driftmountains 1
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0000f,-0.0116f,0.9999f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.1535f,0.1747f,0.0262f,0.9722f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.0759f,0.9748f,0.1359f,-0.1595f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.9936f,0.0130f,0.0015f,0.1125f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0015f,0.1125f,0.9936f,0.0130f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3995f,0.8668f,0.2478f],left_rotation:[0.0007f,0.1913f,-0.9811f,0.0309f]}}
particle minecraft:cloud 49.23 66.57 -39.82 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke 49.23 66.37 -39.82 -0.055 0.02 -0.063 1 0 force
particle minecraft:cloud 47.94 66.57 -38.70 0.35 0.18 0.35 0.02 2 force
scoreboard players set #gx driftmountains 39084
scoreboard players set #gdx driftmountains 1159
scoreboard players set #gy driftmountains 66368
scoreboard players set #gdy driftmountains -14
scoreboard players set #gz driftmountains -45536
scoreboard players set #gdz driftmountains 922
scoreboard players set #gr driftmountains -4019
scoreboard players set #gdr driftmountains 319
scoreboard players set #gp driftmountains 55
scoreboard players set #gdp driftmountains -1
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0000f,-0.0069f,1.0000f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.7202f,0.1065f,-0.0357f,0.6846f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.1078f,0.6922f,0.7130f,-0.0314f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.9936f,0.0130f,0.0015f,0.1125f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0015f,0.1125f,0.9936f,0.0130f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3835f,0.8218f,0.0901f],left_rotation:[0.1110f,0.1407f,-0.7722f,0.6095f]}}
particle minecraft:cloud 38.91 66.69 -47.04 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke 38.91 66.49 -47.04 -0.053 0.02 -0.063 1 0 force
particle minecraft:cloud 37.63 66.69 -45.96 0.35 0.18 0.35 0.02 2 force
