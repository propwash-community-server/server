scoreboard players set #gx driftmountains 41797
scoreboard players set #gdx driftmountains 1123
scoreboard players set #gy driftmountains 66345
scoreboard players set #gdy driftmountains -13
scoreboard players set #gz driftmountains -45144
scoreboard players set #gdz driftmountains 703
scoreboard players set #gr driftmountains -4068
scoreboard players set #gdr driftmountains 303
scoreboard players set #gp driftmountains 52
scoreboard players set #gdp driftmountains -1
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0000f,-0.0106f,0.9999f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.9679f,0.0813f,-0.1345f,0.1962f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.1559f,0.2114f,0.9647f,0.0200f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.9025f,0.0118f,-0.0056f,-0.4305f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0056f,-0.4305f,0.9025f,0.0118f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3994f,0.8350f,0.0952f],left_rotation:[0.0347f,0.1784f,-0.9594f,0.2155f]}}
particle minecraft:cloud 41.61 66.66 -46.64 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke 41.61 66.46 -46.64 -0.052 0.02 -0.060 1 0 force
particle minecraft:cloud 40.34 66.66 -45.56 0.35 0.18 0.35 0.02 2 force
playsound driftgen:grain.kaze.059 neutral @a 50.86 66.74 -39.27 12 1
scoreboard players set #gx driftmountains 33533
scoreboard players set #gdx driftmountains 1026
scoreboard players set #gy driftmountains 66432
scoreboard players set #gdy driftmountains -13
scoreboard players set #gz driftmountains -48533
scoreboard players set #gdz driftmountains 726
scoreboard players set #gr driftmountains -5420
scoreboard players set #gdr driftmountains 69
scoreboard players set #gp driftmountains 60
scoreboard players set #gdp driftmountains -1
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0000f,-0.0003f,1.0000f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.6212f,0.0352f,0.0388f,0.7819f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.0431f,0.7821f,0.6209f,0.0298f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.9025f,0.0118f,-0.0056f,-0.4305f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0056f,-0.4305f,0.9025f,0.0118f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3645f,0.8328f,0.2345f],left_rotation:[0.1797f,0.0006f,-0.0285f,0.9833f]}}
playsound driftgen:grain.onyx.062 neutral @a 42.35 66.83 -42.53 12 1
scoreboard players set #gx driftmountains 24358
scoreboard players set #gdx driftmountains 1130
scoreboard players set #gy driftmountains 66560
scoreboard players set #gdy driftmountains -14
scoreboard players set #gz driftmountains -55755
scoreboard players set #gdz driftmountains 547
scoreboard players set #gr driftmountains -6352
scoreboard players set #gdr driftmountains 33
scoreboard players set #gp driftmountains 62
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[0.0061f,0.0000f,-0.0002f,1.0000f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.9696f,0.0571f,-0.0128f,0.2377f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.0379f,0.2403f,0.9689f,0.0445f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.9025f,0.0118f,-0.0056f,-0.4305f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0056f,-0.4305f,0.9025f,0.0118f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3554f,0.8326f,0.0943f],left_rotation:[0.1806f,0.0365f,-0.2290f,0.9558f]}}
playsound driftgen:grain.kaze.060 neutral @a 32.84 66.95 -50.44 12 1
