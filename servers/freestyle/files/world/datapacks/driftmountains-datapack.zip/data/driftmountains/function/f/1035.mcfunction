scoreboard players set #gx driftmountains 13777
scoreboard players set #gdx driftmountains -896
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 59817
scoreboard players set #gdz driftmountains 587
scoreboard players set #gr driftmountains 11222
scoreboard players set #gdr driftmountains 391
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.8488f,-0.0917f,-0.4168f,-0.3122f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.3863f,-0.2701f,0.8631f,0.1815f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.4232f,0.0055f,-0.0119f,-0.9059f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0119f,-0.9059f,0.4232f,0.0055f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3804f,0.8212f,0.0898f],left_rotation:[-0.1206f,-0.1326f,0.7311f,-0.6583f]}}
particle minecraft:cloud 14.63 71.32 61.07 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 14.63 71.12 61.07 0.060 0.02 0.024 1 0 force
particle minecraft:cloud 15.26 71.32 59.52 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains 19162
scoreboard players set #gdx driftmountains -780
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 53446
scoreboard players set #gdz driftmountains 765
scoreboard players set #gr driftmountains 10362
scoreboard players set #gdr driftmountains 173
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[0.0061f,0.0001f,-0.0223f,0.9997f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.7935f,0.2574f,-0.3851f,0.3947f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.4287f,0.4373f,0.7708f,-0.1754f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.4232f,0.0055f,-0.0119f,-0.9059f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0119f,-0.9059f,0.4232f,0.0055f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.4062f,0.8528f,0.2423f],left_rotation:[-0.0588f,-0.1776f,0.9190f,-0.3472f]}}
particle minecraft:cloud 20.29 71.32 54.60 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 20.29 71.12 54.60 0.065 0.02 0.016 1 0 force
particle minecraft:cloud 20.69 71.32 52.94 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains 23817
scoreboard players set #gdx driftmountains -545
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 49124
scoreboard players set #gdz driftmountains 950
scoreboard players set #gr driftmountains 8521
scoreboard players set #gdr driftmountains 213
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.1916f,-0.4121f,-0.1494f,-0.8782f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.0579f,-0.8673f,0.2360f,0.4345f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.4232f,0.0055f,-0.0119f,-0.9059f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0119f,-0.9059f,0.4232f,0.0055f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3859f,0.8226f,0.0904f],left_rotation:[-0.1030f,-0.1467f,0.8029f,-0.5684f]}}
particle minecraft:cloud 25.14 71.32 49.85 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 25.14 71.12 49.85 0.065 0.02 -0.005 1 0 force
particle minecraft:cloud 25.00 71.32 48.19 0.35 0.18 0.35 0.02 3 force
