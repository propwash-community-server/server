scoreboard players set #gx driftmountains -71780
scoreboard players set #gdx driftmountains -970
scoreboard players set #gy driftmountains 70325
scoreboard players set #gdy driftmountains -27
scoreboard players set #gz driftmountains 30931
scoreboard players set #gdz driftmountains -1041
scoreboard players set #gr driftmountains 17842
scoreboard players set #gdr driftmountains -40
scoreboard players set #gp driftmountains 80
scoreboard players set #gdp driftmountains 2
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[0.0061f,0.0001f,-0.0223f,0.9997f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.9322f,0.0258f,-0.3520f,-0.0801f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.3455f,-0.0435f,0.9346f,0.0720f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.7782f,0.0102f,-0.0082f,-0.6279f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0082f,-0.6279f,0.7782f,0.0102f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3531f,0.8382f,0.0965f],left_rotation:[-0.1856f,-0.0123f,0.1007f,-0.9773f]}}
particle minecraft:cloud -72.58 70.65 32.21 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -72.58 70.45 32.21 0.002 0.02 0.086 1 0 force
particle minecraft:cloud -70.91 70.65 32.17 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -63689
scoreboard players set #gdx driftmountains -1032
scoreboard players set #gy driftmountains 70493
scoreboard players set #gdy driftmountains -15
scoreboard players set #gz driftmountains 38238
scoreboard players set #gdz driftmountains -915
scoreboard players set #gr driftmountains 17759
scoreboard players set #gdr driftmountains 71
scoreboard players set #gp driftmountains 38
scoreboard players set #gdp driftmountains 10
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.6909f,0.2896f,-0.2393f,0.6177f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.3055f,0.6463f,0.6642f,-0.2186f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.7782f,0.0102f,-0.0082f,-0.6279f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0082f,-0.6279f,0.7782f,0.0102f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3782f,0.8273f,0.2323f],left_rotation:[-0.1689f,-0.0568f,0.3153f,-0.9321f]}}
particle minecraft:cloud -64.49 70.81 39.64 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -64.49 70.61 39.64 0.003 0.02 0.083 1 0 force
particle minecraft:cloud -62.78 70.81 39.57 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -59700
scoreboard players set #gdx driftmountains -1083
scoreboard players set #gy driftmountains 70517
scoreboard players set #gdy driftmountains -1
scoreboard players set #gz driftmountains 41747
scoreboard players set #gdz driftmountains -803
scoreboard players set #gr driftmountains 17445
scoreboard players set #gdr driftmountains 159
scoreboard players set #gp driftmountains -3
scoreboard players set #gdp driftmountains 8
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.4252f,-0.3162f,-0.2286f,-0.8167f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.1440f,-0.7972f,0.4607f,0.3626f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.7782f,0.0102f,-0.0082f,-0.6279f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0082f,-0.6279f,0.7782f,0.0102f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3632f,0.8248f,0.0912f],left_rotation:[-0.1640f,-0.0778f,0.4462f,-0.8763f]}}
particle minecraft:cloud -60.41 70.84 43.08 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -60.41 70.64 43.08 0.008 0.02 0.081 1 0 force
particle minecraft:cloud -58.75 70.84 42.92 0.35 0.18 0.35 0.02 3 force
