scoreboard players set #gx driftmountains 45178
scoreboard players set #gdx driftmountains 1134
scoreboard players set #gy driftmountains 66307
scoreboard players set #gdy driftmountains -12
scoreboard players set #gz driftmountains -43014
scoreboard players set #gdz driftmountains 727
scoreboard players set #gr driftmountains -3351
scoreboard players set #gdr driftmountains 156
scoreboard players set #gp driftmountains 49
scoreboard players set #gdp driftmountains -1
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0001f,-0.0146f,0.9999f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.8134f,-0.0680f,-0.1983f,-0.5427f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.1423f,-0.5248f,0.8250f,0.1539f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.3407f,0.0045f,-0.0123f,-0.9401f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0123f,-0.9401f,0.3407f,0.0045f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3968f,0.8570f,0.1038f],left_rotation:[-0.0590f,0.1785f,-0.9423f,-0.2767f]}}
particle minecraft:cloud 45.18 66.63 -44.53 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke 45.18 66.43 -44.53 -0.044 0.02 -0.067 1 0 force
particle minecraft:cloud 43.79 66.63 -43.60 0.35 0.18 0.35 0.02 2 force
scoreboard players set #gx driftmountains 36716
scoreboard players set #gdx driftmountains 1102
scoreboard players set #gy driftmountains 66392
scoreboard players set #gdy driftmountains -13
scoreboard players set #gz driftmountains -46284
scoreboard players set #gdz driftmountains 764
scoreboard players set #gr driftmountains -5023
scoreboard players set #gdr driftmountains 256
scoreboard players set #gp driftmountains 57
scoreboard players set #gdp driftmountains -1
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0000f,-0.0029f,1.0000f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.9912f,0.0575f,-0.0425f,0.1112f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.0544f,0.1162f,0.9906f,0.0464f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.3407f,0.0045f,-0.0123f,-0.9401f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0123f,-0.9401f,0.3407f,0.0045f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3839f,0.8273f,0.2323f],left_rotation:[0.1607f,0.0772f,-0.4190f,0.8903f]}}
scoreboard players set #gx driftmountains 27670
scoreboard players set #gdx driftmountains 1108
scoreboard players set #gy driftmountains 66519
scoreboard players set #gdy driftmountains -15
scoreboard players set #gz driftmountains -54079
scoreboard players set #gdz driftmountains 694
scoreboard players set #gr driftmountains -5735
scoreboard players set #gdr driftmountains 345
scoreboard players set #gp driftmountains 65
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[-0.0020f,-0.0000f,-0.0014f,1.0000f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.8551f,0.0622f,0.0017f,-0.5148f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[-0.0558f,-0.5178f,0.8533f,0.0274f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.3407f,0.0045f,-0.0123f,-0.9401f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0123f,-0.9401f,0.3407f,0.0045f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3563f,0.8562f,0.1035f],left_rotation:[0.1802f,-0.0622f,0.2982f,0.9352f]}}
