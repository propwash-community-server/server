scoreboard players set #gx driftmountains -1352
scoreboard players set #gdx driftmountains -976
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 62907
scoreboard players set #gdz driftmountains -235
scoreboard players set #gr driftmountains 15579
scoreboard players set #gdr driftmountains 300
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0001f,-0.0223f,0.9997f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.3870f,-0.3315f,-0.2168f,-0.8327f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.1305f,-0.8145f,0.4239f,0.3740f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.3067f,0.0040f,0.0125f,0.9517f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0125f,0.9517f,0.3067f,0.0040f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3657f,0.8234f,0.0907f],left_rotation:[-0.1583f,-0.0876f,0.4976f,-0.8482f]}}
particle minecraft:cloud -1.60 71.32 64.40 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -1.60 71.12 64.40 0.025 0.02 0.055 1 0 force
particle minecraft:cloud -0.07 71.32 63.71 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains 6250
scoreboard players set #gdx driftmountains -996
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 60890
scoreboard players set #gdz driftmountains 151
scoreboard players set #gr driftmountains 14092
scoreboard players set #gdr driftmountains 235
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[0.0025f,0.0001f,-0.0223f,0.9997f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.8459f,-0.0867f,-0.4436f,-0.2831f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.4163f,-0.2381f,0.8597f,0.1761f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.3067f,0.0040f,0.0125f,0.9517f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0125f,0.9517f,0.3067f,0.0040f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.4060f,0.8474f,0.2402f],left_rotation:[-0.0781f,-0.1681f,0.8731f,-0.4509f]}}
particle minecraft:cloud 6.45 71.32 62.49 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 6.45 71.12 62.49 0.039 0.02 0.048 1 0 force
particle minecraft:cloud 7.77 71.32 61.41 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains 12751
scoreboard players set #gdx driftmountains -919
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 60657
scoreboard players set #gdz driftmountains 452
scoreboard players set #gr driftmountains 12354
scoreboard players set #gdr driftmountains 343
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[-0.0005f,-0.0000f,-0.0223f,0.9998f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.4824f,0.4091f,-0.1935f,0.7500f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.2734f,0.7744f,0.4421f,-0.3607f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.3067f,0.0040f,0.0125f,0.9517f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0125f,0.9517f,0.3067f,0.0040f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3921f,0.8259f,0.0917f],left_rotation:[-0.0792f,-0.1614f,0.8767f,-0.4461f]}}
particle minecraft:cloud 13.34 71.32 62.05 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 13.34 71.12 62.05 0.051 0.02 0.034 1 0 force
particle minecraft:cloud 14.26 71.32 60.66 0.35 0.18 0.35 0.02 3 force
