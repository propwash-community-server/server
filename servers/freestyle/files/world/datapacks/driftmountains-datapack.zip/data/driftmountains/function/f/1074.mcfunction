scoreboard players set #gx driftmountains -26377
scoreboard players set #gdx driftmountains -1122
scoreboard players set #gy driftmountains 70970
scoreboard players set #gdy driftmountains -26
scoreboard players set #gz driftmountains 55503
scoreboard players set #gdz driftmountains -360
scoreboard players set #gr driftmountains 15465
scoreboard players set #gdr driftmountains 22
scoreboard players set #gp driftmountains 80
scoreboard players set #gdp driftmountains 10
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.3863f,-0.3341f,-0.2180f,-0.8317f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.1318f,-0.8133f,0.4235f,0.3765f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.2504f,0.0033f,0.0127f,0.9681f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0127f,0.9681f,0.2504f,0.0033f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3670f,0.8229f,0.0905f],left_rotation:[-0.1555f,-0.0920f,0.5207f,-0.8343f]}}
particle minecraft:cloud -26.59 71.29 57.00 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -26.59 71.09 57.00 0.030 0.02 0.064 1 0 force
particle minecraft:cloud -25.08 71.29 56.28 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -16986
scoreboard players set #gdx driftmountains -1006
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 58305
scoreboard players set #gdz driftmountains -278
scoreboard players set #gr driftmountains 15092
scoreboard players set #gdr driftmountains 14
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.8758f,-0.0660f,-0.3813f,-0.2886f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.3530f,-0.2502f,0.8875f,0.1584f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.2504f,0.0033f,0.0127f,0.9681f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0127f,0.9681f,0.2504f,0.0033f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3838f,0.8273f,0.2323f],left_rotation:[-0.1609f,-0.0769f,0.4172f,-0.8912f]}}
particle minecraft:cloud -17.07 71.32 59.91 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -17.07 71.12 59.91 0.032 0.02 0.058 1 0 force
particle minecraft:cloud -15.57 71.32 59.08 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -12256
scoreboard players set #gdx driftmountains -1046
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 59753
scoreboard players set #gdz driftmountains -284
scoreboard players set #gr driftmountains 15143
scoreboard players set #gdr driftmountains -18
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.4940f,0.3594f,-0.1617f,0.7750f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.2440f,0.7963f,0.4590f,-0.3095f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.2504f,0.0033f,0.0127f,0.9681f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0127f,0.9681f,0.2504f,0.0033f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3649f,0.8239f,0.0908f],left_rotation:[-0.1604f,-0.0843f,0.4802f,-0.8582f]}}
particle minecraft:cloud -12.39 71.32 61.26 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -12.39 71.12 61.26 0.032 0.02 0.059 1 0 force
particle minecraft:cloud -10.92 71.32 60.46 0.35 0.18 0.35 0.02 3 force
