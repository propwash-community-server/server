scoreboard players set #gx driftmountains -61668
scoreboard players set #gdx driftmountains -1086
scoreboard players set #gy driftmountains 70514
scoreboard players set #gdy driftmountains -7
scoreboard players set #gz driftmountains 40520
scoreboard players set #gdz driftmountains -833
scoreboard players set #gr driftmountains 17578
scoreboard players set #gdr driftmountains 159
scoreboard players set #gp driftmountains 12
scoreboard players set #gdp driftmountains 11
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[0.0049f,0.0001f,-0.0223f,0.9997f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.8345f,0.2147f,-0.3270f,0.3881f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.3696f,0.4246f,0.8165f,-0.1282f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.9838f,0.0129f,-0.0023f,-0.1788f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0023f,-0.1788f,0.9838f,0.0129f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3636f,0.8246f,0.0911f],left_rotation:[-0.1631f,-0.0794f,0.4547f,-0.8719f]}}
particle minecraft:cloud -62.41 70.83 41.84 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -62.41 70.63 41.84 0.006 0.02 0.082 1 0 force
particle minecraft:cloud -60.74 70.83 41.71 0.35 0.18 0.35 0.02 3 force
playsound driftgen:grain.kaze.021 neutral @a -69.82 70.88 33.00 12 1
scoreboard players set #gx driftmountains -52008
scoreboard players set #gdx driftmountains -1242
scoreboard players set #gy driftmountains 70481
scoreboard players set #gdy driftmountains 7
scoreboard players set #gz driftmountains 45772
scoreboard players set #gdz driftmountains -631
scoreboard players set #gr driftmountains 16133
scoreboard players set #gdr driftmountains 169
scoreboard players set #gp driftmountains -20
scoreboard players set #gdp driftmountains -1
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.2898f,0.3649f,-0.0606f,0.8827f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.1537f,0.8940f,0.2531f,-0.3364f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.9838f,0.0129f,-0.0023f,-0.1788f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0023f,-0.1788f,0.9838f,0.0129f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3753f,0.8278f,0.2325f],left_rotation:[-0.1722f,-0.0462f,0.2616f,-0.9486f]}}
particle minecraft:cloud -52.38 70.80 47.34 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -52.38 70.60 47.34 0.027 0.02 0.080 1 0 force
particle minecraft:cloud -50.76 70.80 46.79 0.35 0.18 0.35 0.02 3 force
playsound driftgen:grain.onyx.022 neutral @a -61.57 71.01 39.96 12 1
scoreboard players set #gx driftmountains -47345
scoreboard players set #gdx driftmountains -1256
scoreboard players set #gy driftmountains 70468
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 48513
scoreboard players set #gdz driftmountains -553
scoreboard players set #gr driftmountains 15706
scoreboard players set #gdr driftmountains 91
scoreboard players set #gp driftmountains 4
scoreboard players set #gdp driftmountains -9
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.7864f,-0.1454f,-0.3338f,-0.4991f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.2832f,-0.4667f,0.8060f,0.2288f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.9838f,0.0129f,-0.0023f,-0.1788f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0023f,-0.1788f,0.9838f,0.0129f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3549f,0.8335f,0.0946f],left_rotation:[-0.1817f,-0.0324f,0.2071f,-0.9607f]}}
particle minecraft:cloud -47.62 70.79 50.00 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -47.62 70.59 50.00 0.032 0.02 0.076 1 0 force
particle minecraft:cloud -46.09 70.79 49.35 0.35 0.18 0.35 0.02 3 force
playsound driftgen:grain.kaze.020 neutral @a -57.36 71.01 43.33 12 1
