scoreboard players set #gx driftmountains -29761
scoreboard players set #gdx driftmountains -1140
scoreboard players set #gy driftmountains 70882
scoreboard players set #gdy driftmountains -36
scoreboard players set #gz driftmountains 54409
scoreboard players set #gdz driftmountains -374
scoreboard players set #gr driftmountains 15544
scoreboard players set #gdr driftmountains 8
scoreboard players set #gp driftmountains 113
scoreboard players set #gdp driftmountains 8
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.3147f,0.3930f,-0.0830f,0.8600f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.1739f,0.8735f,0.2751f,-0.3621f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.8578f,0.0112f,0.0067f,0.5138f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0067f,0.5138f,0.8578f,0.0112f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3682f,0.8224f,0.0903f],left_rotation:[-0.1526f,-0.0964f,0.5436f,-0.8196f]}}
particle minecraft:cloud -30.00 71.20 55.90 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -30.00 71.00 55.90 0.030 0.02 0.065 1 0 force
particle minecraft:cloud -28.48 71.20 55.21 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -20126
scoreboard players set #gdx driftmountains -1092
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 57429
scoreboard players set #gdz driftmountains -311
scoreboard players set #gr driftmountains 15141
scoreboard players set #gdr driftmountains 25
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.4153f,-0.3157f,-0.2227f,-0.8236f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.1373f,-0.8047f,0.4508f,0.3611f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.8578f,0.0112f,0.0067f,0.5138f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0067f,0.5138f,0.8578f,0.0112f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3836f,0.8273f,0.2323f],left_rotation:[-0.1614f,-0.0759f,0.4122f,-0.8935f]}}
particle minecraft:cloud -20.22 71.32 59.04 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -20.22 71.12 59.04 0.032 0.02 0.059 1 0 force
particle minecraft:cloud -18.72 71.32 58.22 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -15492
scoreboard players set #gdx driftmountains -1100
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 58871
scoreboard players set #gdz driftmountains -302
scoreboard players set #gr driftmountains 15125
scoreboard players set #gdr driftmountains 6
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.8983f,0.1393f,-0.3661f,0.1991f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.3890f,0.2386f,0.8886f,-0.0457f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.8578f,0.0112f,0.0067f,0.5138f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0067f,0.5138f,0.8578f,0.0112f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3638f,0.8244f,0.0911f],left_rotation:[-0.1626f,-0.0803f,0.4593f,-0.8695f]}}
particle minecraft:cloud -15.62 71.32 60.38 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -15.62 71.12 60.38 0.033 0.02 0.059 1 0 force
particle minecraft:cloud -14.15 71.32 59.57 0.35 0.18 0.35 0.02 3 force
