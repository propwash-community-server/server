scoreboard players set #gx driftmountains -40994
scoreboard players set #gdx driftmountains 583
scoreboard players set #gy driftmountains 67549
scoreboard players set #gdy driftmountains -16
scoreboard players set #gz driftmountains -91232
scoreboard players set #gdz driftmountains -154
scoreboard players set #gr driftmountains -6987
scoreboard players set #gdr driftmountains 402
scoreboard players set #gp driftmountains 117
scoreboard players set #gdp driftmountains 7
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[0.0014f,0.0000f,-0.0223f,0.9997f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.5749f,0.1923f,-0.0736f,0.7919f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.1572f,0.8040f,0.5579f,-0.1329f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.1650f,0.0022f,0.0129f,0.9862f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0129f,0.9862f,0.1650f,0.0022f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3977f,0.8556f,0.1033f],left_rotation:[-0.0526f,0.1800f,-0.9517f,-0.2428f]}}
particle minecraft:cloud -41.89 67.87 -92.45 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -41.89 67.67 -92.45 -0.034 0.02 -0.013 1 0 force
particle minecraft:cloud -42.46 67.87 -90.88 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -45554
scoreboard players set #gdx driftmountains 483
scoreboard players set #gy driftmountains 67657
scoreboard players set #gdy driftmountains -11
scoreboard players set #gz driftmountains -89072
scoreboard players set #gdz driftmountains -359
scoreboard players set #gr driftmountains -9144
scoreboard players set #gdr driftmountains 238
scoreboard players set #gp driftmountains 84
scoreboard players set #gdp driftmountains 2
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[0.0061f,0.0001f,-0.0221f,0.9997f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.5370f,0.2296f,-0.0880f,0.8070f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.1733f,0.8207f,0.5158f,-0.1744f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.1650f,0.0022f,0.0129f,0.9862f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0129f,0.9862f,0.1650f,0.0022f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3687f,0.8713f,0.2496f],left_rotation:[-0.1106f,0.1570f,-0.7896f,-0.5828f]}}
particle minecraft:cloud -46.94 67.98 -89.89 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -46.94 67.78 -89.89 -0.036 0.02 0.001 1 0 force
particle minecraft:cloud -46.90 67.98 -88.18 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -48941
scoreboard players set #gdx driftmountains 519
scoreboard players set #gy driftmountains 67747
scoreboard players set #gdy driftmountains -14
scoreboard players set #gz driftmountains -85018
scoreboard players set #gdz driftmountains -677
scoreboard players set #gr driftmountains -11115
scoreboard players set #gdr driftmountains 154
scoreboard players set #gp driftmountains 78
scoreboard players set #gdp driftmountains 2
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0001f,-0.0195f,0.9998f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.1830f,0.2452f,0.0078f,0.9520f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.0923f,0.9564f,0.1582f,-0.2273f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.1650f,0.0022f,0.0129f,0.9862f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0129f,0.9862f,0.1650f,0.0022f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3833f,0.8657f,0.1073f],left_rotation:[-0.1153f,0.1527f,-0.7937f,-0.5773f]}}
particle minecraft:cloud -50.42 68.07 -85.34 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -50.42 67.87 -85.34 -0.043 0.02 0.017 1 0 force
particle minecraft:cloud -49.81 68.07 -83.78 0.35 0.18 0.35 0.02 3 force
