scoreboard players set #gx driftmountains -55707
scoreboard players set #gdx driftmountains -126
scoreboard players set #gy driftmountains 68231
scoreboard players set #gdy driftmountains -13
scoreboard players set #gz driftmountains -62851
scoreboard players set #gdz driftmountains -760
scoreboard players set #gr driftmountains -17715
scoreboard players set #gdr driftmountains 437
scoreboard players set #gp driftmountains 93
scoreboard players set #gdp driftmountains -2
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[0.0061f,0.0000f,-0.0076f,1.0000f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.9552f,0.0238f,-0.1076f,-0.2748f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.0793f,-0.2650f,0.9579f,0.0765f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.4750f,0.0062f,-0.0115f,-0.8799f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0115f,-0.8799f,0.4750f,0.0062f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3825f,0.8216f,0.0900f],left_rotation:[0.1143f,0.1380f,-0.7585f,0.6265f]}}
particle minecraft:cloud -56.60 68.55 -61.63 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -56.60 68.35 -61.63 -0.002 0.02 0.047 1 0 force
particle minecraft:cloud -54.94 68.55 -61.55 0.35 0.18 0.35 0.02 2 force
scoreboard players set #gx driftmountains -54243
scoreboard players set #gdx driftmountains -100
scoreboard players set #gy driftmountains 68341
scoreboard players set #gdy driftmountains -13
scoreboard players set #gz driftmountains -56795
scoreboard players set #gdz driftmountains -696
scoreboard players set #gr driftmountains 15007
scoreboard players set #gdr driftmountains 286
scoreboard players set #gp driftmountains 102
scoreboard players set #gdp driftmountains -1
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[-0.0039f,0.0001f,0.0134f,0.9999f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.6524f,-0.0922f,0.1526f,0.7366f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[-0.0760f,0.7246f,0.6657f,0.1613f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.4750f,0.0062f,-0.0115f,-0.8799f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0115f,-0.8799f,0.4750f,0.0062f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3982f,0.8680f,0.2483f],left_rotation:[0.0062f,-0.1916f,0.9815f,0.0068f]}}
particle minecraft:cloud -54.30 68.66 -55.19 0.35 0.18 0.35 0.02 2 force
particle minecraft:cloud -52.82 68.66 -56.04 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -52.82 68.46 -56.04 0.021 0.02 0.036 1 0 force
scoreboard players set #gx driftmountains -54144
scoreboard players set #gdx driftmountains 146
scoreboard players set #gy driftmountains 68497
scoreboard players set #gdy driftmountains -27
scoreboard players set #gz driftmountains -51094
scoreboard players set #gdz driftmountains -681
scoreboard players set #gr driftmountains 16130
scoreboard players set #gdr driftmountains -171
scoreboard players set #gp driftmountains 182
scoreboard players set #gdp driftmountains 4
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[0.0061f,-0.0001f,0.0191f,0.9998f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.0852f,-0.2148f,0.0727f,0.9702f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.0288f,0.9679f,0.1082f,0.2250f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.4750f,0.0062f,-0.0115f,-0.8799f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0115f,-0.8799f,0.4750f,0.0062f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3925f,0.8263f,0.0918f],left_rotation:[-0.0773f,-0.1623f,0.8816f,-0.4364f]}}
particle minecraft:cloud -54.53 68.82 -49.63 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud -52.95 68.82 -50.17 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -52.95 68.62 -50.17 0.014 0.02 0.040 1 0 force
