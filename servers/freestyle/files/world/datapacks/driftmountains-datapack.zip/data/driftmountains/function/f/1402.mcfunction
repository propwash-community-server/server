scoreboard players set #gx driftmountains 18341
scoreboard players set #gdx driftmountains 986
scoreboard players set #gy driftmountains 66635
scoreboard players set #gdy driftmountains -12
scoreboard players set #gz driftmountains -59121
scoreboard players set #gdz driftmountains 622
scoreboard players set #gr driftmountains -5986
scoreboard players set #gdr driftmountains 31
scoreboard players set #gp driftmountains 61
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,0.0000f,0.0013f,1.0000f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.7424f,0.0272f,0.0480f,0.6677f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.0219f,0.6663f,0.7437f,0.0507f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.9996f,0.0131f,0.0003f,0.0248f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0003f,0.0248f,0.9996f,0.0131f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3533f,0.8502f,0.1012f],left_rotation:[0.1857f,-0.0363f,0.1588f,0.9689f]}}
scoreboard players set #gx driftmountains 11251
scoreboard players set #gdx driftmountains 921
scoreboard players set #gy driftmountains 66725
scoreboard players set #gdy driftmountains -12
scoreboard players set #gz driftmountains -63832
scoreboard players set #gdz driftmountains 620
scoreboard players set #gr driftmountains -5763
scoreboard players set #gdr driftmountains -23
scoreboard players set #gp driftmountains 61
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[-0.0039f,0.0000f,0.0010f,1.0000f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.1460f,-0.0071f,0.0540f,0.9878f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.0496f,0.9876f,0.1476f,0.0225f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.9996f,0.0131f,0.0003f,0.0248f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0003f,0.0248f,0.9996f,0.0131f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3591f,0.8388f,0.2369f],left_rotation:[0.1789f,-0.0314f,0.1356f,0.9740f]}}
scoreboard players set #gx driftmountains 2317
scoreboard players set #gdx driftmountains 830
scoreboard players set #gy driftmountains 66840
scoreboard players set #gdy driftmountains -11
scoreboard players set #gz driftmountains -69889
scoreboard players set #gdz driftmountains 550
scoreboard players set #gr driftmountains -5162
scoreboard players set #gdr driftmountains -27
scoreboard players set #gp driftmountains 61
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0000f,-0.0030f,1.0000f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.7210f,0.0671f,0.0056f,0.6896f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.0668f,0.6928f,0.7180f,0.0083f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.9996f,0.0131f,0.0003f,0.0248f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0003f,0.0248f,0.9996f,0.0131f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3599f,0.8273f,0.0922f],left_rotation:[0.1713f,0.0628f,-0.3677f,0.9118f]}}
