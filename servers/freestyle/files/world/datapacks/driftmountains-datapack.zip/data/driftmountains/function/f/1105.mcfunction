scoreboard players set #gx driftmountains -62754
scoreboard players set #gdx driftmountains -1057
scoreboard players set #gy driftmountains 70507
scoreboard players set #gdy driftmountains -11
scoreboard players set #gz driftmountains 39686
scoreboard players set #gdz driftmountains -871
scoreboard players set #gr driftmountains 17738
scoreboard players set #gdr driftmountains 144
scoreboard players set #gp driftmountains 24
scoreboard players set #gdp driftmountains 11
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0001f,-0.0223f,0.9997f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.5922f,-0.2571f,-0.2894f,-0.7067f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.2167f,-0.6802f,0.6225f,0.3207f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.0844f,0.0011f,-0.0130f,-0.9963f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0130f,-0.9963f,0.0844f,0.0011f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3620f,0.8256f,0.0915f],left_rotation:[-0.1668f,-0.0725f,0.4187f,-0.8897f]}}
particle minecraft:cloud -63.53 70.83 40.98 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -63.53 70.63 40.98 0.004 0.02 0.082 1 0 force
particle minecraft:cloud -61.86 70.83 40.91 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -53250
scoreboard players set #gdx driftmountains -1194
scoreboard players set #gy driftmountains 70488
scoreboard players set #gdy driftmountains 7
scoreboard players set #gz driftmountains 45141
scoreboard players set #gdz driftmountains -633
scoreboard players set #gr driftmountains 16302
scoreboard players set #gdr driftmountains 168
scoreboard players set #gp driftmountains -21
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.9260f,0.0357f,-0.3724f,-0.0517f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.3690f,-0.0128f,0.9273f,0.0615f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.0844f,0.0011f,-0.0130f,-0.9963f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0130f,-0.9963f,0.0844f,0.0011f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3774f,0.8274f,0.2324f],left_rotation:[-0.1699f,-0.0539f,0.3007f,-0.9369f]}}
particle minecraft:cloud -53.67 70.81 46.70 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -53.67 70.61 46.70 0.024 0.02 0.080 1 0 force
particle minecraft:cloud -52.03 70.81 46.20 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -48602
scoreboard players set #gdx driftmountains -1303
scoreboard players set #gy driftmountains 70468
scoreboard players set #gdy driftmountains 3
scoreboard players set #gz driftmountains 47960
scoreboard players set #gdz driftmountains -596
scoreboard players set #gr driftmountains 15797
scoreboard players set #gdr driftmountains 132
scoreboard players set #gp driftmountains -5
scoreboard players set #gdp driftmountains -7
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.2785f,0.3600f,-0.0540f,0.8888f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.1477f,0.8993f,0.2422f,-0.3327f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.0844f,0.0011f,-0.0130f,-0.9963f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0130f,-0.9963f,0.0844f,0.0011f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3549f,0.8336f,0.0946f],left_rotation:[-0.1817f,-0.0323f,0.2067f,-0.9608f]}}
particle minecraft:cloud -48.90 70.79 49.44 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -48.90 70.59 49.44 0.031 0.02 0.078 1 0 force
particle minecraft:cloud -47.36 70.79 48.81 0.35 0.18 0.35 0.02 3 force
