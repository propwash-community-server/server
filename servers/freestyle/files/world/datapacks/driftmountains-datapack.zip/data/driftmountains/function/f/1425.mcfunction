scoreboard players set #gx driftmountains 42920
scoreboard players set #gdx driftmountains 1127
scoreboard players set #gy driftmountains 66332
scoreboard players set #gdy driftmountains -13
scoreboard players set #gz driftmountains -44441
scoreboard players set #gdz driftmountains 710
scoreboard players set #gr driftmountains -3765
scoreboard players set #gdr driftmountains 231
scoreboard players set #gp driftmountains 51
scoreboard players set #gdp driftmountains -1
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0000f,-0.0124f,0.9999f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.4371f,-0.1308f,-0.1242f,-0.8811f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.0323f,-0.8729f,0.4533f,0.1774f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.1798f,0.0024f,0.0129f,0.9836f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0129f,0.9836f,0.1798f,0.0024f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.4013f,0.8450f,0.0991f],left_rotation:[-0.0072f,0.1843f,-0.9828f,-0.0035f]}}
particle minecraft:cloud 42.81 66.65 -45.95 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke 42.81 66.45 -45.95 -0.049 0.02 -0.063 1 0 force
particle minecraft:cloud 41.49 66.65 -44.93 0.35 0.18 0.35 0.02 2 force
scoreboard players set #gx driftmountains 34559
scoreboard players set #gdx driftmountains 1134
scoreboard players set #gy driftmountains 66419
scoreboard players set #gdy driftmountains -14
scoreboard players set #gz driftmountains -47807
scoreboard players set #gdz driftmountains 803
scoreboard players set #gr driftmountains -5351
scoreboard players set #gdr driftmountains 141
scoreboard players set #gp driftmountains 59
scoreboard players set #gdp driftmountains -1
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0000f,-0.0007f,1.0000f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.9159f,0.0439f,-0.0303f,-0.3979f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[-0.0114f,-0.3970f,0.9163f,0.0521f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.1798f,0.0024f,0.0129f,0.9836f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0129f,0.9836f,0.1798f,0.0024f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3671f,0.8310f,0.2338f],left_rotation:[0.1788f,0.0126f,-0.0898f,0.9797f]}}
scoreboard players set #gx driftmountains 25488
scoreboard players set #gdx driftmountains 1121
scoreboard players set #gy driftmountains 66547
scoreboard players set #gdy driftmountains -14
scoreboard players set #gz driftmountains -55208
scoreboard players set #gdz driftmountains 547
scoreboard players set #gr driftmountains -6319
scoreboard players set #gdr driftmountains 225
scoreboard players set #gp driftmountains 63
scoreboard players set #gdp driftmountains 1
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[0.0061f,0.0000f,-0.0008f,1.0000f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.4819f,0.0254f,-0.0458f,-0.8747f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[-0.0459f,-0.8747f,0.4819f,0.0251f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.1798f,0.0024f,0.0129f,0.9836f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0129f,0.9836f,0.1798f,0.0024f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3523f,0.8430f,0.0984f],left_rotation:[0.1872f,-0.0073f,0.0037f,0.9822f]}}
