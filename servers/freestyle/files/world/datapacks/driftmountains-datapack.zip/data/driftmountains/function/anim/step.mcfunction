execute store result storage driftmountains:anim t int 1 run scoreboard players get #t driftmountains
function driftmountains:anim/play with storage driftmountains:anim
scoreboard players add #t driftmountains 1
execute if score #t driftmountains >= #n driftmountains run scoreboard players set #t driftmountains 0
execute if score #t driftmountains matches 0 run function driftmountains:glide/sync
