scoreboard players set #gx driftmountains -26154
scoreboard players set #gdx driftmountains 681
scoreboard players set #gy driftmountains 67235
scoreboard players set #gdy driftmountains -11
scoreboard players set #gz driftmountains -87750
scoreboard players set #gdz driftmountains 352
scoreboard players set #gr driftmountains -3396
scoreboard players set #gdr driftmountains 34
scoreboard players set #gp driftmountains 71
scoreboard players set #gdp driftmountains -1
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0001f,-0.0177f,0.9998f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.7540f,-0.1070f,-0.2178f,-0.6104f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.1549f,-0.5909f,0.7694f,0.1869f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.9317f,0.0122f,-0.0048f,-0.3629f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0048f,-0.3629f,0.9317f,0.0122f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3845f,0.8654f,0.1071f],left_rotation:[-0.1116f,0.1552f,-0.8082f,-0.5569f]}}
particle minecraft:cloud -26.17 67.55 -89.26 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -26.17 67.35 -89.26 -0.026 0.02 -0.038 1 0 force
particle minecraft:cloud -27.55 67.55 -88.33 0.35 0.18 0.35 0.02 2 force
scoreboard players set #gx driftmountains -32142
scoreboard players set #gdx driftmountains 608
scoreboard players set #gy driftmountains 67335
scoreboard players set #gdy driftmountains -11
scoreboard players set #gz driftmountains -90406
scoreboard players set #gdz driftmountains 260
scoreboard players set #gr driftmountains -3584
scoreboard players set #gdr driftmountains 25
scoreboard players set #gp driftmountains 86
scoreboard players set #gdp driftmountains -5
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0001f,-0.0191f,0.9998f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.0985f,-0.2129f,-0.0756f,-0.9692f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[-0.0259f,-0.9666f,0.1214f,0.2244f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.9317f,0.0122f,-0.0048f,-0.3629f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0048f,-0.3629f,0.9317f,0.0122f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3778f,0.8741f,0.2507f],left_rotation:[-0.0815f,0.1751f,-0.8862f,-0.4211f]}}
particle minecraft:cloud -32.25 67.65 -92.01 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -32.25 67.45 -92.01 -0.024 0.02 -0.033 1 0 force
particle minecraft:cloud -33.63 67.65 -91.01 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -38134
scoreboard players set #gdx driftmountains 563
scoreboard players set #gy driftmountains 67465
scoreboard players set #gdy driftmountains -15
scoreboard players set #gz driftmountains -92403
scoreboard players set #gdz driftmountains 25
scoreboard players set #gr driftmountains -5385
scoreboard players set #gdr driftmountains 365
scoreboard players set #gp driftmountains 127
scoreboard players set #gdp driftmountains -4
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0001f,-0.0217f,0.9998f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.9365f,0.1008f,-0.1374f,0.3065f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.1704f,0.3226f,0.9311f,-0.0029f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.9317f,0.0122f,-0.0048f,-0.3629f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0048f,-0.3629f,0.9317f,0.0122f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.4010f,0.8406f,0.0974f],left_rotation:[0.0108f,0.1829f,-0.9788f,0.0909f]}}
particle minecraft:cloud -38.66 67.79 -93.82 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -38.66 67.59 -93.82 -0.027 0.02 -0.020 1 0 force
particle minecraft:cloud -39.64 67.79 -92.47 0.35 0.18 0.35 0.02 3 force
