scoreboard players set #gx driftmountains -51391
scoreboard players set #gdx driftmountains 438
scoreboard players set #gy driftmountains 67800
scoreboard players set #gdy driftmountains -12
scoreboard players set #gz driftmountains -82834
scoreboard players set #gdz driftmountains -578
scoreboard players set #gr driftmountains -11118
scoreboard players set #gdr driftmountains 164
scoreboard players set #gp driftmountains 76
scoreboard players set #gdp driftmountains 3
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0001f,-0.0198f,0.9998f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.6869f,-0.1281f,-0.2046f,-0.6855f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.1337f,-0.6678f,0.7041f,0.2010f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.4564f,0.0060f,0.0116f,0.8897f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0116f,0.8897f,0.4564f,0.0060f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3850f,0.8652f,0.1071f],left_rotation:[-0.1098f,0.1564f,-0.8148f,-0.5472f]}}
particle minecraft:cloud -52.87 68.12 -83.16 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -52.87 67.92 -83.16 -0.040 0.02 0.016 1 0 force
particle minecraft:cloud -52.26 68.12 -81.60 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -53667
scoreboard players set #gdx driftmountains 198
scoreboard players set #gy driftmountains 67882
scoreboard players set #gdy driftmountains -8
scoreboard players set #gz driftmountains -78552
scoreboard players set #gdz driftmountains -421
scoreboard players set #gr driftmountains -12194
scoreboard players set #gdr driftmountains 57
scoreboard players set #gp driftmountains 86
scoreboard players set #gdp driftmountains -3
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0001f,-0.0203f,0.9998f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.5133f,-0.1839f,-0.1791f,-0.8189f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.0941f,-0.8046f,0.5355f,0.2389f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.4564f,0.0060f,0.0116f,0.8897f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0116f,0.8897f,0.4564f,0.0060f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3643f,0.8685f,0.2485f],left_rotation:[-0.1248f,0.1447f,-0.7244f,-0.6624f]}}
particle minecraft:cloud -55.28 68.20 -78.56 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -55.28 68.00 -78.56 -0.034 0.02 0.021 1 0 force
particle minecraft:cloud -54.37 68.20 -77.10 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -54984
scoreboard players set #gdx driftmountains 213
scoreboard players set #gy driftmountains 68016
scoreboard players set #gdy driftmountains -24
scoreboard players set #gz driftmountains -72967
scoreboard players set #gdz driftmountains -612
scoreboard players set #gr driftmountains -12949
scoreboard players set #gdr driftmountains 106
scoreboard players set #gp driftmountains 188
scoreboard players set #gdp driftmountains -32
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.9406f,-0.0017f,-0.1925f,-0.2796f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.1641f,-0.2610f,0.9460f,0.1005f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.4564f,0.0060f,0.0116f,0.8897f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0116f,0.8897f,0.4564f,0.0060f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.4003f,0.8502f,0.1012f],left_rotation:[-0.0290f,0.1836f,-0.9754f,-0.1181f]}}
particle minecraft:cloud -56.49 68.34 -72.81 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -56.49 68.14 -72.81 -0.030 0.02 0.025 1 0 force
particle minecraft:cloud -55.43 68.34 -71.52 0.35 0.18 0.35 0.02 3 force
