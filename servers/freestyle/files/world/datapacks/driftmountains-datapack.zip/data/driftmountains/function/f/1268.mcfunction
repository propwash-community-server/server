scoreboard players set #gx driftmountains -55001
scoreboard players set #gdx driftmountains -148
scoreboard players set #gy driftmountains 68295
scoreboard players set #gdy driftmountains -13
scoreboard players set #gz driftmountains -59069
scoreboard players set #gdz driftmountains -741
scoreboard players set #gr driftmountains 16056
scoreboard players set #gdr driftmountains 435
scoreboard players set #gp driftmountains 100
scoreboard players set #gdp driftmountains -2
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,0.0000f,0.0049f,1.0000f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.7203f,0.0903f,0.0185f,-0.6875f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[-0.0909f,-0.6933f,0.7148f,-0.0150f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.6776f,0.0089f,-0.0096f,-0.7353f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0096f,-0.7353f,0.6776f,0.0089f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3714f,0.8660f,0.1074f],left_rotation:[0.1479f,-0.1228f,0.6283f,0.7538f]}}
scoreboard players set #gx driftmountains -53915
scoreboard players set #gdx driftmountains -23
scoreboard players set #gy driftmountains 68418
scoreboard players set #gdy driftmountains -19
scoreboard players set #gz driftmountains -53295
scoreboard players set #gdz driftmountains -715
scoreboard players set #gr driftmountains 14621
scoreboard players set #gdr driftmountains -267
scoreboard players set #gp driftmountains 135
scoreboard players set #gdp driftmountains -21
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[-0.0020f,0.0000f,0.0207f,0.9998f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.9255f,0.1117f,0.1566f,-0.3262f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[-0.1917f,-0.3444f,0.9189f,-0.0150f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.6776f,0.0089f,-0.0096f,-0.7353f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0096f,-0.7353f,0.6776f,0.0089f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.4025f,0.8631f,0.2464f],left_rotation:[-0.0180f,-0.1894f,0.9737f,-0.1257f]}}
particle minecraft:cloud -53.87 68.74 -51.69 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud -52.44 68.74 -52.64 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -52.44 68.54 -52.64 0.023 0.02 0.034 1 0 force
scoreboard players set #gx driftmountains -54758
scoreboard players set #gdx driftmountains 126
scoreboard players set #gy driftmountains 68591
scoreboard players set #gdy driftmountains -20
scoreboard players set #gz driftmountains -48061
scoreboard players set #gdz driftmountains -650
scoreboard players set #gr driftmountains 15964
scoreboard players set #gdr driftmountains -18
scoreboard players set #gp driftmountains 144
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[0.0025f,-0.0000f,0.0192f,0.9998f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.9599f,0.0766f,0.2566f,-0.0829f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[-0.2667f,-0.1103f,0.9572f,0.0239f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.6776f,0.0089f,-0.0096f,-0.7353f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0096f,-0.7353f,0.6776f,0.0089f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3746f,0.8211f,0.0897f],left_rotation:[-0.1367f,-0.1165f,0.6479f,-0.7402f]}}
particle minecraft:cloud -55.10 68.91 -46.59 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud -53.54 68.91 -47.17 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -53.54 68.71 -47.17 0.016 0.02 0.043 1 0 force
