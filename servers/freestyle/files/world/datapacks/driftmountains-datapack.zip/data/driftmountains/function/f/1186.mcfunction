scoreboard players set #gx driftmountains -87025
scoreboard players set #gdx driftmountains 527
scoreboard players set #gy driftmountains 69526
scoreboard players set #gdy driftmountains -15
scoreboard players set #gz driftmountains -25525
scoreboard players set #gdz driftmountains -272
scoreboard players set #gr driftmountains -7464
scoreboard players set #gdr driftmountains 158
scoreboard players set #gp driftmountains 106
scoreboard players set #gdp driftmountains 5
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.8733f,-0.0673f,-0.2857f,-0.3887f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.2464f,-0.3609f,0.8852f,0.1595f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.8761f,0.0115f,-0.0063f,-0.4820f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0063f,-0.4820f,0.8761f,0.0115f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3618f,0.8618f,0.1057f],left_rotation:[-0.1692f,0.0903f,-0.4504f,-0.8719f]}}
particle minecraft:cloud -88.02 69.85 -26.66 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -88.02 69.65 -26.66 -0.035 0.02 -0.010 1 0 force
particle minecraft:cloud -88.46 69.85 -25.05 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -91972
scoreboard players set #gdx driftmountains 535
scoreboard players set #gy driftmountains 69685
scoreboard players set #gdy driftmountains -19
scoreboard players set #gz driftmountains -22111
scoreboard players set #gdz driftmountains -490
scoreboard players set #gr driftmountains -8837
scoreboard players set #gdr driftmountains 93
scoreboard players set #gp driftmountains 107
scoreboard players set #gdp driftmountains 1
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.7407f,0.2500f,-0.2292f,0.5799f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.2914f,0.6072f,0.7185f,-0.1736f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.8761f,0.0115f,-0.0063f,-0.4820f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0063f,-0.4820f,0.8761f,0.0115f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3623f,0.8348f,0.2353f],left_rotation:[-0.1800f,0.0111f,-0.0313f,-0.9831f]}}
particle minecraft:cloud -93.31 70.01 -23.00 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -93.31 69.81 -23.00 -0.044 0.02 -0.001 1 0 force
particle minecraft:cloud -93.36 70.01 -21.30 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -95259
scoreboard players set #gdx driftmountains 482
scoreboard players set #gy driftmountains 69812
scoreboard players set #gdy driftmountains -19
scoreboard players set #gz driftmountains -18319
scoreboard players set #gdz driftmountains -619
scoreboard players set #gr driftmountains -9415
scoreboard players set #gdr driftmountains 137
scoreboard players set #gp driftmountains 89
scoreboard players set #gdp driftmountains 3
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.0787f,0.3652f,0.0254f,0.9272f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.0720f,0.9297f,0.0408f,-0.3590f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.8761f,0.0115f,-0.0063f,-0.4820f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0063f,-0.4820f,0.8761f,0.0115f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3554f,0.8327f,0.0943f],left_rotation:[-0.1808f,-0.0360f,0.2263f,-0.9564f]}}
particle minecraft:cloud -96.58 70.13 -19.06 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -96.58 69.93 -19.06 -0.047 0.02 0.003 1 0 force
particle minecraft:cloud -96.46 70.13 -17.39 0.35 0.18 0.35 0.02 3 force
