scoreboard players set #gx driftmountains -6239
scoreboard players set #gdx driftmountains -1003
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 61478
scoreboard players set #gdz driftmountains -277
scoreboard players set #gr driftmountains 15652
scoreboard players set #gdr driftmountains -143
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.1520f,-0.4200f,-0.1312f,-0.8850f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.0389f,-0.8761f,0.1970f,0.4383f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.5322f,0.0070f,0.0111f,0.8465f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0111f,0.8465f,0.5322f,0.0070f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3867f,0.8229f,0.0905f],left_rotation:[-0.1001f,-0.1487f,0.8130f,-0.5539f]}}
particle minecraft:cloud -6.50 71.32 62.97 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -6.50 71.12 62.97 0.025 0.02 0.057 1 0 force
particle minecraft:cloud -4.97 71.32 62.30 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains 1391
scoreboard players set #gdx driftmountains -993
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 61224
scoreboard players set #gdz driftmountains -3
scoreboard players set #gr driftmountains 14735
scoreboard players set #gdr driftmountains -232
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.7303f,-0.2143f,-0.4299f,-0.4857f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.3812f,-0.4432f,0.7568f,0.2923f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.5322f,0.0070f,0.0111f,0.8465f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0111f,0.8465f,0.5322f,0.0070f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.4038f,0.8609f,0.2455f],left_rotation:[-0.0279f,-0.1875f,0.9654f,-0.1791f]}}
particle minecraft:cloud 1.41 71.32 62.83 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 1.41 71.12 62.83 0.031 0.02 0.048 1 0 force
particle minecraft:cloud 2.85 71.32 61.91 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains 7846
scoreboard players set #gdx driftmountains -1079
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 62423
scoreboard players set #gdz driftmountains 204
scoreboard players set #gr driftmountains 13961
scoreboard players set #gdr driftmountains 308
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.6571f,0.3511f,-0.2994f,0.5961f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.3637f,0.6308f,0.6239f,-0.2839f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.5322f,0.0070f,0.0111f,0.8465f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0111f,0.8465f,0.5322f,0.0070f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3953f,0.8288f,0.0928f],left_rotation:[-0.0634f,-0.1688f,0.9134f,-0.3648f]}}
particle minecraft:cloud 8.03 71.32 63.92 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 8.03 71.12 63.92 0.043 0.02 0.050 1 0 force
particle minecraft:cloud 9.30 71.32 62.84 0.35 0.18 0.35 0.02 3 force
