scoreboard players set #gx driftmountains -56502
scoreboard players set #gdx driftmountains 119
scoreboard players set #gy driftmountains 68041
scoreboard players set #gdy driftmountains -18
scoreboard players set #gz driftmountains -72256
scoreboard players set #gdz driftmountains -583
scoreboard players set #gr driftmountains -13716
scoreboard players set #gdr driftmountains 497
scoreboard players set #gp driftmountains 143
scoreboard players set #gdp driftmountains 5
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[-0.0038f,-0.0001f,-0.0206f,0.9998f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.2001f,0.1819f,0.0165f,0.9626f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.0846f,0.9662f,0.1821f,-0.1618f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.8687f,0.0114f,-0.0065f,-0.4951f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0065f,-0.4951f,0.8687f,0.0114f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.4012f,0.8460f,0.0995f],left_rotation:[-0.0113f,0.1843f,-0.9824f,-0.0250f]}}
particle minecraft:cloud -57.97 68.36 -71.90 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -57.97 68.16 -71.90 -0.024 0.02 0.026 1 0 force
particle minecraft:cloud -56.75 68.36 -70.76 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -55736
scoreboard players set #gdx driftmountains -77
scoreboard players set #gy driftmountains 68160
scoreboard players set #gdy driftmountains -14
scoreboard players set #gz driftmountains -67234
scoreboard players set #gdz driftmountains -735
scoreboard players set #gr driftmountains -15710
scoreboard players set #gdr driftmountains 273
scoreboard players set #gp driftmountains 92
scoreboard players set #gdp driftmountains 2
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[0.0061f,0.0001f,-0.0179f,0.9998f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.7527f,0.1885f,-0.1460f,0.6137f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.2113f,0.6325f,0.7370f,-0.1104f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.8687f,0.0114f,-0.0065f,-0.4951f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0065f,-0.4951f,0.8687f,0.0114f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3720f,0.8728f,0.2502f],left_rotation:[-0.1001f,0.1645f,-0.8294f,-0.5244f]}}
particle minecraft:cloud -57.05 68.48 -66.31 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -57.05 68.28 -66.31 -0.018 0.02 0.042 1 0 force
particle minecraft:cloud -55.48 68.48 -65.64 0.35 0.18 0.35 0.02 2 force
scoreboard players set #gx driftmountains -54577
scoreboard players set #gdx driftmountains -90
scoreboard players set #gy driftmountains 68277
scoreboard players set #gdy driftmountains -12
scoreboard players set #gz driftmountains -60516
scoreboard players set #gdz driftmountains -726
scoreboard players set #gr driftmountains 17106
scoreboard players set #gdr driftmountains 387
scoreboard players set #gp driftmountains 94
scoreboard players set #gdp driftmountains -1
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,0.0000f,0.0011f,1.0000f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.9970f,0.0534f,0.0182f,-0.0528f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[-0.0239f,-0.0551f,0.9969f,0.0511f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.8687f,0.0114f,-0.0065f,-0.4951f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0065f,-0.4951f,0.8687f,0.0114f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3538f,0.8515f,0.1017f],left_rotation:[0.1849f,-0.0420f,0.1897f,0.9633f]}}
