scoreboard players set #gx driftmountains -96297
scoreboard players set #gdx driftmountains 400
scoreboard players set #gy driftmountains 69856
scoreboard players set #gdy driftmountains -17
scoreboard players set #gz driftmountains -16757
scoreboard players set #gdz driftmountains -648
scoreboard players set #gr driftmountains -10065
scoreboard players set #gdr driftmountains 203
scoreboard players set #gp driftmountains 85
scoreboard players set #gdp driftmountains 3
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.9406f,0.0463f,-0.3354f,-0.0259f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.3346f,0.0092f,0.9409f,0.0523f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.5201f,0.0068f,0.0112f,0.8540f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0112f,0.8540f,0.5201f,0.0068f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3523f,0.8446f,0.0990f],left_rotation:[-0.1873f,0.0135f,-0.0370f,-0.9815f]}}
particle minecraft:cloud -97.69 70.18 -17.34 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -97.69 69.98 -17.34 -0.045 0.02 0.008 1 0 force
particle minecraft:cloud -97.38 70.18 -15.70 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -98146
scoreboard players set #gdx driftmountains 60
scoreboard players set #gy driftmountains 69989
scoreboard players set #gdy driftmountains -12
scoreboard players set #gz driftmountains -9945
scoreboard players set #gdz driftmountains -824
scoreboard players set #gr driftmountains -12741
scoreboard players set #gdr driftmountains 229
scoreboard players set #gp driftmountains 51
scoreboard players set #gdp driftmountains 6
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.8632f,-0.0829f,-0.3606f,-0.3435f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.3264f,-0.3075f,0.8767f,0.1741f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.5201f,0.0068f,0.0112f,0.8540f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0112f,0.8540f,0.5201f,0.0068f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3754f,0.8277f,0.2325f],left_rotation:[-0.1722f,-0.0464f,0.2625f,-0.9483f]}}
particle minecraft:cloud -99.75 70.31 -9.79 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -99.75 70.11 -9.79 -0.039 0.02 0.030 1 0 force
particle minecraft:cloud -98.71 70.31 -8.44 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -98001
scoreboard players set #gdx driftmountains -110
scoreboard players set #gy driftmountains 70030
scoreboard players set #gdy driftmountains -3
scoreboard players set #gz driftmountains -4900
scoreboard players set #gdz driftmountains -847
scoreboard players set #gr driftmountains -13756
scoreboard players set #gdr driftmountains 152
scoreboard players set #gp driftmountains 12
scoreboard players set #gdp driftmountains 5
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.8021f,0.2378f,-0.3040f,0.4557f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.3535f,0.4901f,0.7815f,-0.1548f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.5201f,0.0068f,0.0112f,0.8540f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0112f,0.8540f,0.5201f,0.0068f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3616f,0.8259f,0.0917f],left_rotation:[-0.1677f,-0.0707f,0.4089f,-0.8942f]}}
particle minecraft:cloud -99.47 70.35 -4.53 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -99.47 70.15 -4.53 -0.034 0.02 0.038 1 0 force
particle minecraft:cloud -98.24 70.35 -3.41 0.35 0.18 0.35 0.02 3 force
