scoreboard players set #gx driftmountains -76998
scoreboard players set #gdx driftmountains 629
scoreboard players set #gy driftmountains 69315
scoreboard players set #gdy driftmountains -9
scoreboard players set #gz driftmountains -27883
scoreboard players set #gdz driftmountains -231
scoreboard players set #gr driftmountains -12757
scoreboard players set #gdr driftmountains 75
scoreboard players set #gp driftmountains 78
scoreboard players set #gdp driftmountains -1
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,0.0000f,0.0110f,0.9999f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.9444f,0.0865f,0.0976f,-0.3018f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[-0.1299f,-0.3137f,0.9405f,0.0123f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.7496f,0.0098f,-0.0087f,-0.6618f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0087f,-0.6618f,0.7496f,0.0098f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3901f,0.8629f,0.1062f],left_rotation:[0.0916f,-0.1666f,0.8727f,0.4497f]}}
particle minecraft:cloud -78.51 69.63 -27.78 0.35 0.18 0.35 0.02 2 force
particle minecraft:cloud -77.49 69.63 -26.45 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -77.49 69.43 -26.45 -0.032 0.02 0.024 1 0 force
scoreboard players set #gx driftmountains -83164
scoreboard players set #gdx driftmountains 620
scoreboard players set #gy driftmountains 69419
scoreboard players set #gdy driftmountains -12
scoreboard players set #gz driftmountains -27367
scoreboard players set #gdz driftmountains -112
scoreboard players set #gr driftmountains -8554
scoreboard players set #gdr driftmountains -388
scoreboard players set #gp driftmountains 111
scoreboard players set #gdp driftmountains -4
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0000f,-0.0093f,0.9999f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.6687f,0.1041f,-0.0236f,0.7358f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.1011f,0.7424f,0.6614f,-0.0344f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.7496f,0.0098f,-0.0087f,-0.6618f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0087f,-0.6618f,0.7496f,0.0098f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.4012f,0.8366f,0.2360f],left_rotation:[0.1158f,0.1401f,-0.7349f,0.6534f]}}
particle minecraft:cloud -84.46 69.74 -28.33 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -84.46 69.54 -28.33 -0.037 0.02 -0.003 1 0 force
particle minecraft:cloud -84.59 69.74 -26.62 0.35 0.18 0.35 0.02 2 force
scoreboard players set #gx driftmountains -87175
scoreboard players set #gdx driftmountains 382
scoreboard players set #gy driftmountains 69535
scoreboard players set #gdy driftmountains -11
scoreboard players set #gz driftmountains -25171
scoreboard players set #gdz driftmountains -203
scoreboard players set #gr driftmountains -7174
scoreboard players set #gdr driftmountains 125
scoreboard players set #gp driftmountains 102
scoreboard players set #gdp driftmountains 1
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.2930f,0.3272f,-0.0486f,0.8970f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.1432f,0.9071f,0.2603f,-0.2982f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.7496f,0.0098f,-0.0087f,-0.6618f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0087f,-0.6618f,0.7496f,0.0098f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3527f,0.8480f,0.1003f],left_rotation:[-0.1867f,0.0275f,-0.1118f,-0.9756f]}}
particle minecraft:cloud -88.11 69.86 -26.36 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -88.11 69.66 -26.36 -0.009 0.02 -0.003 1 0 force
particle minecraft:cloud -88.63 69.86 -24.77 0.35 0.18 0.35 0.02 3 force
