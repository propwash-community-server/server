scoreboard players set #gx driftmountains -54511
scoreboard players set #gdx driftmountains 100
scoreboard players set #gy driftmountains 68644
scoreboard players set #gdy driftmountains -20
scoreboard players set #gz driftmountains -46161
scoreboard players set #gdz driftmountains -711
scoreboard players set #gr driftmountains 15698
scoreboard players set #gdr driftmountains -115
scoreboard players set #gp driftmountains 138
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.9699f,0.0518f,0.2376f,0.0084f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[-0.2381f,-0.0165f,0.9698f,0.0498f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.7644f,0.0100f,0.0084f,0.6446f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0084f,0.6446f,0.7644f,0.0100f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3859f,0.8226f,0.0904f],left_rotation:[-0.1031f,-0.1466f,0.8025f,-0.5689f]}}
particle minecraft:cloud -54.79 68.96 -44.67 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud -53.25 68.96 -45.33 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -53.25 68.76 -45.33 0.017 0.02 0.039 1 0 force
scoreboard players set #gx driftmountains -56771
scoreboard players set #gdx driftmountains 281
scoreboard players set #gy driftmountains 68779
scoreboard players set #gdy driftmountains -20
scoreboard players set #gz driftmountains -42091
scoreboard players set #gdz driftmountains -588
scoreboard players set #gr driftmountains 17152
scoreboard players set #gdr driftmountains -204
scoreboard players set #gp driftmountains 143
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.1885f,-0.2128f,0.0968f,0.9538f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.0029f,0.9489f,0.2119f,0.2338f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.7644f,0.0100f,0.0084f,0.6446f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0084f,0.6446f,0.7644f,0.0100f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.4055f,0.8451f,0.2393f],left_rotation:[-0.0861f,-0.1633f,0.8495f,-0.4943f]}}
particle minecraft:cloud -57.42 69.10 -40.61 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud -55.72 69.10 -40.87 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -55.72 68.90 -40.87 0.006 0.02 0.038 1 0 force
scoreboard players set #gx driftmountains -59454
scoreboard players set #gdx driftmountains 376
scoreboard players set #gy driftmountains 68955
scoreboard players set #gdy driftmountains -20
scoreboard players set #gz driftmountains -37078
scoreboard players set #gdz driftmountains -509
scoreboard players set #gr driftmountains -17761
scoreboard players set #gdr driftmountains -50
scoreboard players set #gp driftmountains 152
scoreboard players set #gdp driftmountains -3
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.7626f,0.1910f,0.1562f,-0.5979f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[-0.2199f,-0.6176f,0.7468f,-0.1119f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.7644f,0.0100f,0.0084f,0.6446f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0084f,0.6446f,0.7644f,0.0100f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3843f,0.8221f,0.0901f],left_rotation:[-0.1083f,-0.1427f,0.7827f,-0.5960f]}}
particle minecraft:cloud -60.34 69.28 -35.85 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud -58.67 69.28 -35.78 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -58.67 69.08 -35.78 -0.002 0.02 0.038 1 0 force
