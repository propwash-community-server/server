scoreboard players set #gx driftmountains -53953
scoreboard players set #gdx driftmountains 317
scoreboard players set #gy driftmountains 67881
scoreboard players set #gdy driftmountains -12
scoreboard players set #gz driftmountains -78692
scoreboard players set #gdz driftmountains -595
scoreboard players set #gr driftmountains -12095
scoreboard players set #gdr driftmountains 77
scoreboard players set #gp driftmountains 87
scoreboard players set #gdp driftmountains -4
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0001f,-0.0192f,0.9998f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.9282f,0.1204f,-0.2115f,0.2814f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.2422f,0.3052f,0.9207f,-0.0235f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.6837f,0.0090f,0.0096f,0.7296f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0096f,0.7296f,0.6837f,0.0090f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3842f,0.8655f,0.1072f],left_rotation:[-0.1126f,0.1546f,-0.8045f,-0.5623f]}}
particle minecraft:cloud -55.46 68.20 -78.76 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -55.46 68.00 -78.76 -0.035 0.02 0.021 1 0 force
particle minecraft:cloud -54.60 68.20 -77.33 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -55375
scoreboard players set #gdx driftmountains 246
scoreboard players set #gy driftmountains 67978
scoreboard players set #gdy driftmountains -18
scoreboard players set #gz driftmountains -74249
scoreboard players set #gdz driftmountains -717
scoreboard players set #gr driftmountains -12617
scoreboard players set #gdr driftmountains 107
scoreboard players set #gp driftmountains 116
scoreboard players set #gdp driftmountains -11
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0001f,-0.0218f,0.9998f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.8380f,-0.0727f,-0.2315f,-0.4887f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.1814f,-0.4671f,0.8503f,0.1611f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.6837f,0.0090f,0.0096f,0.7296f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0096f,0.7296f,0.6837f,0.0090f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3701f,0.8720f,0.2499f],left_rotation:[-0.1062f,0.1603f,-0.8072f,-0.5581f]}}
particle minecraft:cloud -56.98 68.30 -74.13 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -56.98 68.10 -74.13 -0.032 0.02 0.023 1 0 force
particle minecraft:cloud -55.97 68.30 -72.75 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -55341
scoreboard players set #gdx driftmountains -28
scoreboard players set #gy driftmountains 68139
scoreboard players set #gdy driftmountains -16
scoreboard players set #gz driftmountains -68580
scoreboard players set #gdz driftmountains -774
scoreboard players set #gr driftmountains -15369
scoreboard players set #gdr driftmountains 289
scoreboard players set #gp driftmountains 98
scoreboard players set #gdp driftmountains 6
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[0.0061f,0.0001f,-0.0177f,0.9998f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.9200f,0.1222f,-0.1870f,0.3219f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.2219f,0.3433f,0.9123f,-0.0262f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.6837f,0.0090f,0.0096f,0.7296f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0096f,0.7296f,0.6837f,0.0090f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3924f,0.8614f,0.1055f],left_rotation:[-0.0820f,0.1709f,-0.8973f,-0.3985f]}}
particle minecraft:cloud -56.65 68.46 -67.82 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -56.65 68.26 -67.82 -0.019 0.02 0.038 1 0 force
particle minecraft:cloud -55.15 68.46 -67.08 0.35 0.18 0.35 0.02 2 force
