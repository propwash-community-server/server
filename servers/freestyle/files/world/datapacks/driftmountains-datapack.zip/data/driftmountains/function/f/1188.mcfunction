scoreboard players set #gx driftmountains -85966
scoreboard players set #gdx driftmountains 534
scoreboard players set #gy driftmountains 69495
scoreboard players set #gdy driftmountains -16
scoreboard players set #gz driftmountains -26027
scoreboard players set #gdz driftmountains -189
scoreboard players set #gr driftmountains -7318
scoreboard players set #gdr driftmountains -9
scoreboard players set #gp driftmountains 123
scoreboard players set #gdp driftmountains 7
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[0.0025f,0.0001f,-0.0223f,0.9997f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.5336f,0.2041f,-0.0693f,0.8178f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.1556f,0.8296f,0.5151f,-0.1491f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.9996f,0.0131f,0.0003f,0.0255f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0003f,0.0255f,0.9996f,0.0131f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3950f,0.8590f,0.1046f],left_rotation:[-0.0690f,0.1756f,-0.9250f,-0.3296f]}}
particle minecraft:cloud -86.93 69.81 -27.19 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -86.93 69.61 -27.19 -0.033 0.02 -0.010 1 0 force
particle minecraft:cloud -87.41 69.81 -25.59 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -90898
scoreboard players set #gdx driftmountains 533
scoreboard players set #gy driftmountains 69647
scoreboard players set #gdy driftmountains -19
scoreboard players set #gz driftmountains -23077
scoreboard players set #gdz driftmountains -451
scoreboard players set #gr driftmountains -8618
scoreboard players set #gdr driftmountains 123
scoreboard players set #gp driftmountains 110
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.0835f,-0.3382f,-0.0862f,-0.9334f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[-0.0114f,-0.9295f,0.1195f,0.3488f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.9996f,0.0131f,0.0003f,0.0255f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0003f,0.0255f,0.9996f,0.0131f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3659f,0.8318f,0.2341f],left_rotation:[-0.1793f,-0.0072f,0.0627f,-0.9818f]}}
particle minecraft:cloud -92.20 69.97 -24.02 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -92.20 69.77 -24.02 -0.043 0.02 -0.003 1 0 force
particle minecraft:cloud -92.32 69.97 -22.32 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -94280
scoreboard players set #gdx driftmountains 509
scoreboard players set #gy driftmountains 69774
scoreboard players set #gdy driftmountains -19
scoreboard players set #gz driftmountains -19541
scoreboard players set #gdz driftmountains -591
scoreboard players set #gr driftmountains -9219
scoreboard players set #gdr driftmountains 79
scoreboard players set #gp driftmountains 95
scoreboard players set #gdp driftmountains 3
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.5940f,-0.2389f,-0.2700f,-0.7191f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.1959f,-0.6947f,0.6224f,0.3026f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.9996f,0.0131f,0.0003f,0.0255f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0003f,0.0255f,0.9996f,0.0131f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3542f,0.8350f,0.0952f],left_rotation:[-0.1832f,-0.0260f,0.1730f,-0.9673f]}}
particle minecraft:cloud -95.57 70.09 -20.33 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -95.57 69.89 -20.33 -0.047 0.02 0.002 1 0 force
particle minecraft:cloud -95.51 70.09 -18.66 0.35 0.18 0.35 0.02 3 force
