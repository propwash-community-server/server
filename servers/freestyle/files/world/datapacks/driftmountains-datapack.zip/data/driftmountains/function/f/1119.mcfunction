scoreboard players set #gx driftmountains -76475
scoreboard players set #gdx driftmountains -896
scoreboard players set #gy driftmountains 70194
scoreboard players set #gdy driftmountains -25
scoreboard players set #gz driftmountains 25784
scoreboard players set #gdz driftmountains -1010
scoreboard players set #gr driftmountains 17769
scoreboard players set #gdr driftmountains 24
scoreboard players set #gp driftmountains 82
scoreboard players set #gdp driftmountains -3
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.8856f,-0.0606f,-0.3314f,-0.3197f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.2996f,-0.2867f,0.8969f,0.1540f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.5990f,0.0078f,-0.0105f,-0.8007f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0105f,-0.8007f,0.5990f,0.0078f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3524f,0.8453f,0.0993f],left_rotation:[-0.1873f,0.0167f,-0.0539f,-0.9806f]}}
particle minecraft:cloud -77.26 70.51 27.08 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -77.26 70.31 27.08 0.003 0.02 0.081 1 0 force
particle minecraft:cloud -75.59 70.51 27.01 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -68699
scoreboard players set #gdx driftmountains -985
scoreboard players set #gy driftmountains 70396
scoreboard players set #gdy driftmountains -24
scoreboard players set #gz driftmountains 33500
scoreboard players set #gdz driftmountains -991
scoreboard players set #gr driftmountains 17793
scoreboard players set #gdr driftmountains -60
scoreboard players set #gp driftmountains 72
scoreboard players set #gdp driftmountains 3
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.8313f,0.2121f,-0.2948f,0.4208f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.3406f,0.4541f,0.8136f,-0.1259f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.5990f,0.0078f,-0.0105f,-0.8007f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0105f,-0.8007f,0.5990f,0.0078f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3721f,0.8287f,0.2329f],left_rotation:[-0.1753f,-0.0337f,0.1979f,-0.9638f]}}
particle minecraft:cloud -69.50 70.72 34.90 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -69.50 70.52 34.90 0.003 0.02 0.083 1 0 force
particle minecraft:cloud -67.80 70.72 34.83 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -64806
scoreboard players set #gdx driftmountains -936
scoreboard players set #gy driftmountains 70479
scoreboard players set #gdy driftmountains -17
scoreboard players set #gz driftmountains 37443
scoreboard players set #gdz driftmountains -923
scoreboard players set #gr driftmountains -17921
scoreboard players set #gdr driftmountains 30
scoreboard players set #gp driftmountains 47
scoreboard players set #gdp driftmountains 6
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.2006f,-0.3559f,-0.1370f,-0.9024f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.0429f,-0.8930f,0.2391f,0.3789f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.5990f,0.0078f,-0.0105f,-0.8007f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0105f,-0.8007f,0.5990f,0.0078f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3599f,0.8273f,0.0922f],left_rotation:[-0.1714f,-0.0628f,0.3674f,-0.9119f]}}
particle minecraft:cloud -65.66 70.80 38.69 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -65.66 70.60 38.69 -0.001 0.02 0.080 1 0 force
particle minecraft:cloud -63.99 70.80 38.71 0.35 0.18 0.35 0.02 3 force
