scoreboard players set #gx driftmountains 21410
scoreboard players set #gdx driftmountains -638
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 51747
scoreboard players set #gdz driftmountains 901
scoreboard players set #gr driftmountains 8760
scoreboard players set #gdr driftmountains 169
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.8936f,0.1280f,-0.4014f,0.1548f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.4199f,0.1978f,0.8851f,-0.0348f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.8052f,0.0105f,-0.0078f,-0.5928f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0078f,-0.5928f,0.8052f,0.0105f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3777f,0.8210f,0.0897f],left_rotation:[-0.1283f,-0.1254f,0.6939f,-0.6973f]}}
particle minecraft:cloud 22.70 71.32 52.53 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 22.70 71.12 52.53 0.066 0.02 -0.003 1 0 force
particle minecraft:cloud 22.63 71.32 50.86 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains 25737
scoreboard players set #gdx driftmountains -494
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 44491
scoreboard players set #gdz driftmountains 950
scoreboard players set #gr driftmountains 8714
scoreboard players set #gdr driftmountains 137
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.4886f,0.4200f,-0.2078f,0.7360f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.2863f,0.7619f,0.4471f,-0.3710f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.8052f,0.0105f,-0.0078f,-0.5928f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0078f,-0.5928f,0.8052f,0.0105f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.4058f,0.8554f,0.2434f],left_rotation:[-0.0493f,-0.1813f,0.9367f,-0.2955f]}}
particle minecraft:cloud 27.14 71.32 45.28 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 27.14 71.12 45.28 0.065 0.02 -0.003 1 0 force
particle minecraft:cloud 27.06 71.32 43.57 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains 27085
scoreboard players set #gdx driftmountains -155
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 39567
scoreboard players set #gdz driftmountains 902
scoreboard players set #gr driftmountains 6775
scoreboard players set #gdr driftmountains 196
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.6024f,-0.2872f,-0.3400f,-0.6626f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.2722f,-0.6305f,0.6359f,0.3521f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.8052f,0.0105f,-0.0078f,-0.5928f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0078f,-0.5928f,0.8052f,0.0105f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3890f,0.8240f,0.0909f],left_rotation:[-0.0920f,-0.1540f,0.8400f,-0.5120f]}}
particle minecraft:cloud 28.57 71.32 39.86 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 28.57 71.12 39.86 0.053 0.02 -0.022 1 0 force
particle minecraft:cloud 27.93 71.32 38.32 0.35 0.18 0.35 0.02 3 force
