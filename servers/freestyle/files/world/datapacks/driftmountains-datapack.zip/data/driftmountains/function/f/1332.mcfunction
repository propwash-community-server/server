scoreboard players set #gx driftmountains -36029
scoreboard players set #gdx driftmountains 651
scoreboard players set #gy driftmountains 67412
scoreboard players set #gdy driftmountains -12
scoreboard players set #gz driftmountains -91546
scoreboard players set #gdz driftmountains 94
scoreboard players set #gr driftmountains -4861
scoreboard players set #gdr driftmountains 206
scoreboard players set #gp driftmountains 90
scoreboard players set #gdp driftmountains -1
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0001f,-0.0211f,0.9998f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.9226f,-0.0174f,-0.2126f,-0.3214f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.1800f,-0.3008f,0.9295f,0.1145f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.9296f,0.0122f,0.0048f,0.3684f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0048f,0.3684f,0.9296f,0.0122f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3957f,0.8582f,0.1043f],left_rotation:[-0.0652f,0.1768f,-0.9320f,-0.3096f]}}
particle minecraft:cloud -36.42 67.73 -93.01 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -36.42 67.53 -93.01 -0.029 0.02 -0.026 1 0 force
particle minecraft:cloud -37.53 67.73 -91.75 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -41357
scoreboard players set #gdx driftmountains 648
scoreboard players set #gy driftmountains 67556
scoreboard players set #gdy driftmountains -17
scoreboard players set #gz driftmountains -91337
scoreboard players set #gdz driftmountains -180
scoreboard players set #gr driftmountains -6929
scoreboard players set #gdr driftmountains 440
scoreboard players set #gp driftmountains 110
scoreboard players set #gdp driftmountains 7
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[0.0050f,0.0001f,-0.0223f,0.9997f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.9778f,0.0648f,-0.1905f,0.0583f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.1977f,0.0786f,0.9764f,0.0376f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.9296f,0.0122f,0.0048f,0.3684f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0048f,0.3684f,0.9296f,0.0122f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3896f,0.8729f,0.2502f],left_rotation:[-0.0417f,0.1884f,-0.9604f,-0.2010f]}}
particle minecraft:cloud -42.33 67.88 -92.62 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -42.33 67.68 -92.62 -0.034 0.02 -0.013 1 0 force
particle minecraft:cloud -42.94 67.88 -91.02 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -45520
scoreboard players set #gdx driftmountains 502
scoreboard players set #gy driftmountains 67658
scoreboard players set #gdy driftmountains -13
scoreboard players set #gz driftmountains -88892
scoreboard players set #gdz driftmountains -455
scoreboard players set #gr driftmountains -9948
scoreboard players set #gdr driftmountains 251
scoreboard players set #gp driftmountains 87
scoreboard players set #gdp driftmountains 2
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[0.0061f,0.0001f,-0.0206f,0.9998f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.9714f,0.0561f,-0.2304f,0.0099f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.2327f,0.0341f,0.9709f,0.0457f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.9296f,0.0122f,0.0048f,0.3684f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0048f,0.3684f,0.9296f,0.0122f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3869f,0.8645f,0.1068f],left_rotation:[-0.1034f,0.1603f,-0.8369f,-0.5129f]}}
particle minecraft:cloud -46.90 67.98 -89.51 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -46.90 67.78 -89.51 -0.030 0.02 0.005 1 0 force
particle minecraft:cloud -46.62 67.98 -87.86 0.35 0.18 0.35 0.02 3 force
