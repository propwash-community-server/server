scoreboard players set #gx driftmountains -34724
scoreboard players set #gdx driftmountains 653
scoreboard players set #gy driftmountains 67386
scoreboard players set #gdy driftmountains -13
scoreboard players set #gz driftmountains -91327
scoreboard players set #gdz driftmountains 161
scoreboard players set #gr driftmountains -4422
scoreboard players set #gdr driftmountains 206
scoreboard players set #gp driftmountains 93
scoreboard players set #gdp driftmountains -1
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0001f,-0.0204f,0.9998f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.6759f,0.1823f,-0.1004f,0.7070f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.1752f,0.7214f,0.6605f,-0.1123f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.6170f,0.0081f,0.0103f,0.7869f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0103f,0.7869f,0.6170f,0.0081f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3972f,0.8564f,0.1036f],left_rotation:[-0.0565f,0.1791f,-0.9463f,-0.2631f]}}
particle minecraft:cloud -35.00 67.71 -92.81 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -35.00 67.51 -92.81 -0.028 0.02 -0.029 1 0 force
particle minecraft:cloud -36.20 67.71 -91.65 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -40241
scoreboard players set #gdx driftmountains 681
scoreboard players set #gy driftmountains 67527
scoreboard players set #gdy driftmountains -19
scoreboard players set #gz driftmountains -91610
scoreboard players set #gdz driftmountains -93
scoreboard players set #gr driftmountains -6178
scoreboard players set #gdr driftmountains 425
scoreboard players set #gp driftmountains 121
scoreboard players set #gdp driftmountains 7
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0001f,-0.0223f,0.9997f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.1325f,0.2007f,0.0265f,0.9703f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.0754f,0.9729f,0.1121f,-0.1879f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.6170f,0.0081f,0.0103f,0.7869f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0103f,0.7869f,0.6170f,0.0081f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3891f,0.8731f,0.2503f],left_rotation:[-0.0436f,0.1880f,-0.9581f,-0.2118f]}}
particle minecraft:cloud -41.04 67.85 -93.01 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -41.04 67.65 -93.01 -0.031 0.02 -0.017 1 0 force
particle minecraft:cloud -41.85 67.85 -91.50 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -44653
scoreboard players set #gdx driftmountains 456
scoreboard players set #gy driftmountains 67637
scoreboard players set #gdy driftmountains -11
scoreboard players set #gz driftmountains -89651
scoreboard players set #gdz driftmountains -362
scoreboard players set #gr driftmountains -9512
scoreboard players set #gdr driftmountains 227
scoreboard players set #gp driftmountains 89
scoreboard players set #gdp driftmountains 2
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[0.0061f,0.0001f,-0.0209f,0.9998f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.0340f,0.2279f,0.0458f,0.9720f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.0561f,0.9726f,0.0103f,-0.2256f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.6170f,0.0081f,0.0103f,0.7869f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0103f,0.7869f,0.6170f,0.0081f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3889f,0.8636f,0.1064f],left_rotation:[-0.0963f,0.1642f,-0.8591f,-0.4749f]}}
particle minecraft:cloud -45.98 67.96 -90.37 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -45.98 67.76 -90.37 -0.024 0.02 0.002 1 0 force
particle minecraft:cloud -45.83 67.96 -88.71 0.35 0.18 0.35 0.02 3 force
