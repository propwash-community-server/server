scoreboard players set #gx driftmountains 22021
scoreboard players set #gdx driftmountains -610
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 50836
scoreboard players set #gdz driftmountains 912
scoreboard players set #gr driftmountains 8592
scoreboard players set #gdr driftmountains 168
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.0818f,0.4197f,0.0199f,0.9038f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.0750f,0.9067f,0.0381f,-0.4134f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.7825f,0.0102f,0.0081f,0.6225f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0081f,0.6225f,0.7825f,0.0102f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3771f,0.8210f,0.0897f],left_rotation:[-0.1299f,-0.1238f,0.6855f,-0.7055f]}}
particle minecraft:cloud 23.34 71.32 51.58 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 23.34 71.12 51.58 0.065 0.02 -0.005 1 0 force
particle minecraft:cloud 23.22 71.32 49.91 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains 26210
scoreboard players set #gdx driftmountains -473
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 43500
scoreboard players set #gdz driftmountains 992
scoreboard players set #gr driftmountains 8580
scoreboard players set #gdr driftmountains 134
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.5817f,-0.3147f,-0.3565f,-0.6599f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.2891f,-0.6261f,0.6179f,0.3775f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.7825f,0.0102f,0.0081f,0.6225f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0081f,0.6225f,0.7825f,0.0102f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.4048f,0.8587f,0.2446f],left_rotation:[-0.0367f,-0.1853f,0.9554f,-0.2271f]}}
particle minecraft:cloud 27.63 71.32 44.25 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 27.63 71.12 44.25 0.065 0.02 -0.005 1 0 force
particle minecraft:cloud 27.51 71.32 42.55 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains 27208
scoreboard players set #gdx driftmountains -123
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 38628
scoreboard players set #gdz driftmountains 939
scoreboard players set #gr driftmountains 6531
scoreboard players set #gdr driftmountains 244
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.7973f,0.2526f,-0.3624f,0.4114f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.4077f,0.4517f,0.7751f,-0.1702f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.7825f,0.0102f,0.0081f,0.6225f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0081f,0.6225f,0.7825f,0.0102f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3875f,0.8233f,0.0906f],left_rotation:[-0.0974f,-0.1506f,0.8224f,-0.5398f]}}
particle minecraft:cloud 28.70 71.32 38.86 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 28.70 71.12 38.86 0.051 0.02 -0.023 1 0 force
particle minecraft:cloud 28.00 71.32 37.34 0.35 0.18 0.35 0.02 3 force
