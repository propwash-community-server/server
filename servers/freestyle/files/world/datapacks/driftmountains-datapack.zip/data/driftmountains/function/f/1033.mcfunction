scoreboard players set #gx driftmountains 15501
scoreboard players set #gdx driftmountains -852
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 58474
scoreboard players set #gdz driftmountains 695
scoreboard players set #gr driftmountains 10575
scoreboard players set #gdr driftmountains 295
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.5782f,-0.2895f,-0.3165f,-0.6941f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.2453f,-0.6646f,0.6118f,0.3519f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.0913f,0.0012f,0.0130f,0.9957f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0130f,0.9957f,0.0913f,0.0012f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3815f,0.8214f,0.0899f],left_rotation:[-0.1174f,-0.1354f,0.7454f,-0.6420f]}}
particle minecraft:cloud 16.49 71.32 59.62 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 16.49 71.12 59.62 0.064 0.02 0.018 1 0 force
particle minecraft:cloud 16.94 71.32 58.01 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains 20694
scoreboard players set #gdx driftmountains -723
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 51816
scoreboard players set #gdz driftmountains 792
scoreboard players set #gr driftmountains 10035
scoreboard players set #gdr driftmountains 154
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[-0.0031f,-0.0001f,-0.0223f,0.9997f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.8852f,0.0305f,-0.4610f,-0.0549f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.4578f,-0.0067f,0.8869f,0.0624f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.0913f,0.0012f,0.0130f,0.9957f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0130f,0.9957f,0.0913f,0.0012f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.4062f,0.8522f,0.2421f],left_rotation:[-0.0610f,-0.1766f,0.9146f,-0.3588f]}}
particle minecraft:cloud 21.88 71.32 52.90 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 21.88 71.12 52.90 0.067 0.02 0.012 1 0 force
particle minecraft:cloud 22.19 71.32 51.22 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains 24780
scoreboard players set #gdx driftmountains -461
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 47221
scoreboard players set #gdz driftmountains 953
scoreboard players set #gr driftmountains 8121
scoreboard players set #gdr driftmountains 199
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.2733f,0.4295f,-0.0760f,0.8573f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.1665f,0.8701f,0.2297f,-0.4031f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.0913f,0.0012f,0.0130f,0.9957f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0130f,0.9957f,0.0913f,0.0012f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3849f,0.8223f,0.0902f],left_rotation:[-0.1064f,-0.1442f,0.7904f,-0.5857f]}}
particle minecraft:cloud 26.15 71.32 47.85 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 26.15 71.12 47.85 0.062 0.02 -0.010 1 0 force
particle minecraft:cloud 25.90 71.32 46.20 0.35 0.18 0.35 0.02 3 force
