scoreboard players set #gx driftmountains -32769
scoreboard players set #gdx driftmountains 648
scoreboard players set #gy driftmountains 67348
scoreboard players set #gdy driftmountains -13
scoreboard players set #gz driftmountains -90751
scoreboard players set #gdz driftmountains 250
scoreboard players set #gr driftmountains -3797
scoreboard players set #gdr driftmountains 74
scoreboard players set #gp driftmountains 90
scoreboard players set #gdp driftmountains -4
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0001f,-0.0193f,0.9998f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.6295f,0.2007f,-0.0996f,0.7440f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.1783f,0.7586f,0.6118f,-0.1357f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.9918f,0.0130f,0.0017f,0.1274f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0017f,0.1274f,0.9918f,0.0130f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3921f,0.8615f,0.1056f],left_rotation:[-0.0831f,0.1704f,-0.8947f,-0.4044f]}}
particle minecraft:cloud -32.89 67.67 -92.26 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -32.89 67.47 -92.26 -0.026 0.02 -0.033 1 0 force
particle minecraft:cloud -34.20 67.67 -91.23 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -38359
scoreboard players set #gdx driftmountains 607
scoreboard players set #gy driftmountains 67472
scoreboard players set #gdy driftmountains -18
scoreboard players set #gz driftmountains -91716
scoreboard players set #gdz driftmountains 24
scoreboard players set #gr driftmountains -5055
scoreboard players set #gdr driftmountains -57
scoreboard players set #gp driftmountains 137
scoreboard players set #gdp driftmountains -4
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.2672f,-0.1942f,-0.1111f,-0.9373f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.0132f,-0.9308f,0.2891f,0.2233f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.9918f,0.0130f,0.0017f,0.1274f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0017f,0.1274f,0.9918f,0.0130f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3789f,0.8742f,0.2507f],left_rotation:[-0.0782f,0.1767f,-0.8948f,-0.4025f]}}
particle minecraft:cloud -38.87 67.79 -93.24 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -38.87 67.59 -93.24 -0.028 0.02 -0.023 1 0 force
particle minecraft:cloud -39.96 67.79 -91.92 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -43189
scoreboard players set #gdx driftmountains 315
scoreboard players set #gy driftmountains 67601
scoreboard players set #gdy driftmountains -8
scoreboard players set #gz driftmountains -90726
scoreboard players set #gdz driftmountains -200
scoreboard players set #gr driftmountains -8773
scoreboard players set #gdr driftmountains 168
scoreboard players set #gp driftmountains 102
scoreboard players set #gdp driftmountains 3
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[0.0061f,0.0001f,-0.0215f,0.9997f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.3420f,-0.1836f,-0.1260f,-0.9129f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.0308f,-0.9047f,0.3632f,0.2206f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.9918f,0.0130f,0.0017f,0.1274f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0017f,0.1274f,0.9918f,0.0130f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3926f,0.8612f,0.1055f],left_rotation:[-0.0809f,0.1713f,-0.8998f,-0.3928f]}}
particle minecraft:cloud -44.41 67.92 -91.61 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -44.41 67.72 -91.61 -0.033 0.02 -0.001 1 0 force
particle minecraft:cloud -44.48 67.92 -89.94 0.35 0.18 0.35 0.02 3 force
