scoreboard players set #gx driftmountains -56536
scoreboard players set #gdx driftmountains 295
scoreboard players set #gy driftmountains 68838
scoreboard players set #gdy driftmountains -19
scoreboard players set #gz driftmountains -39728
scoreboard players set #gdz driftmountains -574
scoreboard players set #gr driftmountains 17526
scoreboard players set #gdr driftmountains -206
scoreboard players set #gp driftmountains 139
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,0.0001f,0.0201f,0.9998f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.6632f,-0.1197f,0.1840f,0.7156f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[-0.1098f,0.7002f,0.6794f,0.1901f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.3626f,0.0047f,0.0122f,0.9319f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0122f,0.9319f,0.3626f,0.0047f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3950f,0.8285f,0.0927f],left_rotation:[-0.0651f,-0.1681f,0.9099f,-0.3734f]}}
particle minecraft:cloud -57.26 69.16 -38.40 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud -55.60 69.16 -38.54 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -55.60 68.96 -38.54 0.003 0.02 0.038 1 0 force
playsound driftgen:grain.kaze.034 neutral @a -54.75 69.18 -44.77 12 1
scoreboard players set #gx driftmountains -60377
scoreboard players set #gdx driftmountains 381
scoreboard players set #gy driftmountains 68979
scoreboard players set #gdy driftmountains -21
scoreboard players set #gz driftmountains -37033
scoreboard players set #gdz driftmountains -441
scoreboard players set #gr driftmountains -17473
scoreboard players set #gdr driftmountains -85
scoreboard players set #gp driftmountains 166
scoreboard players set #gdp driftmountains -7
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[-0.0039f,0.0001f,0.0221f,0.9997f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.4366f,-0.1650f,0.1424f,0.8729f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[-0.0514f,0.8627f,0.4563f,0.2118f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.3626f,0.0047f,0.0122f,0.9319f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0122f,0.9319f,0.3626f,0.0047f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.4062f,0.8522f,0.2421f],left_rotation:[-0.0612f,-0.1766f,0.9141f,-0.3598f]}}
particle minecraft:cloud -61.35 69.30 -35.75 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud -59.65 69.30 -35.60 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -59.65 69.10 -35.60 -0.003 0.02 0.035 1 0 force
playsound driftgen:grain.onyx.035 neutral @a -57.38 69.32 -40.97 12 1
scoreboard players set #gx driftmountains -64364
scoreboard players set #gdx driftmountains 593
scoreboard players set #gy driftmountains 69126
scoreboard players set #gdy driftmountains -12
scoreboard players set #gz driftmountains -33298
scoreboard players set #gdz driftmountains -274
scoreboard players set #gr driftmountains -13986
scoreboard players set #gdr driftmountains -407
scoreboard players set #gp driftmountains 89
scoreboard players set #gdp driftmountains 4
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[0.0061f,-0.0001f,0.0158f,0.9999f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.7433f,0.1595f,0.1034f,-0.6414f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[-0.1714f,-0.6558f,0.7306f,-0.0823f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.3626f,0.0047f,0.0122f,0.9319f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0122f,0.9319f,0.3626f,0.0047f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.4009f,0.8399f,0.0971f],left_rotation:[-0.0136f,-0.1825f,0.9774f,-0.1056f]}}
particle minecraft:cloud -65.81 69.45 -32.87 0.35 0.18 0.35 0.02 2 force
particle minecraft:cloud -64.54 69.45 -31.80 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -64.54 69.25 -31.80 -0.020 0.02 0.023 1 0 force
playsound driftgen:grain.kaze.033 neutral @a -60.23 69.50 -36.08 12 1
