scoreboard players set #gx driftmountains -56216
scoreboard players set #gdx driftmountains 190
scoreboard players set #gy driftmountains 68005
scoreboard players set #gdy driftmountains -17
scoreboard players set #gz driftmountains -73417
scoreboard players set #gdz driftmountains -579
scoreboard players set #gr driftmountains -12874
scoreboard players set #gdr driftmountains 125
scoreboard players set #gp driftmountains 144
scoreboard players set #gdp driftmountains -20
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.8840f,-0.0356f,-0.1984f,-0.4218f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.1552f,-0.4033f,0.8926f,0.1287f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.9999f,0.0131f,0.0001f,0.0105f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0001f,0.0105f,0.9999f,0.0131f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3987f,0.8539f,0.1026f],left_rotation:[-0.0452f,0.1815f,-0.9610f,-0.2033f]}}
particle minecraft:cloud -57.72 68.32 -73.28 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -57.72 68.12 -73.28 -0.028 0.02 0.023 1 0 force
particle minecraft:cloud -56.68 68.32 -71.98 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -55881
scoreboard players set #gdx driftmountains -53
scoreboard players set #gy driftmountains 68132
scoreboard players set #gdy driftmountains -15
scoreboard players set #gz driftmountains -68712
scoreboard players set #gdz driftmountains -717
scoreboard players set #gr driftmountains -15171
scoreboard players set #gdr driftmountains 239
scoreboard players set #gp driftmountains 96
scoreboard players set #gdp driftmountains 3
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[0.0061f,0.0001f,-0.0202f,0.9998f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.0295f,-0.2447f,-0.0615f,-0.9672f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[-0.0398f,-0.9661f,0.0554f,0.2492f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.9999f,0.0131f,0.0001f,0.0105f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0001f,0.0105f,0.9999f,0.0131f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3660f,0.8698f,0.2490f],left_rotation:[-0.1192f,0.1499f,-0.7519f,-0.6309f]}}
particle minecraft:cloud -57.28 68.45 -67.91 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -57.28 68.25 -67.91 -0.021 0.02 0.039 1 0 force
particle minecraft:cloud -55.78 68.45 -67.10 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -54752
scoreboard players set #gdx driftmountains -89
scoreboard players set #gy driftmountains 68253
scoreboard players set #gdy driftmountains -13
scoreboard players set #gz driftmountains -61958
scoreboard players set #gdz driftmountains -782
scoreboard players set #gr driftmountains 17849
scoreboard players set #gdr driftmountains 419
scoreboard players set #gp driftmountains 93
scoreboard players set #gdp driftmountains -1
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0000f,-0.0031f,1.0000f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.6521f,0.0618f,0.0159f,0.7555f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.0634f,0.7579f,0.6492f,0.0064f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.9999f,0.0131f,0.0001f,0.0105f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0001f,0.0105f,0.9999f,0.0131f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3581f,0.8291f,0.0929f],left_rotation:[0.1752f,0.0534f,-0.3180f,0.9302f]}}
