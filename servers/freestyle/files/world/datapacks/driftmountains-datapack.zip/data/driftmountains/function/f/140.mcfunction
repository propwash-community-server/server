scoreboard players set #gx driftmountains 14360
scoreboard players set #gdx driftmountains 442
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains -627
scoreboard players set #gdz driftmountains 935
scoreboard players set #gr driftmountains 1214
scoreboard players set #gdr driftmountains -1
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.4400f,-0.2535f,-0.1952f,-0.8391f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.1081f,-0.8232f,0.4691f,0.3011f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.9043f,0.0118f,-0.0056f,-0.4267f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0056f,-0.4267f,0.9043f,0.0118f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3542f,0.8526f,0.1021f],left_rotation:[-0.1841f,0.0466f,-0.2141f,-0.9581f]}}
particle minecraft:cloud 15.44 71.32 -1.68 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 15.44 71.12 -1.68 0.013 0.02 -0.060 1 0 force
particle minecraft:cloud 13.81 71.32 -2.03 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains 11299
scoreboard players set #gdx driftmountains 434
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains -6401
scoreboard players set #gdz driftmountains 859
scoreboard players set #gr driftmountains 1085
scoreboard players set #gdr driftmountains 19
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.8836f,-0.0624f,-0.3157f,-0.3402f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.2816f,-0.3089f,0.8950f,0.1556f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.9043f,0.0118f,-0.0056f,-0.4267f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0056f,-0.4267f,0.9043f,0.0118f]}}
particle minecraft:cloud 12.40 71.32 -7.58 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 12.40 71.12 -7.58 0.012 0.02 -0.060 1 0 force
particle minecraft:cloud 10.72 71.32 -7.90 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains 8523
scoreboard players set #gdx driftmountains 490
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains -11734
scoreboard players set #gdz driftmountains 903
scoreboard players set #gr driftmountains 915
scoreboard players set #gdr driftmountains 1
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.3005f,-0.2839f,-0.1533f,-0.8975f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.0598f,-0.8864f,0.3320f,0.3171f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.9043f,0.0118f,-0.0056f,-0.4267f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0056f,-0.4267f,0.9043f,0.0118f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3538f,0.8515f,0.1017f],left_rotation:[-0.1849f,0.0419f,-0.1890f,-0.9635f]}}
particle minecraft:cloud 9.55 71.32 -12.85 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 9.55 71.12 -12.85 0.009 0.02 -0.057 1 0 force
particle minecraft:cloud 7.90 71.32 -13.11 0.35 0.18 0.35 0.02 3 force
