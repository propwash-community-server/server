scoreboard players set #gx driftmountains 2807
scoreboard players set #gdx driftmountains 862
scoreboard players set #gy driftmountains 66833
scoreboard players set #gdy driftmountains -11
scoreboard players set #gz driftmountains -69534
scoreboard players set #gdz driftmountains 585
scoreboard players set #gr driftmountains -5119
scoreboard players set #gdr driftmountains -22
scoreboard players set #gp driftmountains 61
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0000f,-0.0028f,1.0000f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.5465f,0.0618f,0.0222f,0.8349f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.0655f,0.8372f,0.5430f,-0.0047f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.9700f,0.0127f,0.0032f,0.2426f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0032f,0.2426f,0.9700f,0.0127f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3590f,0.8281f,0.0925f],left_rotation:[0.1732f,0.0585f,-0.3448f,0.9207f]}}
scoreboard players set #gx driftmountains -4131
scoreboard players set #gdx driftmountains 834
scoreboard players set #gy driftmountains 66921
scoreboard players set #gdy driftmountains -11
scoreboard players set #gz driftmountains -73900
scoreboard players set #gdz driftmountains 533
scoreboard players set #gr driftmountains -4972
scoreboard players set #gdr driftmountains -53
scoreboard players set #gp driftmountains 62
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0000f,-0.0047f,1.0000f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.1102f,-0.0597f,-0.0594f,-0.9903f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[-0.0443f,-0.9895f,0.1170f,0.0716f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.9700f,0.0127f,0.0032f,0.2426f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0032f,0.2426f,0.9700f,0.0127f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3916f,0.8293f,0.2331f],left_rotation:[0.1460f,0.1039f,-0.5535f,0.8133f]}}
scoreboard players set #gx driftmountains -12360
scoreboard players set #gdx driftmountains 736
scoreboard players set #gy driftmountains 67033
scoreboard players set #gdy driftmountains -10
scoreboard players set #gz driftmountains -79616
scoreboard players set #gdz driftmountains 486
scoreboard players set #gr driftmountains -3669
scoreboard players set #gdr driftmountains -117
scoreboard players set #gp driftmountains 62
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0000f,-0.0122f,0.9999f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.5166f,0.1736f,-0.0447f,0.8373f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.1329f,0.8466f,0.5012f,-0.1203f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.9700f,0.0127f,0.0032f,0.2426f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0032f,0.2426f,0.9700f,0.0127f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.4013f,0.8445f,0.0989f],left_rotation:[-0.0053f,0.1842f,-0.9828f,0.0066f]}}
particle minecraft:cloud -12.44 67.35 -81.13 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -12.44 67.15 -81.13 -0.034 0.02 -0.046 1 0 force
particle minecraft:cloud -13.78 67.35 -80.13 0.35 0.18 0.35 0.02 2 force
