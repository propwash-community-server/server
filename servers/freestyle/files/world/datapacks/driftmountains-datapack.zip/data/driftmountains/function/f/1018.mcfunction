scoreboard players set #gx driftmountains 25066
scoreboard players set #gdx driftmountains -427
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 45181
scoreboard players set #gdz driftmountains 963
scoreboard players set #gr driftmountains 7625
scoreboard players set #gdr driftmountains 142
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.9056f,0.0202f,-0.4158f,-0.0817f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.4095f,-0.0384f,0.9084f,0.0749f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.6109f,0.0080f,-0.0104f,-0.7916f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0104f,-0.7916f,0.6109f,0.0080f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3752f,0.8210f,0.0897f],left_rotation:[-0.1351f,-0.1183f,0.6573f,-0.7318f]}}
particle minecraft:cloud 26.49 71.32 45.69 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 26.49 71.12 45.69 0.061 0.02 -0.015 1 0 force
particle minecraft:cloud 26.09 71.32 44.07 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains 28163
scoreboard players set #gdx driftmountains -208
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 37622
scoreboard players set #gdz driftmountains 989
scoreboard players set #gr driftmountains 7447
scoreboard players set #gdr driftmountains 305
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0001f,-0.0223f,0.9997f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.6624f,0.3520f,-0.3096f,0.5844f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.3727f,0.6202f,0.6290f,-0.2844f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.6109f,0.0080f,-0.0104f,-0.7916f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0104f,-0.7916f,0.6109f,0.0080f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.4058f,0.8555f,0.2434f],left_rotation:[-0.0489f,-0.1814f,0.9373f,-0.2936f]}}
particle minecraft:cloud 29.71 71.32 38.08 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 29.71 71.12 38.08 0.058 0.02 -0.016 1 0 force
particle minecraft:cloud 29.25 71.32 36.43 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains 26949
scoreboard players set #gdx driftmountains 160
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 32981
scoreboard players set #gdz driftmountains 933
scoreboard players set #gr driftmountains 4633
scoreboard players set #gdr driftmountains 327
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.4152f,-0.3502f,-0.2462f,-0.8027f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.1632f,-0.7813f,0.4543f,0.3958f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.6109f,0.0080f,-0.0104f,-0.7916f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0104f,-0.7916f,0.6109f,0.0080f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3811f,0.8213f,0.0898f],left_rotation:[-0.1186f,-0.1344f,0.7399f,-0.6484f]}}
particle minecraft:cloud 28.44 71.32 32.71 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 28.44 71.12 32.71 0.041 0.02 -0.039 1 0 force
particle minecraft:cloud 27.28 71.32 31.51 0.35 0.18 0.35 0.02 3 force
