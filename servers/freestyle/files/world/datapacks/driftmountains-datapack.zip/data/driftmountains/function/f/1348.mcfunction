scoreboard players set #gx driftmountains -25473
scoreboard players set #gdx driftmountains 685
scoreboard players set #gy driftmountains 67224
scoreboard players set #gdy driftmountains -11
scoreboard players set #gz driftmountains -87398
scoreboard players set #gdz driftmountains 361
scoreboard players set #gr driftmountains -3362
scoreboard players set #gdr driftmountains 37
scoreboard players set #gp driftmountains 70
scoreboard players set #gdp driftmountains -1
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0001f,-0.0176f,0.9998f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.2558f,0.2414f,-0.0101f,0.9360f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.1086f,0.9423f,0.2318f,-0.2159f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.1069f,0.0014f,0.0130f,0.9942f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0130f,0.9942f,0.1069f,0.0014f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3849f,0.8653f,0.1071f],left_rotation:[-0.1101f,0.1562f,-0.8137f,-0.5489f]}}
particle minecraft:cloud -25.48 67.54 -88.91 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -25.48 67.34 -88.91 -0.026 0.02 -0.039 1 0 force
particle minecraft:cloud -26.87 67.54 -87.98 0.35 0.18 0.35 0.02 2 force
scoreboard players set #gx driftmountains -31535
scoreboard players set #gdx driftmountains 682
scoreboard players set #gy driftmountains 67324
scoreboard players set #gdy driftmountains -12
scoreboard players set #gz driftmountains -90146
scoreboard players set #gdz driftmountains 303
scoreboard players set #gr driftmountains -3559
scoreboard players set #gdr driftmountains 55
scoreboard players set #gp driftmountains 81
scoreboard players set #gdp driftmountains -3
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0001f,-0.0189f,0.9998f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.7796f,0.1790f,-0.1503f,0.5810f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.2122f,0.6000f,0.7651f,-0.0981f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.1069f,0.0014f,0.0130f,0.9942f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0130f,0.9942f,0.1069f,0.0014f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3741f,0.8734f,0.2504f],left_rotation:[-0.0934f,0.1687f,-0.8519f,-0.4870f]}}
particle minecraft:cloud -31.63 67.64 -91.75 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -31.63 67.44 -91.75 -0.024 0.02 -0.034 1 0 force
particle minecraft:cloud -33.02 67.64 -90.76 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -37571
scoreboard players set #gdx driftmountains 527
scoreboard players set #gy driftmountains 67450
scoreboard players set #gdy driftmountains -14
scoreboard players set #gz driftmountains -92378
scoreboard players set #gdz driftmountains 57
scoreboard players set #gr driftmountains -5019
scoreboard players set #gdr driftmountains 294
scoreboard players set #gp driftmountains 124
scoreboard players set #gdp driftmountains -8
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0001f,-0.0216f,0.9998f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.8464f,-0.0429f,-0.1770f,-0.5005f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.1253f,-0.4847f,0.8555f,0.1321f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.1069f,0.0014f,0.0130f,0.9942f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0130f,0.9942f,0.1069f,0.0014f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.4012f,0.8457f,0.0994f],left_rotation:[-0.0104f,0.1843f,-0.9826f,-0.0203f]}}
particle minecraft:cloud -38.00 67.77 -93.83 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -38.00 67.57 -93.83 -0.026 0.02 -0.022 1 0 force
particle minecraft:cloud -39.07 67.77 -92.54 0.35 0.18 0.35 0.02 3 force
