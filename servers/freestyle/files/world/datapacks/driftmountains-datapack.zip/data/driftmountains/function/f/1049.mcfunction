scoreboard players set #gx driftmountains -371
scoreboard players set #gdx driftmountains -981
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 63088
scoreboard players set #gdz driftmountains -181
scoreboard players set #gr driftmountains 15348
scoreboard players set #gdr driftmountains 231
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[-0.0016f,-0.0000f,-0.0223f,0.9997f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.9062f,0.1229f,-0.3722f,0.1588f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.3909f,0.1988f,0.8983f,-0.0283f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.8386f,0.0110f,-0.0071f,-0.5446f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0071f,-0.5446f,0.8386f,0.0110f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3639f,0.8244f,0.0910f],left_rotation:[-0.1624f,-0.0807f,0.4614f,-0.8684f]}}
particle minecraft:cloud -0.56 71.32 64.59 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -0.56 71.12 64.59 0.027 0.02 0.054 1 0 force
particle minecraft:cloud 0.94 71.32 63.84 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains 7243
scoreboard players set #gdx driftmountains -993
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 60689
scoreboard players set #gdz driftmountains 201
scoreboard players set #gr driftmountains 13833
scoreboard players set #gdr driftmountains 259
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[-0.0030f,-0.0001f,-0.0223f,0.9997f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.4919f,0.4078f,-0.1997f,0.7428f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.2789f,0.7679f,0.4518f,-0.3584f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.8386f,0.0110f,-0.0071f,-0.5446f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0071f,-0.5446f,0.8386f,0.0110f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.4062f,0.8484f,0.2406f],left_rotation:[-0.0746f,-0.1700f,0.8825f,-0.4322f]}}
particle minecraft:cloud 7.51 71.32 62.28 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 7.51 71.12 62.28 0.041 0.02 0.046 1 0 force
particle minecraft:cloud 8.79 71.32 61.14 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains 13580
scoreboard players set #gdx driftmountains -829
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 60197
scoreboard players set #gdz driftmountains 460
scoreboard players set #gr driftmountains 12034
scoreboard players set #gdr driftmountains 320
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.5992f,-0.2934f,-0.3456f,-0.6598f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.2782f,-0.6272f,0.6334f,0.3579f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.8386f,0.0110f,-0.0071f,-0.5446f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0071f,-0.5446f,0.8386f,0.0110f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3924f,0.8262f,0.0918f],left_rotation:[-0.0778f,-0.1621f,0.8802f,-0.4391f]}}
particle minecraft:cloud 14.25 71.32 61.55 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 14.25 71.12 61.55 0.052 0.02 0.031 1 0 force
particle minecraft:cloud 15.09 71.32 60.11 0.35 0.18 0.35 0.02 3 force
