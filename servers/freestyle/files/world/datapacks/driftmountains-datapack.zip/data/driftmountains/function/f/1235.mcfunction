scoreboard players set #gx driftmountains -58240
scoreboard players set #gdx driftmountains 357
scoreboard players set #gy driftmountains 68929
scoreboard players set #gdy driftmountains -18
scoreboard players set #gz driftmountains -37119
scoreboard players set #gdz driftmountains -494
scoreboard players set #gr driftmountains -17731
scoreboard players set #gdr driftmountains -98
scoreboard players set #gp driftmountains 139
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,0.0001f,0.0206f,0.9998f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.7114f,0.2059f,0.1436f,-0.6564f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[-0.2134f,-0.6751f,0.6937f,-0.1323f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.1212f,0.0016f,0.0130f,0.9925f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0130f,0.9925f,0.1212f,0.0016f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3824f,0.8216f,0.0899f],left_rotation:[-0.1145f,-0.1378f,0.7577f,-0.6274f]}}
particle minecraft:cloud -59.13 69.25 -35.90 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud -57.46 69.25 -35.82 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -57.46 69.05 -35.82 -0.002 0.02 0.036 1 0 force
scoreboard players set #gx driftmountains -62565
scoreboard players set #gdx driftmountains 552
scoreboard players set #gy driftmountains 69079
scoreboard players set #gdy driftmountains -17
scoreboard players set #gz driftmountains -35262
scoreboard players set #gdz driftmountains -316
scoreboard players set #gr driftmountains -15342
scoreboard players set #gdr driftmountains -380
scoreboard players set #gp driftmountains 118
scoreboard players set #gdp driftmountains 18
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[0.0061f,-0.0001f,0.0213f,0.9998f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.6278f,0.1697f,0.0717f,-0.7563f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[-0.1516f,-0.7680f,0.6134f,-0.1046f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.1212f,0.0016f,0.0130f,0.9925f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0130f,0.9925f,0.1212f,0.0016f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.4002f,0.8661f,0.2475f],left_rotation:[-0.0040f,-0.1910f,0.9804f,-0.0493f]}}
particle minecraft:cloud -63.94 69.40 -34.42 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud -62.41 69.40 -33.66 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -62.41 69.20 -33.66 -0.016 0.02 0.032 1 0 force
scoreboard players set #gx driftmountains -66876
scoreboard players set #gdx driftmountains 574
scoreboard players set #gy driftmountains 69168
scoreboard players set #gdy driftmountains -9
scoreboard players set #gz driftmountains -32253
scoreboard players set #gdz driftmountains -234
scoreboard players set #gr driftmountains -12557
scoreboard players set #gdr driftmountains -278
scoreboard players set #gp driftmountains 83
scoreboard players set #gdp driftmountains 1
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[0.0061f,-0.0001f,0.0083f,0.9999f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.9734f,0.0298f,0.1214f,0.1918f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[-0.1019f,0.1801f,0.9757f,0.0724f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.1212f,0.0016f,0.0130f,0.9925f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0130f,0.9925f,0.1212f,0.0016f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3878f,0.8641f,0.1066f],left_rotation:[0.1003f,-0.1621f,0.8467f,0.4966f]}}
particle minecraft:cloud -68.39 69.49 -32.20 0.35 0.18 0.35 0.02 2 force
particle minecraft:cloud -67.42 69.49 -30.84 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -67.42 69.29 -30.84 -0.031 0.02 0.022 1 0 force
