scoreboard players set #gx driftmountains -3077
scoreboard players set #gdx driftmountains 825
scoreboard players set #gy driftmountains 66909
scoreboard players set #gdy driftmountains -11
scoreboard players set #gz driftmountains -73493
scoreboard players set #gdz driftmountains 550
scoreboard players set #gr driftmountains -4909
scoreboard players set #gdr driftmountains -44
scoreboard players set #gp driftmountains 62
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0000f,-0.0044f,1.0000f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.7439f,0.0797f,-0.0106f,0.6634f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.0804f,0.6682f,0.7396f,-0.0020f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.9993f,0.0131f,-0.0004f,-0.0339f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0004f,-0.0339f,0.9993f,0.0131f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3668f,0.8230f,0.0905f],left_rotation:[0.1560f,0.0913f,-0.5168f,0.8368f]}}
scoreboard players set #gx driftmountains -10005
scoreboard players set #gdx driftmountains 816
scoreboard players set #gy driftmountains 66998
scoreboard players set #gdy driftmountains -11
scoreboard players set #gz driftmountains -77632
scoreboard players set #gdz driftmountains 515
scoreboard players set #gr driftmountains -4265
scoreboard players set #gdr driftmountains -137
scoreboard players set #gp driftmountains 63
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0000f,-0.0092f,0.9999f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.1523f,0.1364f,0.0322f,0.9784f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.0705f,0.9804f,0.1388f,-0.1211f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.9993f,0.0131f,-0.0004f,-0.0339f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0004f,-0.0339f,0.9993f,0.0131f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.4063f,0.8515f,0.2418f],left_rotation:[0.0635f,0.1755f,-0.9091f,0.3724f]}}
particle minecraft:cloud -10.30 67.32 -79.21 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -10.30 67.12 -79.21 -0.039 0.02 -0.042 1 0 force
particle minecraft:cloud -11.56 67.32 -78.06 0.35 0.18 0.35 0.02 2 force
scoreboard players set #gx driftmountains -17719
scoreboard players set #gdx driftmountains 676
scoreboard players set #gy driftmountains 67109
scoreboard players set #gdy driftmountains -10
scoreboard players set #gz driftmountains -83123
scoreboard players set #gdz driftmountains 438
scoreboard players set #gr driftmountains -3013
scoreboard players set #gdr driftmountains -57
scoreboard players set #gp driftmountains 62
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0001f,-0.0165f,0.9999f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.7093f,0.1953f,-0.1298f,0.6648f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.2003f,0.6821f,0.6927f,-0.1218f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.9993f,0.0131f,-0.0004f,-0.0339f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0004f,-0.0339f,0.9993f,0.0131f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3880f,0.8640f,0.1066f],left_rotation:[-0.0993f,0.1626f,-0.8498f,-0.4914f]}}
particle minecraft:cloud -17.63 67.43 -84.63 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -17.63 67.23 -84.63 -0.027 0.02 -0.046 1 0 force
particle minecraft:cloud -19.07 67.43 -83.79 0.35 0.18 0.35 0.02 2 force
