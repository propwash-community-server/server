scoreboard players set #gx driftmountains 17363
scoreboard players set #gdx driftmountains 978
scoreboard players set #gy driftmountains 66647
scoreboard players set #gdy driftmountains -12
scoreboard players set #gz driftmountains -59741
scoreboard players set #gdz driftmountains 620
scoreboard players set #gr driftmountains -6004
scoreboard players set #gdr driftmountains 18
scoreboard players set #gp driftmountains 61
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.4527f,0.0388f,-0.0390f,-0.8900f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[-0.0543f,-0.8908f,0.4511f,0.0086f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.2372f,0.0031f,0.0127f,0.9714f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0127f,0.9714f,0.2372f,0.0031f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3532f,0.8499f,0.1011f],left_rotation:[0.1859f,-0.0352f,0.1532f,0.9699f]}}
scoreboard players set #gx driftmountains 10278
scoreboard players set #gdx driftmountains 973
scoreboard players set #gy driftmountains 66738
scoreboard players set #gdy driftmountains -12
scoreboard players set #gz driftmountains -64485
scoreboard players set #gdz driftmountains 653
scoreboard players set #gr driftmountains -5705
scoreboard players set #gdr driftmountains -58
scoreboard players set #gp driftmountains 61
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[-0.0039f,0.0000f,0.0005f,1.0000f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.9163f,0.0518f,-0.0120f,-0.3970f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[-0.0297f,-0.3979f,0.9159f,0.0442f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.2372f,0.0031f,0.0127f,0.9714f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0127f,0.9714f,0.2372f,0.0031f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3605f,0.8369f,0.2361f],left_rotation:[0.1796f,-0.0222f,0.0881f,0.9796f]}}
scoreboard players set #gx driftmountains 1309
scoreboard players set #gdx driftmountains 1008
scoreboard players set #gy driftmountains 66852
scoreboard players set #gdy driftmountains -13
scoreboard players set #gz driftmountains -70557
scoreboard players set #gdz driftmountains 668
scoreboard players set #gr driftmountains -5135
scoreboard players set #gdr driftmountains -27
scoreboard players set #gp driftmountains 61
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0000f,-0.0031f,1.0000f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.4793f,-0.0141f,-0.0674f,-0.8749f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[-0.0242f,-0.8727f,0.4834f,0.0645f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.2372f,0.0031f,0.0127f,0.9714f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0127f,0.9714f,0.2372f,0.0031f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3607f,0.8266f,0.0919f],left_rotation:[0.1696f,0.0666f,-0.3877f,0.9035f]}}
