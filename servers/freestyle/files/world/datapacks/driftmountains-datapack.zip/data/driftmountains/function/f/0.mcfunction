scoreboard players set #gx driftmountains -9349
scoreboard players set #gdx driftmountains -906
scoreboard players set #gy driftmountains 65000
scoreboard players set #gdy driftmountains 20
scoreboard players set #gz driftmountains 20317
scoreboard players set #gdz driftmountains -410
scoreboard players set #gr driftmountains 14163
scoreboard players set #gdr driftmountains -39
scoreboard players set #gp driftmountains -35
scoreboard players set #gdp driftmountains -91
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0001f,-0.0166f,0.9999f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.9401f,0.1106f,-0.2165f,0.2390f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.2428f,0.2631f,0.9336f,-0.0124f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.9652f,0.0126f,0.0034f,0.2612f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0034f,0.2612f,0.9652f,0.0126f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3843f,0.8655f,0.1072f],left_rotation:[-0.1122f,0.1548f,-0.8058f,-0.5604f]}}
particle minecraft:cloud -9.22 65.32 21.82 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -9.22 65.12 21.82 0.037 0.02 0.047 1 0 force
particle minecraft:cloud -7.91 65.32 20.79 0.35 0.18 0.35 0.02 2 force
playsound driftgen:grain.kaze.024 neutral @a -16.75 65.80 16.88 12 1
scoreboard players set #gx driftmountains -3513
scoreboard players set #gdx driftmountains -914
scoreboard players set #gy driftmountains 65000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 22530
scoreboard players set #gdz driftmountains -367
scoreboard players set #gr driftmountains 14507
scoreboard players set #gdr driftmountains -228
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0001f,-0.0209f,0.9998f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.9329f,0.1180f,-0.2455f,0.2355f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.2716f,0.2626f,0.9257f,-0.0206f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.9652f,0.0126f,0.0034f,0.2612f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0034f,0.2612f,0.9652f,0.0126f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3594f,0.8631f,0.2464f],left_rotation:[-0.1429f,0.1243f,-0.6170f,-0.7639f]}}
particle minecraft:cloud -3.43 65.32 24.14 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -3.43 65.12 24.14 0.032 0.02 0.046 1 0 force
particle minecraft:cloud -2.03 65.32 23.16 0.35 0.18 0.35 0.02 3 force
playsound driftgen:grain.onyx.025 neutral @a -10.73 65.54 19.49 12 1
scoreboard players set #gx driftmountains 3419
scoreboard players set #gdx driftmountains -926
scoreboard players set #gy driftmountains 65000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 24896
scoreboard players set #gdz driftmountains -220
scoreboard players set #gr driftmountains 14632
scoreboard players set #gdr driftmountains 64
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0001f,-0.0223f,0.9997f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.9084f,0.1378f,-0.3248f,0.2244f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.3502f,0.2598f,0.8989f,-0.0431f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.9652f,0.0126f,0.0034f,0.2612f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0034f,0.2612f,0.9652f,0.0126f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3530f,0.8383f,0.0965f],left_rotation:[-0.1856f,-0.0121f,0.0995f,-0.9774f]}}
particle minecraft:cloud 3.42 65.32 26.41 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 3.42 65.12 26.41 0.031 0.02 0.047 1 0 force
particle minecraft:cloud 4.81 65.32 25.48 0.35 0.18 0.35 0.02 3 force
playsound driftgen:grain.kaze.057 neutral @a -3.72 65.50 22.66 12 1
