scoreboard players set #gx driftmountains -81659
scoreboard players set #gdx driftmountains -822
scoreboard players set #gy driftmountains 70063
scoreboard players set #gdy driftmountains -17
scoreboard players set #gz driftmountains 19846
scoreboard players set #gdz driftmountains -959
scoreboard players set #gr driftmountains 17577
scoreboard players set #gdr driftmountains -3
scoreboard players set #gp driftmountains 65
scoreboard players set #gdp driftmountains -5
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[0.0061f,0.0001f,-0.0222f,0.9997f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.3212f,0.3089f,-0.0525f,0.8937f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.1468f,0.9041f,0.2905f,-0.2769f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.7918f,0.0104f,0.0080f,0.6106f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0080f,0.6106f,0.7918f,0.0104f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3556f,0.8552f,0.1031f],left_rotation:[-0.1814f,0.0579f,-0.2752f,-0.9423f]}}
particle minecraft:cloud -82.40 70.38 21.16 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -82.40 70.18 21.16 0.006 0.02 0.076 1 0 force
particle minecraft:cloud -80.73 70.38 21.04 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -74528
scoreboard players set #gdx driftmountains -945
scoreboard players set #gy driftmountains 70242
scoreboard players set #gdy driftmountains -26
scoreboard players set #gz driftmountains 27529
scoreboard players set #gdz driftmountains -994
scoreboard players set #gr driftmountains 17523
scoreboard players set #gdr driftmountains -7
scoreboard players set #gp driftmountains 84
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[-0.0038f,-0.0001f,-0.0223f,0.9997f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.4275f,-0.2674f,-0.1982f,-0.8405f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.1109f,-0.8243f,0.4580f,0.3138f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.7918f,0.0104f,0.0080f,0.6106f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0080f,0.6106f,0.7918f,0.0104f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3603f,0.8371f,0.2362f],left_rotation:[-0.1796f,0.0229f,-0.0921f,-0.9792f]}}
particle minecraft:cloud -75.27 70.56 28.96 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -75.27 70.36 28.96 0.007 0.02 0.083 1 0 force
particle minecraft:cloud -73.56 70.56 28.82 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -70337
scoreboard players set #gdx driftmountains -935
scoreboard players set #gy driftmountains 70353
scoreboard players set #gdy driftmountains -25
scoreboard players set #gz driftmountains 31701
scoreboard players set #gdz driftmountains -1003
scoreboard players set #gr driftmountains 17896
scoreboard players set #gdr driftmountains -75
scoreboard players set #gp driftmountains 77
scoreboard players set #gdp driftmountains 4
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[0.0041f,0.0001f,-0.0223f,0.9997f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.9106f,0.1322f,-0.3344f,0.2038f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.3576f,0.2401f,0.9017f,-0.0373f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.7918f,0.0104f,0.0080f,0.6106f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0080f,0.6106f,0.7918f,0.0104f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3540f,0.8354f,0.0954f],left_rotation:[-0.1836f,-0.0243f,0.1643f,-0.9688f]}}
particle minecraft:cloud -71.15 70.67 32.98 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -71.15 70.47 32.98 0.001 0.02 0.080 1 0 force
particle minecraft:cloud -69.48 70.67 32.95 0.35 0.18 0.35 0.02 3 force
