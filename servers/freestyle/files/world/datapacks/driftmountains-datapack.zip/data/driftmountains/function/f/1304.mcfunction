scoreboard players set #gx driftmountains -51811
scoreboard players set #gdx driftmountains 420
scoreboard players set #gy driftmountains 67811
scoreboard players set #gdy driftmountains -11
scoreboard players set #gz driftmountains -82251
scoreboard players set #gdz driftmountains -583
scoreboard players set #gr driftmountains -11277
scoreboard players set #gdr driftmountains 159
scoreboard players set #gp driftmountains 77
scoreboard players set #gdp driftmountains -1
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0001f,-0.0196f,0.9998f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.9275f,0.1204f,-0.2069f,0.2870f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.2382f,0.3103f,0.9200f,-0.0235f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.7396f,0.0097f,-0.0088f,-0.6730f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0088f,-0.6730f,0.7396f,0.0097f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3859f,0.8649f,0.1069f],left_rotation:[-0.1068f,0.1583f,-0.8254f,-0.5312f]}}
particle minecraft:cloud -53.30 68.13 -82.53 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -53.30 67.93 -82.53 -0.040 0.02 0.017 1 0 force
particle minecraft:cloud -52.65 68.13 -80.99 0.35 0.18 0.35 0.02 3 force
playsound driftgen:grain.kaze.035 neutral @a -47.94 68.21 -86.76 12 1
scoreboard players set #gx driftmountains -53943
scoreboard players set #gdx driftmountains 276
scoreboard players set #gy driftmountains 67894
scoreboard players set #gdy driftmountains -12
scoreboard players set #gz driftmountains -77944
scoreboard players set #gdz driftmountains -608
scoreboard players set #gr driftmountains -12267
scoreboard players set #gdr driftmountains 72
scoreboard players set #gp driftmountains 90
scoreboard players set #gdp driftmountains -4
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0001f,-0.0204f,0.9998f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.9657f,0.0501f,-0.2544f,-0.0151f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.2542f,0.0115f,0.9657f,0.0511f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.7396f,0.0097f,-0.0088f,-0.6730f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0088f,-0.6730f,0.7396f,0.0097f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3634f,0.8677f,0.2482f],left_rotation:[-0.1279f,0.1416f,-0.7082f,-0.6797f]}}
particle minecraft:cloud -55.55 68.21 -77.93 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -55.55 68.01 -77.93 -0.033 0.02 0.021 1 0 force
particle minecraft:cloud -54.63 68.21 -76.49 0.35 0.18 0.35 0.02 3 force
playsound driftgen:grain.onyx.036 neutral @a -51.32 68.30 -82.79 12 1
scoreboard players set #gx driftmountains -55161
scoreboard players set #gdx driftmountains 176
scoreboard players set #gy driftmountains 68041
scoreboard players set #gdy driftmountains -25
scoreboard players set #gz driftmountains -72348
scoreboard players set #gdz driftmountains -619
scoreboard players set #gr driftmountains -13426
scoreboard players set #gdr driftmountains 478
scoreboard players set #gp driftmountains 180
scoreboard players set #gdp driftmountains 8
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0001f,-0.0197f,0.9998f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.7578f,0.1515f,-0.0998f,0.6268f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.1663f,0.6407f,0.7460f,-0.0727f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.7396f,0.0097f,-0.0088f,-0.6730f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0088f,-0.6730f,0.7396f,0.0097f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.4012f,0.8455f,0.0993f],left_rotation:[-0.0093f,0.1843f,-0.9827f,-0.0143f]}}
particle minecraft:cloud -56.65 68.36 -72.07 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -56.65 68.16 -72.07 -0.028 0.02 0.027 1 0 force
particle minecraft:cloud -55.48 68.36 -70.87 0.35 0.18 0.35 0.02 3 force
playsound driftgen:grain.kaze.033 neutral @a -53.25 68.40 -77.45 12 1
