scoreboard players set #gx driftmountains -36676
scoreboard players set #gdx driftmountains 648
scoreboard players set #gy driftmountains 67425
scoreboard players set #gdy driftmountains -13
scoreboard players set #gz driftmountains -91610
scoreboard players set #gdz driftmountains 63
scoreboard players set #gr driftmountains -5084
scoreboard players set #gdr driftmountains 223
scoreboard players set #gp driftmountains 107
scoreboard players set #gdp driftmountains -17
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0001f,-0.0214f,0.9998f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.7762f,0.1787f,-0.1475f,0.5863f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.2099f,0.6050f,0.7617f,-0.0981f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.1128f,0.0015f,-0.0130f,-0.9935f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0130f,-0.9935f,0.1128f,0.0015f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3892f,0.8634f,0.1064f],left_rotation:[-0.0951f,0.1648f,-0.8624f,-0.4689f]}}
particle minecraft:cloud -37.13 67.75 -93.05 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -37.13 67.55 -93.05 -0.030 0.02 -0.025 1 0 force
particle minecraft:cloud -38.18 67.75 -91.76 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -41936
scoreboard players set #gdx driftmountains 579
scoreboard players set #gy driftmountains 67571
scoreboard players set #gdy driftmountains -15
scoreboard players set #gz driftmountains -91136
scoreboard players set #gdz driftmountains -201
scoreboard players set #gr driftmountains -7254
scoreboard players set #gdr driftmountains 325
scoreboard players set #gp driftmountains 107
scoreboard players set #gdp driftmountains 3
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.5542f,0.1981f,-0.0714f,0.8053f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.1564f,0.8173f,0.5364f,-0.1409f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.1128f,0.0015f,-0.0130f,-0.9935f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0130f,-0.9935f,0.1128f,0.0015f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3853f,0.8740f,0.2506f],left_rotation:[-0.0571f,0.1846f,-0.9385f,-0.2862f]}}
particle minecraft:cloud -42.98 67.89 -92.36 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -42.98 67.69 -92.36 -0.036 0.02 -0.011 1 0 force
particle minecraft:cloud -43.49 67.89 -90.73 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -45894
scoreboard players set #gdx driftmountains 374
scoreboard players set #gy driftmountains 67668
scoreboard players set #gdy driftmountains -9
scoreboard players set #gz driftmountains -88531
scoreboard players set #gdz driftmountains -361
scoreboard players set #gr driftmountains -10081
scoreboard players set #gdr driftmountains 132
scoreboard players set #gp driftmountains 86
scoreboard players set #gdp driftmountains 1
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[0.0061f,0.0001f,-0.0205f,0.9998f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.6891f,0.2020f,-0.1271f,0.6842f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.1997f,0.7013f,0.6717f,-0.1307f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.1128f,0.0015f,-0.0130f,-0.9935f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0130f,-0.9935f,0.1128f,0.0015f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3863f,0.8648f,0.1069f],left_rotation:[-0.1057f,0.1589f,-0.8291f,-0.5254f]}}
particle minecraft:cloud -47.29 67.99 -89.11 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -47.29 67.79 -89.11 -0.032 0.02 0.006 1 0 force
particle minecraft:cloud -46.98 67.99 -87.47 0.35 0.18 0.35 0.02 3 force
