scoreboard players set #gx driftmountains 25826
scoreboard players set #gdx driftmountains -364
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 43239
scoreboard players set #gdz driftmountains 973
scoreboard players set #gr driftmountains 7367
scoreboard players set #gdr driftmountains 126
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.7388f,-0.1967f,-0.3792f,-0.5212f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.3265f,-0.4842f,0.7636f,0.2755f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.1284f,0.0017f,-0.0130f,-0.9916f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0130f,-0.9916f,0.1284f,0.0017f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3806f,0.8212f,0.0898f],left_rotation:[-0.1199f,-0.1332f,0.7340f,-0.6550f]}}
particle minecraft:cloud 27.27 71.32 43.69 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 27.27 71.12 43.69 0.060 0.02 -0.017 1 0 force
particle minecraft:cloud 26.80 71.32 42.08 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains 28412
scoreboard players set #gdx driftmountains -98
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 35631
scoreboard players set #gdz driftmountains 1008
scoreboard players set #gr driftmountains 6776
scoreboard players set #gdr driftmountains 350
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[0.0060f,0.0001f,-0.0223f,0.9997f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.8669f,0.1497f,-0.4419f,0.1753f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.4628f,0.2227f,0.8560f,-0.0594f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.1284f,0.0017f,-0.0130f,-0.9916f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0130f,-0.9916f,0.1284f,0.0017f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.4060f,0.8544f,0.2430f],left_rotation:[-0.0529f,-0.1799f,0.9304f,-0.3151f]}}
particle minecraft:cloud 30.00 71.32 35.91 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 30.00 71.12 35.91 0.056 0.02 -0.023 1 0 force
particle minecraft:cloud 29.35 71.32 34.32 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains 26508
scoreboard players set #gdx driftmountains 236
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 31135
scoreboard players set #gdz driftmountains 898
scoreboard players set #gr driftmountains 3977
scoreboard players set #gdr driftmountains 335
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.0417f,0.4233f,0.0383f,0.9042f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.0565f,0.9052f,-0.0026f,-0.4212f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.1284f,0.0017f,-0.0130f,-0.9916f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0130f,-0.9916f,0.1284f,0.0017f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3795f,0.8211f,0.0898f],left_rotation:[-0.1231f,-0.1303f,0.7192f,-0.6712f]}}
particle minecraft:cloud 27.96 71.32 30.70 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 27.96 71.12 30.70 0.036 0.02 -0.044 1 0 force
particle minecraft:cloud 26.67 71.32 29.63 0.35 0.18 0.35 0.02 3 force
