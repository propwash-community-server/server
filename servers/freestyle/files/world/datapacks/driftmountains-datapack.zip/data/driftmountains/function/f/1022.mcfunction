scoreboard players set #gx driftmountains 23158
scoreboard players set #gdx driftmountains -554
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 48985
scoreboard players set #gdz driftmountains 930
scoreboard players set #gr driftmountains 8260
scoreboard players set #gdr driftmountains 165
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.5235f,0.3702f,-0.1904f,0.7434f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.2696f,0.7675f,0.4875f,-0.3172f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.9896f,0.0130f,0.0019f,0.1430f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0019f,0.1430f,0.9896f,0.0130f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3752f,0.8210f,0.0897f],left_rotation:[-0.1350f,-0.1184f,0.6576f,-0.7316f]}}
particle minecraft:cloud 24.51 71.32 49.65 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 24.51 71.12 49.65 0.064 0.02 -0.008 1 0 force
particle minecraft:cloud 24.30 71.32 47.99 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains 27028
scoreboard players set #gdx driftmountains -394
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 41542
scoreboard players set #gdz driftmountains 984
scoreboard players set #gr driftmountains 8351
scoreboard players set #gdr driftmountains 113
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.1726f,-0.4572f,-0.1527f,-0.8590f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.0633f,-0.8476f,0.2216f,0.4779f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.9896f,0.0130f,0.0019f,0.1430f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0019f,0.1430f,0.9896f,0.0130f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.4034f,0.8616f,0.2458f],left_rotation:[-0.0247f,-0.1882f,0.9684f,-0.1617f]}}
particle minecraft:cloud 28.48 71.32 42.24 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 28.48 71.12 42.24 0.062 0.02 -0.007 1 0 force
particle minecraft:cloud 28.29 71.32 40.54 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains 27312
scoreboard players set #gdx driftmountains -29
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 36784
scoreboard players set #gdz driftmountains 915
scoreboard players set #gr driftmountains 5939
scoreboard players set #gdr driftmountains 293
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[-0.0026f,-0.0001f,-0.0223f,0.9997f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.8993f,0.0378f,-0.4336f,-0.0421f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.4315f,0.0032f,0.9003f,0.0565f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.9896f,0.0130f,0.0019f,0.1430f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0019f,0.1430f,0.9896f,0.0130f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3845f,0.8221f,0.0902f],left_rotation:[-0.1078f,-0.1431f,0.7847f,-0.5934f]}}
particle minecraft:cloud 28.82 71.32 36.86 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 28.82 71.12 36.86 0.047 0.02 -0.028 1 0 force
particle minecraft:cloud 27.97 71.32 35.42 0.35 0.18 0.35 0.02 3 force
