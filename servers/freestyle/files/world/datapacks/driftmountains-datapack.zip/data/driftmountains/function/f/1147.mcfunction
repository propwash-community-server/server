scoreboard players set #gx driftmountains -96441
scoreboard players set #gdx driftmountains -340
scoreboard players set #gy driftmountains 70029
scoreboard players set #gdy driftmountains 2
scoreboard players set #gz driftmountains 497
scoreboard players set #gdz driftmountains -891
scoreboard players set #gr driftmountains -15142
scoreboard players set #gdr driftmountains 290
scoreboard players set #gp driftmountains -11
scoreboard players set #gdp driftmountains 3
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[-0.0034f,-0.0001f,-0.0223f,0.9997f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.7099f,0.2819f,-0.2482f,0.5958f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.3122f,0.6252f,0.6842f,-0.2088f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.9825f,0.0129f,0.0024f,0.1860f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0024f,0.1860f,0.9825f,0.0129f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3580f,0.8292f,0.0929f],left_rotation:[-0.1754f,-0.0528f,0.3147f,-0.9313f]}}
particle minecraft:cloud -97.78 70.35 1.20 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -97.78 70.15 1.20 -0.027 0.02 0.050 1 0 force
particle minecraft:cloud -96.31 70.35 2.00 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -92016
scoreboard players set #gdx driftmountains -650
scoreboard players set #gy driftmountains 69994
scoreboard players set #gdy driftmountains 4
scoreboard players set #gz driftmountains 7786
scoreboard players set #gdz driftmountains -792
scoreboard players set #gr driftmountains -17738
scoreboard players set #gdr driftmountains 372
scoreboard players set #gp driftmountains -16
scoreboard players set #gdp driftmountains -1
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.0507f,0.3472f,0.0371f,0.9357f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.0611f,0.9370f,0.0145f,-0.3437f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.9825f,0.0129f,0.0024f,0.1860f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0024f,0.1860f,0.9825f,0.0129f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3660f,0.8317f,0.2341f],left_rotation:[-0.1793f,-0.0075f,0.0642f,-0.9817f]}}
particle minecraft:cloud -92.93 70.31 9.11 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -92.93 70.11 9.11 -0.003 0.02 0.061 1 0 force
particle minecraft:cloud -91.22 70.31 9.19 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -88170
scoreboard players set #gdx driftmountains -744
scoreboard players set #gy driftmountains 69983
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 12060
scoreboard players set #gdz driftmountains -842
scoreboard players set #gr driftmountains 17625
scoreboard players set #gdr driftmountains 84
scoreboard players set #gp driftmountains 3
scoreboard players set #gdp driftmountains -6
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.9029f,-0.0425f,-0.3230f,-0.2805f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.2953f,-0.2481f,0.9123f,0.1376f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.9825f,0.0129f,0.0024f,0.1860f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0024f,0.1860f,0.9825f,0.0129f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3533f,0.8502f,0.1012f],left_rotation:[-0.1857f,0.0364f,-0.1594f,-0.9689f]}}
particle minecraft:cloud -88.92 70.30 13.37 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -88.92 70.10 13.37 0.004 0.02 0.062 1 0 force
particle minecraft:cloud -87.25 70.30 13.26 0.35 0.18 0.35 0.02 3 force
