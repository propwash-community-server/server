scoreboard players set #gx driftmountains 6142
scoreboard players set #gdx driftmountains 453
scoreboard players set #gy driftmountains 70912
scoreboard players set #gdy driftmountains 41
scoreboard players set #gz driftmountains -15927
scoreboard players set #gdz driftmountains 782
scoreboard players set #gr driftmountains 1232
scoreboard players set #gdr driftmountains -89
scoreboard players set #gp driftmountains -221
scoreboard players set #gdp driftmountains 50
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.8286f,0.2121f,-0.2858f,0.4321f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.3328f,0.4645f,0.8109f,-0.1262f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.4660f,0.0061f,0.0116f,0.8847f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0116f,0.8847f,0.4660f,0.0061f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3534f,0.8369f,0.0960f],left_rotation:[-0.1848f,-0.0178f,0.1296f,-0.9740f]}}
particle minecraft:cloud 7.23 71.23 -16.98 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 7.23 71.03 -16.98 0.012 0.02 -0.053 1 0 force
particle minecraft:cloud 5.59 71.23 -17.34 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains 3240
scoreboard players set #gdx driftmountains 506
scoreboard players set #gy driftmountains 70523
scoreboard players set #gdy driftmountains 48
scoreboard players set #gz driftmountains -20922
scoreboard players set #gdz driftmountains 674
scoreboard players set #gr driftmountains 711
scoreboard players set #gdr driftmountains 262
scoreboard players set #gp driftmountains -193
scoreboard players set #gdp driftmountains -62
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.3861f,0.3068f,-0.0764f,0.8666f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.1679f,0.8794f,0.3560f,-0.2679f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.4660f,0.0061f,0.0116f,0.8847f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0116f,0.8847f,0.4660f,0.0061f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3567f,0.8439f,0.2388f],left_rotation:[-0.1752f,0.0534f,-0.2489f,-0.9511f]}}
particle minecraft:cloud 4.26 70.84 -22.17 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 4.26 70.64 -22.17 0.006 0.02 -0.052 1 0 force
particle minecraft:cloud 2.56 70.84 -22.38 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -657
scoreboard players set #gdx driftmountains 619
scoreboard players set #gy driftmountains 70521
scoreboard players set #gdy driftmountains -9
scoreboard players set #gz driftmountains -24059
scoreboard players set #gdz driftmountains 448
scoreboard players set #gr driftmountains -1019
scoreboard players set #gdr driftmountains 153
scoreboard players set #gp driftmountains 37
scoreboard players set #gdp driftmountains 14
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.9340f,0.0363f,-0.3516f,-0.0523f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.3481f,-0.0157f,0.9353f,0.0617f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.4660f,0.0061f,0.0116f,0.8847f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0116f,0.8847f,0.4660f,0.0061f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3531f,0.8380f,0.0964f],left_rotation:[-0.1855f,-0.0134f,0.1062f,-0.9768f]}}
particle minecraft:cloud -0.06 70.84 -25.45 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -0.06 70.64 -25.45 -0.009 0.02 -0.049 1 0 force
particle minecraft:cloud -1.70 70.84 -25.15 0.35 0.18 0.35 0.02 3 force
