scoreboard players set #gx driftmountains 4284
scoreboard players set #gdx driftmountains 483
scoreboard players set #gy driftmountains 70671
scoreboard players set #gdy driftmountains 66
scoreboard players set #gz driftmountains -18942
scoreboard players set #gdz driftmountains 729
scoreboard players set #gr driftmountains 1115
scoreboard players set #gdr driftmountains 127
scoreboard players set #gp driftmountains -311
scoreboard players set #gdp driftmountains 5
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.7927f,-0.1350f,-0.3164f,-0.5033f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.2653f,-0.4728f,0.8112f,0.2191f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.9995f,0.0131f,0.0004f,0.0290f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0004f,0.0290f,0.9995f,0.0131f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3524f,0.8421f,0.0980f],left_rotation:[-0.1871f,0.0037f,0.0151f,-0.9822f]}}
particle minecraft:cloud 5.35 70.99 -20.02 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 5.35 70.79 -20.02 0.010 0.02 -0.051 1 0 force
particle minecraft:cloud 3.71 70.99 -20.34 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains 842
scoreboard players set #gdx driftmountains 634
scoreboard players set #gy driftmountains 70499
scoreboard players set #gdy driftmountains -13
scoreboard players set #gz driftmountains -23362
scoreboard players set #gdz driftmountains 556
scoreboard players set #gr driftmountains -495
scoreboard players set #gdr driftmountains 254
scoreboard players set #gp driftmountains 71
scoreboard players set #gdp driftmountains -23
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.9423f,0.0720f,-0.3233f,0.0483f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.3302f,0.0825f,0.9399f,0.0266f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.9995f,0.0131f,0.0004f,0.0290f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0004f,0.0290f,0.9995f,0.0131f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3599f,0.8377f,0.2364f],left_rotation:[-0.1794f,0.0259f,-0.1072f,-0.9776f]}}
particle minecraft:cloud 1.58 70.82 -24.80 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 1.58 70.62 -24.80 -0.004 0.02 -0.051 1 0 force
particle minecraft:cloud -0.13 70.82 -24.65 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -3237
scoreboard players set #gdx driftmountains 638
scoreboard players set #gy driftmountains 70470
scoreboard players set #gdy driftmountains 26
scoreboard players set #gz driftmountains -25824
scoreboard players set #gdz driftmountains 435
scoreboard players set #gr driftmountains -1061
scoreboard players set #gdr driftmountains -81
scoreboard players set #gp driftmountains -163
scoreboard players set #gdp driftmountains 47
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.0410f,-0.3702f,-0.0729f,-0.9252f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[-0.0240f,-0.9226f,0.0801f,0.3765f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.9995f,0.0131f,0.0004f,0.0290f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0004f,0.0290f,0.9995f,0.0131f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3585f,0.8286f,0.0927f],left_rotation:[-0.1742f,-0.0558f,0.3306f,-0.9258f]}}
particle minecraft:cloud -2.65 70.79 -27.22 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -2.65 70.59 -27.22 -0.008 0.02 -0.045 1 0 force
particle minecraft:cloud -4.29 70.79 -26.91 0.35 0.18 0.35 0.02 3 force
