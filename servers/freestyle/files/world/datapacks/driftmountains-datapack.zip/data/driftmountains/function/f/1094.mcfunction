scoreboard players set #gx driftmountains -49834
scoreboard players set #gdx driftmountains -1211
scoreboard players set #gy driftmountains 70471
scoreboard players set #gdy driftmountains 5
scoreboard players set #gz driftmountains 47060
scoreboard players set #gdz driftmountains -532
scoreboard players set #gr driftmountains 15849
scoreboard players set #gdr driftmountains 135
scoreboard players set #gp driftmountains -12
scoreboard players set #gdp driftmountains -4
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.5315f,0.3366f,-0.1668f,0.7592f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.2475f,0.7809f,0.4991f,-0.2826f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.9493f,0.0124f,0.0041f,0.3140f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0041f,0.3140f,0.9493f,0.0124f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3580f,0.8292f,0.0929f],left_rotation:[-0.1753f,-0.0529f,0.3157f,-0.9310f]}}
particle minecraft:cloud -50.15 70.79 48.54 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -50.15 70.59 48.54 0.029 0.02 0.074 1 0 force
particle minecraft:cloud -48.60 70.79 47.93 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -39695
scoreboard players set #gdx driftmountains -1120
scoreboard players set #gy driftmountains 70555
scoreboard players set #gdy driftmountains -26
scoreboard players set #gz driftmountains 51079
scoreboard players set #gdz driftmountains -432
scoreboard players set #gr driftmountains 15458
scoreboard players set #gdr driftmountains 22
scoreboard players set #gp driftmountains 98
scoreboard players set #gdp driftmountains -16
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.1909f,-0.3422f,-0.1291f,-0.9109f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.0341f,-0.9024f,0.2280f,0.3642f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.9493f,0.0124f,0.0041f,0.3140f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0041f,0.3140f,0.9493f,0.0124f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3733f,0.8283f,0.2327f],left_rotation:[-0.1742f,-0.0386f,0.2228f,-0.9584f]}}
particle minecraft:cloud -39.88 70.88 52.68 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -39.88 70.68 52.68 0.033 0.02 0.069 1 0 force
particle minecraft:cloud -38.34 70.88 51.94 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -35020
scoreboard players set #gdx driftmountains -1209
scoreboard players set #gy driftmountains 70705
scoreboard players set #gdy driftmountains -42
scoreboard players set #gz driftmountains 53153
scoreboard players set #gdz driftmountains -398
scoreboard players set #gr driftmountains 15399
scoreboard players set #gdr driftmountains 7
scoreboard players set #gp driftmountains 134
scoreboard players set #gdp driftmountains -5
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.9210f,0.0400f,-0.3854f,-0.0400f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.3834f,0.0003f,0.9219f,0.0566f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.9493f,0.0124f,0.0041f,0.3140f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0041f,0.3140f,0.9493f,0.0124f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3622f,0.8255f,0.0915f],left_rotation:[-0.1664f,-0.0733f,0.4228f,-0.8878f]}}
particle minecraft:cloud -35.22 71.03 54.65 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -35.22 70.83 54.65 0.033 0.02 0.068 1 0 force
particle minecraft:cloud -33.72 71.03 53.92 0.35 0.18 0.35 0.02 3 force
