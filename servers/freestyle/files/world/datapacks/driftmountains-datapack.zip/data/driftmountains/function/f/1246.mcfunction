scoreboard players set #gx driftmountains -55066
scoreboard players set #gdx driftmountains 170
scoreboard players set #gy driftmountains 68724
scoreboard players set #gdy driftmountains -20
scoreboard players set #gz driftmountains -43419
scoreboard players set #gdz driftmountains -668
scoreboard players set #gr driftmountains 16296
scoreboard players set #gdr driftmountains -181
scoreboard players set #gp driftmountains 138
scoreboard players set #gdp driftmountains 1
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,0.0001f,0.0198f,0.9998f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.4487f,-0.1664f,0.1466f,0.8657f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[-0.0564f,0.8551f,0.4687f,0.2144f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.9371f,0.0123f,-0.0046f,-0.3489f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0046f,-0.3489f,0.9371f,0.0123f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3942f,0.8278f,0.0924f],left_rotation:[-0.0689f,-0.1664f,0.9017f,-0.3930f]}}
particle minecraft:cloud -55.49 69.04 -41.97 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud -53.90 69.04 -42.46 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -53.90 68.84 -42.46 0.012 0.02 0.039 1 0 force
scoreboard players set #gx driftmountains -58108
scoreboard players set #gdx driftmountains 400
scoreboard players set #gy driftmountains 68860
scoreboard players set #gdy driftmountains -23
scoreboard players set #gz driftmountains -39846
scoreboard players set #gdz driftmountains -594
scoreboard players set #gr driftmountains 17987
scoreboard players set #gdr driftmountains -235
scoreboard players set #gp driftmountains 148
scoreboard players set #gdp driftmountains -2
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[-0.0039f,0.0001f,0.0215f,0.9998f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.4417f,0.2387f,0.0616f,-0.8626f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[-0.1526f,-0.8739f,0.4191f,-0.1936f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.9371f,0.0123f,-0.0046f,-0.3489f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0046f,-0.3489f,0.9371f,0.0123f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.4033f,0.8397f,0.2372f],left_rotation:[-0.1047f,-0.1499f,0.7834f,-0.5941f]}}
particle minecraft:cloud -58.96 69.18 -38.48 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud -57.25 69.18 -38.48 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -57.25 68.98 -38.48 0.000 0.02 0.037 1 0 force
scoreboard players set #gx driftmountains -61066
scoreboard players set #gdx driftmountains 411
scoreboard players set #gy driftmountains 69039
scoreboard players set #gdy driftmountains -20
scoreboard players set #gz driftmountains -35211
scoreboard players set #gdz driftmountains -396
scoreboard players set #gr driftmountains -16570
scoreboard players set #gdr driftmountains -489
scoreboard players set #gp driftmountains 156
scoreboard players set #gdp driftmountains 14
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,0.0001f,0.0209f,0.9998f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.9775f,0.0722f,0.1635f,-0.1118f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[-0.1761f,-0.1296f,0.9753f,0.0302f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.9371f,0.0123f,-0.0046f,-0.3489f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0046f,-0.3489f,0.9371f,0.0123f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.4013f,0.8449f,0.0991f],left_rotation:[0.0071f,-0.1843f,0.9828f,0.0025f]}}
particle minecraft:cloud -62.19 69.36 -34.20 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud -60.57 69.36 -33.78 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -60.57 69.16 -33.78 -0.009 0.02 0.036 1 0 force
