scoreboard players set #gx driftmountains -2433
scoreboard players set #gdx driftmountains 659
scoreboard players set #gy driftmountains 70506
scoreboard players set #gdy driftmountains 14
scoreboard players set #gz driftmountains -25041
scoreboard players set #gdz driftmountains 444
scoreboard players set #gr driftmountains -1066
scoreboard players set #gdr driftmountains 24
scoreboard players set #gp driftmountains -94
scoreboard players set #gdp driftmountains 46
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.7300f,0.2795f,-0.2699f,0.5623f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.3305f,0.5937f,0.7046f,-0.2043f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.2608f,0.0034f,-0.0126f,-0.9653f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0126f,-0.9653f,0.2608f,0.0034f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3626f,0.8252f,0.0914f],left_rotation:[-0.1655f,-0.0750f,0.4317f,-0.8835f]}}
particle minecraft:cloud -1.85 70.83 -26.43 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -1.85 70.63 -26.43 -0.009 0.02 -0.047 1 0 force
particle minecraft:cloud -3.49 70.83 -26.12 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -6216
scoreboard players set #gdx driftmountains 579
scoreboard players set #gy driftmountains 70201
scoreboard players set #gdy driftmountains 61
scoreboard players set #gz driftmountains -28371
scoreboard players set #gdz driftmountains 329
scoreboard players set #gr driftmountains -1596
scoreboard players set #gdr driftmountains 245
scoreboard players set #gp driftmountains -386
scoreboard players set #gdp driftmountains 37
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0001f,-0.0223f,0.9997f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.8687f,0.1714f,-0.2448f,0.3950f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.2876f,0.4229f,0.8555f,-0.0811f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.2608f,0.0034f,-0.0126f,-0.9653f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0126f,-0.9653f,0.2608f,0.0034f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3557f,0.8518f,0.2419f],left_rotation:[-0.1659f,0.0835f,-0.4044f,-0.8955f]}}
particle minecraft:cloud -5.77 70.52 -29.92 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -5.77 70.32 -29.92 -0.012 0.02 -0.043 1 0 force
particle minecraft:cloud -7.41 70.52 -29.45 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -10832
scoreboard players set #gdx driftmountains 785
scoreboard players set #gy driftmountains 69796
scoreboard players set #gdy driftmountains 60
scoreboard players set #gz driftmountains -29135
scoreboard players set #gdz driftmountains 130
scoreboard players set #gr driftmountains -3450
scoreboard players set #gdr driftmountains 182
scoreboard players set #gp driftmountains -289
scoreboard players set #gdp driftmountains -6
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.0419f,0.3572f,0.0400f,0.9322f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.0577f,0.9331f,0.0046f,-0.3548f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.2608f,0.0034f,-0.0126f,-0.9653f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0126f,-0.9653f,0.2608f,0.0034f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3540f,0.8354f,0.0954f],left_rotation:[-0.1836f,-0.0241f,0.1634f,-0.9690f]}}
particle minecraft:cloud -10.86 70.12 -30.65 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -10.86 69.92 -30.65 -0.028 0.02 -0.041 1 0 force
particle minecraft:cloud -12.23 70.12 -29.70 0.35 0.18 0.35 0.02 3 force
