scoreboard players set #gx driftmountains -63160
scoreboard players set #gdx driftmountains 569
scoreboard players set #gy driftmountains 69104
scoreboard players set #gdy driftmountains -12
scoreboard players set #gz driftmountains -33074
scoreboard players set #gdz driftmountains -254
scoreboard players set #gr driftmountains -14294
scoreboard players set #gdr driftmountains -487
scoreboard players set #gp driftmountains 94
scoreboard players set #gdp driftmountains 5
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[0.0061f,-0.0001f,0.0182f,0.9998f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.8736f,0.1363f,0.1512f,-0.4421f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[-0.1985f,-0.4604f,0.8640f,-0.0453f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.9935f,0.0130f,0.0015f,0.1132f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0015f,0.1132f,0.9935f,0.0130f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3991f,0.8343f,0.0949f],left_rotation:[-0.0376f,-0.1776f,0.9558f,-0.2310f]}}
particle minecraft:cloud -64.59 69.42 -32.57 0.35 0.18 0.35 0.02 2 force
particle minecraft:cloud -63.25 69.42 -31.57 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -63.25 69.22 -31.57 -0.023 0.02 0.030 1 0 force
playsound driftgen:grain.kaze.032 neutral @a -59.34 69.48 -35.72 12 1
scoreboard players set #gx driftmountains -69330
scoreboard players set #gdx driftmountains 664
scoreboard players set #gy driftmountains 69204
scoreboard players set #gdy driftmountains -10
scoreboard players set #gz driftmountains -32480
scoreboard players set #gdz driftmountains -262
scoreboard players set #gr driftmountains -11802
scoreboard players set #gdr driftmountains -73
scoreboard players set #gp driftmountains 77
scoreboard players set #gdp driftmountains 2
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[0.0061f,-0.0000f,0.0038f,1.0000f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.8041f,0.0026f,0.0853f,0.5884f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[-0.0240f,0.5826f,0.8082f,0.0819f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.9935f,0.0130f,0.0015f,0.1132f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0015f,0.1132f,0.9935f,0.0130f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3579f,0.8605f,0.2453f],left_rotation:[0.1495f,-0.1148f,0.5677f,0.8014f]}}
playsound driftgen:grain.onyx.047 neutral @a -64.17 69.62 -34.50 12 1
scoreboard players set #gx driftmountains -74509
scoreboard players set #gdx driftmountains 671
scoreboard players set #gy driftmountains 69278
scoreboard players set #gdy driftmountains -9
scoreboard players set #gz driftmountains -28949
scoreboard players set #gdz driftmountains -311
scoreboard players set #gr driftmountains -12515
scoreboard players set #gdr driftmountains 226
scoreboard players set #gp driftmountains 72
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,0.0000f,0.0063f,1.0000f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.9911f,0.0448f,0.0858f,0.0918f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[-0.0767f,0.0833f,0.9918f,0.0591f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.9935f,0.0130f,0.0015f,0.1132f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0015f,0.1132f,0.9935f,0.0130f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3738f,0.8664f,0.1075f],left_rotation:[0.1418f,-0.1297f,0.6663f,0.7205f]}}
particle minecraft:cloud -76.02 69.60 -28.91 0.35 0.18 0.35 0.02 2 force
particle minecraft:cloud -75.06 69.60 -27.54 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -75.06 69.40 -27.54 -0.037 0.02 0.026 1 0 force
playsound driftgen:grain.kaze.045 neutral @a -68.85 69.70 -31.45 12 1
