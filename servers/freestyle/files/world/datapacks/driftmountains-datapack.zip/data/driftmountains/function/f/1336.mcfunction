scoreboard players set #gx driftmountains -33419
scoreboard players set #gdx driftmountains 649
scoreboard players set #gy driftmountains 67361
scoreboard players set #gdy driftmountains -13
scoreboard players set #gz driftmountains -90975
scoreboard players set #gdz driftmountains 224
scoreboard players set #gr driftmountains -4037
scoreboard players set #gdr driftmountains 240
scoreboard players set #gp driftmountains 91
scoreboard players set #gdp driftmountains -1
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0001f,-0.0196f,0.9998f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.3216f,-0.1806f,-0.1197f,-0.9217f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.0235f,-0.9142f,0.3424f,0.2154f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.1360f,0.0018f,0.0130f,0.9906f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0130f,0.9906f,0.1360f,0.0018f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3947f,0.8594f,0.1048f],left_rotation:[-0.0710f,0.1750f,-0.9211f,-0.3403f]}}
particle minecraft:cloud -33.60 67.68 -92.48 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -33.60 67.48 -92.48 -0.027 0.02 -0.031 1 0 force
particle minecraft:cloud -34.87 67.68 -91.39 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -38952
scoreboard players set #gdx driftmountains 594
scoreboard players set #gy driftmountains 67490
scoreboard players set #gdy driftmountains -18
scoreboard players set #gz driftmountains -91732
scoreboard players set #gdz driftmountains 15
scoreboard players set #gr driftmountains -5266
scoreboard players set #gdr driftmountains 211
scoreboard players set #gp driftmountains 137
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.9068f,-0.0278f,-0.2140f,-0.3622f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.1771f,-0.3417f,0.9147f,0.1233f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.1360f,0.0018f,0.0130f,0.9906f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0130f,0.9906f,0.1360f,0.0018f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3828f,0.8743f,0.2507f],left_rotation:[-0.0656f,0.1818f,-0.9230f,-0.3329f]}}
particle minecraft:cloud -39.52 67.81 -93.24 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -39.52 67.61 -93.24 -0.029 0.02 -0.022 1 0 force
particle minecraft:cloud -40.56 67.81 -91.88 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -43622
scoreboard players set #gdx driftmountains 433
scoreboard players set #gy driftmountains 67612
scoreboard players set #gdy driftmountains -11
scoreboard players set #gz driftmountains -90434
scoreboard players set #gdz driftmountains -292
scoreboard players set #gr driftmountains -8993
scoreboard players set #gdr driftmountains 219
scoreboard players set #gp driftmountains 97
scoreboard players set #gdp driftmountains 5
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[0.0061f,0.0001f,-0.0214f,0.9998f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.9026f,-0.0327f,-0.2227f,-0.3670f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.1854f,-0.3456f,0.9110f,0.1277f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.1360f,0.0018f,0.0130f,0.9906f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0130f,0.9906f,0.1360f,0.0018f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3918f,0.8618f,0.1057f],left_rotation:[-0.0847f,0.1697f,-0.8907f,-0.4130f]}}
particle minecraft:cloud -44.88 67.93 -91.27 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -44.88 67.73 -91.27 -0.038 0.02 -0.000 1 0 force
particle minecraft:cloud -44.88 67.93 -89.60 0.35 0.18 0.35 0.02 3 force
