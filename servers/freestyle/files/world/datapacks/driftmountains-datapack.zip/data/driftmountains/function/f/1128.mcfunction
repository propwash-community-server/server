scoreboard players set #gx driftmountains -84087
scoreboard players set #gdx driftmountains -783
scoreboard players set #gy driftmountains 70016
scoreboard players set #gdy driftmountains -11
scoreboard players set #gz driftmountains 16994
scoreboard players set #gdz driftmountains -935
scoreboard players set #gr driftmountains 17608
scoreboard players set #gdr driftmountains 17
scoreboard players set #gp driftmountains 47
scoreboard players set #gdp driftmountains -8
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.8599f,0.1799f,-0.2525f,0.4055f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.2965f,0.4343f,0.8458f,-0.0905f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.9926f,0.0130f,-0.0016f,-0.1208f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0016f,-0.1208f,0.9926f,0.0130f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3565f,0.8565f,0.1036f],left_rotation:[-0.1798f,0.0635f,-0.3056f,-0.9328f]}}
particle minecraft:cloud -84.83 70.34 18.31 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -84.83 70.14 18.31 0.005 0.02 0.073 1 0 force
particle minecraft:cloud -83.17 70.34 18.19 0.35 0.18 0.35 0.02 3 force
playsound driftgen:grain.kaze.026 neutral @a -90.10 70.49 9.83 12 1
scoreboard players set #gx driftmountains -77330
scoreboard players set #gdx driftmountains -896
scoreboard players set #gy driftmountains 70167
scoreboard players set #gdy driftmountains -23
scoreboard players set #gz driftmountains 24560
scoreboard players set #gdz driftmountains -966
scoreboard players set #gr driftmountains 17556
scoreboard players set #gdr driftmountains 22
scoreboard players set #gp driftmountains 80
scoreboard players set #gdp driftmountains -2
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.2922f,0.3252f,-0.0476f,0.8981f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.1423f,0.9080f,0.2597f,-0.2963f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.9926f,0.0130f,-0.0016f,-0.1208f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0016f,-0.1208f,0.9926f,0.0130f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3592f,0.8387f,0.2368f],left_rotation:[-0.1790f,0.0306f,-0.1314f,-0.9746f]}}
particle minecraft:cloud -78.08 70.49 25.99 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -78.08 70.29 25.99 0.006 0.02 0.080 1 0 force
particle minecraft:cloud -76.37 70.49 25.85 0.35 0.18 0.35 0.02 3 force
playsound driftgen:grain.onyx.013 neutral @a -84.15 70.52 17.02 12 1
scoreboard players set #gx driftmountains -73070
scoreboard players set #gdx driftmountains -886
scoreboard players set #gy driftmountains 70278
scoreboard players set #gdy driftmountains -25
scoreboard players set #gz driftmountains 28762
scoreboard players set #gdz driftmountains -960
scoreboard players set #gr driftmountains 17726
scoreboard players set #gdr driftmountains -32
scoreboard players set #gp driftmountains 83
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.7935f,-0.1344f,-0.3164f,-0.5021f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.2654f,-0.4716f,0.8120f,0.2185f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.9926f,0.0130f,-0.0016f,-0.1208f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0016f,-0.1208f,0.9926f,0.0130f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3524f,0.8423f,0.0981f],left_rotation:[-0.1871f,0.0042f,0.0126f,-0.9822f]}}
particle minecraft:cloud -73.84 70.60 30.06 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -73.84 70.40 30.06 0.004 0.02 0.078 1 0 force
particle minecraft:cloud -72.18 70.60 29.98 0.35 0.18 0.35 0.02 3 force
playsound driftgen:grain.kaze.013 neutral @a -79.90 70.60 21.32 12 1
