scoreboard players set #gx driftmountains -24788
scoreboard players set #gdx driftmountains 688
scoreboard players set #gy driftmountains 67213
scoreboard players set #gdy driftmountains -11
scoreboard players set #gz driftmountains -87037
scoreboard players set #gdz driftmountains 370
scoreboard players set #gr driftmountains -3325
scoreboard players set #gdr driftmountains 38
scoreboard players set #gp driftmountains 69
scoreboard players set #gdp driftmountains -1
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0001f,-0.0175f,0.9998f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.9618f,0.0851f,-0.2245f,0.1318f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.2396f,0.1561f,0.9581f,0.0155f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.9876f,0.0129f,0.0020f,0.1564f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0020f,0.1564f,0.9876f,0.0129f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3856f,0.8650f,0.1070f],left_rotation:[-0.1078f,0.1577f,-0.8220f,-0.5365f]}}
particle minecraft:cloud -24.78 67.53 -88.55 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -24.78 67.33 -88.55 -0.026 0.02 -0.039 1 0 force
particle minecraft:cloud -26.18 67.53 -87.63 0.35 0.18 0.35 0.02 2 force
scoreboard players set #gx driftmountains -30853
scoreboard players set #gdx driftmountains 578
scoreboard players set #gy driftmountains 67312
scoreboard players set #gdy driftmountains -10
scoreboard players set #gz driftmountains -89844
scoreboard players set #gdz driftmountains 266
scoreboard players set #gr driftmountains -3504
scoreboard players set #gdr driftmountains 42
scoreboard players set #gp driftmountains 78
scoreboard players set #gdp driftmountains -1
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0001f,-0.0187f,0.9998f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.8952f,-0.0414f,-0.2389f,-0.3740f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.2009f,-0.3509f,0.9045f,0.1357f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.9876f,0.0129f,0.0020f,0.1564f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0020f,0.1564f,0.9876f,0.0129f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3701f,0.8720f,0.2499f],left_rotation:[-0.1060f,0.1605f,-0.8081f,-0.5568f]}}
particle minecraft:cloud -30.94 67.63 -91.45 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -30.94 67.43 -91.45 -0.024 0.02 -0.034 1 0 force
particle minecraft:cloud -32.34 67.63 -90.47 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -37044
scoreboard players set #gdx driftmountains 678
scoreboard players set #gy driftmountains 67436
scoreboard players set #gdy driftmountains -16
scoreboard players set #gz driftmountains -92321
scoreboard players set #gdz driftmountains 114
scoreboard players set #gr driftmountains -4725
scoreboard players set #gdr driftmountains 323
scoreboard players set #gp driftmountains 115
scoreboard players set #gdp driftmountains -17
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0001f,-0.0214f,0.9998f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.1629f,-0.1785f,-0.0841f,-0.9667f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[-0.0170f,-0.9632f,0.1825f,0.1966f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.9876f,0.0129f,0.0020f,0.1564f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0020f,0.1564f,0.9876f,0.0129f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3995f,0.8522f,0.1020f],left_rotation:[-0.0377f,0.1827f,-0.9686f,-0.1640f]}}
particle minecraft:cloud -37.40 67.76 -93.79 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -37.40 67.56 -93.79 -0.026 0.02 -0.024 1 0 force
particle minecraft:cloud -38.54 67.76 -92.56 0.35 0.18 0.35 0.02 3 force
