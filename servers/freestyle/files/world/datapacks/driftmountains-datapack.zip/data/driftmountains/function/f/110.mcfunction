scoreboard players set #gx driftmountains -451
scoreboard players set #gdx driftmountains 657
scoreboard players set #gy driftmountains 70517
scoreboard players set #gdy driftmountains -11
scoreboard players set #gz driftmountains -23676
scoreboard players set #gdz driftmountains 485
scoreboard players set #gr driftmountains -881
scoreboard players set #gdr driftmountains 186
scoreboard players set #gp driftmountains 55
scoreboard players set #gdp driftmountains 6
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.9201f,0.1148f,-0.3398f,0.1571f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.3582f,0.1937f,0.9132f,-0.0187f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.4918f,0.0064f,0.0114f,0.8706f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0114f,0.8706f,0.4918f,0.0064f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3539f,0.8358f,0.0955f],left_rotation:[-0.1839f,-0.0227f,0.1557f,-0.9702f]}}
particle minecraft:cloud 0.18 70.84 -25.05 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 0.18 70.64 -25.05 -0.007 0.02 -0.048 1 0 force
particle minecraft:cloud -1.47 70.84 -24.79 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -4251
scoreboard players set #gdx driftmountains 601
scoreboard players set #gy driftmountains 70390
scoreboard players set #gdy driftmountains 42
scoreboard players set #gz driftmountains -27124
scoreboard players set #gdz driftmountains 426
scoreboard players set #gr driftmountains -1016
scoreboard players set #gdr driftmountains 93
scoreboard players set #gp driftmountains -254
scoreboard players set #gdp driftmountains 42
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.9151f,0.1268f,-0.3307f,0.1927f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.3528f,0.2285f,0.9068f,-0.0313f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.4918f,0.0064f,0.0114f,0.8706f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0114f,0.8706f,0.4918f,0.0064f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3681f,0.8304f,0.2336f],left_rotation:[-0.1782f,-0.0171f,0.1129f,-0.9774f]}}
particle minecraft:cloud -3.65 70.71 -28.62 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -3.65 70.51 -28.62 -0.008 0.02 -0.044 1 0 force
particle minecraft:cloud -5.33 70.71 -28.32 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -8478
scoreboard players set #gdx driftmountains 602
scoreboard players set #gy driftmountains 69986
scoreboard players set #gdy driftmountains 60
scoreboard players set #gz driftmountains -28661
scoreboard players set #gdz driftmountains 183
scoreboard players set #gr driftmountains -2763
scoreboard players set #gdr driftmountains 286
scoreboard players set #gp driftmountains -355
scoreboard players set #gdp driftmountains -31
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.4199f,0.3036f,-0.0884f,0.8507f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.1783f,0.8647f,0.3903f,-0.2611f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.4918f,0.0064f,0.0114f,0.8706f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0114f,0.8706f,0.4918f,0.0064f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3550f,0.8541f,0.1027f],left_rotation:[-0.1826f,0.0531f,-0.2495f,-0.9495f]}}
particle minecraft:cloud -8.32 70.31 -30.16 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -8.32 70.11 -30.16 -0.021 0.02 -0.041 1 0 force
particle minecraft:cloud -9.80 70.31 -29.39 0.35 0.18 0.35 0.02 3 force
