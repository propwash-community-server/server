scoreboard players set #gx driftmountains -58972
scoreboard players set #gdx driftmountains 369
scoreboard players set #gy driftmountains 68964
scoreboard players set #gdy driftmountains -18
scoreboard players set #gz driftmountains -36173
scoreboard players set #gdz driftmountains -466
scoreboard players set #gr driftmountains -17540
scoreboard players set #gdr driftmountains -73
scoreboard players set #gp driftmountains 143
scoreboard players set #gdp driftmountains -2
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.4742f,-0.1652f,0.1535f,0.8510f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[-0.0649f,0.8396f,0.4942f,0.2160f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.6051f,0.0079f,0.0104f,0.7960f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0104f,0.7960f,0.6051f,0.0079f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3930f,0.8266f,0.0919f],left_rotation:[-0.0752f,-0.1634f,0.8869f,-0.4255f]}}
particle minecraft:cloud -59.91 69.28 -34.98 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud -58.24 69.28 -34.85 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -58.24 69.08 -34.85 -0.003 0.02 0.035 1 0 force
scoreboard players set #gx driftmountains -63609
scoreboard players set #gdx driftmountains 558
scoreboard players set #gy driftmountains 69106
scoreboard players set #gdy driftmountains -14
scoreboard players set #gz driftmountains -34743
scoreboard players set #gdz driftmountains -266
scoreboard players set #gr driftmountains -14571
scoreboard players set #gdr driftmountains -471
scoreboard players set #gp driftmountains 102
scoreboard players set #gdp driftmountains 9
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[0.0061f,-0.0001f,0.0191f,0.9998f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.5934f,-0.1198f,0.1581f,0.7801f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[-0.0770f,0.7678f,0.6092f,0.1829f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.6051f,0.0079f,0.0104f,0.7960f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0104f,0.7960f,0.6051f,0.0079f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.4039f,0.8607f,0.2454f],left_rotation:[-0.0285f,-0.1873f,0.9648f,-0.1827f]}}
particle minecraft:cloud -65.08 69.43 -34.10 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud -63.67 69.43 -33.13 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -63.67 69.23 -33.13 -0.021 0.02 0.031 1 0 force
scoreboard players set #gx driftmountains -68173
scoreboard players set #gdx driftmountains 697
scoreboard players set #gy driftmountains 69188
scoreboard players set #gdy driftmountains -11
scoreboard players set #gz driftmountains -31727
scoreboard players set #gdz driftmountains -283
scoreboard players set #gr driftmountains -12034
scoreboard players set #gdr driftmountains -297
scoreboard players set #gp driftmountains 79
scoreboard players set #gdp driftmountains 2
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[0.0061f,-0.0000f,0.0051f,1.0000f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.6271f,0.0916f,0.0067f,-0.7735f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[-0.0880f,-0.7785f,0.6209f,-0.0262f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.6051f,0.0079f,0.0104f,0.7960f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0104f,0.7960f,0.6051f,0.0079f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3712f,0.8660f,0.1073f],left_rotation:[0.1483f,-0.1223f,0.6254f,0.7562f]}}
