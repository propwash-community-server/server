scoreboard players set #gx driftmountains -18698
scoreboard players set #gdx driftmountains -1079
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 57899
scoreboard players set #gdz driftmountains -328
scoreboard players set #gr driftmountains 15305
scoreboard players set #gdr driftmountains 19
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.1587f,-0.3729f,-0.1230f,-0.9059f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.0285f,-0.8979f,0.1988f,0.3917f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.5072f,0.0066f,0.0113f,0.8617f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0113f,0.8617f,0.5072f,0.0066f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3643f,0.8242f,0.0910f],left_rotation:[-0.1617f,-0.0819f,0.4680f,-0.8649f]}}
particle minecraft:cloud -18.87 71.32 59.40 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -18.87 71.12 59.40 0.031 0.02 0.060 1 0 force
particle minecraft:cloud -17.38 71.32 58.64 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -9858
scoreboard players set #gdx driftmountains -971
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 60208
scoreboard players set #gdz driftmountains -253
scoreboard players set #gr driftmountains 15192
scoreboard players set #gdr driftmountains -73
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.7659f,-0.1699f,-0.3626f,-0.5030f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.3117f,-0.4677f,0.7880f,0.2513f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.5072f,0.0066f,0.0113f,0.8617f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0113f,0.8617f,0.5072f,0.0066f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3904f,0.8289f,0.2329f],left_rotation:[-0.1486f,-0.0997f,0.5325f,-0.8273f]}}
particle minecraft:cloud -9.97 71.32 61.81 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -9.97 71.12 61.81 0.028 0.02 0.052 1 0 force
particle minecraft:cloud -8.46 71.32 61.01 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -4923
scoreboard players set #gdx driftmountains -1038
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 61698
scoreboard players set #gdz driftmountains -264
scoreboard players set #gr driftmountains 15604
scoreboard players set #gdr driftmountains -60
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.6676f,0.3291f,-0.2753f,0.6084f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.3407f,0.6407f,0.6367f,-0.2608f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.5072f,0.0066f,0.0113f,0.8617f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0113f,0.8617f,0.5072f,0.0066f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3815f,0.8214f,0.0899f],left_rotation:[-0.1172f,-0.1356f,0.7463f,-0.6410f]}}
particle minecraft:cloud -5.17 71.32 63.19 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -5.17 71.12 63.19 0.026 0.02 0.059 1 0 force
particle minecraft:cloud -3.65 71.32 62.51 0.35 0.18 0.35 0.02 3 force
