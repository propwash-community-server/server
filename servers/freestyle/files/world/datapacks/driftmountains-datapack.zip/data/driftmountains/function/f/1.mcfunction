scoreboard players set #gx driftmountains -10255
scoreboard players set #gdx driftmountains -914
scoreboard players set #gy driftmountains 65020
scoreboard players set #gdy driftmountains 27
scoreboard players set #gz driftmountains 19907
scoreboard players set #gdz driftmountains -411
scoreboard players set #gr driftmountains 14124
scoreboard players set #gdr driftmountains 2
scoreboard players set #gp driftmountains -126
scoreboard players set #gdp driftmountains -20
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0001f,-0.0165f,0.9999f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.4740f,-0.1812f,-0.1633f,-0.8460f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.0753f,-0.8335f,0.4957f,0.2320f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.5042f,0.0066f,-0.0113f,-0.8635f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0113f,-0.8635f,0.5042f,0.0066f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3839f,0.8656f,0.1072f],left_rotation:[-0.1134f,0.1540f,-0.8013f,-0.5668f]}}
particle minecraft:cloud -10.12 65.34 21.41 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -10.12 65.14 21.41 0.038 0.02 0.047 1 0 force
particle minecraft:cloud -8.82 65.34 20.37 0.35 0.18 0.35 0.02 2 force
scoreboard players set #gx driftmountains -4427
scoreboard players set #gdx driftmountains -782
scoreboard players set #gy driftmountains 65000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 22163
scoreboard players set #gdz driftmountains -326
scoreboard players set #gr driftmountains 14279
scoreboard players set #gdr driftmountains -96
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0001f,-0.0189f,0.9998f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.4726f,-0.1884f,-0.1673f,-0.8445f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.0795f,-0.8315f,0.4950f,0.2391f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.5042f,0.0066f,-0.0113f,-0.8635f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0113f,-0.8635f,0.5042f,0.0066f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3662f,0.8699f,0.2490f],left_rotation:[-0.1187f,0.1504f,-0.7542f,-0.6281f]}}
particle minecraft:cloud -4.28 65.32 23.77 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -4.28 65.12 23.77 0.034 0.02 0.045 1 0 force
particle minecraft:cloud -2.92 65.32 22.73 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains 2493
scoreboard players set #gdx driftmountains -920
scoreboard players set #gy driftmountains 65000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 24676
scoreboard players set #gdz driftmountains -233
scoreboard players set #gr driftmountains 14697
scoreboard players set #gdr driftmountains 50
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.4522f,-0.2768f,-0.2164f,-0.8198f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.1315f,-0.8015f,0.4838f,0.3258f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.5042f,0.0066f,-0.0113f,-0.8635f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0113f,-0.8635f,0.5042f,0.0066f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3529f,0.8389f,0.0967f],left_rotation:[-0.1860f,-0.0095f,0.0854f,-0.9787f]}}
particle minecraft:cloud 2.48 65.32 26.19 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 2.48 65.12 26.19 0.031 0.02 0.048 1 0 force
particle minecraft:cloud 3.88 65.32 25.28 0.35 0.18 0.35 0.02 3 force
