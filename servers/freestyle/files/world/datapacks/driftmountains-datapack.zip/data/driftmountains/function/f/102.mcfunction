scoreboard players set #gx driftmountains -5629
scoreboard players set #gdx driftmountains 635
scoreboard players set #gy driftmountains 70301
scoreboard players set #gdy driftmountains 60
scoreboard players set #gz driftmountains -27215
scoreboard players set #gdz driftmountains 415
scoreboard players set #gr driftmountains -1135
scoreboard players set #gdr driftmountains 133
scoreboard players set #gp driftmountains -336
scoreboard players set #gdp driftmountains 49
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.9212f,0.1234f,-0.3123f,0.1968f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.3347f,0.2307f,0.9133f,-0.0273f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.4912f,0.0064f,-0.0114f,-0.8710f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0114f,-0.8710f,0.4912f,0.0064f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3524f,0.8458f,0.0995f],left_rotation:[-0.1872f,0.0186f,-0.0643f,-0.9800f]}}
particle minecraft:cloud -5.06 70.62 -28.61 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -5.06 70.42 -28.61 -0.009 0.02 -0.044 1 0 force
particle minecraft:cloud -6.70 70.62 -28.29 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -9719
scoreboard players set #gdx driftmountains 721
scoreboard players set #gy driftmountains 69872
scoreboard players set #gdy driftmountains 56
scoreboard players set #gz driftmountains -29535
scoreboard players set #gdz driftmountains 148
scoreboard players set #gr driftmountains -3245
scoreboard players set #gdr driftmountains 205
scoreboard players set #gp driftmountains -292
scoreboard players set #gdp driftmountains -13
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.9013f,-0.0432f,-0.3329f,-0.2739f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.3059f,-0.2405f,0.9108f,0.1382f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.4912f,0.0064f,-0.0114f,-0.8710f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0114f,-0.8710f,0.4912f,0.0064f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3612f,0.8360f,0.2358f],left_rotation:[-0.1799f,0.0177f,-0.0651f,-0.9814f]}}
particle minecraft:cloud -9.73 70.19 -31.15 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -9.73 69.99 -31.15 -0.027 0.02 -0.042 1 0 force
particle minecraft:cloud -11.17 70.19 -30.23 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -15024
scoreboard players set #gdx driftmountains 857
scoreboard players set #gy driftmountains 69498
scoreboard players set #gdy driftmountains 59
scoreboard players set #gz driftmountains -29552
scoreboard players set #gdz driftmountains 56
scoreboard players set #gr driftmountains -4310
scoreboard players set #gdr driftmountains 152
scoreboard players set #gp driftmountains -283
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.0073f,-0.3484f,-0.0586f,-0.9355f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[-0.0394f,-0.9345f,0.0440f,0.3511f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.4912f,0.0064f,-0.0114f,-0.8710f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0114f,-0.8710f,0.4912f,0.0064f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3531f,0.8380f,0.0964f],left_rotation:[-0.1855f,-0.0131f,0.1045f,-0.9769f]}}
particle minecraft:cloud -15.28 69.82 -31.04 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -15.28 69.62 -31.04 -0.035 0.02 -0.038 1 0 force
particle minecraft:cloud -16.49 69.82 -29.90 0.35 0.18 0.35 0.02 3 force
