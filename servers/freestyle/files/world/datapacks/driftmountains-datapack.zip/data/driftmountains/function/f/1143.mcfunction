scoreboard players set #gx driftmountains -94647
scoreboard players set #gdx driftmountains -513
scoreboard players set #gy driftmountains 70014
scoreboard players set #gdy driftmountains 4
scoreboard players set #gz driftmountains 3979
scoreboard players set #gdz driftmountains -861
scoreboard players set #gr driftmountains -16322
scoreboard players set #gdr driftmountains 305
scoreboard players set #gp driftmountains -17
scoreboard players set #gdp driftmountains 1
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.8733f,-0.0719f,-0.3625f,-0.3174f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.3311f,-0.2810f,0.8857f,0.1641f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.6449f,0.0084f,-0.0100f,-0.7642f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0100f,-0.7642f,0.6449f,0.0084f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3562f,0.8314f,0.0938f],left_rotation:[-0.1790f,-0.0422f,0.2589f,-0.9482f]}}
particle minecraft:cloud -95.81 70.33 4.94 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -95.81 70.13 4.94 -0.017 0.02 0.058 1 0 force
particle minecraft:cloud -94.21 70.33 5.43 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -89291
scoreboard players set #gdx driftmountains -725
scoreboard players set #gy driftmountains 69983
scoreboard players set #gdy driftmountains 2
scoreboard players set #gz driftmountains 11021
scoreboard players set #gdz driftmountains -855
scoreboard players set #gr driftmountains 17759
scoreboard players set #gdr driftmountains 99
scoreboard players set #gp driftmountains -4
scoreboard players set #gdp driftmountains -4
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.8425f,0.1950f,-0.2611f,0.4290f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.3076f,0.4588f,0.8266f,-0.1075f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.6449f,0.0084f,-0.0100f,-0.7642f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0100f,-0.7642f,0.6449f,0.0084f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3585f,0.8398f,0.2372f],left_rotation:[-0.1783f,0.0359f,-0.1586f,-0.9705f]}}
particle minecraft:cloud -90.09 70.30 12.42 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -90.09 70.10 12.42 0.003 0.02 0.065 1 0 force
particle minecraft:cloud -88.38 70.30 12.35 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -85308
scoreboard players set #gdx driftmountains -737
scoreboard players set #gy driftmountains 69998
scoreboard players set #gdy driftmountains -7
scoreboard players set #gz driftmountains 15298
scoreboard players set #gdz driftmountains -836
scoreboard players set #gr driftmountains 17492
scoreboard players set #gdr driftmountains 3
scoreboard players set #gp driftmountains 32
scoreboard players set #gdp driftmountains -9
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[0.0061f,0.0001f,-0.0222f,0.9997f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.2101f,-0.2894f,-0.1221f,-0.9259f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.0255f,-0.9181f,0.2416f,0.3130f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.6449f,0.0084f,-0.0100f,-0.7642f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0100f,-0.7642f,0.6449f,0.0084f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3555f,0.8550f,0.1030f],left_rotation:[-0.1818f,0.0567f,-0.2688f,-0.9441f]}}
particle minecraft:cloud -86.03 70.32 16.63 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -86.03 70.12 16.63 0.006 0.02 0.066 1 0 force
particle minecraft:cloud -84.36 70.32 16.48 0.35 0.18 0.35 0.02 3 force
