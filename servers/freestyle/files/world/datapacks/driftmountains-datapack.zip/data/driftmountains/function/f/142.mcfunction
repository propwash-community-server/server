scoreboard players set #gx driftmountains 15244
scoreboard players set #gdx driftmountains 438
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 1251
scoreboard players set #gdz driftmountains 953
scoreboard players set #gr driftmountains 1221
scoreboard players set #gdr driftmountains 24
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.8023f,-0.1190f,-0.2912f,-0.5073f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.2395f,-0.4795f,0.8192f,0.2040f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.9961f,0.0130f,0.0011f,0.0875f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0011f,0.0875f,0.9961f,0.0130f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3553f,0.8547f,0.1030f],left_rotation:[-0.1820f,0.0558f,-0.2637f,-0.9456f]}}
particle minecraft:cloud 16.33 71.32 0.20 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 16.33 71.12 0.20 0.013 0.02 -0.061 1 0 force
particle minecraft:cloud 14.69 71.32 -0.16 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains 12192
scoreboard players set #gdx driftmountains 457
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains -4623
scoreboard players set #gdz driftmountains 921
scoreboard players set #gr driftmountains 1121
scoreboard players set #gdr driftmountains 16
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.9352f,0.1039f,-0.3048f,0.1472f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.3219f,0.1800f,0.9295f,-0.0061f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.9961f,0.0130f,0.0011f,0.0875f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0011f,0.0875f,0.9961f,0.0130f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3577f,0.8414f,0.2379f],left_rotation:[-0.1773f,0.0429f,-0.1950f,-0.9637f]}}
particle minecraft:cloud 13.30 71.32 -5.80 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 13.30 71.12 -5.80 0.012 0.02 -0.061 1 0 force
particle minecraft:cloud 11.62 71.32 -6.13 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains 9470
scoreboard players set #gdx driftmountains 421
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains -9979
scoreboard players set #gdz driftmountains 794
scoreboard players set #gr driftmountains 935
scoreboard players set #gdr driftmountains 27
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.7105f,-0.1659f,-0.2709f,-0.6279f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.2064f,-0.6029f,0.7318f,0.2415f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.9961f,0.0130f,0.0011f,0.0875f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0011f,0.0875f,0.9961f,0.0130f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3547f,0.8535f,0.1025f],left_rotation:[-0.1832f,0.0505f,-0.2352f,-0.9531f]}}
particle minecraft:cloud 10.50 71.32 -11.09 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 10.50 71.12 -11.09 0.010 0.02 -0.058 1 0 force
particle minecraft:cloud 8.85 71.32 -11.36 0.35 0.18 0.35 0.02 3 force
