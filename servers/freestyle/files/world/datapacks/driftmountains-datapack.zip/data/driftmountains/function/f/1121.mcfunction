scoreboard players set #gx driftmountains -78254
scoreboard players set #gdx driftmountains -870
scoreboard players set #gy driftmountains 70146
scoreboard players set #gdy driftmountains -23
scoreboard players set #gz driftmountains 23772
scoreboard players set #gdz driftmountains -994
scoreboard players set #gr driftmountains 17811
scoreboard players set #gdr driftmountains 10
scoreboard players set #gp driftmountains 77
scoreboard players set #gdp driftmountains -3
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.9267f,0.1133f,-0.3177f,0.1658f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.3369f,0.2002f,0.9199f,-0.0165f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.9210f,0.0121f,-0.0051f,-0.3894f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0051f,-0.3894f,0.9210f,0.0121f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3524f,0.8451f,0.0992f],left_rotation:[-0.1873f,0.0158f,-0.0494f,-0.9809f]}}
particle minecraft:cloud -79.05 70.47 25.06 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -79.05 70.27 25.06 0.003 0.02 0.080 1 0 force
particle minecraft:cloud -77.38 70.47 25.00 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -70675
scoreboard players set #gdx driftmountains -909
scoreboard players set #gy driftmountains 70346
scoreboard players set #gdy driftmountains -24
scoreboard players set #gz driftmountains 31506
scoreboard players set #gdz driftmountains -927
scoreboard players set #gr driftmountains 17665
scoreboard players set #gdr driftmountains -65
scoreboard players set #gp driftmountains 78
scoreboard players set #gdp driftmountains 4
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.5113f,0.3213f,-0.1429f,0.7841f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.2261f,0.8035f,0.4804f,-0.2693f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.9210f,0.0121f,-0.0051f,-0.3894f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0051f,-0.3894f,0.9210f,0.0121f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3670f,0.8311f,0.2338f],left_rotation:[-0.1788f,-0.0122f,0.0882f,-0.9799f]}}
particle minecraft:cloud -71.45 70.67 32.92 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -71.45 70.47 32.92 0.005 0.02 0.084 1 0 force
particle minecraft:cloud -69.74 70.67 32.82 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -66699
scoreboard players set #gdx driftmountains -870
scoreboard players set #gy driftmountains 70442
scoreboard players set #gdy driftmountains -19
scoreboard players set #gz driftmountains 35546
scoreboard players set #gdz driftmountains -904
scoreboard players set #gr driftmountains -17885
scoreboard players set #gdr driftmountains -28
scoreboard players set #gp driftmountains 60
scoreboard players set #gdp driftmountains 6
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.6259f,-0.2375f,-0.2947f,-0.6819f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.2246f,-0.6547f,0.6543f,0.3046f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.9210f,0.0121f,-0.0051f,-0.3894f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0051f,-0.3894f,0.9210f,0.0121f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3589f,0.8282f,0.0926f],left_rotation:[-0.1734f,-0.0579f,0.3416f,-0.9218f]}}
particle minecraft:cloud -67.56 70.76 36.79 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -67.56 70.56 36.79 -0.002 0.02 0.080 1 0 force
particle minecraft:cloud -65.89 70.76 36.82 0.35 0.18 0.35 0.02 3 force
