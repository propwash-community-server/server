scoreboard players set #gx driftmountains -31470
scoreboard players set #gdx driftmountains 654
scoreboard players set #gy driftmountains 67323
scoreboard players set #gdy driftmountains -11
scoreboard players set #gz driftmountains -90241
scoreboard players set #gdz driftmountains 274
scoreboard players set #gr driftmountains -3696
scoreboard players set #gdr driftmountains 56
scoreboard players set #gp driftmountains 81
scoreboard players set #gdp driftmountains -3
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0001f,-0.0188f,0.9998f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.3158f,-0.2006f,-0.1258f,-0.9188f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.0300f,-0.9106f,0.3386f,0.2349f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.7922f,0.0104f,0.0080f,0.6101f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0080f,0.6101f,0.7922f,0.0104f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3871f,0.8645f,0.1068f],left_rotation:[-0.1029f,0.1606f,-0.8384f,-0.5105f]}}
particle minecraft:cloud -31.56 67.64 -91.75 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -31.56 67.44 -91.75 -0.025 0.02 -0.034 1 0 force
particle minecraft:cloud -32.90 67.64 -90.75 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -37142
scoreboard players set #gdx driftmountains 640
scoreboard players set #gy driftmountains 67437
scoreboard players set #gdy driftmountains -16
scoreboard players set #gz driftmountains -91660
scoreboard players set #gdz driftmountains 63
scoreboard players set #gr driftmountains -4982
scoreboard players set #gdr driftmountains 213
scoreboard players set #gp driftmountains 124
scoreboard players set #gdp driftmountains -22
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0001f,-0.0220f,0.9997f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.9714f,0.0569f,-0.2301f,0.0130f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.2328f,0.0372f,0.9708f,0.0449f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.7922f,0.0104f,0.0080f,0.6101f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0080f,0.6101f,0.7922f,0.0104f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3726f,0.8730f,0.2502f],left_rotation:[-0.0982f,0.1657f,-0.8360f,-0.5139f]}}
particle minecraft:cloud -37.63 67.76 -93.19 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -37.63 67.56 -93.19 -0.028 0.02 -0.024 1 0 force
particle minecraft:cloud -38.74 67.76 -91.89 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -42413
scoreboard players set #gdx driftmountains 439
scoreboard players set #gy driftmountains 67580
scoreboard players set #gdy driftmountains -11
scoreboard players set #gz driftmountains -91197
scoreboard players set #gdz driftmountains -233
scoreboard players set #gr driftmountains -8334
scoreboard players set #gdr driftmountains 247
scoreboard players set #gp driftmountains 107
scoreboard players set #gdp driftmountains 1
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[0.0061f,0.0001f,-0.0218f,0.9997f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.8154f,0.1594f,-0.1447f,0.5373f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.2019f,0.5555f,0.8032f,-0.0746f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.7922f,0.0104f,0.0080f,0.6101f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0080f,0.6101f,0.7922f,0.0104f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3951f,0.8589f,0.1046f],left_rotation:[-0.0686f,0.1758f,-0.9259f,-0.3272f]}}
particle minecraft:cloud -43.57 67.90 -92.17 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -43.57 67.70 -92.17 -0.031 0.02 -0.004 1 0 force
particle minecraft:cloud -43.76 67.90 -90.51 0.35 0.18 0.35 0.02 3 force
