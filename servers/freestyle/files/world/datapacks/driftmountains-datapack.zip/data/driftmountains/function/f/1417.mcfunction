scoreboard players set #gx driftmountains 34067
scoreboard players set #gdx driftmountains 1094
scoreboard players set #gy driftmountains 66435
scoreboard players set #gdy driftmountains -13
scoreboard players set #gz driftmountains -49889
scoreboard players set #gdz driftmountains 654
scoreboard players set #gr driftmountains -5881
scoreboard players set #gdr driftmountains 68
scoreboard players set #gp driftmountains 60
scoreboard players set #gdp driftmountains -1
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0000f,-0.0003f,1.0000f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.9972f,0.0524f,-0.0005f,-0.0537f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[-0.0052f,-0.0539f,0.9972f,0.0521f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.7491f,0.0098f,-0.0087f,-0.6623f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0087f,-0.6623f,0.7491f,0.0098f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3523f,0.8439f,0.0987f],left_rotation:[0.1873f,-0.0110f,0.0235f,0.9819f]}}
scoreboard players set #gx driftmountains 26204
scoreboard players set #gdx driftmountains 1009
scoreboard players set #gy driftmountains 66531
scoreboard players set #gdy driftmountains -14
scoreboard players set #gz driftmountains -53798
scoreboard players set #gdz driftmountains 757
scoreboard players set #gr driftmountains -5137
scoreboard players set #gdr driftmountains 45
scoreboard players set #gp driftmountains 64
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0000f,-0.0011f,1.0000f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.8025f,0.0473f,0.0240f,0.5943f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.0383f,0.5950f,0.8020f,0.0368f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.7491f,0.0098f,-0.0087f,-0.6623f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0087f,-0.6623f,0.7491f,0.0098f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3665f,0.8314f,0.2339f],left_rotation:[0.1790f,0.0100f,-0.0770f,0.9808f]}}
scoreboard players set #gx driftmountains 16842
scoreboard players set #gdx driftmountains 1053
scoreboard players set #gy driftmountains 66655
scoreboard players set #gdy driftmountains -13
scoreboard players set #gz driftmountains -60327
scoreboard players set #gdz driftmountains 666
scoreboard players set #gr driftmountains -6003
scoreboard players set #gdr driftmountains -11
scoreboard players set #gp driftmountains 61
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.9983f,0.0527f,0.0165f,-0.0191f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[-0.0186f,-0.0209f,0.9983f,0.0520f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.7491f,0.0098f,-0.0087f,-0.6623f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0087f,-0.6623f,0.7491f,0.0098f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3533f,0.8501f,0.1012f],left_rotation:[0.1857f,-0.0362f,0.1587f,0.9690f]}}
