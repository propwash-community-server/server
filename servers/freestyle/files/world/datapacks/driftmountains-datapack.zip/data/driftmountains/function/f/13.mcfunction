scoreboard players set #gx driftmountains -21229
scoreboard players set #gdx driftmountains -849
scoreboard players set #gy driftmountains 65532
scoreboard players set #gdy driftmountains 33
scoreboard players set #gz driftmountains 14002
scoreboard players set #gdz driftmountains -681
scoreboard players set #gr driftmountains 17070
scoreboard players set #gdr driftmountains 168
scoreboard players set #gp driftmountains -139
scoreboard players set #gdp driftmountains 19
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.4558f,-0.2632f,-0.2089f,-0.8242f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.1234f,-0.8068f,0.4859f,0.3125f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.5293f,0.0069f,-0.0111f,-0.8483f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0111f,-0.8483f,0.5293f,0.0069f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3524f,0.8457f,0.0994f],left_rotation:[-0.1872f,0.0182f,-0.0622f,-0.9801f]}}
particle minecraft:cloud -21.85 65.85 15.38 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -21.85 65.65 15.38 0.011 0.02 0.064 1 0 force
particle minecraft:cloud -20.20 65.85 15.11 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -15540
scoreboard players set #gdx driftmountains -1092
scoreboard players set #gy driftmountains 65233
scoreboard players set #gdy driftmountains 56
scoreboard players set #gz driftmountains 17496
scoreboard players set #gdz driftmountains -497
scoreboard players set #gr driftmountains 14510
scoreboard players set #gdr driftmountains 494
scoreboard players set #gp driftmountains -224
scoreboard players set #gdp driftmountains 2
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0001f,-0.0191f,0.9998f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.4727f,-0.1880f,-0.1671f,-0.8446f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.0793f,-0.8317f,0.4951f,0.2387f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.5293f,0.0069f,-0.0111f,-0.8483f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0111f,-0.8483f,0.5293f,0.0069f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3663f,0.8700f,0.2491f],left_rotation:[-0.1182f,0.1508f,-0.7567f,-0.6250f]}}
particle minecraft:cloud -15.46 65.55 19.10 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -15.46 65.35 19.10 0.038 0.02 0.055 1 0 force
particle minecraft:cloud -14.06 65.55 18.13 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -8239
scoreboard players set #gdx driftmountains -961
scoreboard players set #gy driftmountains 65000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 20564
scoreboard players set #gdz driftmountains -455
scoreboard players set #gr driftmountains 14290
scoreboard players set #gdr driftmountains -86
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains -33
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0001f,-0.0168f,0.9999f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.4738f,-0.1826f,-0.1641f,-0.8457f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.0761f,-0.8332f,0.4956f,0.2334f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.5293f,0.0069f,-0.0111f,-0.8483f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0111f,-0.8483f,0.5293f,0.0069f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3832f,0.8658f,0.1073f],left_rotation:[-0.1156f,0.1525f,-0.7929f,-0.5784f]}}
particle minecraft:cloud -8.15 65.32 22.07 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -8.15 65.12 22.07 0.038 0.02 0.050 1 0 force
particle minecraft:cloud -6.81 65.32 21.07 0.35 0.18 0.35 0.02 2 force
