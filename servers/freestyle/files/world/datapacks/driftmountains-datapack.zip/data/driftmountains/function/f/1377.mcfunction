scoreboard players set #gx driftmountains -3896
scoreboard players set #gdx driftmountains 819
scoreboard players set #gy driftmountains 66920
scoreboard players set #gdy driftmountains -11
scoreboard players set #gz driftmountains -74038
scoreboard players set #gdz driftmountains 545
scoreboard players set #gr driftmountains -4855
scoreboard players set #gdr driftmountains -54
scoreboard players set #gp driftmountains 62
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0000f,-0.0048f,1.0000f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.4479f,-0.0356f,-0.0766f,-0.8901f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[-0.0165f,-0.8869f,0.4541f,0.0829f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.2937f,0.0038f,0.0125f,0.9558f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0125f,0.9558f,0.2937f,0.0038f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3690f,0.8222f,0.0902f],left_rotation:[0.1508f,0.0989f,-0.5567f,0.8108f]}}
scoreboard players set #gx driftmountains -10811
scoreboard players set #gdx driftmountains 806
scoreboard players set #gy driftmountains 67009
scoreboard players set #gdy driftmountains -11
scoreboard players set #gz driftmountains -78140
scoreboard players set #gdz driftmountains 508
scoreboard players set #gr driftmountains -4121
scoreboard players set #gdr driftmountains -144
scoreboard players set #gp driftmountains 63
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0000f,-0.0101f,0.9999f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.9037f,-0.0094f,-0.1519f,-0.4002f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.1107f,-0.3865f,0.9096f,0.1045f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.2937f,0.0038f,0.0125f,0.9558f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0125f,0.9558f,0.2937f,0.0038f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.4054f,0.8571f,0.2440f],left_rotation:[0.0430f,0.1834f,-0.9467f,0.2615f]}}
particle minecraft:cloud -11.07 67.33 -79.73 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -11.07 67.13 -79.73 -0.037 0.02 -0.042 1 0 force
particle minecraft:cloud -12.35 67.33 -78.60 0.35 0.18 0.35 0.02 2 force
scoreboard players set #gx driftmountains -18530
scoreboard players set #gdx driftmountains 811
scoreboard players set #gy driftmountains 67121
scoreboard players set #gdy driftmountains -12
scoreboard players set #gz driftmountains -83644
scoreboard players set #gdz driftmountains 520
scoreboard players set #gr driftmountains -2975
scoreboard players set #gdr driftmountains -38
scoreboard players set #gp driftmountains 63
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0001f,-0.0169f,0.9998f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.4579f,-0.1796f,-0.1570f,-0.8564f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.0679f,-0.8446f,0.4793f,0.2287f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.2937f,0.0038f,0.0125f,0.9558f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0125f,0.9558f,0.2937f,0.0038f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3863f,0.8648f,0.1069f],left_rotation:[-0.1055f,0.1591f,-0.8298f,-0.5243f]}}
particle minecraft:cloud -18.43 67.44 -85.15 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -18.43 67.24 -85.15 -0.026 0.02 -0.046 1 0 force
particle minecraft:cloud -19.88 67.44 -84.32 0.35 0.18 0.35 0.02 2 force
