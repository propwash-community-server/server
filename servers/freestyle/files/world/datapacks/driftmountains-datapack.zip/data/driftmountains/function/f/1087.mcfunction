scoreboard players set #gx driftmountains -41416
scoreboard players set #gdx driftmountains -1190
scoreboard players set #gy driftmountains 70517
scoreboard players set #gdy driftmountains -19
scoreboard players set #gz driftmountains 50405
scoreboard players set #gdz driftmountains -450
scoreboard players set #gr driftmountains 15501
scoreboard players set #gdr driftmountains 39
scoreboard players set #gp driftmountains 71
scoreboard players set #gdp driftmountains -20
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.7101f,0.2815f,-0.2477f,0.5960f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.3117f,0.6253f,0.6844f,-0.2085f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.9991f,0.0131f,0.0005f,0.0405f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0005f,0.0405f,0.9991f,0.0131f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3578f,0.8294f,0.0930f],left_rotation:[-0.1758f,-0.0518f,0.3097f,-0.9330f]}}
particle minecraft:cloud -41.64 70.84 51.90 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -41.64 70.64 51.90 0.032 0.02 0.069 1 0 force
particle minecraft:cloud -40.13 70.84 51.19 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -31440
scoreboard players set #gdx driftmountains -1240
scoreboard players set #gy driftmountains 70828
scoreboard players set #gdy driftmountains -43
scoreboard players set #gz driftmountains 53979
scoreboard players set #gdz driftmountains -411
scoreboard players set #gr driftmountains 15435
scoreboard players set #gdr driftmountains 15
scoreboard players set #gp driftmountains 127
scoreboard players set #gdp driftmountains 6
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.0522f,0.3875f,0.0348f,0.9197f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.0617f,0.9211f,0.0118f,-0.3841f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.9991f,0.0131f,0.0005f,0.0405f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0005f,0.0405f,0.9991f,0.0131f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3849f,0.8275f,0.2324f],left_rotation:[-0.1592f,-0.0806f,0.4359f,-0.8822f]}}
particle minecraft:cloud -31.62 71.15 55.58 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -31.62 70.95 55.58 0.032 0.02 0.067 1 0 force
particle minecraft:cloud -30.08 71.15 54.84 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -26755
scoreboard players set #gdx driftmountains -1178
scoreboard players set #gy driftmountains 70962
scoreboard players set #gdy driftmountains -28
scoreboard players set #gz driftmountains 55694
scoreboard players set #gdz driftmountains -347
scoreboard players set #gr driftmountains 15276
scoreboard players set #gdr driftmountains 27
scoreboard players set #gp driftmountains 83
scoreboard players set #gdp driftmountains 11
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.8764f,-0.0632f,-0.3892f,-0.2766f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.3623f,-0.2372f,0.8878f,0.1557f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.9991f,0.0131f,0.0005f,0.0405f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0005f,0.0405f,0.9991f,0.0131f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3649f,0.8238f,0.0908f],left_rotation:[-0.1602f,-0.0846f,0.4818f,-0.8573f]}}
particle minecraft:cloud -26.92 71.28 57.20 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -26.92 71.08 57.20 0.033 0.02 0.065 1 0 force
particle minecraft:cloud -25.44 71.28 56.43 0.35 0.18 0.35 0.02 3 force
