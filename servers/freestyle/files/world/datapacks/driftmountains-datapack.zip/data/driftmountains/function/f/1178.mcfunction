scoreboard players set #gx driftmountains -91367
scoreboard players set #gdx driftmountains 548
scoreboard players set #gy driftmountains 69666
scoreboard players set #gdy driftmountains -19
scoreboard players set #gz driftmountains -22553
scoreboard players set #gdz driftmountains -451
scoreboard players set #gr driftmountains -8616
scoreboard players set #gdr driftmountains 172
scoreboard players set #gp driftmountains 109
scoreboard players set #gdp driftmountains 1
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.4225f,0.3159f,-0.0962f,0.8440f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.1855f,0.8588f,0.3917f,-0.2733f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.8654f,0.0113f,0.0066f,0.5009f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0066f,0.5009f,0.8654f,0.0113f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3528f,0.8482f,0.1004f],left_rotation:[-0.1866f,0.0285f,-0.1170f,-0.9750f]}}
particle minecraft:cloud -92.57 69.99 -23.47 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -92.57 69.79 -23.47 -0.043 0.02 -0.003 1 0 force
particle minecraft:cloud -92.68 69.99 -21.80 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -95971
scoreboard players set #gdx driftmountains 430
scoreboard players set #gy driftmountains 69840
scoreboard players set #gdy driftmountains -18
scoreboard players set #gz driftmountains -17330
scoreboard players set #gdz driftmountains -653
scoreboard players set #gr driftmountains -9875
scoreboard players set #gdr driftmountains 175
scoreboard players set #gp driftmountains 87
scoreboard players set #gdp driftmountains 3
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.7945f,0.2270f,-0.2551f,0.5022f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.3092f,0.5318f,0.7750f,-0.1448f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.8654f,0.0113f,0.0066f,0.5009f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0066f,0.5009f,0.8654f,0.0113f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3631f,0.8341f,0.2350f],left_rotation:[-0.1800f,0.0069f,-0.0097f,-0.9836f]}}
particle minecraft:cloud -97.45 70.16 -17.97 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -97.45 69.96 -17.97 -0.047 0.02 0.007 1 0 force
particle minecraft:cloud -97.19 70.16 -16.28 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -97826
scoreboard players set #gdx driftmountains 197
scoreboard players set #gy driftmountains 69941
scoreboard players set #gdy driftmountains -16
scoreboard players set #gz driftmountains -12915
scoreboard players set #gdz driftmountains -811
scoreboard players set #gr driftmountains -11731
scoreboard players set #gdr driftmountains 405
scoreboard players set #gp driftmountains 66
scoreboard players set #gdp driftmountains 4
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.4064f,0.3419f,-0.1031f,0.8410f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.1920f,0.8565f,0.3727f,-0.3011f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.8654f,0.0113f,0.0066f,0.5009f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0066f,0.5009f,0.8654f,0.0113f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3536f,0.8364f,0.0958f],left_rotation:[-0.1844f,-0.0199f,0.1410f,-0.9724f]}}
particle minecraft:cloud -99.33 70.26 -13.08 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -99.33 70.06 -13.08 -0.039 0.02 0.020 1 0 force
particle minecraft:cloud -98.56 70.26 -11.59 0.35 0.18 0.35 0.02 3 force
