scoreboard players set #gx driftmountains -18587
scoreboard players set #gdx driftmountains -901
scoreboard players set #gy driftmountains 65397
scoreboard players set #gdy driftmountains 49
scoreboard players set #gz driftmountains 15843
scoreboard players set #gdz driftmountains -572
scoreboard players set #gr driftmountains 16254
scoreboard players set #gdr driftmountains 322
scoreboard players set #gp driftmountains -203
scoreboard players set #gdp driftmountains 15
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.9129f,-0.0320f,-0.3118f,-0.2614f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.2861f,-0.2301f,0.9213f,0.1282f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.9724f,0.0127f,-0.0030f,-0.2327f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0030f,-0.2327f,0.9724f,0.0127f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3556f,0.8552f,0.1031f],left_rotation:[-0.1815f,0.0578f,-0.2745f,-0.9425f]}}
particle minecraft:cloud -19.01 65.72 17.30 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -19.01 65.52 17.30 0.019 0.02 0.061 1 0 force
particle minecraft:cloud -17.41 65.72 16.79 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -12646
scoreboard players set #gdx driftmountains -969
scoreboard players set #gy driftmountains 65102
scoreboard players set #gdy driftmountains 40
scoreboard players set #gz driftmountains 18710
scoreboard players set #gdz driftmountains -395
scoreboard players set #gr driftmountains 13994
scoreboard players set #gdr driftmountains 80
scoreboard players set #gp driftmountains -184
scoreboard players set #gdp driftmountains -20
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0001f,-0.0170f,0.9998f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.9340f,-0.0120f,-0.2414f,-0.2631f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.2150f,-0.2392f,0.9404f,0.1103f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.9724f,0.0127f,-0.0030f,-0.2327f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0030f,-0.2327f,0.9724f,0.0127f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3705f,0.8722f,0.2499f],left_rotation:[-0.1048f,0.1613f,-0.8126f,-0.5502f]}}
particle minecraft:cloud -12.42 65.42 20.30 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -12.42 65.22 20.30 0.041 0.02 0.049 1 0 force
particle minecraft:cloud -11.11 65.42 19.20 0.35 0.18 0.35 0.02 2 force
scoreboard players set #gx driftmountains -5518
scoreboard players set #gdx driftmountains -936
scoreboard players set #gy driftmountains 65000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 21852
scoreboard players set #gdz driftmountains -439
scoreboard players set #gr driftmountains 14379
scoreboard players set #gdr driftmountains -13
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0001f,-0.0177f,0.9998f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.9335f,-0.0126f,-0.2433f,-0.2631f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.2170f,-0.2389f,0.9400f,0.1108f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.9724f,0.0127f,-0.0030f,-0.2327f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0030f,-0.2327f,0.9724f,0.0127f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3841f,0.8655f,0.1072f],left_rotation:[-0.1129f,0.1543f,-0.8032f,-0.5642f]}}
particle minecraft:cloud -5.45 65.32 23.36 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -5.45 65.12 23.36 0.035 0.02 0.048 1 0 force
particle minecraft:cloud -4.10 65.32 22.38 0.35 0.18 0.35 0.02 2 force
