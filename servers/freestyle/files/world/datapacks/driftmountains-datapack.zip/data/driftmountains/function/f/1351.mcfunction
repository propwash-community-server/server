scoreboard players set #gx driftmountains -23409
scoreboard players set #gdx driftmountains 694
scoreboard players set #gy driftmountains 67192
scoreboard players set #gdy driftmountains -11
scoreboard players set #gz driftmountains -86288
scoreboard players set #gdz driftmountains 389
scoreboard players set #gr driftmountains -3247
scoreboard players set #gdr driftmountains 44
scoreboard players set #gp driftmountains 67
scoreboard players set #gdp driftmountains -1
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0001f,-0.0174f,0.9998f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.5965f,0.2170f,-0.1007f,0.7662f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.1818f,0.7810f,0.5769f,-0.1555f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.7740f,0.0101f,0.0083f,0.6331f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0083f,0.6331f,0.7740f,0.0101f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3860f,0.8649f,0.1069f],left_rotation:[-0.1065f,0.1585f,-0.8264f,-0.5297f]}}
particle minecraft:cloud -23.38 67.51 -87.80 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -23.38 67.31 -87.80 -0.026 0.02 -0.040 1 0 force
particle minecraft:cloud -24.79 67.51 -86.90 0.35 0.18 0.35 0.02 2 force
scoreboard players set #gx driftmountains -29628
scoreboard players set #gdx driftmountains 654
scoreboard players set #gy driftmountains 67291
scoreboard players set #gdy driftmountains -11
scoreboard players set #gz driftmountains -89268
scoreboard players set #gdz driftmountains 322
scoreboard players set #gr driftmountains -3412
scoreboard players set #gdr driftmountains 33
scoreboard players set #gp driftmountains 76
scoreboard players set #gdp driftmountains -1
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0001f,-0.0183f,0.9998f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.7948f,0.1796f,-0.1627f,0.5564f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.2220f,0.5765f,0.7803f,-0.0971f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.7740f,0.0101f,0.0083f,0.6331f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0083f,0.6331f,0.7740f,0.0101f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3702f,0.8721f,0.2499f],left_rotation:[-0.1057f,0.1607f,-0.8089f,-0.5556f]}}
particle minecraft:cloud -29.69 67.61 -90.88 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -29.69 67.41 -90.88 -0.024 0.02 -0.036 1 0 force
particle minecraft:cloud -31.10 67.61 -89.92 0.35 0.18 0.35 0.02 2 force
scoreboard players set #gx driftmountains -35851
scoreboard players set #gdx driftmountains 575
scoreboard players set #gy driftmountains 67410
scoreboard players set #gdy driftmountains -11
scoreboard players set #gz driftmountains -92092
scoreboard players set #gdz driftmountains 147
scoreboard players set #gr driftmountains -4219
scoreboard players set #gdr driftmountains 86
scoreboard players set #gp driftmountains 90
scoreboard players set #gdp driftmountains -1
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0001f,-0.0209f,0.9998f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.9748f,0.0502f,-0.2170f,-0.0154f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.2166f,0.0074f,0.9749f,0.0520f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.7740f,0.0101f,0.0083f,0.6331f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0083f,0.6331f,0.7740f,0.0101f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3926f,0.8612f,0.1055f],left_rotation:[-0.0809f,0.1713f,-0.8999f,-0.3927f]}}
particle minecraft:cloud -36.08 67.73 -93.59 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -36.08 67.53 -93.59 -0.024 0.02 -0.026 1 0 force
particle minecraft:cloud -37.32 67.73 -92.46 0.35 0.18 0.35 0.02 3 force
