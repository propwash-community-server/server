scoreboard players set #gx driftmountains -20367
scoreboard players set #gdx driftmountains -863
scoreboard players set #gy driftmountains 65492
scoreboard players set #gdy driftmountains 40
scoreboard players set #gz driftmountains 14654
scoreboard players set #gdz driftmountains -652
scoreboard players set #gr driftmountains 16873
scoreboard players set #gdr driftmountains 197
scoreboard players set #gp driftmountains -173
scoreboard players set #gdp driftmountains 34
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.9174f,0.1312f,-0.2984f,0.2283f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.3240f,0.2610f,0.9087f,-0.0355f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.9571f,0.0125f,0.0038f,0.2893f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0038f,0.2893f,0.9571f,0.0125f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3533f,0.8501f,0.1011f],left_rotation:[-0.1858f,0.0361f,-0.1578f,-0.9691f]}}
particle minecraft:cloud -20.94 65.81 16.05 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -20.94 65.61 16.05 0.013 0.02 0.063 1 0 force
particle minecraft:cloud -19.30 65.81 15.73 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -14618
scoreboard players set #gdx driftmountains -922
scoreboard players set #gy driftmountains 65188
scoreboard players set #gdy driftmountains 45
scoreboard players set #gz driftmountains 17895
scoreboard players set #gdz driftmountains -399
scoreboard players set #gr driftmountains 14196
scoreboard players set #gdr driftmountains 314
scoreboard players set #gp driftmountains -217
scoreboard players set #gdp driftmountains -7
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0001f,-0.0176f,0.9998f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.9412f,0.1094f,-0.2116f,0.2396f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.2380f,0.2631f,0.9349f,-0.0111f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.9571f,0.0125f,0.0038f,0.2893f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0038f,0.2893f,0.9571f,0.0125f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3720f,0.8728f,0.2502f],left_rotation:[-0.0999f,0.1647f,-0.8302f,-0.5231f]}}
particle minecraft:cloud -14.45 65.51 19.50 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -14.45 65.31 19.50 0.040 0.02 0.052 1 0 force
particle minecraft:cloud -13.10 65.51 18.44 0.35 0.18 0.35 0.02 2 force
scoreboard players set #gx driftmountains -7293
scoreboard players set #gdx driftmountains -946
scoreboard players set #gy driftmountains 65000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 21015
scoreboard players set #gdz driftmountains -451
scoreboard players set #gr driftmountains 14332
scoreboard players set #gdr driftmountains -43
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0001f,-0.0171f,0.9998f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.9395f,0.1112f,-0.2189f,0.2387f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.2452f,0.2630f,0.9330f,-0.0131f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.9571f,0.0125f,0.0038f,0.2893f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0038f,0.2893f,0.9571f,0.0125f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3832f,0.8658f,0.1073f],left_rotation:[-0.1156f,0.1524f,-0.7926f,-0.5789f]}}
particle minecraft:cloud -7.21 65.32 22.52 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -7.21 65.12 22.52 0.037 0.02 0.049 1 0 force
particle minecraft:cloud -5.87 65.32 21.53 0.35 0.18 0.35 0.02 2 force
