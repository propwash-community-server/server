scoreboard players set #gx driftmountains -61523
scoreboard players set #gdx driftmountains 494
scoreboard players set #gy driftmountains 69066
scoreboard players set #gdy driftmountains -14
scoreboard players set #gz driftmountains -33879
scoreboard players set #gdz driftmountains -302
scoreboard players set #gr driftmountains -15297
scoreboard players set #gdr driftmountains -435
scoreboard players set #gp driftmountains 112
scoreboard players set #gdp driftmountains 14
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[0.0061f,-0.0001f,0.0204f,0.9998f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.9832f,0.0584f,0.1705f,-0.0303f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[-0.1746f,-0.0484f,0.9824f,0.0446f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.7871f,0.0103f,-0.0081f,-0.6167f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0081f,-0.6167f,0.7871f,0.0103f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.4013f,0.8442f,0.0988f],left_rotation:[0.0043f,-0.1842f,0.9828f,-0.0120f]}}
particle minecraft:cloud -62.84 69.39 -33.14 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud -61.35 69.39 -32.38 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -61.35 69.19 -32.38 -0.016 0.02 0.031 1 0 force
scoreboard players set #gx driftmountains -67254
scoreboard players set #gdx driftmountains 601
scoreboard players set #gy driftmountains 69173
scoreboard players set #gdy driftmountains -10
scoreboard players set #gz driftmountains -33289
scoreboard players set #gdz driftmountains -232
scoreboard players set #gr driftmountains -12378
scoreboard players set #gdr driftmountains -258
scoreboard players set #gp driftmountains 85
scoreboard players set #gdp driftmountains 2
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[0.0061f,-0.0000f,0.0077f,1.0000f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.8606f,-0.0105f,0.1242f,0.4939f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[-0.0729f,0.4835f,0.8664f,0.1010f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.7871f,0.0103f,-0.0081f,-0.6167f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0081f,-0.6167f,0.7871f,0.0103f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3733f,0.8732f,0.2503f],left_rotation:[0.0960f,-0.1672f,0.8436f,0.5013f]}}
particle minecraft:cloud -68.86 69.49 -33.24 0.35 0.18 0.35 0.02 2 force
particle minecraft:cloud -67.91 69.49 -31.82 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -67.91 69.29 -31.82 -0.035 0.02 0.023 1 0 force
scoreboard players set #gx driftmountains -72439
scoreboard players set #gdx driftmountains 720
scoreboard players set #gy driftmountains 69249
scoreboard players set #gdy driftmountains -10
scoreboard players set #gz driftmountains -29904
scoreboard players set #gdz driftmountains -326
scoreboard players set #gr driftmountains -11875
scoreboard players set #gdr driftmountains 43
scoreboard players set #gp driftmountains 72
scoreboard players set #gdp driftmountains 1
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,0.0000f,0.0025f,1.0000f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.9749f,0.0606f,0.0324f,-0.2117f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[-0.0548f,-0.2162f,0.9739f,0.0415f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.7871f,0.0103f,-0.0081f,-0.6167f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0081f,-0.6167f,0.7871f,0.0103f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3593f,0.8597f,0.1049f],left_rotation:[0.1742f,-0.0793f,0.3906f,0.9004f]}}
