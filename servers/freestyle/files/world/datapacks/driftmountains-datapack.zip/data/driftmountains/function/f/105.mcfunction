scoreboard players set #gx driftmountains -3725
scoreboard players set #gdx driftmountains 640
scoreboard players set #gy driftmountains 70451
scoreboard players set #gdy driftmountains 32
scoreboard players set #gz driftmountains -25930
scoreboard players set #gdz driftmountains 447
scoreboard players set #gr driftmountains -911
scoreboard players set #gdr driftmountains -77
scoreboard players set #gp driftmountains -186
scoreboard players set #gdp driftmountains 45
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.9151f,0.0107f,-0.3880f,-0.1095f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.3786f,-0.0693f,0.9190f,0.0854f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.2615f,0.0034f,0.0126f,0.9651f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0126f,0.9651f,0.2615f,0.0034f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3624f,0.8253f,0.0914f],left_rotation:[-0.1659f,-0.0743f,0.4281f,-0.8852f]}}
particle minecraft:cloud -3.10 70.77 -27.31 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -3.10 70.57 -27.31 -0.007 0.02 -0.046 1 0 force
particle minecraft:cloud -4.75 70.77 -27.04 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -7668
scoreboard players set #gdx driftmountains 771
scoreboard players set #gy driftmountains 70048
scoreboard players set #gdy driftmountains 79
scoreboard players set #gz driftmountains -29008
scoreboard players set #gdz driftmountains 302
scoreboard players set #gr driftmountains -2430
scoreboard players set #gdr driftmountains 454
scoreboard players set #gp driftmountains -369
scoreboard players set #gdp driftmountains -15
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[0.0038f,0.0001f,-0.0223f,0.9997f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.8446f,-0.0873f,-0.2821f,-0.4466f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.2367f,-0.4195f,0.8584f,0.1765f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.2615f,0.0034f,0.0126f,0.9651f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0126f,0.9651f,0.2615f,0.0034f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3558f,0.8534f,0.2426f],left_rotation:[-0.1634f,0.0894f,-0.4351f,-0.8809f]}}
particle minecraft:cloud -7.45 70.37 -30.60 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -7.45 70.17 -30.60 -0.019 0.02 -0.042 1 0 force
particle minecraft:cloud -9.01 70.37 -29.90 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -12481
scoreboard players set #gdx driftmountains 828
scoreboard players set #gy driftmountains 69676
scoreboard players set #gdy driftmountains 60
scoreboard players set #gz driftmountains -29346
scoreboard players set #gdz driftmountains 97
scoreboard players set #gr driftmountains -3814
scoreboard players set #gdr driftmountains 177
scoreboard players set #gp driftmountains -286
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[0.0061f,0.0001f,-0.0223f,0.9997f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.5973f,0.3114f,-0.1870f,0.7151f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.2632f,0.7387f,0.5678f,-0.2504f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.2615f,0.0034f,0.0126f,0.9651f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0126f,0.9651f,0.2615f,0.0034f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3547f,0.8339f,0.0948f],left_rotation:[-0.1821f,-0.0310f,0.1995f,-0.9623f]}}
particle minecraft:cloud -12.60 70.00 -30.85 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -12.60 69.80 -30.85 -0.031 0.02 -0.040 1 0 force
particle minecraft:cloud -13.92 70.00 -29.82 0.35 0.18 0.35 0.02 3 force
