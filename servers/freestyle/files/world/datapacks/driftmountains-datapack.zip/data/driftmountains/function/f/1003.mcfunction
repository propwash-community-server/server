scoreboard players set #gx driftmountains 27051
scoreboard players set #gdx driftmountains 191
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 30315
scoreboard players set #gdz driftmountains 1027
scoreboard players set #gr driftmountains 4026
scoreboard players set #gdr driftmountains 342
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[0.0047f,0.0001f,-0.0223f,0.9997f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.7027f,0.2984f,-0.2678f,0.5877f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.3311f,0.6191f,0.6752f,-0.2262f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.9864f,0.0129f,-0.0021f,-0.1640f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0021f,-0.1640f,0.9864f,0.0129f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3679f,0.8225f,0.0903f],left_rotation:[-0.1534f,-0.0953f,0.5377f,-0.8235f]}}
particle minecraft:cloud 28.50 71.32 29.89 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 28.50 71.12 29.89 0.041 0.02 -0.048 1 0 force
particle minecraft:cloud 27.23 71.32 28.81 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains 25538
scoreboard players set #gdx driftmountains 501
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 23426
scoreboard players set #gdz driftmountains 873
scoreboard players set #gr driftmountains 1047
scoreboard players set #gdr driftmountains 425
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.0493f,0.3134f,0.0388f,0.9475f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.0605f,0.9487f,0.0166f,-0.3100f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.9864f,0.0129f,-0.0021f,-0.1640f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0021f,-0.1640f,0.9864f,0.0129f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3567f,0.8441f,0.2389f],left_rotation:[-0.1751f,0.0540f,-0.2522f,-0.9502f]}}
particle minecraft:cloud 26.63 71.32 22.24 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 26.63 71.12 22.24 0.010 0.02 -0.054 1 0 force
particle minecraft:cloud 24.95 71.32 21.93 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains 22454
scoreboard players set #gdx driftmountains 351
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 18754
scoreboard players set #gdz driftmountains 890
scoreboard players set #gr driftmountains 948
scoreboard players set #gdr driftmountains 276
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0001f,-0.0195f,0.9998f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.9243f,-0.0216f,-0.2554f,-0.2829f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.2270f,-0.2576f,0.9316f,0.1189f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.9864f,0.0129f,-0.0021f,-0.1640f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0021f,-0.1640f,0.9864f,0.0129f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3782f,0.8665f,0.1076f],left_rotation:[-0.1302f,0.1410f,-0.7285f,-0.6575f]}}
particle minecraft:cloud 23.48 71.32 17.65 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 23.48 71.12 17.65 0.010 0.02 -0.062 1 0 force
particle minecraft:cloud 21.84 71.32 17.37 0.35 0.18 0.35 0.02 3 force
