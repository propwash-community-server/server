scoreboard players set #gx driftmountains -56353
scoreboard players set #gdx driftmountains -77
scoreboard players set #gy driftmountains 68155
scoreboard players set #gdy driftmountains -13
scoreboard players set #gz driftmountains -67206
scoreboard players set #gdz driftmountains -679
scoreboard players set #gr driftmountains -15866
scoreboard players set #gdr driftmountains 240
scoreboard players set #gp driftmountains 93
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[0.0061f,0.0001f,-0.0172f,0.9998f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.8370f,-0.0654f,-0.2143f,-0.4993f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.1630f,-0.4795f,0.8485f,0.1537f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.8728f,0.0114f,0.0064f,0.4878f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0064f,0.4878f,0.8728f,0.0114f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3922f,0.8615f,0.1056f],left_rotation:[-0.0830f,0.1705f,-0.8949f,-0.4040f]}}
particle minecraft:cloud -57.59 68.48 -66.34 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -57.59 68.28 -66.34 -0.015 0.02 0.039 1 0 force
particle minecraft:cloud -56.03 68.48 -65.73 0.35 0.18 0.35 0.02 2 force
scoreboard players set #gx driftmountains -54903
scoreboard players set #gdx driftmountains -115
scoreboard players set #gy driftmountains 68265
scoreboard players set #gdy driftmountains -13
scoreboard players set #gz driftmountains -61059
scoreboard players set #gdz driftmountains -765
scoreboard players set #gr driftmountains 17304
scoreboard players set #gdr driftmountains 453
scoreboard players set #gp driftmountains 95
scoreboard players set #gdp driftmountains -2
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0000f,-0.0010f,1.0000f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.8247f,0.0488f,0.0213f,0.5631f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.0378f,0.5640f,0.8241f,0.0376f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.8728f,0.0114f,0.0064f,0.4878f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0064f,0.4878f,0.8728f,0.0114f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3669f,0.8311f,0.2338f],left_rotation:[0.1788f,0.0119f,-0.0867f,0.9800f]}}
scoreboard players set #gx driftmountains -53930
scoreboard players set #gdx driftmountains -58
scoreboard players set #gy driftmountains 68377
scoreboard players set #gdy driftmountains -14
scoreboard players set #gz driftmountains -55067
scoreboard players set #gdz driftmountains -653
scoreboard players set #gr driftmountains 14849
scoreboard players set #gdr driftmountains 155
scoreboard players set #gp driftmountains 108
scoreboard players set #gdp driftmountains -2
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,0.0001f,0.0164f,0.9999f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.3307f,0.1901f,0.0115f,-0.9243f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[-0.1087f,-0.9306f,0.3126f,-0.1564f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.8728f,0.0114f,0.0064f,0.4878f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0064f,0.4878f,0.8728f,0.0114f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.4009f,0.8398f,0.0971f],left_rotation:[-0.0142f,-0.1824f,0.9770f,-0.1086f]}}
particle minecraft:cloud -53.98 68.70 -53.56 0.35 0.18 0.35 0.02 2 force
particle minecraft:cloud -52.56 68.70 -54.43 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -52.56 68.50 -54.43 0.020 0.02 0.033 1 0 force
