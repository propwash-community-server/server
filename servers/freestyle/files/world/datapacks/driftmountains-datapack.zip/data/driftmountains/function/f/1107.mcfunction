scoreboard players set #gx driftmountains -64843
scoreboard players set #gdx driftmountains -1017
scoreboard players set #gy driftmountains 70482
scoreboard players set #gdy driftmountains -17
scoreboard players set #gz driftmountains 37905
scoreboard players set #gdz driftmountains -939
scoreboard players set #gr driftmountains 17964
scoreboard players set #gdr driftmountains 62
scoreboard players set #gp driftmountains 44
scoreboard players set #gdp driftmountains 8
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.8671f,-0.0773f,-0.3772f,-0.3161f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.3461f,-0.2782f,0.8800f,0.1688f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.5752f,0.0075f,-0.0107f,-0.8179f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0107f,-0.8179f,0.5752f,0.0075f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3612f,0.8262f,0.0918f],left_rotation:[-0.1684f,-0.0692f,0.4010f,-0.8977f]}}
particle minecraft:cloud -65.67 70.80 39.17 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -65.67 70.60 39.17 0.001 0.02 0.083 1 0 force
particle minecraft:cloud -64.00 70.80 39.16 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -55730
scoreboard players set #gdx driftmountains -1208
scoreboard players set #gy driftmountains 70503
scoreboard players set #gdy driftmountains 6
scoreboard players set #gz driftmountains 43795
scoreboard players set #gdz driftmountains -705
scoreboard players set #gr driftmountains 16659
scoreboard players set #gdr driftmountains 197
scoreboard players set #gp driftmountains -19
scoreboard players set #gdp driftmountains 4
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.8254f,0.2203f,-0.3110f,0.4166f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.3565f,0.4515f,0.8068f,-0.1347f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.5752f,0.0075f,-0.0107f,-0.8179f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0107f,-0.8179f,0.5752f,0.0075f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3809f,0.8272f,0.2323f],left_rotation:[-0.1653f,-0.0666f,0.3650f,-0.9138f]}}
particle minecraft:cloud -56.25 70.82 45.32 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -56.25 70.62 45.32 0.020 0.02 0.082 1 0 force
particle minecraft:cloud -54.58 70.82 44.92 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -51170
scoreboard players set #gdx driftmountains -1278
scoreboard players set #gy driftmountains 70476
scoreboard players set #gdy driftmountains 6
scoreboard players set #gz driftmountains 46759
scoreboard players set #gdz driftmountains -639
scoreboard players set #gr driftmountains 16086
scoreboard players set #gdr driftmountains 178
scoreboard players set #gp driftmountains -16
scoreboard players set #gdp driftmountains -3
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.2025f,-0.3437f,-0.1343f,-0.9071f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.0397f,-0.8980f,0.2397f,0.3669f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.5752f,0.0075f,-0.0107f,-0.8179f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0107f,-0.8179f,0.5752f,0.0075f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3561f,0.8316f,0.0939f],left_rotation:[-0.1793f,-0.0412f,0.2539f,-0.9495f]}}
particle minecraft:cloud -51.55 70.80 48.22 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -51.55 70.60 48.22 0.028 0.02 0.081 1 0 force
particle minecraft:cloud -49.97 70.80 47.68 0.35 0.18 0.35 0.02 3 force
