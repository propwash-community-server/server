scoreboard players set #gx driftmountains -65625
scoreboard players set #gdx driftmountains 643
scoreboard players set #gy driftmountains 69149
scoreboard players set #gdy driftmountains -11
scoreboard players set #gz driftmountains -32139
scoreboard players set #gdz driftmountains -226
scoreboard players set #gr driftmountains -12767
scoreboard players set #gdr driftmountains -358
scoreboard players set #gp driftmountains 84
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[0.0061f,-0.0001f,0.0112f,0.9999f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.9456f,0.0092f,0.1514f,0.2879f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[-0.1220f,0.2736f,0.9498f,0.0902f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.5869f,0.0077f,-0.0106f,-0.8096f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0106f,-0.8096f,0.5869f,0.0077f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3973f,0.8562f,0.1035f],left_rotation:[0.0553f,-0.1794f,0.9479f,0.2571f]}}
particle minecraft:cloud -67.13 69.47 -32.03 0.35 0.18 0.35 0.02 2 force
particle minecraft:cloud -66.11 69.47 -30.71 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -66.11 69.27 -30.71 -0.033 0.02 0.025 1 0 force
scoreboard players set #gx driftmountains -72118
scoreboard players set #gdx driftmountains 688
scoreboard players set #gy driftmountains 69244
scoreboard players set #gdy driftmountains -10
scoreboard players set #gz driftmountains -31297
scoreboard players set #gdz driftmountains -305
scoreboard players set #gr driftmountains -11849
scoreboard players set #gdr driftmountains 47
scoreboard players set #gp driftmountains 73
scoreboard players set #gdp driftmountains 1
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[-0.0039f,0.0000f,0.0026f,1.0000f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.4508f,0.0693f,-0.0236f,-0.8896f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[-0.0697f,-0.8920f,0.4460f,-0.0223f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.5869f,0.0077f,-0.0106f,-0.8096f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0106f,-0.8096f,0.5869f,0.0077f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3559f,0.8538f,0.2427f],left_rotation:[0.1626f,-0.0910f,0.4433f,0.8768f]}}
scoreboard players set #gx driftmountains -77222
scoreboard players set #gdx driftmountains 673
scoreboard players set #gy driftmountains 69318
scoreboard players set #gdy driftmountains -10
scoreboard players set #gz driftmountains -27773
scoreboard players set #gdz driftmountains -273
scoreboard players set #gr driftmountains -13075
scoreboard players set #gdr driftmountains 45
scoreboard players set #gp driftmountains 77
scoreboard players set #gdp driftmountains -2
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,0.0000f,0.0119f,0.9999f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.2290f,-0.1103f,0.0804f,0.9638f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.0204f,0.9607f,0.2419f,0.1350f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.5869f,0.0077f,-0.0106f,-0.8096f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0106f,-0.8096f,0.5869f,0.0077f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3925f,0.8613f,0.1055f],left_rotation:[0.0814f,-0.1711f,0.8986f,0.3956f]}}
particle minecraft:cloud -78.72 69.64 -27.58 0.35 0.18 0.35 0.02 2 force
particle minecraft:cloud -77.63 69.64 -26.32 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -77.63 69.44 -26.32 -0.032 0.02 0.028 1 0 force
