scoreboard players set #gx driftmountains -10262
scoreboard players set #gdx driftmountains 778
scoreboard players set #gy driftmountains 67004
scoreboard players set #gdy driftmountains -10
scoreboard players set #gz driftmountains -78211
scoreboard players set #gdz driftmountains 502
scoreboard players set #gr driftmountains -4106
scoreboard players set #gdr driftmountains -139
scoreboard players set #gp driftmountains 62
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0000f,-0.0099f,0.9999f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.9873f,0.0444f,-0.1402f,-0.0605f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.1346f,-0.0461f,0.9881f,0.0592f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.6665f,0.0087f,-0.0098f,-0.7454f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0098f,-0.7454f,0.6665f,0.0087f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3971f,0.8310f,0.0936f],left_rotation:[0.0528f,0.1729f,-0.9334f,0.3098f]}}
particle minecraft:cloud -10.46 67.32 -79.71 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -10.46 67.12 -79.71 -0.036 0.02 -0.042 1 0 force
particle minecraft:cloud -11.72 67.32 -78.61 0.35 0.18 0.35 0.02 2 force
scoreboard players set #gx driftmountains -16994
scoreboard players set #gdx driftmountains 769
scoreboard players set #gy driftmountains 67095
scoreboard players set #gdy driftmountains -11
scoreboard players set #gz driftmountains -82034
scoreboard players set #gdz driftmountains 483
scoreboard players set #gr driftmountains -3231
scoreboard players set #gdr driftmountains -86
scoreboard players set #gp driftmountains 63
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0001f,-0.0156f,0.9999f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.7895f,0.1716f,-0.1458f,0.5709f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.2066f,0.5894f,0.7758f,-0.0896f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.6665f,0.0087f,-0.0098f,-0.7454f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0098f,-0.7454f,0.6665f,0.0087f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3782f,0.8742f,0.2507f],left_rotation:[-0.0804f,0.1756f,-0.8891f,-0.4150f]}}
particle minecraft:cloud -17.00 67.41 -83.64 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -17.00 67.21 -83.64 -0.028 0.02 -0.045 1 0 force
particle minecraft:cloud -18.45 67.41 -82.73 0.35 0.18 0.35 0.02 2 force
scoreboard players set #gx driftmountains -24310
scoreboard players set #gdx driftmountains 714
scoreboard players set #gy driftmountains 67208
scoreboard players set #gdy driftmountains -11
scoreboard players set #gz driftmountains -87140
scoreboard players set #gdz driftmountains 403
scoreboard players set #gr driftmountains -3203
scoreboard players set #gdr driftmountains 47
scoreboard players set #gp driftmountains 68
scoreboard players set #gdp driftmountains -1
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.9263f,-0.0185f,-0.2384f,-0.2912f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.2091f,-0.2678f,0.9333f,0.1160f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.6665f,0.0087f,-0.0098f,-0.7454f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0098f,-0.7454f,0.6665f,0.0087f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3861f,0.8649f,0.1069f],left_rotation:[-0.1063f,0.1586f,-0.8270f,-0.5287f]}}
particle minecraft:cloud -24.27 67.53 -88.65 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -24.27 67.33 -88.65 -0.026 0.02 -0.041 1 0 force
particle minecraft:cloud -25.69 67.53 -87.77 0.35 0.18 0.35 0.02 2 force
