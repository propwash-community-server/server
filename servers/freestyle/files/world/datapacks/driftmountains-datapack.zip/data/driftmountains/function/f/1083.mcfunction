scoreboard players set #gx driftmountains -36691
scoreboard players set #gdx driftmountains -1175
scoreboard players set #gy driftmountains 70643
scoreboard players set #gdy driftmountains -38
scoreboard players set #gz driftmountains 52089
scoreboard players set #gdz driftmountains -406
scoreboard players set #gr driftmountains 15525
scoreboard players set #gdr driftmountains -26
scoreboard players set #gp driftmountains 124
scoreboard players set #gdp driftmountains -9
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.8642f,-0.0796f,-0.3837f,-0.3155f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.3526f,-0.2770f,0.8774f,0.1709f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.5263f,0.0069f,-0.0111f,-0.8502f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0111f,-0.8502f,0.5263f,0.0069f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3639f,0.8244f,0.0911f],left_rotation:[-0.1625f,-0.0805f,0.4606f,-0.8688f]}}
particle minecraft:cloud -36.92 70.96 53.58 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -36.92 70.76 53.58 0.031 0.02 0.068 1 0 force
particle minecraft:cloud -35.41 70.96 52.88 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -26723
scoreboard players set #gdx driftmountains -1246
scoreboard players set #gy driftmountains 70962
scoreboard players set #gdy driftmountains -29
scoreboard players set #gz driftmountains 55477
scoreboard players set #gdz driftmountains -386
scoreboard players set #gr driftmountains 15312
scoreboard players set #gdr driftmountains 35
scoreboard players set #gp driftmountains 83
scoreboard players set #gdp driftmountains 14
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.8225f,0.2240f,-0.3184f,0.4146f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.3638f,0.4503f,0.8035f,-0.1388f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.5263f,0.0069f,-0.0111f,-0.8502f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0111f,-0.8502f,0.5263f,0.0069f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3850f,0.8275f,0.2324f],left_rotation:[-0.1589f,-0.0811f,0.4385f,-0.8809f]}}
particle minecraft:cloud -26.87 71.28 57.08 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -26.87 71.08 57.08 0.033 0.02 0.064 1 0 force
particle minecraft:cloud -25.34 71.28 56.31 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -22121
scoreboard players set #gdx driftmountains -1157
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains -1
scoreboard players set #gz driftmountains 57031
scoreboard players set #gdz driftmountains -329
scoreboard players set #gr driftmountains 15190
scoreboard players set #gdr driftmountains 23
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 6
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.1991f,-0.3660f,-0.1393f,-0.8984f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.0456f,-0.8887f,0.2386f,0.3889f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.5263f,0.0069f,-0.0111f,-0.8502f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0111f,-0.8502f,0.5263f,0.0069f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3638f,0.8245f,0.0911f],left_rotation:[-0.1628f,-0.0801f,0.4583f,-0.8700f]}}
particle minecraft:cloud -22.26 71.32 58.54 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -22.26 71.12 58.54 0.034 0.02 0.063 1 0 force
particle minecraft:cloud -20.79 71.32 57.75 0.35 0.18 0.35 0.02 3 force
