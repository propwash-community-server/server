scoreboard players set #gx driftmountains 26506
scoreboard players set #gdx driftmountains 1075
scoreboard players set #gy driftmountains 66531
scoreboard players set #gdy driftmountains -14
scoreboard players set #gz driftmountains -54223
scoreboard players set #gdz driftmountains 584
scoreboard players set #gr driftmountains -5962
scoreboard players set #gdr driftmountains 65
scoreboard players set #gp driftmountains 64
scoreboard players set #gdp driftmountains 1
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0000f,-0.0012f,1.0000f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.9489f,0.0444f,-0.0326f,-0.3109f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.0001f,-0.3091f,0.9494f,0.0551f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.5378f,0.0070f,-0.0110f,-0.8429f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0110f,-0.8429f,0.5378f,0.0070f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3538f,0.8360f,0.0956f],left_rotation:[0.1840f,0.0218f,-0.1511f,0.9709f]}}
scoreboard players set #gx driftmountains 19001
scoreboard players set #gdx driftmountains 1090
scoreboard players set #gy driftmountains 66626
scoreboard players set #gdy driftmountains -14
scoreboard players set #gz driftmountains -58699
scoreboard players set #gdz driftmountains 709
scoreboard players set #gr driftmountains -5889
scoreboard players set #gdr driftmountains 52
scoreboard players set #gp driftmountains 62
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[-0.0039f,0.0000f,0.0011f,1.0000f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.9284f,0.0422f,0.0356f,0.3675f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.0029f,0.3658f,0.9290f,0.0551f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.5378f,0.0070f,-0.0110f,-0.8429f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0110f,-0.8429f,0.5378f,0.0070f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3585f,0.8398f,0.2372f],left_rotation:[0.1783f,-0.0359f,0.1586f,0.9705f]}}
scoreboard players set #gx driftmountains 9891
scoreboard players set #gdx driftmountains 910
scoreboard players set #gy driftmountains 66744
scoreboard players set #gdy driftmountains -12
scoreboard players set #gz driftmountains -64882
scoreboard players set #gdz driftmountains 602
scoreboard players set #gr driftmountains -5701
scoreboard players set #gdr driftmountains -81
scoreboard players set #gp driftmountains 60
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,0.0000f,0.0003f,1.0000f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.9593f,0.0515f,-0.0103f,-0.2775f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[-0.0189f,-0.2780f,0.9591f,0.0490f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.5378f,0.0070f,-0.0110f,-0.8429f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0110f,-0.8429f,0.5378f,0.0070f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3523f,0.8448f,0.0991f],left_rotation:[0.1873f,-0.0145f,0.0424f,0.9812f]}}
