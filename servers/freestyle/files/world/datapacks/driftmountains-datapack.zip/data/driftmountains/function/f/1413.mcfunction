scoreboard players set #gx driftmountains 29726
scoreboard players set #gdx driftmountains 1076
scoreboard players set #gy driftmountains 66490
scoreboard players set #gdy driftmountains -14
scoreboard players set #gz driftmountains -52418
scoreboard players set #gdz driftmountains 626
scoreboard players set #gr driftmountains -5718
scoreboard players set #gdr driftmountains -81
scoreboard players set #gp driftmountains 64
scoreboard players set #gdp driftmountains -1
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0000f,-0.0015f,1.0000f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.4513f,0.0107f,-0.0533f,-0.8907f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[-0.0401f,-0.8900f,0.4526f,0.0367f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.2086f,0.0027f,0.0128f,0.9779f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0128f,0.9779f,0.2086f,0.0027f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3534f,0.8370f,0.0960f],left_rotation:[0.1848f,0.0174f,-0.1277f,0.9742f]}}
scoreboard players set #gx driftmountains 22142
scoreboard players set #gdx driftmountains 1026
scoreboard players set #gy driftmountains 66586
scoreboard players set #gdy driftmountains -13
scoreboard players set #gz driftmountains -56646
scoreboard players set #gdz driftmountains 682
scoreboard players set #gr driftmountains -5746
scoreboard players set #gdr driftmountains 122
scoreboard players set #gp driftmountains 62
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[-0.0039f,0.0000f,0.0005f,1.0000f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.9163f,0.0536f,-0.0079f,-0.3968f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[-0.0337f,-0.3981f,0.9157f,0.0424f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.2086f,0.0027f,0.0128f,0.9779f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0128f,0.9779f,0.2086f,0.0027f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3593f,0.8385f,0.2367f],left_rotation:[0.1790f,-0.0298f,0.1274f,0.9751f]}}
scoreboard players set #gx driftmountains 12786
scoreboard players set #gdx driftmountains 1009
scoreboard players set #gy driftmountains 66707
scoreboard players set #gdy driftmountains -13
scoreboard players set #gz driftmountains -62966
scoreboard players set #gdz driftmountains 666
scoreboard players set #gr driftmountains -5855
scoreboard players set #gdr driftmountains -26
scoreboard players set #gp driftmountains 61
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,0.0000f,0.0012f,1.0000f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.4825f,0.0394f,-0.0381f,-0.8742f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[-0.0536f,-0.8750f,0.4811f,0.0111f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.2086f,0.0027f,0.0128f,0.9779f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0128f,0.9779f,0.2086f,0.0027f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3531f,0.8496f,0.1009f],left_rotation:[0.1860f,-0.0339f,0.1460f,0.9710f]}}
