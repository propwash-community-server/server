scoreboard players set #gx driftmountains 39565
scoreboard players set #gdx driftmountains 1114
scoreboard players set #gy driftmountains 66370
scoreboard players set #gdy driftmountains -13
scoreboard players set #gz driftmountains -46530
scoreboard players set #gdz driftmountains 690
scoreboard players set #gr driftmountains -4713
scoreboard players set #gdr driftmountains 328
scoreboard players set #gp driftmountains 55
scoreboard players set #gdp driftmountains -1
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0000f,-0.0068f,1.0000f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.9433f,0.0197f,-0.1074f,-0.3134f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.0750f,-0.3038f,0.9464f,0.0793f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.5623f,0.0074f,-0.0108f,-0.8268f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0108f,-0.8268f,0.5623f,0.0074f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3820f,0.8215f,0.0899f],left_rotation:[0.1159f,0.1367f,-0.7519f,0.6343f]}}
particle minecraft:cloud 39.21 66.69 -48.00 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke 39.21 66.49 -48.00 -0.057 0.02 -0.053 1 0 force
particle minecraft:cloud 38.07 66.69 -46.78 0.35 0.18 0.35 0.02 2 force
scoreboard players set #gx driftmountains 31393
scoreboard players set #gdx driftmountains 1029
scoreboard players set #gy driftmountains 66459
scoreboard players set #gdy driftmountains -13
scoreboard players set #gz driftmountains -50040
scoreboard players set #gdz driftmountains 723
scoreboard players set #gr driftmountains -5373
scoreboard players set #gdr driftmountains -43
scoreboard players set #gp driftmountains 62
scoreboard players set #gdp driftmountains -1
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0000f,-0.0007f,1.0000f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.9290f,0.0526f,0.0092f,0.3662f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.0292f,0.3672f,0.9286f,0.0447f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.5623f,0.0074f,-0.0108f,-0.8268f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0108f,-0.8268f,0.5623f,0.0074f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3672f,0.8309f,0.2338f],left_rotation:[0.1787f,0.0133f,-0.0938f,0.9794f]}}
scoreboard players set #gx driftmountains 22078
scoreboard players set #gdx driftmountains 1154
scoreboard players set #gy driftmountains 66589
scoreboard players set #gdy driftmountains -15
scoreboard players set #gz driftmountains -57012
scoreboard players set #gdz driftmountains 678
scoreboard players set #gr driftmountains -5935
scoreboard players set #gdr driftmountains -223
scoreboard players set #gp driftmountains 62
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[0.0033f,-0.0000f,0.0005f,1.0000f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.9586f,0.0437f,-0.0372f,-0.2789f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.0081f,-0.2765f,0.9593f,0.0568f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.5623f,0.0074f,-0.0108f,-0.8268f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0108f,-0.8268f,0.5623f,0.0074f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3549f,0.8335f,0.0946f],left_rotation:[0.1817f,0.0324f,-0.2072f,0.9607f]}}
