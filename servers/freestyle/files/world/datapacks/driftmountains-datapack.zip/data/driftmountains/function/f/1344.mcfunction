scoreboard players set #gx driftmountains -28174
scoreboard players set #gdx driftmountains 669
scoreboard players set #gy driftmountains 67267
scoreboard players set #gdy driftmountains -11
scoreboard players set #gz driftmountains -88757
scoreboard players set #gdz driftmountains 327
scoreboard players set #gr driftmountains -3479
scoreboard players set #gdr driftmountains 32
scoreboard players set #gp driftmountains 74
scoreboard players set #gdp driftmountains -1
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0001f,-0.0180f,0.9998f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.8870f,-0.0469f,-0.2395f,-0.3921f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.1996f,-0.3690f,0.8968f,0.1404f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.9184f,0.0120f,0.0052f,0.3955f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0052f,0.3955f,0.9184f,0.0120f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3839f,0.8656f,0.1072f],left_rotation:[-0.1135f,0.1539f,-0.8007f,-0.5676f]}}
particle minecraft:cloud -28.21 67.59 -90.27 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -28.21 67.39 -90.27 -0.025 0.02 -0.037 1 0 force
particle minecraft:cloud -29.58 67.59 -89.31 0.35 0.18 0.35 0.02 2 force
playsound driftgen:grain.kaze.033 neutral @a -22.71 67.68 -85.90 12 1
scoreboard players set #gx driftmountains -34026
scoreboard players set #gdx driftmountains 623
scoreboard players set #gy driftmountains 67372
scoreboard players set #gdy driftmountains -12
scoreboard players set #gz driftmountains -91097
scoreboard players set #gdz driftmountains 198
scoreboard players set #gr driftmountains -4083
scoreboard players set #gdr driftmountains 212
scoreboard players set #gp driftmountains 92
scoreboard players set #gdp driftmountains -1
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0001f,-0.0201f,0.9998f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.0138f,0.2025f,0.0506f,0.9779f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.0519f,0.9780f,-0.0074f,-0.2021f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.9184f,0.0120f,0.0052f,0.3955f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0052f,0.3955f,0.9184f,0.0120f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3862f,0.8738f,0.2506f],left_rotation:[-0.0540f,0.1855f,-0.9435f,-0.2693f]}}
particle minecraft:cloud -34.27 67.69 -92.69 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -34.27 67.49 -92.69 -0.026 0.02 -0.030 1 0 force
particle minecraft:cloud -35.57 67.69 -91.57 0.35 0.18 0.35 0.02 3 force
playsound driftgen:grain.onyx.036 neutral @a -28.97 67.78 -88.95 12 1
scoreboard players set #gx driftmountains -39764
scoreboard players set #gdx driftmountains 521
scoreboard players set #gy driftmountains 67510
scoreboard players set #gdy driftmountains -14
scoreboard players set #gz driftmountains -92244
scoreboard players set #gdz driftmountains -95
scoreboard players set #gr driftmountains -6657
scoreboard players set #gdr driftmountains 456
scoreboard players set #gp driftmountains 123
scoreboard players set #gdp driftmountains 4
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[0.0020f,0.0000f,-0.0220f,0.9998f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.9265f,-0.0055f,-0.1710f,-0.3352f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.1367f,-0.3191f,0.9322f,0.1029f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.9184f,0.0120f,0.0052f,0.3955f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0052f,0.3955f,0.9184f,0.0120f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.4011f,0.8409f,0.0975f],left_rotation:[0.0095f,0.1830f,-0.9794f,0.0840f]}}
particle minecraft:cloud -40.59 67.83 -93.51 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -40.59 67.63 -93.51 -0.030 0.02 -0.013 1 0 force
particle minecraft:cloud -41.25 67.83 -91.98 0.35 0.18 0.35 0.02 3 force
playsound driftgen:grain.kaze.033 neutral @a -35.28 67.90 -91.95 12 1
