scoreboard players set #gx driftmountains -587
scoreboard players set #gdx driftmountains 841
scoreboard players set #gy driftmountains 66877
scoreboard players set #gdy driftmountains -11
scoreboard players set #gz driftmountains -71826
scoreboard players set #gdz driftmountains 566
scoreboard players set #gr driftmountains -5029
scoreboard players set #gdr driftmountains -29
scoreboard players set #gp driftmountains 61
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0000f,-0.0035f,1.0000f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.9958f,0.0495f,-0.0519f,-0.0563f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.0463f,-0.0512f,0.9961f,0.0548f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.6880f,0.0090f,-0.0095f,-0.7256f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0095f,-0.7256f,0.6880f,0.0090f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3622f,0.8255f,0.0915f],left_rotation:[0.1664f,0.0733f,-0.4227f,0.8878f]}}
scoreboard players set #gx driftmountains -7534
scoreboard players set #gdx driftmountains 762
scoreboard players set #gy driftmountains 66966
scoreboard players set #gdy driftmountains -10
scoreboard players set #gz driftmountains -76066
scoreboard players set #gdz driftmountains 484
scoreboard players set #gr driftmountains -4640
scoreboard players set #gdr driftmountains -99
scoreboard players set #gp driftmountains 62
scoreboard players set #gdp driftmountains 1
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0000f,-0.0068f,1.0000f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.8016f,0.0990f,-0.0461f,0.5879f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.1082f,0.5959f,0.7956f,-0.0153f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.6880f,0.0090f,-0.0095f,-0.7256f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0095f,-0.7256f,0.6880f,0.0090f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.4020f,0.8376f,0.2364f],left_rotation:[0.1122f,0.1435f,-0.7516f,0.6340f]}}
particle minecraft:cloud -7.93 67.29 -77.63 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -7.93 67.09 -77.63 -0.043 0.02 -0.041 1 0 force
particle minecraft:cloud -9.11 67.29 -76.39 0.35 0.18 0.35 0.02 2 force
scoreboard players set #gx driftmountains -15505
scoreboard players set #gdx driftmountains 749
scoreboard players set #gy driftmountains 67077
scoreboard players set #gdy driftmountains -11
scoreboard players set #gz driftmountains -81683
scoreboard players set #gdz driftmountains 491
scoreboard players set #gr driftmountains -3225
scoreboard players set #gdr driftmountains -102
scoreboard players set #gp driftmountains 62
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0001f,-0.0150f,0.9999f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.9758f,0.0469f,-0.2112f,-0.0306f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.2092f,-0.0086f,0.9763f,0.0554f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.6880f,0.0090f,-0.0095f,-0.7256f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0095f,-0.7256f,0.6880f,0.0090f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3948f,0.8593f,0.1047f],left_rotation:[-0.0705f,0.1751f,-0.9222f,-0.3373f]}}
particle minecraft:cloud -15.47 67.40 -83.19 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -15.47 67.20 -83.19 -0.030 0.02 -0.047 1 0 force
particle minecraft:cloud -16.88 67.40 -82.30 0.35 0.18 0.35 0.02 2 force
