scoreboard players set #gx driftmountains -81354
scoreboard players set #gdx driftmountains 614
scoreboard players set #gy driftmountains 69388
scoreboard players set #gdy driftmountains -11
scoreboard players set #gz driftmountains -26838
scoreboard players set #gdz driftmountains -84
scoreboard players set #gr driftmountains -9500
scoreboard players set #gdr driftmountains -609
scoreboard players set #gp driftmountains 105
scoreboard players set #gdp driftmountains -1
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0000f,-0.0010f,1.0000f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.9808f,0.0603f,-0.0381f,0.1816f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.0574f,0.1866f,0.9799f,0.0424f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.5384f,0.0070f,-0.0110f,-0.8426f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0110f,-0.8426f,0.5384f,0.0070f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3620f,0.8256f,0.0915f],left_rotation:[0.1668f,0.0724f,-0.4180f,0.8900f]}}
scoreboard players set #gx driftmountains -87087
scoreboard players set #gdx driftmountains 518
scoreboard players set #gy driftmountains 69519
scoreboard players set #gdy driftmountains -15
scoreboard players set #gz driftmountains -25957
scoreboard players set #gdz driftmountains -301
scoreboard players set #gr driftmountains -7712
scoreboard players set #gdr driftmountains 92
scoreboard players set #gp driftmountains 105
scoreboard players set #gdp driftmountains 5
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.6206f,0.2536f,-0.1445f,0.7278f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.2218f,0.7470f,0.5974f,-0.1898f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.5384f,0.0070f,-0.0110f,-0.8426f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0110f,-0.8426f,0.5384f,0.0070f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3560f,0.8549f,0.2431f],left_rotation:[-0.1608f,0.0948f,-0.4634f,-0.8663f]}}
particle minecraft:cloud -88.23 69.84 -27.09 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -88.23 69.64 -27.09 -0.036 0.02 -0.008 1 0 force
particle minecraft:cloud -88.61 69.84 -25.43 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -89788
scoreboard players set #gdx driftmountains 567
scoreboard players set #gy driftmountains 69616
scoreboard players set #gdy driftmountains -18
scoreboard players set #gz driftmountains -23616
scoreboard players set #gdz driftmountains -370
scoreboard players set #gr driftmountains -7810
scoreboard players set #gdr driftmountains 200
scoreboard players set #gp driftmountains 106
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.8403f,-0.1016f,-0.3286f,-0.4189f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.2864f,-0.3867f,0.8557f,0.1905f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.5384f,0.0070f,-0.0110f,-0.8426f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0110f,-0.8426f,0.5384f,0.0070f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3524f,0.8422f,0.0980f],left_rotation:[-0.1871f,0.0039f,0.0145f,-0.9822f]}}
particle minecraft:cloud -90.85 69.94 -24.69 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -90.85 69.74 -24.69 -0.041 0.02 -0.009 1 0 force
particle minecraft:cloud -91.19 69.94 -23.06 0.35 0.18 0.35 0.02 3 force
