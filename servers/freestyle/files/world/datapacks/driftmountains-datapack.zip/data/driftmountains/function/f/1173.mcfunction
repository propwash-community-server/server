scoreboard players set #gx driftmountains -94023
scoreboard players set #gdx driftmountains 513
scoreboard players set #gy driftmountains 69763
scoreboard players set #gdy driftmountains -20
scoreboard players set #gz driftmountains -19891
scoreboard players set #gdz driftmountains -590
scoreboard players set #gr driftmountains -9352
scoreboard players set #gdr driftmountains 116
scoreboard players set #gp driftmountains 99
scoreboard players set #gdp driftmountains 3
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[0.0061f,0.0001f,-0.0223f,0.9997f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.8582f,0.1896f,-0.2944f,0.3753f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.3355f,0.4083f,0.8430f,-0.1005f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.7149f,0.0094f,0.0092f,0.6991f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0092f,0.6991f,0.7149f,0.0094f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3528f,0.8394f,0.0969f],left_rotation:[-0.1862f,-0.0074f,0.0746f,-0.9796f]}}
particle minecraft:cloud -95.33 70.08 -20.65 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -95.33 69.88 -20.65 -0.047 0.02 0.003 1 0 force
particle minecraft:cloud -95.23 70.08 -18.98 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -97552
scoreboard players set #gdx driftmountains 227
scoreboard players set #gy driftmountains 69922
scoreboard players set #gdy driftmountains -15
scoreboard players set #gz driftmountains -13866
scoreboard players set #gdz driftmountains -714
scoreboard players set #gr driftmountains -11417
scoreboard players set #gdr driftmountains 312
scoreboard players set #gp driftmountains 72
scoreboard players set #gdp driftmountains 3
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.9424f,0.0668f,-0.3259f,0.0329f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.3312f,0.0673f,0.9406f,0.0319f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.7149f,0.0094f,0.0092f,0.6991f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0092f,0.6991f,0.7149f,0.0094f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3603f,0.8371f,0.2362f],left_rotation:[-0.1796f,0.0232f,-0.0932f,-0.9791f]}}
particle minecraft:cloud -99.15 70.24 -14.09 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -99.15 70.04 -14.09 -0.042 0.02 0.019 1 0 force
particle minecraft:cloud -98.45 70.24 -12.53 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -98248
scoreboard players set #gdx driftmountains 33
scoreboard players set #gy driftmountains 70000
scoreboard players set #gdy driftmountains -10
scoreboard players set #gz driftmountains -9066
scoreboard players set #gdz driftmountains -794
scoreboard players set #gr driftmountains -12821
scoreboard players set #gdr driftmountains 188
scoreboard players set #gp driftmountains 41
scoreboard players set #gdp driftmountains 8
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.7530f,0.2640f,-0.2727f,0.5375f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.3307f,0.5691f,0.7294f,-0.1863f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.7149f,0.0094f,0.0092f,0.6991f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0092f,0.6991f,0.7149f,0.0094f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3592f,0.8279f,0.0924f],left_rotation:[-0.1727f,-0.0597f,0.3513f,-0.9182f]}}
particle minecraft:cloud -99.75 70.32 -8.94 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -99.75 70.12 -8.94 -0.038 0.02 0.030 1 0 force
particle minecraft:cloud -98.72 70.32 -7.63 0.35 0.18 0.35 0.02 3 force
