scoreboard players set #gx driftmountains -47940
scoreboard players set #gdx driftmountains 564
scoreboard players set #gy driftmountains 67715
scoreboard players set #gdy driftmountains -13
scoreboard players set #gz driftmountains -86756
scoreboard players set #gdz driftmountains -528
scoreboard players set #gr driftmountains -10024
scoreboard players set #gdr driftmountains 181
scoreboard players set #gp driftmountains 81
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[0.0035f,0.0001f,-0.0206f,0.9998f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.7112f,0.2073f,-0.1451f,0.6559f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.2149f,0.6748f,0.6933f,-0.1337f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.1939f,0.0025f,0.0128f,0.9809f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0128f,0.9809f,0.1939f,0.0025f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3797f,0.8664f,0.1075f],left_rotation:[-0.1260f,0.1445f,-0.7484f,-0.6349f]}}
particle minecraft:cloud -49.33 68.03 -87.35 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -49.33 67.83 -87.35 -0.046 0.02 0.008 1 0 force
particle minecraft:cloud -49.03 68.03 -85.71 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -51322
scoreboard players set #gdx driftmountains 433
scoreboard players set #gy driftmountains 67800
scoreboard players set #gdy driftmountains -12
scoreboard players set #gz driftmountains -82788
scoreboard players set #gdz driftmountains -628
scoreboard players set #gr driftmountains -11212
scoreboard players set #gdr driftmountains 174
scoreboard players set #gp driftmountains 76
scoreboard players set #gdp driftmountains 2
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0001f,-0.0208f,0.9998f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.4678f,0.2398f,-0.0707f,0.8477f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.1602f,0.8598f,0.4451f,-0.1920f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.1939f,0.0025f,0.0128f,0.9809f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0128f,0.9809f,0.1939f,0.0025f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3669f,0.8704f,0.2492f],left_rotation:[-0.1162f,0.1525f,-0.7656f,-0.6141f]}}
particle minecraft:cloud -52.91 68.12 -83.07 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -52.91 67.92 -83.07 -0.042 0.02 0.017 1 0 force
particle minecraft:cloud -52.26 68.12 -81.48 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -53248
scoreboard players set #gdx driftmountains 287
scoreboard players set #gy driftmountains 67897
scoreboard players set #gdy driftmountains -14
scoreboard players set #gz driftmountains -77449
scoreboard players set #gdz driftmountains -646
scoreboard players set #gr driftmountains -12618
scoreboard players set #gdr driftmountains 53
scoreboard players set #gp driftmountains 98
scoreboard players set #gdp driftmountains -5
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0001f,-0.0185f,0.9998f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.4809f,-0.1798f,-0.1648f,-0.8421f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.0772f,-0.8295f,0.5025f,0.2314f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.1939f,0.0025f,0.0128f,0.9809f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0128f,0.9809f,0.1939f,0.0025f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3839f,0.8656f,0.1072f],left_rotation:[-0.1133f,0.1541f,-0.8016f,-0.5664f]}}
particle minecraft:cloud -54.76 68.22 -77.38 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -54.76 68.02 -77.38 -0.033 0.02 0.024 1 0 force
particle minecraft:cloud -53.77 68.22 -76.03 0.35 0.18 0.35 0.02 3 force
