scoreboard players set #gx driftmountains 24639
scoreboard players set #gdx driftmountains -462
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 46144
scoreboard players set #gdz driftmountains 955
scoreboard players set #gr driftmountains 7767
scoreboard players set #gdr driftmountains 168
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.1558f,-0.3942f,-0.1268f,-0.8968f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.0332f,-0.8884f,0.1981f,0.4128f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.6045f,0.0079f,0.0104f,0.7965f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0104f,0.7965f,0.6045f,0.0079f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3742f,0.8211f,0.0898f],left_rotation:[-0.1379f,-0.1152f,0.6413f,-0.7459f]}}
particle minecraft:cloud 26.05 71.32 46.69 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 26.05 71.12 46.69 0.062 0.02 -0.014 1 0 force
particle minecraft:cloud 25.69 71.32 45.06 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains 27955
scoreboard players set #gdx driftmountains -263
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 38610
scoreboard players set #gdz driftmountains 973
scoreboard players set #gr driftmountains 7753
scoreboard players set #gdr driftmountains 260
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.7336f,-0.2106f,-0.4242f,-0.4874f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.3753f,-0.4455f,0.7598f,0.2888f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.6045f,0.0079f,0.0104f,0.7965f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0104f,0.7965f,0.6045f,0.0079f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.4051f,0.8578f,0.2443f],left_rotation:[-0.0404f,-0.1842f,0.9505f,-0.2471f]}}
particle minecraft:cloud 29.47 71.32 39.15 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 29.47 71.12 39.15 0.059 0.02 -0.013 1 0 force
particle minecraft:cloud 29.10 71.32 37.48 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains 27109
scoreboard players set #gdx driftmountains 116
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 33914
scoreboard players set #gdz driftmountains 944
scoreboard players set #gr driftmountains 4960
scoreboard players set #gdr driftmountains 316
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.6671f,0.3303f,-0.2766f,0.6078f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.3420f,0.6402f,0.6360f,-0.2621f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.6045f,0.0079f,0.0104f,0.7965f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0104f,0.7965f,0.6045f,0.0079f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3824f,0.8216f,0.0899f],left_rotation:[-0.1146f,-0.1378f,0.7576f,-0.6276f]}}
particle minecraft:cloud 28.61 71.32 33.73 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 28.61 71.12 33.73 0.043 0.02 -0.037 1 0 force
particle minecraft:cloud 27.53 71.32 32.46 0.35 0.18 0.35 0.02 3 force
