scoreboard players set #gx driftmountains -67639
scoreboard players set #gdx driftmountains 686
scoreboard players set #gy driftmountains 69181
scoreboard players set #gdy driftmountains -11
scoreboard players set #gz driftmountains -31445
scoreboard players set #gdz driftmountains -234
scoreboard players set #gr driftmountains -11911
scoreboard players set #gdr driftmountains -224
scoreboard players set #gp driftmountains 81
scoreboard players set #gdp driftmountains 2
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[0.0061f,-0.0000f,0.0062f,1.0000f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.9468f,0.0228f,0.1005f,0.3048f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[-0.0690f,0.2959f,0.9496f,0.0766f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.9863f,0.0129f,-0.0022f,-0.1647f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0022f,-0.1647f,0.9863f,0.0129f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3771f,0.8666f,0.1076f],left_rotation:[0.1332f,-0.1382f,0.7133f,0.6740f]}}
particle minecraft:cloud -69.15 69.50 -31.56 0.35 0.18 0.35 0.02 2 force
particle minecraft:cloud -68.33 69.50 -30.10 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -68.33 69.30 -30.10 -0.038 0.02 0.021 1 0 force
scoreboard players set #gx driftmountains -74165
scoreboard players set #gdx driftmountains 674
scoreboard players set #gy driftmountains 69273
scoreboard players set #gdy driftmountains -9
scoreboard players set #gz driftmountains -30352
scoreboard players set #gdz driftmountains -314
scoreboard players set #gr driftmountains -12414
scoreboard players set #gdr driftmountains 258
scoreboard players set #gp driftmountains 72
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[-0.0039f,0.0000f,0.0055f,1.0000f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.6600f,0.0919f,0.0113f,-0.7455f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[-0.0897f,-0.7508f,0.6540f,-0.0231f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.9863f,0.0129f,-0.0022f,-0.1647f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0022f,-0.1647f,0.9863f,0.0129f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3599f,0.8639f,0.2467f],left_rotation:[0.1408f,-0.1270f,0.6314f,0.7520f]}}
scoreboard players set #gx driftmountains -79245
scoreboard players set #gdx driftmountains 702
scoreboard players set #gy driftmountains 69350
scoreboard players set #gdy driftmountains -12
scoreboard players set #gz driftmountains -27084
scoreboard players set #gdz driftmountains -213
scoreboard players set #gr driftmountains -11864
scoreboard players set #gdr driftmountains -775
scoreboard players set #gp driftmountains 91
scoreboard players set #gdp driftmountains -8
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,0.0000f,0.0080f,1.0000f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.2265f,-0.0354f,0.0621f,0.9714f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.0397f,0.9702f,0.2315f,0.0594f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.9863f,0.0129f,-0.0022f,-0.1647f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0022f,-0.1647f,0.9863f,0.0129f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3606f,0.8609f,0.1054f],left_rotation:[0.1716f,-0.0853f,0.4233f,0.8854f]}}
particle minecraft:cloud -80.75 69.67 -27.21 0.35 0.18 0.35 0.02 2 force
particle minecraft:cloud -79.95 69.67 -25.75 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -79.95 69.47 -25.75 -0.036 0.02 0.020 1 0 force
