scoreboard players set #gx driftmountains -46205
scoreboard players set #gdx driftmountains -1208
scoreboard players set #gy driftmountains 70470
scoreboard players set #gdy driftmountains -2
scoreboard players set #gz driftmountains 48557
scoreboard players set #gdz driftmountains -485
scoreboard players set #gr driftmountains 15612
scoreboard players set #gdr driftmountains 56
scoreboard players set #gp driftmountains 11
scoreboard players set #gdp driftmountains -9
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.1611f,-0.3550f,-0.1199f,-0.9130f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.0246f,-0.9055f,0.1993f,0.3739f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.4558f,0.0060f,0.0117f,0.8900f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0117f,0.8900f,0.4558f,0.0060f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3577f,0.8295f,0.0931f],left_rotation:[-0.1759f,-0.0513f,0.3069f,-0.9339f]}}
particle minecraft:cloud -46.46 70.79 50.05 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -46.46 70.59 50.05 0.032 0.02 0.071 1 0 force
particle minecraft:cloud -44.93 70.79 49.37 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -36109
scoreboard players set #gdx driftmountains -1200
scoreboard players set #gy driftmountains 70664
scoreboard players set #gdy driftmountains -40
scoreboard players set #gz driftmountains 52389
scoreboard players set #gdz driftmountains -428
scoreboard players set #gr driftmountains 15473
scoreboard players set #gdr driftmountains -7
scoreboard players set #gp driftmountains 130
scoreboard players set #gdp driftmountains -8
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.7734f,-0.1593f,-0.3464f,-0.5065f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.2951f,-0.4729f,0.7944f,0.2415f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.4558f,0.0060f,0.0117f,0.8900f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0117f,0.8900f,0.4558f,0.0060f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3810f,0.8272f,0.2323f],left_rotation:[-0.1652f,-0.0669f,0.3667f,-0.9131f]}}
particle minecraft:cloud -36.30 70.98 53.99 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -36.30 70.78 53.99 0.032 0.02 0.068 1 0 force
particle minecraft:cloud -34.75 70.98 53.26 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -31466
scoreboard players set #gdx driftmountains -1270
scoreboard players set #gy driftmountains 70830
scoreboard players set #gdy driftmountains -44
scoreboard players set #gz driftmountains 54280
scoreboard players set #gdz driftmountains -396
scoreboard players set #gr driftmountains 15374
scoreboard players set #gdr driftmountains 12
scoreboard players set #gp driftmountains 126
scoreboard players set #gdp driftmountains 5
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.6779f,0.3049f,-0.2487f,0.6209f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.3154f,0.6505f,0.6496f,-0.2353f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.4558f,0.0060f,0.0117f,0.8900f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0117f,0.8900f,0.4558f,0.0060f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3646f,0.8240f,0.0909f],left_rotation:[-0.1610f,-0.0833f,0.4749f,-0.8611f]}}
particle minecraft:cloud -31.66 71.15 55.78 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -31.66 70.95 55.78 0.033 0.02 0.067 1 0 force
particle minecraft:cloud -30.16 71.15 55.04 0.35 0.18 0.35 0.02 3 force
