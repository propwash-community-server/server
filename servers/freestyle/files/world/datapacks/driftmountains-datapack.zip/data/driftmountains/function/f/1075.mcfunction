scoreboard players set #gx driftmountains -27499
scoreboard players set #gdx driftmountains -1128
scoreboard players set #gy driftmountains 70944
scoreboard players set #gdy driftmountains -29
scoreboard players set #gz driftmountains 55142
scoreboard players set #gdz driftmountains -364
scoreboard players set #gr driftmountains 15487
scoreboard players set #gdr driftmountains 28
scoreboard players set #gp driftmountains 90
scoreboard players set #gdp driftmountains 12
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.7031f,0.2975f,-0.2668f,0.5882f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.3301f,0.6194f,0.6757f,-0.2252f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.9999f,0.0131f,0.0001f,0.0112f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0001f,0.0112f,0.9999f,0.0131f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3673f,0.8228f,0.0904f],left_rotation:[-0.1548f,-0.0931f,0.5265f,-0.8307f]}}
particle minecraft:cloud -27.72 71.26 56.64 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -27.72 71.06 56.64 0.030 0.02 0.064 1 0 force
particle minecraft:cloud -26.21 71.26 55.93 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -17991
scoreboard players set #gdx driftmountains -1147
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 58027
scoreboard players set #gdz driftmountains -320
scoreboard players set #gr driftmountains 15106
scoreboard players set #gdr driftmountains 18
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.0521f,0.3852f,0.0350f,0.9207f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.0616f,0.9221f,0.0119f,-0.3818f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.9999f,0.0131f,0.0001f,0.0112f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0001f,0.0112f,0.9999f,0.0131f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3838f,0.8273f,0.2323f],left_rotation:[-0.1610f,-0.0766f,0.4157f,-0.8919f]}}
particle minecraft:cloud -18.08 71.32 59.64 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -18.08 71.12 59.64 0.032 0.02 0.058 1 0 force
particle minecraft:cloud -16.58 71.32 58.81 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -13302
scoreboard players set #gdx driftmountains -1106
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 59469
scoreboard players set #gdz driftmountains -302
scoreboard players set #gr driftmountains 15125
scoreboard players set #gdr driftmountains -3
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.8772f,-0.0626f,-0.3873f,-0.2767f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.3603f,-0.2375f,0.8886f,0.1551f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.9999f,0.0131f,0.0001f,0.0112f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0001f,0.0112f,0.9999f,0.0131f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3641f,0.8243f,0.0910f],left_rotation:[-0.1621f,-0.0813f,0.4648f,-0.8666f]}}
particle minecraft:cloud -13.43 71.32 60.98 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -13.43 71.12 60.98 0.032 0.02 0.059 1 0 force
particle minecraft:cloud -11.96 71.32 60.17 0.35 0.18 0.35 0.02 3 force
