scoreboard players set #gx driftmountains 5411
scoreboard players set #gdx driftmountains 880
scoreboard players set #gy driftmountains 66800
scoreboard players set #gdy driftmountains -11
scoreboard players set #gz driftmountains -67765
scoreboard players set #gdz driftmountains 598
scoreboard players set #gr driftmountains -5239
scoreboard players set #gdr driftmountains -69
scoreboard players set #gp driftmountains 61
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0000f,-0.0021f,1.0000f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.9770f,0.0572f,-0.0178f,0.2045f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.0394f,0.2075f,0.9764f,0.0452f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.8612f,0.0113f,-0.0067f,-0.5081f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0067f,-0.5081f,0.8612f,0.0113f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3561f,0.8315f,0.0939f],left_rotation:[0.1792f,0.0416f,-0.2556f,0.9491f]}}
scoreboard players set #gx driftmountains -1566
scoreboard players set #gdx driftmountains 881
scoreboard players set #gy driftmountains 66888
scoreboard players set #gdy driftmountains -11
scoreboard players set #gz driftmountains -72258
scoreboard players set #gdz driftmountains 567
scoreboard players set #gr driftmountains -5113
scoreboard players set #gdr driftmountains -38
scoreboard players set #gp driftmountains 61
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0000f,-0.0038f,1.0000f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.6223f,0.0732f,0.0086f,0.7793f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.0733f,0.7827f,0.6181f,-0.0082f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.8612f,0.0113f,-0.0067f,-0.5081f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0067f,-0.5081f,0.8612f,0.0113f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3854f,0.8275f,0.2324f],left_rotation:[0.1583f,0.0824f,-0.4451f,0.8776f]}}
scoreboard players set #gx driftmountains -10002
scoreboard players set #gdx driftmountains 849
scoreboard players set #gy driftmountains 67001
scoreboard players set #gdy driftmountains -11
scoreboard players set #gz driftmountains -78059
scoreboard players set #gdz driftmountains 562
scoreboard players set #gr driftmountains -4074
scoreboard players set #gdr driftmountains -151
scoreboard players set #gp driftmountains 63
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0000f,-0.0096f,0.9999f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.9622f,0.0830f,-0.1199f,0.2299f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.1447f,0.2438f,0.9588f,0.0177f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.8612f,0.0113f,-0.0067f,-0.5081f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0067f,-0.5081f,0.8612f,0.0113f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3967f,0.8305f,0.0935f],left_rotation:[0.0549f,0.1722f,-0.9298f,0.3206f]}}
particle minecraft:cloud -10.19 67.32 -79.56 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -10.19 67.12 -79.56 -0.039 0.02 -0.045 1 0 force
particle minecraft:cloud -11.46 67.32 -78.47 0.35 0.18 0.35 0.02 2 force
