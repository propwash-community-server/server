scoreboard players set #gx driftmountains -74457
scoreboard players set #gdx driftmountains 647
scoreboard players set #gy driftmountains 69278
scoreboard players set #gdy driftmountains -9
scoreboard players set #gz driftmountains -28868
scoreboard players set #gdz driftmountains -265
scoreboard players set #gr driftmountains -12201
scoreboard players set #gdr driftmountains 230
scoreboard players set #gp driftmountains 74
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,0.0000f,0.0059f,1.0000f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.2798f,0.0893f,-0.0285f,-0.9555f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[-0.0717f,-0.9577f,0.2719f,-0.0604f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.9448f,0.0124f,0.0043f,0.3275f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0043f,0.3275f,0.9448f,0.0124f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3722f,0.8662f,0.1074f],left_rotation:[0.1458f,-0.1253f,0.6418f,0.7423f]}}
scoreboard players set #gx driftmountains -80659
scoreboard players set #gdx driftmountains 626
scoreboard players set #gy driftmountains 69372
scoreboard players set #gdy driftmountains -11
scoreboard players set #gz driftmountains -27841
scoreboard players set #gdz driftmountains -155
scoreboard players set #gr driftmountains -10752
scoreboard players set #gdr driftmountains -600
scoreboard players set #gp driftmountains 98
scoreboard players set #gdp driftmountains -4
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[-0.0039f,0.0000f,0.0027f,1.0000f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.9878f,0.0544f,-0.0102f,0.1456f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.0256f,0.1475f,0.9875f,0.0491f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.9448f,0.0124f,0.0043f,0.3275f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0043f,0.3275f,0.9448f,0.0124f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3702f,0.8294f,0.2332f],left_rotation:[0.1768f,0.0260f,-0.1586f,0.9711f]}}
scoreboard players set #gx driftmountains -85721
scoreboard players set #gdx driftmountains 555
scoreboard players set #gy driftmountains 69492
scoreboard players set #gdy driftmountains -17
scoreboard players set #gz driftmountains -25849
scoreboard players set #gdz driftmountains -185
scoreboard players set #gr driftmountains -6988
scoreboard players set #gdr driftmountains -167
scoreboard players set #gp driftmountains 124
scoreboard players set #gdp driftmountains 8
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[-0.0000f,-0.0000f,-0.0223f,0.9998f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.3236f,-0.2082f,-0.1310f,-0.9136f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.0357f,-0.9049f,0.3473f,0.2434f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.9448f,0.0124f,0.0043f,0.3275f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0043f,0.3275f,0.9448f,0.0124f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3830f,0.8658f,0.1073f],left_rotation:[-0.1163f,0.1520f,-0.7900f,-0.5824f]}}
particle minecraft:cloud -86.62 69.81 -27.07 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -86.62 69.61 -27.07 -0.037 0.02 -0.014 1 0 force
particle minecraft:cloud -87.19 69.81 -25.50 0.35 0.18 0.35 0.02 3 force
