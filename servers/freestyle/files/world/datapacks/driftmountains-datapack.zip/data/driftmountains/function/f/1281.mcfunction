scoreboard players set #gx driftmountains -56498
scoreboard players set #gdx driftmountains -52
scoreboard players set #gy driftmountains 68130
scoreboard players set #gdy driftmountains -13
scoreboard players set #gz driftmountains -68549
scoreboard players set #gdz driftmountains -652
scoreboard players set #gr driftmountains -15403
scoreboard players set #gdr driftmountains 263
scoreboard players set #gp driftmountains 96
scoreboard players set #gdp driftmountains 4
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[0.0061f,0.0001f,-0.0191f,0.9998f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.8021f,0.1752f,-0.1612f,0.5477f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.2196f,0.5677f,0.7881f,-0.0919f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.5078f,0.0066f,0.0113f,0.8614f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0113f,0.8614f,0.5078f,0.0066f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3865f,0.8647f,0.1069f],left_rotation:[-0.1048f,0.1595f,-0.8321f,-0.5207f]}}
particle minecraft:cloud -57.80 68.45 -67.78 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -57.80 68.25 -67.78 -0.017 0.02 0.036 1 0 force
particle minecraft:cloud -56.30 68.45 -67.05 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -55127
scoreboard players set #gdx driftmountains -112
scoreboard players set #gy driftmountains 68240
scoreboard players set #gdy driftmountains -13
scoreboard players set #gz driftmountains -62563
scoreboard players set #gdz driftmountains -786
scoreboard players set #gr driftmountains -17841
scoreboard players set #gdr driftmountains 494
scoreboard players set #gp driftmountains 92
scoreboard players set #gdp driftmountains -1
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0000f,-0.0060f,1.0000f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.1303f,0.0839f,0.0419f,0.9870f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.0616f,0.9881f,0.1222f,-0.0706f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.5078f,0.0066f,0.0113f,0.8614f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0113f,0.8614f,0.5078f,0.0066f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3963f,0.8320f,0.2342f],left_rotation:[0.1338f,0.1205f,-0.6373f,0.7493f]}}
scoreboard players set #gx driftmountains -54058
scoreboard players set #gdx driftmountains -73
scoreboard players set #gy driftmountains 68350
scoreboard players set #gdy driftmountains -12
scoreboard players set #gz driftmountains -56393
scoreboard players set #gdz driftmountains -633
scoreboard players set #gr driftmountains 15178
scoreboard players set #gdr driftmountains 199
scoreboard players set #gp driftmountains 103
scoreboard players set #gdp driftmountains -2
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,0.0001f,0.0134f,0.9999f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.9835f,0.0594f,0.1670f,-0.0369f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[-0.1718f,-0.0546f,0.9826f,0.0436f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.5078f,0.0066f,0.0113f,0.8614f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0113f,0.8614f,0.5078f,0.0066f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.4012f,0.8455f,0.0993f],left_rotation:[0.0096f,-0.1843f,0.9826f,0.0158f]}}
particle minecraft:cloud -54.20 68.67 -54.89 0.35 0.18 0.35 0.02 2 force
particle minecraft:cloud -52.73 68.67 -55.68 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -52.73 68.47 -55.68 0.018 0.02 0.034 1 0 force
