scoreboard players set #gx driftmountains -24100
scoreboard players set #gdx driftmountains 691
scoreboard players set #gy driftmountains 67203
scoreboard players set #gdy driftmountains -11
scoreboard players set #gz driftmountains -86667
scoreboard players set #gdz driftmountains 379
scoreboard players set #gr driftmountains -3288
scoreboard players set #gdr driftmountains 41
scoreboard players set #gp driftmountains 68
scoreboard players set #gdp driftmountains -1
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.4893f,-0.1743f,-0.1640f,-0.8386f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.0768f,-0.8260f,0.5104f,0.2267f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.4089f,0.0054f,-0.0119f,-0.9125f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0119f,-0.9125f,0.4089f,0.0054f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3860f,0.8649f,0.1069f],left_rotation:[-0.1066f,0.1584f,-0.8259f,-0.5303f]}}
particle minecraft:cloud -24.08 67.52 -88.18 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -24.08 67.32 -88.18 -0.026 0.02 -0.040 1 0 force
particle minecraft:cloud -25.49 67.52 -87.27 0.35 0.18 0.35 0.02 2 force
scoreboard players set #gx driftmountains -30275
scoreboard players set #gdx driftmountains 648
scoreboard players set #gy driftmountains 67302
scoreboard players set #gdy driftmountains -11
scoreboard players set #gz driftmountains -89577
scoreboard players set #gdz driftmountains 309
scoreboard players set #gr driftmountains -3462
scoreboard players set #gdr driftmountains 50
scoreboard players set #gp driftmountains 77
scoreboard players set #gdp driftmountains -1
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0001f,-0.0185f,0.9998f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.1148f,-0.2290f,-0.0815f,-0.9632f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[-0.0192f,-0.9599f,0.1395f,0.2423f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.4089f,0.0054f,-0.0119f,-0.9125f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0119f,-0.9125f,0.4089f,0.0054f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3699f,0.8719f,0.2498f],left_rotation:[-0.1068f,0.1599f,-0.8049f,-0.5614f]}}
particle minecraft:cloud -30.35 67.62 -91.19 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -30.35 67.42 -91.19 -0.024 0.02 -0.035 1 0 force
particle minecraft:cloud -31.75 67.62 -90.21 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -36366
scoreboard players set #gdx driftmountains 515
scoreboard players set #gy driftmountains 67421
scoreboard players set #gdy driftmountains -10
scoreboard players set #gz driftmountains -92206
scoreboard players set #gdz driftmountains 115
scoreboard players set #gr driftmountains -4403
scoreboard players set #gdr driftmountains 183
scoreboard players set #gp driftmountains 98
scoreboard players set #gdp driftmountains -8
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0001f,-0.0211f,0.9998f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.6361f,0.1908f,-0.0931f,0.7418f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.1716f,0.7557f,0.6196f,-0.1250f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.4089f,0.0054f,-0.0119f,-0.9125f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0119f,-0.9125f,0.4089f,0.0054f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3960f,0.8579f,0.1042f],left_rotation:[-0.0636f,0.1773f,-0.9349f,-0.3006f]}}
particle minecraft:cloud -36.64 67.74 -93.69 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -36.64 67.54 -93.69 -0.024 0.02 -0.025 1 0 force
particle minecraft:cloud -37.84 67.74 -92.53 0.35 0.18 0.35 0.02 3 force
