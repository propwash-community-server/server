scoreboard players set #gx driftmountains -97870
scoreboard players set #gdx driftmountains -120
scoreboard players set #gy driftmountains 70030
scoreboard players set #gdy driftmountains -4
scoreboard players set #gz driftmountains -4974
scoreboard players set #gdz driftmountains -894
scoreboard players set #gr driftmountains -13886
scoreboard players set #gdr driftmountains 157
scoreboard players set #gp driftmountains 13
scoreboard players set #gdp driftmountains 5
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.5948f,-0.2508f,-0.2841f,-0.7090f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.2111f,-0.6831f,0.6244f,0.3147f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.2004f,0.0026f,-0.0128f,-0.9796f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0128f,-0.9796f,0.2004f,0.0026f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3590f,0.8281f,0.0925f],left_rotation:[-0.1731f,-0.0586f,0.3455f,-0.9204f]}}
particle minecraft:cloud -99.33 70.35 -4.57 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -99.33 70.15 -4.57 -0.036 0.02 0.041 1 0 force
particle minecraft:cloud -98.07 70.35 -3.48 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -95433
scoreboard players set #gdx driftmountains -441
scoreboard players set #gy driftmountains 70019
scoreboard players set #gdy driftmountains 4
scoreboard players set #gz driftmountains 2906
scoreboard players set #gdz driftmountains -851
scoreboard players set #gr driftmountains -15929
scoreboard players set #gdr driftmountains 300
scoreboard players set #gp driftmountains -16
scoreboard players set #gdp driftmountains 2
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.9289f,0.0361f,-0.3650f,-0.0514f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.3616f,-0.0133f,0.9302f,0.0614f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.2004f,0.0026f,-0.0128f,-0.9796f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0128f,-0.9796f,0.2004f,0.0026f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3738f,0.8281f,0.2327f],left_rotation:[-0.1737f,-0.0405f,0.2323f,-0.9562f]}}
particle minecraft:cloud -96.72 70.34 3.88 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -96.72 70.14 3.88 -0.020 0.02 0.054 1 0 force
particle minecraft:cloud -95.12 70.34 4.48 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -92235
scoreboard players set #gdx driftmountains -607
scoreboard players set #gy driftmountains 69995
scoreboard players set #gdy driftmountains 4
scoreboard players set #gz driftmountains 7406
scoreboard players set #gdz driftmountains -729
scoreboard players set #gr driftmountains -17563
scoreboard players set #gdr driftmountains 300
scoreboard players set #gp driftmountains -16
scoreboard players set #gdp driftmountains -1
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.2786f,0.3594f,-0.0538f,0.8890f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.1475f,0.8996f,0.2423f,-0.3321f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.2004f,0.0026f,-0.0128f,-0.9796f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0128f,-0.9796f,0.2004f,0.0026f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3548f,0.8338f,0.0947f],left_rotation:[-0.1820f,-0.0312f,0.2006f,-0.9621f]}}
particle minecraft:cloud -93.16 70.32 8.60 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -93.16 70.12 8.60 -0.004 0.02 0.059 1 0 force
particle minecraft:cloud -91.50 70.32 8.73 0.35 0.18 0.35 0.02 3 force
