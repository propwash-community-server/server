scoreboard players set #gx driftmountains -54043
scoreboard players set #gdx driftmountains -113
scoreboard players set #gy driftmountains 68397
scoreboard players set #gdy driftmountains -16
scoreboard players set #gz driftmountains -54074
scoreboard players set #gdz driftmountains -696
scoreboard players set #gr driftmountains 14093
scoreboard players set #gdr driftmountains 129
scoreboard players set #gp driftmountains 117
scoreboard players set #gdp driftmountains -5
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,0.0001f,0.0186f,0.9998f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.7845f,-0.0778f,0.1941f,0.5838f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[-0.1338f,0.5666f,0.7970f,0.1607f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.4490f,0.0059f,-0.0117f,-0.8935f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0117f,-0.8935f,0.4490f,0.0059f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3979f,0.8321f,0.0941f],left_rotation:[-0.0473f,-0.1748f,0.9423f,-0.2814f]}}
particle minecraft:cloud -53.90 68.72 -52.57 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud -52.60 68.72 -53.62 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -52.60 68.52 -53.62 0.027 0.02 0.033 1 0 force
scoreboard players set #gx driftmountains -54567
scoreboard players set #gdx driftmountains 55
scoreboard players set #gy driftmountains 68553
scoreboard players set #gdy driftmountains -8
scoreboard players set #gz driftmountains -49362
scoreboard players set #gdz driftmountains -259
scoreboard players set #gr driftmountains 15747
scoreboard players set #gdr driftmountains -3
scoreboard players set #gp driftmountains 136
scoreboard players set #gdp driftmountains 1
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[0.0045f,-0.0001f,0.0211f,0.9998f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.7336f,0.2308f,0.1920f,-0.6097f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[-0.2571f,-0.6333f,0.7133f,-0.1550f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.4490f,0.0059f,-0.0117f,-0.8935f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0117f,-0.8935f,0.4490f,0.0059f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3822f,0.8272f,0.2323f],left_rotation:[-0.1634f,-0.0712f,0.3884f,-0.9041f]}}
particle minecraft:cloud -54.83 68.87 -47.77 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud -53.25 68.87 -48.43 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -53.25 68.67 -48.43 0.014 0.02 0.035 1 0 force
scoreboard players set #gx driftmountains -55912
scoreboard players set #gdx driftmountains 217
scoreboard players set #gy driftmountains 68732
scoreboard players set #gdy driftmountains -21
scoreboard players set #gz driftmountains -43426
scoreboard players set #gdz driftmountains -671
scoreboard players set #gr driftmountains 16674
scoreboard players set #gdr driftmountains -161
scoreboard players set #gp driftmountains 144
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,0.0001f,0.0197f,0.9998f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.6488f,-0.1280f,0.1862f,0.7267f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[-0.1109f,0.7111f,0.6658f,0.1969f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.4490f,0.0059f,-0.0117f,-0.8935f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0117f,-0.8935f,0.4490f,0.0059f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3928f,0.8265f,0.0919f],left_rotation:[-0.0759f,-0.1630f,0.8850f,-0.4294f]}}
particle minecraft:cloud -56.44 69.05 -42.01 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud -54.81 69.05 -42.39 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -54.81 68.85 -42.39 0.010 0.02 0.041 1 0 force
