scoreboard players set #gx driftmountains 13547
scoreboard players set #gdx driftmountains 938
scoreboard players set #gy driftmountains 66696
scoreboard players set #gdy driftmountains -12
scoreboard players set #gz driftmountains -62237
scoreboard players set #gdz driftmountains 629
scoreboard players set #gr driftmountains -5818
scoreboard players set #gdr driftmountains -46
scoreboard players set #gp driftmountains 61
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,0.0000f,0.0013f,1.0000f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.5445f,0.0171f,0.0513f,0.8370f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.0364f,0.8362f,0.5457f,0.0400f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.9625f,0.0126f,0.0035f,0.2709f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0035f,0.2709f,0.9625f,0.0126f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3529f,0.8486f,0.1005f],left_rotation:[0.1865f,-0.0298f,0.1242f,0.9741f]}}
scoreboard players set #gx driftmountains 6546
scoreboard players set #gdx driftmountains 918
scoreboard players set #gy driftmountains 66785
scoreboard players set #gdy driftmountains -12
scoreboard players set #gz driftmountains -66970
scoreboard players set #gdz driftmountains 608
scoreboard players set #gr driftmountains -5418
scoreboard players set #gdr driftmountains -65
scoreboard players set #gp driftmountains 61
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0000f,-0.0014f,1.0000f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.1129f,-0.0125f,-0.0541f,-0.9921f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[-0.0499f,-0.9918f,0.1148f,0.0244f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.9625f,0.0126f,0.0035f,0.2709f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0035f,0.2709f,0.9625f,0.0126f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3704f,0.8293f,0.2331f],left_rotation:[0.1767f,0.0268f,-0.1626f,0.9704f]}}
scoreboard players set #gx driftmountains -2275
scoreboard players set #gdx driftmountains 857
scoreboard players set #gy driftmountains 66899
scoreboard players set #gdy driftmountains -11
scoreboard players set #gz driftmountains -72931
scoreboard players set #gdz driftmountains 568
scoreboard players set #gr driftmountains -4967
scoreboard players set #gdr driftmountains -49
scoreboard players set #gp driftmountains 62
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0000f,-0.0041f,1.0000f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.5183f,0.0778f,0.0140f,0.8515f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.0754f,0.8548f,0.5130f,-0.0237f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.9625f,0.0126f,0.0035f,0.2709f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0035f,0.2709f,0.9625f,0.0126f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3660f,0.8233f,0.0906f],left_rotation:[0.1577f,0.0886f,-0.5027f,0.8453f]}}
