scoreboard players set #gx driftmountains -73810
scoreboard players set #gdx driftmountains 655
scoreboard players set #gy driftmountains 69268
scoreboard players set #gdy driftmountains -9
scoreboard players set #gz driftmountains -29133
scoreboard players set #gdz driftmountains -265
scoreboard players set #gr driftmountains -11971
scoreboard players set #gdr driftmountains 212
scoreboard players set #gp driftmountains 74
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,0.0000f,0.0046f,1.0000f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.6952f,-0.0091f,0.0820f,0.7140f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[-0.0074f,0.7094f,0.7000f,0.0822f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.5629f,0.0074f,-0.0108f,-0.8264f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0108f,-0.8264f,0.5629f,0.0074f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3663f,0.8644f,0.1067f],left_rotation:[0.1596f,-0.1071f,0.5419f,0.8181f]}}
scoreboard players set #gx driftmountains -80033
scoreboard players set #gdx driftmountains 577
scoreboard players set #gy driftmountains 69361
scoreboard players set #gdy driftmountains -10
scoreboard players set #gz driftmountains -27996
scoreboard players set #gdz driftmountains -164
scoreboard players set #gr driftmountains -11352
scoreboard players set #gdr driftmountains -610
scoreboard players set #gp driftmountains 93
scoreboard players set #gdp driftmountains -5
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[-0.0039f,0.0000f,0.0053f,1.0000f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.6770f,0.0436f,-0.0310f,-0.7340f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[-0.0460f,-0.7348f,0.6761f,0.0273f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.5629f,0.0074f,-0.0108f,-0.8264f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0108f,-0.8264f,0.5629f,0.0074f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3601f,0.8374f,0.2363f],left_rotation:[0.1795f,-0.0246f,0.1007f,0.9783f]}}
scoreboard players set #gx driftmountains -85166
scoreboard players set #gdx driftmountains 704
scoreboard players set #gy driftmountains 69475
scoreboard players set #gdy driftmountains -20
scoreboard players set #gz driftmountains -26034
scoreboard players set #gdz driftmountains -185
scoreboard players set #gr driftmountains -7155
scoreboard players set #gdr driftmountains -182
scoreboard players set #gp driftmountains 132
scoreboard players set #gdp driftmountains -4
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0001f,-0.0215f,0.9998f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.5859f,0.1907f,-0.0759f,0.7840f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.1587f,0.7963f,0.5691f,-0.1302f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.5629f,0.0074f,-0.0108f,-0.8264f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0108f,-0.8264f,0.5629f,0.0074f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3979f,0.8553f,0.1032f],left_rotation:[-0.0515f,0.1803f,-0.9532f,-0.2368f]}}
particle minecraft:cloud -86.10 69.80 -27.22 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -86.10 69.60 -27.22 -0.037 0.02 -0.012 1 0 force
particle minecraft:cloud -86.63 69.80 -25.64 0.35 0.18 0.35 0.02 3 force
