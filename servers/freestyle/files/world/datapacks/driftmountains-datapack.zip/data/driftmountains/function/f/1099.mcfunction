scoreboard players set #gx driftmountains -55863
scoreboard players set #gdx driftmountains -1189
scoreboard players set #gy driftmountains 70502
scoreboard players set #gdy driftmountains 6
scoreboard players set #gz driftmountains 44169
scoreboard players set #gdz driftmountains -659
scoreboard players set #gr driftmountains 16671
scoreboard players set #gdr driftmountains 202
scoreboard players set #gp driftmountains -18
scoreboard players set #gdp driftmountains 3
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.7052f,0.2929f,-0.2613f,0.5905f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.3248f,0.6212f,0.6783f,-0.2204f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.9975f,0.0131f,0.0009f,0.0698f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0009f,0.0698f,0.9975f,0.0131f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3642f,0.8242f,0.0910f],left_rotation:[-0.1619f,-0.0816f,0.4662f,-0.8659f]}}
particle minecraft:cloud -56.39 70.82 45.59 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -56.39 70.62 45.59 0.019 0.02 0.079 1 0 force
particle minecraft:cloud -54.76 70.82 45.20 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -45728
scoreboard players set #gdx driftmountains -1292
scoreboard players set #gy driftmountains 70472
scoreboard players set #gdy driftmountains -3
scoreboard players set #gz driftmountains 48634
scoreboard players set #gdz driftmountains -555
scoreboard players set #gr driftmountains 15617
scoreboard players set #gdr driftmountains 56
scoreboard players set #gp driftmountains 16
scoreboard players set #gdp driftmountains -11
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.0512f,0.3616f,0.0363f,0.9302f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.0613f,0.9315f,0.0135f,-0.3582f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.9975f,0.0131f,0.0009f,0.0698f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0009f,0.0698f,0.9975f,0.0131f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3722f,0.8286f,0.2328f],left_rotation:[-0.1752f,-0.0344f,0.2011f,-0.9632f]}}
particle minecraft:cloud -45.96 70.79 50.23 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -45.96 70.59 50.23 0.032 0.02 0.073 1 0 force
particle minecraft:cloud -44.39 70.79 49.54 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -41130
scoreboard players set #gdx driftmountains -1245
scoreboard players set #gy driftmountains 70526
scoreboard players set #gdy driftmountains -22
scoreboard players set #gz driftmountains 51028
scoreboard players set #gdz driftmountains -478
scoreboard players set #gr driftmountains 15447
scoreboard players set #gdr driftmountains 49
scoreboard players set #gp driftmountains 78
scoreboard players set #gdp driftmountains -19
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.8880f,-0.0546f,-0.3618f,-0.2784f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.3346f,-0.2419f,0.8987f,0.1482f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.9975f,0.0131f,0.0009f,0.0698f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0009f,0.0698f,0.9975f,0.0131f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3553f,0.8328f,0.0944f],left_rotation:[-0.1809f,-0.0357f,0.2247f,-0.9568f]}}
particle minecraft:cloud -41.34 70.85 52.52 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -41.34 70.65 52.52 0.034 0.02 0.071 1 0 force
particle minecraft:cloud -39.83 70.85 51.80 0.35 0.18 0.35 0.02 3 force
