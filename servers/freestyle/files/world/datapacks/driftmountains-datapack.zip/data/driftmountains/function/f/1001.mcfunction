scoreboard players set #gx driftmountains 26586
scoreboard players set #gdx driftmountains 245
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 28290
scoreboard players set #gdz driftmountains 1006
scoreboard players set #gr driftmountains 3359
scoreboard players set #gdr driftmountains 357
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.9078f,0.1222f,-0.3682f,0.1594f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.3870f,0.1989f,0.8999f,-0.0275f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.7691f,0.0101f,-0.0084f,-0.6390f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0084f,-0.6390f,0.7691f,0.0101f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3623f,0.8254f,0.0914f],left_rotation:[-0.1660f,-0.0741f,0.4267f,-0.8859f]}}
particle minecraft:cloud 27.98 71.32 27.70 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 27.98 71.12 27.70 0.034 0.02 -0.052 1 0 force
particle minecraft:cloud 26.59 71.32 26.78 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains 24531
scoreboard players set #gdx driftmountains 563
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 21823
scoreboard players set #gdz driftmountains 885
scoreboard players set #gr driftmountains 544
scoreboard players set #gdr driftmountains 82
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[0.0061f,0.0001f,-0.0223f,0.9997f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.5132f,0.3106f,-0.1359f,0.7884f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.2195f,0.8071f,0.4834f,-0.2584f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.7691f,0.0101f,-0.0084f,-0.6390f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0084f,-0.6390f,0.7691f,0.0101f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3623f,0.8349f,0.2353f],left_rotation:[-0.1800f,0.0114f,-0.0331f,-0.9831f]}}
particle minecraft:cloud 25.51 71.32 20.55 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 25.51 71.12 20.55 0.005 0.02 -0.056 1 0 force
particle minecraft:cloud 23.81 71.32 20.38 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains 21620
scoreboard players set #gdx driftmountains 400
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 16719
scoreboard players set #gdz driftmountains 975
scoreboard players set #gr driftmountains 789
scoreboard players set #gdr driftmountains 100
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0001f,-0.0185f,0.9998f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.6572f,-0.1523f,-0.2159f,-0.7059f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.1429f,-0.6871f,0.6769f,0.2222f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.7691f,0.0101f,-0.0084f,-0.6390f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0084f,-0.6390f,0.7691f,0.0101f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3745f,0.8665f,0.1075f],left_rotation:[-0.1400f,0.1315f,-0.6763f,-0.7110f]}}
particle minecraft:cloud 22.62 71.32 15.59 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 22.62 71.12 15.59 0.009 0.02 -0.063 1 0 force
particle minecraft:cloud 20.97 71.32 15.36 0.35 0.18 0.35 0.02 3 force
