scoreboard players set #gx driftmountains -60543
scoreboard players set #gdx driftmountains -1125
scoreboard players set #gy driftmountains 70516
scoreboard players set #gdy driftmountains -3
scoreboard players set #gz driftmountains 41323
scoreboard players set #gdz driftmountains -803
scoreboard players set #gr driftmountains 17425
scoreboard players set #gdr driftmountains 153
scoreboard players set #gp driftmountains 3
scoreboard players set #gdp driftmountains 9
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[0.0053f,0.0001f,-0.0223f,0.9997f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.1584f,-0.3756f,-0.1235f,-0.9048f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.0291f,-0.8968f,0.1987f,0.3943f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.4295f,0.0056f,0.0118f,0.9030f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0118f,0.9030f,0.4295f,0.0056f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3654f,0.8236f,0.0907f],left_rotation:[-0.1591f,-0.0863f,0.4910f,-0.8521f]}}
particle minecraft:cloud -61.25 70.84 42.66 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -61.25 70.64 42.66 0.008 0.02 0.083 1 0 force
particle minecraft:cloud -59.59 70.84 42.49 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -50754
scoreboard players set #gdx driftmountains -1254
scoreboard players set #gy driftmountains 70475
scoreboard players set #gdy driftmountains 6
scoreboard players set #gz driftmountains 46384
scoreboard players set #gdz driftmountains -612
scoreboard players set #gr driftmountains 15982
scoreboard players set #gdr driftmountains 151
scoreboard players set #gp driftmountains -16
scoreboard players set #gdp driftmountains -4
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.7789f,-0.1510f,-0.3337f,-0.5090f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.2821f,-0.4767f,0.7991f,0.2337f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.4295f,0.0056f,0.0118f,0.9030f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0118f,0.9030f,0.4295f,0.0056f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3736f,0.8282f,0.2327f],left_rotation:[-0.1739f,-0.0397f,0.2282f,-0.9572f]}}
particle minecraft:cloud -51.09 70.79 47.96 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -51.09 70.59 47.96 0.029 0.02 0.078 1 0 force
particle minecraft:cloud -49.48 70.79 47.37 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -46082
scoreboard players set #gdx driftmountains -1263
scoreboard players set #gy driftmountains 70471
scoreboard players set #gdy driftmountains -3
scoreboard players set #gz driftmountains 49050
scoreboard players set #gdz driftmountains -537
scoreboard players set #gr driftmountains 15634
scoreboard players set #gdr driftmountains 72
scoreboard players set #gp driftmountains 15
scoreboard players set #gdp driftmountains -11
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.6853f,0.2855f,-0.2275f,0.6301f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.2950f,0.6575f,0.6591f,-0.2150f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.4295f,0.0056f,0.0118f,0.9030f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0118f,0.9030f,0.4295f,0.0056f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3551f,0.8332f,0.0945f],left_rotation:[-0.1813f,-0.0341f,0.2163f,-0.9587f]}}
particle minecraft:cloud -46.34 70.79 50.54 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -46.34 70.59 50.54 0.033 0.02 0.075 1 0 force
particle minecraft:cloud -44.81 70.79 49.87 0.35 0.18 0.35 0.02 3 force
