scoreboard players set #gx driftmountains -63810
scoreboard players set #gdx driftmountains -1033
scoreboard players set #gy driftmountains 70496
scoreboard players set #gdy driftmountains -14
scoreboard players set #gz driftmountains 38815
scoreboard players set #gdz driftmountains -910
scoreboard players set #gr driftmountains 17881
scoreboard players set #gdr driftmountains 83
scoreboard players set #gp driftmountains 35
scoreboard players set #gdp driftmountains 9
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.5296f,0.3452f,-0.1728f,0.7553f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.2531f,0.7777f,0.4962f,-0.2914f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.9397f,0.0123f,0.0045f,0.3417f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0045f,0.3417f,0.9397f,0.0123f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3616f,0.8259f,0.0917f],left_rotation:[-0.1677f,-0.0707f,0.4093f,-0.8940f]}}
particle minecraft:cloud -64.62 70.82 40.09 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -64.62 70.62 40.09 0.002 0.02 0.082 1 0 force
particle minecraft:cloud -62.95 70.82 40.06 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -54445
scoreboard players set #gdx driftmountains -1286
scoreboard players set #gy driftmountains 70495
scoreboard players set #gdy driftmountains 7
scoreboard players set #gz driftmountains 44508
scoreboard players set #gdz driftmountains -714
scoreboard players set #gr driftmountains 16470
scoreboard players set #gdr driftmountains 188
scoreboard players set #gp driftmountains -21
scoreboard players set #gdp driftmountains 2
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.1893f,-0.3539f,-0.1316f,-0.9064f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.0370f,-0.8976f,0.2275f,0.3758f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.9397f,0.0123f,0.0045f,0.3417f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0045f,0.3417f,0.9397f,0.0123f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3791f,0.8272f,0.2323f],left_rotation:[-0.1677f,-0.0603f,0.3331f,-0.9259f]}}
particle minecraft:cloud -54.91 70.82 46.05 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -54.91 70.62 46.05 0.022 0.02 0.082 1 0 force
particle minecraft:cloud -53.26 70.82 45.60 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains -49905
scoreboard players set #gdx driftmountains -1265
scoreboard players set #gy driftmountains 70471
scoreboard players set #gdy driftmountains 5
scoreboard players set #gz driftmountains 47363
scoreboard players set #gdz driftmountains -604
scoreboard players set #gr driftmountains 15929
scoreboard players set #gdr driftmountains 157
scoreboard players set #gp driftmountains -12
scoreboard players set #gdp driftmountains -5
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.9298f,0.0409f,-0.3636f,-0.0391f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.3615f,-0.0011f,0.9307f,0.0566f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.9397f,0.0123f,0.0045f,0.3417f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0045f,0.3417f,0.9397f,0.0123f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3553f,0.8328f,0.0944f],left_rotation:[-0.1809f,-0.0357f,0.2244f,-0.9568f]}}
particle minecraft:cloud -50.24 70.79 48.84 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -50.24 70.59 48.84 0.030 0.02 0.080 1 0 force
particle minecraft:cloud -48.68 70.79 48.25 0.35 0.18 0.35 0.02 3 force
