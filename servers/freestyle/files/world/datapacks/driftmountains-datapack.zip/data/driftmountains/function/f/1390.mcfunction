scoreboard players set #gx driftmountains 7176
scoreboard players set #gdx driftmountains 891
scoreboard players set #gy driftmountains 66777
scoreboard players set #gdy driftmountains -11
scoreboard players set #gz driftmountains -66564
scoreboard players set #gdz driftmountains 607
scoreboard players set #gr driftmountains -5387
scoreboard players set #gdr driftmountains -81
scoreboard players set #gp driftmountains 61
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0000f,-0.0012f,1.0000f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.7436f,0.0499f,0.0227f,0.6663f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.0472f,0.6676f,0.7425f,0.0280f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.9999f,0.0131f,-0.0001f,-0.0045f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0001f,-0.0045f,0.9999f,0.0131f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3537f,0.8363f,0.0957f],left_rotation:[0.1843f,0.0204f,-0.1438f,0.9720f]}}
scoreboard players set #gx driftmountains 195
scoreboard players set #gdx driftmountains 891
scoreboard players set #gy driftmountains 66866
scoreboard players set #gdy driftmountains -11
scoreboard players set #gz driftmountains -71122
scoreboard players set #gdz driftmountains 576
scoreboard players set #gr driftmountains -5181
scoreboard players set #gdr driftmountains -21
scoreboard players set #gp driftmountains 61
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0000f,-0.0033f,1.0000f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.1490f,0.0517f,0.0452f,0.9865f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.0583f,0.9871f,0.1444f,-0.0363f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.9999f,0.0131f,-0.0001f,-0.0045f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0001f,-0.0045f,0.9999f,0.0131f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3820f,0.8272f,0.2323f],left_rotation:[0.1638f,0.0704f,-0.3841f,0.9059f]}}
scoreboard players set #gx driftmountains -8347
scoreboard players set #gdx driftmountains 846
scoreboard players set #gy driftmountains 66979
scoreboard players set #gdy driftmountains -11
scoreboard players set #gz driftmountains -76962
scoreboard players set #gdz driftmountains 562
scoreboard players set #gr driftmountains -4349
scoreboard players set #gdr driftmountains -127
scoreboard players set #gp driftmountains 62
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0000f,-0.0079f,1.0000f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.7197f,0.1150f,-0.0447f,0.6832f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.1167f,0.6917f,0.7116f,-0.0400f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.9999f,0.0131f,-0.0001f,-0.0045f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0001f,-0.0045f,0.9999f,0.0131f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3886f,0.8238f,0.0908f],left_rotation:[0.0932f,0.1533f,-0.8362f,0.5182f]}}
particle minecraft:cloud -8.61 67.30 -78.45 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -8.61 67.10 -78.45 -0.041 0.02 -0.044 1 0 force
particle minecraft:cloud -9.82 67.30 -77.30 0.35 0.18 0.35 0.02 2 force
