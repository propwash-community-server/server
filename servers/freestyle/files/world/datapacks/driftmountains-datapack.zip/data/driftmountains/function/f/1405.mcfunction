scoreboard players set #gx driftmountains 21314
scoreboard players set #gdx driftmountains 1005
scoreboard players set #gy driftmountains 66597
scoreboard players set #gdy driftmountains -13
scoreboard players set #gz driftmountains -57241
scoreboard players set #gdz driftmountains 632
scoreboard players set #gr driftmountains -5895
scoreboard players set #gdr driftmountains 25
scoreboard players set #gp driftmountains 62
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,0.0000f,0.0007f,1.0000f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.9972f,0.0524f,0.0004f,-0.0536f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[-0.0061f,-0.0540f,0.9972f,0.0521f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.7294f,0.0095f,-0.0090f,-0.6840f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0090f,-0.6840f,0.7294f,0.0095f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3523f,0.8443f,0.0989f],left_rotation:[0.1873f,-0.0125f,0.0315f,0.9817f]}}
scoreboard players set #gx driftmountains 14108
scoreboard players set #gdx driftmountains 974
scoreboard players set #gy driftmountains 66689
scoreboard players set #gdy driftmountains -12
scoreboard players set #gz driftmountains -61906
scoreboard players set #gdz driftmountains 651
scoreboard players set #gr driftmountains -5828
scoreboard players set #gdr driftmountains -40
scoreboard players set #gp driftmountains 61
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[-0.0039f,0.0000f,0.0013f,1.0000f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.8017f,0.0331f,0.0432f,0.5952f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.0191f,0.5940f,0.8027f,0.0510f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.7294f,0.0095f,-0.0090f,-0.6840f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0090f,-0.6840f,0.7294f,0.0095f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3591f,0.8388f,0.2369f],left_rotation:[0.1789f,-0.0314f,0.1356f,0.9740f]}}
scoreboard players set #gx driftmountains 5031
scoreboard players set #gdx driftmountains 951
scoreboard players set #gy driftmountains 66805
scoreboard players set #gdy driftmountains -12
scoreboard players set #gz driftmountains -68093
scoreboard players set #gdz driftmountains 628
scoreboard players set #gr driftmountains -5274
scoreboard players set #gdr driftmountains -80
scoreboard players set #gp driftmountains 61
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0000f,-0.0023f,1.0000f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.9978f,0.0516f,-0.0343f,-0.0218f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.0322f,-0.0183f,0.9979f,0.0530f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.7294f,0.0095f,-0.0090f,-0.6840f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0090f,-0.6840f,0.7294f,0.0095f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3572f,0.8301f,0.0933f],left_rotation:[0.1771f,0.0481f,-0.2903f,0.9391f]}}
