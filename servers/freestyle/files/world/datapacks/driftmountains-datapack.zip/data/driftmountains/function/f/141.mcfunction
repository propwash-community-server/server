scoreboard players set #gx driftmountains 14802
scoreboard players set #gdx driftmountains 441
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 308
scoreboard players set #gdz driftmountains 943
scoreboard players set #gr driftmountains 1214
scoreboard players set #gdr driftmountains 7
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.6971f,0.2524f,-0.1924f,0.6429f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.2610f,0.6667f,0.6745f,-0.1805f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.1757f,0.0023f,0.0129f,0.9844f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0129f,0.9844f,0.1757f,0.0023f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3548f,0.8537f,0.1025f],left_rotation:[-0.1831f,0.0511f,-0.2388f,-0.9522f]}}
particle minecraft:cloud 15.88 71.32 -0.75 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 15.88 71.12 -0.75 0.013 0.02 -0.061 1 0 force
particle minecraft:cloud 14.25 71.32 -1.10 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains 11733
scoreboard players set #gdx driftmountains 459
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains -5541
scoreboard players set #gdz driftmountains 918
scoreboard players set #gr driftmountains 1103
scoreboard players set #gdr driftmountains 18
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.0999f,0.3211f,0.0215f,0.9415f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.0774f,0.9445f,0.0667f,-0.3124f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.1757f,0.0023f,0.0129f,0.9844f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0129f,0.9844f,0.1757f,0.0023f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3577f,0.8415f,0.2379f],left_rotation:[-0.1772f,0.0432f,-0.1966f,-0.9634f]}}
particle minecraft:cloud 12.83 71.32 -6.72 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 12.83 71.12 -6.72 0.012 0.02 -0.060 1 0 force
particle minecraft:cloud 11.15 71.32 -7.04 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains 9013
scoreboard players set #gdx driftmountains 457
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains -10831
scoreboard players set #gdz driftmountains 853
scoreboard players set #gr driftmountains 915
scoreboard players set #gdr driftmountains 20
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.7900f,0.2197f,-0.2318f,0.5233f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.2881f,0.5506f,0.7713f,-0.1379f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.1757f,0.0023f,0.0129f,0.9844f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0129f,0.9844f,0.1757f,0.0023f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3543f,0.8528f,0.1022f],left_rotation:[-0.1839f,0.0476f,-0.2195f,-0.9569f]}}
particle minecraft:cloud 10.04 71.32 -11.94 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 10.04 71.12 -11.94 0.009 0.02 -0.057 1 0 force
particle minecraft:cloud 8.39 71.32 -12.21 0.35 0.18 0.35 0.02 3 force
