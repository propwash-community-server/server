scoreboard players set #gx driftmountains -7913
scoreboard players set #gdx driftmountains 793
scoreboard players set #gy driftmountains 66973
scoreboard players set #gdy driftmountains -10
scoreboard players set #gz driftmountains -76687
scoreboard players set #gdz driftmountains 520
scoreboard players set #gr driftmountains -4468
scoreboard players set #gdr driftmountains -106
scoreboard players set #gp driftmountains 61
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0000f,-0.0074f,1.0000f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.6595f,-0.0417f,-0.1074f,-0.7428f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.0299f,-0.7356f,0.6675f,0.1113f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.0485f,0.0006f,0.0131f,0.9987f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[0.0131f,0.9987f,0.0485f,0.0006f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3849f,0.8223f,0.0902f],left_rotation:[0.1064f,0.1442f,-0.7903f,0.5859f]}}
particle minecraft:cloud -8.21 67.29 -78.17 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -8.21 67.09 -78.17 -0.040 0.02 -0.040 1 0 force
particle minecraft:cloud -9.39 67.29 -77.00 0.35 0.18 0.35 0.02 2 force
scoreboard players set #gx driftmountains -14722
scoreboard players set #gdx driftmountains 802
scoreboard players set #gy driftmountains 67062
scoreboard players set #gdy driftmountains -11
scoreboard players set #gz driftmountains -80604
scoreboard players set #gdz driftmountains 505
scoreboard players set #gr driftmountains -3518
scoreboard players set #gdr driftmountains -118
scoreboard players set #gp driftmountains 62
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/onyx
data merge entity 629b4b55-3f5d-5603-af22-e656d17ac9e9 {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0001f,-0.0138f,0.9999f]}}
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.9671f,0.0220f,-0.2012f,-0.1541f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.1861f,-0.1338f,0.9701f,0.0795f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.0485f,0.0006f,0.0131f,0.9987f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[0.0131f,0.9987f,0.0485f,0.0006f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.3891f,0.8731f,0.2503f],left_rotation:[-0.0436f,0.1880f,-0.9581f,-0.2116f]}}
particle minecraft:cloud -14.81 67.38 -82.21 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -14.81 67.18 -82.21 -0.031 0.02 -0.044 1 0 force
particle minecraft:cloud -16.21 67.38 -81.23 0.35 0.18 0.35 0.02 2 force
scoreboard players set #gx driftmountains -22170
scoreboard players set #gdx driftmountains 643
scoreboard players set #gy driftmountains 67175
scoreboard players set #gdy driftmountains -10
scoreboard players set #gz driftmountains -85903
scoreboard players set #gdz driftmountains 387
scoreboard players set #gr driftmountains -3060
scoreboard players set #gdr driftmountains 29
scoreboard players set #gp driftmountains 66
scoreboard players set #gdp driftmountains -1
function driftmountains:glide/move/kaze2
data merge entity bd924090-27f5-5d45-b644-5399ca3dd51b {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.0001f,-0.0174f,0.9998f]}}
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.6078f,-0.1483f,-0.1881f,-0.7571f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.1095f,-0.7415f,0.6267f,0.2130f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.0485f,0.0006f,0.0131f,0.9987f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[0.0131f,0.9987f,0.0485f,0.0006f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3859f,0.8649f,0.1069f],left_rotation:[-0.1069f,0.1582f,-0.8250f,-0.5318f]}}
particle minecraft:cloud -22.09 67.50 -87.41 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -22.09 67.30 -87.41 -0.025 0.02 -0.043 1 0 force
particle minecraft:cloud -23.53 67.50 -86.56 0.35 0.18 0.35 0.02 2 force
