scoreboard players set #gx driftmountains 6930
scoreboard players set #gdx driftmountains -1072
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 62803
scoreboard players set #gdz driftmountains 209
scoreboard players set #gr driftmountains 13622
scoreboard players set #gdr driftmountains 326
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze
data merge entity c7322e54-c06f-5b95-8971-087c2521a10b {start_interpolation:0,transformation:{left_rotation:[0.0059f,0.0001f,-0.0223f,0.9997f]}}
data merge entity e9234154-0bfb-56e4-9c1c-1ac7c35948ab {start_interpolation:0,transformation:{left_rotation:[0.8956f,0.0183f,-0.4369f,-0.0821f]}}
data merge entity 1bb11ff2-39e3-5d49-be02-a2cb91e10d88 {start_interpolation:0,transformation:{left_rotation:[0.4307f,-0.0367f,0.8986f,0.0757f]}}
data merge entity 8f23be1c-6139-5400-b8f3-69b0c6f3b2b9 {start_interpolation:0,transformation:{left_rotation:[0.6563f,0.0086f,-0.0099f,-0.7544f]}}
data merge entity 161a0ca5-986d-542c-ac70-dca6b502aa0a {start_interpolation:0,transformation:{left_rotation:[-0.0099f,-0.7544f,0.6563f,0.0086f]}}
data merge entity e79afc0e-ce4d-5961-8069-5e70cdf079be {start_interpolation:0,transformation:{translation:[-0.3855f,0.8224f,0.0903f],left_rotation:[-0.1046f,-0.1455f,0.7970f,-0.5767f]}}
particle minecraft:cloud 7.20 71.32 64.29 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 7.20 71.12 64.29 0.045 0.02 0.047 1 0 force
particle minecraft:cloud 8.40 71.32 63.14 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains 13553
scoreboard players set #gdx driftmountains -824
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 58066
scoreboard players set #gdz driftmountains 501
scoreboard players set #gr driftmountains 11812
scoreboard players set #gdr driftmountains 293
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/onyx
data merge entity 2815400c-031d-52ef-becd-8b8ab4e87d9f {start_interpolation:0,transformation:{left_rotation:[0.6673f,0.3426f,-0.2988f,0.5900f]}}
data merge entity 2f66665d-f1b9-5755-bc94-51c0e9910fed {start_interpolation:0,transformation:{left_rotation:[0.3625f,0.6247f,0.6349f,-0.2743f]}}
data merge entity 783ec082-d5db-55ee-9d59-4dcd05fc3011 {start_interpolation:0,transformation:{left_rotation:[0.6563f,0.0086f,-0.0099f,-0.7544f]}}
data merge entity d4c1c6e5-c394-59d4-8c72-fdc9b1b56bd8 {start_interpolation:0,transformation:{left_rotation:[-0.0099f,-0.7544f,0.6563f,0.0086f]}}
data merge entity 1d92c708-738d-5c0f-bf1c-a1cf6fbc5b23 {start_interpolation:0,transformation:{translation:[-0.4062f,0.8486f,0.2407f],left_rotation:[-0.0738f,-0.1705f,0.8846f,-0.4277f]}}
particle minecraft:cloud 14.35 71.32 59.46 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 14.35 71.12 59.46 0.051 0.02 0.027 1 0 force
particle minecraft:cloud 15.16 71.32 57.96 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx driftmountains 19345
scoreboard players set #gdx driftmountains -740
scoreboard players set #gy driftmountains 71000
scoreboard players set #gdy driftmountains 0
scoreboard players set #gz driftmountains 55368
scoreboard players set #gdz driftmountains 784
scoreboard players set #gr driftmountains 10023
scoreboard players set #gdr driftmountains 241
scoreboard players set #gp driftmountains 0
scoreboard players set #gdp driftmountains 0
function driftmountains:glide/move/kaze2
data merge entity cd884c87-b2bc-5d3d-959a-614757d979c8 {start_interpolation:0,transformation:{left_rotation:[0.4089f,-0.3702f,-0.2566f,-0.7937f]}}
data merge entity 4492623c-7cd5-5cdb-9db9-9f7ba40f77d1 {start_interpolation:0,transformation:{left_rotation:[0.1746f,-0.7711f,0.4500f,0.4152f]}}
data merge entity 8b4425e1-cbd6-5b95-8cea-72066f2ab24b {start_interpolation:0,transformation:{left_rotation:[0.6563f,0.0086f,-0.0099f,-0.7544f]}}
data merge entity 5aaee5f6-0980-5228-b56f-98397d334329 {start_interpolation:0,transformation:{left_rotation:[-0.0099f,-0.7544f,0.6563f,0.0086f]}}
data merge entity 7a3bf99e-c36b-5f68-91ac-1b77003bb08e {start_interpolation:0,transformation:{translation:[-0.3912f,0.8254f,0.0914f],left_rotation:[-0.0828f,-0.1594f,0.8670f,-0.4648f]}}
particle minecraft:cloud 20.44 71.32 56.41 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 20.44 71.12 56.41 0.065 0.02 0.012 1 0 force
particle minecraft:cloud 20.73 71.32 54.77 0.35 0.18 0.35 0.02 3 force
