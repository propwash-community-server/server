$function drift:f/$(t)
