tp 425483f9-2934-53dd-805b-82336df4bdbc -54.149 65 61.525 -97 0
tp 77d4edec-4f89-5806-8a73-69da291cf64a -54.149 65 61.525 -97 0
tp a18c987f-26df-590a-b51c-8f6379e10218 -54.149 65 61.525 -97 0
tp 8bd36e4e-1a75-51ba-b224-63055ff644c2 -54.149 65 61.525 -97 0
tp 7b07c259-0b81-5b46-b286-5b101f183bf9 -54.149 65 61.525 -97 0
tp 04fc5281-333c-5c0d-ba69-0b625cbc7206 -54.149 65 61.525 -97 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0058f,-0.0001f,0.019f,0.9998f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.2523f,-0.1836f,0.0063f,0.9501f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.0936f,0.9546f,-0.2344f,0.1581f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.2471f,-0.0032f,0.0127f,0.9689f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.0127f,-0.9689f,0.2471f,0.0032f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4024f,0.8466f,0.0999f],left_rotation:[0.0014f,0.1851f,-0.9817f,0.0448f]}}
particle minecraft:cloud -59.35 65.32 59.43 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -59.23 65.12 61.09 -0.036 0.02 0.031 1 0 force
particle minecraft:cloud -59.23 65.32 61.09 0.35 0.18 0.35 0.02 2 force
tp 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 -67.221 65 56.865 -90.84 0
tp f74f363c-8714-5fe5-bb64-beafe6b6ac28 -67.221 65 56.865 -90.84 0
tp 97428e5f-5a51-575c-8305-607c4b0f68cb -67.221 65 56.865 -90.84 0
tp 186c432f-da2b-5bec-ba8a-9d97f056504e -67.221 65 56.865 -90.84 0
tp b7fef3cd-3066-54f8-9318-2747261e9dd9 -67.221 65 56.865 -90.84 0
tp 0d17ad00-82d8-5739-af58-9e93f268e98c -67.221 65 56.865 -90.84 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0059f,-0.0001f,0.0219f,0.9997f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.2768f,-0.2446f,-0.0166f,0.9291f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.1144f,0.936f,-0.2526f,0.2169f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.2471f,-0.0032f,0.0127f,0.9689f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.0127f,-0.9689f,0.2471f,0.0032f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4075f,0.8458f,0.2398f],left_rotation:[0.103f,0.1537f,-0.7917f,0.5823f]}}
particle minecraft:cloud -71.47 65.32 53.82 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -71.47 65.42 53.82 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke -71.55 65.12 55.53 -0.047 0.022 0.011 1 0 force
particle minecraft:cloud -71.55 65.32 55.53 0.35 0.18 0.35 0.02 3 force
