tp 425483f9-2934-53dd-805b-82336df4bdbc 34.414 65 -50.232 58.66 0
tp 77d4edec-4f89-5806-8a73-69da291cf64a 34.414 65 -50.232 58.66 0
tp a18c987f-26df-590a-b51c-8f6379e10218 34.414 65 -50.232 58.66 0
tp 8bd36e4e-1a75-51ba-b224-63055ff644c2 34.414 65 -50.232 58.66 0
tp 7b07c259-0b81-5b46-b286-5b101f183bf9 34.414 65 -50.232 58.66 0
tp 04fc5281-333c-5c0d-ba69-0b625cbc7206 34.414 65 -50.232 58.66 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0.0043f,0.0001f,0.0223f,0.9997f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.842f,-0.063f,0.2145f,0.4909f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.1641f,0.4711f,0.8533f,0.1519f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.8591f,0.0112f,0.0067f,0.5116f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.0067f,0.5116f,0.8591f,0.0112f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4079f,0.8417f,0.1174f],left_rotation:[0.0732f,0.1808f,-0.8919f,0.4081f]}}
particle minecraft:cloud 39.71 65.32 -49.77 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 38.99 65.12 -51.28 0.031 0.022 -0.029 1 0 force
particle minecraft:cloud 38.99 65.32 -51.28 0.35 0.18 0.35 0.02 3 force
tp 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 48.154 65 -49.017 76.03 0
tp f74f363c-8714-5fe5-bb64-beafe6b6ac28 48.154 65 -49.017 76.03 0
tp 97428e5f-5a51-575c-8305-607c4b0f68cb 48.154 65 -49.017 76.03 0
tp 186c432f-da2b-5bec-ba8a-9d97f056504e 48.154 65 -49.017 76.03 0
tp b7fef3cd-3066-54f8-9318-2747261e9dd9 48.154 65 -49.017 76.03 0
tp 0d17ad00-82d8-5739-af58-9e93f268e98c 48.154 65 -49.017 76.03 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0.0106f,0.0002f,0.0222f,0.9997f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.7791f,-0.1763f,-0.1458f,0.5836f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.2079f,0.6022f,-0.7649f,0.0953f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.8591f,0.0112f,0.0067f,0.5116f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.0067f,0.5116f,0.8591f,0.0112f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4076f,0.8372f,0.2681f],left_rotation:[0.0845f,0.1826f,-0.8698f,0.4506f]}}
particle minecraft:cloud 53.93 65.32 -46.66 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 53.68 65.12 -48.35 0.047 0.022 -0.024 1 0 force
particle minecraft:cloud 53.68 65.32 -48.35 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 53.68 65.42 -48.35 0.45 0.2 0.45 0.008 1 force
