tp 425483f9-2934-53dd-805b-82336df4bdbc 46.886 65 -48.516 78.13 0
tp 77d4edec-4f89-5806-8a73-69da291cf64a 46.886 65 -48.516 78.13 0
tp a18c987f-26df-590a-b51c-8f6379e10218 46.886 65 -48.516 78.13 0
tp 8bd36e4e-1a75-51ba-b224-63055ff644c2 46.886 65 -48.516 78.13 0
tp 7b07c259-0b81-5b46-b286-5b101f183bf9 46.886 65 -48.516 78.13 0
tp 04fc5281-333c-5c0d-ba69-0b625cbc7206 46.886 65 -48.516 78.13 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0.0103f,0.0002f,0.0222f,0.9997f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.2277f,-0.2045f,0.006f,0.952f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.094f,0.9566f,-0.2074f,0.1816f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.2415f,-0.0032f,0.0127f,0.9703f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.0127f,-0.9703f,0.2415f,0.0032f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4078f,0.8402f,0.1276f],left_rotation:[0.0406f,0.1967f,-0.9497f,0.2403f]}}
particle minecraft:campfire_cosy_smoke 52.47 65.12 -46.33 0.05 0.022 0.068 1 0 force
particle minecraft:cloud 52.47 65.32 -46.33 0.35 0.18 0.35 0.02 2 force
particle minecraft:cloud 52.29 65.32 -47.99 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke 52.29 65.42 -47.99 0.45 0.2 0.45 0.008 1 force
tp 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 62.41 65 -42.471 93.58 0
tp f74f363c-8714-5fe5-bb64-beafe6b6ac28 62.41 65 -42.471 93.58 0
tp 97428e5f-5a51-575c-8305-607c4b0f68cb 62.41 65 -42.471 93.58 0
tp 186c432f-da2b-5bec-ba8a-9d97f056504e 62.41 65 -42.471 93.58 0
tp b7fef3cd-3066-54f8-9318-2747261e9dd9 62.41 65 -42.471 93.58 0
tp 0d17ad00-82d8-5739-af58-9e93f268e98c 62.41 65 -42.471 93.58 0
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.7463f,-0.0884f,0.1869f,0.6327f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.1214f,0.6165f,0.7597f,0.1673f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.2415f,-0.0032f,0.0127f,0.9703f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.0127f,-0.9703f,0.2415f,0.0032f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.408f,0.8456f,0.2399f],left_rotation:[0.0411f,0.1805f,-0.9476f,0.2605f]}}
particle minecraft:campfire_cosy_smoke 67.72 65.12 -38.81 0.041 0.022 0.074 1 0 force
particle minecraft:cloud 67.72 65.32 -38.81 0.35 0.18 0.35 0.02 2 force
particle minecraft:cloud 67.95 65.32 -40.51 0.35 0.18 0.35 0.02 2 force
