tp 425483f9-2934-53dd-805b-82336df4bdbc -68.981 65 54.606 -84.27 0
tp 77d4edec-4f89-5806-8a73-69da291cf64a -68.981 65 54.606 -84.27 0
tp a18c987f-26df-590a-b51c-8f6379e10218 -68.981 65 54.606 -84.27 0
tp 8bd36e4e-1a75-51ba-b224-63055ff644c2 -68.981 65 54.606 -84.27 0
tp 7b07c259-0b81-5b46-b286-5b101f183bf9 -68.981 65 54.606 -84.27 0
tp 04fc5281-333c-5c0d-ba69-0b625cbc7206 -68.981 65 54.606 -84.27 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0036f,-0.0001f,0.0222f,0.9997f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.4444f,-0.2192f,-0.0521f,0.867f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.1435f,0.8773f,-0.4238f,0.1737f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.4532f,-0.0059f,0.0117f,0.8913f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.0117f,-0.8913f,0.4532f,0.0059f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4078f,0.8435f,0.1037f],left_rotation:[0.0731f,0.1724f,-0.8864f,0.4233f]}}
particle minecraft:campfire_cosy_smoke -72.68 65.12 51.38 -0.015 0.022 -0.077 1 0 force
particle minecraft:cloud -72.68 65.32 51.38 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud -72.96 65.32 53.02 0.35 0.18 0.35 0.02 3 force
tp 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 -78.251 65 46.372 -70.35 0
tp f74f363c-8714-5fe5-bb64-beafe6b6ac28 -78.251 65 46.372 -70.35 0
tp 97428e5f-5a51-575c-8305-607c4b0f68cb -78.251 65 46.372 -70.35 0
tp 186c432f-da2b-5bec-ba8a-9d97f056504e -78.251 65 46.372 -70.35 0
tp b7fef3cd-3066-54f8-9318-2747261e9dd9 -78.251 65 46.372 -70.35 0
tp 0d17ad00-82d8-5739-af58-9e93f268e98c -78.251 65 46.372 -70.35 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0.0111f,0.0002f,0.0195f,0.9997f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.3985f,-0.2462f,-0.052f,0.882f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.145f,0.8923f,-0.3748f,0.2056f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.4532f,-0.0059f,0.0117f,0.8913f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.0117f,-0.8913f,0.4532f,0.0059f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4031f,0.8391f,0.2691f],left_rotation:[0.1227f,0.1601f,-0.7536f,0.6256f]}}
particle minecraft:campfire_cosy_smoke -81.18 65.12 41.18 -0.004 0.022 -0.092 1 0 force
particle minecraft:cloud -81.18 65.32 41.18 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud -81.96 65.32 42.7 0.35 0.18 0.35 0.02 3 force
