tp 425483f9-2934-53dd-805b-82336df4bdbc -38.477 65 -18.584 160.15 0
tp 77d4edec-4f89-5806-8a73-69da291cf64a -38.477 65 -18.584 160.15 0
tp a18c987f-26df-590a-b51c-8f6379e10218 -38.477 65 -18.584 160.15 0
tp 8bd36e4e-1a75-51ba-b224-63055ff644c2 -38.477 65 -18.584 160.15 0
tp 7b07c259-0b81-5b46-b286-5b101f183bf9 -38.477 65 -18.584 160.15 0
tp 04fc5281-333c-5c0d-ba69-0b625cbc7206 -38.477 65 -18.584 160.15 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0059f,0.0001f,-0.0205f,0.9998f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.549f,0.1982f,-0.0699f,0.809f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.1553f,-0.8208f,-0.5312f,0.1415f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.9737f,-0.0127f,0.003f,0.2274f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.003f,-0.2274f,0.9737f,0.0127f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.3343f,0.8757f,0.0999f],left_rotation:[0.0472f,-0.1789f,0.9391f,0.2897f]}}
particle minecraft:cloud -36.33 65.32 -15.09 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -34.77 65.12 -15.7 0.073 0.022 0.003 1 0 force
particle minecraft:cloud -34.77 65.32 -15.7 0.35 0.18 0.35 0.02 3 force
tp 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 -30.023 65 -11.958 153.89 0
tp f74f363c-8714-5fe5-bb64-beafe6b6ac28 -30.023 65 -11.958 153.89 0
tp 97428e5f-5a51-575c-8305-607c4b0f68cb -30.023 65 -11.958 153.89 0
tp 186c432f-da2b-5bec-ba8a-9d97f056504e -30.023 65 -11.958 153.89 0
tp b7fef3cd-3066-54f8-9318-2747261e9dd9 -30.023 65 -11.958 153.89 0
tp 0d17ad00-82d8-5739-af58-9e93f268e98c -30.023 65 -11.958 153.89 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0.0004f,0f,-0.0223f,0.9998f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.3437f,0.2921f,-0.054f,0.8909f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.148f,-0.9015f,-0.3149f,0.2576f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.9737f,-0.0127f,0.003f,0.2274f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.003f,-0.2274f,0.9737f,0.0127f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.3314f,0.8754f,0.2506f],left_rotation:[0.1691f,-0.0892f,0.4189f,0.8877f]}}
particle minecraft:cloud -26.99 65.32 -9.45 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -26.99 65.42 -9.45 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke -25.56 65.12 -10.37 0.07 0.022 -0.008 1 0 force
particle minecraft:cloud -25.56 65.32 -10.37 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -25.56 65.42 -10.37 0.45 0.2 0.45 0.008 1 force
