tp 425483f9-2934-53dd-805b-82336df4bdbc -80.818 65 40.481 -55.06 0
tp 77d4edec-4f89-5806-8a73-69da291cf64a -80.818 65 40.481 -55.06 0
tp a18c987f-26df-590a-b51c-8f6379e10218 -80.818 65 40.481 -55.06 0
tp 8bd36e4e-1a75-51ba-b224-63055ff644c2 -80.818 65 40.481 -55.06 0
tp 7b07c259-0b81-5b46-b286-5b101f183bf9 -80.818 65 40.481 -55.06 0
tp 04fc5281-333c-5c0d-ba69-0b625cbc7206 -80.818 65 40.481 -55.06 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0.0111f,0.0002f,0.014f,0.9998f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.9702f,-0.0808f,-0.1612f,0.1621f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.1791f,-0.18f,0.967f,0.0207f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.9948f,-0.013f,0.0013f,0.1014f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.0013f,-0.1014f,0.9948f,0.013f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.3938f,0.8467f,0.1291f],left_rotation:[-0.004f,0.2017f,-0.9794f,0.0081f]}}
particle minecraft:campfire_cosy_smoke -83.32 65.12 34.74 -0.007 0.019 -0.089 1 0 force
particle minecraft:cloud -83.32 65.32 34.74 0.35 0.18 0.35 0.02 2 force
particle minecraft:cloud -84.45 65.32 35.97 0.35 0.18 0.35 0.02 2 force
tp 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 -88.361 65 24.732 -30.72 0
tp f74f363c-8714-5fe5-bb64-beafe6b6ac28 -88.361 65 24.732 -30.72 0
tp 97428e5f-5a51-575c-8305-607c4b0f68cb -88.361 65 24.732 -30.72 0
tp 186c432f-da2b-5bec-ba8a-9d97f056504e -88.361 65 24.732 -30.72 0
tp b7fef3cd-3066-54f8-9318-2747261e9dd9 -88.361 65 24.732 -30.72 0
tp 0d17ad00-82d8-5739-af58-9e93f268e98c -88.361 65 24.732 -30.72 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0f,0f,0.0113f,0.9999f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.9953f,-0.0556f,-0.062f,0.0499f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.0676f,-0.0567f,0.9949f,0.0487f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.9948f,-0.013f,0.0013f,0.1014f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.0013f,-0.1014f,0.9948f,0.013f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.3894f,0.8514f,0.25f],left_rotation:[0.1603f,-0.1036f,0.5513f,0.8122f]}}
