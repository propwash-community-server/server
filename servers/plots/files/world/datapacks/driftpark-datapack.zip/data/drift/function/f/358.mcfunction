tp 425483f9-2934-53dd-805b-82336df4bdbc -50.28 65 -32.882 114.9 0
tp 77d4edec-4f89-5806-8a73-69da291cf64a -50.28 65 -32.882 114.9 0
tp a18c987f-26df-590a-b51c-8f6379e10218 -50.28 65 -32.882 114.9 0
tp 8bd36e4e-1a75-51ba-b224-63055ff644c2 -50.28 65 -32.882 114.9 0
tp 7b07c259-0b81-5b46-b286-5b101f183bf9 -50.28 65 -32.882 114.9 0
tp 04fc5281-333c-5c0d-ba69-0b625cbc7206 -50.28 65 -32.882 114.9 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0059f,0f,0.0064f,1f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.9428f,0.0073f,0.1532f,0.2961f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.1229f,0.2816f,0.9472f,0.0917f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.3359f,-0.0044f,0.0123f,0.9418f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.0123f,-0.9418f,0.3359f,0.0044f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.381f,0.8564f,0.0999f],left_rotation:[0.0496f,-0.1783f,0.95f,0.2515f]}}
particle minecraft:cloud -47.24 65.32 -28.32 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -46.26 65.12 -29.67 0.057 0.017 0.003 1 0 force
particle minecraft:cloud -46.26 65.32 -29.67 0.35 0.18 0.35 0.02 2 force
tp 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 -42.667 65 -21.748 153.9 0
tp f74f363c-8714-5fe5-bb64-beafe6b6ac28 -42.667 65 -21.748 153.9 0
tp 97428e5f-5a51-575c-8305-607c4b0f68cb -42.667 65 -21.748 153.9 0
tp 186c432f-da2b-5bec-ba8a-9d97f056504e -42.667 65 -21.748 153.9 0
tp b7fef3cd-3066-54f8-9318-2747261e9dd9 -42.667 65 -21.748 153.9 0
tp 0d17ad00-82d8-5739-af58-9e93f268e98c -42.667 65 -21.748 153.9 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0058f,0.0001f,-0.0153f,0.9999f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.985f,-0.0436f,0.1556f,0.0598f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.1502f,-0.0438f,0.9859f,0.0597f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.3359f,-0.0044f,0.0123f,0.9418f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.0123f,-0.9418f,0.3359f,0.0044f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.3434f,0.8738f,0.2399f],left_rotation:[0.0369f,0.1814f,-0.9686f,0.1662f]}}
particle minecraft:cloud -40.6 65.32 -17.63 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -38.99 65.12 -18.21 0.072 0.019 0.019 1 0 force
particle minecraft:cloud -38.99 65.32 -18.21 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -38.99 65.42 -18.21 0.45 0.2 0.45 0.008 1 force
