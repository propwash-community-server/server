tp 425483f9-2934-53dd-805b-82336df4bdbc -96.565 65 -21.161 -17.91 0
tp 77d4edec-4f89-5806-8a73-69da291cf64a -96.565 65 -21.161 -17.91 0
tp a18c987f-26df-590a-b51c-8f6379e10218 -96.565 65 -21.161 -17.91 0
tp 8bd36e4e-1a75-51ba-b224-63055ff644c2 -96.565 65 -21.161 -17.91 0
tp 7b07c259-0b81-5b46-b286-5b101f183bf9 -96.565 65 -21.161 -17.91 0
tp 04fc5281-333c-5c0d-ba69-0b625cbc7206 -96.565 65 -21.161 -17.91 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0059f,-0.0001f,0.0175f,0.9998f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.8337f,-0.1447f,-0.1324f,0.5162f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.1874f,0.5329f,-0.8231f,0.0578f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.8792f,-0.0115f,0.0062f,0.4763f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.0062f,-0.4763f,0.8792f,0.0115f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.3999f,0.8478f,0.0998f],left_rotation:[0.0236f,0.1835f,-0.9697f,0.1594f]}}
particle minecraft:cloud -95.38 65.32 -26.16 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -97 65.12 -25.74 -0.036 0.022 -0.025 1 0 force
particle minecraft:cloud -97 65.32 -25.74 0.35 0.18 0.35 0.02 2 force
tp 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 -94.288 65 -33.142 -10.78 0
tp f74f363c-8714-5fe5-bb64-beafe6b6ac28 -94.288 65 -33.142 -10.78 0
tp 97428e5f-5a51-575c-8305-607c4b0f68cb -94.288 65 -33.142 -10.78 0
tp 186c432f-da2b-5bec-ba8a-9d97f056504e -94.288 65 -33.142 -10.78 0
tp b7fef3cd-3066-54f8-9318-2747261e9dd9 -94.288 65 -33.142 -10.78 0
tp 0d17ad00-82d8-5739-af58-9e93f268e98c -94.288 65 -33.142 -10.78 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0058f,-0.0001f,0.0191f,0.9998f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.4646f,-0.2452f,-0.0727f,0.8478f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.1622f,0.8601f,-0.4414f,0.1977f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.8792f,-0.0115f,0.0062f,0.4763f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.0062f,-0.4763f,0.8792f,0.0115f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4028f,0.8481f,0.24f],left_rotation:[0.1183f,0.1423f,-0.7311f,0.6567f]}}
particle minecraft:cloud -92.19 65.32 -37.4 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -93.89 65.12 -37.16 -0.021 0.022 -0.02 1 0 force
particle minecraft:cloud -93.89 65.32 -37.16 0.35 0.18 0.35 0.02 3 force
