tp 425483f9-2934-53dd-805b-82336df4bdbc -86.627 65 28.241 -33.29 0
tp 77d4edec-4f89-5806-8a73-69da291cf64a -86.627 65 28.241 -33.29 0
tp a18c987f-26df-590a-b51c-8f6379e10218 -86.627 65 28.241 -33.29 0
tp 8bd36e4e-1a75-51ba-b224-63055ff644c2 -86.627 65 28.241 -33.29 0
tp 7b07c259-0b81-5b46-b286-5b101f183bf9 -86.627 65 28.241 -33.29 0
tp 04fc5281-333c-5c0d-ba69-0b625cbc7206 -86.627 65 28.241 -33.29 0
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.0646f,-0.0681f,0.0481f,0.9944f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.0561f,0.9948f,-0.0578f,0.0617f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.1332f,-0.0017f,0.013f,0.991f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.013f,-0.991f,0.1332f,0.0017f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.3894f,0.8514f,0.11f],left_rotation:[0.1601f,-0.1038f,0.5525f,0.8114f]}}
tp 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 -92.934 65 11.221 -24.34 0
tp f74f363c-8714-5fe5-bb64-beafe6b6ac28 -92.934 65 11.221 -24.34 0
tp 97428e5f-5a51-575c-8305-607c4b0f68cb -92.934 65 11.221 -24.34 0
tp 186c432f-da2b-5bec-ba8a-9d97f056504e -92.934 65 11.221 -24.34 0
tp b7fef3cd-3066-54f8-9318-2747261e9dd9 -92.934 65 11.221 -24.34 0
tp 0d17ad00-82d8-5739-af58-9e93f268e98c -92.934 65 11.221 -24.34 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0059f,-0.0001f,0.0099f,0.9999f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.241f,-0.0805f,0.034f,0.9666f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.0674f,0.9683f,-0.2339f,0.0556f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.1332f,-0.0017f,0.013f,0.991f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.013f,-0.991f,0.1332f,0.0017f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.3869f,0.8554f,0.2399f],left_rotation:[0.1504f,-0.1078f,0.5883f,0.7872f]}}
particle minecraft:campfire_cosy_smoke -95.52 65.12 5.58 -0.051 0.012 -0.048 1 0 force
