tp 425483f9-2934-53dd-805b-82336df4bdbc 14.747 65 -44.379 17.14 0
tp 77d4edec-4f89-5806-8a73-69da291cf64a 14.747 65 -44.379 17.14 0
tp a18c987f-26df-590a-b51c-8f6379e10218 14.747 65 -44.379 17.14 0
tp 8bd36e4e-1a75-51ba-b224-63055ff644c2 14.747 65 -44.379 17.14 0
tp 7b07c259-0b81-5b46-b286-5b101f183bf9 14.747 65 -44.379 17.14 0
tp 04fc5281-333c-5c0d-ba69-0b625cbc7206 14.747 65 -44.379 17.14 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0.0065f,0.0001f,0.0223f,0.9997f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.6741f,-0.1513f,0.2245f,0.6873f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.1535f,0.6675f,0.6937f,0.223f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.828f,0.0108f,0.0073f,0.5606f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.0073f,0.5606f,0.828f,0.0108f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4078f,0.8412f,0.1212f],left_rotation:[0.1459f,0.1326f,-0.6265f,0.7541f]}}
particle minecraft:cloud 18.83 65.32 -46.77 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 18.83 65.42 -46.77 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke 17.31 65.12 -47.46 0.004 0.022 -0.043 1 0 force
particle minecraft:cloud 17.31 65.32 -47.46 0.35 0.18 0.35 0.02 3 force
tp 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 25.216 65 -49.955 39.98 0
tp f74f363c-8714-5fe5-bb64-beafe6b6ac28 25.216 65 -49.955 39.98 0
tp 97428e5f-5a51-575c-8305-607c4b0f68cb 25.216 65 -49.955 39.98 0
tp 186c432f-da2b-5bec-ba8a-9d97f056504e 25.216 65 -49.955 39.98 0
tp b7fef3cd-3066-54f8-9318-2747261e9dd9 25.216 65 -49.955 39.98 0
tp 0d17ad00-82d8-5739-af58-9e93f268e98c 25.216 65 -49.955 39.98 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0.0012f,0f,0.0223f,0.9998f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.731f,-0.2073f,-0.1574f,0.6307f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.2246f,0.6507f,-0.7133f,0.1316f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.828f,0.0108f,0.0073f,0.5606f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.0073f,0.5606f,0.828f,0.0108f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4079f,0.8421f,0.252f],left_rotation:[0.1286f,0.1425f,-0.6985f,0.6894f]}}
particle minecraft:cloud 30.5 65.32 -50.92 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 30.5 65.42 -50.92 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke 29.32 65.12 -52.15 0.018 0.022 -0.027 1 0 force
particle minecraft:cloud 29.32 65.32 -52.15 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 29.32 65.42 -52.15 0.45 0.2 0.45 0.008 1 force
