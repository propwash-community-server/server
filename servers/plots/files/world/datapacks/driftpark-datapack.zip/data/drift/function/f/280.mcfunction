tp 425483f9-2934-53dd-805b-82336df4bdbc -1.578 65 -21.588 71.88 0
tp 77d4edec-4f89-5806-8a73-69da291cf64a -1.578 65 -21.588 71.88 0
tp a18c987f-26df-590a-b51c-8f6379e10218 -1.578 65 -21.588 71.88 0
tp 8bd36e4e-1a75-51ba-b224-63055ff644c2 -1.578 65 -21.588 71.88 0
tp 7b07c259-0b81-5b46-b286-5b101f183bf9 -1.578 65 -21.588 71.88 0
tp 04fc5281-333c-5c0d-ba69-0b625cbc7206 -1.578 65 -21.588 71.88 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0004f,0f,-0.0179f,0.9998f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.9508f,0.1002f,-0.2091f,0.2055f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.2318f,-0.2286f,-0.9455f,0.0008f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.9881f,0.0129f,0.002f,0.1533f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.002f,0.1533f,0.9881f,0.0129f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.3391f,0.8727f,0.1094f],left_rotation:[0.0858f,-0.17f,0.8601f,0.4732f]}}
particle minecraft:cloud 2.09 65.32 -24.72 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 1.29 65.12 -26.19 0.013 0.022 -0.076 1 0 force
particle minecraft:cloud 1.29 65.32 -26.19 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 1.29 65.42 -26.19 0.45 0.2 0.45 0.008 1 force
tp 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 4.827 65 -32.903 30.21 0
tp f74f363c-8714-5fe5-bb64-beafe6b6ac28 4.827 65 -32.903 30.21 0
tp 97428e5f-5a51-575c-8305-607c4b0f68cb 4.827 65 -32.903 30.21 0
tp 186c432f-da2b-5bec-ba8a-9d97f056504e 4.827 65 -32.903 30.21 0
tp b7fef3cd-3066-54f8-9318-2747261e9dd9 4.827 65 -32.903 30.21 0
tp 0d17ad00-82d8-5739-af58-9e93f268e98c 4.827 65 -32.903 30.21 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0059f,-0.0001f,0.0105f,0.9999f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.6643f,-0.0852f,-0.0058f,0.7426f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.0839f,0.7473f,-0.659f,0.0158f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.9881f,0.0129f,0.002f,0.1533f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.002f,0.1533f,0.9881f,0.0129f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.388f,0.855f,0.2398f],left_rotation:[0.1529f,-0.1042f,0.5706f,0.8001f]}}
particle minecraft:campfire_cosy_smoke 5.82 65.12 -37.57 -0.025 0.013 -0.06 1 0 force
