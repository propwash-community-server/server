tp 425483f9-2934-53dd-805b-82336df4bdbc -16.197 65 -11.317 121.01 0
tp 77d4edec-4f89-5806-8a73-69da291cf64a -16.197 65 -11.317 121.01 0
tp a18c987f-26df-590a-b51c-8f6379e10218 -16.197 65 -11.317 121.01 0
tp 8bd36e4e-1a75-51ba-b224-63055ff644c2 -16.197 65 -11.317 121.01 0
tp 7b07c259-0b81-5b46-b286-5b101f183bf9 -16.197 65 -11.317 121.01 0
tp 04fc5281-333c-5c0d-ba69-0b625cbc7206 -16.197 65 -11.317 121.01 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0018f,0f,-0.0223f,0.9998f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.8692f,0.0676f,0.2729f,0.4068f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.2316f,-0.3804f,0.8811f,0.1593f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.4583f,-0.006f,0.0116f,0.8887f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.0116f,-0.8887f,0.4583f,0.006f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.3314f,0.876f,0.1069f],left_rotation:[0.1518f,-0.1126f,0.5492f,0.8141f]}}
particle minecraft:campfire_cosy_smoke -12.99 65.12 -10.75 0.019 0.022 0.034 1 0 force
particle minecraft:cloud -12.99 65.32 -10.75 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud -12.31 65.32 -12.28 0.35 0.18 0.35 0.02 3 force
tp 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 -7.492 65 -14.257 100.79 0
tp f74f363c-8714-5fe5-bb64-beafe6b6ac28 -7.492 65 -14.257 100.79 0
tp 97428e5f-5a51-575c-8305-607c4b0f68cb -7.492 65 -14.257 100.79 0
tp 186c432f-da2b-5bec-ba8a-9d97f056504e -7.492 65 -14.257 100.79 0
tp b7fef3cd-3066-54f8-9318-2747261e9dd9 -7.492 65 -14.257 100.79 0
tp 0d17ad00-82d8-5739-af58-9e93f268e98c -7.492 65 -14.257 100.79 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0.0106f,-0.0002f,-0.0222f,0.9997f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.3076f,0.3288f,-0.0548f,0.8912f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.1488f,-0.9019f,-0.2748f,0.2982f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.4583f,-0.006f,0.0116f,0.8887f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.0116f,-0.8887f,0.4583f,0.006f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.3317f,0.8701f,0.2681f],left_rotation:[0.1993f,-0.0274f,0.09f,0.9754f]}}
particle minecraft:campfire_cosy_smoke -3.71 65.12 -15.54 0.03 0.022 0.013 1 0 force
particle minecraft:cloud -3.71 65.32 -15.54 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -3.71 65.42 -15.54 0.45 0.2 0.45 0.008 1 force
particle minecraft:cloud -3.64 65.32 -17.25 0.35 0.18 0.35 0.02 3 force
