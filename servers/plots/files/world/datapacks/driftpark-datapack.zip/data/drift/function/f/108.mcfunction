tp 425483f9-2934-53dd-805b-82336df4bdbc 78.665 65 38.162 -167.04 0
tp 77d4edec-4f89-5806-8a73-69da291cf64a 78.665 65 38.162 -167.04 0
tp a18c987f-26df-590a-b51c-8f6379e10218 78.665 65 38.162 -167.04 0
tp 8bd36e4e-1a75-51ba-b224-63055ff644c2 78.665 65 38.162 -167.04 0
tp 7b07c259-0b81-5b46-b286-5b101f183bf9 78.665 65 38.162 -167.04 0
tp 04fc5281-333c-5c0d-ba69-0b625cbc7206 78.665 65 38.162 -167.04 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0.0036f,0.0001f,0.0223f,0.9997f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.2532f,-0.199f,0.002f,0.9467f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.0975f,0.9517f,-0.2337f,0.1735f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.2583f,-0.0034f,0.0126f,0.966f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.0126f,-0.966f,0.2583f,0.0034f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4079f,0.8419f,0.1162f],left_rotation:[0.0291f,0.1922f,-0.9624f,0.19f]}}
particle minecraft:cloud 74.46 65.32 42.35 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke 76.05 65.12 42.87 0.003 0.021 0.048 1 0 force
particle minecraft:cloud 76.05 65.32 42.87 0.35 0.18 0.35 0.02 2 force
tp 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 67.612 65 49.41 -154.02 0
tp f74f363c-8714-5fe5-bb64-beafe6b6ac28 67.612 65 49.41 -154.02 0
tp 97428e5f-5a51-575c-8305-607c4b0f68cb 67.612 65 49.41 -154.02 0
tp 186c432f-da2b-5bec-ba8a-9d97f056504e 67.612 65 49.41 -154.02 0
tp b7fef3cd-3066-54f8-9318-2747261e9dd9 67.612 65 49.41 -154.02 0
tp 0d17ad00-82d8-5739-af58-9e93f268e98c 67.612 65 49.41 -154.02 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0.0011f,0f,0.0223f,0.9998f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.2952f,-0.1851f,0.1149f,0.9303f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.0178f,0.9233f,0.3162f,0.2172f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.2583f,-0.0034f,0.0126f,0.966f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.0126f,-0.966f,0.2583f,0.0034f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4079f,0.8421f,0.2519f],left_rotation:[0.0623f,0.1815f,-0.9132f,0.3594f]}}
particle minecraft:cloud 62.17 65.32 52.65 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 62.17 65.42 52.65 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke 63.65 65.12 53.52 -0.02 0.022 0.044 1 0 force
particle minecraft:cloud 63.65 65.32 53.52 0.35 0.18 0.35 0.02 3 force
