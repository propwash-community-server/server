tp 425483f9-2934-53dd-805b-82336df4bdbc -86.149 65 -42.771 10.54 0
tp 77d4edec-4f89-5806-8a73-69da291cf64a -86.149 65 -42.771 10.54 0
tp a18c987f-26df-590a-b51c-8f6379e10218 -86.149 65 -42.771 10.54 0
tp 8bd36e4e-1a75-51ba-b224-63055ff644c2 -86.149 65 -42.771 10.54 0
tp 7b07c259-0b81-5b46-b286-5b101f183bf9 -86.149 65 -42.771 10.54 0
tp 04fc5281-333c-5c0d-ba69-0b625cbc7206 -86.149 65 -42.771 10.54 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0011f,0f,0.0223f,0.9998f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.7753f,-0.1139f,0.2466f,0.5702f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.188f,0.5475f,0.7915f,0.1961f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.89f,0.0117f,0.006f,0.4558f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.006f,0.4558f,0.89f,0.0117f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4079f,0.8429f,0.1081f],left_rotation:[0.1415f,0.1264f,-0.6207f,0.7607f]}}
particle minecraft:cloud -82.93 65.32 -44.89 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -82.93 65.42 -44.89 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke -84.5 65.12 -45.43 -0.017 0.022 -0.032 1 0 force
particle minecraft:cloud -84.5 65.32 -45.43 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -84.5 65.42 -45.43 0.45 0.2 0.45 0.008 1 force
tp 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 -78.48 65 -46.894 34.79 0
tp f74f363c-8714-5fe5-bb64-beafe6b6ac28 -78.48 65 -46.894 34.79 0
tp 97428e5f-5a51-575c-8305-607c4b0f68cb -78.48 65 -46.894 34.79 0
tp 186c432f-da2b-5bec-ba8a-9d97f056504e -78.48 65 -46.894 34.79 0
tp b7fef3cd-3066-54f8-9318-2747261e9dd9 -78.48 65 -46.894 34.79 0
tp 0d17ad00-82d8-5739-af58-9e93f268e98c -78.48 65 -46.894 34.79 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0.0057f,0.0001f,0.0223f,0.9997f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.5811f,-0.2817f,-0.1488f,0.7489f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.2283f,0.7686f,-0.5547f,0.2221f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.89f,0.0117f,0.006f,0.4558f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.006f,0.4558f,0.89f,0.0117f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4078f,0.8398f,0.2598f],left_rotation:[0.1888f,0.0541f,-0.2278f,0.9537f]}}
particle minecraft:cloud -73.94 65.32 -47.51 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -75.2 65.12 -48.67 0.017 0.022 -0.027 1 0 force
particle minecraft:cloud -75.2 65.32 -48.67 0.35 0.18 0.35 0.02 3 force
