tp 425483f9-2934-53dd-805b-82336df4bdbc -8.038 65 -14.978 96.19 0
tp 77d4edec-4f89-5806-8a73-69da291cf64a -8.038 65 -14.978 96.19 0
tp a18c987f-26df-590a-b51c-8f6379e10218 -8.038 65 -14.978 96.19 0
tp 8bd36e4e-1a75-51ba-b224-63055ff644c2 -8.038 65 -14.978 96.19 0
tp 7b07c259-0b81-5b46-b286-5b101f183bf9 -8.038 65 -14.978 96.19 0
tp 04fc5281-333c-5c0d-ba69-0b625cbc7206 -8.038 65 -14.978 96.19 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0.0106f,-0.0002f,-0.0222f,0.9997f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.1108f,0.2884f,0.0889f,0.9469f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.0101f,-0.9428f,0.1417f,0.3016f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.0812f,0.0011f,0.013f,0.9966f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.013f,0.9966f,0.0812f,0.0011f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.3315f,0.8731f,0.1282f],left_rotation:[0.182f,-0.0857f,0.3773f,0.904f]}}
particle minecraft:campfire_cosy_smoke -4.37 65.12 -16.32 0.021 0.022 0.022 1 0 force
particle minecraft:cloud -4.37 65.32 -16.32 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud -4.43 65.32 -17.99 0.35 0.18 0.35 0.02 3 force
tp 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 0.817 65 -23.588 68.1 0
tp f74f363c-8714-5fe5-bb64-beafe6b6ac28 0.817 65 -23.588 68.1 0
tp 97428e5f-5a51-575c-8305-607c4b0f68cb 0.817 65 -23.588 68.1 0
tp 186c432f-da2b-5bec-ba8a-9d97f056504e 0.817 65 -23.588 68.1 0
tp b7fef3cd-3066-54f8-9318-2747261e9dd9 0.817 65 -23.588 68.1 0
tp 0d17ad00-82d8-5739-af58-9e93f268e98c 0.817 65 -23.588 68.1 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0059f,0.0001f,-0.0112f,0.9999f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.8284f,0.1596f,-0.1557f,0.5138f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.2105f,-0.533f,-0.8162f,0.0734f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.0812f,0.0011f,0.013f,0.9966f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.013f,0.9966f,0.0812f,0.0011f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.3506f,0.8709f,0.2399f],left_rotation:[0.0703f,-0.1712f,0.9004f,0.3937f]}}
particle minecraft:campfire_cosy_smoke 4.05 65.12 -27.09 0.048 0.022 -0.017 1 0 force
particle minecraft:cloud 4.05 65.32 -27.09 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud 3.11 65.32 -28.52 0.35 0.18 0.35 0.02 3 force
