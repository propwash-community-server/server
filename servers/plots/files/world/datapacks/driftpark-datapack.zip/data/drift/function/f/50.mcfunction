tp 425483f9-2934-53dd-805b-82336df4bdbc 14.272 65 63.378 -96.93 0
tp 77d4edec-4f89-5806-8a73-69da291cf64a 14.272 65 63.378 -96.93 0
tp a18c987f-26df-590a-b51c-8f6379e10218 14.272 65 63.378 -96.93 0
tp 8bd36e4e-1a75-51ba-b224-63055ff644c2 14.272 65 63.378 -96.93 0
tp 7b07c259-0b81-5b46-b286-5b101f183bf9 14.272 65 63.378 -96.93 0
tp 04fc5281-333c-5c0d-ba69-0b625cbc7206 14.272 65 63.378 -96.93 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0f,0f,0.0047f,1f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.597f,-0.0469f,0.0303f,0.8003f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.0536f,-0.8015f,0.5953f,0.0156f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.6008f,-0.0079f,0.0105f,0.7993f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.0105f,-0.7993f,0.6008f,0.0079f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.3781f,0.8565f,0.11f],left_rotation:[0.188f,-0.0325f,0.1763f,0.9657f]}}
tp 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 -3.918 65 63.799 -90.53 0
tp f74f363c-8714-5fe5-bb64-beafe6b6ac28 -3.918 65 63.799 -90.53 0
tp 97428e5f-5a51-575c-8305-607c4b0f68cb -3.918 65 63.799 -90.53 0
tp 186c432f-da2b-5bec-ba8a-9d97f056504e -3.918 65 63.799 -90.53 0
tp b7fef3cd-3066-54f8-9318-2747261e9dd9 -3.918 65 63.799 -90.53 0
tp 0d17ad00-82d8-5739-af58-9e93f268e98c -3.918 65 63.799 -90.53 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0f,0f,-0.0029f,1f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.3666f,-0.0151f,0.0503f,0.9289f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.0471f,-0.9287f,0.367f,0.0233f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.6008f,-0.0079f,0.0105f,0.7993f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.0105f,-0.7993f,0.6008f,0.0079f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.365f,0.8621f,0.25f],left_rotation:[0.1907f,0.0071f,-0.042f,0.9807f]}}
