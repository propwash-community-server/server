tp 425483f9-2934-53dd-805b-82336df4bdbc 9.056 65 -38.907 9.93 0
tp 77d4edec-4f89-5806-8a73-69da291cf64a 9.056 65 -38.907 9.93 0
tp a18c987f-26df-590a-b51c-8f6379e10218 9.056 65 -38.907 9.93 0
tp 8bd36e4e-1a75-51ba-b224-63055ff644c2 9.056 65 -38.907 9.93 0
tp 7b07c259-0b81-5b46-b286-5b101f183bf9 9.056 65 -38.907 9.93 0
tp 04fc5281-333c-5c0d-ba69-0b625cbc7206 9.056 65 -38.907 9.93 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0057f,-0.0001f,0.021f,0.9998f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.6239f,-0.1275f,0.1756f,0.7508f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.0976f,0.7365f,0.6407f,0.1938f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.3523f,-0.0046f,0.0123f,0.9358f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.0123f,-0.9358f,0.3523f,0.0046f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4058f,0.8449f,0.1002f],left_rotation:[0.0588f,0.1756f,-0.9179f,0.351f]}}
particle minecraft:campfire_cosy_smoke 12.1 65.12 -42.16 0.061 0.022 -0.018 1 0 force
particle minecraft:cloud 12.1 65.32 -42.16 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud 10.46 65.32 -42.48 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 10.46 65.42 -42.48 0.45 0.2 0.45 0.008 1 force
tp 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 16.269 65 -46.408 18.1 0
tp f74f363c-8714-5fe5-bb64-beafe6b6ac28 16.269 65 -46.408 18.1 0
tp 97428e5f-5a51-575c-8305-607c4b0f68cb 16.269 65 -46.408 18.1 0
tp 186c432f-da2b-5bec-ba8a-9d97f056504e 16.269 65 -46.408 18.1 0
tp b7fef3cd-3066-54f8-9318-2747261e9dd9 16.269 65 -46.408 18.1 0
tp 0d17ad00-82d8-5739-af58-9e93f268e98c 16.269 65 -46.408 18.1 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0.0062f,0.0001f,0.0223f,0.9997f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.7601f,-0.1318f,0.2631f,0.5793f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.2037f,0.5549f,0.7781f,0.2124f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.3523f,-0.0046f,0.0123f,0.9358f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.0123f,-0.9358f,0.3523f,0.0046f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4078f,0.8395f,0.2606f],left_rotation:[0.1716f,0.0965f,-0.4422f,0.875f]}}
particle minecraft:campfire_cosy_smoke 20.76 65.12 -48.72 0.072 0.022 -0.006 1 0 force
particle minecraft:cloud 20.76 65.32 -48.72 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud 19.22 65.32 -49.47 0.35 0.18 0.35 0.02 3 force
particle minecraft:flame 20.31 65.24 -50.16 0.05 0.04 0.05 0.02 6 force
particle minecraft:large_smoke 20.31 65.24 -50.16 0.05 0.04 0.05 0.01 2 force
particle minecraft:flame 20.63 65.24 -50 0.05 0.04 0.05 0.02 6 force
particle minecraft:large_smoke 20.63 65.24 -50 0.05 0.04 0.05 0.01 2 force
