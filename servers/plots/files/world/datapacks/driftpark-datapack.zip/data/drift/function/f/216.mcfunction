tp 425483f9-2934-53dd-805b-82336df4bdbc 40.016 65 -49.91 67.45 0
tp 77d4edec-4f89-5806-8a73-69da291cf64a 40.016 65 -49.91 67.45 0
tp a18c987f-26df-590a-b51c-8f6379e10218 40.016 65 -49.91 67.45 0
tp 8bd36e4e-1a75-51ba-b224-63055ff644c2 40.016 65 -49.91 67.45 0
tp 7b07c259-0b81-5b46-b286-5b101f183bf9 40.016 65 -49.91 67.45 0
tp 04fc5281-333c-5c0d-ba69-0b625cbc7206 40.016 65 -49.91 67.45 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0.0069f,0.0002f,0.0223f,0.9997f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.4795f,-0.2103f,-0.0572f,0.85f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.1468f,0.8607f,-0.46f,0.1611f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.4991f,-0.0065f,0.0113f,0.8664f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.0113f,-0.8664f,0.4991f,0.0065f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4078f,0.8411f,0.1219f],left_rotation:[0.0642f,0.1868f,-0.9119f,0.3596f]}}
particle minecraft:cloud 45.44 65.32 -48.68 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 45.44 65.42 -48.68 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke 44.96 65.12 -50.28 0.047 0.022 -0.038 1 0 force
particle minecraft:cloud 44.96 65.32 -50.28 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 44.96 65.42 -50.28 0.45 0.2 0.45 0.008 1 force
tp 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 54.484 65 -46.458 85.06 0
tp f74f363c-8714-5fe5-bb64-beafe6b6ac28 54.484 65 -46.458 85.06 0
tp 97428e5f-5a51-575c-8305-607c4b0f68cb 54.484 65 -46.458 85.06 0
tp 186c432f-da2b-5bec-ba8a-9d97f056504e 54.484 65 -46.458 85.06 0
tp b7fef3cd-3066-54f8-9318-2747261e9dd9 54.484 65 -46.458 85.06 0
tp 0d17ad00-82d8-5739-af58-9e93f268e98c 54.484 65 -46.458 85.06 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0.0055f,0.0001f,0.0221f,0.9997f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.572f,-0.1383f,0.1661f,0.7913f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.0838f,0.7782f,0.5897f,0.1992f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.4991f,-0.0065f,0.0113f,0.8664f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.0113f,-0.8664f,0.4991f,0.0065f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4074f,0.8401f,0.2594f],left_rotation:[0.0605f,0.1866f,-0.9185f,0.3434f]}}
particle minecraft:cloud 60.4 65.32 -43.33 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 60.4 65.42 -43.33 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke 60.4 65.12 -45.04 0.052 0.022 -0.003 1 0 force
particle minecraft:cloud 60.4 65.32 -45.04 0.35 0.18 0.35 0.02 3 force
particle minecraft:flame 61.5 65.24 -44.36 0.05 0.04 0.05 0.02 6 force
particle minecraft:large_smoke 61.5 65.24 -44.36 0.05 0.04 0.05 0.01 2 force
particle minecraft:flame 61.5 65.24 -44 0.05 0.04 0.05 0.02 6 force
particle minecraft:large_smoke 61.5 65.24 -44 0.05 0.04 0.05 0.01 2 force
