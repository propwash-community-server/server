tp 425483f9-2934-53dd-805b-82336df4bdbc 55.386 65 -45.39 89.59 0
tp 77d4edec-4f89-5806-8a73-69da291cf64a 55.386 65 -45.39 89.59 0
tp a18c987f-26df-590a-b51c-8f6379e10218 55.386 65 -45.39 89.59 0
tp 8bd36e4e-1a75-51ba-b224-63055ff644c2 55.386 65 -45.39 89.59 0
tp 7b07c259-0b81-5b46-b286-5b101f183bf9 55.386 65 -45.39 89.59 0
tp 04fc5281-333c-5c0d-ba69-0b625cbc7206 55.386 65 -45.39 89.59 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0.0021f,0f,0.0221f,0.9998f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.9358f,-0.1056f,-0.156f,0.2981f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.1882f,0.3161f,-0.9298f,0.0078f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.9555f,-0.0125f,0.0039f,0.2946f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.2946f,0.9555f,0.0125f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4076f,0.8424f,0.1136f],left_rotation:[0.0095f,0.1926f,-0.9769f,0.0916f]}}
particle minecraft:campfire_cosy_smoke 61.06 65.12 -42.12 0.051 0.02 0.078 1 0 force
particle minecraft:cloud 61.06 65.32 -42.12 0.35 0.18 0.35 0.02 2 force
particle minecraft:cloud 61.19 65.32 -43.79 0.35 0.18 0.35 0.02 2 force
tp 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 70.376 65 -37.159 101.07 0
tp f74f363c-8714-5fe5-bb64-beafe6b6ac28 70.376 65 -37.159 101.07 0
tp 97428e5f-5a51-575c-8305-607c4b0f68cb 70.376 65 -37.159 101.07 0
tp 186c432f-da2b-5bec-ba8a-9d97f056504e 70.376 65 -37.159 101.07 0
tp b7fef3cd-3066-54f8-9318-2747261e9dd9 70.376 65 -37.159 101.07 0
tp 0d17ad00-82d8-5739-af58-9e93f268e98c 70.376 65 -37.159 101.07 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0055f,-0.0001f,0.0223f,0.9997f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.1975f,-0.2127f,0.0107f,0.9569f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.0898f,0.961f,-0.1762f,0.1931f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.9555f,-0.0125f,0.0039f,0.2946f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.2946f,0.9555f,0.0125f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.408f,0.8454f,0.2404f],left_rotation:[0.0518f,0.178f,-0.9304f,0.3163f]}}
particle minecraft:campfire_cosy_smoke 74.88 65.12 -33 0.022 0.022 0.07 1 0 force
particle minecraft:cloud 74.88 65.32 -33 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 74.88 65.42 -33 0.45 0.2 0.45 0.008 1 force
particle minecraft:cloud 75.32 65.32 -34.65 0.35 0.18 0.35 0.02 3 force
