tp 425483f9-2934-53dd-805b-82336df4bdbc -76.256 65 -46.239 45.41 0
tp 77d4edec-4f89-5806-8a73-69da291cf64a -76.256 65 -46.239 45.41 0
tp a18c987f-26df-590a-b51c-8f6379e10218 -76.256 65 -46.239 45.41 0
tp 8bd36e4e-1a75-51ba-b224-63055ff644c2 -76.256 65 -46.239 45.41 0
tp 7b07c259-0b81-5b46-b286-5b101f183bf9 -76.256 65 -46.239 45.41 0
tp 04fc5281-333c-5c0d-ba69-0b625cbc7206 -76.256 65 -46.239 45.41 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0.0046f,0.0001f,0.0223f,0.9997f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.4223f,-0.2752f,-0.0743f,0.8605f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.1652f,0.873f,-0.3957f,0.2324f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.7687f,0.0101f,0.0084f,0.6395f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.0084f,0.6395f,0.7687f,0.0101f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4078f,0.8416f,0.1179f],left_rotation:[0.1612f,0.1103f,-0.5173f,0.8332f]}}
particle minecraft:campfire_cosy_smoke -71.74 65.12 -46.26 0.057 0.022 0.025 1 0 force
particle minecraft:cloud -71.74 65.32 -46.26 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud -72.75 65.32 -47.59 0.35 0.18 0.35 0.02 3 force
particle minecraft:flame -71.69 65.22 -47.97 0.05 0.04 0.05 0.02 6 force
particle minecraft:large_smoke -71.69 65.22 -47.97 0.05 0.04 0.05 0.01 2 force
tp 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 -65.475 65 -45.669 67.29 0
tp f74f363c-8714-5fe5-bb64-beafe6b6ac28 -65.475 65 -45.669 67.29 0
tp 97428e5f-5a51-575c-8305-607c4b0f68cb -65.475 65 -45.669 67.29 0
tp 186c432f-da2b-5bec-ba8a-9d97f056504e -65.475 65 -45.669 67.29 0
tp b7fef3cd-3066-54f8-9318-2747261e9dd9 -65.475 65 -45.669 67.29 0
tp 0d17ad00-82d8-5739-af58-9e93f268e98c -65.475 65 -45.669 67.29 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0.0001f,0f,0.0223f,0.9998f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.8956f,-0.1527f,-0.2553f,0.3308f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.2915f,0.3594f,-0.8845f,0.0594f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.7687f,0.0101f,0.0084f,0.6395f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.0084f,0.6395f,0.7687f,0.0101f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4079f,0.8426f,0.2502f],left_rotation:[0.1692f,0.0884f,-0.4152f,0.8894f]}}
particle minecraft:campfire_cosy_smoke -61.09 65.12 -44 0.046 0.022 0.047 1 0 force
particle minecraft:cloud -61.09 65.32 -44 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -61.09 65.42 -44 0.45 0.2 0.45 0.008 1 force
particle minecraft:cloud -61.59 65.32 -45.63 0.35 0.18 0.35 0.02 3 force
