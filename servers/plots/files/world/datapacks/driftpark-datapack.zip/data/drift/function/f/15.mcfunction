tp 425483f9-2934-53dd-805b-82336df4bdbc -31.207 65 64.54 -93.7 0
tp 77d4edec-4f89-5806-8a73-69da291cf64a -31.207 65 64.54 -93.7 0
tp a18c987f-26df-590a-b51c-8f6379e10218 -31.207 65 64.54 -93.7 0
tp 8bd36e4e-1a75-51ba-b224-63055ff644c2 -31.207 65 64.54 -93.7 0
tp 7b07c259-0b81-5b46-b286-5b101f183bf9 -31.207 65 64.54 -93.7 0
tp 04fc5281-333c-5c0d-ba69-0b625cbc7206 -31.207 65 64.54 -93.7 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0059f,-0.0001f,0.0131f,0.9999f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.6778f,-0.0061f,0.0771f,0.7312f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.0007f,0.7271f,0.6822f,0.0774f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.6809f,0.0089f,0.0096f,0.7322f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.0096f,0.7322f,0.6809f,0.0089f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.3925f,0.8512f,0.0999f],left_rotation:[0.1623f,-0.0889f,0.4948f,0.8491f]}}
tp 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 -47.917 65 63.637 -102.91 0
tp f74f363c-8714-5fe5-bb64-beafe6b6ac28 -47.917 65 63.637 -102.91 0
tp 97428e5f-5a51-575c-8305-607c4b0f68cb -47.917 65 63.637 -102.91 0
tp 186c432f-da2b-5bec-ba8a-9d97f056504e -47.917 65 63.637 -102.91 0
tp b7fef3cd-3066-54f8-9318-2747261e9dd9 -47.917 65 63.637 -102.91 0
tp 0d17ad00-82d8-5739-af58-9e93f268e98c -47.917 65 63.637 -102.91 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0058f,-0.0001f,0.018f,0.9998f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.7169f,-0.0888f,0.1732f,0.6694f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.1038f,0.6549f,0.7302f,0.1647f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.6809f,0.0089f,0.0096f,0.7322f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.0096f,0.7322f,0.6809f,0.0089f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4009f,0.8489f,0.2399f],left_rotation:[0.021f,0.1839f,-0.9718f,0.1464f]}}
particle minecraft:campfire_cosy_smoke -53.72 65.12 62.09 -0.065 0.021 -0.046 1 0 force
particle minecraft:cloud -53.72 65.32 62.09 0.35 0.18 0.35 0.02 2 force
particle minecraft:cloud -53.38 65.32 63.77 0.35 0.18 0.35 0.02 2 force
