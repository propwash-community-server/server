tp 425483f9-2934-53dd-805b-82336df4bdbc -92.81 65 -34.212 -5.31 0
tp 77d4edec-4f89-5806-8a73-69da291cf64a -92.81 65 -34.212 -5.31 0
tp a18c987f-26df-590a-b51c-8f6379e10218 -92.81 65 -34.212 -5.31 0
tp 8bd36e4e-1a75-51ba-b224-63055ff644c2 -92.81 65 -34.212 -5.31 0
tp 7b07c259-0b81-5b46-b286-5b101f183bf9 -92.81 65 -34.212 -5.31 0
tp 04fc5281-333c-5c0d-ba69-0b625cbc7206 -92.81 65 -34.212 -5.31 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0059f,-0.0001f,0.0198f,0.9998f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.8837f,-0.0469f,0.2319f,0.4039f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.1907f,0.3818f,0.8935f,0.14f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.0116f,0.0002f,0.0131f,0.9998f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.0131f,0.9998f,0.0116f,0.0002f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4038f,0.8459f,0.0998f],left_rotation:[0.0904f,0.1614f,-0.8377f,0.5139f]}}
particle minecraft:cloud -90.55 65.32 -38.07 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -92.22 65.12 -37.99 -0.019 0.022 -0.035 1 0 force
particle minecraft:cloud -92.22 65.32 -37.99 0.35 0.18 0.35 0.02 3 force
tp 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 -87.675 65 -42.701 3.92 0
tp f74f363c-8714-5fe5-bb64-beafe6b6ac28 -87.675 65 -42.701 3.92 0
tp 97428e5f-5a51-575c-8305-607c4b0f68cb -87.675 65 -42.701 3.92 0
tp 186c432f-da2b-5bec-ba8a-9d97f056504e -87.675 65 -42.701 3.92 0
tp b7fef3cd-3066-54f8-9318-2747261e9dd9 -87.675 65 -42.701 3.92 0
tp 0d17ad00-82d8-5739-af58-9e93f268e98c -87.675 65 -42.701 3.92 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.004f,-0.0001f,0.0223f,0.9997f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.8037f,-0.206f,-0.221f,0.5127f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.2761f,0.5387f,-0.7864f,0.1227f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.0116f,0.0002f,0.0131f,0.9998f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.0131f,0.9998f,0.0116f,0.0002f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.408f,0.8446f,0.2432f],left_rotation:[0.1694f,0.079f,-0.3753f,0.9079f]}}
particle minecraft:cloud -84.53 65.32 -45.32 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -86.22 65.12 -45.63 -0.018 0.022 -0.026 1 0 force
particle minecraft:cloud -86.22 65.32 -45.63 0.35 0.18 0.35 0.02 3 force
