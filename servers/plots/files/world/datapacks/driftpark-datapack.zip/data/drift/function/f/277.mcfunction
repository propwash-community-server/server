tp 425483f9-2934-53dd-805b-82336df4bdbc 0.106 65 -24.031 64.21 0
tp 77d4edec-4f89-5806-8a73-69da291cf64a 0.106 65 -24.031 64.21 0
tp a18c987f-26df-590a-b51c-8f6379e10218 0.106 65 -24.031 64.21 0
tp 8bd36e4e-1a75-51ba-b224-63055ff644c2 0.106 65 -24.031 64.21 0
tp 7b07c259-0b81-5b46-b286-5b101f183bf9 0.106 65 -24.031 64.21 0
tp 04fc5281-333c-5c0d-ba69-0b625cbc7206 0.106 65 -24.031 64.21 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0059f,0.0001f,-0.0112f,0.9999f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.5352f,0.1878f,-0.0587f,0.8215f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.1454f,-0.8322f,-0.5184f,0.1326f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.5962f,0.0078f,0.0105f,0.8028f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.0105f,0.8028f,0.5962f,0.0078f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.3507f,0.8693f,0.0999f],left_rotation:[0.0259f,-0.1832f,0.9697f,0.1592f]}}
particle minecraft:campfire_cosy_smoke 3.57 65.12 -27.36 0.047 0.021 -0.017 1 0 force
particle minecraft:cloud 3.57 65.32 -27.36 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke 3.57 65.42 -27.36 0.45 0.2 0.45 0.008 1 force
particle minecraft:cloud 2.57 65.32 -28.7 0.35 0.18 0.35 0.02 2 force
tp 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 5.618 65 -35.405 18.75 0
tp f74f363c-8714-5fe5-bb64-beafe6b6ac28 5.618 65 -35.405 18.75 0
tp 97428e5f-5a51-575c-8305-607c4b0f68cb 5.618 65 -35.405 18.75 0
tp 186c432f-da2b-5bec-ba8a-9d97f056504e 5.618 65 -35.405 18.75 0
tp b7fef3cd-3066-54f8-9318-2747261e9dd9 5.618 65 -35.405 18.75 0
tp 0d17ad00-82d8-5739-af58-9e93f268e98c 5.618 65 -35.405 18.75 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0058f,-0.0001f,0.0148f,0.9999f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.9403f,-0.0949f,-0.1218f,0.3032f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.1544f,-0.3177f,0.9355f,0.0034f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.5962f,0.0078f,0.0105f,0.8028f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.0105f,0.8028f,0.5962f,0.0078f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.3954f,0.8515f,0.2399f],left_rotation:[0.0494f,-0.1784f,0.9545f,0.2339f]}}
particle minecraft:campfire_cosy_smoke 8.56 65.12 -39.29 0.064 0.019 -0.032 1 0 force
particle minecraft:cloud 8.56 65.32 -39.29 0.35 0.18 0.35 0.02 2 force
particle minecraft:cloud 6.88 65.32 -39.61 0.35 0.18 0.35 0.02 2 force
