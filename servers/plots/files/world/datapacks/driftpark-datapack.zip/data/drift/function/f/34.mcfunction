tp 425483f9-2934-53dd-805b-82336df4bdbc -6.517 65 63.887 -90.72 0
tp 77d4edec-4f89-5806-8a73-69da291cf64a -6.517 65 63.887 -90.72 0
tp a18c987f-26df-590a-b51c-8f6379e10218 -6.517 65 63.887 -90.72 0
tp 8bd36e4e-1a75-51ba-b224-63055ff644c2 -6.517 65 63.887 -90.72 0
tp 7b07c259-0b81-5b46-b286-5b101f183bf9 -6.517 65 63.887 -90.72 0
tp 04fc5281-333c-5c0d-ba69-0b625cbc7206 -6.517 65 63.887 -90.72 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0f,0f,-0.0028f,1f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.4297f,0.0266f,0.0453f,0.9015f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.0492f,0.9017f,0.4292f,0.0184f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.4271f,0.0056f,0.0118f,0.9041f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.0118f,0.9041f,0.4271f,0.0056f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.3651f,0.8621f,0.11f],left_rotation:[0.1907f,0.0073f,-0.043f,0.9807f]}}
tp 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 -24.747 65 64.686 -91.34 0
tp f74f363c-8714-5fe5-bb64-beafe6b6ac28 -24.747 65 64.686 -91.34 0
tp 97428e5f-5a51-575c-8305-607c4b0f68cb -24.747 65 64.686 -91.34 0
tp 186c432f-da2b-5bec-ba8a-9d97f056504e -24.747 65 64.686 -91.34 0
tp b7fef3cd-3066-54f8-9318-2747261e9dd9 -24.747 65 64.686 -91.34 0
tp 0d17ad00-82d8-5739-af58-9e93f268e98c -24.747 65 64.686 -91.34 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0046f,0f,0.0096f,0.9999f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.5825f,0.0152f,0.0535f,0.8109f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.0314f,0.8098f,0.5841f,0.0459f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.4271f,0.0056f,0.0118f,0.9041f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.0118f,0.9041f,0.4271f,0.0056f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.3865f,0.855f,0.2421f],left_rotation:[0.1839f,-0.0298f,0.1759f,0.9666f]}}
