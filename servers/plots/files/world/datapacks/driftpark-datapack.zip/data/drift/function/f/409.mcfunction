tp 425483f9-2934-53dd-805b-82336df4bdbc -84.74 65 -43.731 17.21 0
tp 77d4edec-4f89-5806-8a73-69da291cf64a -84.74 65 -43.731 17.21 0
tp a18c987f-26df-590a-b51c-8f6379e10218 -84.74 65 -43.731 17.21 0
tp 8bd36e4e-1a75-51ba-b224-63055ff644c2 -84.74 65 -43.731 17.21 0
tp 7b07c259-0b81-5b46-b286-5b101f183bf9 -84.74 65 -43.731 17.21 0
tp 04fc5281-333c-5c0d-ba69-0b625cbc7206 -84.74 65 -43.731 17.21 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0.0041f,0.0001f,0.0223f,0.9997f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.9458f,0.005f,0.2747f,0.1731f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.258f,0.1452f,0.9505f,0.0944f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.314f,0.0041f,0.0124f,0.9493f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.0124f,0.9493f,0.314f,0.0041f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4079f,0.8418f,0.1171f],left_rotation:[0.1491f,0.1255f,-0.5975f,0.7778f]}}
particle minecraft:campfire_cosy_smoke -81.24 65.12 -45.51 0.058 0.022 -0.001 1 0 force
particle minecraft:cloud -81.24 65.32 -45.51 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud -82.75 65.32 -46.22 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -82.75 65.42 -46.22 0.45 0.2 0.45 0.008 1 force
playsound driftpark:lap.kaze.07.119 neutral @a -82.56 65.5 -44.68 12 1
playsound driftpark:lap.kaze.07.120 neutral @a -86.59 65.5 -42.27 12 1
playsound driftpark:lap.kaze.07.121 neutral @a -90.14 65.5 -38.49 12 1
playsound driftpark:lap.kaze.07.122 neutral @a -93.07 65.5 -33.4 12 1
playsound driftpark:lap.kaze.07.123 neutral @a -95.25 65.5 -27.24 12 1
playsound driftpark:lap.kaze.07.124 neutral @a -96.59 65.5 -20.15 12 1
playsound driftpark:lap.kaze.07.125 neutral @a -96.9 65.5 -12.27 12 1
playsound driftpark:lap.kaze.07.126 neutral @a -96.06 65.5 -3.75 12 1
playsound driftpark:lap.kaze.07.127 neutral @a -94.18 65.5 5.29 12 1
tp 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 -76.307 65 -47.142 40.93 0
tp f74f363c-8714-5fe5-bb64-beafe6b6ac28 -76.307 65 -47.142 40.93 0
tp 97428e5f-5a51-575c-8305-607c4b0f68cb -76.307 65 -47.142 40.93 0
tp 186c432f-da2b-5bec-ba8a-9d97f056504e -76.307 65 -47.142 40.93 0
tp b7fef3cd-3066-54f8-9318-2747261e9dd9 -76.307 65 -47.142 40.93 0
tp 0d17ad00-82d8-5739-af58-9e93f268e98c -76.307 65 -47.142 40.93 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0.0046f,0.0001f,0.0223f,0.9997f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.7043f,-0.2491f,-0.1937f,0.6359f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.2616f,0.6598f,-0.682f,0.1765f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.314f,0.0041f,0.0124f,0.9493f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.0124f,0.9493f,0.314f,0.0041f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4078f,0.8404f,0.2579f],left_rotation:[0.1861f,0.0591f,-0.2548f,0.9471f]}}
particle minecraft:campfire_cosy_smoke -71.62 65.12 -47.33 0.063 0.022 0.039 1 0 force
particle minecraft:cloud -71.62 65.32 -47.33 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud -72.75 65.32 -48.61 0.35 0.18 0.35 0.02 3 force
particle minecraft:flame -71.48 65.24 -48.83 0.05 0.04 0.05 0.02 5 force
particle minecraft:large_smoke -71.48 65.24 -48.83 0.05 0.04 0.05 0.01 2 force
particle minecraft:flame -71.25 65.24 -48.56 0.05 0.04 0.05 0.02 5 force
particle minecraft:large_smoke -71.25 65.24 -48.56 0.05 0.04 0.05 0.01 2 force
