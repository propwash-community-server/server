tp 425483f9-2934-53dd-805b-82336df4bdbc 26.317 65 -49.287 45.57 0
tp 77d4edec-4f89-5806-8a73-69da291cf64a 26.317 65 -49.287 45.57 0
tp a18c987f-26df-590a-b51c-8f6379e10218 26.317 65 -49.287 45.57 0
tp 8bd36e4e-1a75-51ba-b224-63055ff644c2 26.317 65 -49.287 45.57 0
tp 7b07c259-0b81-5b46-b286-5b101f183bf9 26.317 65 -49.287 45.57 0
tp 04fc5281-333c-5c0d-ba69-0b625cbc7206 26.317 65 -49.287 45.57 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0.0005f,0f,0.0223f,0.9998f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.2277f,-0.2056f,0.1047f,0.946f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.0059f,0.9402f,0.2506f,0.2306f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.2245f,0.0029f,0.0128f,0.9744f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.0128f,0.9744f,0.2245f,0.0029f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4079f,0.8426f,0.1108f],left_rotation:[0.0836f,0.172f,-0.8628f,0.468f]}}
particle minecraft:campfire_cosy_smoke 31.46 65.12 -49.95 0.061 0.022 0.024 1 0 force
particle minecraft:cloud 31.46 65.32 -49.95 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud 30.43 65.32 -51.26 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 30.43 65.42 -51.26 0.45 0.2 0.45 0.008 1 force
tp 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 39.16 65 -50.915 62.13 0
tp f74f363c-8714-5fe5-bb64-beafe6b6ac28 39.16 65 -50.915 62.13 0
tp 97428e5f-5a51-575c-8305-607c4b0f68cb 39.16 65 -50.915 62.13 0
tp 186c432f-da2b-5bec-ba8a-9d97f056504e 39.16 65 -50.915 62.13 0
tp b7fef3cd-3066-54f8-9318-2747261e9dd9 39.16 65 -50.915 62.13 0
tp 0d17ad00-82d8-5739-af58-9e93f268e98c 39.16 65 -50.915 62.13 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0.0065f,0.0001f,0.0223f,0.9997f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.9625f,0.0255f,0.2453f,0.1131f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.2348f,0.0879f,0.9651f,0.0755f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.2245f,0.0029f,0.0128f,0.9744f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.0128f,0.9744f,0.2245f,0.0029f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4077f,0.8394f,0.2611f],left_rotation:[0.112f,0.1623f,-0.7813f,0.5921f]}}
particle minecraft:campfire_cosy_smoke 44.77 65.12 -49.92 0.064 0.022 0.055 1 0 force
particle minecraft:cloud 44.77 65.32 -49.92 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 44.77 65.42 -49.92 0.45 0.2 0.45 0.008 1 force
particle minecraft:cloud 44.13 65.32 -51.51 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 44.13 65.42 -51.51 0.45 0.2 0.45 0.008 1 force
