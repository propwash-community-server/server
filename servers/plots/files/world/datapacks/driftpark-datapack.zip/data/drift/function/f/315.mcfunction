tp 425483f9-2934-53dd-805b-82336df4bdbc -23.127 65 -11.127 134.93 0
tp 77d4edec-4f89-5806-8a73-69da291cf64a -23.127 65 -11.127 134.93 0
tp a18c987f-26df-590a-b51c-8f6379e10218 -23.127 65 -11.127 134.93 0
tp 8bd36e4e-1a75-51ba-b224-63055ff644c2 -23.127 65 -11.127 134.93 0
tp 7b07c259-0b81-5b46-b286-5b101f183bf9 -23.127 65 -11.127 134.93 0
tp 04fc5281-333c-5c0d-ba69-0b625cbc7206 -23.127 65 -11.127 134.93 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0045f,0.0001f,-0.0223f,0.9997f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.3848f,0.2218f,0.156f,0.8823f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.0641f,-0.8707f,0.4102f,0.2635f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.0232f,0.0003f,0.0131f,0.9996f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.0131f,0.9996f,0.0232f,0.0003f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.3313f,0.8766f,0.1023f],left_rotation:[0.1385f,-0.1247f,0.6242f,0.7587f]}}
particle minecraft:campfire_cosy_smoke -19.82 65.12 -9.6 0.017 0.022 0.03 1 0 force
particle minecraft:cloud -19.82 65.32 -9.6 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud -18.76 65.32 -10.89 0.35 0.18 0.35 0.02 3 force
tp 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 -13.556 65 -11.053 119.16 0
tp f74f363c-8714-5fe5-bb64-beafe6b6ac28 -13.556 65 -11.053 119.16 0
tp 97428e5f-5a51-575c-8305-607c4b0f68cb -13.556 65 -11.053 119.16 0
tp 186c432f-da2b-5bec-ba8a-9d97f056504e -13.556 65 -11.053 119.16 0
tp b7fef3cd-3066-54f8-9318-2747261e9dd9 -13.556 65 -11.053 119.16 0
tp 0d17ad00-82d8-5739-af58-9e93f268e98c -13.556 65 -11.053 119.16 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0.0049f,-0.0001f,-0.0223f,0.9997f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.9456f,-0.0352f,0.3179f,0.0597f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.3134f,-0.0267f,0.9471f,0.064f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.0232f,0.0003f,0.0131f,0.9996f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.0131f,0.9996f,0.0232f,0.0003f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.3315f,0.8731f,0.2584f],left_rotation:[0.1887f,-0.0515f,0.2159f,0.9566f]}}
particle minecraft:campfire_cosy_smoke -10.11 65.12 -10.89 0.024 0.022 0.018 1 0 force
particle minecraft:cloud -10.11 65.32 -10.89 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud -9.49 65.32 -12.48 0.35 0.18 0.35 0.02 3 force
