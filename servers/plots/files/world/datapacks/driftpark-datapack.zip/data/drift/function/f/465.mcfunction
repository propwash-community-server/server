tp 425483f9-2934-53dd-805b-82336df4bdbc -95.328 65 0.657 -23.66 0
tp 77d4edec-4f89-5806-8a73-69da291cf64a -95.328 65 0.657 -23.66 0
tp a18c987f-26df-590a-b51c-8f6379e10218 -95.328 65 0.657 -23.66 0
tp 8bd36e4e-1a75-51ba-b224-63055ff644c2 -95.328 65 0.657 -23.66 0
tp 7b07c259-0b81-5b46-b286-5b101f183bf9 -95.328 65 0.657 -23.66 0
tp 04fc5281-333c-5c0d-ba69-0b625cbc7206 -95.328 65 0.657 -23.66 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0059f,-0.0001f,0.0152f,0.9999f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.9553f,0.0211f,0.1188f,0.2701f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.091f,0.2591f,0.9583f,0.0791f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.9428f,0.0123f,0.0044f,0.3332f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.0044f,0.3332f,0.9428f,0.0123f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.3959f,0.8496f,0.0998f],left_rotation:[0.1049f,-0.1524f,0.8259f,0.5326f]}}
particle minecraft:campfire_cosy_smoke -95.85 65.12 -5.29 0.035 0.015 -0.069 1 0 force
tp 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 -97.842 65 -14.371 -27.59 0
tp f74f363c-8714-5fe5-bb64-beafe6b6ac28 -97.842 65 -14.371 -27.59 0
tp 97428e5f-5a51-575c-8305-607c4b0f68cb -97.842 65 -14.371 -27.59 0
tp 186c432f-da2b-5bec-ba8a-9d97f056504e -97.842 65 -14.371 -27.59 0
tp b7fef3cd-3066-54f8-9318-2747261e9dd9 -97.842 65 -14.371 -27.59 0
tp 0d17ad00-82d8-5739-af58-9e93f268e98c -97.842 65 -14.371 -27.59 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0058f,-0.0001f,0.0189f,0.9998f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.8165f,-0.0686f,0.2018f,0.5366f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.1465f,0.5184f,0.8282f,0.1548f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.9428f,0.0123f,0.0044f,0.3332f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.0044f,0.3332f,0.9428f,0.0123f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4023f,0.8483f,0.24f],left_rotation:[0.0528f,0.1774f,-0.9307f,0.3155f]}}
particle minecraft:campfire_cosy_smoke -97.43 65.12 -19.96 0.046 0.022 -0.069 1 0 force
particle minecraft:cloud -97.43 65.32 -19.96 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud -99 65.32 -19.26 0.35 0.18 0.35 0.02 3 force
