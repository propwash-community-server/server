tp 425483f9-2934-53dd-805b-82336df4bdbc -32.365 65 -14.048 153.83 0
tp 77d4edec-4f89-5806-8a73-69da291cf64a -32.365 65 -14.048 153.83 0
tp a18c987f-26df-590a-b51c-8f6379e10218 -32.365 65 -14.048 153.83 0
tp 8bd36e4e-1a75-51ba-b224-63055ff644c2 -32.365 65 -14.048 153.83 0
tp 7b07c259-0b81-5b46-b286-5b101f183bf9 -32.365 65 -14.048 153.83 0
tp 04fc5281-333c-5c0d-ba69-0b625cbc7206 -32.365 65 -14.048 153.83 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0.0027f,-0.0001f,-0.0223f,0.9997f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.9508f,-0.0086f,0.2587f,0.1705f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.2422f,-0.1443f,0.9551f,0.0913f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.9637f,0.0126f,0.0035f,0.2667f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.0035f,0.2667f,0.9637f,0.0126f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.3314f,0.875f,0.1147f],left_rotation:[0.1276f,-0.1455f,0.7081f,0.6791f]}}
particle minecraft:cloud -29.67 65.32 -11.36 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -28.24 65.12 -12.22 0.066 0.022 -0.013 1 0 force
particle minecraft:cloud -28.24 65.32 -12.22 0.35 0.18 0.35 0.02 3 force
tp 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 -22.479 65 -10.149 137.87 0
tp f74f363c-8714-5fe5-bb64-beafe6b6ac28 -22.479 65 -10.149 137.87 0
tp 97428e5f-5a51-575c-8305-607c4b0f68cb -22.479 65 -10.149 137.87 0
tp 186c432f-da2b-5bec-ba8a-9d97f056504e -22.479 65 -10.149 137.87 0
tp b7fef3cd-3066-54f8-9318-2747261e9dd9 -22.479 65 -10.149 137.87 0
tp 0d17ad00-82d8-5739-af58-9e93f268e98c -22.479 65 -10.149 137.87 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0047f,0.0001f,-0.0223f,0.9997f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.9201f,0.0247f,0.3012f,0.2491f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.2766f,-0.2189f,0.9278f,0.1216f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.9637f,0.0126f,0.0035f,0.2667f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.0035f,0.2667f,0.9637f,0.0126f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.3313f,0.8779f,0.2419f],left_rotation:[0.1687f,-0.0787f,0.3753f,0.908f]}}
particle minecraft:cloud -19.11 65.32 -8.6 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -19.11 65.42 -8.6 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke -17.96 65.12 -9.86 0.061 0.022 -0.035 1 0 force
particle minecraft:cloud -17.96 65.32 -9.86 0.35 0.18 0.35 0.02 3 force
