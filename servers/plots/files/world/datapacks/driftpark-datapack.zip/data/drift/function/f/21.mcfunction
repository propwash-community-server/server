tp 425483f9-2934-53dd-805b-82336df4bdbc -23.431 65 64.48 -91.02 0
tp 77d4edec-4f89-5806-8a73-69da291cf64a -23.431 65 64.48 -91.02 0
tp a18c987f-26df-590a-b51c-8f6379e10218 -23.431 65 64.48 -91.02 0
tp 8bd36e4e-1a75-51ba-b224-63055ff644c2 -23.431 65 64.48 -91.02 0
tp 7b07c259-0b81-5b46-b286-5b101f183bf9 -23.431 65 64.48 -91.02 0
tp 04fc5281-333c-5c0d-ba69-0b625cbc7206 -23.431 65 64.48 -91.02 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0034f,0f,0.0088f,1f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.7401f,-0.0455f,0.0278f,0.6704f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.0426f,-0.6712f,0.7394f,0.0321f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.742f,-0.0097f,0.0088f,0.6702f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.0088f,-0.6702f,0.742f,0.0097f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.3851f,0.8541f,0.1042f],left_rotation:[0.1869f,-0.0152f,0.0969f,0.9775f]}}
tp 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 -41.022 65 64.502 -101.26 0
tp f74f363c-8714-5fe5-bb64-beafe6b6ac28 -41.022 65 64.502 -101.26 0
tp 97428e5f-5a51-575c-8305-607c4b0f68cb -41.022 65 64.502 -101.26 0
tp 186c432f-da2b-5bec-ba8a-9d97f056504e -41.022 65 64.502 -101.26 0
tp b7fef3cd-3066-54f8-9318-2747261e9dd9 -41.022 65 64.502 -101.26 0
tp 0d17ad00-82d8-5739-af58-9e93f268e98c -41.022 65 64.502 -101.26 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0059f,-0.0001f,0.0169f,0.9998f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.6594f,-0.1475f,-0.0613f,0.7346f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.1388f,0.7451f,-0.6475f,0.079f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.742f,-0.0097f,0.0088f,0.6702f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.0088f,-0.6702f,0.742f,0.0097f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.3989f,0.8499f,0.2399f],left_rotation:[0.0405f,-0.1806f,0.9657f,0.1824f]}}
particle minecraft:campfire_cosy_smoke -47.15 65.12 63.36 -0.066 0.018 -0.039 1 0 force
particle minecraft:cloud -47.15 65.32 63.36 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -47.15 65.42 63.36 0.45 0.2 0.45 0.008 1 force
particle minecraft:cloud -46.78 65.32 65.03 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -46.78 65.42 65.03 0.45 0.2 0.45 0.008 1 force
