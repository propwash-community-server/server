tp 425483f9-2934-53dd-805b-82336df4bdbc -93.138 65 -33.511 -5.78 0
tp 77d4edec-4f89-5806-8a73-69da291cf64a -93.138 65 -33.511 -5.78 0
tp a18c987f-26df-590a-b51c-8f6379e10218 -93.138 65 -33.511 -5.78 0
tp 8bd36e4e-1a75-51ba-b224-63055ff644c2 -93.138 65 -33.511 -5.78 0
tp 7b07c259-0b81-5b46-b286-5b101f183bf9 -93.138 65 -33.511 -5.78 0
tp 04fc5281-333c-5c0d-ba69-0b625cbc7206 -93.138 65 -33.511 -5.78 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0058f,-0.0001f,0.0194f,0.9998f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.744f,-0.1866f,-0.1382f,0.6265f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.2048f,0.6445f,-0.7285f,0.1095f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.9682f,0.0127f,0.0033f,0.2499f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.0033f,0.2499f,0.9682f,0.0127f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4032f,0.8462f,0.1f],left_rotation:[0.0838f,0.1651f,-0.8584f,0.4784f]}}
particle minecraft:campfire_cosy_smoke -90.94 65.12 -37.45 0.052 0.022 -0.032 1 0 force
particle minecraft:cloud -90.94 65.32 -37.45 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud -92.6 65.32 -37.35 0.35 0.18 0.35 0.02 3 force
tp 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 -88.175 65 -42.255 1.38 0
tp f74f363c-8714-5fe5-bb64-beafe6b6ac28 -88.175 65 -42.255 1.38 0
tp 97428e5f-5a51-575c-8305-607c4b0f68cb -88.175 65 -42.255 1.38 0
tp 186c432f-da2b-5bec-ba8a-9d97f056504e -88.175 65 -42.255 1.38 0
tp b7fef3cd-3066-54f8-9318-2747261e9dd9 -88.175 65 -42.255 1.38 0
tp 0d17ad00-82d8-5739-af58-9e93f268e98c -88.175 65 -42.255 1.38 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0046f,-0.0001f,0.0223f,0.9997f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.0981f,-0.3016f,0.0239f,0.9481f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.0756f,0.9508f,-0.067f,0.2929f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.9682f,0.0127f,0.0033f,0.2499f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.0033f,0.2499f,0.9682f,0.0127f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.408f,0.8449f,0.2421f],left_rotation:[0.1691f,0.0782f,-0.3722f,0.9093f]}}
particle minecraft:campfire_cosy_smoke -85.08 65.12 -45 0.057 0.022 -0.008 1 0 force
particle minecraft:cloud -85.08 65.32 -45 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud -86.77 65.32 -45.26 0.35 0.18 0.35 0.02 3 force
