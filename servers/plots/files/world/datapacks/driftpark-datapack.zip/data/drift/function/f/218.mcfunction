tp 425483f9-2934-53dd-805b-82336df4bdbc 38.122 65 -50.104 64.94 0
tp 77d4edec-4f89-5806-8a73-69da291cf64a 38.122 65 -50.104 64.94 0
tp a18c987f-26df-590a-b51c-8f6379e10218 38.122 65 -50.104 64.94 0
tp 8bd36e4e-1a75-51ba-b224-63055ff644c2 38.122 65 -50.104 64.94 0
tp 7b07c259-0b81-5b46-b286-5b101f183bf9 38.122 65 -50.104 64.94 0
tp 04fc5281-333c-5c0d-ba69-0b625cbc7206 38.122 65 -50.104 64.94 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0.006f,0.0001f,0.0223f,0.9997f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.8421f,-0.1542f,-0.1577f,0.4921f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.2103f,0.5114f,-0.8306f,0.0666f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.8679f,-0.0114f,0.0065f,0.4966f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.0065f,-0.4966f,0.8679f,0.0114f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4078f,0.8413f,0.1204f],left_rotation:[0.0686f,0.1844f,-0.9028f,0.3825f]}}
particle minecraft:cloud 43.5 65.32 -49.14 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 43.5 65.42 -49.14 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke 42.94 65.12 -50.71 0.041 0.022 -0.035 1 0 force
particle minecraft:cloud 42.94 65.32 -50.71 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 42.94 65.42 -50.71 0.45 0.2 0.45 0.008 1 force
tp 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 52.353 65 -47.46 82.02 0
tp f74f363c-8714-5fe5-bb64-beafe6b6ac28 52.353 65 -47.46 82.02 0
tp 97428e5f-5a51-575c-8305-607c4b0f68cb 52.353 65 -47.46 82.02 0
tp 186c432f-da2b-5bec-ba8a-9d97f056504e 52.353 65 -47.46 82.02 0
tp b7fef3cd-3066-54f8-9318-2747261e9dd9 52.353 65 -47.46 82.02 0
tp 0d17ad00-82d8-5739-af58-9e93f268e98c 52.353 65 -47.46 82.02 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0.0108f,0.0002f,0.022f,0.9997f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.1052f,-0.2061f,0.0762f,0.9699f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.0253f,0.9672f,0.1274f,0.2183f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.8679f,-0.0114f,0.0065f,0.4966f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.0065f,-0.4966f,0.8679f,0.0114f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4073f,0.8372f,0.2686f],left_rotation:[0.0688f,0.1893f,-0.905f,0.3746f]}}
particle minecraft:cloud 58.21 65.32 -44.52 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 58.21 65.42 -44.52 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke 58.13 65.12 -46.23 0.05 0.022 -0.018 1 0 force
particle minecraft:cloud 58.13 65.32 -46.23 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 58.13 65.42 -46.23 0.45 0.2 0.45 0.008 1 force
