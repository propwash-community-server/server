tp 425483f9-2934-53dd-805b-82336df4bdbc -97.018 65 -15.378 -23.35 0
tp 77d4edec-4f89-5806-8a73-69da291cf64a -97.018 65 -15.378 -23.35 0
tp a18c987f-26df-590a-b51c-8f6379e10218 -97.018 65 -15.378 -23.35 0
tp 8bd36e4e-1a75-51ba-b224-63055ff644c2 -97.018 65 -15.378 -23.35 0
tp 7b07c259-0b81-5b46-b286-5b101f183bf9 -97.018 65 -15.378 -23.35 0
tp 04fc5281-333c-5c0d-ba69-0b625cbc7206 -97.018 65 -15.378 -23.35 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0058f,-0.0001f,0.0188f,0.9998f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.5055f,-0.1281f,0.139f,0.8418f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.0513f,0.8319f,0.5218f,0.1819f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.4635f,0.0061f,0.0116f,0.886f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.0116f,0.886f,0.4635f,0.0061f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4021f,0.8467f,0.1f],left_rotation:[0.0109f,0.1848f,-0.9781f,0.0947f]}}
particle minecraft:cloud -96.35 65.32 -20.72 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -96.35 65.42 -20.72 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke -97.92 65.12 -20.16 -0.043 0.021 -0.034 1 0 force
particle minecraft:cloud -97.92 65.32 -20.16 0.35 0.18 0.35 0.02 2 force
tp 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 -95.966 65 -28.404 -14.45 0
tp f74f363c-8714-5fe5-bb64-beafe6b6ac28 -95.966 65 -28.404 -14.45 0
tp 97428e5f-5a51-575c-8305-607c4b0f68cb -95.966 65 -28.404 -14.45 0
tp 186c432f-da2b-5bec-ba8a-9d97f056504e -95.966 65 -28.404 -14.45 0
tp b7fef3cd-3066-54f8-9318-2747261e9dd9 -95.966 65 -28.404 -14.45 0
tp 0d17ad00-82d8-5739-af58-9e93f268e98c -95.966 65 -28.404 -14.45 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0059f,-0.0001f,0.0176f,0.9998f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.3264f,-0.1971f,0.1274f,0.9156f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.0318f,0.9073f,0.3489f,0.2325f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.4635f,0.0061f,0.0116f,0.886f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.0116f,0.886f,0.4635f,0.0061f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4002f,0.8493f,0.2399f],left_rotation:[0.0879f,0.1628f,-0.8478f,0.497f]}}
particle minecraft:cloud -94.27 65.32 -33.09 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -95.95 65.12 -32.74 -0.021 0.022 -0.038 1 0 force
particle minecraft:cloud -95.95 65.32 -32.74 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -95.95 65.42 -32.74 0.45 0.2 0.45 0.008 1 force
