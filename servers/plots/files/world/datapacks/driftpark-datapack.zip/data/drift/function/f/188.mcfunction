tp 425483f9-2934-53dd-805b-82336df4bdbc 69.016 65 -37.288 103.67 0
tp 77d4edec-4f89-5806-8a73-69da291cf64a 69.016 65 -37.288 103.67 0
tp a18c987f-26df-590a-b51c-8f6379e10218 69.016 65 -37.288 103.67 0
tp 8bd36e4e-1a75-51ba-b224-63055ff644c2 69.016 65 -37.288 103.67 0
tp 7b07c259-0b81-5b46-b286-5b101f183bf9 69.016 65 -37.288 103.67 0
tp 04fc5281-333c-5c0d-ba69-0b625cbc7206 69.016 65 -37.288 103.67 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0056f,-0.0001f,0.0223f,0.9997f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.5552f,-0.1173f,0.1448f,0.8106f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.0604f,0.7998f,0.5706f,0.1763f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.5582f,0.0073f,0.0109f,0.8296f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.0109f,0.8296f,0.5582f,0.0073f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4079f,0.8439f,0.1003f],left_rotation:[0.0056f,0.1852f,-0.9799f,0.0735f]}}
particle minecraft:cloud 73.38 65.32 -33.17 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke 73.38 65.42 -33.17 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke 73.88 65.12 -34.76 0.062 0.021 -0.004 1 0 force
particle minecraft:cloud 73.88 65.32 -34.76 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke 73.88 65.42 -34.76 0.45 0.2 0.45 0.008 1 force
tp 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 80.431 65 -27.179 113.12 0
tp f74f363c-8714-5fe5-bb64-beafe6b6ac28 80.431 65 -27.179 113.12 0
tp 97428e5f-5a51-575c-8305-607c4b0f68cb 80.431 65 -27.179 113.12 0
tp 186c432f-da2b-5bec-ba8a-9d97f056504e 80.431 65 -27.179 113.12 0
tp b7fef3cd-3066-54f8-9318-2747261e9dd9 80.431 65 -27.179 113.12 0
tp 0d17ad00-82d8-5739-af58-9e93f268e98c 80.431 65 -27.179 113.12 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0.002f,0f,0.0223f,0.9998f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.9741f,-0.0578f,-0.2179f,0.0187f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.221f,-0.0417f,0.9734f,0.0442f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.5582f,0.0073f,0.0109f,0.8296f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.0109f,0.8296f,0.5582f,0.0073f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4079f,0.8417f,0.2535f],left_rotation:[0.0755f,0.1774f,-0.885f,0.4238f]}}
particle minecraft:cloud 83.54 65.32 -22.19 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 84.34 65.12 -23.71 0.054 0.022 0.013 1 0 force
particle minecraft:cloud 84.34 65.32 -23.71 0.35 0.18 0.35 0.02 3 force
