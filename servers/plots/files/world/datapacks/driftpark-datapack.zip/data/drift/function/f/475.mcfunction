tp 425483f9-2934-53dd-805b-82336df4bdbc -92.308 65 12.346 -23.6 0
tp 77d4edec-4f89-5806-8a73-69da291cf64a -92.308 65 12.346 -23.6 0
tp a18c987f-26df-590a-b51c-8f6379e10218 -92.308 65 12.346 -23.6 0
tp 8bd36e4e-1a75-51ba-b224-63055ff644c2 -92.308 65 12.346 -23.6 0
tp 7b07c259-0b81-5b46-b286-5b101f183bf9 -92.308 65 12.346 -23.6 0
tp 04fc5281-333c-5c0d-ba69-0b625cbc7206 -92.308 65 12.346 -23.6 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0058f,-0.0001f,0.0099f,0.9999f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.9713f,-0.064f,-0.044f,0.2249f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.0679f,-0.2308f,0.9699f,0.0377f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.9872f,-0.0129f,0.0021f,0.159f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.0021f,-0.159f,0.9872f,0.0129f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.387f,0.8537f,0.1f],left_rotation:[0.1617f,-0.0901f,0.4954f,0.8487f]}}
tp 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 -96.702 65 -3.711 -28.5 0
tp f74f363c-8714-5fe5-bb64-beafe6b6ac28 -96.702 65 -3.711 -28.5 0
tp 97428e5f-5a51-575c-8305-607c4b0f68cb -96.702 65 -3.711 -28.5 0
tp 186c432f-da2b-5bec-ba8a-9d97f056504e -96.702 65 -3.711 -28.5 0
tp b7fef3cd-3066-54f8-9318-2747261e9dd9 -96.702 65 -3.711 -28.5 0
tp 0d17ad00-82d8-5739-af58-9e93f268e98c -96.702 65 -3.711 -28.5 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0058f,-0.0001f,0.0172f,0.9998f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.9843f,0.0487f,0.1677f,0.0257f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.1659f,0.0082f,0.9846f,0.0545f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.9872f,-0.0129f,0.0021f,0.159f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.0021f,-0.159f,0.9872f,0.0129f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.3994f,0.8496f,0.24f],left_rotation:[0.0143f,-0.1846f,0.9818f,0.042f]}}
particle minecraft:campfire_cosy_smoke -97.22 65.12 -9.67 0.031 0.02 -0.077 1 0 force
particle minecraft:cloud -97.22 65.32 -9.67 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -97.22 65.42 -9.67 0.45 0.2 0.45 0.008 1 force
particle minecraft:cloud -98.71 65.32 -8.83 0.35 0.18 0.35 0.02 2 force
