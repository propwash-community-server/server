tp 425483f9-2934-53dd-805b-82336df4bdbc 37.186 65 -50.168 63.06 0
tp 77d4edec-4f89-5806-8a73-69da291cf64a 37.186 65 -50.168 63.06 0
tp a18c987f-26df-590a-b51c-8f6379e10218 37.186 65 -50.168 63.06 0
tp 8bd36e4e-1a75-51ba-b224-63055ff644c2 37.186 65 -50.168 63.06 0
tp 7b07c259-0b81-5b46-b286-5b101f183bf9 37.186 65 -50.168 63.06 0
tp 04fc5281-333c-5c0d-ba69-0b625cbc7206 37.186 65 -50.168 63.06 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0.0056f,0.0001f,0.0223f,0.9997f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.2551f,-0.1935f,0.108f,0.9412f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.0096f,0.935f,0.2768f,0.2214f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.2527f,0.0033f,0.0127f,0.9675f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.0127f,0.9675f,0.2527f,0.0033f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4078f,0.8414f,0.1196f],left_rotation:[0.0702f,0.1833f,-0.8992f,0.391f]}}
particle minecraft:campfire_cosy_smoke 42.54 65.12 -49.33 0.066 0.022 0.035 1 0 force
particle minecraft:cloud 42.54 65.32 -49.33 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud 41.95 65.32 -50.89 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 41.95 65.42 -50.89 0.45 0.2 0.45 0.008 1 force
tp 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 51.288 65 -47.892 80.46 0
tp f74f363c-8714-5fe5-bb64-beafe6b6ac28 51.288 65 -47.892 80.46 0
tp 97428e5f-5a51-575c-8305-607c4b0f68cb 51.288 65 -47.892 80.46 0
tp 186c432f-da2b-5bec-ba8a-9d97f056504e 51.288 65 -47.892 80.46 0
tp b7fef3cd-3066-54f8-9318-2747261e9dd9 51.288 65 -47.892 80.46 0
tp 0d17ad00-82d8-5739-af58-9e93f268e98c 51.288 65 -47.892 80.46 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0.0111f,0.0002f,0.0221f,0.9997f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.964f,0.0206f,0.2209f,0.1466f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.2067f,0.1242f,0.9671f,0.0806f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.2527f,0.0033f,0.0127f,0.9675f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.0127f,0.9675f,0.2527f,0.0033f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4074f,0.837f,0.2691f],left_rotation:[0.0726f,0.1882f,-0.8973f,0.3926f]}}
particle minecraft:campfire_cosy_smoke 57.12 65.12 -45.1 0.048 0.022 0.066 1 0 force
particle minecraft:cloud 57.12 65.32 -45.1 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud 57 65.32 -46.8 0.35 0.18 0.35 0.02 3 force
