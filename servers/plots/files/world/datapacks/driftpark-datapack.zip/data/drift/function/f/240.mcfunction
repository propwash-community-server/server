tp 425483f9-2934-53dd-805b-82336df4bdbc 18.87 65 -46.751 28.25 0
tp 77d4edec-4f89-5806-8a73-69da291cf64a 18.87 65 -46.751 28.25 0
tp a18c987f-26df-590a-b51c-8f6379e10218 18.87 65 -46.751 28.25 0
tp 8bd36e4e-1a75-51ba-b224-63055ff644c2 18.87 65 -46.751 28.25 0
tp 7b07c259-0b81-5b46-b286-5b101f183bf9 18.87 65 -46.751 28.25 0
tp 04fc5281-333c-5c0d-ba69-0b625cbc7206 18.87 65 -46.751 28.25 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0.0055f,0.0001f,0.0223f,0.9997f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.5231f,-0.238f,-0.0888f,0.8135f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.1748f,0.8273f,-0.501f,0.1843f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.5486f,-0.0072f,0.0109f,0.836f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.0109f,-0.836f,0.5486f,0.0072f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4078f,0.8414f,0.1194f],left_rotation:[0.1224f,0.1533f,-0.7384f,0.6452f]}}
particle minecraft:cloud 23.55 65.32 -48.5 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 22.2 65.12 -49.49 0.007 0.022 -0.03 1 0 force
particle minecraft:cloud 22.2 65.32 -49.49 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 22.2 65.42 -49.49 0.45 0.2 0.45 0.008 1 force
tp 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 30.697 65 -50.92 48.96 0
tp f74f363c-8714-5fe5-bb64-beafe6b6ac28 30.697 65 -50.92 48.96 0
tp 97428e5f-5a51-575c-8305-607c4b0f68cb 30.697 65 -50.92 48.96 0
tp 186c432f-da2b-5bec-ba8a-9d97f056504e 30.697 65 -50.92 48.96 0
tp b7fef3cd-3066-54f8-9318-2747261e9dd9 30.697 65 -50.92 48.96 0
tp 0d17ad00-82d8-5739-af58-9e93f268e98c 30.697 65 -50.92 48.96 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0.0021f,0f,0.0223f,0.9998f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.6193f,-0.1552f,0.1996f,0.7433f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.1226f,0.7265f,0.639f,0.2211f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.5486f,-0.0072f,0.0109f,0.836f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.0109f,-0.836f,0.5486f,0.0072f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4078f,0.8416f,0.2536f],left_rotation:[0.1187f,0.1521f,-0.7459f,0.6375f]}}
particle minecraft:cloud 36.09 65.32 -51.11 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 35.12 65.12 -52.51 0.033 0.022 -0.033 1 0 force
particle minecraft:cloud 35.12 65.32 -52.51 0.35 0.18 0.35 0.02 3 force
