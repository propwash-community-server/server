tp 425483f9-2934-53dd-805b-82336df4bdbc -84.534 65 33.002 -41.27 0
tp 77d4edec-4f89-5806-8a73-69da291cf64a -84.534 65 33.002 -41.27 0
tp a18c987f-26df-590a-b51c-8f6379e10218 -84.534 65 33.002 -41.27 0
tp 8bd36e4e-1a75-51ba-b224-63055ff644c2 -84.534 65 33.002 -41.27 0
tp 7b07c259-0b81-5b46-b286-5b101f183bf9 -84.534 65 33.002 -41.27 0
tp 04fc5281-333c-5c0d-ba69-0b625cbc7206 -84.534 65 33.002 -41.27 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0.004f,0f,0.0111f,0.9999f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.8959f,-0.0899f,-0.0658f,0.4302f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.1113f,-0.4394f,0.8913f,0.0037f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.9285f,-0.0122f,0.0049f,0.3712f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.0049f,-0.3712f,0.9285f,0.0122f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.389f,0.8506f,0.1169f],left_rotation:[0.1244f,-0.1498f,0.7684f,0.6096f]}}
particle minecraft:campfire_cosy_smoke -88 65.12 27.61 -0.051 0.014 -0.036 1 0 force
particle minecraft:flame -88.32 65.22 26.54 0.05 0.04 0.05 0.02 6 force
particle minecraft:large_smoke -88.32 65.22 26.54 0.05 0.04 0.05 0.01 2 force
tp 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 -91.446 65 16.089 -26.19 0
tp f74f363c-8714-5fe5-bb64-beafe6b6ac28 -91.446 65 16.089 -26.19 0
tp 97428e5f-5a51-575c-8305-607c4b0f68cb -91.446 65 16.089 -26.19 0
tp 186c432f-da2b-5bec-ba8a-9d97f056504e -91.446 65 16.089 -26.19 0
tp b7fef3cd-3066-54f8-9318-2747261e9dd9 -91.446 65 16.089 -26.19 0
tp 0d17ad00-82d8-5739-af58-9e93f268e98c -91.446 65 16.089 -26.19 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0059f,-0.0001f,0.0105f,0.9999f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.9546f,-0.0682f,-0.0449f,0.2863f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.0752f,-0.2926f,0.9527f,0.0318f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.9285f,-0.0122f,0.0049f,0.3712f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.0049f,-0.3712f,0.9285f,0.0122f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.3881f,0.8549f,0.2399f],left_rotation:[0.1572f,-0.0976f,0.5357f,0.8239f]}}
