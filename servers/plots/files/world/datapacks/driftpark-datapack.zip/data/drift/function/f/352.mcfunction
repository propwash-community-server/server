tp 425483f9-2934-53dd-805b-82336df4bdbc -46.581 65 -28.156 131.9 0
tp 77d4edec-4f89-5806-8a73-69da291cf64a -46.581 65 -28.156 131.9 0
tp a18c987f-26df-590a-b51c-8f6379e10218 -46.581 65 -28.156 131.9 0
tp 8bd36e4e-1a75-51ba-b224-63055ff644c2 -46.581 65 -28.156 131.9 0
tp 7b07c259-0b81-5b46-b286-5b101f183bf9 -46.581 65 -28.156 131.9 0
tp 04fc5281-333c-5c0d-ba69-0b625cbc7206 -46.581 65 -28.156 131.9 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0059f,0f,-0.0045f,1f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.2797f,-0.0377f,0.0435f,0.9584f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.057f,0.9591f,-0.2773f,0.0085f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.9466f,0.0124f,0.0042f,0.3222f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.0042f,0.3222f,0.9466f,0.0124f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.3623f,0.8645f,0.0999f],left_rotation:[0.1805f,-0.0407f,0.2074f,0.9606f]}}
particle minecraft:flame -42.41 65.22 -23.66 0.05 0.04 0.05 0.02 5 force
particle minecraft:large_smoke -42.41 65.22 -23.66 0.05 0.04 0.05 0.01 2 force
tp 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 -39.103 65 -17.932 163.73 0
tp f74f363c-8714-5fe5-bb64-beafe6b6ac28 -39.103 65 -17.932 163.73 0
tp 97428e5f-5a51-575c-8305-607c4b0f68cb -39.103 65 -17.932 163.73 0
tp 186c432f-da2b-5bec-ba8a-9d97f056504e -39.103 65 -17.932 163.73 0
tp b7fef3cd-3066-54f8-9318-2747261e9dd9 -39.103 65 -17.932 163.73 0
tp 0d17ad00-82d8-5739-af58-9e93f268e98c -39.103 65 -17.932 163.73 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0059f,0.0001f,-0.0205f,0.9998f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.4443f,0.2295f,-0.0575f,0.8641f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.1486f,-0.8749f,-0.4226f,0.1841f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.9466f,0.0124f,0.0042f,0.3222f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.0042f,0.3222f,0.9466f,0.0124f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.3342f,0.8773f,0.2399f],left_rotation:[0.0903f,-0.1615f,0.8373f,0.5145f]}}
particle minecraft:cloud -36.97 65.32 -14.3 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -35.34 65.12 -14.82 0.069 0.022 0.012 1 0 force
particle minecraft:cloud -35.34 65.32 -14.82 0.35 0.18 0.35 0.02 3 force
