tp 425483f9-2934-53dd-805b-82336df4bdbc 90.126 65 1.975 150.44 0
tp 77d4edec-4f89-5806-8a73-69da291cf64a 90.126 65 1.975 150.44 0
tp a18c987f-26df-590a-b51c-8f6379e10218 90.126 65 1.975 150.44 0
tp 8bd36e4e-1a75-51ba-b224-63055ff644c2 90.126 65 1.975 150.44 0
tp 7b07c259-0b81-5b46-b286-5b101f183bf9 90.126 65 1.975 150.44 0
tp 04fc5281-333c-5c0d-ba69-0b625cbc7206 90.126 65 1.975 150.44 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0.0003f,0f,0.0223f,0.9998f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.8042f,-0.0646f,0.1858f,0.5609f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.1278f,0.5445f,0.8154f,0.1495f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.8181f,0.0107f,0.0075f,0.575f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.0075f,0.575f,0.8181f,0.0107f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4079f,0.8426f,0.1106f],left_rotation:[0.0245f,0.1896f,-0.9669f,0.1688f]}}
particle minecraft:campfire_cosy_smoke 89.89 65.12 7.78 -0.04 0.021 0.074 1 0 force
particle minecraft:cloud 89.89 65.32 7.78 0.35 0.18 0.35 0.02 2 force
particle minecraft:cloud 91.41 65.32 7.08 0.35 0.18 0.35 0.02 2 force
tp 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 89.825 65 17.029 162.93 0
tp f74f363c-8714-5fe5-bb64-beafe6b6ac28 89.825 65 17.029 162.93 0
tp 97428e5f-5a51-575c-8305-607c4b0f68cb 89.825 65 17.029 162.93 0
tp 186c432f-da2b-5bec-ba8a-9d97f056504e 89.825 65 17.029 162.93 0
tp b7fef3cd-3066-54f8-9318-2747261e9dd9 89.825 65 17.029 162.93 0
tp 0d17ad00-82d8-5739-af58-9e93f268e98c 89.825 65 17.029 162.93 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0016f,0f,0.0223f,0.9998f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.9628f,-0.0865f,-0.2075f,0.1496f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.2244f,-0.1723f,0.959f,0.0142f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.8181f,0.0107f,0.0075f,0.575f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.0075f,0.575f,0.8181f,0.0107f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4079f,0.8435f,0.2473f],left_rotation:[0.0731f,0.1746f,-0.888f,0.4191f]}}
particle minecraft:campfire_cosy_smoke 88.12 65.12 22.69 -0.046 0.022 0.052 1 0 force
particle minecraft:cloud 88.12 65.32 22.69 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud 89.79 65.32 22.31 0.35 0.18 0.35 0.02 3 force
