tp 425483f9-2934-53dd-805b-82336df4bdbc 75.651 65 -31.372 110.64 0
tp 77d4edec-4f89-5806-8a73-69da291cf64a 75.651 65 -31.372 110.64 0
tp a18c987f-26df-590a-b51c-8f6379e10218 75.651 65 -31.372 110.64 0
tp 8bd36e4e-1a75-51ba-b224-63055ff644c2 75.651 65 -31.372 110.64 0
tp 7b07c259-0b81-5b46-b286-5b101f183bf9 75.651 65 -31.372 110.64 0
tp 04fc5281-333c-5c0d-ba69-0b625cbc7206 75.651 65 -31.372 110.64 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0043f,-0.0001f,0.0223f,0.9997f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.4076f,-0.1923f,-0.0293f,0.8922f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.1232f,0.9002f,-0.3896f,0.1505f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.4219f,-0.0055f,0.0119f,0.9066f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.0119f,-0.9066f,0.4219f,0.0055f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4079f,0.8436f,0.1026f],left_rotation:[0.0201f,0.1855f,-0.9711f,0.1491f]}}
particle minecraft:cloud 79.16 65.32 -26.85 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke 79.16 65.42 -26.85 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke 79.87 65.12 -28.37 0.059 0.021 0.001 1 0 force
particle minecraft:cloud 79.87 65.32 -28.37 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke 79.87 65.42 -28.37 0.45 0.2 0.45 0.008 1 force
tp 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 84.893 65 -19.976 122.24 0
tp f74f363c-8714-5fe5-bb64-beafe6b6ac28 84.893 65 -19.976 122.24 0
tp 97428e5f-5a51-575c-8305-607c4b0f68cb 84.893 65 -19.976 122.24 0
tp 186c432f-da2b-5bec-ba8a-9d97f056504e 84.893 65 -19.976 122.24 0
tp b7fef3cd-3066-54f8-9318-2747261e9dd9 84.893 65 -19.976 122.24 0
tp 0d17ad00-82d8-5739-af58-9e93f268e98c 84.893 65 -19.976 122.24 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0.0015f,0f,0.0223f,0.9998f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.4833f,-0.1644f,0.1557f,0.8457f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.0677f,0.834f,0.5032f,0.2161f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.4219f,-0.0055f,0.0119f,0.9066f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.0119f,-0.9066f,0.4219f,0.0055f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4079f,0.8419f,0.2526f],left_rotation:[0.0769f,0.1763f,-0.8811f,0.4321f]}}
particle minecraft:cloud 87.21 65.32 -14.46 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 88.25 65.12 -15.82 0.055 0.022 0.024 1 0 force
particle minecraft:cloud 88.25 65.32 -15.82 0.35 0.18 0.35 0.02 3 force
