tp 425483f9-2934-53dd-805b-82336df4bdbc -59.029 65 59.886 -93.27 0
tp 77d4edec-4f89-5806-8a73-69da291cf64a -59.029 65 59.886 -93.27 0
tp a18c987f-26df-590a-b51c-8f6379e10218 -59.029 65 59.886 -93.27 0
tp 8bd36e4e-1a75-51ba-b224-63055ff644c2 -59.029 65 59.886 -93.27 0
tp 7b07c259-0b81-5b46-b286-5b101f183bf9 -59.029 65 59.886 -93.27 0
tp 04fc5281-333c-5c0d-ba69-0b625cbc7206 -59.029 65 59.886 -93.27 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0059f,-0.0001f,0.0201f,0.9998f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.4792f,-0.1887f,-0.0446f,0.856f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.1348f,0.8654f,-0.462f,0.1393f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.4789f,-0.0063f,0.0115f,0.8778f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.0115f,-0.8778f,0.4789f,0.0063f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4043f,0.8457f,0.0999f],left_rotation:[0.0191f,0.1841f,-0.9726f,0.1408f]}}
particle minecraft:campfire_cosy_smoke -63.85 65.12 57.44 -0.043 0.021 -0.069 1 0 force
particle minecraft:cloud -63.85 65.32 57.44 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -63.85 65.42 57.44 0.45 0.2 0.45 0.008 1 force
particle minecraft:cloud -63.83 65.32 59.11 0.35 0.18 0.35 0.02 2 force
tp 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 -70.884 65 54.306 -86.87 0
tp f74f363c-8714-5fe5-bb64-beafe6b6ac28 -70.884 65 54.306 -86.87 0
tp 97428e5f-5a51-575c-8305-607c4b0f68cb -70.884 65 54.306 -86.87 0
tp 186c432f-da2b-5bec-ba8a-9d97f056504e -70.884 65 54.306 -86.87 0
tp b7fef3cd-3066-54f8-9318-2747261e9dd9 -70.884 65 54.306 -86.87 0
tp 0d17ad00-82d8-5739-af58-9e93f268e98c -70.884 65 54.306 -86.87 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0.002f,0f,0.0222f,0.9998f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.4004f,-0.2513f,-0.055f,0.8795f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.1477f,0.8901f,-0.3762f,0.2106f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.4789f,-0.0063f,0.0115f,0.8778f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.0115f,-0.8778f,0.4789f,0.0063f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4078f,0.8417f,0.2534f],left_rotation:[0.1249f,0.1468f,-0.7185f,0.6683f]}}
particle minecraft:campfire_cosy_smoke -74.66 65.12 50.88 -0.025 0.022 -0.06 1 0 force
particle minecraft:cloud -74.66 65.32 50.88 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -74.66 65.42 50.88 0.45 0.2 0.45 0.008 1 force
particle minecraft:cloud -74.91 65.32 52.58 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -74.91 65.42 52.58 0.45 0.2 0.45 0.008 1 force
