tp 425483f9-2934-53dd-805b-82336df4bdbc 8.141 65 -37.653 12.31 0
tp 77d4edec-4f89-5806-8a73-69da291cf64a 8.141 65 -37.653 12.31 0
tp a18c987f-26df-590a-b51c-8f6379e10218 8.141 65 -37.653 12.31 0
tp 8bd36e4e-1a75-51ba-b224-63055ff644c2 8.141 65 -37.653 12.31 0
tp 7b07c259-0b81-5b46-b286-5b101f183bf9 8.141 65 -37.653 12.31 0
tp 04fc5281-333c-5c0d-ba69-0b625cbc7206 8.141 65 -37.653 12.31 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0058f,-0.0001f,0.0194f,0.9998f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.1797f,-0.196f,0.0177f,0.9638f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.0835f,0.9673f,-0.16f,0.1782f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.776f,-0.0102f,0.0083f,0.6305f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.0083f,-0.6305f,0.776f,0.0102f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4031f,0.8462f,0.0999f],left_rotation:[0.0245f,0.1834f,-0.9683f,0.1678f]}}
particle minecraft:campfire_cosy_smoke 11.11 65.12 -41.08 0.059 0.022 -0.022 1 0 force
particle minecraft:cloud 11.11 65.32 -41.08 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud 9.47 65.32 -41.39 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 9.47 65.42 -41.39 0.45 0.2 0.45 0.008 1 force
tp 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 14.893 65 -45.566 14.42 0
tp f74f363c-8714-5fe5-bb64-beafe6b6ac28 14.893 65 -45.566 14.42 0
tp 97428e5f-5a51-575c-8305-607c4b0f68cb 14.893 65 -45.566 14.42 0
tp 186c432f-da2b-5bec-ba8a-9d97f056504e 14.893 65 -45.566 14.42 0
tp b7fef3cd-3066-54f8-9318-2747261e9dd9 14.893 65 -45.566 14.42 0
tp 0d17ad00-82d8-5739-af58-9e93f268e98c 14.893 65 -45.566 14.42 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0.0064f,0.0001f,0.0223f,0.9997f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.2479f,-0.27f,0.1294f,0.9213f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.0333f,0.9128f,0.2777f,0.2976f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.776f,-0.0102f,0.0083f,0.6305f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.0083f,-0.6305f,0.776f,0.0102f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4077f,0.8394f,0.2611f],left_rotation:[0.1764f,0.088f,-0.3981f,0.8959f]}}
particle minecraft:campfire_cosy_smoke 19.16 65.12 -48.09 0.084 0.022 -0.009 1 0 force
particle minecraft:cloud 19.16 65.32 -48.09 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 19.16 65.42 -48.09 0.45 0.2 0.45 0.008 1 force
particle minecraft:cloud 17.58 65.32 -48.73 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 17.58 65.42 -48.73 0.45 0.2 0.45 0.008 1 force
