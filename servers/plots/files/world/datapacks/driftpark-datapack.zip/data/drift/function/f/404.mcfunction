tp 425483f9-2934-53dd-805b-82336df4bdbc -82.093 65 -45.01 28.04 0
tp 77d4edec-4f89-5806-8a73-69da291cf64a -82.093 65 -45.01 28.04 0
tp a18c987f-26df-590a-b51c-8f6379e10218 -82.093 65 -45.01 28.04 0
tp 8bd36e4e-1a75-51ba-b224-63055ff644c2 -82.093 65 -45.01 28.04 0
tp 7b07c259-0b81-5b46-b286-5b101f183bf9 -82.093 65 -45.01 28.04 0
tp 04fc5281-333c-5c0d-ba69-0b625cbc7206 -82.093 65 -45.01 28.04 0
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.2294f,-0.2842f,-0.0139f,0.9308f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.1118f,0.9374f,-0.2008f,0.2617f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.0696f,0.0009f,0.0131f,0.9975f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.0131f,0.9975f,0.0696f,0.0009f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4078f,0.8413f,0.1206f],left_rotation:[0.1619f,0.112f,-0.5213f,0.8303f]}}
particle minecraft:cloud -78.14 65.32 -46.21 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -79.5 65.12 -47.18 0.007 0.022 -0.034 1 0 force
particle minecraft:cloud -79.5 65.32 -47.18 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -79.5 65.42 -47.18 0.45 0.2 0.45 0.008 1 force
tp 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 -72.479 65 -47.118 50.49 0
tp f74f363c-8714-5fe5-bb64-beafe6b6ac28 -72.479 65 -47.118 50.49 0
tp 97428e5f-5a51-575c-8305-607c4b0f68cb -72.479 65 -47.118 50.49 0
tp 186c432f-da2b-5bec-ba8a-9d97f056504e -72.479 65 -47.118 50.49 0
tp b7fef3cd-3066-54f8-9318-2747261e9dd9 -72.479 65 -47.118 50.49 0
tp 0d17ad00-82d8-5739-af58-9e93f268e98c -72.479 65 -47.118 50.49 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0.0014f,0f,0.0223f,0.9998f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.2798f,-0.303f,-0.0357f,0.9103f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.1316f,0.9191f,-0.2495f,0.2753f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.0696f,0.0009f,0.0131f,0.9975f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.0131f,0.9975f,0.0696f,0.0009f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4079f,0.842f,0.2524f],left_rotation:[0.1764f,0.0763f,-0.3491f,0.9172f]}}
particle minecraft:cloud -67.7 65.32 -46.58 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -68.6 65.12 -48.03 0.025 0.022 -0.032 1 0 force
particle minecraft:cloud -68.6 65.32 -48.03 0.35 0.18 0.35 0.02 3 force
