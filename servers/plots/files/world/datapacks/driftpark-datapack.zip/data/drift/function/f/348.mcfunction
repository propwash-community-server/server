tp 425483f9-2934-53dd-805b-82336df4bdbc -44.268 65 -25.149 143.33 0
tp 77d4edec-4f89-5806-8a73-69da291cf64a -44.268 65 -25.149 143.33 0
tp a18c987f-26df-590a-b51c-8f6379e10218 -44.268 65 -25.149 143.33 0
tp 8bd36e4e-1a75-51ba-b224-63055ff644c2 -44.268 65 -25.149 143.33 0
tp 7b07c259-0b81-5b46-b286-5b101f183bf9 -44.268 65 -25.149 143.33 0
tp 04fc5281-333c-5c0d-ba69-0b625cbc7206 -44.268 65 -25.149 143.33 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0058f,0.0001f,-0.0104f,0.9999f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.6989f,0.0786f,-0.0038f,0.7109f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.0785f,-0.7152f,-0.6945f,0.0056f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.7459f,-0.0098f,0.0087f,0.6659f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.0087f,-0.6659f,0.7459f,0.0098f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.352f,0.8687f,0.1f],left_rotation:[0.1606f,0.092f,-0.5061f,0.8424f]}}
particle minecraft:campfire_cosy_smoke -40.59 65.12 -21.7 0.06 0.012 0.012 1 0 force
tp 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 -36.601 65 -15.765 162.82 0
tp f74f363c-8714-5fe5-bb64-beafe6b6ac28 -36.601 65 -15.765 162.82 0
tp 97428e5f-5a51-575c-8305-607c4b0f68cb -36.601 65 -15.765 162.82 0
tp 186c432f-da2b-5bec-ba8a-9d97f056504e -36.601 65 -15.765 162.82 0
tp b7fef3cd-3066-54f8-9318-2747261e9dd9 -36.601 65 -15.765 162.82 0
tp 0d17ad00-82d8-5739-af58-9e93f268e98c -36.601 65 -15.765 162.82 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0056f,0.0001f,-0.0221f,0.9997f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.8255f,0.0858f,0.2458f,0.5008f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.1946f,-0.4777f,0.8391f,0.1731f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.7459f,-0.0098f,0.0087f,0.6659f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.0087f,-0.6659f,0.7459f,0.0098f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.3316f,0.8782f,0.2403f],left_rotation:[0.1243f,-0.1375f,0.6992f,0.6905f]}}
particle minecraft:cloud -34.33 65.32 -12.49 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -34.33 65.42 -12.49 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke -32.72 65.12 -13.08 0.072 0.022 0.005 1 0 force
particle minecraft:cloud -32.72 65.32 -13.08 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -32.72 65.42 -13.08 0.45 0.2 0.45 0.008 1 force
