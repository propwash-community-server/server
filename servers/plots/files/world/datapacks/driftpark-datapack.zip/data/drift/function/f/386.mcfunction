tp 425483f9-2934-53dd-805b-82336df4bdbc -69.484 65 -45.8 62.78 0
tp 77d4edec-4f89-5806-8a73-69da291cf64a -69.484 65 -45.8 62.78 0
tp a18c987f-26df-590a-b51c-8f6379e10218 -69.484 65 -45.8 62.78 0
tp 8bd36e4e-1a75-51ba-b224-63055ff644c2 -69.484 65 -45.8 62.78 0
tp 7b07c259-0b81-5b46-b286-5b101f183bf9 -69.484 65 -45.8 62.78 0
tp 04fc5281-333c-5c0d-ba69-0b625cbc7206 -69.484 65 -45.8 62.78 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0017f,0f,0.0223f,0.9998f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.963f,-0.0592f,-0.2621f,0.0182f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.2655f,-0.0458f,0.9621f,0.0417f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.9935f,-0.013f,0.0015f,0.113f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.0015f,-0.113f,0.9935f,0.013f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4079f,0.8431f,0.107f],left_rotation:[0.1375f,0.1298f,-0.6416f,0.7433f]}}
particle minecraft:cloud -65.04 65.32 -44.61 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -65.04 65.42 -44.61 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke -65.62 65.12 -46.18 0.02 0.022 -0.036 1 0 force
particle minecraft:cloud -65.62 65.32 -46.18 0.35 0.18 0.35 0.02 3 force
tp 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 -59.27 65 -42.631 80.4 0
tp f74f363c-8714-5fe5-bb64-beafe6b6ac28 -59.27 65 -42.631 80.4 0
tp 97428e5f-5a51-575c-8305-607c4b0f68cb -59.27 65 -42.631 80.4 0
tp 186c432f-da2b-5bec-ba8a-9d97f056504e -59.27 65 -42.631 80.4 0
tp b7fef3cd-3066-54f8-9318-2747261e9dd9 -59.27 65 -42.631 80.4 0
tp 0d17ad00-82d8-5739-af58-9e93f268e98c -59.27 65 -42.631 80.4 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0.0107f,0.0002f,0.0221f,0.9997f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.5578f,-0.2121f,0.2211f,0.7713f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.1413f,0.7523f,0.5832f,0.2719f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.9935f,-0.013f,0.0015f,0.113f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.0015f,-0.113f,0.9935f,0.013f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4074f,0.8373f,0.2683f],left_rotation:[0.1857f,0.0776f,-0.3373f,0.9196f]}}
particle minecraft:cloud -55.09 65.32 -39.65 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -55.09 65.42 -39.65 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke -55.15 65.12 -41.36 0.025 0.022 -0.012 1 0 force
particle minecraft:cloud -55.15 65.32 -41.36 0.35 0.18 0.35 0.02 3 force
