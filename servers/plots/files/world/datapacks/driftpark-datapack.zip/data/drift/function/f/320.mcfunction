tp 425483f9-2934-53dd-805b-82336df4bdbc -26.811 65 -11.843 143.46 0
tp 77d4edec-4f89-5806-8a73-69da291cf64a -26.811 65 -11.843 143.46 0
tp a18c987f-26df-590a-b51c-8f6379e10218 -26.811 65 -11.843 143.46 0
tp 8bd36e4e-1a75-51ba-b224-63055ff644c2 -26.811 65 -11.843 143.46 0
tp 7b07c259-0b81-5b46-b286-5b101f183bf9 -26.811 65 -11.843 143.46 0
tp 04fc5281-333c-5c0d-ba69-0b625cbc7206 -26.811 65 -11.843 143.46 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0022f,0f,-0.0223f,0.9998f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.8711f,0.0632f,0.2609f,0.4111f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.2192f,-0.386f,0.8826f,0.1551f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.2695f,0.0035f,0.0126f,0.9629f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.0126f,0.9629f,0.2695f,0.0035f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.3314f,0.8761f,0.1063f],left_rotation:[0.1369f,-0.1299f,0.6434f,0.7419f]}}
particle minecraft:cloud -23.6 65.32 -9.83 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -22.39 65.12 -10.98 0.069 0.022 -0.02 1 0 force
particle minecraft:cloud -22.39 65.32 -10.98 0.35 0.18 0.35 0.02 3 force
tp 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 -16.694 65 -10.313 126.86 0
tp f74f363c-8714-5fe5-bb64-beafe6b6ac28 -16.694 65 -10.313 126.86 0
tp 97428e5f-5a51-575c-8305-607c4b0f68cb -16.694 65 -10.313 126.86 0
tp 186c432f-da2b-5bec-ba8a-9d97f056504e -16.694 65 -10.313 126.86 0
tp b7fef3cd-3066-54f8-9318-2747261e9dd9 -16.694 65 -10.313 126.86 0
tp 0d17ad00-82d8-5739-af58-9e93f268e98c -16.694 65 -10.313 126.86 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0036f,0.0001f,-0.0223f,0.9997f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.0873f,0.3097f,0.0267f,0.9464f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.0727f,-0.9488f,-0.0552f,0.3023f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.2695f,0.0035f,0.0126f,0.9629f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.0126f,0.9629f,0.2695f,0.0035f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.3313f,0.8774f,0.2438f],left_rotation:[0.1757f,-0.0647f,0.2981f,0.936f]}}
particle minecraft:cloud -13.39 65.32 -9.55 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -12.52 65.12 -11.03 0.042 0.022 -0.048 1 0 force
particle minecraft:cloud -12.52 65.32 -11.03 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -12.52 65.42 -11.03 0.45 0.2 0.45 0.008 1 force
