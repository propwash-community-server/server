tp 425483f9-2934-53dd-805b-82336df4bdbc 84.881 65 28.579 -180.68 0
tp 77d4edec-4f89-5806-8a73-69da291cf64a 84.881 65 28.579 -180.68 0
tp a18c987f-26df-590a-b51c-8f6379e10218 84.881 65 28.579 -180.68 0
tp 8bd36e4e-1a75-51ba-b224-63055ff644c2 84.881 65 28.579 -180.68 0
tp 7b07c259-0b81-5b46-b286-5b101f183bf9 84.881 65 28.579 -180.68 0
tp 04fc5281-333c-5c0d-ba69-0b625cbc7206 84.881 65 28.579 -180.68 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0.0023f,0.0001f,0.0223f,0.9997f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.979f,0.0484f,0.1964f,0.0248f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.1949f,0.0043f,0.9793f,0.0542f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.9996f,0.0131f,0.0003f,0.0261f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.0003f,0.0261f,0.9996f,0.0131f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4079f,0.8422f,0.114f],left_rotation:[0.035f,0.1899f,-0.9561f,0.2204f]}}
particle minecraft:campfire_cosy_smoke 81.86 65.12 33.35 -0.07 0.022 0.033 1 0 force
particle minecraft:cloud 81.86 65.32 33.35 0.35 0.18 0.35 0.02 2 force
particle minecraft:cloud 83.53 65.32 33.48 0.35 0.18 0.35 0.02 2 force
tp 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 77.105 65 41.17 -166.76 0
tp f74f363c-8714-5fe5-bb64-beafe6b6ac28 77.105 65 41.17 -166.76 0
tp 97428e5f-5a51-575c-8305-607c4b0f68cb 77.105 65 41.17 -166.76 0
tp 186c432f-da2b-5bec-ba8a-9d97f056504e 77.105 65 41.17 -166.76 0
tp b7fef3cd-3066-54f8-9318-2747261e9dd9 77.105 65 41.17 -166.76 0
tp 0d17ad00-82d8-5739-af58-9e93f268e98c 77.105 65 41.17 -166.76 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0.0032f,0.0001f,0.0223f,0.9997f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.8039f,-0.1665f,-0.148f,0.5514f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.2067f,0.57f,-0.7909f,0.0829f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.9996f,0.0131f,0.0003f,0.0261f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.0003f,0.0261f,0.9996f,0.0131f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4078f,0.841f,0.2556f],left_rotation:[0.0713f,0.1804f,-0.8953f,0.401f]}}
particle minecraft:campfire_cosy_smoke 72.55 65.12 45.34 -0.077 0.022 0.019 1 0 force
particle minecraft:cloud 72.55 65.32 45.34 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud 74.18 65.32 45.87 0.35 0.18 0.35 0.02 3 force
