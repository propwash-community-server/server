tp 425483f9-2934-53dd-805b-82336df4bdbc -94.821 65 2.933 -22.77 0
tp 77d4edec-4f89-5806-8a73-69da291cf64a -94.821 65 2.933 -22.77 0
tp a18c987f-26df-590a-b51c-8f6379e10218 -94.821 65 2.933 -22.77 0
tp 8bd36e4e-1a75-51ba-b224-63055ff644c2 -94.821 65 2.933 -22.77 0
tp 7b07c259-0b81-5b46-b286-5b101f183bf9 -94.821 65 2.933 -22.77 0
tp 04fc5281-333c-5c0d-ba69-0b625cbc7206 -94.821 65 2.933 -22.77 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0058f,-0.0001f,0.0139f,0.9999f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.6907f,-0.0301f,0.1021f,0.7153f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.0275f,0.7085f,0.6976f,0.1028f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.6462f,0.0085f,0.01f,0.7631f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.01f,0.7631f,0.6462f,0.0085f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.3938f,0.8506f,0.0999f],left_rotation:[0.1257f,-0.1358f,0.7394f,0.6473f]}}
particle minecraft:campfire_cosy_smoke -95.45 65.12 -3.08 0.019 0.014 -0.074 1 0 force
playsound driftpark:lap.kaze.08.126 neutral @a -96.06 65.5 -3.75 12 1
playsound driftpark:lap.kaze.08.127 neutral @a -94.18 65.5 5.29 12 1
playsound driftpark:lap.kaze.08.128 neutral @a -91.49 65.5 14.82 12 1
playsound driftpark:lap.kaze.08.129 neutral @a -88.03 65.5 24.6 12 1
playsound driftpark:lap.kaze.08.130 neutral @a -83.97 65.5 34.06 12 1
playsound driftpark:lap.kaze.08.131 neutral @a -79.71 65.5 42.23 12 1
tp 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 -97.778 65 -12.31 -28.52 0
tp f74f363c-8714-5fe5-bb64-beafe6b6ac28 -97.778 65 -12.31 -28.52 0
tp 97428e5f-5a51-575c-8305-607c4b0f68cb -97.778 65 -12.31 -28.52 0
tp 186c432f-da2b-5bec-ba8a-9d97f056504e -97.778 65 -12.31 -28.52 0
tp b7fef3cd-3066-54f8-9318-2747261e9dd9 -97.778 65 -12.31 -28.52 0
tp 0d17ad00-82d8-5739-af58-9e93f268e98c -97.778 65 -12.31 -28.52 0
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.4444f,-0.1567f,0.14f,0.8709f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.0492f,0.861f,0.4633f,0.2042f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.6462f,0.0085f,0.01f,0.7631f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.01f,0.7631f,0.6462f,0.0085f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4024f,0.8483f,0.2399f],left_rotation:[0.0474f,0.1788f,-0.9397f,0.2878f]}}
particle minecraft:campfire_cosy_smoke -97.57 65.12 -17.98 0.029 0.022 -0.06 1 0 force
particle minecraft:cloud -97.57 65.32 -17.98 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -97.57 65.42 -17.98 0.45 0.2 0.45 0.008 1 force
particle minecraft:cloud -99.11 65.32 -17.23 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -99.11 65.42 -17.23 0.45 0.2 0.45 0.008 1 force
