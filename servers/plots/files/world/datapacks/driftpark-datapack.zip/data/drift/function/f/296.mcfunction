tp 425483f9-2934-53dd-805b-82336df4bdbc -10.935 65 -13.148 105.06 0
tp 77d4edec-4f89-5806-8a73-69da291cf64a -10.935 65 -13.148 105.06 0
tp a18c987f-26df-590a-b51c-8f6379e10218 -10.935 65 -13.148 105.06 0
tp 8bd36e4e-1a75-51ba-b224-63055ff644c2 -10.935 65 -13.148 105.06 0
tp 7b07c259-0b81-5b46-b286-5b101f183bf9 -10.935 65 -13.148 105.06 0
tp 04fc5281-333c-5c0d-ba69-0b625cbc7206 -10.935 65 -13.148 105.06 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0.008f,-0.0002f,-0.0223f,0.9997f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.6075f,0.1926f,0.2301f,0.7355f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.1541f,-0.7154f,0.631f,0.2575f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.325f,0.0043f,0.0124f,0.9456f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.0124f,0.9456f,0.325f,0.0043f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.3315f,0.8737f,0.1238f],left_rotation:[0.1783f,-0.0876f,0.3927f,0.8979f]}}
particle minecraft:cloud -7.43 65.32 -13.72 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -7.2 65.12 -15.38 0.039 0.022 -0.069 1 0 force
particle minecraft:cloud -7.2 65.32 -15.38 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -7.2 65.42 -15.38 0.45 0.2 0.45 0.008 1 force
tp 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 -2.089 65 -19.472 81.58 0
tp f74f363c-8714-5fe5-bb64-beafe6b6ac28 -2.089 65 -19.472 81.58 0
tp 97428e5f-5a51-575c-8305-607c4b0f68cb -2.089 65 -19.472 81.58 0
tp 186c432f-da2b-5bec-ba8a-9d97f056504e -2.089 65 -19.472 81.58 0
tp b7fef3cd-3066-54f8-9318-2747261e9dd9 -2.089 65 -19.472 81.58 0
tp 0d17ad00-82d8-5739-af58-9e93f268e98c -2.089 65 -19.472 81.58 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0.0065f,-0.0001f,-0.0203f,0.9998f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.9234f,0.1275f,-0.2512f,0.2607f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.28f,-0.2885f,-0.9151f,0.0311f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.325f,0.0043f,0.0124f,0.9456f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.0124f,0.9456f,0.325f,0.0043f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.3349f,0.871f,0.2611f],left_rotation:[0.1592f,-0.1163f,0.5455f,0.8146f]}}
particle minecraft:cloud 1.82 65.32 -22.36 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 1.25 65.12 -23.97 0.023 0.022 -0.07 1 0 force
particle minecraft:cloud 1.25 65.32 -23.97 0.35 0.18 0.35 0.02 3 force
particle minecraft:flame 2.51 65.24 -23.7 0.05 0.04 0.05 0.02 6 force
particle minecraft:large_smoke 2.51 65.24 -23.7 0.05 0.04 0.05 0.01 2 force
particle minecraft:flame 2.63 65.24 -23.36 0.05 0.04 0.05 0.02 6 force
particle minecraft:large_smoke 2.63 65.24 -23.36 0.05 0.04 0.05 0.01 2 force
