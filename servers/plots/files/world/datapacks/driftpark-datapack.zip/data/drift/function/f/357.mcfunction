tp 425483f9-2934-53dd-805b-82336df4bdbc -49.633 65 -32.085 117.53 0
tp 77d4edec-4f89-5806-8a73-69da291cf64a -49.633 65 -32.085 117.53 0
tp a18c987f-26df-590a-b51c-8f6379e10218 -49.633 65 -32.085 117.53 0
tp 8bd36e4e-1a75-51ba-b224-63055ff644c2 -49.633 65 -32.085 117.53 0
tp 7b07c259-0b81-5b46-b286-5b101f183bf9 -49.633 65 -32.085 117.53 0
tp 04fc5281-333c-5c0d-ba69-0b625cbc7206 -49.633 65 -32.085 117.53 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0059f,0f,0.0045f,1f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.0388f,-0.1282f,0.0478f,0.9898f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.056f,0.9903f,-0.0256f,0.1249f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.9968f,0.013f,0.001f,0.0783f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.001f,0.0783f,0.9968f,0.013f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.3777f,0.8579f,0.0999f],left_rotation:[0.0773f,-0.1681f,0.8964f,0.4027f]}}
particle minecraft:campfire_cosy_smoke -46.7 65.12 -27.52 0.006 0.016 0.078 1 0 force
particle minecraft:cloud -46.7 65.32 -27.52 0.35 0.18 0.35 0.02 1 force
particle minecraft:cloud -45.66 65.32 -28.82 0.35 0.18 0.35 0.02 1 force
tp 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 -42.09 65 -21.076 156.94 0
tp f74f363c-8714-5fe5-bb64-beafe6b6ac28 -42.09 65 -21.076 156.94 0
tp 97428e5f-5a51-575c-8305-607c4b0f68cb -42.09 65 -21.076 156.94 0
tp 186c432f-da2b-5bec-ba8a-9d97f056504e -42.09 65 -21.076 156.94 0
tp b7fef3cd-3066-54f8-9318-2747261e9dd9 -42.09 65 -21.076 156.94 0
tp 0d17ad00-82d8-5739-af58-9e93f268e98c -42.09 65 -21.076 156.94 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0058f,0.0001f,-0.0164f,0.9998f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.3387f,0.1786f,-0.0089f,0.9237f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.1061f,-0.9298f,-0.3218f,0.144f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.9968f,0.013f,0.001f,0.0783f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.001f,0.0783f,0.9968f,0.013f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.3415f,0.8745f,0.2399f],left_rotation:[0.0067f,0.185f,-0.9827f,0.0032f]}}
particle minecraft:campfire_cosy_smoke -40.03 65.12 -17.03 -0.003 0.021 0.047 1 0 force
particle minecraft:cloud -40.03 65.32 -17.03 0.35 0.18 0.35 0.02 2 force
particle minecraft:cloud -38.41 65.32 -17.58 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -38.41 65.42 -17.58 0.45 0.2 0.45 0.008 1 force
