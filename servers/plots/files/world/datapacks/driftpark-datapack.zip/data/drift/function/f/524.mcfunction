tp 425483f9-2934-53dd-805b-82336df4bdbc -65.162 65 57.028 -88.57 0
tp 77d4edec-4f89-5806-8a73-69da291cf64a -65.162 65 57.028 -88.57 0
tp a18c987f-26df-590a-b51c-8f6379e10218 -65.162 65 57.028 -88.57 0
tp 8bd36e4e-1a75-51ba-b224-63055ff644c2 -65.162 65 57.028 -88.57 0
tp 7b07c259-0b81-5b46-b286-5b101f183bf9 -65.162 65 57.028 -88.57 0
tp 04fc5281-333c-5c0d-ba69-0b625cbc7206 -65.162 65 57.028 -88.57 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0059f,-0.0001f,0.0216f,0.9997f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.2259f,-0.2126f,0.0045f,0.9506f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.0954f,0.9554f,-0.2048f,0.19f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.2189f,-0.0029f,0.0128f,0.9757f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.0128f,-0.9757f,0.2189f,0.0029f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4069f,0.8444f,0.0999f],left_rotation:[0.0513f,0.1778f,-0.9315f,0.3132f]}}
particle minecraft:cloud -69.36 65.32 54.11 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -69.51 65.12 55.77 -0.035 0.022 0.015 1 0 force
particle minecraft:cloud -69.51 65.32 55.77 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -69.51 65.42 55.77 0.45 0.2 0.45 0.008 1 force
tp 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 -75.248 65 50.175 -78.73 0
tp f74f363c-8714-5fe5-bb64-beafe6b6ac28 -75.248 65 50.175 -78.73 0
tp 97428e5f-5a51-575c-8305-607c4b0f68cb -75.248 65 50.175 -78.73 0
tp 186c432f-da2b-5bec-ba8a-9d97f056504e -75.248 65 50.175 -78.73 0
tp b7fef3cd-3066-54f8-9318-2747261e9dd9 -75.248 65 50.175 -78.73 0
tp 0d17ad00-82d8-5739-af58-9e93f268e98c -75.248 65 50.175 -78.73 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0.0111f,0.0002f,0.0218f,0.9997f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.1429f,-0.2686f,0.0146f,0.9525f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.0855f,0.9562f,-0.1154f,0.2551f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.2189f,-0.0029f,0.0128f,0.9757f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.0128f,-0.9757f,0.2189f,0.0029f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4069f,0.8373f,0.2691f],left_rotation:[0.1472f,0.1379f,-0.638f,0.7432f]}}
particle minecraft:cloud -78.69 65.32 45.78 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -79.22 65.12 47.41 -0.045 0.022 0.002 1 0 force
particle minecraft:cloud -79.22 65.32 47.41 0.35 0.18 0.35 0.02 3 force
