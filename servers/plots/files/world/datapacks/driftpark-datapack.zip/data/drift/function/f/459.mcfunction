tp 425483f9-2934-53dd-805b-82336df4bdbc -96.478 65 -5.988 -26.39 0
tp 77d4edec-4f89-5806-8a73-69da291cf64a -96.478 65 -5.988 -26.39 0
tp a18c987f-26df-590a-b51c-8f6379e10218 -96.478 65 -5.988 -26.39 0
tp 8bd36e4e-1a75-51ba-b224-63055ff644c2 -96.478 65 -5.988 -26.39 0
tp 7b07c259-0b81-5b46-b286-5b101f183bf9 -96.478 65 -5.988 -26.39 0
tp 04fc5281-333c-5c0d-ba69-0b625cbc7206 -96.478 65 -5.988 -26.39 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0059f,-0.0001f,0.0179f,0.9998f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.2575f,-0.1646f,0.0104f,0.9521f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.0896f,0.9563f,-0.2416f,0.1384f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.3195f,-0.0042f,0.0124f,0.9475f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.0124f,-0.9475f,0.3195f,0.0042f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4006f,0.8474f,0.0999f],left_rotation:[0.0316f,-0.1823f,0.9737f,0.1328f]}}
particle minecraft:campfire_cosy_smoke -96.61 65.12 -11.74 0.034 0.019 -0.063 1 0 force
particle minecraft:cloud -96.61 65.32 -11.74 0.35 0.18 0.35 0.02 2 force
particle minecraft:cloud -98.12 65.32 -11.01 0.35 0.18 0.35 0.02 2 force
tp 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 -97.579 65 -20.332 -22.31 0
tp f74f363c-8714-5fe5-bb64-beafe6b6ac28 -97.579 65 -20.332 -22.31 0
tp 97428e5f-5a51-575c-8305-607c4b0f68cb -97.579 65 -20.332 -22.31 0
tp 186c432f-da2b-5bec-ba8a-9d97f056504e -97.579 65 -20.332 -22.31 0
tp b7fef3cd-3066-54f8-9318-2747261e9dd9 -97.579 65 -20.332 -22.31 0
tp 0d17ad00-82d8-5739-af58-9e93f268e98c -97.579 65 -20.332 -22.31 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0059f,-0.0001f,0.0177f,0.9998f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.5504f,-0.207f,-0.0766f,0.8052f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.1617f,0.8177f,-0.5317f,0.1503f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.3195f,-0.0042f,0.0124f,0.9475f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.0124f,-0.9475f,0.3195f,0.0042f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4004f,0.8492f,0.2398f],left_rotation:[0.0655f,0.173f,-0.9061f,0.3804f]}}
particle minecraft:campfire_cosy_smoke -96.57 65.12 -25.59 0.045 0.022 -0.068 1 0 force
particle minecraft:cloud -96.57 65.32 -25.59 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud -98.19 65.32 -25.03 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -98.19 65.42 -25.03 0.45 0.2 0.45 0.008 1 force
