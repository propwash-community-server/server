tp 425483f9-2934-53dd-805b-82336df4bdbc -75.534 65 -46.278 46.69 0
tp 77d4edec-4f89-5806-8a73-69da291cf64a -75.534 65 -46.278 46.69 0
tp a18c987f-26df-590a-b51c-8f6379e10218 -75.534 65 -46.278 46.69 0
tp 8bd36e4e-1a75-51ba-b224-63055ff644c2 -75.534 65 -46.278 46.69 0
tp 7b07c259-0b81-5b46-b286-5b101f183bf9 -75.534 65 -46.278 46.69 0
tp 04fc5281-333c-5c0d-ba69-0b625cbc7206 -75.534 65 -46.278 46.69 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0.0041f,0.0001f,0.0223f,0.9997f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.9586f,0.0462f,0.2796f,0.0285f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.2782f,-0.0008f,0.959f,0.0543f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.4166f,-0.0055f,0.0119f,0.909f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.0119f,-0.909f,0.4166f,0.0055f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4079f,0.8418f,0.117f],left_rotation:[0.159f,0.1126f,-0.5307f,0.8249f]}}
particle minecraft:cloud -70.99 65.32 -46.15 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -71.95 65.12 -47.52 0.017 0.022 -0.033 1 0 force
particle minecraft:cloud -71.95 65.32 -47.52 0.35 0.18 0.35 0.02 3 force
tp 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 -64.775 65 -45.422 68.09 0
tp f74f363c-8714-5fe5-bb64-beafe6b6ac28 -64.775 65 -45.422 68.09 0
tp 97428e5f-5a51-575c-8305-607c4b0f68cb -64.775 65 -45.422 68.09 0
tp 186c432f-da2b-5bec-ba8a-9d97f056504e -64.775 65 -45.422 68.09 0
tp b7fef3cd-3066-54f8-9318-2747261e9dd9 -64.775 65 -45.422 68.09 0
tp 0d17ad00-82d8-5739-af58-9e93f268e98c -64.775 65 -45.422 68.09 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0.0019f,0f,0.0223f,0.9998f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.6825f,-0.1664f,0.2487f,0.6668f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.18f,0.6444f,0.7037f,0.2391f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.4166f,-0.0055f,0.0119f,0.909f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.0119f,-0.909f,0.4166f,0.0055f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4079f,0.8417f,0.2533f],left_rotation:[0.1723f,0.0863f,-0.3999f,0.8961f]}}
particle minecraft:cloud -60.41 65.32 -43.61 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -60.86 65.12 -45.26 0.018 0.022 -0.013 1 0 force
particle minecraft:cloud -60.86 65.32 -45.26 0.35 0.18 0.35 0.02 3 force
