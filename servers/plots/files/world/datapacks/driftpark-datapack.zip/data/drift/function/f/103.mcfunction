tp 425483f9-2934-53dd-805b-82336df4bdbc 74.994 65 42.226 -161.02 0
tp 77d4edec-4f89-5806-8a73-69da291cf64a 74.994 65 42.226 -161.02 0
tp a18c987f-26df-590a-b51c-8f6379e10218 74.994 65 42.226 -161.02 0
tp 8bd36e4e-1a75-51ba-b224-63055ff644c2 74.994 65 42.226 -161.02 0
tp 7b07c259-0b81-5b46-b286-5b101f183bf9 74.994 65 42.226 -161.02 0
tp 04fc5281-333c-5c0d-ba69-0b625cbc7206 74.994 65 42.226 -161.02 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0.0029f,0.0001f,0.0223f,0.9997f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.4799f,-0.19f,-0.0455f,0.8553f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.1357f,0.8648f,-0.4626f,0.1406f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.489f,-0.0064f,0.0114f,0.8722f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.0114f,-0.8722f,0.489f,0.0064f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4079f,0.842f,0.115f],left_rotation:[0.0224f,0.1924f,-0.9684f,0.1569f]}}
particle minecraft:campfire_cosy_smoke 70.31 65.12 46.06 -0.084 0.021 0.025 1 0 force
particle minecraft:cloud 70.31 65.32 46.06 0.35 0.18 0.35 0.02 2 force
particle minecraft:cloud 71.84 65.32 46.74 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke 71.84 65.42 46.74 0.45 0.2 0.45 0.008 1 force
tp 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 62.736 65 52.553 -148.18 0
tp f74f363c-8714-5fe5-bb64-beafe6b6ac28 62.736 65 52.553 -148.18 0
tp 97428e5f-5a51-575c-8305-607c4b0f68cb 62.736 65 52.553 -148.18 0
tp 186c432f-da2b-5bec-ba8a-9d97f056504e 62.736 65 52.553 -148.18 0
tp b7fef3cd-3066-54f8-9318-2747261e9dd9 62.736 65 52.553 -148.18 0
tp 0d17ad00-82d8-5739-af58-9e93f268e98c 62.736 65 52.553 -148.18 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0.0064f,0.0001f,0.0223f,0.9997f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.03f,-0.2089f,0.06f,0.9756f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.0422f,0.9747f,0.0521f,0.2132f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.489f,-0.0064f,0.0114f,0.8722f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.0114f,-0.8722f,0.489f,0.0064f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4078f,0.8394f,0.2609f],left_rotation:[0.063f,0.1867f,-0.914f,0.3546f]}}
particle minecraft:campfire_cosy_smoke 56.89 65.12 55.3 -0.093 0.022 0.004 1 0 force
particle minecraft:cloud 56.89 65.32 55.3 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud 58.27 65.32 56.31 0.35 0.18 0.35 0.02 3 force
