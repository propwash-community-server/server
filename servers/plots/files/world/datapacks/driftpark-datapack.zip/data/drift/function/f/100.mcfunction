tp 425483f9-2934-53dd-805b-82336df4bdbc 72.554 65 44.541 -157.37 0
tp 77d4edec-4f89-5806-8a73-69da291cf64a 72.554 65 44.541 -157.37 0
tp a18c987f-26df-590a-b51c-8f6379e10218 72.554 65 44.541 -157.37 0
tp 8bd36e4e-1a75-51ba-b224-63055ff644c2 72.554 65 44.541 -157.37 0
tp 7b07c259-0b81-5b46-b286-5b101f183bf9 72.554 65 44.541 -157.37 0
tp 04fc5281-333c-5c0d-ba69-0b625cbc7206 72.554 65 44.541 -157.37 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0.0023f,0.0001f,0.0223f,0.9997f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.9425f,-0.1029f,-0.1643f,0.2722f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.1938f,0.2909f,-0.9369f,0.0044f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.9605f,-0.0126f,0.0036f,0.2779f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.0036f,-0.2779f,0.9605f,0.0126f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4079f,0.8422f,0.114f],left_rotation:[0.0196f,0.1921f,-0.9708f,0.1427f]}}
particle minecraft:cloud 67.62 65.32 48.14 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke 67.62 65.42 48.14 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke 69.1 65.12 48.9 -0.014 0.021 0.05 1 0 force
particle minecraft:cloud 69.1 65.32 48.9 0.35 0.18 0.35 0.02 2 force
tp 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 59.614 65 54.218 -145.17 0
tp f74f363c-8714-5fe5-bb64-beafe6b6ac28 59.614 65 54.218 -145.17 0
tp 97428e5f-5a51-575c-8305-607c4b0f68cb 59.614 65 54.218 -145.17 0
tp 186c432f-da2b-5bec-ba8a-9d97f056504e 59.614 65 54.218 -145.17 0
tp b7fef3cd-3066-54f8-9318-2747261e9dd9 59.614 65 54.218 -145.17 0
tp 0d17ad00-82d8-5739-af58-9e93f268e98c 59.614 65 54.218 -145.17 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0.0079f,0.0002f,0.0223f,0.9997f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.675f,-0.1886f,-0.1064f,0.7053f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.1811f,0.7204f,-0.6589f,0.1187f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.9605f,-0.0126f,0.0036f,0.2779f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.0036f,-0.2779f,0.9605f,0.0126f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4077f,0.8387f,0.2635f],left_rotation:[0.062f,0.1886f,-0.9166f,0.3471f]}}
particle minecraft:cloud 53.48 65.32 56.7 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 54.8 65.12 57.78 -0.024 0.022 0.058 1 0 force
particle minecraft:cloud 54.8 65.32 57.78 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 54.8 65.42 57.78 0.45 0.2 0.45 0.008 1 force
