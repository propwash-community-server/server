tp 425483f9-2934-53dd-805b-82336df4bdbc 40.973 65 -49.78 68.98 0
tp 77d4edec-4f89-5806-8a73-69da291cf64a 40.973 65 -49.78 68.98 0
tp a18c987f-26df-590a-b51c-8f6379e10218 40.973 65 -49.78 68.98 0
tp 8bd36e4e-1a75-51ba-b224-63055ff644c2 40.973 65 -49.78 68.98 0
tp 7b07c259-0b81-5b46-b286-5b101f183bf9 40.973 65 -49.78 68.98 0
tp 04fc5281-333c-5c0d-ba69-0b625cbc7206 40.973 65 -49.78 68.98 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0.0074f,0.0002f,0.0223f,0.9997f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.9461f,0.0001f,0.2164f,0.2409f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.1923f,0.2195f,0.9513f,0.0993f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.9667f,0.0127f,0.0033f,0.2555f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.0033f,0.2555f,0.9667f,0.0127f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4078f,0.841f,0.1227f],left_rotation:[0.0616f,0.1883f,-0.9171f,0.3459f]}}
particle minecraft:campfire_cosy_smoke 46.42 65.12 -48.42 0.063 0.022 0.053 1 0 force
particle minecraft:cloud 46.42 65.32 -48.42 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud 45.99 65.32 -50.03 0.35 0.18 0.35 0.02 3 force
tp 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 55.621 65 -45.915 86.1 0
tp f74f363c-8714-5fe5-bb64-beafe6b6ac28 55.621 65 -45.915 86.1 0
tp 97428e5f-5a51-575c-8305-607c4b0f68cb 55.621 65 -45.915 86.1 0
tp 186c432f-da2b-5bec-ba8a-9d97f056504e 55.621 65 -45.915 86.1 0
tp b7fef3cd-3066-54f8-9318-2747261e9dd9 55.621 65 -45.915 86.1 0
tp 0d17ad00-82d8-5739-af58-9e93f268e98c 55.621 65 -45.915 86.1 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0.0021f,0f,0.0221f,0.9998f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.6187f,-0.1942f,-0.0898f,0.7559f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.1698f,0.7695f,-0.6017f,0.1303f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.9667f,0.0127f,0.0033f,0.2555f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.0033f,0.2555f,0.9667f,0.0127f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4076f,0.8418f,0.2536f],left_rotation:[0.0558f,0.1846f,-0.9258f,0.3251f]}}
particle minecraft:campfire_cosy_smoke 61.51 65.12 -42.72 0.061 0.022 0.074 1 0 force
particle minecraft:cloud 61.51 65.32 -42.72 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud 61.54 65.32 -44.42 0.35 0.18 0.35 0.02 3 force
