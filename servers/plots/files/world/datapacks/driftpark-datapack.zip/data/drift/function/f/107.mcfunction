tp 425483f9-2934-53dd-805b-82336df4bdbc 77.972 65 38.993 -165.75 0
tp 77d4edec-4f89-5806-8a73-69da291cf64a 77.972 65 38.993 -165.75 0
tp a18c987f-26df-590a-b51c-8f6379e10218 77.972 65 38.993 -165.75 0
tp 8bd36e4e-1a75-51ba-b224-63055ff644c2 77.972 65 38.993 -165.75 0
tp 7b07c259-0b81-5b46-b286-5b101f183bf9 77.972 65 38.993 -165.75 0
tp 04fc5281-333c-5c0d-ba69-0b625cbc7206 77.972 65 38.993 -165.75 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0.0035f,0.0001f,0.0223f,0.9997f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.9802f,-0.0539f,-0.1907f,0.0027f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.1921f,-0.0228f,0.9799f,0.0489f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.9999f,-0.0131f,0f,0.0029f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0f,-0.0029f,0.9999f,0.0131f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4079f,0.8419f,0.116f],left_rotation:[0.0277f,0.1923f,-0.9638f,0.1827f]}}
particle minecraft:campfire_cosy_smoke 73.66 65.12 43.12 -0.069 0.021 0.021 1 0 force
particle minecraft:cloud 73.66 65.32 43.12 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke 73.66 65.42 43.12 0.45 0.2 0.45 0.008 1 force
particle minecraft:cloud 75.24 65.32 43.67 0.35 0.18 0.35 0.02 2 force
tp 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 66.647 65 50.078 -152.62 0
tp f74f363c-8714-5fe5-bb64-beafe6b6ac28 66.647 65 50.078 -152.62 0
tp 97428e5f-5a51-575c-8305-607c4b0f68cb 66.647 65 50.078 -152.62 0
tp 186c432f-da2b-5bec-ba8a-9d97f056504e 66.647 65 50.078 -152.62 0
tp b7fef3cd-3066-54f8-9318-2747261e9dd9 66.647 65 50.078 -152.62 0
tp 0d17ad00-82d8-5739-af58-9e93f268e98c 66.647 65 50.078 -152.62 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0.0019f,0f,0.0223f,0.9998f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.8238f,-0.1584f,-0.1493f,0.5235f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.2052f,0.5421f,-0.8117f,0.0726f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.9999f,-0.0131f,0f,0.0029f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0f,-0.0029f,0.9999f,0.0131f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4079f,0.8418f,0.2532f],left_rotation:[0.0621f,0.1823f,-0.9139f,0.3574f]}}
particle minecraft:campfire_cosy_smoke 61.15 65.12 53.22 -0.087 0.022 0.014 1 0 force
particle minecraft:cloud 61.15 65.32 53.22 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud 62.61 65.32 54.12 0.35 0.18 0.35 0.02 3 force
