tp 425483f9-2934-53dd-805b-82336df4bdbc -56.148 65 60.911 -95.69 0
tp 77d4edec-4f89-5806-8a73-69da291cf64a -56.148 65 60.911 -95.69 0
tp a18c987f-26df-590a-b51c-8f6379e10218 -56.148 65 60.911 -95.69 0
tp 8bd36e4e-1a75-51ba-b224-63055ff644c2 -56.148 65 60.911 -95.69 0
tp 7b07c259-0b81-5b46-b286-5b101f183bf9 -56.148 65 60.911 -95.69 0
tp 04fc5281-333c-5c0d-ba69-0b625cbc7206 -56.148 65 60.911 -95.69 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0059f,-0.0001f,0.0194f,0.9998f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.2605f,-0.1592f,0.099f,0.9471f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0f,0.9419f,0.2787f,0.1874f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.2751f,0.0036f,0.0126f,0.9613f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.0126f,0.9613f,0.2751f,0.0036f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4031f,0.8462f,0.0999f],left_rotation:[0.0079f,0.1849f,-0.9795f,0.0801f]}}
particle minecraft:cloud -61.2 65.32 58.67 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -61.2 65.42 58.67 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke -61.12 65.12 60.34 -0.052 0.021 0.022 1 0 force
particle minecraft:cloud -61.12 65.32 60.34 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -61.12 65.42 60.34 0.45 0.2 0.45 0.008 1 force
tp 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 -68.763 65 55.863 -89.45 0
tp f74f363c-8714-5fe5-bb64-beafe6b6ac28 -68.763 65 55.863 -89.45 0
tp 97428e5f-5a51-575c-8305-607c4b0f68cb -68.763 65 55.863 -89.45 0
tp 186c432f-da2b-5bec-ba8a-9d97f056504e -68.763 65 55.863 -89.45 0
tp b7fef3cd-3066-54f8-9318-2747261e9dd9 -68.763 65 55.863 -89.45 0
tp 0d17ad00-82d8-5739-af58-9e93f268e98c -68.763 65 55.863 -89.45 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0054f,-0.0001f,0.0221f,0.9997f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.2313f,-0.2246f,0.1109f,0.9401f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.0127f,0.9336f,0.2562f,0.2502f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.2751f,0.0036f,0.0126f,0.9613f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.0126f,0.9613f,0.2751f,0.0036f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4078f,0.8454f,0.2406f],left_rotation:[0.1109f,0.1487f,-0.761f,0.6216f]}}
particle minecraft:cloud -72.81 65.32 52.68 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -72.95 65.12 54.39 -0.032 0.022 0.014 1 0 force
particle minecraft:cloud -72.95 65.32 54.39 0.35 0.18 0.35 0.02 3 force
