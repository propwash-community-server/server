tp 425483f9-2934-53dd-805b-82336df4bdbc -53.746 65 -36.812 102.69 0
tp 77d4edec-4f89-5806-8a73-69da291cf64a -53.746 65 -36.812 102.69 0
tp a18c987f-26df-590a-b51c-8f6379e10218 -53.746 65 -36.812 102.69 0
tp 8bd36e4e-1a75-51ba-b224-63055ff644c2 -53.746 65 -36.812 102.69 0
tp 7b07c259-0b81-5b46-b286-5b101f183bf9 -53.746 65 -36.812 102.69 0
tp 04fc5281-333c-5c0d-ba69-0b625cbc7206 -53.746 65 -36.812 102.69 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0.0058f,0.0001f,0.0156f,0.9999f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.9736f,0.0411f,0.2173f,0.0566f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.2126f,0.034f,0.9746f,0.061f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.0928f,-0.0012f,0.013f,0.9956f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.013f,-0.9956f,0.0928f,0.0012f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.3965f,0.8468f,0.1199f],left_rotation:[0.0707f,0.1833f,-0.9034f,0.3811f]}}
particle minecraft:campfire_cosy_smoke -50.14 65.12 -32.42 0.02 0.022 0.068 1 0 force
particle minecraft:cloud -50.14 65.32 -32.42 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud -49.5 65.32 -33.96 0.35 0.18 0.35 0.02 3 force
tp 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 -45.021 65 -25.76 140.41 0
tp f74f363c-8714-5fe5-bb64-beafe6b6ac28 -45.021 65 -25.76 140.41 0
tp 97428e5f-5a51-575c-8305-607c4b0f68cb -45.021 65 -25.76 140.41 0
tp 186c432f-da2b-5bec-ba8a-9d97f056504e -45.021 65 -25.76 140.41 0
tp b7fef3cd-3066-54f8-9318-2747261e9dd9 -45.021 65 -25.76 140.41 0
tp 0d17ad00-82d8-5739-af58-9e93f268e98c -45.021 65 -25.76 140.41 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0059f,0.0001f,-0.009f,0.9999f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.9483f,-0.0354f,0.0603f,0.3096f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.0281f,-0.3049f,0.9498f,0.0641f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.0928f,-0.0012f,0.013f,0.9956f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.013f,-0.9956f,0.0928f,0.0012f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.3544f,0.8694f,0.2398f],left_rotation:[0.1697f,0.0738f,-0.4082f,0.894f]}}
