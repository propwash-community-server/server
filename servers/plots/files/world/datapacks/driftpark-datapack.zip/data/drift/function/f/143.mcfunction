tp 425483f9-2934-53dd-805b-82336df4bdbc 90.219 65 4.11 152.66 0
tp 77d4edec-4f89-5806-8a73-69da291cf64a 90.219 65 4.11 152.66 0
tp a18c987f-26df-590a-b51c-8f6379e10218 90.219 65 4.11 152.66 0
tp 8bd36e4e-1a75-51ba-b224-63055ff644c2 90.219 65 4.11 152.66 0
tp 7b07c259-0b81-5b46-b286-5b101f183bf9 90.219 65 4.11 152.66 0
tp 04fc5281-333c-5c0d-ba69-0b625cbc7206 90.219 65 4.11 152.66 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0.0001f,0f,0.0223f,0.9998f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.9772f,0.0378f,0.1933f,0.0792f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.186f,0.0593f,0.9786f,0.0647f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.9964f,0.013f,0.0011f,0.0841f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.0011f,0.0841f,0.9964f,0.013f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4079f,0.8427f,0.1101f],left_rotation:[0.0249f,0.1892f,-0.9666f,0.1712f]}}
particle minecraft:campfire_cosy_smoke 89.76 65.12 9.9 -0.038 0.021 0.071 1 0 force
particle minecraft:cloud 89.76 65.32 9.9 0.35 0.18 0.35 0.02 2 force
particle minecraft:cloud 91.3 65.32 9.26 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke 91.3 65.42 9.26 0.45 0.2 0.45 0.008 1 force
tp 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 89.329 65 19.122 165.12 0
tp f74f363c-8714-5fe5-bb64-beafe6b6ac28 89.329 65 19.122 165.12 0
tp 97428e5f-5a51-575c-8305-607c4b0f68cb 89.329 65 19.122 165.12 0
tp 186c432f-da2b-5bec-ba8a-9d97f056504e 89.329 65 19.122 165.12 0
tp b7fef3cd-3066-54f8-9318-2747261e9dd9 89.329 65 19.122 165.12 0
tp 0d17ad00-82d8-5739-af58-9e93f268e98c 89.329 65 19.122 165.12 0
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.7625f,-0.1783f,-0.1381f,0.6064f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.2025f,0.6242f,-0.748f,0.0992f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.9964f,0.013f,0.0011f,0.0841f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.0011f,0.0841f,0.9964f,0.013f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4079f,0.8436f,0.2469f],left_rotation:[0.0741f,0.1739f,-0.8853f,0.4249f]}}
particle minecraft:campfire_cosy_smoke 87.41 65.12 24.69 -0.062 0.022 0.067 1 0 force
particle minecraft:cloud 87.41 65.32 24.69 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 87.41 65.42 24.69 0.45 0.2 0.45 0.008 1 force
particle minecraft:cloud 89.09 65.32 24.37 0.35 0.18 0.35 0.02 3 force
