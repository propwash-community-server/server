tp 425483f9-2934-53dd-805b-82336df4bdbc 9.076 65 63.567 -93.54 0
tp 77d4edec-4f89-5806-8a73-69da291cf64a 9.076 65 63.567 -93.54 0
tp a18c987f-26df-590a-b51c-8f6379e10218 9.076 65 63.567 -93.54 0
tp 8bd36e4e-1a75-51ba-b224-63055ff644c2 9.076 65 63.567 -93.54 0
tp 7b07c259-0b81-5b46-b286-5b101f183bf9 9.076 65 63.567 -93.54 0
tp 04fc5281-333c-5c0d-ba69-0b625cbc7206 9.076 65 63.567 -93.54 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0f,0f,0.0025f,1f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.4039f,0.016f,0.0501f,0.9133f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.0456f,0.9131f,0.4044f,0.0263f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.4007f,0.0052f,0.012f,0.9161f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.012f,0.9161f,0.4007f,0.0052f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.3743f,0.8581f,0.11f],left_rotation:[0.1906f,-0.0092f,0.0521f,0.9802f]}}
tp 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 -9.119 65 63.848 -90.81 0
tp f74f363c-8714-5fe5-bb64-beafe6b6ac28 -9.119 65 63.848 -90.81 0
tp 97428e5f-5a51-575c-8305-607c4b0f68cb -9.119 65 63.848 -90.81 0
tp 186c432f-da2b-5bec-ba8a-9d97f056504e -9.119 65 63.848 -90.81 0
tp b7fef3cd-3066-54f8-9318-2747261e9dd9 -9.119 65 63.848 -90.81 0
tp 0d17ad00-82d8-5739-af58-9e93f268e98c -9.119 65 63.848 -90.81 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0f,0f,-0.0016f,1f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.612f,0.0383f,0.0365f,0.7891f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.0462f,0.7896f,0.6114f,0.0258f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.4007f,0.0052f,0.012f,0.9161f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.012f,0.9161f,0.4007f,0.0052f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.3673f,0.8612f,0.25f],left_rotation:[0.1903f,0.0132f,-0.0712f,0.979f]}}
