tp 425483f9-2934-53dd-805b-82336df4bdbc -74.057 65 -46.291 50.78 0
tp 77d4edec-4f89-5806-8a73-69da291cf64a -74.057 65 -46.291 50.78 0
tp a18c987f-26df-590a-b51c-8f6379e10218 -74.057 65 -46.291 50.78 0
tp 8bd36e4e-1a75-51ba-b224-63055ff644c2 -74.057 65 -46.291 50.78 0
tp 7b07c259-0b81-5b46-b286-5b101f183bf9 -74.057 65 -46.291 50.78 0
tp 04fc5281-333c-5c0d-ba69-0b625cbc7206 -74.057 65 -46.291 50.78 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0.0028f,0.0001f,0.0223f,0.9997f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.6739f,-0.2334f,-0.1536f,0.6839f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.2263f,0.7039f,-0.6531f,0.1639f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.0986f,0.0013f,0.013f,0.995f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.013f,0.995f,0.0986f,0.0013f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4079f,0.8421f,0.1148f],left_rotation:[0.1536f,0.1178f,-0.5617f,0.8043f]}}
particle minecraft:cloud -69.49 65.32 -45.89 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -70.35 65.12 -47.32 0.011 0.022 -0.026 1 0 force
particle minecraft:cloud -70.35 65.32 -47.32 0.35 0.18 0.35 0.02 3 force
tp 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 -63.373 65 -44.857 71.1 0
tp f74f363c-8714-5fe5-bb64-beafe6b6ac28 -63.373 65 -44.857 71.1 0
tp 97428e5f-5a51-575c-8305-607c4b0f68cb -63.373 65 -44.857 71.1 0
tp 186c432f-da2b-5bec-ba8a-9d97f056504e -63.373 65 -44.857 71.1 0
tp b7fef3cd-3066-54f8-9318-2747261e9dd9 -63.373 65 -44.857 71.1 0
tp 0d17ad00-82d8-5739-af58-9e93f268e98c -63.373 65 -44.857 71.1 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0.0049f,0.0001f,0.0223f,0.9997f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.9499f,-0.0785f,-0.2928f,0.0761f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.3024f,-0.1073f,0.9469f,0.0209f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.0986f,0.0013f,0.013f,0.995f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.013f,0.995f,0.0986f,0.0013f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4078f,0.8402f,0.2585f],left_rotation:[0.1781f,0.081f,-0.3661f,0.9098f]}}
particle minecraft:cloud -59.06 65.32 -42.78 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -59.43 65.12 -44.45 0.028 0.022 -0.026 1 0 force
particle minecraft:cloud -59.43 65.32 -44.45 0.35 0.18 0.35 0.02 3 force
