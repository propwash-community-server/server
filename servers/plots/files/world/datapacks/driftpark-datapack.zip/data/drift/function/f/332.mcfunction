tp 425483f9-2934-53dd-805b-82336df4bdbc -34.808 65 -15.563 157.77 0
tp 77d4edec-4f89-5806-8a73-69da291cf64a -34.808 65 -15.563 157.77 0
tp a18c987f-26df-590a-b51c-8f6379e10218 -34.808 65 -15.563 157.77 0
tp 8bd36e4e-1a75-51ba-b224-63055ff644c2 -34.808 65 -15.563 157.77 0
tp 7b07c259-0b81-5b46-b286-5b101f183bf9 -34.808 65 -15.563 157.77 0
tp 04fc5281-333c-5c0d-ba69-0b625cbc7206 -34.808 65 -15.563 157.77 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0031f,0.0001f,-0.0222f,0.9997f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.0651f,0.2313f,0.0695f,0.9682f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.0318f,-0.9662f,0.0898f,0.2395f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.2415f,0.0032f,0.0127f,0.9703f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.0127f,0.9703f,0.2415f,0.0032f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.3314f,0.8763f,0.1046f],left_rotation:[0.099f,-0.1595f,0.8106f,0.5547f]}}
particle minecraft:cloud -32.45 65.32 -12.6 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -32.45 65.42 -12.6 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke -30.95 65.12 -13.34 0.073 0.022 -0.001 1 0 force
particle minecraft:cloud -30.95 65.32 -13.34 0.35 0.18 0.35 0.02 3 force
tp 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 -25.523 65 -10.606 143.75 0
tp f74f363c-8714-5fe5-bb64-beafe6b6ac28 -25.523 65 -10.606 143.75 0
tp 97428e5f-5a51-575c-8305-607c4b0f68cb -25.523 65 -10.606 143.75 0
tp 186c432f-da2b-5bec-ba8a-9d97f056504e -25.523 65 -10.606 143.75 0
tp b7fef3cd-3066-54f8-9318-2747261e9dd9 -25.523 65 -10.606 143.75 0
tp 0d17ad00-82d8-5739-af58-9e93f268e98c -25.523 65 -10.606 143.75 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0033f,0.0001f,-0.0223f,0.9997f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.1051f,0.2855f,0.0867f,0.9486f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.0125f,-0.9448f,0.1357f,0.2981f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.2415f,0.0032f,0.0127f,0.9703f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.0127f,0.9703f,0.2415f,0.0032f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.3313f,0.8772f,0.2444f],left_rotation:[0.167f,-0.0854f,0.4078f,0.8936f]}}
particle minecraft:cloud -22.22 65.32 -8.66 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -20.94 65.12 -9.8 0.074 0.022 -0.031 1 0 force
particle minecraft:cloud -20.94 65.32 -9.8 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -20.94 65.42 -9.8 0.45 0.2 0.45 0.008 1 force
particle minecraft:flame -20.71 65.24 -8.53 0.05 0.04 0.05 0.02 6 force
particle minecraft:large_smoke -20.71 65.24 -8.53 0.05 0.04 0.05 0.01 2 force
particle minecraft:flame -20.98 65.24 -8.29 0.05 0.04 0.05 0.02 6 force
particle minecraft:large_smoke -20.98 65.24 -8.29 0.05 0.04 0.05 0.01 2 force
