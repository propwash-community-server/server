tp 425483f9-2934-53dd-805b-82336df4bdbc -94.332 65 -30.543 -8.74 0
tp 77d4edec-4f89-5806-8a73-69da291cf64a -94.332 65 -30.543 -8.74 0
tp a18c987f-26df-590a-b51c-8f6379e10218 -94.332 65 -30.543 -8.74 0
tp 8bd36e4e-1a75-51ba-b224-63055ff644c2 -94.332 65 -30.543 -8.74 0
tp 7b07c259-0b81-5b46-b286-5b101f183bf9 -94.332 65 -30.543 -8.74 0
tp 04fc5281-333c-5c0d-ba69-0b625cbc7206 -94.332 65 -30.543 -8.74 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0058f,-0.0001f,0.0183f,0.9998f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.6008f,-0.1327f,0.1715f,0.7694f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.0916f,0.7556f,0.618f,0.1966f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.2583f,0.0034f,0.0126f,0.966f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.0126f,0.966f,0.2583f,0.0034f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4012f,0.8471f,0.1f],left_rotation:[0.0591f,0.1754f,-0.9192f,0.3475f]}}
particle minecraft:campfire_cosy_smoke -92.38 65.12 -34.79 0.059 0.022 -0.034 1 0 force
particle minecraft:cloud -92.38 65.32 -34.79 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -92.38 65.42 -34.79 0.45 0.2 0.45 0.008 1 force
particle minecraft:cloud -94.04 65.32 -34.62 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -94.04 65.42 -34.62 0.45 0.2 0.45 0.008 1 force
tp 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 -90.043 65 -40.276 -3.1 0
tp f74f363c-8714-5fe5-bb64-beafe6b6ac28 -90.043 65 -40.276 -3.1 0
tp 97428e5f-5a51-575c-8305-607c4b0f68cb -90.043 65 -40.276 -3.1 0
tp 186c432f-da2b-5bec-ba8a-9d97f056504e -90.043 65 -40.276 -3.1 0
tp b7fef3cd-3066-54f8-9318-2747261e9dd9 -90.043 65 -40.276 -3.1 0
tp 0d17ad00-82d8-5739-af58-9e93f268e98c -90.043 65 -40.276 -3.1 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0058f,-0.0001f,0.0221f,0.9997f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.4493f,-0.2333f,0.1866f,0.8419f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.0991f,0.827f,0.4763f,0.2818f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.2583f,0.0034f,0.0126f,0.966f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.0126f,0.966f,0.2583f,0.0034f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4078f,0.8457f,0.24f],left_rotation:[0.1651f,0.0837f,-0.4051f,0.8954f]}}
particle minecraft:campfire_cosy_smoke -87.23 65.12 -43.5 0.07 0.022 -0.026 1 0 force
particle minecraft:cloud -87.23 65.32 -43.5 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud -88.94 65.32 -43.56 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -88.94 65.42 -43.56 0.45 0.2 0.45 0.008 1 force
