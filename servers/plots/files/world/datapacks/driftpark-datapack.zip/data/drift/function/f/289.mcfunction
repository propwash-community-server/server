tp 425483f9-2934-53dd-805b-82336df4bdbc -6.871 65 -15.899 92.26 0
tp 77d4edec-4f89-5806-8a73-69da291cf64a -6.871 65 -15.899 92.26 0
tp a18c987f-26df-590a-b51c-8f6379e10218 -6.871 65 -15.899 92.26 0
tp 8bd36e4e-1a75-51ba-b224-63055ff644c2 -6.871 65 -15.899 92.26 0
tp 7b07c259-0b81-5b46-b286-5b101f183bf9 -6.871 65 -15.899 92.26 0
tp 04fc5281-333c-5c0d-ba69-0b625cbc7206 -6.871 65 -15.899 92.26 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0.0113f,-0.0002f,-0.0221f,0.9997f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.4887f,0.2792f,-0.1027f,0.8202f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.1894f,-0.8355f,-0.4621f,0.2294f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.5726f,0.0075f,0.0107f,0.8197f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.0107f,0.8197f,0.5726f,0.0075f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.3317f,0.8728f,0.1293f],left_rotation:[0.1789f,-0.0934f,0.4144f,0.8874f]}}
particle minecraft:campfire_cosy_smoke -3.15 65.12 -17.58 0.025 0.022 0.016 1 0 force
particle minecraft:cloud -3.15 65.32 -17.58 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud -3.33 65.32 -19.24 0.35 0.18 0.35 0.02 3 force
tp 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 1.675 65 -25.341 63.61 0
tp f74f363c-8714-5fe5-bb64-beafe6b6ac28 1.675 65 -25.341 63.61 0
tp 97428e5f-5a51-575c-8305-607c4b0f68cb 1.675 65 -25.341 63.61 0
tp 186c432f-da2b-5bec-ba8a-9d97f056504e 1.675 65 -25.341 63.61 0
tp b7fef3cd-3066-54f8-9318-2747261e9dd9 1.675 65 -25.341 63.61 0
tp 0d17ad00-82d8-5739-af58-9e93f268e98c 1.675 65 -25.341 63.61 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0058f,0f,-0.0065f,1f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.9809f,0.0604f,-0.1807f,0.0386f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.1857f,0.0578f,0.98f,0.0424f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.5726f,0.0075f,0.0107f,0.8197f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.0107f,0.8197f,0.5726f,0.0075f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.3587f,0.8676f,0.24f],left_rotation:[0.0158f,-0.1844f,0.978f,0.0966f]}}
particle minecraft:campfire_cosy_smoke 4.78 65.12 -28.97 0.039 0.02 -0.002 1 0 force
particle minecraft:cloud 4.78 65.32 -28.97 0.35 0.18 0.35 0.02 2 force
particle minecraft:cloud 3.68 65.32 -30.29 0.35 0.18 0.35 0.02 2 force
