tp 425483f9-2934-53dd-805b-82336df4bdbc 80.618 65 35.623 -170.94 0
tp 77d4edec-4f89-5806-8a73-69da291cf64a 80.618 65 35.623 -170.94 0
tp a18c987f-26df-590a-b51c-8f6379e10218 80.618 65 35.623 -170.94 0
tp 8bd36e4e-1a75-51ba-b224-63055ff644c2 80.618 65 35.623 -170.94 0
tp 7b07c259-0b81-5b46-b286-5b101f183bf9 80.618 65 35.623 -170.94 0
tp 04fc5281-333c-5c0d-ba69-0b625cbc7206 80.618 65 35.623 -170.94 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0.0038f,0.0001f,0.0223f,0.9997f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.4841f,-0.1423f,0.1423f,0.8516f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.0536f,0.8413f,0.5017f,0.194f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.4941f,0.0065f,0.0114f,0.8693f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.0114f,0.8693f,0.4941f,0.0065f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4079f,0.8418f,0.1165f],left_rotation:[0.0333f,0.1917f,-0.958f,0.2106f]}}
particle minecraft:campfire_cosy_smoke 76.72 65.12 40 -0.082 0.022 0.035 1 0 force
particle minecraft:cloud 76.72 65.32 40 0.35 0.18 0.35 0.02 2 force
particle minecraft:cloud 78.34 65.32 40.41 0.35 0.18 0.35 0.02 2 force
tp 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 70.404 65 47.32 -157.05 0
tp f74f363c-8714-5fe5-bb64-beafe6b6ac28 70.404 65 47.32 -157.05 0
tp 97428e5f-5a51-575c-8305-607c4b0f68cb 70.404 65 47.32 -157.05 0
tp 186c432f-da2b-5bec-ba8a-9d97f056504e 70.404 65 47.32 -157.05 0
tp b7fef3cd-3066-54f8-9318-2747261e9dd9 70.404 65 47.32 -157.05 0
tp 0d17ad00-82d8-5739-af58-9e93f268e98c 70.404 65 47.32 -157.05 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0.0015f,0f,0.0223f,0.9998f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.8703f,-0.0481f,0.2133f,0.4414f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.1681f,0.4214f,0.8801f,0.1398f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.4941f,0.0065f,0.0114f,0.8693f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.0114f,0.8693f,0.4941f,0.0065f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4079f,0.8419f,0.2527f],left_rotation:[0.0637f,0.1815f,-0.9106f,0.3659f]}}
particle minecraft:campfire_cosy_smoke 65.17 65.12 50.84 -0.089 0.022 0.016 1 0 force
particle minecraft:cloud 65.17 65.32 50.84 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud 66.69 65.32 51.62 0.35 0.18 0.35 0.02 3 force
