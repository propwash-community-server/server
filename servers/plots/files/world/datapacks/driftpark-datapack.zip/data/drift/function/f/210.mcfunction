tp 425483f9-2934-53dd-805b-82336df4bdbc 45.879 65 -48.786 76.54 0
tp 77d4edec-4f89-5806-8a73-69da291cf64a 45.879 65 -48.786 76.54 0
tp a18c987f-26df-590a-b51c-8f6379e10218 45.879 65 -48.786 76.54 0
tp 8bd36e4e-1a75-51ba-b224-63055ff644c2 45.879 65 -48.786 76.54 0
tp 7b07c259-0b81-5b46-b286-5b101f183bf9 45.879 65 -48.786 76.54 0
tp 04fc5281-333c-5c0d-ba69-0b625cbc7206 45.879 65 -48.786 76.54 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0.0098f,0.0002f,0.0223f,0.9997f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.8591f,-0.0487f,0.2009f,0.4682f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.1528f,0.4497f,0.869f,0.1392f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.8736f,0.0114f,0.0064f,0.4865f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.0064f,0.4865f,0.8736f,0.0114f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4078f,0.8404f,0.1268f],left_rotation:[0.0445f,0.1954f,-0.9446f,0.26f]}}
particle minecraft:cloud 51.44 65.32 -46.74 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 51.44 65.42 -46.74 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke 51.22 65.12 -48.39 0.045 0.022 -0.018 1 0 force
particle minecraft:cloud 51.22 65.32 -48.39 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 51.22 65.42 -48.39 0.45 0.2 0.45 0.008 1 force
tp 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 61.326 65 -43.079 92.49 0
tp f74f363c-8714-5fe5-bb64-beafe6b6ac28 61.326 65 -43.079 92.49 0
tp 97428e5f-5a51-575c-8305-607c4b0f68cb 61.326 65 -43.079 92.49 0
tp 186c432f-da2b-5bec-ba8a-9d97f056504e 61.326 65 -43.079 92.49 0
tp b7fef3cd-3066-54f8-9318-2747261e9dd9 61.326 65 -43.079 92.49 0
tp 0d17ad00-82d8-5739-af58-9e93f268e98c 61.326 65 -43.079 92.49 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0059f,-0.0001f,0.0222f,0.9997f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.8026f,-0.1582f,-0.1335f,0.5595f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.193f,0.5766f,-0.7904f,0.0747f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.8736f,0.0114f,0.0064f,0.4865f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.0064f,0.4865f,0.8736f,0.0114f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.408f,0.8456f,0.2399f],left_rotation:[0.0416f,0.1803f,-0.9469f,0.2631f]}}
particle minecraft:cloud 66.74 65.32 -39.49 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke 66.74 65.42 -39.49 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke 66.93 65.12 -41.19 0.059 0.022 -0.001 1 0 force
particle minecraft:cloud 66.93 65.32 -41.19 0.35 0.18 0.35 0.02 2 force
