tp 425483f9-2934-53dd-805b-82336df4bdbc -93.455 65 -32.793 -7 0
tp 77d4edec-4f89-5806-8a73-69da291cf64a -93.455 65 -32.793 -7 0
tp a18c987f-26df-590a-b51c-8f6379e10218 -93.455 65 -32.793 -7 0
tp 8bd36e4e-1a75-51ba-b224-63055ff644c2 -93.455 65 -32.793 -7 0
tp 7b07c259-0b81-5b46-b286-5b101f183bf9 -93.455 65 -32.793 -7 0
tp 04fc5281-333c-5c0d-ba69-0b625cbc7206 -93.455 65 -32.793 -7 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0058f,-0.0001f,0.0191f,0.9998f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.2624f,-0.1991f,0.1115f,0.9376f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.0135f,0.931f,0.2848f,0.2278f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.4941f,-0.0065f,0.0114f,0.8693f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.0114f,-0.8693f,0.4941f,0.0065f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4027f,0.8464f,0.1f],left_rotation:[0.0774f,0.1681f,-0.8763f,0.4448f]}}
particle minecraft:cloud -91.31 65.32 -36.81 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -92.98 65.12 -36.7 -0.015 0.022 -0.031 1 0 force
particle minecraft:cloud -92.98 65.32 -36.7 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -92.98 65.42 -36.7 0.45 0.2 0.45 0.008 1 force
tp 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 -88.653 65 -41.796 0.08 0
tp f74f363c-8714-5fe5-bb64-beafe6b6ac28 -88.653 65 -41.796 0.08 0
tp 97428e5f-5a51-575c-8305-607c4b0f68cb -88.653 65 -41.796 0.08 0
tp 186c432f-da2b-5bec-ba8a-9d97f056504e -88.653 65 -41.796 0.08 0
tp b7fef3cd-3066-54f8-9318-2747261e9dd9 -88.653 65 -41.796 0.08 0
tp 0d17ad00-82d8-5739-af58-9e93f268e98c -88.653 65 -41.796 0.08 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0051f,-0.0001f,0.0222f,0.9997f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.6894f,-0.1657f,0.2529f,0.6583f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.1851f,0.6353f,0.7106f,0.2391f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.4941f,-0.0065f,0.0114f,0.8693f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.0114f,-0.8693f,0.4941f,0.0065f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.408f,0.8452f,0.2413f],left_rotation:[0.1686f,0.0782f,-0.3735f,0.9088f]}}
particle minecraft:cloud -85.63 65.32 -44.67 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -87.33 65.12 -44.87 -0.01 0.022 -0.018 1 0 force
particle minecraft:cloud -87.33 65.32 -44.87 0.35 0.18 0.35 0.02 3 force
