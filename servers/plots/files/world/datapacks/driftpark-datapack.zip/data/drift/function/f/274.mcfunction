tp 425483f9-2934-53dd-805b-82336df4bdbc 1.606 65 -26.479 56.58 0
tp 77d4edec-4f89-5806-8a73-69da291cf64a 1.606 65 -26.479 56.58 0
tp a18c987f-26df-590a-b51c-8f6379e10218 1.606 65 -26.479 56.58 0
tp 8bd36e4e-1a75-51ba-b224-63055ff644c2 1.606 65 -26.479 56.58 0
tp 7b07c259-0b81-5b46-b286-5b101f183bf9 1.606 65 -26.479 56.58 0
tp 04fc5281-333c-5c0d-ba69-0b625cbc7206 1.606 65 -26.479 56.58 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0058f,0f,-0.0043f,1f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.2001f,0.1253f,0.0799f,0.9684f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.0215f,-0.9654f,0.2144f,0.147f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.1389f,-0.0018f,0.013f,0.9902f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.013f,-0.9902f,0.1389f,0.0018f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.3625f,0.8644f,0.1f],left_rotation:[0.0575f,0.1759f,-0.9367f,0.2972f]}}
particle minecraft:cloud 4.91 65.32 -29.98 0.35 0.18 0.35 0.02 1 force
particle minecraft:campfire_cosy_smoke 3.72 65.12 -31.14 -0.016 0.017 -0.061 1 0 force
particle minecraft:cloud 3.72 65.32 -31.14 0.35 0.18 0.35 0.02 1 force
tp 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 6.94 65 -37.496 10.36 0
tp f74f363c-8714-5fe5-bb64-beafe6b6ac28 6.94 65 -37.496 10.36 0
tp 97428e5f-5a51-575c-8305-607c4b0f68cb 6.94 65 -37.496 10.36 0
tp 186c432f-da2b-5bec-ba8a-9d97f056504e 6.94 65 -37.496 10.36 0
tp b7fef3cd-3066-54f8-9318-2747261e9dd9 6.94 65 -37.496 10.36 0
tp 0d17ad00-82d8-5739-af58-9e93f268e98c 6.94 65 -37.496 10.36 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0058f,-0.0001f,0.0184f,0.9998f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.9754f,0.0387f,0.205f,0.0709f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.1987f,0.0497f,0.9767f,0.0636f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.1389f,-0.0018f,0.013f,0.9902f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.013f,-0.9902f,0.1389f,0.0018f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4015f,0.8487f,0.2399f],left_rotation:[0.0451f,0.1795f,-0.9437f,0.2743f]}}
particle minecraft:cloud 9.9 65.32 -41.24 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 8.21 65.12 -41.46 -0.012 0.022 -0.043 1 0 force
particle minecraft:cloud 8.21 65.32 -41.46 0.35 0.18 0.35 0.02 3 force
