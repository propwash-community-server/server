tp 425483f9-2934-53dd-805b-82336df4bdbc -78.063 65 45.035 -64.87 0
tp 77d4edec-4f89-5806-8a73-69da291cf64a -78.063 65 45.035 -64.87 0
tp a18c987f-26df-590a-b51c-8f6379e10218 -78.063 65 45.035 -64.87 0
tp 8bd36e4e-1a75-51ba-b224-63055ff644c2 -78.063 65 45.035 -64.87 0
tp 7b07c259-0b81-5b46-b286-5b101f183bf9 -78.063 65 45.035 -64.87 0
tp 04fc5281-333c-5c0d-ba69-0b625cbc7206 -78.063 65 45.035 -64.87 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0.0111f,0.0002f,0.0188f,0.9998f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.8937f,-0.1339f,-0.1719f,0.3922f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.2141f,0.4125f,-0.8845f,0.0407f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.9388f,-0.0123f,0.0045f,0.3441f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.0045f,-0.3441f,0.9388f,0.0123f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.402f,0.8428f,0.1291f],left_rotation:[0.0662f,0.1906f,-0.9125f,0.356f]}}
particle minecraft:cloud -80.9 65.32 39.88 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -81.81 65.12 41.28 -0.043 0.022 -0.01 1 0 force
particle minecraft:cloud -81.81 65.32 41.28 0.35 0.18 0.35 0.02 3 force
tp 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 -85.862 65 30.745 -39.23 0
tp f74f363c-8714-5fe5-bb64-beafe6b6ac28 -85.862 65 30.745 -39.23 0
tp 97428e5f-5a51-575c-8305-607c4b0f68cb -85.862 65 30.745 -39.23 0
tp 186c432f-da2b-5bec-ba8a-9d97f056504e -85.862 65 30.745 -39.23 0
tp b7fef3cd-3066-54f8-9318-2747261e9dd9 -85.862 65 30.745 -39.23 0
tp 0d17ad00-82d8-5739-af58-9e93f268e98c -85.862 65 30.745 -39.23 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0.0004f,0f,0.0113f,0.9999f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.9422f,-0.0792f,-0.0704f,0.3177f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.1042f,-0.3269f,0.9391f,0.0194f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.9388f,-0.0123f,0.0045f,0.3441f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.0045f,-0.3441f,0.9388f,0.0123f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.3893f,0.8512f,0.2507f],left_rotation:[0.1302f,-0.14f,0.7338f,0.6519f]}}
particle minecraft:campfire_cosy_smoke -89.31 65.12 25.2 -0.062 0.014 -0.048 1 0 force
