tp 425483f9-2934-53dd-805b-82336df4bdbc 3.417 65 -29.684 44.53 0
tp 77d4edec-4f89-5806-8a73-69da291cf64a 3.417 65 -29.684 44.53 0
tp a18c987f-26df-590a-b51c-8f6379e10218 3.417 65 -29.684 44.53 0
tp 8bd36e4e-1a75-51ba-b224-63055ff644c2 3.417 65 -29.684 44.53 0
tp 7b07c259-0b81-5b46-b286-5b101f183bf9 3.417 65 -29.684 44.53 0
tp 04fc5281-333c-5c0d-ba69-0b625cbc7206 3.417 65 -29.684 44.53 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0059f,0f,0.0036f,1f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.748f,0.0704f,-0.0006f,0.6599f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.0699f,0.6636f,0.7447f,0.0079f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.794f,0.0104f,0.008f,0.6077f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.008f,0.6077f,0.794f,0.0104f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.3762f,0.8585f,0.0999f],left_rotation:[0.1683f,0.0769f,-0.4017f,0.8969f]}}
particle minecraft:flame 5.95 65.22 -34.97 0.05 0.04 0.05 0.02 6 force
particle minecraft:large_smoke 5.95 65.22 -34.97 0.05 0.04 0.05 0.01 2 force
tp 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 8.822 65 -40.072 5.66 0
tp f74f363c-8714-5fe5-bb64-beafe6b6ac28 8.822 65 -40.072 5.66 0
tp 97428e5f-5a51-575c-8305-607c4b0f68cb 8.822 65 -40.072 5.66 0
tp 186c432f-da2b-5bec-ba8a-9d97f056504e 8.822 65 -40.072 5.66 0
tp b7fef3cd-3066-54f8-9318-2747261e9dd9 8.822 65 -40.072 5.66 0
tp 0d17ad00-82d8-5739-af58-9e93f268e98c 8.822 65 -40.072 5.66 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0046f,-0.0001f,0.0215f,0.9998f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.1569f,-0.2338f,0.0931f,0.955f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.0067f,0.9505f,0.1823f,0.2516f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.794f,0.0104f,0.008f,0.6077f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.008f,0.6077f,0.794f,0.0104f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4068f,0.8455f,0.2422f],left_rotation:[0.1131f,0.1481f,-0.7544f,0.6295f]}}
particle minecraft:cloud 11.93 65.32 -43.48 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 10.24 65.12 -43.7 -0.008 0.022 -0.028 1 0 force
particle minecraft:cloud 10.24 65.32 -43.7 0.35 0.18 0.35 0.02 3 force
