tp 425483f9-2934-53dd-805b-82336df4bdbc -79.183 65 43.294 -60.91 0
tp 77d4edec-4f89-5806-8a73-69da291cf64a -79.183 65 43.294 -60.91 0
tp a18c987f-26df-590a-b51c-8f6379e10218 -79.183 65 43.294 -60.91 0
tp 8bd36e4e-1a75-51ba-b224-63055ff644c2 -79.183 65 43.294 -60.91 0
tp 7b07c259-0b81-5b46-b286-5b101f183bf9 -79.183 65 43.294 -60.91 0
tp 04fc5281-333c-5c0d-ba69-0b625cbc7206 -79.183 65 43.294 -60.91 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0.0111f,0.0002f,0.0171f,0.9998f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.5753f,-0.191f,-0.0728f,0.792f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.1564f,0.804f,-0.5584f,0.1316f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.6373f,-0.0083f,0.0101f,0.7705f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.0101f,-0.7705f,0.6373f,0.0083f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.3992f,0.8442f,0.1291f],left_rotation:[0.0415f,0.1974f,-0.951f,0.2342f]}}
particle minecraft:cloud -81.88 65.32 37.9 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -81.88 65.42 37.9 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke -82.88 65.12 39.23 -0.056 0.021 -0.012 1 0 force
particle minecraft:cloud -82.88 65.32 39.23 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -82.88 65.42 39.23 0.45 0.2 0.45 0.008 1 force
tp 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 -86.892 65 28.353 -34.97 0
tp f74f363c-8714-5fe5-bb64-beafe6b6ac28 -86.892 65 28.353 -34.97 0
tp 97428e5f-5a51-575c-8305-607c4b0f68cb -86.892 65 28.353 -34.97 0
tp 186c432f-da2b-5bec-ba8a-9d97f056504e -86.892 65 28.353 -34.97 0
tp b7fef3cd-3066-54f8-9318-2747261e9dd9 -86.892 65 28.353 -34.97 0
tp 0d17ad00-82d8-5739-af58-9e93f268e98c -86.892 65 28.353 -34.97 0
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.6618f,-0.0915f,-0.0112f,0.744f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.0894f,0.7493f,-0.6558f,0.0225f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.6373f,-0.0083f,0.0101f,0.7705f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.0101f,-0.7705f,0.6373f,0.0083f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.3894f,0.8514f,0.25f],left_rotation:[0.149f,-0.1192f,0.6302f,0.7526f]}}
particle minecraft:campfire_cosy_smoke -90.22 65.12 22.71 -0.057 0.013 -0.045 1 0 force
