tp 425483f9-2934-53dd-805b-82336df4bdbc 20.408 65 -47.432 32.49 0
tp 77d4edec-4f89-5806-8a73-69da291cf64a 20.408 65 -47.432 32.49 0
tp a18c987f-26df-590a-b51c-8f6379e10218 20.408 65 -47.432 32.49 0
tp 8bd36e4e-1a75-51ba-b224-63055ff644c2 20.408 65 -47.432 32.49 0
tp 7b07c259-0b81-5b46-b286-5b101f183bf9 20.408 65 -47.432 32.49 0
tp 04fc5281-333c-5c0d-ba69-0b625cbc7206 20.408 65 -47.432 32.49 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0.0047f,0.0001f,0.0223f,0.9997f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.0415f,-0.2432f,0.0436f,0.9681f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.058f,0.9689f,-0.0162f,0.2402f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.0522f,-0.0007f,0.0131f,0.9985f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.0131f,-0.9985f,0.0522f,0.0007f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4078f,0.8416f,0.1181f],left_rotation:[0.1117f,0.1604f,-0.7791f,0.5957f]}}
particle minecraft:cloud 25.24 65.32 -48.95 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 23.96 65.12 -50.03 0.012 0.022 -0.03 1 0 force
particle minecraft:cloud 23.96 65.32 -50.03 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 23.96 65.42 -50.03 0.45 0.2 0.45 0.008 1 force
particle minecraft:flame 24.91 65.22 -50.63 0.05 0.04 0.05 0.02 6 force
particle minecraft:large_smoke 24.91 65.22 -50.63 0.05 0.04 0.05 0.01 2 force
tp 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 32.548 65 -51.07 52.44 0
tp f74f363c-8714-5fe5-bb64-beafe6b6ac28 32.548 65 -51.07 52.44 0
tp 97428e5f-5a51-575c-8305-607c4b0f68cb 32.548 65 -51.07 52.44 0
tp 186c432f-da2b-5bec-ba8a-9d97f056504e 32.548 65 -51.07 52.44 0
tp b7fef3cd-3066-54f8-9318-2747261e9dd9 32.548 65 -51.07 52.44 0
tp 0d17ad00-82d8-5739-af58-9e93f268e98c 32.548 65 -51.07 52.44 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0.0035f,0.0001f,0.0223f,0.9997f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.9062f,-0.0358f,0.2494f,0.3395f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.2151f,0.3152f,0.915f,0.1312f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.0522f,-0.0007f,0.0131f,0.9985f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.0131f,-0.9985f,0.0522f,0.0007f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4078f,0.8409f,0.2559f],left_rotation:[0.1182f,0.1541f,-0.7509f,0.6313f]}}
particle minecraft:cloud 37.98 65.32 -51 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 37.98 65.42 -51 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke 37.08 65.12 -52.45 0.032 0.022 -0.026 1 0 force
particle minecraft:cloud 37.08 65.32 -52.45 0.35 0.18 0.35 0.02 3 force
