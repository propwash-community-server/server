tp 425483f9-2934-53dd-805b-82336df4bdbc -10.414 65 64.005 -91.01 0
tp 77d4edec-4f89-5806-8a73-69da291cf64a -10.414 65 64.005 -91.01 0
tp a18c987f-26df-590a-b51c-8f6379e10218 -10.414 65 64.005 -91.01 0
tp 8bd36e4e-1a75-51ba-b224-63055ff644c2 -10.414 65 64.005 -91.01 0
tp 7b07c259-0b81-5b46-b286-5b101f183bf9 -10.414 65 64.005 -91.01 0
tp 04fc5281-333c-5c0d-ba69-0b625cbc7206 -10.414 65 64.005 -91.01 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0f,0f,-0.0006f,1f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.3269f,-0.01f,0.0519f,0.9436f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.047f,-0.9433f,0.3276f,0.0243f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.3304f,-0.0043f,0.0124f,0.9437f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.0124f,-0.9437f,0.3304f,0.0043f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.3689f,0.8605f,0.11f],left_rotation:[0.1904f,0.0128f,-0.0672f,0.9793f]}}
tp 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 -28.654 65 64.812 -92.62 0
tp f74f363c-8714-5fe5-bb64-beafe6b6ac28 -28.654 65 64.812 -92.62 0
tp 97428e5f-5a51-575c-8305-607c4b0f68cb -28.654 65 64.812 -92.62 0
tp 186c432f-da2b-5bec-ba8a-9d97f056504e -28.654 65 64.812 -92.62 0
tp b7fef3cd-3066-54f8-9318-2747261e9dd9 -28.654 65 64.812 -92.62 0
tp 0d17ad00-82d8-5739-af58-9e93f268e98c -28.654 65 64.812 -92.62 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0059f,-0.0001f,0.0118f,0.9999f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.1715f,-0.0535f,0.0439f,0.9828f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.0592f,0.9836f,-0.1668f,0.0357f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.3304f,-0.0043f,0.0124f,0.9437f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.0124f,-0.9437f,0.3304f,0.0043f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.3903f,0.8539f,0.2398f],left_rotation:[0.1707f,-0.0714f,0.4006f,0.8974f]}}
