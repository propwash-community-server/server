tp 425483f9-2934-53dd-805b-82336df4bdbc 15.38 65 -44.805 18.74 0
tp 77d4edec-4f89-5806-8a73-69da291cf64a 15.38 65 -44.805 18.74 0
tp a18c987f-26df-590a-b51c-8f6379e10218 15.38 65 -44.805 18.74 0
tp 8bd36e4e-1a75-51ba-b224-63055ff644c2 15.38 65 -44.805 18.74 0
tp 7b07c259-0b81-5b46-b286-5b101f183bf9 15.38 65 -44.805 18.74 0
tp 04fc5281-333c-5c0d-ba69-0b625cbc7206 15.38 65 -44.805 18.74 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0.0064f,0.0001f,0.0223f,0.9997f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.4229f,-0.2611f,-0.0672f,0.8651f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.1585f,0.8769f,-0.3978f,0.2181f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.325f,-0.0043f,0.0124f,0.9456f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.0124f,-0.9456f,0.325f,0.0043f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4078f,0.8412f,0.1211f],left_rotation:[0.1445f,0.1341f,-0.6342f,0.7476f]}}
particle minecraft:campfire_cosy_smoke 19.57 65.12 -47.1 0.073 0.022 -0.009 1 0 force
particle minecraft:cloud 19.57 65.32 -47.1 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud 18.07 65.32 -47.84 0.35 0.18 0.35 0.02 3 force
tp 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 26.121 65 -50.169 41.66 0
tp f74f363c-8714-5fe5-bb64-beafe6b6ac28 26.121 65 -50.169 41.66 0
tp 97428e5f-5a51-575c-8305-607c4b0f68cb 26.121 65 -50.169 41.66 0
tp 186c432f-da2b-5bec-ba8a-9d97f056504e 26.121 65 -50.169 41.66 0
tp b7fef3cd-3066-54f8-9318-2747261e9dd9 26.121 65 -50.169 41.66 0
tp 0d17ad00-82d8-5739-af58-9e93f268e98c 26.121 65 -50.169 41.66 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0.0005f,0f,0.0223f,0.9998f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.7973f,-0.0981f,0.2392f,0.5454f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.1832f,0.5233f,0.812f,0.1825f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.325f,-0.0043f,0.0124f,0.9456f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.0124f,-0.9456f,0.325f,0.0043f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4079f,0.8425f,0.2508f],left_rotation:[0.1258f,0.1441f,-0.71f,0.6777f]}}
particle minecraft:campfire_cosy_smoke 31.43 65.12 -51 0.076 0.022 0.02 1 0 force
particle minecraft:cloud 31.43 65.32 -51 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 31.43 65.42 -51 0.45 0.2 0.45 0.008 1 force
particle minecraft:cloud 30.28 65.32 -52.27 0.35 0.18 0.35 0.02 3 force
