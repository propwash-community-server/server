tp 425483f9-2934-53dd-805b-82336df4bdbc -97.026 65 -13.359 -24.87 0
tp 77d4edec-4f89-5806-8a73-69da291cf64a -97.026 65 -13.359 -24.87 0
tp a18c987f-26df-590a-b51c-8f6379e10218 -97.026 65 -13.359 -24.87 0
tp 8bd36e4e-1a75-51ba-b224-63055ff644c2 -97.026 65 -13.359 -24.87 0
tp 7b07c259-0b81-5b46-b286-5b101f183bf9 -97.026 65 -13.359 -24.87 0
tp 04fc5281-333c-5c0d-ba69-0b625cbc7206 -97.026 65 -13.359 -24.87 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0059f,-0.0001f,0.0189f,0.9998f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.0125f,-0.178f,0.0555f,0.9824f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.0475f,0.982f,0.0312f,0.1802f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.0464f,-0.0006f,0.0131f,0.9988f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.0131f,-0.9988f,0.0464f,0.0006f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4023f,0.8466f,0.0999f],left_rotation:[0.0062f,0.1849f,-0.9802f,0.0701f]}}
particle minecraft:cloud -96.54 65.32 -18.8 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -98.09 65.12 -18.19 -0.035 0.021 -0.041 1 0 force
particle minecraft:cloud -98.09 65.32 -18.19 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -98.09 65.42 -18.19 0.45 0.2 0.45 0.008 1 force
tp 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 -96.424 65 -26.7 -16.46 0
tp f74f363c-8714-5fe5-bb64-beafe6b6ac28 -96.424 65 -26.7 -16.46 0
tp 97428e5f-5a51-575c-8305-607c4b0f68cb -96.424 65 -26.7 -16.46 0
tp 186c432f-da2b-5bec-ba8a-9d97f056504e -96.424 65 -26.7 -16.46 0
tp b7fef3cd-3066-54f8-9318-2747261e9dd9 -96.424 65 -26.7 -16.46 0
tp 0d17ad00-82d8-5739-af58-9e93f268e98c -96.424 65 -26.7 -16.46 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0059f,-0.0001f,0.0173f,0.9998f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.2851f,-0.2299f,-0.0143f,0.9304f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.1121f,0.937f,-0.2625f,0.2012f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.0464f,-0.0006f,0.0131f,0.9988f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.0131f,-0.9988f,0.0464f,0.0006f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.3996f,0.8496f,0.2399f],left_rotation:[0.0811f,0.1663f,-0.8679f,0.4609f]}}
particle minecraft:cloud -94.87 65.32 -31.52 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -96.54 65.12 -31.13 -0.031 0.022 -0.025 1 0 force
particle minecraft:cloud -96.54 65.32 -31.13 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -96.54 65.42 -31.13 0.45 0.2 0.45 0.008 1 force
