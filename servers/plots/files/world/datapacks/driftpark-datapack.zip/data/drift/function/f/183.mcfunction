tp 425483f9-2934-53dd-805b-82336df4bdbc 73.325 65 -33.659 107.92 0
tp 77d4edec-4f89-5806-8a73-69da291cf64a 73.325 65 -33.659 107.92 0
tp a18c987f-26df-590a-b51c-8f6379e10218 73.325 65 -33.659 107.92 0
tp 8bd36e4e-1a75-51ba-b224-63055ff644c2 73.325 65 -33.659 107.92 0
tp 7b07c259-0b81-5b46-b286-5b101f183bf9 73.325 65 -33.659 107.92 0
tp 04fc5281-333c-5c0d-ba69-0b625cbc7206 73.325 65 -33.659 107.92 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0049f,-0.0001f,0.0223f,0.9997f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.3366f,-0.1547f,0.1132f,0.9219f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.0169f,0.9151f,0.3547f,0.1909f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.3359f,0.0044f,0.0123f,0.9418f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.0123f,0.9418f,0.3359f,0.0044f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4079f,0.8437f,0.1016f],left_rotation:[0.015f,0.1854f,-0.9748f,0.1228f]}}
particle minecraft:campfire_cosy_smoke 77.16 65.12 -29.28 0.03 0.021 0.074 1 0 force
particle minecraft:cloud 77.16 65.32 -29.28 0.35 0.18 0.35 0.02 2 force
particle minecraft:cloud 77.78 65.32 -30.83 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke 77.78 65.42 -30.83 0.45 0.2 0.45 0.008 1 force
tp 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 83.341 65 -22.78 119.08 0
tp f74f363c-8714-5fe5-bb64-beafe6b6ac28 83.341 65 -22.78 119.08 0
tp 97428e5f-5a51-575c-8305-607c4b0f68cb 83.341 65 -22.78 119.08 0
tp 186c432f-da2b-5bec-ba8a-9d97f056504e 83.341 65 -22.78 119.08 0
tp b7fef3cd-3066-54f8-9318-2747261e9dd9 83.341 65 -22.78 119.08 0
tp 0d17ad00-82d8-5739-af58-9e93f268e98c 83.341 65 -22.78 119.08 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0.0019f,0f,0.0223f,0.9998f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.9417f,-0.0043f,0.2272f,0.248f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.2024f,0.2254f,0.9474f,0.1033f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.3359f,0.0044f,0.0123f,0.9418f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.0123f,0.9418f,0.3359f,0.0044f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4079f,0.8417f,0.2533f],left_rotation:[0.0784f,0.176f,-0.8776f,0.4389f]}}
particle minecraft:campfire_cosy_smoke 85.97 65.12 -17.45 0.01 0.022 0.078 1 0 force
particle minecraft:cloud 85.97 65.32 -17.45 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud 86.92 65.32 -18.88 0.35 0.18 0.35 0.02 3 force
