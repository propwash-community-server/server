tp 425483f9-2934-53dd-805b-82336df4bdbc 15.57 65 63.317 -97.93 0
tp 77d4edec-4f89-5806-8a73-69da291cf64a 15.57 65 63.317 -97.93 0
tp a18c987f-26df-590a-b51c-8f6379e10218 15.57 65 63.317 -97.93 0
tp 8bd36e4e-1a75-51ba-b224-63055ff644c2 15.57 65 63.317 -97.93 0
tp 7b07c259-0b81-5b46-b286-5b101f183bf9 15.57 65 63.317 -97.93 0
tp 04fc5281-333c-5c0d-ba69-0b625cbc7206 15.57 65 63.317 -97.93 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0f,0f,0.0053f,1f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.6165f,0.0135f,0.0559f,0.7853f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.0263f,0.7837f,0.6185f,0.0512f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.6146f,0.008f,0.0103f,0.7887f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.0103f,0.7887f,0.6146f,0.008f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.379f,0.8561f,0.11f],left_rotation:[0.1866f,-0.0399f,0.2154f,0.9577f]}}
tp 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 -2.619 65 63.789 -90.6 0
tp f74f363c-8714-5fe5-bb64-beafe6b6ac28 -2.619 65 63.789 -90.6 0
tp 97428e5f-5a51-575c-8305-607c4b0f68cb -2.619 65 63.789 -90.6 0
tp 186c432f-da2b-5bec-ba8a-9d97f056504e -2.619 65 63.789 -90.6 0
tp b7fef3cd-3066-54f8-9318-2747261e9dd9 -2.619 65 63.789 -90.6 0
tp 0d17ad00-82d8-5739-af58-9e93f268e98c -2.619 65 63.789 -90.6 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0f,0f,-0.0025f,1f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.8041f,0.0445f,0.0278f,0.5921f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.0343f,0.5925f,0.8039f,0.0397f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.6146f,0.008f,0.0103f,0.7887f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.0103f,0.7887f,0.6146f,0.008f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.3658f,0.8618f,0.25f],left_rotation:[0.1907f,0.0065f,-0.0383f,0.9809f]}}
