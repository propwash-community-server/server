tp 425483f9-2934-53dd-805b-82336df4bdbc 89.207 65 15.804 165.01 0
tp 77d4edec-4f89-5806-8a73-69da291cf64a 89.207 65 15.804 165.01 0
tp a18c987f-26df-590a-b51c-8f6379e10218 89.207 65 15.804 165.01 0
tp 8bd36e4e-1a75-51ba-b224-63055ff644c2 89.207 65 15.804 165.01 0
tp 7b07c259-0b81-5b46-b286-5b101f183bf9 89.207 65 15.804 165.01 0
tp 04fc5281-333c-5c0d-ba69-0b625cbc7206 89.207 65 15.804 165.01 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0015f,0f,0.0223f,0.9998f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.3057f,-0.1982f,-0.0089f,0.9312f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.1069f,0.9373f,-0.2865f,0.1672f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.314f,-0.0041f,0.0124f,0.9493f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.0124f,-0.9493f,0.314f,0.0041f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4079f,0.843f,0.1075f],left_rotation:[0.0274f,0.1874f,-0.9643f,0.1851f]}}
particle minecraft:cloud 87.52 65.32 21.3 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke 89.16 65.12 21 0.026 0.022 0.04 1 0 force
particle minecraft:cloud 89.16 65.32 21 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke 89.16 65.42 21 0.45 0.2 0.45 0.008 1 force
tp 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 85.239 65 29.909 -182.68 0
tp f74f363c-8714-5fe5-bb64-beafe6b6ac28 85.239 65 29.909 -182.68 0
tp 97428e5f-5a51-575c-8305-607c4b0f68cb 85.239 65 29.909 -182.68 0
tp 186c432f-da2b-5bec-ba8a-9d97f056504e 85.239 65 29.909 -182.68 0
tp b7fef3cd-3066-54f8-9318-2747261e9dd9 85.239 65 29.909 -182.68 0
tp 0d17ad00-82d8-5739-af58-9e93f268e98c 85.239 65 29.909 -182.68 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0.0033f,0.0001f,0.0223f,0.9997f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.3587f,-0.1872f,0.1319f,0.9049f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.0376f,0.896f,0.3804f,0.2259f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.314f,-0.0041f,0.0124f,0.9493f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.0124f,-0.9493f,0.314f,0.0041f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4078f,0.841f,0.2557f],left_rotation:[0.082f,0.1759f,-0.8699f,0.4535f]}}
particle minecraft:cloud 82.1 65.32 34.85 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 83.81 65.12 34.9 0.007 0.022 0.05 1 0 force
particle minecraft:cloud 83.81 65.32 34.9 0.35 0.18 0.35 0.02 3 force
