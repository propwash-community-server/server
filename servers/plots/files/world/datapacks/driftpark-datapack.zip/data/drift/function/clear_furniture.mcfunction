kill @e[type=minecraft:item_display,tag=drift.f,distance=0..]
kill @e[type=minecraft:interaction,tag=drift.fi,distance=0..]
kill @e[type=minecraft:item_display,tag=drift.seat,distance=0..]
tellraw @s {"text":"All furniture removed.","color":"gray"}
