tp 425483f9-2934-53dd-805b-82336df4bdbc -49.974 65 62.585 -99.47 0
tp 77d4edec-4f89-5806-8a73-69da291cf64a -49.974 65 62.585 -99.47 0
tp a18c987f-26df-590a-b51c-8f6379e10218 -49.974 65 62.585 -99.47 0
tp 8bd36e4e-1a75-51ba-b224-63055ff644c2 -49.974 65 62.585 -99.47 0
tp 7b07c259-0b81-5b46-b286-5b101f183bf9 -49.974 65 62.585 -99.47 0
tp 04fc5281-333c-5c0d-ba69-0b625cbc7206 -49.974 65 62.585 -99.47 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0058f,-0.0001f,0.0183f,0.9998f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.9525f,-0.0937f,-0.149f,0.2485f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.176f,-0.2655f,0.9479f,0.0058f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.9652f,-0.0126f,0.0034f,0.2611f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.0034f,-0.2611f,0.9652f,0.0126f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4012f,0.8471f,0.1f],left_rotation:[0.0119f,-0.1847f,0.9823f,0.0275f]}}
particle minecraft:cloud -55.46 65.32 60.77 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -55.25 65.12 62.43 -0.039 0.02 0.029 1 0 force
particle minecraft:cloud -55.25 65.32 62.43 0.35 0.18 0.35 0.02 2 force
tp 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 -63.904 65 58.716 -93.52 0
tp f74f363c-8714-5fe5-bb64-beafe6b6ac28 -63.904 65 58.716 -93.52 0
tp 97428e5f-5a51-575c-8305-607c4b0f68cb -63.904 65 58.716 -93.52 0
tp 186c432f-da2b-5bec-ba8a-9d97f056504e -63.904 65 58.716 -93.52 0
tp b7fef3cd-3066-54f8-9318-2747261e9dd9 -63.904 65 58.716 -93.52 0
tp 0d17ad00-82d8-5739-af58-9e93f268e98c -63.904 65 58.716 -93.52 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0059f,-0.0001f,0.0212f,0.9998f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.943f,-0.1076f,-0.2072f,0.2373f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.2333f,0.2604f,-0.9368f,0.0091f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.9652f,-0.0126f,0.0034f,0.2611f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.0034f,-0.2611f,0.9652f,0.0126f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4063f,0.8464f,0.2399f],left_rotation:[0.0854f,0.1642f,-0.8518f,0.4901f]}}
particle minecraft:cloud -68.52 65.32 55.95 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -68.51 65.12 57.66 -0.032 0.022 0.018 1 0 force
particle minecraft:cloud -68.51 65.32 57.66 0.35 0.18 0.35 0.02 3 force
