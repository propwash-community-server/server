tp 425483f9-2934-53dd-805b-82336df4bdbc 90.233 65 5.18 153.82 0
tp 77d4edec-4f89-5806-8a73-69da291cf64a 90.233 65 5.18 153.82 0
tp a18c987f-26df-590a-b51c-8f6379e10218 90.233 65 5.18 153.82 0
tp 8bd36e4e-1a75-51ba-b224-63055ff644c2 90.233 65 5.18 153.82 0
tp 7b07c259-0b81-5b46-b286-5b101f183bf9 90.233 65 5.18 153.82 0
tp 04fc5281-333c-5c0d-ba69-0b625cbc7206 90.233 65 5.18 153.82 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0001f,0f,0.0223f,0.9998f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.1787f,-0.1768f,0.087f,0.964f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.0139f,0.9601f,0.1982f,0.1965f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.179f,0.0023f,0.0129f,0.9838f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.0129f,0.9838f,0.179f,0.0023f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4079f,0.8427f,0.1098f],left_rotation:[0.0251f,0.1891f,-0.9664f,0.1722f]}}
particle minecraft:cloud 89.66 65.32 10.96 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke 89.66 65.42 10.96 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke 91.21 65.12 10.35 0.041 0.021 0.034 1 0 force
particle minecraft:cloud 91.21 65.32 10.35 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke 91.21 65.42 10.35 0.45 0.2 0.45 0.008 1 force
tp 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 89.051 65 20.151 165.82 0
tp f74f363c-8714-5fe5-bb64-beafe6b6ac28 89.051 65 20.151 165.82 0
tp 97428e5f-5a51-575c-8305-607c4b0f68cb 89.051 65 20.151 165.82 0
tp 186c432f-da2b-5bec-ba8a-9d97f056504e 89.051 65 20.151 165.82 0
tp b7fef3cd-3066-54f8-9318-2747261e9dd9 89.051 65 20.151 165.82 0
tp 0d17ad00-82d8-5739-af58-9e93f268e98c 89.051 65 20.151 165.82 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0018f,0f,0.0223f,0.9998f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.7813f,-0.088f,0.208f,0.5819f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.148f,0.5632f,0.7948f,0.1706f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.179f,0.0023f,0.0129f,0.9838f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.0129f,0.9838f,0.179f,0.0023f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4079f,0.8436f,0.2468f],left_rotation:[0.0747f,0.1736f,-0.8838f,0.428f]}}
particle minecraft:cloud 87.02 65.32 25.67 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 88.71 65.12 25.39 0.025 0.022 0.042 1 0 force
particle minecraft:cloud 88.71 65.32 25.39 0.35 0.18 0.35 0.02 3 force
