tp 425483f9-2934-53dd-805b-82336df4bdbc -11.515 65 -12.856 106.99 0
tp 77d4edec-4f89-5806-8a73-69da291cf64a -11.515 65 -12.856 106.99 0
tp a18c987f-26df-590a-b51c-8f6379e10218 -11.515 65 -12.856 106.99 0
tp 8bd36e4e-1a75-51ba-b224-63055ff644c2 -11.515 65 -12.856 106.99 0
tp 7b07c259-0b81-5b46-b286-5b101f183bf9 -11.515 65 -12.856 106.99 0
tp 04fc5281-333c-5c0d-ba69-0b625cbc7206 -11.515 65 -12.856 106.99 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0.0074f,-0.0002f,-0.0223f,0.9997f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.3499f,0.2929f,-0.0565f,0.888f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.1502f,-0.8989f,-0.321f,0.2577f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.9977f,-0.0131f,0.0009f,0.0667f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.0009f,-0.0667f,0.9977f,0.0131f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.3314f,0.8739f,0.1227f],left_rotation:[0.1762f,-0.0904f,0.4081f,0.8912f]}}
particle minecraft:campfire_cosy_smoke -8.04 65.12 -13.29 0.019 0.022 0.012 1 0 force
particle minecraft:cloud -8.04 65.32 -13.29 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud -7.76 65.32 -14.94 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -7.76 65.42 -14.94 0.45 0.2 0.45 0.008 1 force
tp 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 -2.677 65 -18.781 83.67 0
tp f74f363c-8714-5fe5-bb64-beafe6b6ac28 -2.677 65 -18.781 83.67 0
tp 97428e5f-5a51-575c-8305-607c4b0f68cb -2.677 65 -18.781 83.67 0
tp 186c432f-da2b-5bec-ba8a-9d97f056504e -2.677 65 -18.781 83.67 0
tp b7fef3cd-3066-54f8-9318-2747261e9dd9 -2.677 65 -18.781 83.67 0
tp 0d17ad00-82d8-5739-af58-9e93f268e98c -2.677 65 -18.781 83.67 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0.0096f,-0.0002f,-0.0208f,0.9997f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.4864f,0.2187f,0.1926f,0.8237f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.1071f,-0.808f,0.512f,0.271f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.9977f,-0.0131f,0.0009f,0.0667f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.0009f,-0.0667f,0.9977f,0.0131f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.334f,0.8697f,0.2665f],left_rotation:[0.1719f,-0.1027f,0.4667f,0.8614f]}}
particle minecraft:campfire_cosy_smoke 1.23 65.12 -21.47 0.034 0.022 -0.003 1 0 force
particle minecraft:cloud 1.23 65.32 -21.47 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud 0.74 65.32 -23.11 0.35 0.18 0.35 0.02 3 force
particle minecraft:flame 1.98 65.24 -22.78 0.05 0.04 0.05 0.02 6 force
particle minecraft:large_smoke 1.98 65.24 -22.78 0.05 0.04 0.05 0.01 2 force
particle minecraft:flame 2.08 65.24 -22.43 0.05 0.04 0.05 0.02 6 force
particle minecraft:large_smoke 2.08 65.24 -22.43 0.05 0.04 0.05 0.01 2 force
