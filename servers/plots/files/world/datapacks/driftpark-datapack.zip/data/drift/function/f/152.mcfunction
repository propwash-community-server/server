tp 425483f9-2934-53dd-805b-82336df4bdbc 89.132 65 -5.449 142.47 0
tp 77d4edec-4f89-5806-8a73-69da291cf64a 89.132 65 -5.449 142.47 0
tp a18c987f-26df-590a-b51c-8f6379e10218 89.132 65 -5.449 142.47 0
tp 8bd36e4e-1a75-51ba-b224-63055ff644c2 89.132 65 -5.449 142.47 0
tp 7b07c259-0b81-5b46-b286-5b101f183bf9 89.132 65 -5.449 142.47 0
tp 04fc5281-333c-5c0d-ba69-0b625cbc7206 89.132 65 -5.449 142.47 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0009f,0f,0.0223f,0.9998f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.6193f,-0.1129f,0.1607f,0.7602f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.0817f,0.7475f,0.6346f,0.1786f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.6283f,0.0082f,0.0102f,0.7779f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.0102f,0.7779f,0.6283f,0.0082f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4079f,0.8429f,0.1084f],left_rotation:[0.0238f,0.1884f,-0.9676f,0.1662f]}}
particle minecraft:cloud 89.71 65.32 0.35 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke 91.11 65.12 -0.56 0.035 0.021 0.037 1 0 force
particle minecraft:cloud 91.11 65.32 -0.56 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke 91.11 65.42 -0.56 0.45 0.2 0.45 0.008 1 force
tp 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 90.914 65 9.528 155.13 0
tp f74f363c-8714-5fe5-bb64-beafe6b6ac28 90.914 65 9.528 155.13 0
tp 97428e5f-5a51-575c-8305-607c4b0f68cb 90.914 65 9.528 155.13 0
tp 186c432f-da2b-5bec-ba8a-9d97f056504e 90.914 65 9.528 155.13 0
tp b7fef3cd-3066-54f8-9318-2747261e9dd9 90.914 65 9.528 155.13 0
tp 0d17ad00-82d8-5739-af58-9e93f268e98c 90.914 65 9.528 155.13 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0007f,0f,0.0223f,0.9998f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.971f,0.0346f,0.2207f,0.0846f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.2131f,0.0618f,0.9728f,0.0673f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.6283f,0.0082f,0.0102f,0.7779f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.0102f,0.7779f,0.6283f,0.0082f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4079f,0.843f,0.2488f],left_rotation:[0.0711f,0.1764f,-0.8934f,0.4071f]}}
particle minecraft:cloud 89.99 65.32 15.43 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 91.59 65.12 14.82 0.024 0.022 0.046 1 0 force
particle minecraft:cloud 91.59 65.32 14.82 0.35 0.18 0.35 0.02 3 force
