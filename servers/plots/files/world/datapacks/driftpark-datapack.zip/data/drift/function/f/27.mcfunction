tp 425483f9-2934-53dd-805b-82336df4bdbc -15.609 65 64.205 -90.98 0
tp 77d4edec-4f89-5806-8a73-69da291cf64a -15.609 65 64.205 -90.98 0
tp a18c987f-26df-590a-b51c-8f6379e10218 -15.609 65 64.205 -90.98 0
tp 8bd36e4e-1a75-51ba-b224-63055ff644c2 -15.609 65 64.205 -90.98 0
tp 7b07c259-0b81-5b46-b286-5b101f183bf9 -15.609 65 64.205 -90.98 0
tp 04fc5281-333c-5c0d-ba69-0b625cbc7206 -15.609 65 64.205 -90.98 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0f,0f,0.0032f,1f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.6607f,0.0403f,0.0343f,0.7488f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.0443f,0.7493f,0.6601f,0.0289f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.6594f,0.0086f,0.0098f,0.7517f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.0098f,0.7517f,0.6594f,0.0086f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.3754f,0.8576f,0.11f],left_rotation:[0.1903f,0.0136f,-0.0637f,0.9796f]}}
tp 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 -33.723 65 64.833 -96.18 0
tp f74f363c-8714-5fe5-bb64-beafe6b6ac28 -33.723 65 64.833 -96.18 0
tp 97428e5f-5a51-575c-8305-607c4b0f68cb -33.723 65 64.833 -96.18 0
tp 186c432f-da2b-5bec-ba8a-9d97f056504e -33.723 65 64.833 -96.18 0
tp b7fef3cd-3066-54f8-9318-2747261e9dd9 -33.723 65 64.833 -96.18 0
tp 0d17ad00-82d8-5739-af58-9e93f268e98c -33.723 65 64.833 -96.18 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0059f,-0.0001f,0.0143f,0.9999f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.7539f,-0.0186f,0.1022f,0.6487f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.0346f,0.6415f,0.7601f,0.098f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.6594f,0.0086f,0.0098f,0.7517f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.0098f,0.7517f,0.6594f,0.0086f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.3945f,0.852f,0.2398f],left_rotation:[0.1293f,-0.1323f,0.722f,0.6667f]}}
particle minecraft:campfire_cosy_smoke -40.1 65.12 63.96 -0.075 0.014 -0.044 1 0 force
