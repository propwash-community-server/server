tp 425483f9-2934-53dd-805b-82336df4bdbc 87.601 65 21.926 171.93 0
tp 77d4edec-4f89-5806-8a73-69da291cf64a 87.601 65 21.926 171.93 0
tp a18c987f-26df-590a-b51c-8f6379e10218 87.601 65 21.926 171.93 0
tp 8bd36e4e-1a75-51ba-b224-63055ff644c2 87.601 65 21.926 171.93 0
tp 7b07c259-0b81-5b46-b286-5b101f183bf9 87.601 65 21.926 171.93 0
tp 04fc5281-333c-5c0d-ba69-0b625cbc7206 87.601 65 21.926 171.93 0
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.935f,-0.0068f,0.2003f,0.2926f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.1706f,0.2732f,0.9409f,0.1051f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.9538f,0.0125f,0.0039f,0.3001f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.0039f,0.3001f,0.9538f,0.0125f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4079f,0.8431f,0.1066f],left_rotation:[0.0308f,0.1863f,-0.9607f,0.2033f]}}
particle minecraft:cloud 85.29 65.32 27.11 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke 85.29 65.42 27.11 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke 86.96 65.12 27 0.016 0.022 0.047 1 0 force
particle minecraft:cloud 86.96 65.32 27 0.35 0.18 0.35 0.02 2 force
tp 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 81.936 65 35.263 -175.42 0
tp f74f363c-8714-5fe5-bb64-beafe6b6ac28 81.936 65 35.263 -175.42 0
tp 97428e5f-5a51-575c-8305-607c4b0f68cb 81.936 65 35.263 -175.42 0
tp 186c432f-da2b-5bec-ba8a-9d97f056504e 81.936 65 35.263 -175.42 0
tp b7fef3cd-3066-54f8-9318-2747261e9dd9 81.936 65 35.263 -175.42 0
tp 0d17ad00-82d8-5739-af58-9e93f268e98c 81.936 65 35.263 -175.42 0
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.9113f,-0.1283f,-0.1887f,0.3427f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.2258f,0.3645f,-0.9028f,0.0332f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.9538f,0.0125f,0.0039f,0.3001f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.0039f,0.3001f,0.9538f,0.0125f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4078f,0.8408f,0.2566f],left_rotation:[0.0808f,0.177f,-0.8732f,0.4468f]}}
particle minecraft:cloud 78.11 65.32 39.89 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 79.8 65.12 40.17 0.006 0.022 0.045 1 0 force
particle minecraft:cloud 79.8 65.32 40.17 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 79.8 65.42 40.17 0.45 0.2 0.45 0.008 1 force
