tp 425483f9-2934-53dd-805b-82336df4bdbc -63.499 65 57.91 -89.92 0
tp 77d4edec-4f89-5806-8a73-69da291cf64a -63.499 65 57.91 -89.92 0
tp a18c987f-26df-590a-b51c-8f6379e10218 -63.499 65 57.91 -89.92 0
tp 8bd36e4e-1a75-51ba-b224-63055ff644c2 -63.499 65 57.91 -89.92 0
tp 7b07c259-0b81-5b46-b286-5b101f183bf9 -63.499 65 57.91 -89.92 0
tp 04fc5281-333c-5c0d-ba69-0b625cbc7206 -63.499 65 57.91 -89.92 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0059f,-0.0001f,0.0212f,0.9998f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.6749f,-0.1816f,-0.0993f,0.7083f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.1743f,0.7226f,-0.6595f,0.1117f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.6809f,-0.0089f,0.0096f,0.7322f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.0096f,-0.7322f,0.6809f,0.0089f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4062f,0.8447f,0.0999f],left_rotation:[0.0418f,0.1803f,-0.9471f,0.2622f]}}
particle minecraft:cloud -67.89 65.32 55.12 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -67.89 65.42 55.12 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke -67.98 65.12 56.79 -0.045 0.022 0.021 1 0 force
particle minecraft:cloud -67.98 65.32 56.79 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -67.98 65.42 56.79 0.45 0.2 0.45 0.008 1 force
tp 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 -74.025 65 51.485 -80.9 0
tp f74f363c-8714-5fe5-bb64-beafe6b6ac28 -74.025 65 51.485 -80.9 0
tp 97428e5f-5a51-575c-8305-607c4b0f68cb -74.025 65 51.485 -80.9 0
tp 186c432f-da2b-5bec-ba8a-9d97f056504e -74.025 65 51.485 -80.9 0
tp b7fef3cd-3066-54f8-9318-2747261e9dd9 -74.025 65 51.485 -80.9 0
tp 0d17ad00-82d8-5739-af58-9e93f268e98c -74.025 65 51.485 -80.9 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0.0107f,0.0002f,0.0222f,0.9997f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.5955f,-0.2409f,-0.1205f,0.7569f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.2007f,0.7737f,-0.5734f,0.1797f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.6809f,-0.0089f,0.0096f,0.7322f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.0096f,-0.7322f,0.6809f,0.0089f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4075f,0.8372f,0.2684f],left_rotation:[0.1473f,0.1373f,-0.6354f,0.7455f]}}
particle minecraft:cloud -77.58 65.32 47.38 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -78.01 65.12 49.04 -0.032 0.022 0.007 1 0 force
particle minecraft:cloud -78.01 65.32 49.04 0.35 0.18 0.35 0.02 3 force
