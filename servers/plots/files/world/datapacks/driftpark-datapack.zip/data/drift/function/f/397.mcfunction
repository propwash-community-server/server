tp 425483f9-2934-53dd-805b-82336df4bdbc -77.661 65 -46.1 41.28 0
tp 77d4edec-4f89-5806-8a73-69da291cf64a -77.661 65 -46.1 41.28 0
tp a18c987f-26df-590a-b51c-8f6379e10218 -77.661 65 -46.1 41.28 0
tp 8bd36e4e-1a75-51ba-b224-63055ff644c2 -77.661 65 -46.1 41.28 0
tp 7b07c259-0b81-5b46-b286-5b101f183bf9 -77.661 65 -46.1 41.28 0
tp 04fc5281-333c-5c0d-ba69-0b625cbc7206 -77.661 65 -46.1 41.28 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0.0054f,0.0001f,0.0223f,0.9997f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.9338f,-0.1159f,-0.2629f,0.213f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.2867f,0.2418f,-0.9268f,0.0184f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.3414f,0.0045f,0.0123f,0.9398f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.0123f,0.9398f,0.3414f,0.0045f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4078f,0.8415f,0.1193f],left_rotation:[0.1642f,0.1073f,-0.4992f,0.844f]}}
particle minecraft:campfire_cosy_smoke -73.23 65.12 -46.4 0.07 0.022 0.037 1 0 force
particle minecraft:cloud -73.23 65.32 -46.4 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -73.23 65.42 -46.4 0.45 0.2 0.45 0.008 1 force
particle minecraft:cloud -74.33 65.32 -47.66 0.35 0.18 0.35 0.02 3 force
tp 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 -66.961 65 -46.129 64.19 0
tp f74f363c-8714-5fe5-bb64-beafe6b6ac28 -66.961 65 -46.129 64.19 0
tp 97428e5f-5a51-575c-8305-607c4b0f68cb -66.961 65 -46.129 64.19 0
tp 186c432f-da2b-5bec-ba8a-9d97f056504e -66.961 65 -46.129 64.19 0
tp b7fef3cd-3066-54f8-9318-2747261e9dd9 -66.961 65 -46.129 64.19 0
tp 0d17ad00-82d8-5739-af58-9e93f268e98c -66.961 65 -46.129 64.19 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0025f,-0.0001f,0.0223f,0.9997f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.8182f,-0.1036f,0.2783f,0.4924f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.2281f,0.4658f,0.8336f,0.1902f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.3414f,0.0045f,0.0123f,0.9398f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.0123f,0.9398f,0.3414f,0.0045f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.408f,0.8439f,0.2457f],left_rotation:[0.1665f,0.0881f,-0.4203f,0.8876f]}}
particle minecraft:campfire_cosy_smoke -62.47 65.12 -44.7 0.045 0.022 0.048 1 0 force
particle minecraft:cloud -62.47 65.32 -44.7 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud -63.06 65.32 -46.3 0.35 0.18 0.35 0.02 3 force
