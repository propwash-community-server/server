tp 425483f9-2934-53dd-805b-82336df4bdbc 81.814 65 33.895 -173.4 0
tp 77d4edec-4f89-5806-8a73-69da291cf64a 81.814 65 33.895 -173.4 0
tp a18c987f-26df-590a-b51c-8f6379e10218 81.814 65 33.895 -173.4 0
tp 8bd36e4e-1a75-51ba-b224-63055ff644c2 81.814 65 33.895 -173.4 0
tp 7b07c259-0b81-5b46-b286-5b101f183bf9 81.814 65 33.895 -173.4 0
tp 04fc5281-333c-5c0d-ba69-0b625cbc7206 81.814 65 33.895 -173.4 0
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.0112f,-0.1958f,0.0511f,0.9793f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.0515f,0.9793f,0.0093f,0.1957f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.0116f,-0.0002f,0.0131f,0.9998f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.0131f,-0.9998f,0.0116f,0.0002f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4079f,0.8418f,0.1166f],left_rotation:[0.0353f,0.1913f,-0.9557f,0.2207f]}}
particle minecraft:campfire_cosy_smoke 78.13 65.12 38.38 -0.07 0.022 0.041 1 0 force
particle minecraft:cloud 78.13 65.32 38.38 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke 78.13 65.42 38.38 0.45 0.2 0.45 0.008 1 force
particle minecraft:cloud 79.77 65.32 38.72 0.35 0.18 0.35 0.02 2 force
tp 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 72.187 65 45.855 -159.37 0
tp f74f363c-8714-5fe5-bb64-beafe6b6ac28 72.187 65 45.855 -159.37 0
tp 97428e5f-5a51-575c-8305-607c4b0f68cb 72.187 65 45.855 -159.37 0
tp 186c432f-da2b-5bec-ba8a-9d97f056504e 72.187 65 45.855 -159.37 0
tp b7fef3cd-3066-54f8-9318-2747261e9dd9 72.187 65 45.855 -159.37 0
tp 0d17ad00-82d8-5739-af58-9e93f268e98c 72.187 65 45.855 -159.37 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0.0021f,0f,0.0223f,0.9998f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.5377f,-0.1479f,0.1619f,0.8141f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.0772f,0.8016f,0.5562f,0.2053f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.0116f,-0.0002f,0.0131f,0.9998f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.0131f,-0.9998f,0.0116f,0.0002f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4078f,0.8416f,0.2535f],left_rotation:[0.065f,0.1815f,-0.9081f,0.3718f]}}
particle minecraft:campfire_cosy_smoke 67.11 65.12 49.55 -0.091 0.022 0.009 1 0 force
particle minecraft:cloud 67.11 65.32 49.55 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 67.11 65.42 49.55 0.45 0.2 0.45 0.008 1 force
particle minecraft:cloud 68.66 65.32 50.27 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 68.66 65.42 50.27 0.45 0.2 0.45 0.008 1 force
