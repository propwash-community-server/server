tp 425483f9-2934-53dd-805b-82336df4bdbc -89.02 65 22.197 -27.99 0
tp 77d4edec-4f89-5806-8a73-69da291cf64a -89.02 65 22.197 -27.99 0
tp a18c987f-26df-590a-b51c-8f6379e10218 -89.02 65 22.197 -27.99 0
tp 8bd36e4e-1a75-51ba-b224-63055ff644c2 -89.02 65 22.197 -27.99 0
tp 7b07c259-0b81-5b46-b286-5b101f183bf9 -89.02 65 22.197 -27.99 0
tp 04fc5281-333c-5c0d-ba69-0b625cbc7206 -89.02 65 22.197 -27.99 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0016f,0f,0.0113f,0.9999f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.3084f,-0.0671f,0.0333f,0.9483f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.0662f,0.95f,-0.3031f,0.035f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.3739f,-0.0049f,0.0121f,0.9274f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.0121f,-0.9274f,0.3739f,0.0049f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.3893f,0.8518f,0.1073f],left_rotation:[0.1685f,-0.0861f,0.4664f,0.8641f]}}
tp 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 -94.558 65 5.318 -23.84 0
tp f74f363c-8714-5fe5-bb64-beafe6b6ac28 -94.558 65 5.318 -23.84 0
tp 97428e5f-5a51-575c-8305-607c4b0f68cb -94.558 65 5.318 -23.84 0
tp 186c432f-da2b-5bec-ba8a-9d97f056504e -94.558 65 5.318 -23.84 0
tp b7fef3cd-3066-54f8-9318-2747261e9dd9 -94.558 65 5.318 -23.84 0
tp 0d17ad00-82d8-5739-af58-9e93f268e98c -94.558 65 5.318 -23.84 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0059f,-0.0001f,0.0125f,0.9999f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.4959f,-0.1068f,-0.0008f,0.8618f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.0914f,0.8666f,-0.4874f,0.0552f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.3739f,-0.0049f,0.0121f,0.9274f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.0121f,-0.9274f,0.3739f,0.0049f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.3914f,0.8534f,0.2399f],left_rotation:[0.125f,-0.1364f,0.7406f,0.6459f]}}
particle minecraft:campfire_cosy_smoke -95.49 65.12 -0.85 0.031 0.014 -0.08 1 0 force
