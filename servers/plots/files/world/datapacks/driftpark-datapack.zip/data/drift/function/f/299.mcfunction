tp 425483f9-2934-53dd-805b-82336df4bdbc -12.674 65 -12.341 110.71 0
tp 77d4edec-4f89-5806-8a73-69da291cf64a -12.674 65 -12.341 110.71 0
tp a18c987f-26df-590a-b51c-8f6379e10218 -12.674 65 -12.341 110.71 0
tp 8bd36e4e-1a75-51ba-b224-63055ff644c2 -12.674 65 -12.341 110.71 0
tp 7b07c259-0b81-5b46-b286-5b101f183bf9 -12.674 65 -12.341 110.71 0
tp 04fc5281-333c-5c0d-ba69-0b625cbc7206 -12.674 65 -12.341 110.71 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0.0061f,-0.0001f,-0.0223f,0.9997f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.6121f,0.187f,0.2271f,0.734f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.1512f,-0.7142f,0.6351f,0.2523f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.8952f,0.0117f,0.0058f,0.4454f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.0058f,0.4454f,0.8952f,0.0117f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.3314f,0.8742f,0.1204f],left_rotation:[0.1714f,-0.0966f,0.4428f,0.8748f]}}
particle minecraft:campfire_cosy_smoke -9.27 65.12 -12.51 0.015 0.022 0.028 1 0 force
particle minecraft:cloud -9.27 65.32 -12.51 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -9.27 65.42 -12.51 0.45 0.2 0.45 0.008 1 force
particle minecraft:cloud -8.89 65.32 -14.14 0.35 0.18 0.35 0.02 3 force
tp 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 -3.877 65 -17.467 89.03 0
tp f74f363c-8714-5fe5-bb64-beafe6b6ac28 -3.877 65 -17.467 89.03 0
tp 97428e5f-5a51-575c-8305-607c4b0f68cb -3.877 65 -17.467 89.03 0
tp 186c432f-da2b-5bec-ba8a-9d97f056504e -3.877 65 -17.467 89.03 0
tp b7fef3cd-3066-54f8-9318-2747261e9dd9 -3.877 65 -17.467 89.03 0
tp 0d17ad00-82d8-5739-af58-9e93f268e98c -3.877 65 -17.467 89.03 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0.0112f,-0.0002f,-0.0214f,0.9997f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.8253f,0.103f,0.2901f,0.4734f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.2419f,-0.4455f,0.8407f,0.1903f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.8952f,0.0117f,0.0058f,0.4454f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.0058f,0.4454f,0.8952f,0.0117f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.3331f,0.8692f,0.2692f],left_rotation:[0.1873f,-0.0751f,0.3254f,0.9238f]}}
particle minecraft:campfire_cosy_smoke 0.03 65.12 -19.81 0.044 0.022 0 1 0 force
particle minecraft:cloud 0.03 65.32 -19.81 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud -0.31 65.32 -21.48 0.35 0.18 0.35 0.02 3 force
