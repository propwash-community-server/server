tp 425483f9-2934-53dd-805b-82336df4bdbc -87.614 65 25.836 -30.43 0
tp 77d4edec-4f89-5806-8a73-69da291cf64a -87.614 65 25.836 -30.43 0
tp a18c987f-26df-590a-b51c-8f6379e10218 -87.614 65 25.836 -30.43 0
tp 8bd36e4e-1a75-51ba-b224-63055ff644c2 -87.614 65 25.836 -30.43 0
tp 7b07c259-0b81-5b46-b286-5b101f183bf9 -87.614 65 25.836 -30.43 0
tp 04fc5281-333c-5c0d-ba69-0b625cbc7206 -87.614 65 25.836 -30.43 0
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.446f,-0.0277f,0.0725f,0.8917f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.0209f,0.889f,0.4514f,0.0747f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.3847f,0.005f,0.0121f,0.923f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.0121f,0.923f,0.3847f,0.005f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.3894f,0.8514f,0.11f],left_rotation:[0.1669f,-0.0924f,0.4947f,0.8479f]}}
tp 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 -93.527 65 8.815 -23.95 0
tp f74f363c-8714-5fe5-bb64-beafe6b6ac28 -93.527 65 8.815 -23.95 0
tp 97428e5f-5a51-575c-8305-607c4b0f68cb -93.527 65 8.815 -23.95 0
tp 186c432f-da2b-5bec-ba8a-9d97f056504e -93.527 65 8.815 -23.95 0
tp b7fef3cd-3066-54f8-9318-2747261e9dd9 -93.527 65 8.815 -23.95 0
tp 0d17ad00-82d8-5739-af58-9e93f268e98c -93.527 65 8.815 -23.95 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0059f,-0.0001f,0.0104f,0.9999f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.2684f,-0.0601f,0.0713f,0.9588f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.029f,0.9566f,0.2762f,0.0887f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.3847f,0.005f,0.0121f,0.923f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.0121f,0.923f,0.3847f,0.005f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.3878f,0.855f,0.2399f],left_rotation:[0.143f,-0.1174f,0.6393f,0.7463f]}}
particle minecraft:campfire_cosy_smoke -96.15 65.12 3.28 -0.054 0.013 -0.047 1 0 force
