tp 425483f9-2934-53dd-805b-82336df4bdbc -88.912 65 -40.204 2.08 0
tp 77d4edec-4f89-5806-8a73-69da291cf64a -88.912 65 -40.204 2.08 0
tp a18c987f-26df-590a-b51c-8f6379e10218 -88.912 65 -40.204 2.08 0
tp 8bd36e4e-1a75-51ba-b224-63055ff644c2 -88.912 65 -40.204 2.08 0
tp 7b07c259-0b81-5b46-b286-5b101f183bf9 -88.912 65 -40.204 2.08 0
tp 04fc5281-333c-5c0d-ba69-0b625cbc7206 -88.912 65 -40.204 2.08 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0058f,-0.0001f,0.0222f,0.9997f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.1591f,-0.2532f,0.0975f,0.9492f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.0017f,0.9442f,0.1866f,0.2713f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.4686f,-0.0061f,0.0116f,0.8833f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.0116f,-0.8833f,0.4686f,0.0061f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4078f,0.844f,0.1001f],left_rotation:[0.1378f,0.1237f,-0.6233f,0.7598f]}}
particle minecraft:cloud -86.05 65.32 -43.06 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -87.71 65.12 -43.29 -0.024 0.022 -0.031 1 0 force
particle minecraft:cloud -87.71 65.32 -43.29 0.35 0.18 0.35 0.02 3 force
tp 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 -82.396 65 -45.863 23.49 0
tp f74f363c-8714-5fe5-bb64-beafe6b6ac28 -82.396 65 -45.863 23.49 0
tp 97428e5f-5a51-575c-8305-607c4b0f68cb -82.396 65 -45.863 23.49 0
tp 186c432f-da2b-5bec-ba8a-9d97f056504e -82.396 65 -45.863 23.49 0
tp b7fef3cd-3066-54f8-9318-2747261e9dd9 -82.396 65 -45.863 23.49 0
tp 0d17ad00-82d8-5739-af58-9e93f268e98c -82.396 65 -45.863 23.49 0
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.6326f,-0.2677f,-0.1655f,0.7076f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.2407f,0.7289f,-0.608f,0.2027f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.4686f,-0.0061f,0.0116f,0.8833f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.0116f,-0.8833f,0.4686f,0.0061f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4078f,0.8395f,0.2606f],left_rotation:[0.1871f,0.0612f,-0.2629f,0.9445f]}}
particle minecraft:cloud -78.31 65.32 -47.28 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -79.78 65.12 -48.16 0.007 0.022 -0.023 1 0 force
particle minecraft:cloud -79.78 65.32 -48.16 0.35 0.18 0.35 0.02 3 force
