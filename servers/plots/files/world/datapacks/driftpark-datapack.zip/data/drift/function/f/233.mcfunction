tp 425483f9-2934-53dd-805b-82336df4bdbc 24.559 65 -48.849 42.19 0
tp 77d4edec-4f89-5806-8a73-69da291cf64a 24.559 65 -48.849 42.19 0
tp a18c987f-26df-590a-b51c-8f6379e10218 24.559 65 -48.849 42.19 0
tp 8bd36e4e-1a75-51ba-b224-63055ff644c2 24.559 65 -48.849 42.19 0
tp 7b07c259-0b81-5b46-b286-5b101f183bf9 24.559 65 -48.849 42.19 0
tp 04fc5281-333c-5c0d-ba69-0b625cbc7206 24.559 65 -48.849 42.19 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0.0019f,0f,0.0223f,0.9998f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.2801f,-0.2338f,-0.0142f,0.931f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.1121f,0.9376f,-0.2571f,0.2057f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.2974f,-0.0039f,0.0125f,0.9547f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.0125f,-0.9547f,0.2974f,0.0039f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4079f,0.8423f,0.1132f],left_rotation:[0.09f,0.1703f,-0.8464f,0.4965f]}}
particle minecraft:campfire_cosy_smoke 29.66 65.12 -49.76 0.07 0.022 0.021 1 0 force
particle minecraft:cloud 29.66 65.32 -49.76 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud 28.55 65.32 -51.01 0.35 0.18 0.35 0.02 3 force
tp 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 37.24 65 -51.069 59.24 0
tp f74f363c-8714-5fe5-bb64-beafe6b6ac28 37.24 65 -51.069 59.24 0
tp 97428e5f-5a51-575c-8305-607c4b0f68cb 37.24 65 -51.069 59.24 0
tp 186c432f-da2b-5bec-ba8a-9d97f056504e 37.24 65 -51.069 59.24 0
tp b7fef3cd-3066-54f8-9318-2747261e9dd9 37.24 65 -51.069 59.24 0
tp 0d17ad00-82d8-5739-af58-9e93f268e98c 37.24 65 -51.069 59.24 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0.0056f,0.0001f,0.0223f,0.9997f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.7798f,-0.1007f,0.2277f,0.5744f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.1686f,0.5536f,0.7947f,0.1832f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.2974f,-0.0039f,0.0125f,0.9547f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.0125f,-0.9547f,0.2974f,0.0039f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4078f,0.8398f,0.2596f],left_rotation:[0.1151f,0.159f,-0.768f,0.6096f]}}
particle minecraft:campfire_cosy_smoke 42.8 65.12 -50.34 0.062 0.022 0.04 1 0 force
particle minecraft:cloud 42.8 65.32 -50.34 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud 42.08 65.32 -51.9 0.35 0.18 0.35 0.02 3 force
