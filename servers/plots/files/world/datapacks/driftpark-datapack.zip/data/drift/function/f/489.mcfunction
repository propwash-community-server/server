tp 425483f9-2934-53dd-805b-82336df4bdbc -86.118 65 29.438 -35.11 0
tp 77d4edec-4f89-5806-8a73-69da291cf64a -86.118 65 29.438 -35.11 0
tp a18c987f-26df-590a-b51c-8f6379e10218 -86.118 65 29.438 -35.11 0
tp 8bd36e4e-1a75-51ba-b224-63055ff644c2 -86.118 65 29.438 -35.11 0
tp 7b07c259-0b81-5b46-b286-5b101f183bf9 -86.118 65 29.438 -35.11 0
tp 04fc5281-333c-5c0d-ba69-0b625cbc7206 -86.118 65 29.438 -35.11 0
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.9426f,0.0267f,0.0842f,0.3221f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.0508f,0.3151f,0.945f,0.0723f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.9218f,0.0121f,0.0051f,0.3873f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.0051f,0.3873f,0.9218f,0.0121f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.3893f,0.8514f,0.11f],left_rotation:[0.154f,-0.1127f,0.5973f,0.779f]}}
particle minecraft:campfire_cosy_smoke -87.97 65.12 23.05 0.005 0.012 -0.078 1 0 force
tp 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 -92.581 65 12.428 -24.72 0
tp f74f363c-8714-5fe5-bb64-beafe6b6ac28 -92.581 65 12.428 -24.72 0
tp 97428e5f-5a51-575c-8305-607c4b0f68cb -92.581 65 12.428 -24.72 0
tp 186c432f-da2b-5bec-ba8a-9d97f056504e -92.581 65 12.428 -24.72 0
tp b7fef3cd-3066-54f8-9318-2747261e9dd9 -92.581 65 12.428 -24.72 0
tp 0d17ad00-82d8-5739-af58-9e93f268e98c -92.581 65 12.428 -24.72 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0058f,-0.0001f,0.0099f,0.9999f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.8729f,0.0136f,0.0841f,0.4804f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.034f,0.4742f,0.8763f,0.0781f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.9218f,0.0121f,0.0051f,0.3873f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.0051f,0.3873f,0.9218f,0.0121f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.387f,0.8553f,0.24f],left_rotation:[0.1531f,-0.104f,0.5684f,0.8017f]}}
particle minecraft:campfire_cosy_smoke -93.65 65.12 6.05 0.027 0.012 -0.071 1 0 force
