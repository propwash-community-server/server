tp 425483f9-2934-53dd-805b-82336df4bdbc 85.734 65 26.763 -182.64 0
tp 77d4edec-4f89-5806-8a73-69da291cf64a 85.734 65 26.763 -182.64 0
tp a18c987f-26df-590a-b51c-8f6379e10218 85.734 65 26.763 -182.64 0
tp 8bd36e4e-1a75-51ba-b224-63055ff644c2 85.734 65 26.763 -182.64 0
tp 7b07c259-0b81-5b46-b286-5b101f183bf9 85.734 65 26.763 -182.64 0
tp 04fc5281-333c-5c0d-ba69-0b625cbc7206 85.734 65 26.763 -182.64 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0f,0f,0.0223f,0.9998f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.8332f,-0.0568f,0.1934f,0.5149f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.1404f,0.4974f,0.8438f,0.1447f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.8501f,0.0111f,0.0069f,0.5265f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.0069f,0.5265f,0.8501f,0.0111f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4079f,0.8427f,0.1101f],left_rotation:[0.0333f,0.1879f,-0.958f,0.2142f]}}
particle minecraft:campfire_cosy_smoke 82.94 65.12 31.62 -0.073 0.022 0.039 1 0 force
particle minecraft:cloud 82.94 65.32 31.62 0.35 0.18 0.35 0.02 2 force
particle minecraft:cloud 84.61 65.32 31.68 0.35 0.18 0.35 0.02 2 force
tp 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 78.59 65 39.525 -169.32 0
tp f74f363c-8714-5fe5-bb64-beafe6b6ac28 78.59 65 39.525 -169.32 0
tp 97428e5f-5a51-575c-8305-607c4b0f68cb 78.59 65 39.525 -169.32 0
tp 186c432f-da2b-5bec-ba8a-9d97f056504e 78.59 65 39.525 -169.32 0
tp b7fef3cd-3066-54f8-9318-2747261e9dd9 78.59 65 39.525 -169.32 0
tp 0d17ad00-82d8-5739-af58-9e93f268e98c 78.59 65 39.525 -169.32 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0.0035f,0.0001f,0.0223f,0.9997f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.9711f,-0.0716f,-0.2126f,0.0812f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.2223f,-0.104f,0.969f,0.0301f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.8501f,0.0111f,0.0069f,0.5265f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.0069f,0.5265f,0.8501f,0.0111f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4078f,0.8409f,0.256f],left_rotation:[0.0741f,0.1795f,-0.8891f,0.4144f]}}
particle minecraft:campfire_cosy_smoke 74.23 65.12 43.84 -0.088 0.022 0.032 1 0 force
particle minecraft:cloud 74.23 65.32 43.84 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud 75.88 65.32 44.3 0.35 0.18 0.35 0.02 3 force
