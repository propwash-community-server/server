tp 425483f9-2934-53dd-805b-82336df4bdbc 80.897 65 -24.956 118.9 0
tp 77d4edec-4f89-5806-8a73-69da291cf64a 80.897 65 -24.956 118.9 0
tp a18c987f-26df-590a-b51c-8f6379e10218 80.897 65 -24.956 118.9 0
tp 8bd36e4e-1a75-51ba-b224-63055ff644c2 80.897 65 -24.956 118.9 0
tp 7b07c259-0b81-5b46-b286-5b101f183bf9 80.897 65 -24.956 118.9 0
tp 04fc5281-333c-5c0d-ba69-0b625cbc7206 80.897 65 -24.956 118.9 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0.0023f,0.0001f,0.0223f,0.9997f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.9734f,-0.0749f,-0.186f,0.1108f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.1986f,-0.1309f,0.9709f,0.027f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.9941f,-0.013f,0.0014f,0.1072f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.0014f,-0.1072f,0.9941f,0.013f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4079f,0.8422f,0.1139f],left_rotation:[0.0316f,0.1904f,-0.9599f,0.2035f]}}
particle minecraft:cloud 83.64 65.32 -19.93 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke 84.57 65.12 -21.32 0.048 0.022 0.02 1 0 force
particle minecraft:cloud 84.57 65.32 -21.32 0.35 0.18 0.35 0.02 2 force
tp 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 88.246 65 -11.966 132.02 0
tp f74f363c-8714-5fe5-bb64-beafe6b6ac28 88.246 65 -11.966 132.02 0
tp 97428e5f-5a51-575c-8305-607c4b0f68cb 88.246 65 -11.966 132.02 0
tp 186c432f-da2b-5bec-ba8a-9d97f056504e 88.246 65 -11.966 132.02 0
tp b7fef3cd-3066-54f8-9318-2747261e9dd9 88.246 65 -11.966 132.02 0
tp 0d17ad00-82d8-5739-af58-9e93f268e98c 88.246 65 -11.966 132.02 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0.0002f,0f,0.0223f,0.9998f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.5107f,-0.2127f,-0.0679f,0.8303f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.1555f,0.842f,-0.4912f,0.1602f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.9941f,-0.013f,0.0014f,0.1072f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.0014f,-0.1072f,0.9941f,0.013f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4079f,0.8426f,0.2503f],left_rotation:[0.0711f,0.1772f,-0.8938f,0.4059f]}}
particle minecraft:cloud 89.68 65.32 -6.12 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 90.93 65.12 -7.29 0.048 0.022 0.021 1 0 force
particle minecraft:cloud 90.93 65.32 -7.29 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 90.93 65.42 -7.29 0.45 0.2 0.45 0.008 1 force
