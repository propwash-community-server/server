tp 425483f9-2934-53dd-805b-82336df4bdbc -95.559 65 -0.469 -23.88 0
tp 77d4edec-4f89-5806-8a73-69da291cf64a -95.559 65 -0.469 -23.88 0
tp a18c987f-26df-590a-b51c-8f6379e10218 -95.559 65 -0.469 -23.88 0
tp 8bd36e4e-1a75-51ba-b224-63055ff644c2 -95.559 65 -0.469 -23.88 0
tp 7b07c259-0b81-5b46-b286-5b101f183bf9 -95.559 65 -0.469 -23.88 0
tp 04fc5281-333c-5c0d-ba69-0b625cbc7206 -95.559 65 -0.469 -23.88 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0058f,-0.0001f,0.0157f,0.9999f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.0118f,-0.1177f,0.0513f,0.9917f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.0526f,0.9917f,0.0006f,0.1171f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.0754f,-0.001f,0.0131f,0.9971f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.0131f,-0.9971f,0.0754f,0.001f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.3969f,0.8492f,0.0999f],left_rotation:[0.0929f,-0.1601f,0.8651f,0.4663f]}}
particle minecraft:cloud -96.03 65.32 -6.39 0.35 0.18 0.35 0.02 1 force
particle minecraft:campfire_cosy_smoke -97.54 65.12 -5.67 -0.045 0.016 -0.033 1 0 force
particle minecraft:cloud -97.54 65.32 -5.67 0.35 0.18 0.35 0.02 1 force
tp 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 -97.848 65 -15.391 -26.82 0
tp f74f363c-8714-5fe5-bb64-beafe6b6ac28 -97.848 65 -15.391 -26.82 0
tp 97428e5f-5a51-575c-8305-607c4b0f68cb -97.848 65 -15.391 -26.82 0
tp 186c432f-da2b-5bec-ba8a-9d97f056504e -97.848 65 -15.391 -26.82 0
tp b7fef3cd-3066-54f8-9318-2747261e9dd9 -97.848 65 -15.391 -26.82 0
tp 0d17ad00-82d8-5739-af58-9e93f268e98c -97.848 65 -15.391 -26.82 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0058f,-0.0001f,0.0188f,0.9998f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.3097f,-0.214f,-0.0151f,0.9263f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.1126f,0.933f,-0.2889f,0.1826f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.0754f,-0.001f,0.0131f,0.9971f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.0131f,-0.9971f,0.0754f,0.001f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4021f,0.8484f,0.24f],left_rotation:[0.055f,0.1767f,-0.9266f,0.3273f]}}
particle minecraft:cloud -97.34 65.32 -20.93 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -98.91 65.12 -20.25 -0.039 0.022 -0.031 1 0 force
particle minecraft:cloud -98.91 65.32 -20.25 0.35 0.18 0.35 0.02 3 force
