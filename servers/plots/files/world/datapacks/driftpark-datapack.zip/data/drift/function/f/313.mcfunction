tp 425483f9-2934-53dd-805b-82336df4bdbc -21.669 65 -10.995 132.25 0
tp 77d4edec-4f89-5806-8a73-69da291cf64a -21.669 65 -10.995 132.25 0
tp a18c987f-26df-590a-b51c-8f6379e10218 -21.669 65 -10.995 132.25 0
tp 8bd36e4e-1a75-51ba-b224-63055ff644c2 -21.669 65 -10.995 132.25 0
tp 7b07c259-0b81-5b46-b286-5b101f183bf9 -21.669 65 -10.995 132.25 0
tp 04fc5281-333c-5c0d-ba69-0b625cbc7206 -21.669 65 -10.995 132.25 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0049f,0.0001f,-0.0223f,0.9997f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.533f,0.2535f,-0.1035f,0.8006f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.1882f,-0.8159f,-0.5093f,0.1989f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.5241f,0.0069f,0.0111f,0.8516f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.0111f,0.8516f,0.5241f,0.0069f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.3313f,0.8766f,0.1016f],left_rotation:[0.1413f,-0.121f,0.6051f,0.7741f]}}
particle minecraft:campfire_cosy_smoke -18.36 65.12 -9.66 0.002 0.022 0.034 1 0 force
particle minecraft:cloud -18.36 65.32 -9.66 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -18.36 65.42 -9.66 0.45 0.2 0.45 0.008 1 force
particle minecraft:cloud -17.37 65.32 -11 0.35 0.18 0.35 0.02 3 force
tp 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 -12.331 65 -11.502 115.29 0
tp f74f363c-8714-5fe5-bb64-beafe6b6ac28 -12.331 65 -11.502 115.29 0
tp 97428e5f-5a51-575c-8305-607c4b0f68cb -12.331 65 -11.502 115.29 0
tp 186c432f-da2b-5bec-ba8a-9d97f056504e -12.331 65 -11.502 115.29 0
tp b7fef3cd-3066-54f8-9318-2747261e9dd9 -12.331 65 -11.502 115.29 0
tp 0d17ad00-82d8-5739-af58-9e93f268e98c -12.331 65 -11.502 115.29 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0.0061f,-0.0001f,-0.0223f,0.9997f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.32f,0.2826f,0.1603f,0.89f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.0677f,-0.878f,0.3515f,0.3178f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.5241f,0.0069f,0.0111f,0.8516f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.0111f,0.8516f,0.5241f,0.0069f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.3315f,0.8725f,0.2604f],left_rotation:[0.1921f,-0.0425f,0.1691f,0.9658f]}}
particle minecraft:campfire_cosy_smoke -8.82 65.12 -11.6 0.021 0.022 0.026 1 0 force
particle minecraft:cloud -8.82 65.32 -11.6 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud -8.3 65.32 -13.23 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -8.3 65.42 -13.23 0.45 0.2 0.45 0.008 1 force
