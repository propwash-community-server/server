tp 425483f9-2934-53dd-805b-82336df4bdbc -40.828 65 -21.013 155.48 0
tp 77d4edec-4f89-5806-8a73-69da291cf64a -40.828 65 -21.013 155.48 0
tp a18c987f-26df-590a-b51c-8f6379e10218 -40.828 65 -21.013 155.48 0
tp 8bd36e4e-1a75-51ba-b224-63055ff644c2 -40.828 65 -21.013 155.48 0
tp 7b07c259-0b81-5b46-b286-5b101f183bf9 -40.828 65 -21.013 155.48 0
tp 04fc5281-333c-5c0d-ba69-0b625cbc7206 -40.828 65 -21.013 155.48 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0058f,0.0001f,-0.0174f,0.9998f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.6606f,0.084f,0.1474f,0.7313f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.0713f,-0.7198f,0.6731f,0.1539f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.6767f,0.0089f,0.0096f,0.7362f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.0096f,0.7362f,0.6767f,0.0089f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.3398f,0.8736f,0.0999f],left_rotation:[0.0231f,0.1836f,-0.9787f,0.0888f]}}
particle minecraft:cloud -38.75 65.32 -17.19 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -38.75 65.42 -17.19 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke -37.19 65.12 -17.8 0.076 0.02 0.005 1 0 force
particle minecraft:cloud -37.19 65.32 -17.8 0.35 0.18 0.35 0.02 2 force
tp 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 -32.787 65 -13.248 157.99 0
tp f74f363c-8714-5fe5-bb64-beafe6b6ac28 -32.787 65 -13.248 157.99 0
tp 97428e5f-5a51-575c-8305-607c4b0f68cb -32.787 65 -13.248 157.99 0
tp 186c432f-da2b-5bec-ba8a-9d97f056504e -32.787 65 -13.248 157.99 0
tp b7fef3cd-3066-54f8-9318-2747261e9dd9 -32.787 65 -13.248 157.99 0
tp 0d17ad00-82d8-5739-af58-9e93f268e98c -32.787 65 -13.248 157.99 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0.0027f,-0.0001f,-0.0223f,0.9997f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.9415f,-0.002f,0.2879f,0.1751f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.2711f,-0.1458f,0.9465f,0.097f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.6767f,0.0089f,0.0096f,0.7362f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.0096f,0.7362f,0.6767f,0.0089f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.3314f,0.8742f,0.2547f],left_rotation:[0.1626f,-0.1049f,0.4948f,0.8472f]}}
particle minecraft:cloud -30.09 65.32 -10.43 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -28.57 65.12 -11.2 0.063 0.022 -0.009 1 0 force
particle minecraft:cloud -28.57 65.32 -11.2 0.35 0.18 0.35 0.02 3 force
