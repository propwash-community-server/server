tp 425483f9-2934-53dd-805b-82336df4bdbc -74.8 65 -46.295 49.48 0
tp 77d4edec-4f89-5806-8a73-69da291cf64a -74.8 65 -46.295 49.48 0
tp a18c987f-26df-590a-b51c-8f6379e10218 -74.8 65 -46.295 49.48 0
tp 8bd36e4e-1a75-51ba-b224-63055ff644c2 -74.8 65 -46.295 49.48 0
tp 7b07c259-0b81-5b46-b286-5b101f183bf9 -74.8 65 -46.295 49.48 0
tp 04fc5281-333c-5c0d-ba69-0b625cbc7206 -74.8 65 -46.295 49.48 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0.0035f,0.0001f,0.0223f,0.9997f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.3609f,-0.2355f,0.1544f,0.8891f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.0618f,0.8777f,0.3877f,0.2747f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.9863f,0.0129f,0.0022f,0.1647f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.0022f,0.1647f,0.9863f,0.0129f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4079f,0.8419f,0.116f],left_rotation:[0.1565f,0.115f,-0.5452f,0.8155f]}}
particle minecraft:campfire_cosy_smoke -70.24 65.12 -46.03 0.067 0.022 0.034 1 0 force
particle minecraft:cloud -70.24 65.32 -46.03 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -70.24 65.42 -46.03 0.45 0.2 0.45 0.008 1 force
particle minecraft:cloud -71.15 65.32 -47.43 0.35 0.18 0.35 0.02 3 force
tp 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 -64.06 65 -45.145 70.37 0
tp f74f363c-8714-5fe5-bb64-beafe6b6ac28 -64.06 65 -45.145 70.37 0
tp 97428e5f-5a51-575c-8305-607c4b0f68cb -64.06 65 -45.145 70.37 0
tp 186c432f-da2b-5bec-ba8a-9d97f056504e -64.06 65 -45.145 70.37 0
tp b7fef3cd-3066-54f8-9318-2747261e9dd9 -64.06 65 -45.145 70.37 0
tp 0d17ad00-82d8-5739-af58-9e93f268e98c -64.06 65 -45.145 70.37 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0.0037f,0.0001f,0.0223f,0.9997f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.3191f,-0.2975f,-0.0475f,0.8986f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.1422f,0.9085f,-0.2896f,0.2656f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.9863f,0.0129f,0.0022f,0.1647f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.0022f,0.1647f,0.9863f,0.0129f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4078f,0.8408f,0.2563f],left_rotation:[0.1755f,0.0837f,-0.3824f,0.9033f]}}
particle minecraft:campfire_cosy_smoke -59.73 65.12 -43.21 0.054 0.022 0.066 1 0 force
particle minecraft:cloud -59.73 65.32 -43.21 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -59.73 65.42 -43.21 0.45 0.2 0.45 0.008 1 force
particle minecraft:cloud -60.15 65.32 -44.87 0.35 0.18 0.35 0.02 3 force
