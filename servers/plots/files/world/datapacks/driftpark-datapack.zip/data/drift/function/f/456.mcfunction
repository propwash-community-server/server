tp 425483f9-2934-53dd-805b-82336df4bdbc -96.822 65 -9.202 -26.71 0
tp 77d4edec-4f89-5806-8a73-69da291cf64a -96.822 65 -9.202 -26.71 0
tp a18c987f-26df-590a-b51c-8f6379e10218 -96.822 65 -9.202 -26.71 0
tp 8bd36e4e-1a75-51ba-b224-63055ff644c2 -96.822 65 -9.202 -26.71 0
tp 7b07c259-0b81-5b46-b286-5b101f183bf9 -96.822 65 -9.202 -26.71 0
tp 04fc5281-333c-5c0d-ba69-0b625cbc7206 -96.822 65 -9.202 -26.71 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0059f,-0.0001f,0.0186f,0.9998f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.8503f,-0.1314f,-0.1201f,0.4953f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.1728f,0.5107f,-0.8412f,0.0428f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.8926f,-0.0117f,0.0059f,0.4506f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.0059f,-0.4506f,0.8926f,0.0117f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4018f,0.8469f,0.0998f],left_rotation:[0.0086f,-0.1848f,0.9827f,0.0091f]}}
particle minecraft:cloud -96.7 65.32 -14.83 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -98.22 65.12 -14.14 -0.028 0.02 -0.026 1 0 force
particle minecraft:cloud -98.22 65.32 -14.14 0.35 0.18 0.35 0.02 2 force
tp 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 -97.171 65 -23.141 -19.72 0
tp f74f363c-8714-5fe5-bb64-beafe6b6ac28 -97.171 65 -23.141 -19.72 0
tp 97428e5f-5a51-575c-8305-607c4b0f68cb -97.171 65 -23.141 -19.72 0
tp 186c432f-da2b-5bec-ba8a-9d97f056504e -97.171 65 -23.141 -19.72 0
tp b7fef3cd-3066-54f8-9318-2747261e9dd9 -97.171 65 -23.141 -19.72 0
tp 0d17ad00-82d8-5739-af58-9e93f268e98c -97.171 65 -23.141 -19.72 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0059f,-0.0001f,0.0172f,0.9998f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.9593f,-0.0911f,-0.2051f,0.1713f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.2242f,-0.1938f,0.955f,0.0092f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.8926f,-0.0117f,0.0059f,0.4506f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.0059f,-0.4506f,0.8926f,0.0117f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.3994f,0.8496f,0.2399f],left_rotation:[0.0716f,0.1706f,-0.8926f,0.4111f]}}
particle minecraft:cloud -95.92 65.32 -28.22 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -97.56 65.12 -27.74 -0.02 0.022 -0.025 1 0 force
particle minecraft:cloud -97.56 65.32 -27.74 0.35 0.18 0.35 0.02 3 force
