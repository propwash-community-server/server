tp 425483f9-2934-53dd-805b-82336df4bdbc -3.918 65 63.834 -90.61 0
tp 77d4edec-4f89-5806-8a73-69da291cf64a -3.918 65 63.834 -90.61 0
tp a18c987f-26df-590a-b51c-8f6379e10218 -3.918 65 63.834 -90.61 0
tp 8bd36e4e-1a75-51ba-b224-63055ff644c2 -3.918 65 63.834 -90.61 0
tp 7b07c259-0b81-5b46-b286-5b101f183bf9 -3.918 65 63.834 -90.61 0
tp 04fc5281-333c-5c0d-ba69-0b625cbc7206 -3.918 65 63.834 -90.61 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0f,0f,-0.0029f,1f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.0833f,-0.0007f,0.0525f,0.9951f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.0518f,-0.9951f,0.0837f,0.008f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.087f,-0.0011f,0.013f,0.9961f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.013f,-0.9961f,0.087f,0.0011f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.365f,0.8621f,0.11f],left_rotation:[0.1907f,0.0058f,-0.0353f,0.981f]}}
tp 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 -22.101 65 64.571 -90.88 0
tp f74f363c-8714-5fe5-bb64-beafe6b6ac28 -22.101 65 64.571 -90.88 0
tp 97428e5f-5a51-575c-8305-607c4b0f68cb -22.101 65 64.571 -90.88 0
tp 186c432f-da2b-5bec-ba8a-9d97f056504e -22.101 65 64.571 -90.88 0
tp b7fef3cd-3066-54f8-9318-2747261e9dd9 -22.101 65 64.571 -90.88 0
tp 0d17ad00-82d8-5739-af58-9e93f268e98c -22.101 65 64.571 -90.88 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0022f,0f,0.0079f,1f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.1055f,-0.0008f,0.0527f,0.993f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.0514f,0.9929f,0.1062f,0.0118f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.087f,-0.0011f,0.013f,0.9961f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.013f,-0.9961f,0.087f,0.0011f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.3836f,0.8551f,0.2462f],left_rotation:[0.1884f,-0.0093f,0.0638f,0.98f]}}
