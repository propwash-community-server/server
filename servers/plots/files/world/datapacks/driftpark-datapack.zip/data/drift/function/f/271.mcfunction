tp 425483f9-2934-53dd-805b-82336df4bdbc 2.978 65 -28.892 47.74 0
tp 77d4edec-4f89-5806-8a73-69da291cf64a 2.978 65 -28.892 47.74 0
tp a18c987f-26df-590a-b51c-8f6379e10218 2.978 65 -28.892 47.74 0
tp 8bd36e4e-1a75-51ba-b224-63055ff644c2 2.978 65 -28.892 47.74 0
tp 7b07c259-0b81-5b46-b286-5b101f183bf9 2.978 65 -28.892 47.74 0
tp 04fc5281-333c-5c0d-ba69-0b625cbc7206 2.978 65 -28.892 47.74 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0059f,0f,0.0017f,1f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.8303f,-0.0039f,0.0891f,0.5501f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.0318f,-0.5437f,0.8345f,0.0834f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.794f,-0.0104f,0.008f,0.6077f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.008f,-0.6077f,0.794f,0.0104f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.373f,0.8599f,0.0999f],left_rotation:[0.1468f,0.1126f,-0.5955f,0.7817f]}}
tp 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 8.339 65 -39.458 6.28 0
tp f74f363c-8714-5fe5-bb64-beafe6b6ac28 8.339 65 -39.458 6.28 0
tp 97428e5f-5a51-575c-8305-607c4b0f68cb 8.339 65 -39.458 6.28 0
tp 186c432f-da2b-5bec-ba8a-9d97f056504e 8.339 65 -39.458 6.28 0
tp b7fef3cd-3066-54f8-9318-2747261e9dd9 8.339 65 -39.458 6.28 0
tp 0d17ad00-82d8-5739-af58-9e93f268e98c 8.339 65 -39.458 6.28 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0057f,-0.0001f,0.021f,0.9998f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.9228f,-0.0219f,0.2427f,0.2985f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.2127f,0.2746f,0.9302f,0.119f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.794f,-0.0104f,0.008f,0.6077f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.008f,-0.6077f,0.794f,0.0104f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4059f,0.8465f,0.2402f],left_rotation:[0.1011f,0.1552f,-0.8001f,0.5705f]}}
particle minecraft:campfire_cosy_smoke 11.4 65.12 -42.96 0.06 0.022 -0.018 1 0 force
particle minecraft:cloud 11.4 65.32 -42.96 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 11.4 65.42 -42.96 0.45 0.2 0.45 0.008 1 force
particle minecraft:cloud 9.71 65.32 -43.17 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 9.71 65.42 -43.17 0.45 0.2 0.45 0.008 1 force
