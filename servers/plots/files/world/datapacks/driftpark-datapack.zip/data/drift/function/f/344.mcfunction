tp 425483f9-2934-53dd-805b-82336df4bdbc -41.981 65 -22.333 151.63 0
tp 77d4edec-4f89-5806-8a73-69da291cf64a -41.981 65 -22.333 151.63 0
tp a18c987f-26df-590a-b51c-8f6379e10218 -41.981 65 -22.333 151.63 0
tp 8bd36e4e-1a75-51ba-b224-63055ff644c2 -41.981 65 -22.333 151.63 0
tp 7b07c259-0b81-5b46-b286-5b101f183bf9 -41.981 65 -22.333 151.63 0
tp 04fc5281-333c-5c0d-ba69-0b625cbc7206 -41.981 65 -22.333 151.63 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0058f,0.0001f,-0.0153f,0.9999f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.9552f,-0.0167f,0.1394f,0.2607f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.1128f,-0.2475f,0.9587f,0.0836f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.2132f,0.0028f,0.0128f,0.9769f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.0128f,0.9769f,0.2132f,0.0028f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.3434f,0.8722f,0.0999f],left_rotation:[0.0732f,0.17f,-0.914f,0.361f]}}
particle minecraft:cloud -39.89 65.32 -18.35 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -38.35 65.12 -19.01 0.069 0.017 0.01 1 0 force
particle minecraft:cloud -38.35 65.32 -19.01 0.35 0.18 0.35 0.02 2 force
tp 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 -34.073 65 -13.995 160.17 0
tp f74f363c-8714-5fe5-bb64-beafe6b6ac28 -34.073 65 -13.995 160.17 0
tp 97428e5f-5a51-575c-8305-607c4b0f68cb -34.073 65 -13.995 160.17 0
tp 186c432f-da2b-5bec-ba8a-9d97f056504e -34.073 65 -13.995 160.17 0
tp b7fef3cd-3066-54f8-9318-2747261e9dd9 -34.073 65 -13.995 160.17 0
tp 0d17ad00-82d8-5739-af58-9e93f268e98c -34.073 65 -13.995 160.17 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0.0006f,0f,-0.0223f,0.9998f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.7145f,0.2231f,-0.167f,0.6417f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.2354f,-0.6628f,-0.695f,0.1493f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.2132f,0.0028f,0.0128f,0.9769f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.0128f,0.9769f,0.2132f,0.0028f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.3314f,0.8753f,0.251f],left_rotation:[0.1511f,-0.1175f,0.5677f,0.8007f]}}
particle minecraft:cloud -31.57 65.32 -11.04 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -30.01 65.12 -11.74 0.079 0.022 0.007 1 0 force
particle minecraft:cloud -30.01 65.32 -11.74 0.35 0.18 0.35 0.02 3 force
