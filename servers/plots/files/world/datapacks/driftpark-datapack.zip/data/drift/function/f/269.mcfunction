tp 425483f9-2934-53dd-805b-82336df4bdbc 3.848 65 -30.467 40.9 0
tp 77d4edec-4f89-5806-8a73-69da291cf64a 3.848 65 -30.467 40.9 0
tp a18c987f-26df-590a-b51c-8f6379e10218 3.848 65 -30.467 40.9 0
tp 8bd36e4e-1a75-51ba-b224-63055ff644c2 3.848 65 -30.467 40.9 0
tp 7b07c259-0b81-5b46-b286-5b101f183bf9 3.848 65 -30.467 40.9 0
tp 04fc5281-333c-5c0d-ba69-0b625cbc7206 3.848 65 -30.467 40.9 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0059f,0f,0.0054f,1f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.4434f,-0.0048f,0.0561f,0.8945f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.0377f,-0.8936f,0.4454f,0.0418f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.3793f,-0.005f,0.0121f,0.9252f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.0121f,-0.9252f,0.3793f,0.005f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.3793f,0.8572f,0.0999f],left_rotation:[0.1816f,0.0352f,-0.1767f,0.9667f]}}
particle minecraft:flame 6.25 65.22 -35.74 0.05 0.04 0.05 0.02 6 force
particle minecraft:large_smoke 6.25 65.22 -35.74 0.05 0.04 0.05 0.01 2 force
tp 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 9.314 65 -40.666 5.47 0
tp f74f363c-8714-5fe5-bb64-beafe6b6ac28 9.314 65 -40.666 5.47 0
tp 97428e5f-5a51-575c-8305-607c4b0f68cb 9.314 65 -40.666 5.47 0
tp 186c432f-da2b-5bec-ba8a-9d97f056504e 9.314 65 -40.666 5.47 0
tp b7fef3cd-3066-54f8-9318-2747261e9dd9 9.314 65 -40.666 5.47 0
tp 0d17ad00-82d8-5739-af58-9e93f268e98c 9.314 65 -40.666 5.47 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0024f,-0.0001f,0.0219f,0.9998f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.7667f,-0.1966f,-0.1675f,0.5878f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.2302f,0.6086f,-0.7502f,0.1171f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.3793f,-0.005f,0.0121f,0.9252f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.0121f,-0.9252f,0.3793f,0.005f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4074f,0.8442f,0.2459f],left_rotation:[0.1235f,0.1423f,-0.7127f,0.6756f]}}
particle minecraft:campfire_cosy_smoke 12.48 65.12 -43.97 0.065 0.022 -0.016 1 0 force
particle minecraft:cloud 12.48 65.32 -43.97 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud 10.78 65.32 -44.22 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 10.78 65.42 -44.22 0.45 0.2 0.45 0.008 1 force
