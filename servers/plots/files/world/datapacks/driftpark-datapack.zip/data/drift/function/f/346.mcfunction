tp 425483f9-2934-53dd-805b-82336df4bdbc -43.125 65 -23.714 147.57 0
tp 77d4edec-4f89-5806-8a73-69da291cf64a -43.125 65 -23.714 147.57 0
tp a18c987f-26df-590a-b51c-8f6379e10218 -43.125 65 -23.714 147.57 0
tp 8bd36e4e-1a75-51ba-b224-63055ff644c2 -43.125 65 -23.714 147.57 0
tp 7b07c259-0b81-5b46-b286-5b101f183bf9 -43.125 65 -23.714 147.57 0
tp 04fc5281-333c-5c0d-ba69-0b625cbc7206 -43.125 65 -23.714 147.57 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0058f,0.0001f,-0.013f,0.9999f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.9597f,0.0756f,-0.0784f,0.2591f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.1061f,0.2688f,0.957f,0.0248f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.3084f,-0.004f,0.0125f,0.9512f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.0125f,-0.9512f,0.3084f,0.004f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.3475f,0.8705f,0.1f],left_rotation:[0.1221f,0.1391f,-0.7553f,0.6287f]}}
particle minecraft:campfire_cosy_smoke -39.48 65.12 -20.31 0.062 0.015 0.018 1 0 force
tp 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 -35.323 65 -14.82 161.75 0
tp f74f363c-8714-5fe5-bb64-beafe6b6ac28 -35.323 65 -14.82 161.75 0
tp 97428e5f-5a51-575c-8305-607c4b0f68cb -35.323 65 -14.82 161.75 0
tp 186c432f-da2b-5bec-ba8a-9d97f056504e -35.323 65 -14.82 161.75 0
tp b7fef3cd-3066-54f8-9318-2747261e9dd9 -35.323 65 -14.82 161.75 0
tp 0d17ad00-82d8-5739-af58-9e93f268e98c -35.323 65 -14.82 161.75 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0031f,0.0001f,-0.0222f,0.9997f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.1064f,0.2565f,0.0831f,0.9571f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.017f,-0.9536f,0.1339f,0.2691f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.3084f,-0.004f,0.0125f,0.9512f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.0125f,-0.9512f,0.3084f,0.004f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.3313f,0.8771f,0.2446f],left_rotation:[0.1377f,-0.1276f,0.6351f,0.7493f]}}
particle minecraft:cloud -32.97 65.32 -11.72 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -31.38 65.12 -12.37 0.06 0.022 -0.001 1 0 force
particle minecraft:cloud -31.38 65.32 -12.37 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -31.38 65.42 -12.37 0.45 0.2 0.45 0.008 1 force
