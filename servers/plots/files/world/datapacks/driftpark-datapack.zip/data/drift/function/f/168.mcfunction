tp 425483f9-2934-53dd-805b-82336df4bdbc 83.117 65 -21.429 123.46 0
tp 77d4edec-4f89-5806-8a73-69da291cf64a 83.117 65 -21.429 123.46 0
tp a18c987f-26df-590a-b51c-8f6379e10218 83.117 65 -21.429 123.46 0
tp 8bd36e4e-1a75-51ba-b224-63055ff644c2 83.117 65 -21.429 123.46 0
tp 7b07c259-0b81-5b46-b286-5b101f183bf9 83.117 65 -21.429 123.46 0
tp 04fc5281-333c-5c0d-ba69-0b625cbc7206 83.117 65 -21.429 123.46 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0.0018f,0f,0.0223f,0.9998f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.3824f,-0.1991f,-0.0264f,0.9019f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.1214f,0.9097f,-0.3636f,0.16f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.3954f,-0.0052f,0.012f,0.9184f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.012f,-0.9184f,0.3954f,0.0052f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4079f,0.8423f,0.1131f],left_rotation:[0.0322f,0.1899f,-0.9592f,0.2068f]}}
particle minecraft:cloud 85.47 65.32 -16.15 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke 86.51 65.12 -17.45 0.04 0.022 0.019 1 0 force
particle minecraft:cloud 86.51 65.32 -17.45 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke 86.51 65.42 -17.45 0.45 0.2 0.45 0.008 1 force
tp 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 89.458 65 -7.755 136.69 0
tp f74f363c-8714-5fe5-bb64-beafe6b6ac28 89.458 65 -7.755 136.69 0
tp 97428e5f-5a51-575c-8305-607c4b0f68cb 89.458 65 -7.755 136.69 0
tp 186c432f-da2b-5bec-ba8a-9d97f056504e 89.458 65 -7.755 136.69 0
tp b7fef3cd-3066-54f8-9318-2747261e9dd9 89.458 65 -7.755 136.69 0
tp 0d17ad00-82d8-5739-af58-9e93f268e98c 89.458 65 -7.755 136.69 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0006f,0f,0.0223f,0.9998f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.4536f,-0.1663f,0.148f,0.863f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.0581f,0.8522f,0.4736f,0.2148f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.3954f,-0.0052f,0.012f,0.9184f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.012f,-0.9184f,0.3954f,0.0052f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4079f,0.843f,0.249f],left_rotation:[0.0697f,0.1771f,-0.8967f,0.3997f]}}
particle minecraft:cloud 90.43 65.32 -1.82 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 91.77 65.12 -2.89 0.04 0.022 0.021 1 0 force
particle minecraft:cloud 91.77 65.32 -2.89 0.35 0.18 0.35 0.02 3 force
