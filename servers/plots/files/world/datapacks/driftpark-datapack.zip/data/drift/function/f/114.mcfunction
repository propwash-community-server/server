tp 425483f9-2934-53dd-805b-82336df4bdbc 82.379 65 33.022 -174.68 0
tp 77d4edec-4f89-5806-8a73-69da291cf64a 82.379 65 33.022 -174.68 0
tp a18c987f-26df-590a-b51c-8f6379e10218 82.379 65 33.022 -174.68 0
tp 8bd36e4e-1a75-51ba-b224-63055ff644c2 82.379 65 33.022 -174.68 0
tp 7b07c259-0b81-5b46-b286-5b101f183bf9 82.379 65 33.022 -174.68 0
tp 04fc5281-333c-5c0d-ba69-0b625cbc7206 82.379 65 33.022 -174.68 0
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.9423f,-0.0018f,0.2027f,0.2664f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.1758f,0.2466f,0.9477f,0.1009f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.9621f,0.0126f,0.0036f,0.2723f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.0036f,0.2723f,0.9621f,0.0126f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4079f,0.8418f,0.1166f],left_rotation:[0.0359f,0.1912f,-0.955f,0.2237f]}}
particle minecraft:cloud 78.81 65.32 37.56 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke 78.81 65.42 37.56 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke 80.45 65.12 37.87 0.007 0.022 0.041 1 0 force
particle minecraft:cloud 80.45 65.32 37.87 0.35 0.18 0.35 0.02 2 force
tp 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 73.057 65 45.102 -160.89 0
tp f74f363c-8714-5fe5-bb64-beafe6b6ac28 73.057 65 45.102 -160.89 0
tp 97428e5f-5a51-575c-8305-607c4b0f68cb 73.057 65 45.102 -160.89 0
tp 186c432f-da2b-5bec-ba8a-9d97f056504e 73.057 65 45.102 -160.89 0
tp b7fef3cd-3066-54f8-9318-2747261e9dd9 73.057 65 45.102 -160.89 0
tp 0d17ad00-82d8-5739-af58-9e93f268e98c 73.057 65 45.102 -160.89 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0.0023f,0.0001f,0.0223f,0.9997f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.9245f,-0.1188f,-0.1849f,0.3113f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.2186f,0.3325f,-0.9171f,0.0223f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.9621f,0.0126f,0.0036f,0.2723f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.0036f,0.2723f,0.9621f,0.0126f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4078f,0.8415f,0.254f],left_rotation:[0.0658f,0.1815f,-0.9066f,0.3753f]}}
particle minecraft:cloud 68.05 65.32 48.89 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 68.05 65.42 48.89 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke 69.61 65.12 49.58 -0.003 0.022 0.053 1 0 force
particle minecraft:cloud 69.61 65.32 49.58 0.35 0.18 0.35 0.02 3 force
