tp 425483f9-2934-53dd-805b-82336df4bdbc 84.13 65 -19.579 125.83 0
tp 77d4edec-4f89-5806-8a73-69da291cf64a 84.13 65 -19.579 125.83 0
tp a18c987f-26df-590a-b51c-8f6379e10218 84.13 65 -19.579 125.83 0
tp 8bd36e4e-1a75-51ba-b224-63055ff644c2 84.13 65 -19.579 125.83 0
tp 7b07c259-0b81-5b46-b286-5b101f183bf9 84.13 65 -19.579 125.83 0
tp 04fc5281-333c-5c0d-ba69-0b625cbc7206 84.13 65 -19.579 125.83 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0.0015f,0f,0.0223f,0.9998f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.1244f,-0.1846f,0.0774f,0.9718f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.0243f,0.969f,0.1445f,0.1987f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.1216f,0.0016f,0.013f,0.9925f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.013f,0.9925f,0.1216f,0.0016f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4079f,0.8423f,0.1126f],left_rotation:[0.031f,0.1898f,-0.9605f,0.2011f]}}
particle minecraft:cloud 86.27 65.32 -14.18 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke 87.37 65.12 -15.45 0.038 0.022 0.016 1 0 force
particle minecraft:cloud 87.37 65.32 -15.45 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke 87.37 65.42 -15.45 0.45 0.2 0.45 0.008 1 force
tp 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 89.941 65 -5.617 138.92 0
tp f74f363c-8714-5fe5-bb64-beafe6b6ac28 89.941 65 -5.617 138.92 0
tp 97428e5f-5a51-575c-8305-607c4b0f68cb 89.941 65 -5.617 138.92 0
tp 186c432f-da2b-5bec-ba8a-9d97f056504e 89.941 65 -5.617 138.92 0
tp b7fef3cd-3066-54f8-9318-2747261e9dd9 89.941 65 -5.617 138.92 0
tp 0d17ad00-82d8-5739-af58-9e93f268e98c 89.941 65 -5.617 138.92 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0009f,0f,0.0223f,0.9998f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.8213f,-0.0711f,0.2107f,0.5254f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.1566f,0.5061f,0.8333f,0.1579f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.1216f,0.0016f,0.013f,0.9925f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.013f,0.9925f,0.1216f,0.0016f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4079f,0.8431f,0.2484f],left_rotation:[0.0692f,0.1769f,-0.8975f,0.3981f]}}
particle minecraft:cloud 90.68 65.32 0.34 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 90.68 65.42 0.34 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke 92.06 65.12 -0.67 0.047 0.022 0.024 1 0 force
particle minecraft:cloud 92.06 65.32 -0.67 0.35 0.18 0.35 0.02 3 force
