tp 425483f9-2934-53dd-805b-82336df4bdbc 85.944 65 -15.727 130.77 0
tp 77d4edec-4f89-5806-8a73-69da291cf64a 85.944 65 -15.727 130.77 0
tp a18c987f-26df-590a-b51c-8f6379e10218 85.944 65 -15.727 130.77 0
tp 8bd36e4e-1a75-51ba-b224-63055ff644c2 85.944 65 -15.727 130.77 0
tp 7b07c259-0b81-5b46-b286-5b101f183bf9 85.944 65 -15.727 130.77 0
tp 04fc5281-333c-5c0d-ba69-0b625cbc7206 85.944 65 -15.727 130.77 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0.0009f,0f,0.0223f,0.9998f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.9077f,-0.0228f,0.1972f,0.3698f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.1594f,0.3511f,0.915f,0.1183f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.9241f,0.0121f,0.005f,0.382f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.005f,0.382f,0.9241f,0.0121f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4079f,0.8425f,0.1115f],left_rotation:[0.0278f,0.1896f,-0.9638f,0.1856f]}}
particle minecraft:cloud 87.66 65.32 -10.15 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke 88.85 65.12 -11.31 0.037 0.022 0.032 1 0 force
particle minecraft:cloud 88.85 65.32 -11.31 0.35 0.18 0.35 0.02 2 force
tp 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 90.673 65 -1.31 143.47 0
tp f74f363c-8714-5fe5-bb64-beafe6b6ac28 90.673 65 -1.31 143.47 0
tp 97428e5f-5a51-575c-8305-607c4b0f68cb 90.673 65 -1.31 143.47 0
tp 186c432f-da2b-5bec-ba8a-9d97f056504e 90.673 65 -1.31 143.47 0
tp b7fef3cd-3066-54f8-9318-2747261e9dd9 90.673 65 -1.31 143.47 0
tp 0d17ad00-82d8-5739-af58-9e93f268e98c 90.673 65 -1.31 143.47 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0003f,0f,0.0223f,0.9998f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.8709f,-0.1448f,-0.1685f,0.4383f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.2155f,0.4585f,-0.8605f,0.0541f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.9241f,0.0121f,0.005f,0.382f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.005f,0.382f,0.9241f,0.0121f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4079f,0.8429f,0.2494f],left_rotation:[0.0692f,0.1775f,-0.8979f,0.3968f]}}
particle minecraft:cloud 90.92 65.32 4.66 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 92.37 65.12 3.76 0.04 0.022 0.036 1 0 force
particle minecraft:cloud 92.37 65.32 3.76 0.35 0.18 0.35 0.02 3 force
