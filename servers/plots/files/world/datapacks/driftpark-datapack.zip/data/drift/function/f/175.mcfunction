tp 425483f9-2934-53dd-805b-82336df4bdbc 79.074 65 -27.437 115.99 0
tp 77d4edec-4f89-5806-8a73-69da291cf64a 79.074 65 -27.437 115.99 0
tp a18c987f-26df-590a-b51c-8f6379e10218 79.074 65 -27.437 115.99 0
tp 8bd36e4e-1a75-51ba-b224-63055ff644c2 79.074 65 -27.437 115.99 0
tp 7b07c259-0b81-5b46-b286-5b101f183bf9 79.074 65 -27.437 115.99 0
tp 04fc5281-333c-5c0d-ba69-0b625cbc7206 79.074 65 -27.437 115.99 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0.0011f,0f,0.0223f,0.9998f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.6155f,-0.1823f,-0.0786f,0.7628f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.1592f,0.7752f,-0.5997f,0.1186f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.6328f,-0.0083f,0.0101f,0.7742f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.0101f,-0.7742f,0.6328f,0.0083f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4079f,0.8424f,0.1119f],left_rotation:[0.0278f,0.1899f,-0.9637f,0.1855f]}}
particle minecraft:campfire_cosy_smoke 82.09 65.12 -22.63 0.002 0.022 0.076 1 0 force
particle minecraft:cloud 82.09 65.32 -22.63 0.35 0.18 0.35 0.02 2 force
particle minecraft:cloud 82.93 65.32 -24.07 0.35 0.18 0.35 0.02 2 force
tp 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 87.13 65 -15.041 128.76 0
tp f74f363c-8714-5fe5-bb64-beafe6b6ac28 87.13 65 -15.041 128.76 0
tp 97428e5f-5a51-575c-8305-607c4b0f68cb 87.13 65 -15.041 128.76 0
tp 186c432f-da2b-5bec-ba8a-9d97f056504e 87.13 65 -15.041 128.76 0
tp b7fef3cd-3066-54f8-9318-2747261e9dd9 87.13 65 -15.041 128.76 0
tp 0d17ad00-82d8-5739-af58-9e93f268e98c 87.13 65 -15.041 128.76 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0.0007f,0f,0.0223f,0.9998f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.2342f,-0.1984f,0.1044f,0.946f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.0055f,0.9402f,0.2564f,0.2242f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.6328f,-0.0083f,0.0101f,0.7742f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.0101f,-0.7742f,0.6328f,0.0083f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4079f,0.8423f,0.2512f],left_rotation:[0.0729f,0.1771f,-0.89f,0.4138f]}}
particle minecraft:campfire_cosy_smoke 88.9 65.12 -9.3 -0.007 0.022 0.089 1 0 force
particle minecraft:cloud 88.9 65.32 -9.3 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud 90.07 65.32 -10.55 0.35 0.18 0.35 0.02 3 force
