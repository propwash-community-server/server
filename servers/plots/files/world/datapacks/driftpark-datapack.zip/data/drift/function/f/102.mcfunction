tp 425483f9-2934-53dd-805b-82336df4bdbc 74.2 65 43.009 -159.44 0
tp 77d4edec-4f89-5806-8a73-69da291cf64a 74.2 65 43.009 -159.44 0
tp a18c987f-26df-590a-b51c-8f6379e10218 74.2 65 43.009 -159.44 0
tp 8bd36e4e-1a75-51ba-b224-63055ff644c2 74.2 65 43.009 -159.44 0
tp 7b07c259-0b81-5b46-b286-5b101f183bf9 74.2 65 43.009 -159.44 0
tp 04fc5281-333c-5c0d-ba69-0b625cbc7206 74.2 65 43.009 -159.44 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0.0027f,0.0001f,0.0223f,0.9997f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.951f,0.0058f,0.1947f,0.24f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.1706f,0.2208f,0.9557f,0.0941f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.9696f,0.0127f,0.0032f,0.2443f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.0032f,0.2443f,0.9696f,0.0127f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4079f,0.8421f,0.1147f],left_rotation:[0.0214f,0.1923f,-0.9693f,0.1517f]}}
particle minecraft:cloud 69.43 65.32 46.77 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke 70.94 65.12 47.48 0 0.021 0.058 1 0 force
particle minecraft:cloud 70.94 65.32 47.48 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke 70.94 65.42 47.48 0.45 0.2 0.45 0.008 1 force
tp 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 61.719 65 53.124 -147.42 0
tp f74f363c-8714-5fe5-bb64-beafe6b6ac28 61.719 65 53.124 -147.42 0
tp 97428e5f-5a51-575c-8305-607c4b0f68cb 61.719 65 53.124 -147.42 0
tp 186c432f-da2b-5bec-ba8a-9d97f056504e 61.719 65 53.124 -147.42 0
tp b7fef3cd-3066-54f8-9318-2747261e9dd9 61.719 65 53.124 -147.42 0
tp 0d17ad00-82d8-5739-af58-9e93f268e98c 61.719 65 53.124 -147.42 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0.007f,0.0002f,0.0223f,0.9997f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.9355f,-0.1114f,-0.1865f,0.2787f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.2168f,0.2999f,-0.9289f,0.0137f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.9696f,0.0127f,0.0032f,0.2443f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.0032f,0.2443f,0.9696f,0.0127f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4077f,0.8391f,0.262f],left_rotation:[0.0629f,0.1874f,-0.9145f,0.3531f]}}
particle minecraft:cloud 55.77 65.32 55.79 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 57.14 65.12 56.81 -0.026 0.022 0.053 1 0 force
particle minecraft:cloud 57.14 65.32 56.81 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 57.14 65.42 56.81 0.45 0.2 0.45 0.008 1 force
