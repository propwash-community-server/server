tp 425483f9-2934-53dd-805b-82336df4bdbc -67.21 65 -45.26 68.44 0
tp 77d4edec-4f89-5806-8a73-69da291cf64a -67.21 65 -45.26 68.44 0
tp a18c987f-26df-590a-b51c-8f6379e10218 -67.21 65 -45.26 68.44 0
tp 8bd36e4e-1a75-51ba-b224-63055ff644c2 -67.21 65 -45.26 68.44 0
tp 7b07c259-0b81-5b46-b286-5b101f183bf9 -67.21 65 -45.26 68.44 0
tp 04fc5281-333c-5c0d-ba69-0b625cbc7206 -67.21 65 -45.26 68.44 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0025f,-0.0001f,0.0223f,0.9997f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.9152f,-0.0304f,0.2656f,0.3014f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.2354f,0.2752f,0.9235f,0.1267f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.7869f,0.0103f,0.0081f,0.6169f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.0081f,0.6169f,0.7869f,0.0103f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4079f,0.8432f,0.1057f],left_rotation:[0.1353f,0.1311f,-0.6513f,0.735f]}}
particle minecraft:campfire_cosy_smoke -62.95 65.12 -43.74 0.051 0.022 0.05 1 0 force
particle minecraft:cloud -62.95 65.32 -43.74 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud -63.4 65.32 -45.34 0.35 0.18 0.35 0.02 3 force
tp 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 -57.219 65 -41.165 85.46 0
tp f74f363c-8714-5fe5-bb64-beafe6b6ac28 -57.219 65 -41.165 85.46 0
tp 97428e5f-5a51-575c-8305-607c4b0f68cb -57.219 65 -41.165 85.46 0
tp 186c432f-da2b-5bec-ba8a-9d97f056504e -57.219 65 -41.165 85.46 0
tp b7fef3cd-3066-54f8-9318-2747261e9dd9 -57.219 65 -41.165 85.46 0
tp 0d17ad00-82d8-5739-af58-9e93f268e98c -57.219 65 -41.165 85.46 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0.0112f,0.0002f,0.0212f,0.9997f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.1593f,-0.2968f,0.0053f,0.9416f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.0936f,0.9462f,-0.1289f,0.2817f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.7869f,0.0103f,0.0081f,0.6169f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.0081f,0.6169f,0.7869f,0.0103f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4059f,0.8377f,0.2693f],left_rotation:[0.1784f,0.0944f,-0.421f,0.8843f]}}
particle minecraft:campfire_cosy_smoke -53.12 65.12 -37.68 0.026 0.022 0.078 1 0 force
particle minecraft:cloud -53.12 65.32 -37.68 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud -52.99 65.32 -39.38 0.35 0.18 0.35 0.02 3 force
