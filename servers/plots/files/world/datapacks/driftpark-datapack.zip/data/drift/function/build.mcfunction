forceload add ~ ~
kill @e[type=minecraft:marker,tag=drift.builder]
summon minecraft:marker ~ ~ ~ {Tags:["drift","drift.builder"]}
forceload add -160 -144 -33 -17
forceload add -160 -16 -33 111
forceload add -160 112 -33 143
forceload add -32 -144 95 -17
forceload add -32 -16 95 111
forceload add -32 112 95 143
forceload add 96 -144 159 -17
forceload add 96 -16 159 111
forceload add 96 112 159 143
tellraw @s {"text":"Building the Driftpark in this world, this takes about a minute …","color":"yellow"}
schedule function drift:build/step0 100t
