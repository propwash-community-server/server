tp 425483f9-2934-53dd-805b-82336df4bdbc 5.966 65 -34.227 23.53 0
tp 77d4edec-4f89-5806-8a73-69da291cf64a 5.966 65 -34.227 23.53 0
tp a18c987f-26df-590a-b51c-8f6379e10218 5.966 65 -34.227 23.53 0
tp 8bd36e4e-1a75-51ba-b224-63055ff644c2 5.966 65 -34.227 23.53 0
tp 7b07c259-0b81-5b46-b286-5b101f183bf9 5.966 65 -34.227 23.53 0
tp 04fc5281-333c-5c0d-ba69-0b625cbc7206 5.966 65 -34.227 23.53 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0059f,-0.0001f,0.0135f,0.9999f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.4977f,-0.1153f,-0.006f,0.8596f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.0963f,0.865f,-0.4883f,0.0636f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.5962f,-0.0078f,0.0105f,0.8028f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.0105f,-0.8028f,0.5962f,0.0078f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.393f,0.851f,0.0998f],left_rotation:[0.1125f,-0.1468f,0.7958f,0.5766f]}}
particle minecraft:cloud 8.9 65.32 -37.92 0.35 0.18 0.35 0.02 1 force
particle minecraft:campfire_cosy_smoke 7.29 65.12 -38.38 -0.015 0.016 -0.037 1 0 force
particle minecraft:cloud 7.29 65.32 -38.38 0.35 0.18 0.35 0.02 1 force
tp 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 11.836 65 -43.251 8.02 0
tp f74f363c-8714-5fe5-bb64-beafe6b6ac28 11.836 65 -43.251 8.02 0
tp 97428e5f-5a51-575c-8305-607c4b0f68cb 11.836 65 -43.251 8.02 0
tp 186c432f-da2b-5bec-ba8a-9d97f056504e 11.836 65 -43.251 8.02 0
tp b7fef3cd-3066-54f8-9318-2747261e9dd9 11.836 65 -43.251 8.02 0
tp 0d17ad00-82d8-5739-af58-9e93f268e98c 11.836 65 -43.251 8.02 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0.0063f,0.0001f,0.0223f,0.9997f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.1097f,-0.2915f,0.0213f,0.95f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.0784f,0.953f,-0.0797f,0.2816f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.5962f,-0.0078f,0.0105f,0.8028f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.0105f,-0.8028f,0.5962f,0.0078f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4078f,0.8395f,0.2608f],left_rotation:[0.1698f,0.0998f,-0.4585f,0.8666f]}}
particle minecraft:cloud 15.53 65.32 -46.22 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 13.87 65.12 -46.62 0.002 0.022 -0.023 1 0 force
particle minecraft:cloud 13.87 65.32 -46.62 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 13.87 65.42 -46.62 0.45 0.2 0.45 0.008 1 force
