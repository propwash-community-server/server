tp 425483f9-2934-53dd-805b-82336df4bdbc 48.929 65 -47.901 80.94 0
tp 77d4edec-4f89-5806-8a73-69da291cf64a 48.929 65 -47.901 80.94 0
tp a18c987f-26df-590a-b51c-8f6379e10218 48.929 65 -47.901 80.94 0
tp 8bd36e4e-1a75-51ba-b224-63055ff644c2 48.929 65 -47.901 80.94 0
tp 7b07c259-0b81-5b46-b286-5b101f183bf9 48.929 65 -47.901 80.94 0
tp 04fc5281-333c-5c0d-ba69-0b625cbc7206 48.929 65 -47.901 80.94 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0.0108f,0.0002f,0.0222f,0.9997f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.2837f,-0.1691f,0.1069f,0.9378f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.0089f,0.9317f,0.3031f,0.1999f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.2807f,0.0037f,0.0126f,0.9597f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.0126f,0.9597f,0.2807f,0.0037f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4077f,0.8401f,0.1285f],left_rotation:[0.0323f,0.1988f,-0.9589f,0.1998f]}}
particle minecraft:campfire_cosy_smoke 54.56 65.12 -45.43 0.054 0.021 0.069 1 0 force
particle minecraft:cloud 54.56 65.32 -45.43 0.35 0.18 0.35 0.02 2 force
particle minecraft:cloud 54.47 65.32 -47.1 0.35 0.18 0.35 0.02 2 force
tp 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 64.52 65 -41.214 95.54 0
tp f74f363c-8714-5fe5-bb64-beafe6b6ac28 64.52 65 -41.214 95.54 0
tp 97428e5f-5a51-575c-8305-607c4b0f68cb 64.52 65 -41.214 95.54 0
tp 186c432f-da2b-5bec-ba8a-9d97f056504e 64.52 65 -41.214 95.54 0
tp b7fef3cd-3066-54f8-9318-2747261e9dd9 64.52 65 -41.214 95.54 0
tp 0d17ad00-82d8-5739-af58-9e93f268e98c 64.52 65 -41.214 95.54 0
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.9615f,0.0156f,0.2066f,0.1804f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.1888f,0.1597f,0.9652f,0.0854f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.2807f,0.0037f,0.0126f,0.9597f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.0126f,0.9597f,0.2807f,0.0037f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.408f,0.8456f,0.2399f],left_rotation:[0.0419f,0.1803f,-0.9464f,0.2648f]}}
particle minecraft:campfire_cosy_smoke 69.64 65.12 -37.42 0.049 0.022 0.076 1 0 force
particle minecraft:cloud 69.64 65.32 -37.42 0.35 0.18 0.35 0.02 2 force
particle minecraft:cloud 69.92 65.32 -39.11 0.35 0.18 0.35 0.02 2 force
