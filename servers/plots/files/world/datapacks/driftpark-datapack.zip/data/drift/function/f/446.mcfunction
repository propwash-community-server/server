tp 425483f9-2934-53dd-805b-82336df4bdbc -96.785 65 -19.282 -19.65 0
tp 77d4edec-4f89-5806-8a73-69da291cf64a -96.785 65 -19.282 -19.65 0
tp a18c987f-26df-590a-b51c-8f6379e10218 -96.785 65 -19.282 -19.65 0
tp 8bd36e4e-1a75-51ba-b224-63055ff644c2 -96.785 65 -19.282 -19.65 0
tp 7b07c259-0b81-5b46-b286-5b101f183bf9 -96.785 65 -19.282 -19.65 0
tp 04fc5281-333c-5c0d-ba69-0b625cbc7206 -96.785 65 -19.282 -19.65 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0058f,-0.0001f,0.018f,0.9998f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.9807f,-0.0581f,-0.1848f,0.0257f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.1885f,-0.0453f,0.98f,0.0446f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.9994f,0.0131f,0.0004f,0.0319f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.0004f,0.0319f,0.9994f,0.0131f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4007f,0.8474f,0.0999f],left_rotation:[0.0193f,0.1841f,-0.9731f,0.1374f]}}
particle minecraft:cloud -95.76 65.32 -24.4 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -97.37 65.12 -23.93 -0.026 0.021 -0.032 1 0 force
particle minecraft:cloud -97.37 65.32 -23.93 0.35 0.18 0.35 0.02 2 force
tp 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 -94.894 65 -31.631 -11.28 0
tp f74f363c-8714-5fe5-bb64-beafe6b6ac28 -94.894 65 -31.631 -11.28 0
tp 97428e5f-5a51-575c-8305-607c4b0f68cb -94.894 65 -31.631 -11.28 0
tp 186c432f-da2b-5bec-ba8a-9d97f056504e -94.894 65 -31.631 -11.28 0
tp b7fef3cd-3066-54f8-9318-2747261e9dd9 -94.894 65 -31.631 -11.28 0
tp 0d17ad00-82d8-5739-af58-9e93f268e98c -94.894 65 -31.631 -11.28 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0059f,-0.0001f,0.0185f,0.9998f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.9409f,-0.11f,-0.2217f,0.2311f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.2472f,0.2557f,-0.9345f,0.0117f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.9994f,0.0131f,0.0004f,0.0319f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.0004f,0.0319f,0.9994f,0.0131f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4017f,0.8486f,0.2399f],left_rotation:[0.1069f,0.151f,-0.7805f,0.5971f]}}
particle minecraft:cloud -92.94 65.32 -36.03 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -92.94 65.42 -36.03 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke -94.63 65.12 -35.75 -0.015 0.022 -0.022 1 0 force
particle minecraft:cloud -94.63 65.32 -35.75 0.35 0.18 0.35 0.02 3 force
