tp 425483f9-2934-53dd-805b-82336df4bdbc -45.416 65 -26.632 137.81 0
tp 77d4edec-4f89-5806-8a73-69da291cf64a -45.416 65 -26.632 137.81 0
tp a18c987f-26df-590a-b51c-8f6379e10218 -45.416 65 -26.632 137.81 0
tp 8bd36e4e-1a75-51ba-b224-63055ff644c2 -45.416 65 -26.632 137.81 0
tp 7b07c259-0b81-5b46-b286-5b101f183bf9 -45.416 65 -26.632 137.81 0
tp 04fc5281-333c-5c0d-ba69-0b625cbc7206 -45.416 65 -26.632 137.81 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0059f,0f,-0.0076f,1f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.2437f,0.0309f,0.0462f,0.9683f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.0553f,-0.9687f,-0.2418f,0.0054f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.9799f,-0.0128f,0.0026f,0.199f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.0026f,-0.199f,0.9799f,0.0128f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.3569f,0.8667f,0.0999f],left_rotation:[0.1826f,0.0297f,-0.1722f,0.9675f]}}
tp 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 -37.86 65 -16.802 163.34 0
tp f74f363c-8714-5fe5-bb64-beafe6b6ac28 -37.86 65 -16.802 163.34 0
tp 97428e5f-5a51-575c-8305-607c4b0f68cb -37.86 65 -16.802 163.34 0
tp 186c432f-da2b-5bec-ba8a-9d97f056504e -37.86 65 -16.802 163.34 0
tp b7fef3cd-3066-54f8-9318-2747261e9dd9 -37.86 65 -16.802 163.34 0
tp 0d17ad00-82d8-5739-af58-9e93f268e98c -37.86 65 -16.802 163.34 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0059f,0.0001f,-0.0215f,0.9998f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.9232f,0.125f,-0.216f,0.2922f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.2479f,-0.3165f,-0.9152f,0.0286f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.9799f,-0.0128f,0.0026f,0.199f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.0026f,-0.199f,0.9799f,0.0128f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.3325f,0.878f,0.2399f],left_rotation:[0.1093f,-0.1493f,0.7671f,0.6142f]}}
particle minecraft:cloud -35.67 65.32 -13.35 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -34.05 65.12 -13.89 0.069 0.022 0.009 1 0 force
particle minecraft:cloud -34.05 65.32 -13.89 0.35 0.18 0.35 0.02 3 force
