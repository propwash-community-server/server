tp 425483f9-2934-53dd-805b-82336df4bdbc -49 65 -31.29 120.24 0
tp 77d4edec-4f89-5806-8a73-69da291cf64a -49 65 -31.29 120.24 0
tp a18c987f-26df-590a-b51c-8f6379e10218 -49 65 -31.29 120.24 0
tp 8bd36e4e-1a75-51ba-b224-63055ff644c2 -49 65 -31.29 120.24 0
tp 7b07c259-0b81-5b46-b286-5b101f183bf9 -49 65 -31.29 120.24 0
tp 04fc5281-333c-5c0d-ba69-0b625cbc7206 -49 65 -31.29 120.24 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0059f,0f,0.0026f,1f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.9676f,-0.0754f,-0.0931f,0.2224f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.117f,-0.2334f,0.965f,0.0259f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.1847f,0.0024f,0.0129f,0.9827f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.0129f,0.9827f,0.1847f,0.0024f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.3745f,0.8593f,0.0999f],left_rotation:[0.1043f,-0.1529f,0.8148f,0.5495f]}}
particle minecraft:campfire_cosy_smoke -45.07 65.12 -27.98 0.063 0.014 0.01 1 0 force
tp 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 -41.498 65 -20.409 158.53 0
tp f74f363c-8714-5fe5-bb64-beafe6b6ac28 -41.498 65 -20.409 158.53 0
tp 97428e5f-5a51-575c-8305-607c4b0f68cb -41.498 65 -20.409 158.53 0
tp 186c432f-da2b-5bec-ba8a-9d97f056504e -41.498 65 -20.409 158.53 0
tp b7fef3cd-3066-54f8-9318-2747261e9dd9 -41.498 65 -20.409 158.53 0
tp 0d17ad00-82d8-5739-af58-9e93f268e98c -41.498 65 -20.409 158.53 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0058f,0.0001f,-0.0174f,0.9998f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.7755f,0.072f,0.1799f,0.6009f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.1177f,-0.5853f,0.7873f,0.1539f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.1847f,0.0024f,0.0129f,0.9827f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.0129f,0.9827f,0.1847f,0.0024f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.3398f,0.8752f,0.2399f],left_rotation:[0.0195f,-0.184f,0.9731f,0.1373f]}}
particle minecraft:cloud -39.45 65.32 -16.45 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -37.82 65.12 -16.97 0.066 0.022 0.02 1 0 force
particle minecraft:cloud -37.82 65.32 -16.97 0.35 0.18 0.35 0.02 2 force
