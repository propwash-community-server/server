tp 425483f9-2934-53dd-805b-82336df4bdbc -74.571 65 49.578 -74.73 0
tp 77d4edec-4f89-5806-8a73-69da291cf64a -74.571 65 49.578 -74.73 0
tp a18c987f-26df-590a-b51c-8f6379e10218 -74.571 65 49.578 -74.73 0
tp 8bd36e4e-1a75-51ba-b224-63055ff644c2 -74.571 65 49.578 -74.73 0
tp 7b07c259-0b81-5b46-b286-5b101f183bf9 -74.571 65 49.578 -74.73 0
tp 04fc5281-333c-5c0d-ba69-0b625cbc7206 -74.571 65 49.578 -74.73 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0.0111f,0.0002f,0.0218f,0.9997f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.3765f,-0.1952f,0.1406f,0.8947f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.0473f,0.8848f,0.3991f,0.2358f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.3304f,0.0043f,0.0124f,0.9437f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.0124f,0.9437f,0.3304f,0.0043f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4071f,0.8404f,0.1291f],left_rotation:[0.1048f,0.1724f,-0.8139f,0.5449f]}}
particle minecraft:cloud -77.79 65.32 45.23 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -77.79 65.42 45.23 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke -78.41 65.12 46.78 -0.048 0.022 -0.007 1 0 force
particle minecraft:cloud -78.41 65.32 46.78 0.35 0.18 0.35 0.02 3 force
tp 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 -82.678 65 37.574 -52.75 0
tp f74f363c-8714-5fe5-bb64-beafe6b6ac28 -82.678 65 37.574 -52.75 0
tp 97428e5f-5a51-575c-8305-607c4b0f68cb -82.678 65 37.574 -52.75 0
tp 186c432f-da2b-5bec-ba8a-9d97f056504e -82.678 65 37.574 -52.75 0
tp b7fef3cd-3066-54f8-9318-2747261e9dd9 -82.678 65 37.574 -52.75 0
tp 0d17ad00-82d8-5739-af58-9e93f268e98c -82.678 65 37.574 -52.75 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0.0112f,0.0001f,0.0111f,0.9999f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.3273f,-0.1396f,0.1055f,0.9286f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.0085f,0.9226f,0.3438f,0.1748f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.3304f,0.0043f,0.0124f,0.9437f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.0124f,0.9437f,0.3304f,0.0043f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.3889f,0.8457f,0.2693f],left_rotation:[0.0137f,-0.2014f,0.9784f,0.0446f]}}
particle minecraft:cloud -85.13 65.32 31.44 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -86.36 65.12 32.63 -0.05 0.019 -0.037 1 0 force
particle minecraft:cloud -86.36 65.32 32.63 0.35 0.18 0.35 0.02 2 force
