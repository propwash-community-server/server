tp 425483f9-2934-53dd-805b-82336df4bdbc 85.316 65 27.676 -181.49 0
tp 77d4edec-4f89-5806-8a73-69da291cf64a 85.316 65 27.676 -181.49 0
tp a18c987f-26df-590a-b51c-8f6379e10218 85.316 65 27.676 -181.49 0
tp 8bd36e4e-1a75-51ba-b224-63055ff644c2 85.316 65 27.676 -181.49 0
tp 7b07c259-0b81-5b46-b286-5b101f183bf9 85.316 65 27.676 -181.49 0
tp 04fc5281-333c-5c0d-ba69-0b625cbc7206 85.316 65 27.676 -181.49 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0.0012f,0f,0.0223f,0.9998f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.2795f,-0.2018f,-0.0044f,0.9387f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.1031f,0.9443f,-0.2599f,0.1735f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.2863f,-0.0037f,0.0125f,0.9581f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.0125f,-0.9581f,0.2863f,0.0037f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4079f,0.8424f,0.1121f],left_rotation:[0.034f,0.189f,-0.9572f,0.2164f]}}
particle minecraft:cloud 82.41 65.32 32.49 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke 84.08 65.12 32.58 0.007 0.022 0.048 1 0 force
particle minecraft:cloud 84.08 65.32 32.58 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke 84.08 65.42 32.58 0.45 0.2 0.45 0.008 1 force
tp 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 77.858 65 40.352 -168.03 0
tp f74f363c-8714-5fe5-bb64-beafe6b6ac28 77.858 65 40.352 -168.03 0
tp 97428e5f-5a51-575c-8305-607c4b0f68cb 77.858 65 40.352 -168.03 0
tp 186c432f-da2b-5bec-ba8a-9d97f056504e 77.858 65 40.352 -168.03 0
tp b7fef3cd-3066-54f8-9318-2747261e9dd9 77.858 65 40.352 -168.03 0
tp 0d17ad00-82d8-5739-af58-9e93f268e98c 77.858 65 40.352 -168.03 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0.0034f,0.0001f,0.0223f,0.9997f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.3272f,-0.1864f,0.1233f,0.9182f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.0275f,0.9102f,0.3486f,0.2218f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.2863f,-0.0037f,0.0125f,0.9581f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.0125f,-0.9581f,0.2863f,0.0037f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4078f,0.841f,0.2558f],left_rotation:[0.0727f,0.18f,-0.8923f,0.4075f]}}
particle minecraft:cloud 73.4 65.32 44.6 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 75.04 65.12 45.09 -0.001 0.022 0.051 1 0 force
particle minecraft:cloud 75.04 65.32 45.09 0.35 0.18 0.35 0.02 3 force
