tp 425483f9-2934-53dd-805b-82336df4bdbc 89.828 65 -1.205 147.02 0
tp 77d4edec-4f89-5806-8a73-69da291cf64a 89.828 65 -1.205 147.02 0
tp a18c987f-26df-590a-b51c-8f6379e10218 89.828 65 -1.205 147.02 0
tp 8bd36e4e-1a75-51ba-b224-63055ff644c2 89.828 65 -1.205 147.02 0
tp 7b07c259-0b81-5b46-b286-5b101f183bf9 89.828 65 -1.205 147.02 0
tp 04fc5281-333c-5c0d-ba69-0b625cbc7206 89.828 65 -1.205 147.02 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0003f,0f,0.0223f,0.9998f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.9665f,-0.0844f,-0.1772f,0.1653f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.1955f,-0.1848f,0.963f,0.0167f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.9863f,-0.0129f,0.0022f,0.1647f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.0022f,-0.1647f,0.9863f,0.0129f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4079f,0.8428f,0.1094f],left_rotation:[0.0236f,0.189f,-0.9677f,0.1649f]}}
particle minecraft:cloud 89.94 65.32 4.59 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke 91.41 65.12 3.8 0.031 0.021 0.037 1 0 force
particle minecraft:cloud 91.41 65.32 3.8 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke 91.41 65.42 3.8 0.45 0.2 0.45 0.008 1 force
tp 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 90.417 65 13.835 159.25 0
tp f74f363c-8714-5fe5-bb64-beafe6b6ac28 90.417 65 13.835 159.25 0
tp 97428e5f-5a51-575c-8305-607c4b0f68cb 90.417 65 13.835 159.25 0
tp 186c432f-da2b-5bec-ba8a-9d97f056504e 90.417 65 13.835 159.25 0
tp b7fef3cd-3066-54f8-9318-2747261e9dd9 90.417 65 13.835 159.25 0
tp 0d17ad00-82d8-5739-af58-9e93f268e98c 90.417 65 13.835 159.25 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0012f,0f,0.0223f,0.9998f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.5681f,-0.208f,-0.0832f,0.7919f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.1669f,0.805f,-0.5494f,0.1494f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.9863f,-0.0129f,0.0022f,0.1647f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.0022f,-0.1647f,0.9863f,0.0129f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4079f,0.8433f,0.2479f],left_rotation:[0.0718f,0.1755f,-0.8912f,0.4121f]}}
particle minecraft:cloud 89.04 65.32 19.62 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 90.68 65.12 19.15 0.035 0.022 0.045 1 0 force
particle minecraft:cloud 90.68 65.32 19.15 0.35 0.18 0.35 0.02 3 force
