tp 425483f9-2934-53dd-805b-82336df4bdbc 14.136 65 -43.942 15.67 0
tp 77d4edec-4f89-5806-8a73-69da291cf64a 14.136 65 -43.942 15.67 0
tp a18c987f-26df-590a-b51c-8f6379e10218 14.136 65 -43.942 15.67 0
tp 8bd36e4e-1a75-51ba-b224-63055ff644c2 14.136 65 -43.942 15.67 0
tp 7b07c259-0b81-5b46-b286-5b101f183bf9 14.136 65 -43.942 15.67 0
tp 04fc5281-333c-5c0d-ba69-0b625cbc7206 14.136 65 -43.942 15.67 0
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.8801f,-0.1571f,-0.2203f,0.3902f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.2626f,0.4155f,-0.8684f,0.0655f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.7574f,-0.0099f,0.0085f,0.6528f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.0085f,-0.6528f,0.7574f,0.0099f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4078f,0.8412f,0.1212f],left_rotation:[0.1458f,0.1327f,-0.6271f,0.7536f]}}
particle minecraft:campfire_cosy_smoke 18.11 65.12 -46.43 0.065 0.022 -0.013 1 0 force
particle minecraft:cloud 18.11 65.32 -46.43 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud 16.56 65.32 -47.07 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 16.56 65.42 -47.07 0.45 0.2 0.45 0.008 1 force
tp 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 24.322 65 -49.721 38.23 0
tp f74f363c-8714-5fe5-bb64-beafe6b6ac28 24.322 65 -49.721 38.23 0
tp 97428e5f-5a51-575c-8305-607c4b0f68cb 24.322 65 -49.721 38.23 0
tp 186c432f-da2b-5bec-ba8a-9d97f056504e 24.322 65 -49.721 38.23 0
tp b7fef3cd-3066-54f8-9318-2747261e9dd9 24.322 65 -49.721 38.23 0
tp 0d17ad00-82d8-5739-af58-9e93f268e98c 24.322 65 -49.721 38.23 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0.0019f,0f,0.0223f,0.9998f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.4222f,-0.2071f,0.161f,0.8677f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.0707f,0.8556f,0.4463f,0.2526f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.7574f,-0.0099f,0.0085f,0.6528f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.0085f,-0.6528f,0.7574f,0.0099f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4079f,0.8417f,0.2532f],left_rotation:[0.1318f,0.1405f,-0.6853f,0.7023f]}}
particle minecraft:campfire_cosy_smoke 29.57 65.12 -50.81 0.083 0.022 0.021 1 0 force
particle minecraft:cloud 29.57 65.32 -50.81 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud 28.35 65.32 -52.01 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 28.35 65.42 -52.01 0.45 0.2 0.45 0.008 1 force
