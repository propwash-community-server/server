tp 425483f9-2934-53dd-805b-82336df4bdbc -36.047 65 -16.478 158.95 0
tp 77d4edec-4f89-5806-8a73-69da291cf64a -36.047 65 -16.478 158.95 0
tp a18c987f-26df-590a-b51c-8f6379e10218 -36.047 65 -16.478 158.95 0
tp 8bd36e4e-1a75-51ba-b224-63055ff644c2 -36.047 65 -16.478 158.95 0
tp 7b07c259-0b81-5b46-b286-5b101f183bf9 -36.047 65 -16.478 158.95 0
tp 04fc5281-333c-5c0d-ba69-0b625cbc7206 -36.047 65 -16.478 158.95 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0056f,0.0001f,-0.0221f,0.9997f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.7949f,0.0866f,0.2161f,0.5604f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.1583f,-0.5407f,0.8083f,0.1706f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.2807f,-0.0037f,0.0126f,0.9597f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.0126f,-0.9597f,0.2807f,0.0037f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.3317f,0.8767f,0.1003f],left_rotation:[0.0842f,-0.165f,0.8547f,0.4849f]}}
particle minecraft:cloud -33.77 65.32 -13.34 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -32.24 65.12 -14.02 0.061 0.022 0.003 1 0 force
particle minecraft:cloud -32.24 65.32 -14.02 0.35 0.18 0.35 0.02 3 force
tp 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 -27.054 65 -10.971 147.73 0
tp f74f363c-8714-5fe5-bb64-beafe6b6ac28 -27.054 65 -10.971 147.73 0
tp 97428e5f-5a51-575c-8305-607c4b0f68cb -27.054 65 -10.971 147.73 0
tp 186c432f-da2b-5bec-ba8a-9d97f056504e -27.054 65 -10.971 147.73 0
tp b7fef3cd-3066-54f8-9318-2747261e9dd9 -27.054 65 -10.971 147.73 0
tp 0d17ad00-82d8-5739-af58-9e93f268e98c -27.054 65 -10.971 147.73 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0022f,0f,-0.0223f,0.9998f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.8139f,0.1064f,0.2784f,0.4988f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.2276f,-0.4723f,0.8295f,0.1926f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.2807f,-0.0037f,0.0126f,0.9597f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.0126f,-0.9597f,0.2807f,0.0037f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.3313f,0.8767f,0.2463f],left_rotation:[0.1677f,-0.0864f,0.4104f,0.8922f]}}
particle minecraft:cloud -23.8 65.32 -8.83 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -22.47 65.12 -9.91 0.069 0.022 -0.019 1 0 force
particle minecraft:cloud -22.47 65.32 -9.91 0.35 0.18 0.35 0.02 3 force
