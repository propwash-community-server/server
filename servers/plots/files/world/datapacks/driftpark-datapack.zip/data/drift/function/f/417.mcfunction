tp 425483f9-2934-53dd-805b-82336df4bdbc -88.467 65 -40.69 2.09 0
tp 77d4edec-4f89-5806-8a73-69da291cf64a -88.467 65 -40.69 2.09 0
tp a18c987f-26df-590a-b51c-8f6379e10218 -88.467 65 -40.69 2.09 0
tp 8bd36e4e-1a75-51ba-b224-63055ff644c2 -88.467 65 -40.69 2.09 0
tp 7b07c259-0b81-5b46-b286-5b101f183bf9 -88.467 65 -40.69 2.09 0
tp 04fc5281-333c-5c0d-ba69-0b625cbc7206 -88.467 65 -40.69 2.09 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0055f,-0.0001f,0.0222f,0.9997f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.6809f,-0.2272f,-0.1507f,0.6797f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.223f,0.6993f,-0.6608f,0.1569f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.975f,0.0128f,0.0029f,0.2217f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.0029f,0.2217f,0.975f,0.0128f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4079f,0.8439f,0.1005f],left_rotation:[0.1395f,0.1221f,-0.6137f,0.7675f]}}
particle minecraft:campfire_cosy_smoke -85.54 65.12 -43.42 0.069 0.022 -0.018 1 0 force
particle minecraft:cloud -85.54 65.32 -43.42 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -85.54 65.42 -43.42 0.45 0.2 0.45 0.008 1 force
particle minecraft:cloud -87.19 65.32 -43.7 0.35 0.18 0.35 0.02 3 force
tp 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 -81.798 65 -46.078 24.59 0
tp f74f363c-8714-5fe5-bb64-beafe6b6ac28 -81.798 65 -46.078 24.59 0
tp 97428e5f-5a51-575c-8305-607c4b0f68cb -81.798 65 -46.078 24.59 0
tp 186c432f-da2b-5bec-ba8a-9d97f056504e -81.798 65 -46.078 24.59 0
tp b7fef3cd-3066-54f8-9318-2747261e9dd9 -81.798 65 -46.078 24.59 0
tp 0d17ad00-82d8-5739-af58-9e93f268e98c -81.798 65 -46.078 24.59 0
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.9378f,0.0074f,0.316f,0.1435f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.3026f,0.1111f,0.9422f,0.0912f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.975f,0.0128f,0.0029f,0.2217f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.0029f,0.2217f,0.975f,0.0128f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4078f,0.8395f,0.2607f],left_rotation:[0.1879f,0.0588f,-0.2508f,0.9478f]}}
particle minecraft:campfire_cosy_smoke -77.61 65.12 -47.37 0.072 0.022 0.013 1 0 force
particle minecraft:cloud -77.61 65.32 -47.37 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud -79.05 65.32 -48.3 0.35 0.18 0.35 0.02 3 force
