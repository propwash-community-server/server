tp 425483f9-2934-53dd-805b-82336df4bdbc -59.774 65 -41.882 84.75 0
tp 77d4edec-4f89-5806-8a73-69da291cf64a -59.774 65 -41.882 84.75 0
tp a18c987f-26df-590a-b51c-8f6379e10218 -59.774 65 -41.882 84.75 0
tp 8bd36e4e-1a75-51ba-b224-63055ff644c2 -59.774 65 -41.882 84.75 0
tp 7b07c259-0b81-5b46-b286-5b101f183bf9 -59.774 65 -41.882 84.75 0
tp 04fc5281-333c-5c0d-ba69-0b625cbc7206 -59.774 65 -41.882 84.75 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0.0107f,0.0002f,0.0221f,0.9997f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.6215f,-0.1713f,0.2165f,0.7331f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.1407f,0.7144f,0.643f,0.2376f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.7833f,-0.0103f,0.0081f,0.6215f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.0081f,-0.6215f,0.7833f,0.0103f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4076f,0.8403f,0.1284f],left_rotation:[0.1558f,0.1275f,-0.5862f,0.7848f]}}
particle minecraft:cloud -55.82 65.32 -38.87 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -55.76 65.12 -40.54 0.035 0.022 -0.021 1 0 force
particle minecraft:cloud -55.76 65.32 -40.54 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -55.76 65.42 -40.54 0.45 0.2 0.45 0.008 1 force
tp 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 -49.888 65 -33.198 110.79 0
tp f74f363c-8714-5fe5-bb64-beafe6b6ac28 -49.888 65 -33.198 110.79 0
tp 97428e5f-5a51-575c-8305-607c4b0f68cb -49.888 65 -33.198 110.79 0
tp 186c432f-da2b-5bec-ba8a-9d97f056504e -49.888 65 -33.198 110.79 0
tp b7fef3cd-3066-54f8-9318-2747261e9dd9 -49.888 65 -33.198 110.79 0
tp 0d17ad00-82d8-5739-af58-9e93f268e98c -49.888 65 -33.198 110.79 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0059f,0f,0.0064f,1f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.8844f,-0.0258f,0.1737f,0.4324f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.1292f,0.4165f,0.892f,0.1189f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.7833f,-0.0103f,0.0081f,0.6215f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.0081f,-0.6215f,0.7833f,0.0103f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.381f,0.8581f,0.2399f],left_rotation:[0.0106f,-0.1847f,0.9818f,0.0438f]}}
particle minecraft:cloud -46.94 65.32 -28.39 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -46 65.12 -29.82 0.048 0.019 0.006 1 0 force
particle minecraft:cloud -46 65.32 -29.82 0.35 0.18 0.35 0.02 2 force
