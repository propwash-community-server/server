tp 425483f9-2934-53dd-805b-82336df4bdbc 7.695 65 -37 13.55 0
tp 77d4edec-4f89-5806-8a73-69da291cf64a 7.695 65 -37 13.55 0
tp a18c987f-26df-590a-b51c-8f6379e10218 7.695 65 -37 13.55 0
tp 8bd36e4e-1a75-51ba-b224-63055ff644c2 7.695 65 -37 13.55 0
tp 7b07c259-0b81-5b46-b286-5b101f183bf9 7.695 65 -37 13.55 0
tp 04fc5281-333c-5c0d-ba69-0b625cbc7206 7.695 65 -37 13.55 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0058f,-0.0001f,0.0184f,0.9998f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.8118f,-0.0553f,0.1753f,0.5543f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.118f,0.5389f,0.8221f,0.1409f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.406f,0.0053f,0.012f,0.9138f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.012f,0.9138f,0.406f,0.0053f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4014f,0.847f,0.0999f],left_rotation:[0.0017f,0.1851f,-0.9817f,0.045f]}}
particle minecraft:cloud 10.64 65.32 -40.5 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke 9 65.12 -40.82 -0.021 0.021 -0.042 1 0 force
particle minecraft:cloud 9 65.32 -40.82 0.35 0.18 0.35 0.02 2 force
tp 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 14.238 65 -45.126 12.82 0
tp f74f363c-8714-5fe5-bb64-beafe6b6ac28 14.238 65 -45.126 12.82 0
tp 97428e5f-5a51-575c-8305-607c4b0f68cb 14.238 65 -45.126 12.82 0
tp 186c432f-da2b-5bec-ba8a-9d97f056504e 14.238 65 -45.126 12.82 0
tp b7fef3cd-3066-54f8-9318-2747261e9dd9 14.238 65 -45.126 12.82 0
tp 0d17ad00-82d8-5739-af58-9e93f268e98c 14.238 65 -45.126 12.82 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0.0065f,0.0001f,0.0223f,0.9997f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.9498f,0.0276f,0.2993f,0.0869f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.2918f,0.0559f,0.9521f,0.072f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.406f,0.0053f,0.012f,0.9138f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.012f,0.9138f,0.406f,0.0053f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4077f,0.8394f,0.2612f],left_rotation:[0.1774f,0.0861f,-0.3885f,0.9001f]}}
particle minecraft:cloud 18.39 65.32 -47.75 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 16.79 65.12 -48.34 0.004 0.022 -0.037 1 0 force
particle minecraft:cloud 16.79 65.32 -48.34 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 16.79 65.42 -48.34 0.45 0.2 0.45 0.008 1 force
