tp 425483f9-2934-53dd-805b-82336df4bdbc 88.657 65 -7.556 140.24 0
tp 77d4edec-4f89-5806-8a73-69da291cf64a 88.657 65 -7.556 140.24 0
tp a18c987f-26df-590a-b51c-8f6379e10218 88.657 65 -7.556 140.24 0
tp 8bd36e4e-1a75-51ba-b224-63055ff644c2 88.657 65 -7.556 140.24 0
tp 7b07c259-0b81-5b46-b286-5b101f183bf9 88.657 65 -7.556 140.24 0
tp 04fc5281-333c-5c0d-ba69-0b625cbc7206 88.657 65 -7.556 140.24 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0006f,0f,0.0223f,0.9998f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.1518f,-0.1787f,0.0819f,0.9687f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.0194f,0.9654f,0.1714f,0.1956f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.1504f,0.002f,0.0129f,0.9885f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.0129f,0.9885f,0.1504f,0.002f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4079f,0.8428f,0.109f],left_rotation:[0.0241f,0.1887f,-0.9673f,0.1678f]}}
particle minecraft:cloud 89.47 65.32 -1.77 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke 90.83 65.12 -2.73 0.046 0.021 0.025 1 0 force
particle minecraft:cloud 90.83 65.32 -2.73 0.35 0.18 0.35 0.02 2 force
tp 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 91.036 65 7.35 152.48 0
tp f74f363c-8714-5fe5-bb64-beafe6b6ac28 91.036 65 7.35 152.48 0
tp 97428e5f-5a51-575c-8305-607c4b0f68cb 91.036 65 7.35 152.48 0
tp 186c432f-da2b-5bec-ba8a-9d97f056504e 91.036 65 7.35 152.48 0
tp b7fef3cd-3066-54f8-9318-2747261e9dd9 91.036 65 7.35 152.48 0
tp 0d17ad00-82d8-5739-af58-9e93f268e98c 91.036 65 7.35 152.48 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0004f,0f,0.0223f,0.9998f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.802f,-0.0791f,0.2088f,0.5541f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.1517f,0.5352f,0.8147f,0.1638f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.1504f,0.002f,0.0129f,0.9885f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.0129f,0.9885f,0.1504f,0.002f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4079f,0.8429f,0.2493f],left_rotation:[0.0709f,0.1767f,-0.894f,0.4056f]}}
particle minecraft:cloud 90.35 65.32 13.29 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 90.35 65.42 13.29 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke 91.92 65.12 12.63 0.037 0.022 0.047 1 0 force
particle minecraft:cloud 91.92 65.32 12.63 0.35 0.18 0.35 0.02 3 force
