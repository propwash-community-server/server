tp 425483f9-2934-53dd-805b-82336df4bdbc -33.715 65 64.482 -95.08 0
tp 77d4edec-4f89-5806-8a73-69da291cf64a -33.715 65 64.482 -95.08 0
tp a18c987f-26df-590a-b51c-8f6379e10218 -33.715 65 64.482 -95.08 0
tp 8bd36e4e-1a75-51ba-b224-63055ff644c2 -33.715 65 64.482 -95.08 0
tp 7b07c259-0b81-5b46-b286-5b101f183bf9 -33.715 65 64.482 -95.08 0
tp 04fc5281-333c-5c0d-ba69-0b625cbc7206 -33.715 65 64.482 -95.08 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0059f,-0.0001f,0.0143f,0.9999f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.9524f,0.0279f,0.0885f,0.2905f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.0584f,0.2828f,0.9547f,0.0721f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.9572f,0.0125f,0.0038f,0.289f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.0038f,0.289f,0.9572f,0.0125f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.3945f,0.8503f,0.0998f],left_rotation:[0.1441f,-0.116f,0.6379f,0.7476f]}}
particle minecraft:campfire_cosy_smoke -39.94 65.12 63.48 -0.072 0.013 -0.045 1 0 force
tp 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 -50.104 65 63.202 -102.77 0
tp f74f363c-8714-5fe5-bb64-beafe6b6ac28 -50.104 65 63.202 -102.77 0
tp 97428e5f-5a51-575c-8305-607c4b0f68cb -50.104 65 63.202 -102.77 0
tp 186c432f-da2b-5bec-ba8a-9d97f056504e -50.104 65 63.202 -102.77 0
tp b7fef3cd-3066-54f8-9318-2747261e9dd9 -50.104 65 63.202 -102.77 0
tp 0d17ad00-82d8-5739-af58-9e93f268e98c -50.104 65 63.202 -102.77 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0058f,-0.0001f,0.0183f,0.9998f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.953f,0.007f,0.2007f,0.227f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.178f,0.2071f,0.9575f,0.0931f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.9572f,0.0125f,0.0038f,0.289f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.0038f,0.289f,0.9572f,0.0125f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4013f,0.8488f,0.2399f],left_rotation:[0.0317f,0.1823f,-0.9614f,0.2035f]}}
particle minecraft:campfire_cosy_smoke -55.8 65.12 61.54 -0.055 0.022 -0.047 1 0 force
particle minecraft:cloud -55.8 65.32 61.54 0.35 0.18 0.35 0.02 2 force
particle minecraft:cloud -55.49 65.32 63.22 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -55.49 65.42 63.22 0.45 0.2 0.45 0.008 1 force
