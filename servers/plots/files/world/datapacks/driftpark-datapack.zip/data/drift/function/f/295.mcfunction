tp 425483f9-2934-53dd-805b-82336df4bdbc -10.356 65 -13.465 103.88 0
tp 77d4edec-4f89-5806-8a73-69da291cf64a -10.356 65 -13.465 103.88 0
tp a18c987f-26df-590a-b51c-8f6379e10218 -10.356 65 -13.465 103.88 0
tp 8bd36e4e-1a75-51ba-b224-63055ff644c2 -10.356 65 -13.465 103.88 0
tp 7b07c259-0b81-5b46-b286-5b101f183bf9 -10.356 65 -13.465 103.88 0
tp 04fc5281-333c-5c0d-ba69-0b625cbc7206 -10.356 65 -13.465 103.88 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0.0086f,-0.0002f,-0.0223f,0.9997f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.9329f,0.1148f,-0.2787f,0.1968f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.301f,-0.2272f,-0.926f,0.0174f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.828f,-0.0108f,0.0073f,0.5606f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.0073f,-0.5606f,0.828f,0.0108f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.3315f,0.8736f,0.1248f],left_rotation:[0.18f,-0.0855f,0.3806f,0.903f]}}
particle minecraft:campfire_cosy_smoke -6.81 65.12 -14.19 0.016 0.022 0.01 1 0 force
particle minecraft:cloud -6.81 65.32 -14.19 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -6.81 65.42 -14.19 0.45 0.2 0.45 0.008 1 force
particle minecraft:cloud -6.65 65.32 -15.85 0.35 0.18 0.35 0.02 3 force
playsound driftpark:lap.kaze.05.104 neutral @a -4.54 65.5 -18.27 12 1
playsound driftpark:lap.kaze.05.105 neutral @a -9.2 65.5 -14.33 12 1
playsound driftpark:lap.kaze.05.106 neutral @a -13.84 65.5 -12.05 12 1
playsound driftpark:lap.kaze.05.107 neutral @a -18.92 65.5 -11.11 12 1
playsound driftpark:lap.kaze.05.108 neutral @a -24.62 65.5 -11.48 12 1
playsound driftpark:lap.kaze.05.109 neutral @a -30.32 65.5 -13.2 12 1
playsound driftpark:lap.kaze.05.110 neutral @a -35.41 65.5 -16.15 12 1
playsound driftpark:lap.kaze.05.111 neutral @a -40.22 65.5 -20.49 12 1
playsound driftpark:lap.kaze.05.112 neutral @a -44.85 65.5 -25.96 12 1
playsound driftpark:lap.kaze.05.113 neutral @a -49.7 65.5 -32.11 12 1
tp 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 -1.348 65 -20.139 78.99 0
tp f74f363c-8714-5fe5-bb64-beafe6b6ac28 -1.348 65 -20.139 78.99 0
tp 97428e5f-5a51-575c-8305-607c4b0f68cb -1.348 65 -20.139 78.99 0
tp 186c432f-da2b-5bec-ba8a-9d97f056504e -1.348 65 -20.139 78.99 0
tp b7fef3cd-3066-54f8-9318-2747261e9dd9 -1.348 65 -20.139 78.99 0
tp 0d17ad00-82d8-5739-af58-9e93f268e98c -1.348 65 -20.139 78.99 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0.003f,-0.0001f,-0.0193f,0.9998f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.0163f,0.2647f,0.0588f,0.9624f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.042f,-0.9615f,0.0442f,0.2679f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.828f,-0.0108f,0.0073f,0.5606f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.0073f,-0.5606f,0.828f,0.0108f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.3366f,0.8721f,0.2552f],left_rotation:[0.1444f,-0.1292f,0.6255f,0.7558f]}}
particle minecraft:campfire_cosy_smoke 2.35 65.12 -23.29 0.047 0.022 -0.013 1 0 force
particle minecraft:cloud 2.35 65.32 -23.29 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 2.35 65.42 -23.29 0.45 0.2 0.45 0.008 1 force
particle minecraft:cloud 1.7 65.32 -24.87 0.35 0.18 0.35 0.02 3 force
