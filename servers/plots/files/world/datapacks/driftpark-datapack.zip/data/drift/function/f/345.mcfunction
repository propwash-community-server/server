tp 425483f9-2934-53dd-805b-82336df4bdbc -42.554 65 -23.016 150 0
tp 77d4edec-4f89-5806-8a73-69da291cf64a -42.554 65 -23.016 150 0
tp a18c987f-26df-590a-b51c-8f6379e10218 -42.554 65 -23.016 150 0
tp 8bd36e4e-1a75-51ba-b224-63055ff644c2 -42.554 65 -23.016 150 0
tp 7b07c259-0b81-5b46-b286-5b101f183bf9 -42.554 65 -23.016 150 0
tp 04fc5281-333c-5c0d-ba69-0b625cbc7206 -42.554 65 -23.016 150 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0058f,0.0001f,-0.0142f,0.9999f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.0014f,0.1133f,0.0525f,0.9922f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.0515f,-0.9921f,0.0105f,0.1138f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.9987f,0.0131f,0.0006f,0.0493f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.0006f,0.0493f,0.9987f,0.0131f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.3454f,0.8714f,0.1f],left_rotation:[0.0983f,0.1568f,-0.8472f,0.4979f]}}
particle minecraft:campfire_cosy_smoke -40.44 65.12 -18.96 0.002 0.016 0.042 1 0 force
particle minecraft:cloud -40.44 65.32 -18.96 0.35 0.18 0.35 0.02 1 force
particle minecraft:cloud -38.92 65.32 -19.65 0.35 0.18 0.35 0.02 1 force
tp 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 -34.692 65 -14.392 161.08 0
tp f74f363c-8714-5fe5-bb64-beafe6b6ac28 -34.692 65 -14.392 161.08 0
tp 97428e5f-5a51-575c-8305-607c4b0f68cb -34.692 65 -14.392 161.08 0
tp 186c432f-da2b-5bec-ba8a-9d97f056504e -34.692 65 -14.392 161.08 0
tp b7fef3cd-3066-54f8-9318-2747261e9dd9 -34.692 65 -14.392 161.08 0
tp 0d17ad00-82d8-5739-af58-9e93f268e98c -34.692 65 -14.392 161.08 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0012f,0f,-0.0223f,0.9998f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.8982f,0.0452f,0.2701f,0.3438f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.2354f,-0.3174f,0.9079f,0.1399f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.9987f,0.0131f,0.0006f,0.0493f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.0006f,0.0493f,0.9987f,0.0131f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.3313f,0.8762f,0.248f],left_rotation:[0.1441f,-0.1233f,0.6045f,0.7737f]}}
particle minecraft:campfire_cosy_smoke -32.27 65.12 -11.37 -0.011 0.022 0.043 1 0 force
particle minecraft:cloud -32.27 65.32 -11.37 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -32.27 65.42 -11.37 0.45 0.2 0.45 0.008 1 force
particle minecraft:cloud -30.7 65.32 -12.05 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -30.7 65.42 -12.05 0.45 0.2 0.45 0.008 1 force
