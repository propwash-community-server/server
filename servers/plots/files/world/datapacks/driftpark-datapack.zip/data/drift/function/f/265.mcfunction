tp 425483f9-2934-53dd-805b-82336df4bdbc 5.543 65 -33.498 26.65 0
tp 77d4edec-4f89-5806-8a73-69da291cf64a 5.543 65 -33.498 26.65 0
tp a18c987f-26df-590a-b51c-8f6379e10218 5.543 65 -33.498 26.65 0
tp 8bd36e4e-1a75-51ba-b224-63055ff644c2 5.543 65 -33.498 26.65 0
tp 7b07c259-0b81-5b46-b286-5b101f183bf9 5.543 65 -33.498 26.65 0
tp 04fc5281-333c-5c0d-ba69-0b625cbc7206 5.543 65 -33.498 26.65 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0059f,-0.0001f,0.012f,0.9999f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.6506f,-0.0267f,0.0924f,0.7533f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.0138f,0.7477f,0.657f,0.0952f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.6192f,0.0081f,0.0103f,0.7851f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.0103f,0.7851f,0.6192f,0.0081f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.3905f,0.8521f,0.0998f],left_rotation:[0.1394f,-0.1216f,0.6637f,0.7247f]}}
particle minecraft:campfire_cosy_smoke 8.49 65.12 -37.22 0.064 0.014 -0.027 1 0 force
tp 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 11.3 65 -42.764 7.93 0
tp f74f363c-8714-5fe5-bb64-beafe6b6ac28 11.3 65 -42.764 7.93 0
tp 97428e5f-5a51-575c-8305-607c4b0f68cb 11.3 65 -42.764 7.93 0
tp 186c432f-da2b-5bec-ba8a-9d97f056504e 11.3 65 -42.764 7.93 0
tp b7fef3cd-3066-54f8-9318-2747261e9dd9 11.3 65 -42.764 7.93 0
tp 0d17ad00-82d8-5739-af58-9e93f268e98c 11.3 65 -42.764 7.93 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0.006f,0.0001f,0.0223f,0.9997f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.8128f,-0.1029f,0.268f,0.5069f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.2162f,0.4815f,0.8281f,0.1889f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.6192f,0.0081f,0.0103f,0.7851f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.0103f,0.7851f,0.6192f,0.0081f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4078f,0.8396f,0.2603f],left_rotation:[0.1644f,0.108f,-0.5012f,0.8427f]}}
particle minecraft:campfire_cosy_smoke 14.87 65.12 -45.8 0.069 0.022 -0.011 1 0 force
particle minecraft:cloud 14.87 65.32 -45.8 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud 13.2 65.32 -46.16 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 13.2 65.42 -46.16 0.45 0.2 0.45 0.008 1 force
