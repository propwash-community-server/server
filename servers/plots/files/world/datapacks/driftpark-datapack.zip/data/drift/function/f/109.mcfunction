tp 425483f9-2934-53dd-805b-82336df4bdbc 79.337 65 37.323 -168.34 0
tp 77d4edec-4f89-5806-8a73-69da291cf64a 79.337 65 37.323 -168.34 0
tp a18c987f-26df-590a-b51c-8f6379e10218 79.337 65 37.323 -168.34 0
tp 8bd36e4e-1a75-51ba-b224-63055ff644c2 79.337 65 37.323 -168.34 0
tp 7b07c259-0b81-5b46-b286-5b101f183bf9 79.337 65 37.323 -168.34 0
tp 04fc5281-333c-5c0d-ba69-0b625cbc7206 79.337 65 37.323 -168.34 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0.0037f,0.0001f,0.0223f,0.9997f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.8476f,-0.0504f,0.1933f,0.4916f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.1427f,0.474f,0.8576f,0.1398f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.865f,0.0113f,0.0066f,0.5016f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.0066f,0.5016f,0.865f,0.0113f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4079f,0.8419f,0.1163f],left_rotation:[0.0306f,0.192f,-0.9609f,0.1973f]}}
particle minecraft:campfire_cosy_smoke 75.23 65.12 41.58 -0.078 0.022 0.027 1 0 force
particle minecraft:cloud 75.23 65.32 41.58 0.35 0.18 0.35 0.02 2 force
particle minecraft:cloud 76.83 65.32 42.06 0.35 0.18 0.35 0.02 2 force
tp 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 68.555 65 48.729 -154.8 0
tp f74f363c-8714-5fe5-bb64-beafe6b6ac28 68.555 65 48.729 -154.8 0
tp 97428e5f-5a51-575c-8305-607c4b0f68cb 68.555 65 48.729 -154.8 0
tp 186c432f-da2b-5bec-ba8a-9d97f056504e 68.555 65 48.729 -154.8 0
tp b7fef3cd-3066-54f8-9318-2747261e9dd9 68.555 65 48.729 -154.8 0
tp 0d17ad00-82d8-5739-af58-9e93f268e98c 68.555 65 48.729 -154.8 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0.001f,0f,0.0223f,0.9998f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.9748f,-0.0637f,-0.2086f,0.0472f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.2147f,-0.0694f,0.9735f,0.0384f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.865f,0.0113f,0.0066f,0.5016f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.0066f,0.5016f,0.865f,0.0113f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4079f,0.8422f,0.2517f],left_rotation:[0.0626f,0.1812f,-0.9125f,0.3614f]}}
particle minecraft:campfire_cosy_smoke 63.19 65.12 52.07 -0.078 0.022 0.012 1 0 force
particle minecraft:cloud 63.19 65.32 52.07 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud 64.68 65.32 52.91 0.35 0.18 0.35 0.02 3 force
