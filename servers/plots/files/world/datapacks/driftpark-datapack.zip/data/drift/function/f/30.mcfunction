tp 425483f9-2934-53dd-805b-82336df4bdbc -11.713 65 64.052 -91.04 0
tp 77d4edec-4f89-5806-8a73-69da291cf64a -11.713 65 64.052 -91.04 0
tp a18c987f-26df-590a-b51c-8f6379e10218 -11.713 65 64.052 -91.04 0
tp 8bd36e4e-1a75-51ba-b224-63055ff644c2 -11.713 65 64.052 -91.04 0
tp 7b07c259-0b81-5b46-b286-5b101f183bf9 -11.713 65 64.052 -91.04 0
tp 04fc5281-333c-5c0d-ba69-0b625cbc7206 -11.713 65 64.052 -91.04 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0f,0f,0.0003f,1f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.9962f,0.0528f,-0.0044f,0.0692f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.0117f,0.07f,0.9961f,0.0516f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.9973f,0.0131f,0.0009f,0.0725f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.0009f,0.0725f,0.9973f,0.0131f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.3705f,0.8598f,0.11f],left_rotation:[0.1903f,0.014f,-0.0712f,0.979f]}}
tp 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 -29.936 65 64.832 -93.37 0
tp f74f363c-8714-5fe5-bb64-beafe6b6ac28 -29.936 65 64.832 -93.37 0
tp 97428e5f-5a51-575c-8305-607c4b0f68cb -29.936 65 64.832 -93.37 0
tp 186c432f-da2b-5bec-ba8a-9d97f056504e -29.936 65 64.832 -93.37 0
tp b7fef3cd-3066-54f8-9318-2747261e9dd9 -29.936 65 64.832 -93.37 0
tp 0d17ad00-82d8-5739-af58-9e93f268e98c -29.936 65 64.832 -93.37 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0059f,-0.0001f,0.0125f,0.9999f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.9934f,-0.057f,-0.051f,0.0852f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.0602f,-0.091f,0.9929f,0.0471f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.9973f,0.0131f,0.0009f,0.0725f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.0009f,0.0725f,0.9973f,0.0131f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.3915f,0.8534f,0.2398f],left_rotation:[0.1632f,-0.0872f,0.4848f,0.8548f]}}
