tp 425483f9-2934-53dd-805b-82336df4bdbc 35.332 65 -50.231 60.58 0
tp 77d4edec-4f89-5806-8a73-69da291cf64a 35.332 65 -50.231 60.58 0
tp a18c987f-26df-590a-b51c-8f6379e10218 35.332 65 -50.231 60.58 0
tp 8bd36e4e-1a75-51ba-b224-63055ff644c2 35.332 65 -50.231 60.58 0
tp 7b07c259-0b81-5b46-b286-5b101f183bf9 35.332 65 -50.231 60.58 0
tp 04fc5281-333c-5c0d-ba69-0b625cbc7206 35.332 65 -50.231 60.58 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0.0048f,0.0001f,0.0223f,0.9997f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.2541f,-0.223f,-0.0047f,0.9411f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.1036f,0.9468f,-0.232f,0.1976f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.2695f,-0.0035f,0.0126f,0.9629f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.0126f,-0.9629f,0.2695f,0.0035f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4078f,0.8416f,0.1182f],left_rotation:[0.0725f,0.1816f,-0.8937f,0.4038f]}}
particle minecraft:campfire_cosy_smoke 40.65 65.12 -49.65 0.067 0.022 0.031 1 0 force
particle minecraft:cloud 40.65 65.32 -49.65 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 40.65 65.42 -49.65 0.45 0.2 0.45 0.008 1 force
particle minecraft:cloud 39.97 65.32 -51.18 0.35 0.18 0.35 0.02 3 force
tp 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 49.187 65 -48.673 77.32 0
tp f74f363c-8714-5fe5-bb64-beafe6b6ac28 49.187 65 -48.673 77.32 0
tp 97428e5f-5a51-575c-8305-607c4b0f68cb 49.187 65 -48.673 77.32 0
tp 186c432f-da2b-5bec-ba8a-9d97f056504e 49.187 65 -48.673 77.32 0
tp b7fef3cd-3066-54f8-9318-2747261e9dd9 49.187 65 -48.673 77.32 0
tp 0d17ad00-82d8-5739-af58-9e93f268e98c 49.187 65 -48.673 77.32 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0.0108f,0.0002f,0.0222f,0.9997f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.7641f,-0.0943f,0.2058f,0.604f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.1435f,0.5857f,0.7783f,0.1751f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.2695f,-0.0035f,0.0126f,0.9629f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.0126f,-0.9629f,0.2695f,0.0035f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4076f,0.8371f,0.2685f],left_rotation:[0.0805f,0.1846f,-0.8796f,0.431f]}}
particle minecraft:campfire_cosy_smoke 54.98 65.12 -46.16 0.058 0.022 0.068 1 0 force
particle minecraft:cloud 54.98 65.32 -46.16 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud 54.78 65.32 -47.86 0.35 0.18 0.35 0.02 3 force
playsound driftpark:lap.onyx.04.095 neutral @a 57.86 65.5 -44.75 12 1
playsound driftpark:lap.onyx.04.096 neutral @a 49.24 65.5 -48.51 12 1
playsound driftpark:lap.onyx.04.097 neutral @a 41.16 65.5 -50.53 12 1
playsound driftpark:lap.onyx.04.098 neutral @a 33.51 65.5 -50.98 12 1
playsound driftpark:lap.onyx.04.099 neutral @a 26.15 65.5 -50.04 12 1
playsound driftpark:lap.onyx.04.100 neutral @a 19.37 65.5 -47.82 12 1
playsound driftpark:lap.onyx.04.101 neutral @a 13.73 65.5 -44.6 12 1
playsound driftpark:lap.onyx.04.102 neutral @a 9.37 65.5 -40.54 12 1
playsound driftpark:lap.onyx.04.103 neutral @a 5.85 65.5 -35.2 12 1
playsound driftpark:lap.onyx.04.104 neutral @a 3.14 65.5 -28.73 12 1
