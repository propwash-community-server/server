tp 425483f9-2934-53dd-805b-82336df4bdbc 29.903 65 -49.918 51.76 0
tp 77d4edec-4f89-5806-8a73-69da291cf64a 29.903 65 -49.918 51.76 0
tp a18c987f-26df-590a-b51c-8f6379e10218 29.903 65 -49.918 51.76 0
tp 8bd36e4e-1a75-51ba-b224-63055ff644c2 29.903 65 -49.918 51.76 0
tp 7b07c259-0b81-5b46-b286-5b101f183bf9 29.903 65 -49.918 51.76 0
tp 04fc5281-333c-5c0d-ba69-0b625cbc7206 29.903 65 -49.918 51.76 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0.0012f,0f,0.0223f,0.9998f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.9368f,-0.0086f,0.2257f,0.2672f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.1988f,0.2449f,0.9429f,0.1071f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.9589f,0.0126f,0.0037f,0.2835f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.0037f,0.2835f,0.9589f,0.0126f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4079f,0.8424f,0.1121f],left_rotation:[0.0758f,0.1764f,-0.8836f,0.4271f]}}
particle minecraft:campfire_cosy_smoke 35.09 65.12 -50.08 0.066 0.022 0.031 1 0 force
particle minecraft:cloud 35.09 65.32 -50.08 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 35.09 65.42 -50.08 0.45 0.2 0.45 0.008 1 force
particle minecraft:cloud 34.19 65.32 -51.49 0.35 0.18 0.35 0.02 3 force
tp 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 43.105 65 -50.394 68.39 0
tp f74f363c-8714-5fe5-bb64-beafe6b6ac28 43.105 65 -50.394 68.39 0
tp 97428e5f-5a51-575c-8305-607c4b0f68cb 43.105 65 -50.394 68.39 0
tp 186c432f-da2b-5bec-ba8a-9d97f056504e 43.105 65 -50.394 68.39 0
tp b7fef3cd-3066-54f8-9318-2747261e9dd9 43.105 65 -50.394 68.39 0
tp 0d17ad00-82d8-5739-af58-9e93f268e98c 43.105 65 -50.394 68.39 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0.0084f,0.0002f,0.0223f,0.9997f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.5891f,-0.2184f,-0.099f,0.7717f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.1807f,0.7863f,-0.5693f,0.1577f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.9589f,0.0126f,0.0037f,0.2835f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.0037f,0.2835f,0.9589f,0.0126f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4077f,0.8384f,0.2645f],left_rotation:[0.1022f,0.1708f,-0.8178f,0.54f]}}
particle minecraft:campfire_cosy_smoke 48.77 65.12 -48.75 0.07 0.022 0.054 1 0 force
particle minecraft:cloud 48.77 65.32 -48.75 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 48.77 65.42 -48.75 0.45 0.2 0.45 0.008 1 force
particle minecraft:cloud 48.31 65.32 -50.4 0.35 0.18 0.35 0.02 3 force
