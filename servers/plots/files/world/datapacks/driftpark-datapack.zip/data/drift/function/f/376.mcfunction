tp 425483f9-2934-53dd-805b-82336df4bdbc -62.405 65 -43.402 78.32 0
tp 77d4edec-4f89-5806-8a73-69da291cf64a -62.405 65 -43.402 78.32 0
tp a18c987f-26df-590a-b51c-8f6379e10218 -62.405 65 -43.402 78.32 0
tp 8bd36e4e-1a75-51ba-b224-63055ff644c2 -62.405 65 -43.402 78.32 0
tp 7b07c259-0b81-5b46-b286-5b101f183bf9 -62.405 65 -43.402 78.32 0
tp 04fc5281-333c-5c0d-ba69-0b625cbc7206 -62.405 65 -43.402 78.32 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0.0069f,0.0002f,0.0223f,0.9997f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.5124f,-0.2581f,-0.0984f,0.8131f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.1844f,0.8279f,-0.4881f,0.2056f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.9263f,0.0121f,0.0049f,0.3766f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.0049f,0.3766f,0.9263f,0.0121f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4078f,0.8411f,0.1219f],left_rotation:[0.153f,0.1251f,-0.586f,0.7858f]}}
particle minecraft:cloud -58.38 65.32 -41 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -58.53 65.12 -42.66 0.031 0.022 -0.023 1 0 force
particle minecraft:cloud -58.53 65.32 -42.66 0.35 0.18 0.35 0.02 3 force
tp 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 -52.432 65 -36.613 100.93 0
tp f74f363c-8714-5fe5-bb64-beafe6b6ac28 -52.432 65 -36.613 100.93 0
tp 97428e5f-5a51-575c-8305-607c4b0f68cb -52.432 65 -36.613 100.93 0
tp 186c432f-da2b-5bec-ba8a-9d97f056504e -52.432 65 -36.613 100.93 0
tp b7fef3cd-3066-54f8-9318-2747261e9dd9 -52.432 65 -36.613 100.93 0
tp 0d17ad00-82d8-5739-af58-9e93f268e98c -52.432 65 -36.613 100.93 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0.0024f,0f,0.0139f,0.9999f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.0749f,-0.2257f,0.0714f,0.9687f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.03f,0.9665f,0.0991f,0.2348f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.9263f,0.0121f,0.0049f,0.3766f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.0049f,0.3766f,0.9263f,0.0121f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.3938f,0.8482f,0.254f],left_rotation:[0.0956f,0.1678f,-0.8386f,0.5093f]}}
particle minecraft:cloud -48.98 65.32 -31.9 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -48.35 65.12 -33.49 0.039 0.022 0.014 1 0 force
particle minecraft:cloud -48.35 65.32 -33.49 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -48.35 65.42 -33.49 0.45 0.2 0.45 0.008 1 force
