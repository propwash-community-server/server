tp 425483f9-2934-53dd-805b-82336df4bdbc -85.68 65 -43.114 12.6 0
tp 77d4edec-4f89-5806-8a73-69da291cf64a -85.68 65 -43.114 12.6 0
tp a18c987f-26df-590a-b51c-8f6379e10218 -85.68 65 -43.114 12.6 0
tp 8bd36e4e-1a75-51ba-b224-63055ff644c2 -85.68 65 -43.114 12.6 0
tp 7b07c259-0b81-5b46-b286-5b101f183bf9 -85.68 65 -43.114 12.6 0
tp 04fc5281-333c-5c0d-ba69-0b625cbc7206 -85.68 65 -43.114 12.6 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0.0007f,0f,0.0223f,0.9998f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.0483f,-0.2624f,0.0675f,0.9614f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.0331f,0.9596f,0.0761f,0.269f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.2075f,-0.0027f,0.0128f,0.9781f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.0128f,-0.9781f,0.2075f,0.0027f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4079f,0.8425f,0.1112f],left_rotation:[0.1421f,0.1284f,-0.625f,0.7568f]}}
particle minecraft:campfire_cosy_smoke -82.38 65.12 -45.11 0.057 0.022 0.006 1 0 force
particle minecraft:cloud -82.38 65.32 -45.11 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud -83.93 65.32 -45.72 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -83.93 65.42 -45.72 0.45 0.2 0.45 0.008 1 force
tp 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 -77.771 65 -46.997 36.77 0
tp f74f363c-8714-5fe5-bb64-beafe6b6ac28 -77.771 65 -46.997 36.77 0
tp 97428e5f-5a51-575c-8305-607c4b0f68cb -77.771 65 -46.997 36.77 0
tp 186c432f-da2b-5bec-ba8a-9d97f056504e -77.771 65 -46.997 36.77 0
tp b7fef3cd-3066-54f8-9318-2747261e9dd9 -77.771 65 -46.997 36.77 0
tp 0d17ad00-82d8-5739-af58-9e93f268e98c -77.771 65 -46.997 36.77 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0.0054f,0.0001f,0.0223f,0.9997f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.9326f,-0.0022f,0.3179f,0.1707f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.3017f,0.1383f,0.938f,0.1002f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.2075f,-0.0027f,0.0128f,0.9781f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.0128f,-0.9781f,0.2075f,0.0027f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4078f,0.8399f,0.2593f],left_rotation:[0.1882f,0.0552f,-0.2338f,0.9523f]}}
particle minecraft:campfire_cosy_smoke -73.17 65.12 -47.48 0.064 0.022 0.021 1 0 force
particle minecraft:cloud -73.17 65.32 -47.48 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -73.17 65.42 -47.48 0.45 0.2 0.45 0.008 1 force
particle minecraft:cloud -74.39 65.32 -48.67 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -74.39 65.42 -48.67 0.45 0.2 0.45 0.008 1 force
