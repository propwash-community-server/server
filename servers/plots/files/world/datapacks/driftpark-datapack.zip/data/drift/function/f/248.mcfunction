tp 425483f9-2934-53dd-805b-82336df4bdbc 13.546 65 -43.495 14.34 0
tp 77d4edec-4f89-5806-8a73-69da291cf64a 13.546 65 -43.495 14.34 0
tp a18c987f-26df-590a-b51c-8f6379e10218 13.546 65 -43.495 14.34 0
tp 8bd36e4e-1a75-51ba-b224-63055ff644c2 13.546 65 -43.495 14.34 0
tp 7b07c259-0b81-5b46-b286-5b101f183bf9 13.546 65 -43.495 14.34 0
tp 04fc5281-333c-5c0d-ba69-0b625cbc7206 13.546 65 -43.495 14.34 0
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.0392f,-0.2613f,0.065f,0.9623f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.0358f,0.9607f,0.0669f,0.2669f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.4324f,0.0057f,0.0118f,0.9016f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.0118f,0.9016f,0.4324f,0.0057f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4078f,0.8412f,0.1211f],left_rotation:[0.1441f,0.1346f,-0.6365f,0.7456f]}}
particle minecraft:cloud 17.4 65.32 -46.06 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 15.84 65.12 -46.66 -0.005 0.022 -0.039 1 0 force
particle minecraft:cloud 15.84 65.32 -46.66 0.35 0.18 0.35 0.02 3 force
tp 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 23.44 65 -49.467 36.42 0
tp f74f363c-8714-5fe5-bb64-beafe6b6ac28 23.44 65 -49.467 36.42 0
tp 97428e5f-5a51-575c-8305-607c4b0f68cb 23.44 65 -49.467 36.42 0
tp 186c432f-da2b-5bec-ba8a-9d97f056504e 23.44 65 -49.467 36.42 0
tp b7fef3cd-3066-54f8-9318-2747261e9dd9 23.44 65 -49.467 36.42 0
tp 0d17ad00-82d8-5739-af58-9e93f268e98c 23.44 65 -49.467 36.42 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0.0025f,0.0001f,0.0223f,0.9997f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.9463f,-0.1031f,-0.2436f,0.1858f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.2645f,0.2125f,-0.9407f,0.0042f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.4324f,0.0057f,0.0118f,0.9016f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.0118f,0.9016f,0.4324f,0.0057f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4078f,0.8414f,0.2544f],left_rotation:[0.1351f,0.1382f,-0.6703f,0.7164f]}}
particle minecraft:cloud 28.65 65.32 -50.68 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 27.4 65.12 -51.85 0.019 0.022 -0.042 1 0 force
particle minecraft:cloud 27.4 65.32 -51.85 0.35 0.18 0.35 0.02 3 force
