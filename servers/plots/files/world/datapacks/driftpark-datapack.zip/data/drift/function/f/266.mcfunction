tp 425483f9-2934-53dd-805b-82336df4bdbc 5.121 65 -32.757 30.11 0
tp 77d4edec-4f89-5806-8a73-69da291cf64a 5.121 65 -32.757 30.11 0
tp a18c987f-26df-590a-b51c-8f6379e10218 5.121 65 -32.757 30.11 0
tp 8bd36e4e-1a75-51ba-b224-63055ff644c2 5.121 65 -32.757 30.11 0
tp 7b07c259-0b81-5b46-b286-5b101f183bf9 5.121 65 -32.757 30.11 0
tp 04fc5281-333c-5c0d-ba69-0b625cbc7206 5.121 65 -32.757 30.11 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0059f,-0.0001f,0.0105f,0.9999f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.9203f,-0.0702f,-0.0323f,0.3835f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.0728f,-0.389f,0.918f,0.0261f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.9196f,-0.012f,0.0051f,0.3927f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.0051f,-0.3927f,0.9196f,0.012f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.3879f,0.8533f,0.0999f],left_rotation:[0.1621f,-0.0893f,0.492f,0.8507f]}}
particle minecraft:campfire_cosy_smoke 6.52 65.12 -37.06 -0.023 0.012 -0.047 1 0 force
tp 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 10.767 65 -42.252 6.32 0
tp f74f363c-8714-5fe5-bb64-beafe6b6ac28 10.767 65 -42.252 6.32 0
tp 97428e5f-5a51-575c-8305-607c4b0f68cb 10.767 65 -42.252 6.32 0
tp 186c432f-da2b-5bec-ba8a-9d97f056504e 10.767 65 -42.252 6.32 0
tp b7fef3cd-3066-54f8-9318-2747261e9dd9 10.767 65 -42.252 6.32 0
tp 0d17ad00-82d8-5739-af58-9e93f268e98c 10.767 65 -42.252 6.32 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0.0047f,0.0001f,0.0223f,0.9997f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.816f,-0.1912f,-0.2052f,0.5054f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.2595f,0.5298f,-0.8004f,0.1065f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.9196f,-0.012f,0.0051f,0.3927f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.0051f,-0.3927f,0.9196f,0.012f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4078f,0.8403f,0.2581f],left_rotation:[0.1562f,0.1174f,-0.5537f,0.8095f]}}
particle minecraft:cloud 14.24 65.32 -45.36 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 12.56 65.12 -45.69 -0.013 0.022 -0.025 1 0 force
particle minecraft:cloud 12.56 65.32 -45.69 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 12.56 65.42 -45.69 0.45 0.2 0.45 0.008 1 force
