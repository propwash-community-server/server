tp 425483f9-2934-53dd-805b-82336df4bdbc 7.255 65 -36.329 16.32 0
tp 77d4edec-4f89-5806-8a73-69da291cf64a 7.255 65 -36.329 16.32 0
tp a18c987f-26df-590a-b51c-8f6379e10218 7.255 65 -36.329 16.32 0
tp 8bd36e4e-1a75-51ba-b224-63055ff644c2 7.255 65 -36.329 16.32 0
tp 7b07c259-0b81-5b46-b286-5b101f183bf9 7.255 65 -36.329 16.32 0
tp 04fc5281-333c-5c0d-ba69-0b625cbc7206 7.255 65 -36.329 16.32 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0058f,-0.0001f,0.0173f,0.9998f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.8277f,-0.1313f,-0.1054f,0.5353f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.1623f,0.5493f,-0.8185f,0.0451f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.9881f,-0.0129f,0.002f,0.1533f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.002f,-0.1533f,0.9881f,0.0129f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.3996f,0.8479f,0.1f],left_rotation:[0.0253f,-0.1833f,0.9776f,0.1006f]}}
particle minecraft:campfire_cosy_smoke 10.19 65.12 -39.9 0.067 0.02 -0.019 1 0 force
particle minecraft:cloud 10.19 65.32 -39.9 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke 10.19 65.42 -39.9 0.45 0.2 0.45 0.008 1 force
particle minecraft:cloud 8.55 65.32 -40.23 0.35 0.18 0.35 0.02 2 force
tp 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 13.604 65 -44.673 11.38 0
tp f74f363c-8714-5fe5-bb64-beafe6b6ac28 13.604 65 -44.673 11.38 0
tp 97428e5f-5a51-575c-8305-607c4b0f68cb 13.604 65 -44.673 11.38 0
tp 186c432f-da2b-5bec-ba8a-9d97f056504e 13.604 65 -44.673 11.38 0
tp b7fef3cd-3066-54f8-9318-2747261e9dd9 13.604 65 -44.673 11.38 0
tp 0d17ad00-82d8-5739-af58-9e93f268e98c 13.604 65 -44.673 11.38 0
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.4261f,-0.2888f,-0.083f,0.8533f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.1731f,0.8667f,-0.3981f,0.2456f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.9881f,-0.0129f,0.002f,0.1533f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.002f,-0.1533f,0.9881f,0.0129f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4077f,0.8394f,0.2612f],left_rotation:[0.1773f,0.0863f,-0.3895f,0.8997f]}}
particle minecraft:campfire_cosy_smoke 17.64 65.12 -47.39 0.074 0.022 -0.008 1 0 force
particle minecraft:cloud 17.64 65.32 -47.39 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud 16.02 65.32 -47.93 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 16.02 65.42 -47.93 0.45 0.2 0.45 0.008 1 force
