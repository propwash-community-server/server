tp 425483f9-2934-53dd-805b-82336df4bdbc 74.122 65 -32.905 108.84 0
tp 77d4edec-4f89-5806-8a73-69da291cf64a 74.122 65 -32.905 108.84 0
tp a18c987f-26df-590a-b51c-8f6379e10218 74.122 65 -32.905 108.84 0
tp 8bd36e4e-1a75-51ba-b224-63055ff644c2 74.122 65 -32.905 108.84 0
tp 7b07c259-0b81-5b46-b286-5b101f183bf9 74.122 65 -32.905 108.84 0
tp 04fc5281-333c-5c0d-ba69-0b625cbc7206 74.122 65 -32.905 108.84 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0047f,-0.0001f,0.0223f,0.9997f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.802f,-0.1502f,-0.1206f,0.5654f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.1807f,0.5812f,-0.7906f,0.0668f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.8214f,-0.0108f,0.0075f,0.5702f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.0075f,-0.5702f,0.8214f,0.0108f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4079f,0.8437f,0.1019f],left_rotation:[0.0168f,0.1855f,-0.9736f,0.1319f]}}
particle minecraft:cloud 77.85 65.32 -28.48 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke 78.5 65.12 -30.02 0.055 0.021 -0.003 1 0 force
particle minecraft:cloud 78.5 65.32 -30.02 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke 78.5 65.42 -30.02 0.45 0.2 0.45 0.008 1 force
tp 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 83.875 65 -21.863 119.86 0
tp f74f363c-8714-5fe5-bb64-beafe6b6ac28 83.875 65 -21.863 119.86 0
tp 97428e5f-5a51-575c-8305-607c4b0f68cb 83.875 65 -21.863 119.86 0
tp 186c432f-da2b-5bec-ba8a-9d97f056504e 83.875 65 -21.863 119.86 0
tp b7fef3cd-3066-54f8-9318-2747261e9dd9 83.875 65 -21.863 119.86 0
tp 0d17ad00-82d8-5739-af58-9e93f268e98c 83.875 65 -21.863 119.86 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0.0018f,0f,0.0223f,0.9998f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.0014f,-0.2206f,0.054f,0.9739f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.0481f,0.9736f,0.0246f,0.2219f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.8214f,-0.0108f,0.0075f,0.5702f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.0075f,-0.5702f,0.8214f,0.0108f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4079f,0.8418f,0.2531f],left_rotation:[0.0781f,0.176f,-0.8783f,0.4376f]}}
particle minecraft:cloud 86.4 65.32 -16.46 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 86.4 65.42 -16.46 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke 87.38 65.12 -17.87 0.052 0.022 0.008 1 0 force
particle minecraft:cloud 87.38 65.32 -17.87 0.35 0.18 0.35 0.02 3 force
