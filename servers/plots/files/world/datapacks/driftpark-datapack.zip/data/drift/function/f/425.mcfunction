tp 425483f9-2934-53dd-805b-82336df4bdbc -91.756 65 -36.21 -3.63 0
tp 77d4edec-4f89-5806-8a73-69da291cf64a -91.756 65 -36.21 -3.63 0
tp a18c987f-26df-590a-b51c-8f6379e10218 -91.756 65 -36.21 -3.63 0
tp 8bd36e4e-1a75-51ba-b224-63055ff644c2 -91.756 65 -36.21 -3.63 0
tp 7b07c259-0b81-5b46-b286-5b101f183bf9 -91.756 65 -36.21 -3.63 0
tp 04fc5281-333c-5c0d-ba69-0b625cbc7206 -91.756 65 -36.21 -3.63 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0058f,-0.0001f,0.0207f,0.9998f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.8116f,-0.0876f,0.2335f,0.5283f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.1793f,0.5066f,0.8253f,0.1734f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.6936f,-0.0091f,0.0094f,0.7203f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.0094f,-0.7203f,0.6936f,0.0091f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4054f,0.8451f,0.1f],left_rotation:[0.1093f,0.1494f,-0.7684f,0.6126f]}}
particle minecraft:campfire_cosy_smoke -89.31 65.12 -39.8 0.061 0.022 -0.031 1 0 force
particle minecraft:cloud -89.31 65.32 -39.8 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -89.31 65.42 -39.8 0.45 0.2 0.45 0.008 1 force
particle minecraft:cloud -90.98 65.32 -39.79 0.35 0.18 0.35 0.02 3 force
tp 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 -86.202 65 -43.857 8.07 0
tp f74f363c-8714-5fe5-bb64-beafe6b6ac28 -86.202 65 -43.857 8.07 0
tp 97428e5f-5a51-575c-8305-607c4b0f68cb -86.202 65 -43.857 8.07 0
tp 186c432f-da2b-5bec-ba8a-9d97f056504e -86.202 65 -43.857 8.07 0
tp b7fef3cd-3066-54f8-9318-2747261e9dd9 -86.202 65 -43.857 8.07 0
tp 0d17ad00-82d8-5739-af58-9e93f268e98c -86.202 65 -43.857 8.07 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0.0007f,0f,0.0223f,0.9998f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.4666f,-0.2841f,-0.0965f,0.832f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.1845f,0.8468f,-0.4393f,0.2366f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.6936f,-0.0091f,0.0094f,0.7203f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.0094f,-0.7203f,0.6936f,0.0091f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4079f,0.8423f,0.2512f],left_rotation:[0.1719f,0.0845f,-0.3932f,0.8993f]}}
particle minecraft:campfire_cosy_smoke -82.81 65.12 -46.11 0.056 0.022 -0.004 1 0 force
particle minecraft:cloud -82.81 65.32 -46.11 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud -84.44 65.32 -46.6 0.35 0.18 0.35 0.02 3 force
