tp 425483f9-2934-53dd-805b-82336df4bdbc 87.46 65 -11.705 135.58 0
tp 77d4edec-4f89-5806-8a73-69da291cf64a 87.46 65 -11.705 135.58 0
tp a18c987f-26df-590a-b51c-8f6379e10218 87.46 65 -11.705 135.58 0
tp 8bd36e4e-1a75-51ba-b224-63055ff644c2 87.46 65 -11.705 135.58 0
tp 7b07c259-0b81-5b46-b286-5b101f183bf9 87.46 65 -11.705 135.58 0
tp 04fc5281-333c-5c0d-ba69-0b625cbc7206 87.46 65 -11.705 135.58 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0.0002f,0f,0.0223f,0.9998f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.7686f,-0.1597f,-0.1158f,0.6085f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.1804f,0.6241f,-0.7561f,0.0798f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.7869f,-0.0103f,0.0081f,0.6169f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.0081f,-0.6169f,0.7869f,0.0103f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4079f,0.8427f,0.1103f],left_rotation:[0.0255f,0.1893f,-0.966f,0.1741f]}}
particle minecraft:cloud 88.73 65.32 -6 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke 88.73 65.42 -6 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke 90.01 65.12 -7.06 0.042 0.021 0.026 1 0 force
particle minecraft:cloud 90.01 65.32 -7.06 0.35 0.18 0.35 0.02 2 force
tp 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 91.025 65 3.01 148.37 0
tp f74f363c-8714-5fe5-bb64-beafe6b6ac28 91.025 65 3.01 148.37 0
tp 97428e5f-5a51-575c-8305-607c4b0f68cb 91.025 65 3.01 148.37 0
tp 186c432f-da2b-5bec-ba8a-9d97f056504e 91.025 65 3.01 148.37 0
tp b7fef3cd-3066-54f8-9318-2747261e9dd9 91.025 65 3.01 148.37 0
tp 0d17ad00-82d8-5739-af58-9e93f268e98c 91.025 65 3.01 148.37 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0.0002f,0f,0.0223f,0.9998f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.0674f,-0.2195f,0.0385f,0.9725f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.0635f,0.9738f,-0.0447f,0.2136f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.7869f,-0.0103f,0.0081f,0.6169f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.0081f,-0.6169f,0.7869f,0.0103f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4079f,0.8426f,0.2504f],left_rotation:[0.0704f,0.1776f,-0.8956f,0.4018f]}}
particle minecraft:cloud 90.8 65.32 8.99 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 92.32 65.12 8.2 0.038 0.022 0.03 1 0 force
particle minecraft:cloud 92.32 65.32 8.2 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 92.32 65.42 8.2 0.45 0.2 0.45 0.008 1 force
