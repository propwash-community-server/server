tp 425483f9-2934-53dd-805b-82336df4bdbc -68.257 65 55.114 -85.67 0
tp 77d4edec-4f89-5806-8a73-69da291cf64a -68.257 65 55.114 -85.67 0
tp a18c987f-26df-590a-b51c-8f6379e10218 -68.257 65 55.114 -85.67 0
tp 8bd36e4e-1a75-51ba-b224-63055ff644c2 -68.257 65 55.114 -85.67 0
tp 7b07c259-0b81-5b46-b286-5b101f183bf9 -68.257 65 55.114 -85.67 0
tp 04fc5281-333c-5c0d-ba69-0b625cbc7206 -68.257 65 55.114 -85.67 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0054f,-0.0001f,0.0221f,0.9997f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.7144f,-0.1081f,0.1952f,0.6632f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.1266f,0.6463f,0.7297f,0.1838f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.742f,0.0097f,0.0088f,0.6702f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.0088f,0.6702f,0.742f,0.0097f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4078f,0.8439f,0.1006f],left_rotation:[0.0689f,0.1722f,-0.8953f,0.4051f]}}
particle minecraft:cloud -72.06 65.32 51.94 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -72.06 65.42 51.94 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke -72.31 65.12 53.59 -0.044 0.022 0.01 1 0 force
particle minecraft:cloud -72.31 65.32 53.59 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -72.31 65.42 53.59 0.45 0.2 0.45 0.008 1 force
tp 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 -77.727 65 47.238 -72.56 0
tp f74f363c-8714-5fe5-bb64-beafe6b6ac28 -77.727 65 47.238 -72.56 0
tp 97428e5f-5a51-575c-8305-607c4b0f68cb -77.727 65 47.238 -72.56 0
tp 186c432f-da2b-5bec-ba8a-9d97f056504e -77.727 65 47.238 -72.56 0
tp b7fef3cd-3066-54f8-9318-2747261e9dd9 -77.727 65 47.238 -72.56 0
tp 0d17ad00-82d8-5739-af58-9e93f268e98c -77.727 65 47.238 -72.56 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0.0111f,0.0002f,0.0201f,0.9997f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.7493f,-0.1167f,0.2289f,0.6104f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.166f,0.5897f,0.7657f,0.1961f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.742f,0.0097f,0.0088f,0.6702f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.0088f,0.6702f,0.742f,0.0097f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4041f,0.8386f,0.2691f],left_rotation:[0.1305f,0.1538f,-0.7206f,0.6634f]}}
particle minecraft:cloud -80.71 65.32 42.16 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -81.44 65.12 43.7 -0.044 0.022 -0.008 1 0 force
particle minecraft:cloud -81.44 65.32 43.7 0.35 0.18 0.35 0.02 3 force
