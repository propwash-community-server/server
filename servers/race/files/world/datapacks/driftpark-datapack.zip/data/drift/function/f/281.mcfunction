scoreboard players set #gx drift 11
scoreboard players set #gdx drift -550
scoreboard players set #gz drift -24016
scoreboard players set #gdz drift 808
scoreboard players set #gr drift 6405
scoreboard players set #gdr drift 269
function drift:glide/move/kaze
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0.003f,-0.0001f,-0.0193f,0.9998f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.4449f,0.1854f,0.1563f,0.8621f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.0665f,-0.8505f,0.4668f,0.2332f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.406f,-0.0053f,0.012f,0.9138f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.012f,-0.9138f,0.406f,0.0053f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.3365f,0.873f,0.1152f],left_rotation:[0.1041f,-0.1634f,0.8063f,0.5588f]}}
particle minecraft:campfire_cosy_smoke 1.55 65.12 -23.84 0.045 0.022 -0.011 1 0 force
particle minecraft:cloud 1.55 65.32 -23.84 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud 0.82 65.32 -25.34 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx drift 5855
scoreboard players set #gdx drift -328
scoreboard players set #gz drift -35196
scoreboard players set #gdz drift 781
scoreboard players set #gr drift 2104
scoreboard players set #gdr drift 329
function drift:glide/move/onyx
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0059f,-0.0001f,0.0088f,0.9999f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.5004f,-0.0068f,0.0645f,0.8634f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.0259f,0.8614f,0.5038f,0.0594f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.406f,-0.0053f,0.012f,0.9138f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.012f,-0.9138f,0.406f,0.0053f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.3852f,0.8562f,0.2399f],left_rotation:[0.1746f,-0.0611f,0.3411f,0.9216f]}}
