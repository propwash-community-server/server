scoreboard players set #gx drift -81994
scoreboard players set #gdx drift -563
scoreboard players set #gz drift -44905
scoreboard players set #gdz drift 222
scoreboard players set #gr drift 2748
scoreboard players set #gdr drift -201
function drift:glide/move/kaze
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0.0052f,0.0001f,0.0223f,0.9997f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.4325f,-0.218f,0.1708f,0.858f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.0816f,0.8448f,0.4578f,0.2647f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.8344f,-0.0109f,0.0072f,0.551f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.0072f,-0.551f,0.8344f,0.0109f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4078f,0.8415f,0.1189f],left_rotation:[0.1526f,0.1229f,-0.5806f,0.7903f]}}
particle minecraft:cloud -80.65 65.32 -45.68 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -82.13 65.12 -46.45 0.002 0.022 -0.026 1 0 force
particle minecraft:cloud -82.13 65.32 -46.45 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx drift -72472
scoreboard players set #gdx drift -774
scoreboard players set #gz drift -46984
scoreboard players set #gdz drift -50
scoreboard players set #gr drift 5065
scoreboard players set #gdr drift -210
function drift:glide/move/onyx
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0.0041f,0.0001f,0.0223f,0.9997f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.8756f,-0.0687f,0.3062f,0.3672f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.2693f,0.337f,0.8877f,0.1611f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.8344f,-0.0109f,0.0072f,0.551f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.0072f,-0.551f,0.8344f,0.0109f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4078f,0.8406f,0.257f],left_rotation:[0.1847f,0.0621f,-0.2708f,0.9427f]}}
particle minecraft:cloud -70.84 65.32 -47.22 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -71.92 65.12 -48.54 0.02 0.022 -0.021 1 0 force
particle minecraft:cloud -71.92 65.32 -48.54 0.35 0.18 0.35 0.02 3 force
