scoreboard players set #gx drift -94179
scoreboard players set #gdx drift 295
scoreboard players set #gz drift 5286
scoreboard players set #gdz drift 1165
scoreboard players set #gr drift -2297
scoreboard players set #gdr drift 2
function drift:glide/move/kaze
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0059f,-0.0001f,0.01f,0.9999f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.7255f,-0.0812f,-0.0097f,0.6834f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.0816f,0.6882f,-0.7209f,0.0054f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.7724f,-0.0101f,0.0083f,0.635f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.0083f,-0.635f,0.7724f,0.0101f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.3872f,0.8537f,0.0999f],left_rotation:[0.157f,-0.0979f,0.5367f,0.8232f]}}
scoreboard players set #gx drift -97502
scoreboard players set #gdx drift 103
scoreboard players set #gz drift -10148
scoreboard players set #gdz drift 1061
scoreboard players set #gr drift -2919
scoreboard players set #gdr drift -9
function drift:glide/move/onyx
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0059f,-0.0001f,0.0179f,0.9998f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.8661f,-0.1324f,-0.1348f,0.4628f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.1842f,0.4795f,-0.857f,0.0421f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.7724f,-0.0101f,0.0083f,0.635f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.0083f,-0.635f,0.7724f,0.0101f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4007f,0.8491f,0.2399f],left_rotation:[0.0109f,0.1847f,-0.9783f,0.0929f]}}
particle minecraft:campfire_cosy_smoke -97.45 65.12 -11.8 0.023 0.021 -0.078 1 0 force
particle minecraft:cloud -97.45 65.32 -11.8 0.35 0.18 0.35 0.02 2 force
particle minecraft:cloud -98.94 65.32 -10.97 0.35 0.18 0.35 0.02 2 force
