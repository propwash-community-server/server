execute store result storage drift:anim t int 1 run scoreboard players get #t drift
function drift:anim/play with storage drift:anim
scoreboard players add #t drift 1
execute if score #t drift >= #n drift run scoreboard players set #t drift 0
execute if score #t drift matches 0 run function drift:glide/sync
