scoreboard players set #gx drift -94733
scoreboard players set #gdx drift 270
scoreboard players set #gz drift 2980
scoreboard players set #gdz drift 1149
scoreboard players set #gr drift -2316
scoreboard players set #gdr drift 12
function drift:glide/move/kaze
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0059f,-0.0001f,0.0109f,0.9999f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.2824f,-0.0816f,0.0306f,0.9553f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.0697f,0.9574f,-0.2753f,0.0524f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.3468f,-0.0045f,0.0123f,0.9378f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.0123f,-0.9378f,0.3468f,0.0045f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.3887f,0.8529f,0.0999f],left_rotation:[0.1507f,-0.1073f,0.5874f,0.7878f]}}
particle minecraft:campfire_cosy_smoke -94.48 65.12 1.45 0.019 0.012 -0.076 1 0 force
scoreboard players set #gx drift -97654
scoreboard players set #gdx drift 65
scoreboard players set #gz drift -12246
scoreboard players set #gdz drift 1044
scoreboard players set #gr drift -2846
scoreboard players set #gdr drift -39
function drift:glide/move/onyx
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0059f,-0.0001f,0.0184f,0.9998f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.523f,-0.1907f,-0.0573f,0.8288f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.1447f,0.8393f,-0.5058f,0.1368f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.3468f,-0.0045f,0.0123f,0.9378f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.0123f,-0.9378f,0.3468f,0.0045f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4016f,0.8486f,0.2399f],left_rotation:[0.0286f,0.1828f,-0.9646f,0.1877f]}}
particle minecraft:campfire_cosy_smoke -97.58 65.12 -13.9 0.032 0.021 -0.073 1 0 force
particle minecraft:cloud -97.58 65.32 -13.9 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -97.58 65.42 -13.9 0.45 0.2 0.45 0.008 1 force
particle minecraft:cloud -99.08 65.32 -13.08 0.35 0.18 0.35 0.02 2 force
