scoreboard players set #gx drift -91489
scoreboard players set #gdx drift 393
scoreboard players set #gz drift 14819
scoreboard players set #gdz drift 1224
scoreboard players set #gr drift -2491
scoreboard players set #gdr drift -48
function drift:glide/move/kaze
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0039f,0f,0.0111f,0.9999f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.2116f,-0.0405f,0.0624f,0.9745f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.0396f,0.9733f,0.2171f,0.063f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.1447f,0.0019f,0.013f,0.9894f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.013f,0.9894f,0.1447f,0.0019f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.389f,0.8524f,0.1032f],left_rotation:[0.1669f,-0.0842f,0.4616f,0.8672f]}}
scoreboard players set #gx drift -96155
scoreboard players set #gdx drift 244
scoreboard players set #gz drift -1452
scoreboard players set #gdz drift 1118
scoreboard players set #gr drift -2647
scoreboard players set #gdr drift 54
function drift:glide/move/onyx
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0058f,-0.0001f,0.0139f,0.9999f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.0053f,-0.1086f,0.0521f,0.9927f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.052f,0.9927f,0.0061f,0.1086f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.1447f,0.0019f,0.013f,0.9894f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.013f,0.9894f,0.1447f,0.0019f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.3938f,0.8523f,0.2399f],left_rotation:[0.1051f,-0.1523f,0.8241f,0.5354f]}}
particle minecraft:campfire_cosy_smoke -96.02 65.12 -3.1 0.019 0.015 -0.082 1 0 force
