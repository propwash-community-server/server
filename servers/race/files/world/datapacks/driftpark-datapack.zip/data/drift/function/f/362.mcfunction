scoreboard players set #gx drift -50354
scoreboard players set #gdx drift -671
scoreboard players set #gz drift -32904
scoreboard players set #gdz drift -790
scoreboard players set #gr drift 11523
scoreboard players set #gdr drift -259
function drift:glide/move/kaze
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0.0024f,0f,0.0139f,0.9999f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.2007f,-0.1875f,0.094f,0.9569f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.0061f,0.9523f,0.2215f,0.2097f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.9853f,-0.0129f,0.0022f,0.1705f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.0022f,-0.1705f,0.9853f,0.0129f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.3938f,0.8488f,0.114f],left_rotation:[0.0499f,0.1866f,-0.9404f,0.2798f]}}
particle minecraft:cloud -49.52 65.32 -31.59 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -48.81 65.12 -33.1 0.047 0.022 0.012 1 0 force
particle minecraft:cloud -48.81 65.32 -33.1 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -48.81 65.42 -33.1 0.45 0.2 0.45 0.008 1 force
scoreboard players set #gx drift -42453
scoreboard players set #gdx drift -515
scoreboard players set #gz drift -22013
scoreboard players set #gdz drift -740
scoreboard players set #gr drift 15267
scoreboard players set #gdr drift -228
function drift:glide/move/onyx
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0058f,0.0001f,-0.0104f,0.9999f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.5423f,0.0866f,0.0063f,0.8357f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.0815f,-0.8396f,-0.5362f,0.0301f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.9853f,-0.0129f,0.0022f,0.1705f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.0022f,-0.1705f,0.9853f,0.0129f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.352f,0.8704f,0.24f],left_rotation:[0.1511f,0.1069f,-0.5843f,0.7902f]}}
particle minecraft:campfire_cosy_smoke -41.04 65.12 -21.15 0.063 0.013 0.014 1 0 force
