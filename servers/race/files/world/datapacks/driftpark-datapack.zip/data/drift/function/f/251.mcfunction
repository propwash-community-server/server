scoreboard players set #gx drift 14263
scoreboard players set #gdx drift -588
scoreboard players set #gz drift -43872
scoreboard players set #gdz drift 444
scoreboard players set #gr drift 1650
scoreboard players set #gdr drift -111
function drift:glide/move/kaze
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0.006f,0.0001f,0.0223f,0.9997f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.3538f,-0.215f,0.1428f,0.899f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.049f,0.889f,0.3784f,0.2534f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.9408f,0.0123f,0.0044f,0.3387f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.0044f,0.3387f,0.9408f,0.0123f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4078f,0.8413f,0.1203f],left_rotation:[0.1286f,0.1488f,-0.7126f,0.6735f]}}
particle minecraft:campfire_cosy_smoke 15.44 65.12 -44.89 0.066 0.022 -0.011 1 0 force
particle minecraft:cloud 15.44 65.32 -44.89 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 15.44 65.42 -44.89 0.45 0.2 0.45 0.008 1 force
particle minecraft:cloud 13.83 65.32 -45.37 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 13.83 65.42 -45.37 0.45 0.2 0.45 0.008 1 force
scoreboard players set #gx drift 24373
scoreboard players set #gdx drift -872
scoreboard players set #gz drift -49598
scoreboard players set #gdz drift 251
scoreboard players set #gr drift 3790
scoreboard players set #gdr drift -185
function drift:glide/move/onyx
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0.0042f,0.0001f,0.0223f,0.9997f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.5298f,-0.2529f,-0.1018f,0.8031f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.1867f,0.8182f,-0.5061f,0.1986f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.9408f,0.0123f,0.0044f,0.3387f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.0044f,0.3387f,0.9408f,0.0123f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4078f,0.8405f,0.2573f],left_rotation:[0.1467f,0.1284f,-0.6127f,0.7659f]}}
particle minecraft:campfire_cosy_smoke 25.92 65.12 -50.19 0.078 0.022 0.005 1 0 force
particle minecraft:cloud 25.92 65.32 -50.19 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud 24.57 65.32 -51.24 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 24.57 65.42 -51.24 0.45 0.2 0.45 0.008 1 force
particle minecraft:flame 25.77 65.24 -51.69 0.05 0.04 0.05 0.02 6 force
particle minecraft:large_smoke 25.77 65.24 -51.69 0.05 0.04 0.05 0.01 2 force
particle minecraft:flame 26.06 65.24 -51.47 0.05 0.04 0.05 0.02 6 force
particle minecraft:large_smoke 26.06 65.24 -51.47 0.05 0.04 0.05 0.01 2 force
