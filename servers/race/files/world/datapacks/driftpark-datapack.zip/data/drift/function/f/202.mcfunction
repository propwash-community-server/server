scoreboard players set #gx drift 58708
scoreboard players set #gdx drift -1117
scoreboard players set #gz drift -43639
scoreboard players set #gdz drift -565
scoreboard players set #gr drift 9328
scoreboard players set #gdr drift -118
function drift:glide/move/kaze
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0.0055f,0.0001f,0.0221f,0.9997f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.0433f,-0.1802f,0.0613f,0.9808f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.0415f,0.9797f,0.0625f,0.1858f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.0348f,0.0005f,0.0131f,0.9993f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.0131f,0.9993f,0.0348f,0.0005f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4075f,0.8416f,0.1194f],left_rotation:[0.0134f,0.1957f,-0.9744f,0.1101f]}}
particle minecraft:cloud 59.97 65.32 -42.73 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke 60.06 65.12 -44.4 0.054 0.021 -0.018 1 0 force
particle minecraft:cloud 60.06 65.32 -44.4 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke 60.06 65.42 -44.4 0.45 0.2 0.45 0.008 1 force
particle minecraft:flame 61.11 65.22 -44 0.05 0.04 0.05 0.02 5 force
particle minecraft:large_smoke 61.11 65.22 -44 0.05 0.04 0.05 0.01 2 force
scoreboard players set #gx drift 72893
scoreboard players set #gdx drift -860
scoreboard players set #gz drift -34929
scoreboard players set #gdz drift -733
scoreboard players set #gr drift 10378
scoreboard players set #gdr drift -88
function drift:glide/move/onyx
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0056f,-0.0001f,0.0223f,0.9997f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.8747f,-0.0435f,0.2073f,0.4359f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.1626f,0.4165f,0.8841f,0.1357f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.0348f,0.0005f,0.0131f,0.9993f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.0131f,0.9993f,0.0348f,0.0005f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.408f,0.8454f,0.2403f],left_rotation:[0.0499f,0.1785f,-0.9337f,0.3064f]}}
particle minecraft:cloud 74.06 65.32 -33.76 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 74.06 65.42 -33.76 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke 74.47 65.12 -35.42 0.045 0.022 -0.011 1 0 force
particle minecraft:cloud 74.47 65.32 -35.42 0.35 0.18 0.35 0.02 3 force
