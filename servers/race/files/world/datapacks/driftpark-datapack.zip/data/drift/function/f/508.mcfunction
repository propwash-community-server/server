scoreboard players set #gx drift -78031
scoreboard players set #gdx drift 569
scoreboard players set #gz drift 44874
scoreboard players set #gdz drift 826
scoreboard players set #gr drift -6460
scoreboard players set #gdr drift -176
function drift:glide/move/kaze
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0.0112f,0.0002f,0.0212f,0.9997f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.777f,-0.0954f,0.2166f,0.5833f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.1565f,0.5638f,0.7913f,0.1776f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.7612f,0.01f,0.0085f,0.6484f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.0085f,0.6484f,0.7612f,0.01f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.406f,0.8409f,0.1293f],left_rotation:[0.0986f,0.1761f,-0.8336f,0.5141f]}}
particle minecraft:cloud -78.86 65.32 43.56 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -79.57 65.12 45.07 -0.042 0.022 -0.006 1 0 force
particle minecraft:cloud -79.57 65.32 45.07 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx drift -85802
scoreboard players set #gdx drift 523
scoreboard players set #gz drift 30719
scoreboard players set #gdz drift 1174
scoreboard players set #gr drift -4021
scoreboard players set #gdr drift -204
function drift:glide/move/onyx
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0.0086f,0.0001f,0.0107f,0.9999f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.748f,-0.0517f,0.1407f,0.6465f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.0735f,0.6353f,0.7576f,0.1306f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.7612f,0.01f,0.0085f,0.6484f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.0085f,0.6484f,0.7612f,0.01f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.3883f,0.8474f,0.2648f],left_rotation:[0.0608f,-0.1898f,0.9395f,0.2787f]}}
particle minecraft:cloud -86.06 65.32 29.09 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -87.37 65.12 30.19 -0.063 0.017 -0.031 1 0 force
particle minecraft:cloud -87.37 65.32 30.19 0.35 0.18 0.35 0.02 2 force
particle minecraft:flame -87.56 65.24 28.92 0.05 0.04 0.05 0.02 6 force
particle minecraft:large_smoke -87.56 65.24 28.92 0.05 0.04 0.05 0.01 2 force
particle minecraft:flame -87.28 65.24 28.69 0.05 0.04 0.05 0.02 6 force
particle minecraft:large_smoke -87.28 65.24 28.69 0.05 0.04 0.05 0.01 2 force
