scoreboard players set #gx drift 89559
scoreboard players set #gdx drift -163
scoreboard players set #gz drift -2265
scoreboard players set #gdz drift -1060
scoreboard players set #gr drift 14597
scoreboard players set #gdr drift -106
function drift:glide/move/kaze
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0007f,0f,0.0223f,0.9998f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.8955f,-0.1257f,-0.151f,0.3994f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.1938f,0.4175f,-0.8872f,0.0323f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.915f,-0.012f,0.0053f,0.4033f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.0053f,-0.4033f,0.915f,0.012f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4079f,0.8428f,0.1087f],left_rotation:[0.0239f,0.1886f,-0.9675f,0.1668f]}}
particle minecraft:campfire_cosy_smoke 89.6 65.12 -0.71 -0.02 0.021 0.075 1 0 force
particle minecraft:cloud 89.6 65.32 -0.71 0.35 0.18 0.35 0.02 2 force
particle minecraft:cloud 90.98 65.32 -1.65 0.35 0.18 0.35 0.02 2 force
scoreboard players set #gx drift 90449
scoreboard players set #gdx drift 134
scoreboard players set #gz drift 12732
scoreboard players set #gdz drift -1074
scoreboard players set #gr drift 15829
scoreboard players set #gdr drift -116
function drift:glide/move/onyx
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0005f,0f,0.0223f,0.9998f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.3303f,-0.2221f,-0.023f,0.9171f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.1195f,0.9245f,-0.3088f,0.1887f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.915f,-0.012f,0.0053f,0.4033f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.0053f,-0.4033f,0.915f,0.012f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4079f,0.843f,0.2491f],left_rotation:[0.071f,0.1766f,-0.8937f,0.4063f]}}
particle minecraft:campfire_cosy_smoke 90.18 65.12 14.36 -0.045 0.022 0.073 1 0 force
particle minecraft:cloud 90.18 65.32 14.36 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud 91.77 65.32 13.73 0.35 0.18 0.35 0.02 3 force
