scoreboard players set #gx drift -78595
scoreboard players set #gdx drift 564
scoreboard players set #gz drift 44020
scoreboard players set #gdz drift 854
scoreboard players set #gr drift -6279
scoreboard players set #gdr drift -181
function drift:glide/move/kaze
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0.0112f,0.0002f,0.0207f,0.9997f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.3604f,-0.2308f,-0.0342f,0.9032f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.1293f,0.9117f,-0.3381f,0.1942f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.4271f,-0.0056f,0.0118f,0.9041f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.0118f,-0.9041f,0.4271f,0.0056f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4052f,0.8413f,0.1293f],left_rotation:[0.0929f,0.1792f,-0.8501f,0.4865f]}}
particle minecraft:campfire_cosy_smoke -79.38 65.12 42.68 -0.002 0.022 -0.079 1 0 force
particle minecraft:cloud -79.38 65.32 42.68 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -79.38 65.42 42.68 0.45 0.2 0.45 0.008 1 force
particle minecraft:cloud -80.14 65.32 44.16 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx drift -86321
scoreboard players set #gdx drift 519
scoreboard players set #gz drift 29526
scoreboard players set #gdz drift 1193
scoreboard players set #gr drift -3819
scoreboard players set #gdr drift -201
function drift:glide/move/onyx
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0.0063f,0.0001f,0.0109f,0.9999f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.4337f,-0.1374f,-0.0082f,0.8905f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.1019f,0.8963f,-0.4216f,0.0926f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.4271f,-0.0056f,0.0118f,0.9041f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.0118f,-0.9041f,0.4271f,0.0056f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.3887f,0.8485f,0.2609f],left_rotation:[0.0821f,-0.1791f,0.8999f,0.389f]}}
particle minecraft:campfire_cosy_smoke -86.52 65.12 27.89 0 0.016 -0.085 1 0 force
particle minecraft:cloud -86.52 65.32 27.89 0.35 0.18 0.35 0.02 1 force
particle minecraft:cloud -87.87 65.32 28.94 0.35 0.18 0.35 0.02 1 force
particle minecraft:flame -88.01 65.24 27.67 0.05 0.04 0.05 0.02 6 force
particle minecraft:large_smoke -88.01 65.24 27.67 0.05 0.04 0.05 0.01 2 force
particle minecraft:flame -87.73 65.24 27.44 0.05 0.04 0.05 0.02 6 force
particle minecraft:large_smoke -87.73 65.24 27.44 0.05 0.04 0.05 0.01 2 force
