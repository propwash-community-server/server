scoreboard players set #gx drift -89844
scoreboard players set #gdx drift 438
scoreboard players set #gz drift 19732
scoreboard players set #gdz drift 1224
scoreboard players set #gr drift -2698
scoreboard players set #gdr drift -61
function drift:glide/move/kaze
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0f,0f,0.0113f,0.9999f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.7443f,-0.0759f,-0.0064f,0.6635f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.0761f,-0.6678f,0.7405f,0.0019f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.7905f,-0.0103f,0.008f,0.6123f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.008f,-0.6123f,0.7905f,0.0103f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.3894f,0.8514f,0.11f],left_rotation:[0.1685f,-0.0895f,0.4799f,0.8563f]}}
scoreboard players set #gx drift -95088
scoreboard players set #gdx drift 302
scoreboard players set #gz drift 3061
scoreboard players set #gdz drift 1145
scoreboard players set #gr drift -2480
scoreboard players set #gdr drift 22
function drift:glide/move/onyx
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0059f,-0.0001f,0.0109f,0.9999f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.858f,-0.0866f,-0.0436f,0.5045f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.0969f,-0.5118f,0.8536f,0.0031f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.7905f,-0.0103f,0.008f,0.6123f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.008f,-0.6123f,0.7905f,0.0103f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.3888f,0.8546f,0.2399f],left_rotation:[0.1384f,-0.1228f,0.6683f,0.7205f]}}
particle minecraft:campfire_cosy_smoke -94.91 65.12 1.42 0.017 0.013 -0.066 1 0 force
