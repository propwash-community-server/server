scoreboard players set #gx drift -89725
scoreboard players set #gdx drift -414
scoreboard players set #gz drift -39035
scoreboard players set #gdz drift 549
scoreboard players set #gr drift 43
scoreboard players set #gdr drift -69
function drift:glide/move/kaze
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0059f,-0.0001f,0.021f,0.9998f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.0669f,-0.2508f,0.0368f,0.965f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.0645f,0.9665f,-0.0409f,0.2452f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.8764f,0.0115f,0.0063f,0.4814f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.0063f,0.4814f,0.8764f,0.0115f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4059f,0.8449f,0.0998f],left_rotation:[0.1149f,0.145f,-0.7437f,0.6424f]}}
particle minecraft:cloud -88.88 65.32 -40.34 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -90.55 65.12 -40.35 -0.025 0.022 -0.03 1 0 force
particle minecraft:cloud -90.55 65.32 -40.35 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx drift -83473
scoreboard players set #gdx drift -559
scoreboard players set #gz drift -45265
scoreboard players set #gdz drift 268
scoreboard players set #gr drift 1887
scoreboard players set #gdr drift -212
function drift:glide/move/onyx
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0.0025f,0.0001f,0.0223f,0.9997f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.9388f,-0.1058f,-0.2824f,0.1668f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.3014f,0.1974f,-0.9328f,0.0078f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.8764f,0.0115f,0.0063f,0.4814f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.0063f,0.4814f,0.8764f,0.0115f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4078f,0.8415f,0.2542f],left_rotation:[0.1746f,0.0827f,-0.3803f,0.9045f]}}
particle minecraft:cloud -82.21 65.32 -46.33 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -83.82 65.12 -46.88 -0.003 0.022 -0.019 1 0 force
particle minecraft:cloud -83.82 65.32 -46.88 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -83.82 65.42 -46.88 0.45 0.2 0.45 0.008 1 force
