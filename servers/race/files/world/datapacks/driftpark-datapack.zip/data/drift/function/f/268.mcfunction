scoreboard players set #gx drift 5992
scoreboard players set #gdx drift -429
scoreboard players set #gz drift -34135
scoreboard players set #gdz drift 724
scoreboard players set #gr drift 2524
scoreboard players set #gdr drift 305
function drift:glide/move/kaze
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0059f,0f,0.0072f,1f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.9804f,0.0503f,0.0155f,0.1898f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.0043f,0.1892f,0.9805f,0.0525f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.9921f,0.013f,0.0016f,0.1245f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.0016f,0.1245f,0.9921f,0.013f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.3823f,0.8558f,0.0999f],left_rotation:[0.1848f,-0.0082f,0.0576f,0.981f]}}
scoreboard players set #gx drift 11970
scoreboard players set #gdx drift -544
scoreboard players set #gz drift -43187
scoreboard players set #gdz drift 491
scoreboard players set #gr drift 906
scoreboard players set #gdr drift -82
function drift:glide/move/onyx
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0f,0f,0.0221f,0.9998f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.883f,-0.0546f,0.2591f,0.3877f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.2198f,0.3626f,0.8936f,0.1477f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.9921f,0.013f,0.0016f,0.1245f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.0016f,0.1245f,0.9921f,0.013f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4077f,0.8428f,0.2501f],left_rotation:[0.1338f,0.1361f,-0.669f,0.7184f]}}
particle minecraft:cloud 13.04 65.32 -44.45 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 11.35 65.12 -44.72 -0.004 0.022 -0.029 1 0 force
particle minecraft:cloud 11.35 65.32 -44.72 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 11.35 65.42 -44.72 0.45 0.2 0.45 0.008 1 force
