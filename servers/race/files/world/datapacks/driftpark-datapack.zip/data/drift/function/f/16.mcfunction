scoreboard players set #gx drift -34884
scoreboard players set #gdx drift 1237
scoreboard players set #gz drift 64357
scoreboard players set #gdz drift 49
scoreboard players set #gr drift -9559
scoreboard players set #gdr drift 68
function drift:glide/move/kaze
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0059f,-0.0001f,0.0125f,0.9999f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.883f,-0.0684f,-0.0175f,0.4641f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.0664f,-0.4685f,0.8806f,0.024f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.8847f,-0.0116f,0.0061f,0.4661f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.0061f,-0.4661f,0.8847f,0.0116f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.3914f,0.8517f,0.0999f],left_rotation:[0.1693f,-0.0747f,0.4192f,0.8888f]}}
scoreboard players set #gx drift -51103
scoreboard players set #gdx drift 1077
scoreboard players set #gz drift 62898
scoreboard players set #gdz drift 230
scoreboard players set #gr drift -10183
scoreboard players set #gdr drift -35
function drift:glide/move/onyx
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0058f,-0.0001f,0.0179f,0.9998f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.8312f,-0.1425f,-0.1267f,0.5223f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.1823f,0.5385f,-0.8208f,0.0559f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.8847f,-0.0116f,0.0061f,0.4661f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.0061f,-0.4661f,0.8847f,0.0116f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4007f,0.849f,0.24f],left_rotation:[0.014f,0.1846f,-0.9766f,0.1096f]}}
particle minecraft:cloud -52.66 65.32 62.35 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -52.66 65.42 62.35 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke -52.31 65.12 64.02 -0.049 0.021 0.029 1 0 force
particle minecraft:cloud -52.31 65.32 64.02 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -52.31 65.42 64.02 0.45 0.2 0.45 0.008 1 force
