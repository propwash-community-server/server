scoreboard players set #gx drift -48428
scoreboard players set #gdx drift -629
scoreboard players set #gz drift -30541
scoreboard players set #gdz drift -785
scoreboard players set #gr drift 12308
scoreboard players set #gdr drift -267
function drift:glide/move/kaze
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0059f,0f,0.0083f,0.9999f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.5313f,-0.1638f,-0.0419f,0.8301f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.1294f,0.8391f,-0.517f,0.1089f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.8214f,0.0108f,0.0075f,0.5702f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.0075f,0.5702f,0.8214f,0.0108f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.3843f,0.855f,0.0999f],left_rotation:[0.0224f,-0.1837f,0.9773f,0.1028f]}}
particle minecraft:campfire_cosy_smoke -47.79 65.12 -29.13 0.003 0.019 0.079 1 0 force
particle minecraft:cloud -47.79 65.32 -29.13 0.35 0.18 0.35 0.02 2 force
particle minecraft:cloud -46.87 65.32 -30.53 0.35 0.18 0.35 0.02 2 force
scoreboard players set #gx drift -40876
scoreboard players set #gdx drift -532
scoreboard players set #gz drift -19877
scoreboard players set #gdz drift -698
scoreboard players set #gr drift 15857
scoreboard players set #gdr drift -177
function drift:glide/move/onyx
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0058f,0.0001f,-0.0142f,0.9999f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.2114f,0.1186f,0.08f,0.9669f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.0212f,-0.9638f,0.225f,0.1415f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.8214f,0.0108f,0.0075f,0.5702f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.0075f,0.5702f,0.8214f,0.0108f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.3454f,0.873f,0.2399f],left_rotation:[0.0686f,0.1719f,-0.9226f,0.3384f]}}
particle minecraft:campfire_cosy_smoke -41.16 65.12 -18.25 -0.008 0.018 0.055 1 0 force
particle minecraft:cloud -41.16 65.32 -18.25 0.35 0.18 0.35 0.02 2 force
particle minecraft:cloud -39.56 65.32 -18.87 0.35 0.18 0.35 0.02 2 force
