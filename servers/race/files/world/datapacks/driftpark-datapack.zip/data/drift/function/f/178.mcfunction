scoreboard players set #gx drift 79604
scoreboard players set #gdx drift -627
scoreboard players set #gz drift -26535
scoreboard players set #gdz drift -818
scoreboard players set #gr drift 11697
scoreboard players set #gdr drift -102
function drift:glide/move/kaze
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0028f,-0.0001f,0.0223f,0.9997f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.0975f,-0.1825f,0.0718f,0.9757f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.0304f,0.9735f,0.1173f,0.1937f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.0928f,0.0012f,0.013f,0.9956f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.013f,0.9956f,0.0928f,0.0012f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4079f,0.8433f,0.1052f],left_rotation:[0.0231f,0.1866f,-0.9684f,0.1636f]}}
particle minecraft:cloud 80.39 65.32 -25.2 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke 81.15 65.12 -26.68 0.047 0.021 0.012 1 0 force
particle minecraft:cloud 81.15 65.32 -26.68 0.35 0.18 0.35 0.02 2 force
scoreboard players set #gx drift 87402
scoreboard players set #gdx drift -390
scoreboard players set #gz drift -13982
scoreboard players set #gdz drift -1013
scoreboard players set #gr drift 12963
scoreboard players set #gdr drift -113
function drift:glide/move/onyx
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0.0012f,0f,0.0223f,0.9998f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.8387f,-0.0653f,0.2159f,0.4958f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.1649f,0.4758f,0.8501f,0.1538f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.0928f,0.0012f,0.013f,0.9956f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.013f,0.9956f,0.0928f,0.0012f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4079f,0.8421f,0.2521f],left_rotation:[0.0753f,0.1766f,-0.8848f,0.4245f]}}
particle minecraft:cloud 87.95 65.32 -12.42 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 89.04 65.12 -13.74 0.046 0.022 0.013 1 0 force
particle minecraft:cloud 89.04 65.32 -13.74 0.35 0.18 0.35 0.02 3 force
