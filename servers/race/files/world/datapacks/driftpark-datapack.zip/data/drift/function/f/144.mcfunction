scoreboard players set #gx drift 90071
scoreboard players set #gdx drift 28
scoreboard players set #gz drift 7308
scoreboard players set #gdz drift -1067
scoreboard players set #gr drift 15614
scoreboard players set #gdr drift -105
function drift:glide/move/kaze
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0.0002f,0f,0.0223f,0.9998f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.3315f,-0.1963f,-0.0139f,0.9227f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.111f,0.9292f,-0.3127f,0.1625f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.3414f,-0.0045f,0.0123f,0.9398f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.0123f,-0.9398f,0.3414f,0.0045f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4079f,0.8426f,0.1104f],left_rotation:[0.0247f,0.1894f,-0.9667f,0.17f]}}
particle minecraft:cloud 89.84 65.32 8.84 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke 91.36 65.12 8.17 0.044 0.021 0.031 1 0 force
particle minecraft:cloud 91.36 65.32 8.17 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke 91.36 65.42 8.17 0.45 0.2 0.45 0.008 1 force
scoreboard players set #gx drift 88323
scoreboard players set #gdx drift 316
scoreboard players set #gz drift 22136
scoreboard players set #gdz drift -1016
scoreboard players set #gr drift 16828
scoreboard players set #gdr drift -116
function drift:glide/move/onyx
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0017f,0f,0.0223f,0.9998f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.3911f,-0.1788f,0.1369f,0.8924f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.0439f,0.8829f,0.412f,0.2209f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.3414f,-0.0045f,0.0123f,0.9398f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.0123f,-0.9398f,0.3414f,0.0045f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4079f,0.8435f,0.2471f],left_rotation:[0.0736f,0.1743f,-0.8867f,0.422f]}}
particle minecraft:cloud 87.77 65.32 23.7 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 89.45 65.12 23.35 0.03 0.022 0.035 1 0 force
particle minecraft:cloud 89.45 65.32 23.35 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 89.45 65.42 23.35 0.45 0.2 0.45 0.008 1 force
