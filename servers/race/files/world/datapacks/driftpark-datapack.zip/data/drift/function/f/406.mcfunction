scoreboard players set #gx drift -80817
scoreboard players set #gdx drift -597
scoreboard players set #gz drift -45300
scoreboard players set #gdz drift 189
scoreboard players set #gr drift 3135
scoreboard players set #gdr drift -191
function drift:glide/move/kaze
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0.0059f,0.0001f,0.0223f,0.9997f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.9495f,-0.0939f,-0.2648f,0.1394f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.2809f,-0.168f,0.9449f,0.0054f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.4428f,-0.0058f,0.0117f,0.8965f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.0117f,-0.8965f,0.4428f,0.0058f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4078f,0.8413f,0.1201f],left_rotation:[0.1578f,0.1173f,-0.5495f,0.8121f]}}
particle minecraft:cloud -79.42 65.32 -45.98 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -80.85 65.12 -46.85 -0.002 0.022 -0.031 1 0 force
particle minecraft:cloud -80.85 65.32 -46.85 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx drift -70916
scoreboard players set #gdx drift -781
scoreboard players set #gz drift -46818
scoreboard players set #gdz drift -94
scoreboard players set #gr drift 5457
scoreboard players set #gdr drift -205
function drift:glide/move/onyx
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0.0028f,0.0001f,0.0223f,0.9997f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.8556f,-0.1824f,-0.2503f,0.4148f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.2953f,0.4433f,-0.8411f,0.0935f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.4428f,-0.0058f,0.0117f,0.8965f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.0117f,-0.8965f,0.4428f,0.0058f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4078f,0.8413f,0.2548f],left_rotation:[0.1809f,0.0689f,-0.3083f,0.9314f]}}
particle minecraft:cloud -69.27 65.32 -46.94 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -70.26 65.12 -48.34 0.007 0.022 -0.019 1 0 force
particle minecraft:cloud -70.26 65.32 -48.34 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -70.26 65.42 -48.34 0.45 0.2 0.45 0.008 1 force
