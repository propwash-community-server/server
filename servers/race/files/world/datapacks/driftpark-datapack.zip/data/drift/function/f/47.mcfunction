scoreboard players set #gx drift 5178
scoreboard players set #gdx drift 1299
scoreboard players set #gz drift 63658
scoreboard players set #gdz drift -33
scoreboard players set #gr drift -9227
scoreboard players set #gdr drift -50
function drift:glide/move/kaze
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0f,0f,0.003f,1f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.9871f,-0.053f,-0.0004f,0.1513f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.0163f,-0.1522f,0.9869f,0.0504f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.989f,-0.0129f,0.0019f,0.1475f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.0019f,-0.1475f,0.989f,0.0129f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.3752f,0.8577f,0.11f],left_rotation:[0.1903f,-0.0139f,0.0775f,0.9786f]}}
scoreboard players set #gx drift -13013
scoreboard players set #gdx drift 1298
scoreboard players set #gz drift 64058
scoreboard players set #gdz drift -68
scoreboard players set #gr drift -9090
scoreboard players set #gdr drift 4
function drift:glide/move/onyx
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0f,0f,-0.0024f,1f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.9195f,-0.0456f,0.0266f,0.3896f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.0142f,-0.389f,0.9197f,0.0508f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.989f,-0.0129f,0.0019f,0.1475f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.0019f,-0.1475f,0.989f,0.0129f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.3659f,0.8617f,0.25f],left_rotation:[0.1905f,0.0112f,-0.0621f,0.9797f]}}
