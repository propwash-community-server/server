scoreboard players set #gx drift 67015
scoreboard players set #gdx drift -968
scoreboard players set #gz drift -38607
scoreboard players set #gdz drift -672
scoreboard players set #gr drift 10178
scoreboard players set #gdr drift -87
function drift:glide/move/kaze
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.8188f,-0.1404f,-0.1152f,0.5445f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.1731f,0.5596f,-0.8086f,0.0551f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.8376f,-0.011f,0.0071f,0.5461f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.0071f,-0.5461f,0.8376f,0.011f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4079f,0.8439f,0.0999f],left_rotation:[-0.0028f,0.185f,-0.9823f,0.0286f]}}
particle minecraft:cloud 68.13 65.32 -37.52 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke 68.13 65.42 -37.52 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke 68.47 65.12 -39.16 0.066 0.02 0.002 1 0 force
particle minecraft:cloud 68.47 65.32 -39.16 0.35 0.18 0.35 0.02 2 force
scoreboard players set #gx drift 79012
scoreboard players set #gdx drift -692
scoreboard players set #gz drift -28720
scoreboard players set #gdz drift -808
scoreboard players set #gr drift 11140
scoreboard players set #gdr drift -107
function drift:glide/move/onyx
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0043f,-0.0001f,0.0223f,0.9997f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.0363f,-0.2116f,0.0615f,0.9747f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.0406f,0.9736f,0.0587f,0.2166f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.8376f,-0.011f,0.0071f,0.5461f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.0071f,-0.5461f,0.8376f,0.011f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.408f,0.8448f,0.2426f],left_rotation:[0.0647f,0.175f,-0.9055f,0.3812f]}}
particle minecraft:cloud 80.02 65.32 -27.41 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 80.64 65.12 -29 0.059 0.022 0.008 1 0 force
particle minecraft:cloud 80.64 65.32 -29 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 80.64 65.42 -29 0.45 0.2 0.45 0.008 1 force
