scoreboard players set #gx drift -32400
scoreboard players set #gdx drift 1259
scoreboard players set #gz drift 64443
scoreboard players set #gdz drift 26
scoreboard players set #gr drift -9425
scoreboard players set #gdr drift 58
function drift:glide/move/kaze
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0058f,-0.0001f,0.0111f,0.9999f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.9972f,0.051f,0.0322f,0.0433f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.0279f,0.0402f,0.9974f,0.0535f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.999f,0.0131f,0.0006f,0.0435f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.0006f,0.0435f,0.999f,0.0131f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.3891f,0.8528f,0.0999f],left_rotation:[0.1788f,-0.0476f,0.2737f,0.9438f]}}
scoreboard players set #gx drift -48936
scoreboard players set #gdx drift 1104
scoreboard players set #gz drift 63343
scoreboard players set #gdz drift 199
scoreboard players set #gr drift -10242
scoreboard players set #gdr drift -14
function drift:glide/move/onyx
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0059f,-0.0001f,0.0176f,0.9998f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.9825f,-0.0607f,-0.1705f,0.0431f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.176f,-0.0613f,0.9816f,0.0423f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.999f,0.0131f,0.0006f,0.0435f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.0006f,0.0435f,0.999f,0.0131f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4002f,0.8493f,0.2399f],left_rotation:[-0.0032f,0.185f,-0.9826f,0.0178f]}}
particle minecraft:cloud -50.5 65.32 62.81 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -50.13 65.12 64.48 -0.042 0.02 0.027 1 0 force
particle minecraft:cloud -50.13 65.32 64.48 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -50.13 65.42 64.48 0.45 0.2 0.45 0.008 1 force
