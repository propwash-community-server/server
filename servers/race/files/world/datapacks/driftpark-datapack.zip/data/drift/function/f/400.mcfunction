scoreboard players set #gx drift -76905
scoreboard players set #gdx drift -689
scoreboard players set #gz drift -46054
scoreboard players set #gdz drift 78
scoreboard players set #gr drift 4314
scoreboard players set #gdr drift -197
function drift:glide/move/kaze
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0.006f,0.0001f,0.0223f,0.9997f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.8999f,-0.148f,-0.2472f,0.3275f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.283f,0.3553f,-0.8892f,0.0543f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.9029f,0.0118f,0.0056f,0.4297f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.0056f,0.4297f,0.9029f,0.0118f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4078f,0.8413f,0.1204f],left_rotation:[0.1655f,0.1064f,-0.4929f,0.8476f]}}
particle minecraft:cloud -75.4 65.32 -46.44 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -76.62 65.12 -47.58 0.002 0.022 -0.027 1 0 force
particle minecraft:cloud -76.62 65.32 -47.58 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx drift -66289
scoreboard players set #gdx drift -757
scoreboard players set #gz drift -45796
scoreboard players set #gdz drift -223
scoreboard players set #gr drift 6535
scoreboard players set #gdr drift -171
function drift:glide/move/onyx
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0017f,0f,0.0223f,0.9998f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.9263f,-0.0176f,0.2979f,0.2302f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.2753f,0.2002f,0.9332f,0.1151f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.9029f,0.0118f,0.0056f,0.4297f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.0056f,0.4297f,0.9029f,0.0118f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4079f,0.8436f,0.247f],left_rotation:[0.1684f,0.0861f,-0.4076f,0.8934f]}}
particle minecraft:cloud -64.65 65.32 -45.61 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -65.36 65.12 -47.16 0.019 0.022 -0.028 1 0 force
particle minecraft:cloud -65.36 65.32 -47.16 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -65.36 65.42 -47.16 0.45 0.2 0.45 0.008 1 force
