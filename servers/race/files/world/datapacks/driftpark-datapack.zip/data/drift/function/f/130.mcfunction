scoreboard players set #gx drift 87489
scoreboard players set #gdx drift 316
scoreboard players set #gz drift 21861
scoreboard players set #gdz drift -996
scoreboard players set #gr drift 17186
scoreboard players set #gdr drift -116
function drift:glide/move/kaze
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0017f,0f,0.0223f,0.9998f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.2053f,-0.1763f,0.0923f,0.9582f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.0079f,0.9538f,0.225f,0.1989f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.2075f,0.0027f,0.0128f,0.9781f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.0128f,0.9781f,0.2075f,0.0027f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4079f,0.8431f,0.1071f],left_rotation:[0.0284f,0.187f,-0.9633f,0.1907f]}}
particle minecraft:cloud 86.85 65.32 23.28 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke 88.5 65.12 23.04 0.025 0.022 0.053 1 0 force
particle minecraft:cloud 88.5 65.32 23.04 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke 88.5 65.42 23.04 0.45 0.2 0.45 0.008 1 force
scoreboard players set #gx drift 81815
scoreboard players set #gdx drift 607
scoreboard players set #gz drift 35214
scoreboard players set #gdz drift -873
scoreboard players set #gr drift -17562
scoreboard players set #gdr drift -128
function drift:glide/move/onyx
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0.0037f,0.0001f,0.0223f,0.9997f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.7595f,-0.0975f,0.2075f,0.6088f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.1447f,0.5903f,0.7739f,0.1779f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.2075f,0.0027f,0.0128f,0.9781f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.0128f,0.9781f,0.2075f,0.0027f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4078f,0.8408f,0.2564f],left_rotation:[0.0827f,0.176f,-0.8685f,0.456f]}}
particle minecraft:cloud 80.85 65.32 36.56 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 82.56 65.12 36.69 0.013 0.022 0.05 1 0 force
particle minecraft:cloud 82.56 65.32 36.69 0.35 0.18 0.35 0.02 3 force
