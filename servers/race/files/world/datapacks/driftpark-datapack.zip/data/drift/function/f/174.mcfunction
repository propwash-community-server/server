scoreboard players set #gx drift 81939
scoreboard players set #gdx drift -561
scoreboard players set #gz drift -23140
scoreboard players set #gdz drift -872
scoreboard players set #gr drift 12144
scoreboard players set #gdr drift -119
function drift:glide/move/kaze
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0.002f,0f,0.0223f,0.9998f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.8968f,-0.0286f,0.1972f,0.395f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.1568f,0.3764f,0.9048f,0.123f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.9126f,0.0119f,0.0053f,0.4086f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.0053f,0.4086f,0.9126f,0.0119f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4079f,0.8422f,0.1135f],left_rotation:[0.0294f,0.1906f,-0.9621f,0.1928f]}}
particle minecraft:cloud 82.62 65.32 -21.74 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke 83.49 65.12 -23.17 0.052 0.022 0.014 1 0 force
particle minecraft:cloud 83.49 65.32 -23.17 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke 83.49 65.42 -23.17 0.45 0.2 0.45 0.008 1 force
playsound driftpark:lap.kaze.03.089 neutral @a 84.5 65.5 -18.57 12 1
playsound driftpark:lap.kaze.03.090 neutral @a 80.21 65.5 -25.71 12 1
playsound driftpark:lap.kaze.03.091 neutral @a 74.77 65.5 -32.09 12 1
playsound driftpark:lap.kaze.03.092 neutral @a 67.96 65.5 -37.92 12 1
playsound driftpark:lap.kaze.03.093 neutral @a 59.82 65.5 -43.06 12 1
playsound driftpark:lap.kaze.03.094 neutral @a 51.08 65.5 -47.02 12 1
playsound driftpark:lap.kaze.03.095 neutral @a 42.96 65.5 -49.31 12 1
playsound driftpark:lap.kaze.03.096 neutral @a 35.37 65.5 -50.1 12 1
playsound driftpark:lap.kaze.03.097 neutral @a 28.12 65.5 -49.52 12 1
playsound driftpark:lap.kaze.03.098 neutral @a 21.29 65.5 -47.64 12 1
scoreboard players set #gx drift 88769
scoreboard players set #gdx drift -312
scoreboard players set #gz drift -9844
scoreboard players set #gdz drift -1046
scoreboard players set #gr drift 13439
scoreboard players set #gdr drift -120
function drift:glide/move/onyx
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0.0005f,0f,0.0223f,0.9998f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.8546f,-0.1515f,-0.1648f,0.4686f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.215f,0.4885f,-0.8433f,0.0625f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.9126f,0.0119f,0.0053f,0.4086f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.0053f,0.4086f,0.9126f,0.0119f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4079f,0.8424f,0.2509f],left_rotation:[0.0723f,0.1771f,-0.8914f,0.4108f]}}
particle minecraft:cloud 89.18 65.32 -8.24 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 90.38 65.12 -9.47 0.047 0.022 0.026 1 0 force
particle minecraft:cloud 90.38 65.32 -9.47 0.35 0.18 0.35 0.02 3 force
