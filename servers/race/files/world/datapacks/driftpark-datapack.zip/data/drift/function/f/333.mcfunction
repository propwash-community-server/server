scoreboard players set #gx drift -32912
scoreboard players set #gdx drift -629
scoreboard players set #gz drift -14503
scoreboard players set #gdz drift -376
scoreboard players set #gr drift 15477
scoreboard players set #gdr drift 111
function drift:glide/move/kaze
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0048f,0.0001f,-0.0222f,0.9997f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.843f,0.1616f,-0.174f,0.4827f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.2256f,-0.5037f,-0.8306f,0.0739f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.9997f,0.0131f,0.0003f,0.0203f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.0003f,0.0203f,0.9997f,0.0131f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.3315f,0.8766f,0.1018f],left_rotation:[0.0919f,-0.1619f,0.832f,0.5226f]}}
particle minecraft:campfire_cosy_smoke -33.11 65.12 -12.96 -0.011 0.022 0.035 1 0 force
particle minecraft:cloud -33.11 65.32 -12.96 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud -31.6 65.32 -13.67 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx drift -23274
scoreboard players set #gdx drift -752
scoreboard players set #gz drift -10363
scoreboard players set #gdz drift -103
scoreboard players set #gr drift 13950
scoreboard players set #gdr drift 145
function drift:glide/move/onyx
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0027f,0.0001f,-0.0223f,0.9997f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.8038f,0.2041f,-0.2172f,0.5148f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.2725f,-0.5404f,-0.7868f,0.1208f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.9997f,0.0131f,0.0003f,0.0203f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.0003f,0.0203f,0.9997f,0.0131f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.3313f,0.877f,0.2453f],left_rotation:[0.1672f,-0.0861f,0.4104f,0.8923f]}}
particle minecraft:campfire_cosy_smoke -23.01 65.12 -8.73 0.002 0.022 0.029 1 0 force
particle minecraft:cloud -23.01 65.32 -8.73 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud -21.71 65.32 -9.84 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -21.71 65.42 -9.84 0.45 0.2 0.45 0.008 1 force
playsound driftpark:lap.onyx.06.109 neutral @a -20.3 65.5 -10.17 12 1
playsound driftpark:lap.onyx.06.110 neutral @a -26.29 65.5 -10.91 12 1
playsound driftpark:lap.onyx.06.111 neutral @a -32.04 65.5 -13.01 12 1
playsound driftpark:lap.onyx.06.112 neutral @a -37.21 65.5 -16.41 12 1
playsound driftpark:lap.onyx.06.113 neutral @a -41.94 65.5 -21.28 12 1
playsound driftpark:lap.onyx.06.114 neutral @a -46.05 65.5 -27.42 12 1
playsound driftpark:lap.onyx.06.115 neutral @a -50.59 65.5 -34.07 12 1
playsound driftpark:lap.onyx.06.116 neutral @a -55.84 65.5 -39.87 12 1
playsound driftpark:lap.onyx.06.117 neutral @a -61.31 65.5 -43.7 12 1
playsound driftpark:lap.onyx.06.118 neutral @a -67.05 65.5 -46.02 12 1
