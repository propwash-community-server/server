scoreboard players set #gx drift -7454
scoreboard players set #gdx drift -581
scoreboard players set #gz drift -15598
scoreboard players set #gdz drift 448
scoreboard players set #gr drift 9389
scoreboard players set #gdr drift 180
function drift:glide/move/kaze
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0.0092f,-0.0002f,-0.0223f,0.9997f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.2331f,0.302f,-0.0196f,0.9241f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.1169f,-0.9313f,-0.2027f,0.2792f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.7574f,0.0099f,0.0085f,0.6528f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.0085f,0.6528f,0.7574f,0.0099f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.3315f,0.8734f,0.1259f],left_rotation:[0.1815f,-0.0836f,0.37f,0.9073f]}}
particle minecraft:cloud -6.2 65.32 -14.68 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -6.09 65.12 -16.34 0.041 0.022 -0.064 1 0 force
particle minecraft:cloud -6.09 65.32 -16.34 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx drift 1174
scoreboard players set #gdx drift -459
scoreboard players set #gz drift -24418
scoreboard players set #gdz drift 871
scoreboard players set #gr drift 6516
scoreboard players set #gdr drift 271
function drift:glide/move/onyx
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0004f,0f,-0.0179f,0.9998f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.9377f,0.0082f,0.2598f,0.2307f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.237f,-0.2047f,0.9437f,0.1068f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.7574f,0.0099f,0.0085f,0.6528f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.0085f,0.6528f,0.7574f,0.0099f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.3391f,0.8728f,0.2494f],left_rotation:[0.1277f,-0.1413f,0.7044f,0.6838f]}}
particle minecraft:cloud 2.82 65.32 -24.24 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 2.82 65.42 -24.24 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke 2.1 65.12 -25.79 0.014 0.022 -0.087 1 0 force
particle minecraft:cloud 2.1 65.32 -25.79 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 2.1 65.42 -25.79 0.45 0.2 0.45 0.008 1 force
