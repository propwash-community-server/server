scoreboard players set #gx drift -34167
scoreboard players set #gdx drift -624
scoreboard players set #gz drift -15279
scoreboard players set #gdz drift -423
scoreboard players set #gr drift 15665
scoreboard players set #gdr drift 86
function drift:glide/move/kaze
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0058f,0.0001f,-0.0219f,0.9997f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.1864f,0.2277f,0.0103f,0.9557f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.0901f,-0.9599f,-0.1635f,0.2093f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.8531f,0.0112f,0.0068f,0.5216f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.0068f,0.5216f,0.8531f,0.0112f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.332f,0.8766f,0.1f],left_rotation:[0.0765f,-0.1686f,0.8764f,0.4447f]}}
particle minecraft:campfire_cosy_smoke -34.41 65.12 -13.75 -0.007 0.022 0.038 1 0 force
particle minecraft:cloud -34.41 65.32 -13.75 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -34.41 65.42 -13.75 0.45 0.2 0.45 0.008 1 force
particle minecraft:cloud -32.88 65.32 -14.41 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -32.88 65.42 -14.41 0.45 0.2 0.45 0.008 1 force
scoreboard players set #gx drift -24784
scoreboard players set #gdx drift -753
scoreboard players set #gz drift -10593
scoreboard players set #gdz drift -148
scoreboard players set #gr drift 14264
scoreboard players set #gdr drift 149
function drift:glide/move/onyx
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0016f,0f,-0.0223f,0.9998f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.1008f,0.2972f,0.0235f,0.9492f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.0761f,-0.952f,-0.0701f,0.2882f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.8531f,0.0112f,0.0068f,0.5216f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.0068f,0.5216f,0.8531f,0.0112f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.3313f,0.8764f,0.2473f],left_rotation:[0.1683f,-0.0866f,0.4103f,0.8921f]}}
particle minecraft:campfire_cosy_smoke -24.6 65.12 -8.95 0.005 0.022 0.039 1 0 force
particle minecraft:cloud -24.6 65.32 -8.95 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -24.6 65.42 -8.95 0.45 0.2 0.45 0.008 1 force
particle minecraft:cloud -23.25 65.32 -9.99 0.35 0.18 0.35 0.02 3 force
