scoreboard players set #gx drift 85828
scoreboard players set #gdx drift -425
scoreboard players set #gz drift -15673
scoreboard players set #gdz drift -977
scoreboard players set #gr drift 13082
scoreboard players set #gdr drift -125
function drift:glide/move/kaze
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0.0015f,0f,0.0223f,0.9998f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.1244f,-0.1846f,0.0774f,0.9718f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.0243f,0.969f,0.1445f,0.1987f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.1216f,0.0016f,0.013f,0.9925f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.013f,0.9925f,0.1216f,0.0016f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4079f,0.8423f,0.1126f],left_rotation:[0.031f,0.1898f,-0.9605f,0.2011f]}}
particle minecraft:cloud 86.27 65.32 -14.18 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke 87.37 65.12 -15.45 0.038 0.022 0.016 1 0 force
particle minecraft:cloud 87.37 65.32 -15.45 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke 87.37 65.42 -15.45 0.45 0.2 0.45 0.008 1 force
scoreboard players set #gx drift 90529
scoreboard players set #gdx drift -147
scoreboard players set #gz drift -1306
scoreboard players set #gdz drift -1078
scoreboard players set #gr drift 14358
scoreboard players set #gdr drift -117
function drift:glide/move/onyx
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0009f,0f,0.0223f,0.9998f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.8213f,-0.0711f,0.2107f,0.5254f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.1566f,0.5061f,0.8333f,0.1579f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.1216f,0.0016f,0.013f,0.9925f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.013f,0.9925f,0.1216f,0.0016f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4079f,0.8431f,0.2484f],left_rotation:[0.0692f,0.1769f,-0.8975f,0.3981f]}}
particle minecraft:cloud 90.68 65.32 0.34 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 90.68 65.42 0.34 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke 92.06 65.12 -0.67 0.047 0.022 0.024 1 0 force
particle minecraft:cloud 92.06 65.32 -0.67 0.35 0.18 0.35 0.02 3 force
