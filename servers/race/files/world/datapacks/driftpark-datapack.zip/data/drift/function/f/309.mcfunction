scoreboard players set #gx drift -16276
scoreboard players set #gdx drift -642
scoreboard players set #gz drift -11428
scoreboard players set #gdz drift 109
scoreboard players set #gr drift 12079
scoreboard players set #gdr drift 138
function drift:glide/move/kaze
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.3636f,0.2326f,0.154f,0.8888f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.0614f,-0.8775f,0.39f,0.2721f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.9992f,-0.0131f,0.0005f,0.0377f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.0005f,-0.0377f,0.9992f,0.0131f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.3313f,0.8767f,0.1008f],left_rotation:[0.1468f,-0.1136f,0.5662f,0.8031f]}}
particle minecraft:campfire_cosy_smoke -15.58 65.12 -10.04 0.005 0.022 0.026 1 0 force
particle minecraft:cloud -15.58 65.32 -10.04 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud -14.72 65.32 -11.47 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -14.72 65.42 -11.47 0.45 0.2 0.45 0.008 1 force
scoreboard players set #gx drift -7492
scoreboard players set #gdx drift -604
scoreboard players set #gz drift -14431
scoreboard players set #gdz drift 439
scoreboard players set #gr drift 10026
scoreboard players set #gdr drift 206
function drift:glide/move/onyx
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0.0086f,-0.0002f,-0.0223f,0.9997f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.9262f,0.0073f,0.3326f,0.1774f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.3158f,-0.1434f,0.9321f,0.1047f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.9992f,-0.0131f,0.0005f,0.0377f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.0005f,-0.0377f,0.9992f,0.0131f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.3316f,0.8712f,0.2647f],left_rotation:[0.1972f,-0.0282f,0.0955f,0.9753f]}}
particle minecraft:campfire_cosy_smoke -6.25 65.12 -13.34 0.015 0.022 0.012 1 0 force
particle minecraft:cloud -6.25 65.32 -13.34 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud -5.95 65.32 -15.02 0.35 0.18 0.35 0.02 3 force
