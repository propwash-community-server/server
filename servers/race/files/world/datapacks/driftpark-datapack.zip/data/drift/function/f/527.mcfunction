scoreboard players set #gx drift -65844
scoreboard players set #gdx drift 801
scoreboard players set #gz drift 56499
scoreboard players set #gdz drift 458
scoreboard players set #gr drift -8758
scoreboard players set #gdr drift -75
function drift:glide/move/kaze
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0059f,-0.0001f,0.021f,0.9998f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.508f,-0.1408f,0.1479f,0.8368f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.0608f,0.8259f,0.5256f,0.1949f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.529f,0.0069f,0.0111f,0.8485f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.0111f,0.8485f,0.529f,0.0069f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4059f,0.8449f,0.0999f],left_rotation:[0.037f,0.1813f,-0.9538f,0.2366f]}}
particle minecraft:campfire_cosy_smoke -67.12 65.12 55.61 -0.029 0.022 -0.062 1 0 force
particle minecraft:cloud -67.12 65.32 55.61 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -67.12 65.42 55.61 0.45 0.2 0.45 0.008 1 force
particle minecraft:cloud -67.19 65.32 57.28 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx drift -75826
scoreboard players set #gdx drift 605
scoreboard players set #gz drift 49301
scoreboard players set #gdz drift 699
scoreboard players set #gr drift -7660
scoreboard players set #gdr drift -138
function drift:glide/move/onyx
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0.0102f,0.0002f,0.0222f,0.9997f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.5795f,-0.1772f,0.2013f,0.7696f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.1216f,0.7527f,0.6013f,0.2391f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.529f,0.0069f,0.0111f,0.8485f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.0111f,0.8485f,0.529f,0.0069f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4076f,0.8374f,0.2676f],left_rotation:[0.1454f,0.1386f,-0.6436f,0.7385f]}}
particle minecraft:campfire_cosy_smoke -77 65.12 48.14 -0.023 0.022 -0.077 1 0 force
particle minecraft:cloud -77 65.32 48.14 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -77 65.42 48.14 0.45 0.2 0.45 0.008 1 force
particle minecraft:cloud -77.4 65.32 49.81 0.35 0.18 0.35 0.02 3 force
