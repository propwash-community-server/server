scoreboard players set #gx drift 13675
scoreboard players set #gdx drift -567
scoreboard players set #gz drift -43428
scoreboard players set #gdz drift 454
scoreboard players set #gr drift 1539
scoreboard players set #gdr drift -125
function drift:glide/move/kaze
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0.0047f,0.0001f,0.0223f,0.9997f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.9653f,0.0364f,0.2492f,0.0687f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.2433f,0.0429f,0.9668f,0.0649f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.5726f,-0.0075f,0.0107f,0.8197f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.0107f,-0.8197f,0.5726f,0.0075f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4078f,0.8416f,0.1181f],left_rotation:[0.1188f,0.1552f,-0.7515f,0.6301f]}}
particle minecraft:cloud 14.83 65.32 -44.47 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 14.83 65.42 -44.47 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke 13.22 65.12 -44.91 -0.004 0.022 -0.039 1 0 force
particle minecraft:cloud 13.22 65.32 -44.91 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 13.22 65.42 -44.91 0.45 0.2 0.45 0.008 1 force
scoreboard players set #gx drift 23501
scoreboard players set #gdx drift -859
scoreboard players set #gz drift -49347
scoreboard players set #gdz drift 270
scoreboard players set #gr drift 3605
scoreboard players set #gdr drift -192
function drift:glide/move/onyx
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0.0047f,0.0001f,0.0223f,0.9997f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.64f,-0.1656f,0.2206f,0.7171f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.1465f,0.6979f,0.6609f,0.2337f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.5726f,-0.0075f,0.0107f,0.8197f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.0107f,-0.8197f,0.5726f,0.0075f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4078f,0.8403f,0.258f],left_rotation:[0.1509f,0.1242f,-0.5888f,0.7843f]}}
particle minecraft:cloud 25.02 65.32 -49.99 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 25.02 65.42 -49.99 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke 23.64 65.12 -50.99 0.009 0.022 -0.043 1 0 force
particle minecraft:cloud 23.64 65.32 -50.99 0.35 0.18 0.35 0.02 3 force
particle minecraft:flame 24.83 65.24 -51.48 0.05 0.04 0.05 0.02 6 force
particle minecraft:large_smoke 24.83 65.24 -51.48 0.05 0.04 0.05 0.01 2 force
particle minecraft:flame 25.12 65.24 -51.27 0.05 0.04 0.05 0.02 6 force
particle minecraft:large_smoke 25.12 65.24 -51.27 0.05 0.04 0.05 0.01 2 force
