scoreboard players set #gx drift -93689
scoreboard players set #gdx drift -292
scoreboard players set #gz drift -31957
scoreboard players set #gdz drift 748
scoreboard players set #gr drift -736
scoreboard players set #gdr drift -69
function drift:glide/move/kaze
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0059f,-0.0001f,0.0178f,0.9998f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.0432f,-0.206f,0.0444f,0.9766f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.058f,0.9773f,-0.0218f,0.2026f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.2639f,-0.0035f,0.0126f,0.9645f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.0126f,-0.9645f,0.2639f,0.0035f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4004f,0.8475f,0.0999f],left_rotation:[0.0488f,0.1785f,-0.9381f,0.2929f]}}
particle minecraft:campfire_cosy_smoke -93.03 65.12 -33.36 0.064 0.022 -0.048 1 0 force
particle minecraft:cloud -93.03 65.32 -33.36 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud -94.69 65.32 -33.15 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -94.69 65.42 -33.15 0.45 0.2 0.45 0.008 1 force
scoreboard players set #gx drift -89082
scoreboard players set #gdx drift -459
scoreboard players set #gz drift -41171
scoreboard players set #gdz drift 504
scoreboard players set #gr drift -73
scoreboard players set #gdr drift -98
function drift:glide/move/onyx
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0059f,-0.0001f,0.0218f,0.9997f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.6084f,-0.2572f,-0.1414f,0.7373f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.2196f,0.7563f,-0.5848f,0.1947f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.2639f,-0.0035f,0.0126f,0.9645f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.0126f,-0.9645f,0.2639f,0.0035f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4072f,0.8459f,0.2399f],left_rotation:[0.1607f,0.0919f,-0.4502f,0.8736f]}}
particle minecraft:campfire_cosy_smoke -88.25 65.12 -42.6 0.064 0.022 -0.031 1 0 force
particle minecraft:cloud -88.25 65.32 -42.6 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -88.25 65.42 -42.6 0.45 0.2 0.45 0.008 1 force
particle minecraft:cloud -89.96 65.32 -42.57 0.35 0.18 0.35 0.02 3 force
