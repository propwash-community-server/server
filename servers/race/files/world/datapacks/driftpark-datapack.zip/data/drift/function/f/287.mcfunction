scoreboard players set #gx drift -3385
scoreboard players set #gdx drift -578
scoreboard players set #gz drift -19535
scoreboard players set #gdz drift 649
scoreboard players set #gr drift 7913
scoreboard players set #gdr drift 235
function drift:glide/move/kaze
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0.0112f,-0.0002f,-0.0218f,0.9997f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.8457f,0.1814f,-0.2256f,0.4484f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.274f,-0.4746f,-0.8313f,0.0935f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.9078f,0.0119f,0.0055f,0.4192f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.0055f,0.4192f,0.9078f,0.0119f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.3322f,0.8727f,0.1292f],left_rotation:[0.1712f,-0.1068f,0.4816f,0.8529f]}}
particle minecraft:campfire_cosy_smoke -1.94 65.12 -18.96 0.03 0.022 0 1 0 force
particle minecraft:cloud -1.94 65.32 -18.96 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud -2.26 65.32 -20.6 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx drift 3845
scoreboard players set #gdx drift -347
scoreboard players set #gz drift -30396
scoreboard players set #gdz drift 831
scoreboard players set #gr drift 4306
scoreboard players set #gdr drift 365
function drift:glide/move/onyx
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0059f,0f,-0.0022f,1f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.8792f,0.016f,0.1464f,0.4531f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.0996f,-0.4403f,0.8857f,0.1085f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.9078f,0.0119f,0.0055f,0.4192f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.0055f,0.4192f,0.9078f,0.0119f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.3661f,0.8645f,0.2399f],left_rotation:[0.0594f,0.1752f,-0.9321f,0.3114f]}}
particle minecraft:campfire_cosy_smoke 5.44 65.12 -30.85 0.055 0.017 -0.023 1 0 force
particle minecraft:cloud 5.44 65.32 -30.85 0.35 0.18 0.35 0.02 1 force
particle minecraft:cloud 4.19 65.32 -32.01 0.35 0.18 0.35 0.02 1 force
