scoreboard players set #gx drift -62412
scoreboard players set #gdx drift -669
scoreboard players set #gz drift -43257
scoreboard players set #gdz drift -329
scoreboard players set #gr drift 7883
scoreboard players set #gdr drift -162
function drift:glide/move/kaze
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0.0019f,0f,0.0223f,0.9998f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.8011f,-0.1014f,0.2498f,0.5344f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.195f,0.5111f,0.8162f,0.1862f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.1274f,0.0017f,0.013f,0.9918f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.013f,0.9918f,0.1274f,0.0017f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4079f,0.8423f,0.1133f],left_rotation:[0.1412f,0.1311f,-0.6349f,0.7482f]}}
particle minecraft:cloud -60.96 65.32 -42.69 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -61.29 65.12 -44.33 0.032 0.022 -0.02 1 0 force
particle minecraft:cloud -61.29 65.32 -44.33 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -61.29 65.42 -44.33 0.45 0.2 0.45 0.008 1 force
scoreboard players set #gx drift -52475
scoreboard players set #gdx drift -628
scoreboard players set #gz drift -36509
scoreboard players set #gdz drift -770
scoreboard players set #gr drift 10141
scoreboard players set #gdr drift -246
function drift:glide/move/onyx
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0.0112f,0.0002f,0.0191f,0.9998f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.7873f,-0.2006f,-0.192f,0.5505f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.2509f,0.5737f,-0.7706f,0.119f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.1274f,0.0017f,0.013f,0.9918f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.013f,0.9918f,0.1274f,0.0017f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4023f,0.8395f,0.2693f],left_rotation:[0.1585f,0.1249f,-0.5765f,0.7918f]}}
particle minecraft:cloud -51.26 65.32 -35.39 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -51.26 65.42 -35.39 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke -50.92 65.12 -37.07 0.042 0.022 -0.008 1 0 force
particle minecraft:cloud -50.92 65.32 -37.07 0.35 0.18 0.35 0.02 3 force
