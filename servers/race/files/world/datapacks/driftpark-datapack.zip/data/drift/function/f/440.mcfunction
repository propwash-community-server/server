scoreboard players set #gx drift -95024
scoreboard players set #gdx drift -229
scoreboard players set #gz drift -28062
scoreboard players set #gdz drift 824
scoreboard players set #gr drift -1104
scoreboard players set #gdr drift -87
function drift:glide/move/kaze
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.0389f,-0.1913f,0.061f,0.9789f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.0415f,0.9778f,0.0593f,0.1965f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.0174f,-0.0002f,0.0131f,0.9998f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.0131f,-0.9998f,0.0174f,0.0002f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.3993f,0.848f,0.0999f],left_rotation:[0.0319f,0.1823f,-0.9617f,0.2023f]}}
particle minecraft:cloud -94.46 65.32 -29.51 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -94.46 65.42 -29.51 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke -96.09 65.12 -29.19 -0.028 0.022 -0.03 1 0 force
particle minecraft:cloud -96.09 65.32 -29.19 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -96.09 65.42 -29.19 0.45 0.2 0.45 0.008 1 force
scoreboard players set #gx drift -91282
scoreboard players set #gdx drift -410
scoreboard players set #gz drift -38431
scoreboard players set #gdz drift 612
scoreboard players set #gr drift -525
scoreboard players set #gdr drift -93
function drift:glide/move/onyx
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0058f,-0.0001f,0.0204f,0.9998f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.9382f,-0.0061f,0.2737f,0.2117f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.2529f,0.1841f,0.944f,0.1047f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.0174f,-0.0002f,0.0131f,0.9998f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.0131f,-0.9998f,0.0174f,0.0002f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4049f,0.847f,0.2399f],left_rotation:[0.1408f,0.1202f,-0.6071f,0.7728f]}}
particle minecraft:cloud -90.56 65.32 -39.92 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -90.56 65.42 -39.92 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke -92.26 65.12 -39.76 -0.027 0.022 -0.035 1 0 force
particle minecraft:cloud -92.26 65.32 -39.76 0.35 0.18 0.35 0.02 3 force
