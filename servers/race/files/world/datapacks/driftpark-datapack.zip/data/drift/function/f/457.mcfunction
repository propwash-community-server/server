scoreboard players set #gx drift -96895
scoreboard players set #gdx drift 42
scoreboard players set #gz drift -12270
scoreboard players set #gdz drift 1033
scoreboard players set #gr drift -2507
scoreboard players set #gdr drift -42
function drift:glide/move/kaze
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0059f,-0.0001f,0.0184f,0.9998f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.2565f,-0.1466f,0.0945f,0.9507f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.0049f,0.946f,0.2733f,0.1744f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.2018f,0.0026f,0.0128f,0.9793f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.0128f,0.9793f,0.2018f,0.0026f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4015f,0.847f,0.0999f],left_rotation:[0.0148f,-0.1844f,0.9818f,0.0425f]}}
particle minecraft:campfire_cosy_smoke -96.69 65.12 -13.81 0.038 0.02 -0.069 1 0 force
particle minecraft:cloud -96.69 65.32 -13.81 0.35 0.18 0.35 0.02 2 force
particle minecraft:cloud -98.21 65.32 -13.1 0.35 0.18 0.35 0.02 2 force
scoreboard players set #gx drift -96550
scoreboard players set #gdx drift -193
scoreboard players set #gz drift -25749
scoreboard players set #gdz drift 883
scoreboard players set #gr drift -1713
scoreboard players set #gdr drift -86
function drift:glide/move/onyx
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0058f,-0.0001f,0.0173f,0.9998f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.0799f,-0.2204f,0.0357f,0.9715f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.0662f,0.9731f,-0.0572f,0.2132f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.2018f,0.0026f,0.0128f,0.9793f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.0128f,0.9793f,0.2018f,0.0026f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.3996f,0.8495f,0.2399f],left_rotation:[0.0697f,0.1714f,-0.897f,0.4015f]}}
particle minecraft:campfire_cosy_smoke -96.15 65.12 -27.35 0.042 0.022 -0.063 1 0 force
particle minecraft:cloud -96.15 65.32 -27.35 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud -97.78 65.32 -26.85 0.35 0.18 0.35 0.02 3 force
