scoreboard players set #gx drift -96346
scoreboard players set #gdx drift -131
scoreboard players set #gz drift -22001
scoreboard players set #gdz drift 919
scoreboard players set #gr drift -1703
scoreboard players set #gdr drift -98
function drift:glide/move/kaze
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0058f,-0.0001f,0.0182f,0.9998f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.2312f,-0.1924f,0.0082f,0.9537f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.092f,0.9581f,-0.2122f,0.1692f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.2918f,-0.0038f,0.0125f,0.9564f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.0125f,-0.9564f,0.2918f,0.0038f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4012f,0.8472f,0.0999f],left_rotation:[0.0172f,0.1843f,-0.9745f,0.1272f]}}
particle minecraft:campfire_cosy_smoke -95.93 65.12 -23.5 0.054 0.021 -0.067 1 0 force
particle minecraft:cloud -95.93 65.32 -23.5 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -95.93 65.42 -23.5 0.45 0.2 0.45 0.008 1 force
particle minecraft:cloud -97.53 65.32 -23.01 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -97.53 65.42 -23.01 0.45 0.2 0.45 0.008 1 force
scoreboard players set #gx drift -93889
scoreboard players set #gdx drift -324
scoreboard players set #gz drift -33778
scoreboard players set #gdz drift 734
scoreboard players set #gr drift -982
scoreboard players set #gdr drift -65
function drift:glide/move/onyx
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0058f,-0.0001f,0.0183f,0.9998f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.1456f,-0.2432f,0.0176f,0.9588f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.0831f,0.9623f,-0.1208f,0.2293f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.2918f,-0.0038f,0.0125f,0.9564f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.0125f,-0.9564f,0.2918f,0.0038f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4013f,0.8487f,0.24f],left_rotation:[0.1017f,0.1547f,-0.8009f,0.5694f]}}
particle minecraft:campfire_cosy_smoke -93.29 65.12 -35.32 0.065 0.022 -0.045 1 0 force
particle minecraft:cloud -93.29 65.32 -35.32 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud -94.97 65.32 -35.03 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -94.97 65.42 -35.03 0.45 0.2 0.45 0.008 1 force
