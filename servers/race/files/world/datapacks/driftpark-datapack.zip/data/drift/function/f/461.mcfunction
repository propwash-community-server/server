scoreboard players set #gx drift -96617
scoreboard players set #gdx drift 114
scoreboard players set #gz drift -8083
scoreboard players set #gdz drift 1070
scoreboard players set #gr drift -2606
scoreboard players set #gdr drift 8
function drift:glide/move/kaze
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0058f,-0.0001f,0.0172f,0.9998f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.7032f,-0.1377f,-0.0642f,0.6945f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.1376f,0.7051f,-0.6926f,0.0646f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.7536f,-0.0099f,0.0086f,0.6572f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.0086f,-0.6572f,0.7536f,0.0099f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.3994f,0.848f,0.1f],left_rotation:[0.054f,-0.1771f,0.9493f,0.2542f]}}
particle minecraft:campfire_cosy_smoke -96.44 65.12 -9.63 0.036 0.018 -0.07 1 0 force
particle minecraft:cloud -96.44 65.32 -9.63 0.35 0.18 0.35 0.02 2 force
particle minecraft:cloud -97.94 65.32 -8.89 0.35 0.18 0.35 0.02 2 force
scoreboard players set #gx drift -97235
scoreboard players set #gdx drift -133
scoreboard players set #gz drift -22138
scoreboard players set #gdz drift 937
scoreboard players set #gr drift -2058
scoreboard players set #gdr drift -97
function drift:glide/move/onyx
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0058f,-0.0001f,0.0182f,0.9998f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.8772f,-0.1409f,-0.1667f,0.4277f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.2126f,0.4476f,-0.8672f,0.0495f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.7536f,-0.0099f,0.0086f,0.6572f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.0086f,-0.6572f,0.7536f,0.0099f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4012f,0.8488f,0.2399f],left_rotation:[0.0614f,0.1746f,-0.9146f,0.3596f]}}
particle minecraft:campfire_cosy_smoke -96.93 65.12 -23.76 0.054 0.022 -0.061 1 0 force
particle minecraft:cloud -96.93 65.32 -23.76 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud -98.53 65.32 -23.16 0.35 0.18 0.35 0.02 3 force
