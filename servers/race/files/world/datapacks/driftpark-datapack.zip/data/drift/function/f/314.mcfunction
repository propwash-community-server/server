scoreboard players set #gx drift -19604
scoreboard players set #gdx drift -698
scoreboard players set #gz drift -11081
scoreboard players set #gdz drift 8
scoreboard players set #gr drift 12794
scoreboard players set #gdr drift 141
function drift:glide/move/kaze
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0047f,0.0001f,-0.0223f,0.9997f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.959f,-0.0325f,0.2705f,0.0781f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.2638f,-0.0501f,0.9609f,0.0682f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.9589f,-0.0126f,0.0037f,0.2835f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.0037f,-0.2835f,0.9589f,0.0126f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.3313f,0.8766f,0.1019f],left_rotation:[0.1399f,-0.1229f,0.615f,0.7662f]}}
particle minecraft:cloud -19.08 65.32 -9.62 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -18.06 65.12 -10.93 0.061 0.022 -0.034 1 0 force
particle minecraft:cloud -18.06 65.32 -10.93 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx drift -10511
scoreboard players set #gdx drift -604
scoreboard players set #gz drift -12506
scoreboard players set #gdz drift 308
scoreboard players set #gr drift 10954
scoreboard players set #gdr drift 167
function drift:glide/move/onyx
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0.0055f,-0.0001f,-0.0223f,0.9997f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.5741f,0.2862f,-0.1489f,0.7526f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.2288f,-0.7723f,-0.5472f,0.2274f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.9589f,-0.0126f,0.0037f,0.2835f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.0037f,-0.2835f,0.9589f,0.0126f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.3315f,0.8728f,0.2594f],left_rotation:[0.1906f,-0.0467f,0.1906f,0.9619f]}}
particle minecraft:cloud -9.46 65.32 -11.23 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -8.89 65.12 -12.84 0.04 0.022 -0.052 1 0 force
particle minecraft:cloud -8.89 65.32 -12.84 0.35 0.18 0.35 0.02 3 force
