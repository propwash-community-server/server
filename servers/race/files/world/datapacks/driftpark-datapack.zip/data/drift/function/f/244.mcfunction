scoreboard players set #gx drift 18975
scoreboard players set #gdx drift -735
scoreboard players set #gz drift -46655
scoreboard players set #gdz drift 359
scoreboard players set #gr drift 2831
scoreboard players set #gdr drift -195
function drift:glide/move/kaze
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0.0063f,0.0001f,0.0223f,0.9997f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.9552f,0.0193f,0.2668f,0.1267f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.255f,0.0994f,0.9584f,0.081f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.9977f,0.0131f,0.0009f,0.0667f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.0009f,0.0667f,0.9977f,0.0131f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4078f,0.8412f,0.1209f],left_rotation:[0.1417f,0.1369f,-0.649f,0.7348f]}}
particle minecraft:cloud 20.33 65.32 -47.41 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 18.86 65.12 -48.2 0.001 0.022 -0.029 1 0 force
particle minecraft:cloud 18.86 65.32 -48.2 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx drift 30729
scoreboard players set #gdx drift -924
scoreboard players set #gz drift -50791
scoreboard players set #gdz drift 107
scoreboard players set #gr drift 4927
scoreboard players set #gdr drift -150
function drift:glide/move/onyx
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0f,0f,0.0223f,0.9998f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.3232f,-0.2549f,-0.0331f,0.9108f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.129f,0.9192f,-0.2982f,0.2223f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.9977f,0.0131f,0.0009f,0.0667f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.0009f,0.0667f,0.9977f,0.0131f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4079f,0.8427f,0.2501f],left_rotation:[0.1233f,0.1456f,-0.7202f,0.667f]}}
particle minecraft:cloud 32.36 65.32 -51.07 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 31.24 65.12 -52.36 0.012 0.022 -0.041 1 0 force
particle minecraft:cloud 31.24 65.32 -52.36 0.35 0.18 0.35 0.02 3 force
