scoreboard players set #gx drift 74769
scoreboard players set #gdx drift -776
scoreboard players set #gz drift -32094
scoreboard players set #gdz drift -761
scoreboard players set #gr drift 11004
scoreboard players set #gdr drift -95
function drift:glide/move/kaze
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0052f,-0.0001f,0.0223f,0.9997f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.1739f,-0.1885f,0.0202f,0.9663f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.0813f,0.9695f,-0.1551f,0.1713f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.1847f,-0.0024f,0.0129f,0.9827f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.0129f,-0.9827f,0.1847f,0.0024f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4079f,0.8438f,0.1011f],left_rotation:[0.0113f,0.1854f,-0.9772f,0.1033f]}}
particle minecraft:campfire_cosy_smoke 75.71 65.12 -30.86 0.023 0.021 0.074 1 0 force
particle minecraft:cloud 75.71 65.32 -30.86 0.35 0.18 0.35 0.02 2 force
particle minecraft:cloud 76.29 65.32 -32.43 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke 76.29 65.42 -32.43 0.45 0.2 0.45 0.008 1 force
scoreboard players set #gx drift 84286
scoreboard players set #gdx drift -515
scoreboard players set #gz drift -20853
scoreboard players set #gdz drift -933
scoreboard players set #gr drift 12124
scoreboard players set #gdr drift -111
function drift:glide/move/onyx
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0.0022f,0f,0.0223f,0.9998f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.6957f,-0.116f,0.1951f,0.6815f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.1246f,0.6648f,0.7117f,0.1898f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.1847f,-0.0024f,0.0129f,0.9827f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.0129f,-0.9827f,0.1847f,0.0024f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4078f,0.8416f,0.2537f],left_rotation:[0.0782f,0.1764f,-0.8784f,0.4373f]}}
particle minecraft:campfire_cosy_smoke 85.05 65.12 -19.39 0.011 0.022 0.081 1 0 force
particle minecraft:cloud 85.05 65.32 -19.39 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud 85.94 65.32 -20.85 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 85.94 65.42 -20.85 0.45 0.2 0.45 0.008 1 force
