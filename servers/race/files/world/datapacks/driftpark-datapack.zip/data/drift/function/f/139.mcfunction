scoreboard players set #gx drift 89613
scoreboard players set #gdx drift 134
scoreboard players set #gz drift 12617
scoreboard players set #gdz drift -1056
scoreboard players set #gr drift 16185
scoreboard players set #gdr drift -116
function drift:glide/move/kaze
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0005f,0f,0.0223f,0.9998f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.5496f,-0.1872f,-0.0624f,0.8118f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.148f,0.8228f,-0.533f,0.1304f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.563f,-0.0074f,0.0108f,0.8263f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.0108f,-0.8263f,0.563f,0.0074f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4079f,0.8428f,0.1091f],left_rotation:[0.0255f,0.1886f,-0.9661f,0.1746f]}}
particle minecraft:campfire_cosy_smoke 89.23 65.12 14.12 -0.037 0.021 0.066 1 0 force
particle minecraft:cloud 89.23 65.32 14.12 0.35 0.18 0.35 0.02 2 force
particle minecraft:cloud 90.81 65.32 13.6 0.35 0.18 0.35 0.02 2 force
scoreboard players set #gx drift 86451
scoreboard players set #gdx drift 416
scoreboard players set #gz drift 27055
scoreboard players set #gdz drift -960
scoreboard players set #gr drift 17374
scoreboard players set #gdr drift -109
function drift:glide/move/onyx
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.002f,0f,0.0223f,0.9998f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.1324f,-0.2112f,0.0831f,0.9649f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.0178f,0.9614f,0.1553f,0.2263f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.563f,-0.0074f,0.0108f,0.8263f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.0108f,-0.8263f,0.563f,0.0074f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4079f,0.8437f,0.2465f],left_rotation:[0.0764f,0.1726f,-0.8794f,0.437f]}}
particle minecraft:campfire_cosy_smoke 85.75 65.12 28.55 -0.062 0.022 0.047 1 0 force
particle minecraft:cloud 85.75 65.32 28.55 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 85.75 65.42 28.55 0.45 0.2 0.45 0.008 1 force
particle minecraft:cloud 87.45 65.32 28.37 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 87.45 65.42 28.37 0.45 0.2 0.45 0.008 1 force
