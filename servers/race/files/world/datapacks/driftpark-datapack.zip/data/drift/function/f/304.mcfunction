scoreboard players set #gx drift -13259
scoreboard players set #gdx drift -583
scoreboard players set #gz drift -12256
scoreboard players set #gdz drift 204
scoreboard players set #gr drift 11207
scoreboard players set #gdr drift 206
function drift:glide/move/kaze
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0.0001f,0f,-0.0223f,0.9998f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.8382f,0.1822f,-0.2153f,0.4667f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.2655f,-0.4919f,-0.8237f,0.0951f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.9775f,0.0128f,0.0028f,0.2104f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.0028f,0.2104f,0.9775f,0.0128f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.3314f,0.8756f,0.1101f],left_rotation:[0.1543f,-0.1124f,0.542f,0.8184f]}}
particle minecraft:cloud -12.36 65.32 -10.99 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -11.73 65.12 -12.54 0.037 0.022 -0.05 1 0 force
particle minecraft:cloud -11.73 65.32 -12.54 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx drift -4491
scoreboard players set #gdx drift -599
scoreboard players set #gz drift -17035
scoreboard players set #gdz drift 579
scoreboard players set #gr drift 9036
scoreboard players set #gdr drift 211
function drift:glide/move/onyx
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0.011f,-0.0002f,-0.0222f,0.9997f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.7287f,0.1649f,0.2877f,0.5992f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.2263f,-0.5723f,0.75f,0.2423f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.9775f,0.0128f,0.0028f,0.2104f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.0028f,0.2104f,0.9775f,0.0128f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.3317f,0.8699f,0.2688f],left_rotation:[0.1992f,-0.0307f,0.1063f,0.9737f]}}
particle minecraft:cloud -3.08 65.32 -16.17 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -3.08 65.42 -16.17 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke -3.07 65.12 -17.88 0.026 0.022 -0.071 1 0 force
particle minecraft:cloud -3.07 65.32 -17.88 0.35 0.18 0.35 0.02 3 force
