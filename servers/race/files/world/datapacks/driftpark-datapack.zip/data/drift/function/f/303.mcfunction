scoreboard players set #gx drift -12677
scoreboard players set #gdx drift -582
scoreboard players set #gz drift -12482
scoreboard players set #gdz drift 227
scoreboard players set #gr drift 11034
scoreboard players set #gdr drift 173
function drift:glide/move/kaze
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0.002f,0f,-0.0223f,0.9998f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.1033f,0.2836f,0.0241f,0.9531f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.0759f,-0.9558f,-0.074f,0.2743f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.0522f,0.0007f,0.0131f,0.9985f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.0131f,0.9985f,0.0522f,0.0007f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.3314f,0.8752f,0.1135f],left_rotation:[0.1586f,-0.1096f,0.5213f,0.8313f]}}
particle minecraft:campfire_cosy_smoke -11.74 65.12 -11.24 0.021 0.022 0.03 1 0 force
particle minecraft:cloud -11.74 65.32 -11.24 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud -11.16 65.32 -12.81 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx drift -3894
scoreboard players set #gdx drift -597
scoreboard players set #gz drift -17642
scoreboard players set #gdz drift 607
scoreboard players set #gr drift 8821
scoreboard players set #gdr drift 215
function drift:glide/move/onyx
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0.0113f,-0.0002f,-0.0221f,0.9997f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.8017f,0.2183f,-0.246f,0.4991f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.2998f,-0.5277f,-0.7832f,0.1352f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.0522f,0.0007f,0.0131f,0.9985f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.0131f,0.9985f,0.0522f,0.0007f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.3319f,0.8697f,0.2693f],left_rotation:[0.1986f,-0.036f,0.1319f,0.9705f]}}
particle minecraft:campfire_cosy_smoke -2.45 65.12 -16.83 0.033 0.022 0.001 1 0 force
particle minecraft:cloud -2.45 65.32 -16.83 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud -2.51 65.32 -18.54 0.35 0.18 0.35 0.02 3 force
