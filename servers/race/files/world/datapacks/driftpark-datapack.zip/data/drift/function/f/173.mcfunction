scoreboard players set #gx drift 82484
scoreboard players set #gdx drift -545
scoreboard players set #gz drift -22254
scoreboard players set #gdz drift -887
scoreboard players set #gr drift 12252
scoreboard players set #gdr drift -108
function drift:glide/move/kaze
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0.0024f,0.0001f,0.0223f,0.9997f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.1472f,-0.1985f,0.0238f,0.9687f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.0779f,0.9715f,-0.1271f,0.1842f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.1561f,-0.002f,0.0129f,0.9876f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.0129f,-0.9876f,0.1561f,0.002f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4079f,0.8422f,0.1141f],left_rotation:[0.0307f,0.1907f,-0.9608f,0.199f]}}
particle minecraft:campfire_cosy_smoke 83.14 65.12 -20.85 0.008 0.022 0.069 1 0 force
particle minecraft:cloud 83.14 65.32 -20.85 0.35 0.18 0.35 0.02 2 force
particle minecraft:cloud 84.04 65.32 -22.25 0.35 0.18 0.35 0.02 2 force
scoreboard players set #gx drift 89061
scoreboard players set #gdx drift -292
scoreboard players set #gz drift -8791
scoreboard players set #gdz drift -1053
scoreboard players set #gr drift 13558
scoreboard players set #gdr drift -119
function drift:glide/move/onyx
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0.0003f,0f,0.0223f,0.9998f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.6718f,-0.1203f,0.1884f,0.7062f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.1153f,0.6903f,0.6882f,0.1916f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.1561f,-0.002f,0.0129f,0.9876f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.0129f,-0.9876f,0.1561f,0.002f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4079f,0.8425f,0.2506f],left_rotation:[0.0717f,0.1772f,-0.8927f,0.4082f]}}
particle minecraft:campfire_cosy_smoke 89.44 65.12 -7.18 -0.02 0.022 0.088 1 0 force
particle minecraft:cloud 89.44 65.32 -7.18 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud 90.66 65.32 -8.38 0.35 0.18 0.35 0.02 3 force
