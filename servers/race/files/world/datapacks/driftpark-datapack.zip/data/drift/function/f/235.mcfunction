scoreboard players set #gx drift 26348
scoreboard players set #gdx drift -874
scoreboard players set #gz drift -49164
scoreboard players set #gdz drift 207
scoreboard players set #gr drift 4533
scoreboard players set #gdr drift -170
function drift:glide/move/kaze
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0.0032f,0.0001f,0.0223f,0.9997f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.7105f,-0.1979f,-0.1334f,0.662f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.2037f,0.6796f,-0.6936f,0.1243f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.7381f,-0.0097f,0.0088f,0.6745f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.0088f,-0.6745f,0.7381f,0.0097f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4079f,0.842f,0.1155f],left_rotation:[0.0977f,0.1675f,-0.8246f,0.5315f]}}
particle minecraft:campfire_cosy_smoke 27.87 65.12 -49.49 0.077 0.022 0.014 1 0 force
particle minecraft:cloud 27.87 65.32 -49.49 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud 26.69 65.32 -50.68 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx drift 39205
scoreboard players set #gdx drift -964
scoreboard players set #gz drift -50776
scoreboard players set #gdz drift -89
scoreboard players set #gr drift 6226
scoreboard players set #gdr drift -138
function drift:glide/move/onyx
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0.0048f,0.0001f,0.0223f,0.9997f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.3932f,-0.2017f,0.1487f,0.8847f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.0565f,0.8739f,0.4165f,0.2441f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.7381f,-0.0097f,0.0088f,0.6745f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.0088f,-0.6745f,0.7381f,0.0097f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4078f,0.8403f,0.2582f],left_rotation:[0.1169f,0.1567f,-0.7591f,0.621f]}}
particle minecraft:campfire_cosy_smoke 40.86 65.12 -50.68 0.06 0.022 0.045 1 0 force
particle minecraft:cloud 40.86 65.32 -50.68 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud 40.06 65.32 -52.19 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 40.06 65.42 -52.19 0.45 0.2 0.45 0.008 1 force
