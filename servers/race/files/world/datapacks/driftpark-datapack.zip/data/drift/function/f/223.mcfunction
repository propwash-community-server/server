scoreboard players set #gx drift 37229
scoreboard players set #gdx drift -932
scoreboard players set #gz drift -50034
scoreboard players set #gdz drift -44
scoreboard players set #gr drift 6318
scoreboard players set #gdr drift -137
function drift:glide/move/kaze
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0.0039f,0.0001f,0.0223f,0.9997f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.6937f,-0.191f,-0.1172f,0.6846f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.1898f,0.7006f,-0.6774f,0.1191f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.7182f,-0.0094f,0.0091f,0.6957f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.0091f,-0.6957f,0.7182f,0.0094f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4079f,0.8418f,0.1167f],left_rotation:[0.0738f,0.1801f,-0.8902f,0.412f]}}
particle minecraft:campfire_cosy_smoke 38.77 65.12 -49.88 0.072 0.022 0.036 1 0 force
particle minecraft:cloud 38.77 65.32 -49.88 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 38.77 65.42 -49.88 0.45 0.2 0.45 0.008 1 force
particle minecraft:cloud 38.02 65.32 -51.37 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx drift 51343
scoreboard players set #gdx drift -1054
scoreboard players set #gz drift -47729
scoreboard players set #gdz drift -403
scoreboard players set #gr drift 8034
scoreboard players set #gdr drift -147
function drift:glide/move/onyx
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0.0103f,0.0002f,0.0222f,0.9997f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.3644f,-0.1883f,0.134f,0.9021f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.0399f,0.893f,0.3862f,0.2276f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.7182f,-0.0094f,0.0091f,0.6957f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.0091f,-0.6957f,0.7182f,0.0094f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4077f,0.8374f,0.2676f],left_rotation:[0.0884f,0.1804f,-0.8596f,0.4698f]}}
particle minecraft:campfire_cosy_smoke 52.88 65.12 -47.12 0.057 0.022 0.052 1 0 force
particle minecraft:cloud 52.88 65.32 -47.12 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud 52.59 65.32 -48.81 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 52.59 65.42 -48.81 0.45 0.2 0.45 0.008 1 force
