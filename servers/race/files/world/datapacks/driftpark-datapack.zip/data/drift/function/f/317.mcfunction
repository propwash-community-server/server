scoreboard players set #gx drift -21722
scoreboard players set #gdx drift -720
scoreboard players set #gz drift -11122
scoreboard players set #gdz drift -57
scoreboard players set #gr drift 13213
scoreboard players set #gdr drift 164
function drift:glide/move/kaze
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0037f,0.0001f,-0.0223f,0.9997f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.9416f,0.0024f,0.2694f,0.2023f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.2496f,-0.1751f,0.947f,0.1013f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.4839f,-0.0063f,0.0115f,0.875f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.0115f,-0.875f,0.4839f,0.0063f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.3313f,0.8764f,0.1036f],left_rotation:[0.1369f,-0.1276f,0.6372f,0.7476f]}}
particle minecraft:campfire_cosy_smoke -21.31 65.12 -9.62 0.002 0.022 0.03 1 0 force
particle minecraft:cloud -21.31 65.32 -9.62 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud -20.19 65.32 -10.86 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx drift -12333
scoreboard players set #gdx drift -610
scoreboard players set #gz drift -11651
scoreboard players set #gdz drift 237
scoreboard players set #gr drift 11491
scoreboard players set #gdr drift 173
function drift:glide/move/onyx
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0.002f,0f,-0.0223f,0.9998f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.3816f,0.3058f,-0.0741f,0.8691f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.1659f,-0.8817f,-0.3515f,0.2674f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.4839f,-0.0063f,0.0115f,0.875f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.0115f,-0.875f,0.4839f,0.0063f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.3314f,0.8746f,0.2535f],left_rotation:[0.1832f,-0.06f,0.2635f,0.9452f]}}
particle minecraft:campfire_cosy_smoke -11.41 65.12 -10.28 0.009 0.022 0.034 1 0 force
particle minecraft:cloud -11.41 65.32 -10.28 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud -10.69 65.32 -11.83 0.35 0.18 0.35 0.02 3 force
