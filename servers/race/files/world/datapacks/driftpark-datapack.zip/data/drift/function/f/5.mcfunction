scoreboard players set #gx drift -47719
scoreboard players set #gdx drift 1104
scoreboard players set #gz drift 62943
scoreboard players set #gdz drift 199
scoreboard players set #gr drift -9935
scoreboard players set #gdr drift -15
function drift:glide/move/kaze
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0059f,-0.0001f,0.0174f,0.9998f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.2374f,-0.1256f,0.0856f,0.9594f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.0148f,0.9557f,0.2519f,0.1513f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.2471f,0.0032f,0.0127f,0.9689f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.0127f,0.9689f,0.2471f,0.0032f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.3998f,0.8478f,0.0999f],left_rotation:[0.0539f,-0.177f,0.9495f,0.2536f]}}
particle minecraft:campfire_cosy_smoke -49.15 65.12 62.33 -0.071 0.018 -0.043 1 0 force
particle minecraft:cloud -49.15 65.32 62.33 0.35 0.18 0.35 0.02 2 force
particle minecraft:cloud -48.88 65.32 63.98 0.35 0.18 0.35 0.02 2 force
scoreboard players set #gx drift -62026
scoreboard players set #gdx drift 914
scoreboard players set #gz drift 59483
scoreboard players set #gdz drift 390
scoreboard players set #gr drift -9486
scoreboard players set #gdr drift -73
function drift:glide/move/onyx
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0059f,-0.0001f,0.0199f,0.9998f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.2559f,-0.1891f,0.1069f,0.942f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.0084f,0.9359f,0.2771f,0.2171f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.2471f,0.0032f,0.0127f,0.9689f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.0127f,0.9689f,0.2471f,0.0032f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.404f,0.8475f,0.2399f],left_rotation:[0.0594f,0.1753f,-0.9175f,0.352f]}}
particle minecraft:campfire_cosy_smoke -63.51 65.12 58.75 -0.044 0.022 -0.065 1 0 force
particle minecraft:cloud -63.51 65.32 58.75 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -63.51 65.42 58.75 0.45 0.2 0.45 0.008 1 force
particle minecraft:cloud -63.36 65.32 60.45 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -63.36 65.42 60.45 0.45 0.2 0.45 0.008 1 force
