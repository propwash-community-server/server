scoreboard players set #gx drift -96884
scoreboard players set #gdx drift -30
scoreboard players set #gz drift -16299
scoreboard players set #gdz drift 991
scoreboard players set #gr drift -2234
scoreboard players set #gdr drift -69
function drift:glide/move/kaze
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.9519f,0.0075f,0.1847f,0.2444f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.16f,0.2263f,0.9564f,0.0925f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.952f,0.0125f,0.004f,0.3057f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.004f,0.3057f,0.952f,0.0125f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4023f,0.8466f,0.0999f],left_rotation:[0.0034f,0.185f,-0.9812f,0.0553f]}}
particle minecraft:campfire_cosy_smoke -96.61 65.12 -17.83 0.038 0.021 -0.058 1 0 force
particle minecraft:cloud -96.61 65.32 -17.83 0.35 0.18 0.35 0.02 2 force
particle minecraft:cloud -98.15 65.32 -17.19 0.35 0.18 0.35 0.02 2 force
scoreboard players set #gx drift -95642
scoreboard players set #gdx drift -247
scoreboard players set #gz drift -29138
scoreboard players set #gdz drift 825
scoreboard players set #gr drift -1396
scoreboard players set #gdr drift -71
function drift:glide/move/onyx
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0059f,-0.0001f,0.0172f,0.9998f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.8077f,-0.0794f,0.2142f,0.5435f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.1583f,0.524f,0.8205f,0.1648f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.952f,0.0125f,0.004f,0.3057f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.004f,0.3057f,0.952f,0.0125f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.3995f,0.8496f,0.2399f],left_rotation:[0.0782f,0.1677f,-0.8758f,0.4457f]}}
particle minecraft:campfire_cosy_smoke -95.15 65.12 -30.72 0.051 0.022 -0.042 1 0 force
particle minecraft:cloud -95.15 65.32 -30.72 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud -96.81 65.32 -30.31 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -96.81 65.42 -30.31 0.45 0.2 0.45 0.008 1 force
