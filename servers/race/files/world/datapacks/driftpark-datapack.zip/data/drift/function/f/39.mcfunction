scoreboard players set #gx drift -5217
scoreboard players set #gdx drift 1299
scoreboard players set #gz drift 63877
scoreboard players set #gdz drift -28
scoreboard players set #gr drift -9074
scoreboard players set #gdr drift -2
function drift:glide/move/kaze
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0f,0f,-0.0014f,1f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.6394f,0.0356f,0.0384f,0.7671f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.042f,0.7673f,0.6392f,0.0314f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.6373f,0.0083f,0.0101f,0.7705f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.0101f,0.7705f,0.6373f,0.0083f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.3677f,0.861f,0.11f],left_rotation:[0.1908f,0.0045f,-0.0259f,0.9813f]}}
scoreboard players set #gx drift -23401
scoreboard players set #gdx drift 1299
scoreboard players set #gz drift 64586
scoreboard players set #gdz drift -56
scoreboard players set #gr drift -9155
scoreboard players set #gdr drift 21
function drift:glide/move/onyx
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0f,0f,0.0051f,1f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.7827f,0.0442f,0.0285f,0.6202f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.0365f,0.6206f,0.7824f,0.0378f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.6373f,0.0083f,0.0101f,0.7705f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.0101f,0.7705f,0.6373f,0.0083f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.3787f,0.8562f,0.25f],left_rotation:[0.1906f,0.0097f,-0.0401f,0.9808f]}}
