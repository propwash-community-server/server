scoreboard players set #gx drift 83526
scoreboard players set #gdx drift -513
scoreboard players set #gz drift -20438
scoreboard players set #gdz drift -915
scoreboard players set #gr drift 12484
scoreboard players set #gdr drift -111
function drift:glide/move/kaze
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0.0022f,0f,0.0223f,0.9998f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.361f,-0.1603f,0.1209f,0.9107f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.0259f,0.903f,0.3799f,0.1991f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.3631f,0.0048f,0.0122f,0.9317f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.0122f,0.9317f,0.3631f,0.0048f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4079f,0.8422f,0.1137f],left_rotation:[0.0322f,0.1902f,-0.9592f,0.2066f]}}
particle minecraft:campfire_cosy_smoke 84.12 65.12 -19 0.009 0.022 0.083 1 0 force
particle minecraft:cloud 84.12 65.32 -19 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke 84.12 65.42 -19 0.45 0.2 0.45 0.008 1 force
particle minecraft:cloud 85.08 65.32 -20.37 0.35 0.18 0.35 0.02 2 force
scoreboard players set #gx drift 89585
scoreboard players set #gdx drift -251
scoreboard players set #gz drift -6670
scoreboard players set #gdz drift -1063
scoreboard players set #gr drift 13795
scoreboard players set #gdr drift -118
function drift:glide/move/onyx
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0f,0f,0.0223f,0.9998f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.9334f,-0.0111f,0.2228f,0.2812f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.1945f,0.2593f,0.9397f,0.1093f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.3631f,0.0048f,0.0122f,0.9317f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.0122f,0.9317f,0.3631f,0.0048f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4079f,0.8427f,0.25f],left_rotation:[0.0707f,0.1772f,-0.8947f,0.4039f]}}
particle minecraft:campfire_cosy_smoke 89.9 65.12 -5.05 -0.011 0.022 0.074 1 0 force
particle minecraft:cloud 89.9 65.32 -5.05 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 89.9 65.42 -5.05 0.45 0.2 0.45 0.008 1 force
particle minecraft:cloud 91.17 65.32 -6.19 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 91.17 65.42 -6.19 0.45 0.2 0.45 0.008 1 force
