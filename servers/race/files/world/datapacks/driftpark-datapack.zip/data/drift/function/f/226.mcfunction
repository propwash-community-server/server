scoreboard players set #gx drift 34452
scoreboard players set #gdx drift -914
scoreboard players set #gz drift -50102
scoreboard players set #gdz drift 20
scoreboard players set #gr drift 5903
scoreboard players set #gdr drift -156
function drift:glide/move/kaze
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0.0021f,0f,0.0223f,0.9998f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.0133f,-0.2195f,0.0507f,0.9742f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.0515f,0.9742f,0.0097f,0.2193f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.0232f,-0.0003f,0.0131f,0.9996f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.0131f,-0.9996f,0.0232f,0.0003f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4079f,0.8422f,0.1136f],left_rotation:[0.0752f,0.1776f,-0.8856f,0.4224f]}}
particle minecraft:cloud 36 65.32 -50.06 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 36 65.42 -50.06 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke 35.15 65.12 -51.49 0.035 0.022 -0.04 1 0 force
particle minecraft:cloud 35.15 65.32 -51.49 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx drift 48209
scoreboard players set #gdx drift -1028
scoreboard players set #gz drift -48863
scoreboard players set #gdz drift -328
scoreboard players set #gr drift 7583
scoreboard players set #gdr drift -156
function drift:glide/move/onyx
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0.0089f,0.0002f,0.0223f,0.9997f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.8973f,-0.039f,0.2345f,0.372f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.1967f,0.3494f,0.9063f,0.1335f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.0232f,-0.0003f,0.0131f,0.9996f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.0131f,-0.9996f,0.0232f,0.0003f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4077f,0.8381f,0.2653f],left_rotation:[0.099f,0.1733f,-0.8283f,0.5235f]}}
particle minecraft:cloud 49.79 65.32 -48.38 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 49.37 65.12 -50.04 0.043 0.022 -0.024 1 0 force
particle minecraft:cloud 49.37 65.32 -50.04 0.35 0.18 0.35 0.02 3 force
