scoreboard players set #gx drift -92589
scoreboard players set #gdx drift 354
scoreboard players set #gz drift 11188
scoreboard players set #gdz drift 1203
scoreboard players set #gr drift -2370
scoreboard players set #gdr drift -34
function drift:glide/move/kaze
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0059f,-0.0001f,0.0105f,0.9999f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.5336f,-0.0732f,0.0157f,0.8424f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.0728f,0.8454f,-0.5288f,0.0175f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.5915f,-0.0077f,0.0106f,0.8062f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.0106f,-0.8062f,0.5915f,0.0077f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.388f,0.8533f,0.0999f],left_rotation:[0.1648f,-0.0842f,0.4657f,0.8654f]}}
scoreboard players set #gx drift -96794
scoreboard players set #gdx drift 196
scoreboard players set #gz drift -4766
scoreboard players set #gdz drift 1098
scoreboard players set #gr drift -2814
scoreboard players set #gdr drift 56
function drift:glide/move/onyx
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0058f,-0.0001f,0.0157f,0.9999f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.7103f,-0.1332f,-0.0615f,0.6884f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.1342f,0.6987f,-0.7002f,0.0593f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.5915f,-0.0077f,0.0106f,0.8062f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.0106f,-0.8062f,0.5915f,0.0077f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.397f,0.8508f,0.2399f],left_rotation:[0.0627f,-0.1741f,0.9347f,0.3036f]}}
particle minecraft:cloud -96.71 65.32 -6.42 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -98.22 65.12 -5.61 -0.049 0.017 -0.036 1 0 force
particle minecraft:cloud -98.22 65.32 -5.61 0.35 0.18 0.35 0.02 2 force
