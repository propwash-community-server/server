scoreboard players set #gx drift -92235
scoreboard players set #gdx drift 367
scoreboard players set #gz drift 12391
scoreboard players set #gdz drift 1210
scoreboard players set #gr drift -2404
scoreboard players set #gdr drift -42
function drift:glide/move/kaze
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0058f,-0.0001f,0.0107f,0.9999f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.6739f,-0.0036f,0.0744f,0.735f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.0024f,0.7312f,0.678f,0.0745f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.6238f,0.0082f,0.0102f,0.7815f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.0102f,0.7815f,0.6238f,0.0082f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.3884f,0.8531f,0.1001f],left_rotation:[0.1652f,-0.0836f,0.4622f,0.8672f]}}
scoreboard players set #gx drift -96599
scoreboard players set #gdx drift 215
scoreboard players set #gz drift -3668
scoreboard players set #gdz drift 1105
scoreboard players set #gr drift -2757
scoreboard players set #gdr drift 52
function drift:glide/move/onyx
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0059f,-0.0001f,0.0152f,0.9999f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.4848f,-0.0849f,0.1081f,0.8638f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.0179f,0.8572f,0.4963f,0.1363f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.6238f,0.0082f,0.0102f,0.7815f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.0102f,0.7815f,0.6238f,0.0082f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.396f,0.8513f,0.2398f],left_rotation:[0.0781f,-0.1677f,0.903f,0.3877f]}}
particle minecraft:campfire_cosy_smoke -96.5 65.12 -5.32 0.022 0.017 -0.069 1 0 force
particle minecraft:cloud -96.5 65.32 -5.32 0.35 0.18 0.35 0.02 1 force
particle minecraft:cloud -98.01 65.32 -4.53 0.35 0.18 0.35 0.02 1 force
