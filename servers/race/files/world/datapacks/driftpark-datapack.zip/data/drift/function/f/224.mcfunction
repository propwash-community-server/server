scoreboard players set #gx drift 36297
scoreboard players set #gdx drift -925
scoreboard players set #gz drift -50078
scoreboard players set #gdz drift -23
scoreboard players set #gr drift 6181
scoreboard players set #gdr drift -138
function drift:glide/move/kaze
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0.0035f,0.0001f,0.0223f,0.9997f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.4797f,-0.1633f,0.154f,0.8483f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.0657f,0.8368f,0.4995f,0.2146f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.4839f,0.0063f,0.0115f,0.875f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.0115f,0.875f,0.4839f,0.0063f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4079f,0.8419f,0.1159f],left_rotation:[0.0743f,0.1794f,-0.8886f,0.4154f]}}
particle minecraft:cloud 37.85 65.32 -49.96 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 37.06 65.12 -51.43 0.032 0.022 -0.039 1 0 force
particle minecraft:cloud 37.06 65.32 -51.43 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx drift 50289
scoreboard players set #gdx drift -1045
scoreboard players set #gz drift -48132
scoreboard players set #gdz drift -378
scoreboard players set #gr drift 7887
scoreboard players set #gdr drift -150
function drift:glide/move/onyx
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0.0098f,0.0002f,0.0223f,0.9997f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.9648f,-0.0816f,-0.2186f,0.1212f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.2326f,-0.1448f,0.9615f,0.0193f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.4839f,0.0063f,0.0115f,0.875f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.0115f,0.875f,0.4839f,0.0063f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4077f,0.8376f,0.2668f],left_rotation:[0.0921f,0.178f,-0.8492f,0.4886f]}}
particle minecraft:cloud 51.84 65.32 -47.57 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 51.51 65.12 -49.24 0.035 0.022 -0.026 1 0 force
particle minecraft:cloud 51.51 65.32 -49.24 0.35 0.18 0.35 0.02 3 force
