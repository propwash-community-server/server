scoreboard players set #gx drift -16917
scoreboard players set #gdx drift -654
scoreboard players set #gz drift -11319
scoreboard players set #gdz drift 90
scoreboard players set #gr drift 12217
scoreboard players set #gdr drift 159
function drift:glide/move/kaze
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0052f,0.0001f,-0.0223f,0.9997f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.557f,0.2536f,-0.1137f,0.7826f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.1966f,-0.7989f,-0.5334f,0.1965f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.2245f,-0.0029f,0.0128f,0.9744f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.0128f,-0.9744f,0.2245f,0.0029f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.3313f,0.8767f,0.101f],left_rotation:[0.1457f,-0.1151f,0.574f,0.7975f]}}
particle minecraft:cloud -16.25 65.32 -9.91 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -15.36 65.12 -11.33 0.047 0.022 -0.032 1 0 force
particle minecraft:cloud -15.36 65.32 -11.33 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx drift -8097
scoreboard players set #gdx drift -603
scoreboard players set #gz drift -13992
scoreboard players set #gdz drift 410
scoreboard players set #gr drift 10231
scoreboard players set #gdr drift 184
function drift:glide/move/onyx
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0.008f,-0.0002f,-0.0223f,0.9997f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.2837f,0.2948f,0.151f,0.8999f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.0572f,-0.889f,0.3162f,0.3262f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.2245f,-0.0029f,0.0128f,0.9744f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.0128f,-0.9744f,0.2245f,0.0029f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.3316f,0.8715f,0.2638f],left_rotation:[0.1963f,-0.031f,0.1098f,0.9739f]}}
particle minecraft:cloud -6.9 65.32 -12.86 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -6.53 65.12 -14.53 0.034 0.022 -0.05 1 0 force
particle minecraft:cloud -6.53 65.32 -14.53 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -6.53 65.42 -14.53 0.45 0.2 0.45 0.008 1 force
