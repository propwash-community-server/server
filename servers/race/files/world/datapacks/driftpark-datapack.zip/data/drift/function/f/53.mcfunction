scoreboard players set #gx drift 12972
scoreboard players set #gdx drift 1298
scoreboard players set #gz drift 63407
scoreboard players set #gdz drift -58
scoreboard players set #gr drift -9640
scoreboard players set #gdr drift -91
function drift:glide/move/kaze
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0f,0f,0.0064f,1f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.1361f,-0.0262f,0.0565f,0.9887f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.0471f,0.9882f,0.1396f,0.0407f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.1332f,0.0017f,0.013f,0.991f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.013f,0.991f,0.1332f,0.0017f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.3809f,0.8552f,0.11f],left_rotation:[0.1824f,-0.056f,0.3001f,0.9346f]}}
scoreboard players set #gx drift -5218
scoreboard players set #gdx drift 1300
scoreboard players set #gz drift 63828
scoreboard players set #gdz drift -14
scoreboard players set #gr drift -9066
scoreboard players set #gdr drift -3
function drift:glide/move/onyx
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0f,0f,-0.0014f,1f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.4057f,0.0243f,0.0465f,0.9125f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.0492f,0.9127f,0.4054f,0.0182f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.1332f,0.0017f,0.013f,0.991f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.013f,0.991f,0.1332f,0.0017f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.3677f,0.861f,0.25f],left_rotation:[0.1907f,0.0054f,-0.0305f,0.9812f]}}
