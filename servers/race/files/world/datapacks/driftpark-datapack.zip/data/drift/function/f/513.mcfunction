scoreboard players set #gx drift -75137
scoreboard players set #gdx drift 591
scoreboard players set #gz drift 48722
scoreboard players set #gdz drift 683
scoreboard players set #gr drift -7264
scoreboard players set #gdr drift -138
function drift:glide/move/kaze
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0.0102f,0.0002f,0.0222f,0.9997f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.8964f,-0.04f,0.2365f,0.3727f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.1986f,0.3499f,0.9056f,0.1345f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.8978f,0.0118f,0.0058f,0.4402f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.0058f,0.4402f,0.8978f,0.0118f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4077f,0.8403f,0.1276f],left_rotation:[0.1032f,0.1723f,-0.8174f,0.54f]}}
particle minecraft:campfire_cosy_smoke -76.14 65.12 47.53 -0.009 0.022 -0.081 1 0 force
particle minecraft:cloud -76.14 65.32 47.53 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud -76.64 65.32 49.13 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -76.64 65.42 49.13 0.45 0.2 0.45 0.008 1 force
scoreboard players set #gx drift -83274
scoreboard players set #gdx drift 482
scoreboard players set #gz drift 36414
scoreboard players set #gdz drift 1087
scoreboard players set #gr drift -5055
scoreboard players set #gdr drift -202
function drift:glide/move/onyx
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0.0111f,0.0002f,0.014f,0.9998f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.8857f,-0.0361f,0.2023f,0.4163f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.1597f,0.3974f,0.8944f,0.1294f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.8978f,0.0118f,0.0058f,0.4402f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.0058f,0.4402f,0.8978f,0.0118f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.3937f,0.8435f,0.2691f],left_rotation:[0.0442f,0.1968f,-0.9493f,0.2412f]}}
particle minecraft:campfire_cosy_smoke -83.82 65.12 34.86 0.008 0.021 -0.076 1 0 force
particle minecraft:cloud -83.82 65.32 34.86 0.35 0.18 0.35 0.02 2 force
particle minecraft:cloud -84.91 65.32 36.18 0.35 0.18 0.35 0.02 2 force
