scoreboard players set #gx drift -83974
scoreboard players set #gdx drift 523
scoreboard players set #gz drift 34055
scoreboard players set #gdz drift 1106
scoreboard players set #gr drift -4350
scoreboard players set #gdr drift -186
function drift:glide/move/kaze
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0.0112f,0.0001f,0.0118f,0.9999f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.758f,-0.1389f,-0.0839f,0.6318f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.1508f,0.6441f,-0.7475f,0.06f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.8079f,-0.0106f,0.0077f,0.5891f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.0077f,-0.5891f,0.8079f,0.0106f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.3901f,0.8483f,0.1293f],left_rotation:[0.0382f,-0.1982f,0.9658f,0.1626f]}}
particle minecraft:campfire_cosy_smoke -84.27 65.12 32.53 -0.006 0.018 -0.075 1 0 force
particle minecraft:cloud -84.27 65.32 32.53 0.35 0.18 0.35 0.02 2 force
particle minecraft:cloud -85.48 65.32 33.68 0.35 0.18 0.35 0.02 2 force
playsound driftpark:lap.kaze.09.130 neutral @a -83.97 65.5 34.06 12 1
playsound driftpark:lap.kaze.09.131 neutral @a -79.71 65.5 42.23 12 1
playsound driftpark:lap.kaze.09.132 neutral @a -75.14 65.5 48.72 12 1
playsound driftpark:lap.kaze.09.133 neutral @a -70.23 65.5 53.5 12 1
playsound driftpark:lap.kaze.09.134 neutral @a -64.22 65.5 57.4 12 1
playsound driftpark:lap.kaze.09.135 neutral @a -57.02 65.5 60.5 12 1
playsound driftpark:lap.kaze.09.136 neutral @a -52 65.5 62 12 1
playsound driftpark:lap.kaze.09.137 neutral @a -43.22 65.5 63.65 12 1
scoreboard players set #gx drift -90962
scoreboard players set #gdx drift 418
scoreboard players set #gz drift 17365
scoreboard players set #gdz drift 1233
scoreboard players set #gr drift -2709
scoreboard players set #gdr drift -53
function drift:glide/move/onyx
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0016f,0f,0.0113f,0.9999f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.8402f,-0.0779f,-0.0246f,0.5361f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.0811f,-0.5416f,0.8366f,0.01f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.8079f,-0.0106f,0.0077f,0.5891f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.0077f,-0.5891f,0.8079f,0.0106f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.3893f,0.8522f,0.2473f],left_rotation:[0.1608f,-0.0998f,0.5364f,0.8225f]}}
playsound driftpark:lap.onyx.09.130 neutral @a -90.96 65.5 17.36 12 1
playsound driftpark:lap.onyx.09.131 neutral @a -87.33 65.5 27.13 12 1
playsound driftpark:lap.onyx.09.132 neutral @a -83.27 65.5 36.41 12 1
playsound driftpark:lap.onyx.09.133 neutral @a -79.28 65.5 44.46 12 1
playsound driftpark:lap.onyx.09.134 neutral @a -74.61 65.5 50.67 12 1
playsound driftpark:lap.onyx.09.135 neutral @a -69.38 65.5 55.28 12 1
playsound driftpark:lap.onyx.09.136 neutral @a -65.48 65.5 57.74 12 1
playsound driftpark:lap.onyx.09.137 neutral @a -58.26 65.5 60.92 12 1
