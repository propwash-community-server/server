scoreboard players set #gx drift -37851
scoreboard players set #gdx drift -599
scoreboard players set #gz drift -18157
scoreboard players set #gdz drift -555
scoreboard players set #gr drift 15902
scoreboard players set #gdr drift -45
function drift:glide/move/kaze
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0058f,0.0001f,-0.0183f,0.9998f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.8955f,0.1205f,-0.137f,0.406f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.1804f,-0.4227f,-0.8877f,0.027f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.5339f,-0.007f,0.0111f,0.8454f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.0111f,-0.8454f,0.5339f,0.007f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.3382f,0.8742f,0.0999f],left_rotation:[-0.0007f,-0.1851f,0.9822f,0.0321f]}}
particle minecraft:campfire_cosy_smoke -38.16 65.12 -16.64 -0.012 0.021 0.051 1 0 force
particle minecraft:cloud -38.16 65.32 -16.64 0.35 0.18 0.35 0.02 2 force
particle minecraft:cloud -36.6 65.32 -17.23 0.35 0.18 0.35 0.02 2 force
scoreboard players set #gx drift -29248
scoreboard players set #gdx drift -720
scoreboard players set #gz drift -11804
scoreboard players set #gdz drift -275
scoreboard players set #gr drift 15166
scoreboard players set #gdr drift 149
function drift:glide/move/onyx
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0.0024f,-0.0001f,-0.0223f,0.9997f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.5632f,0.2634f,-0.1243f,0.7733f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.2062f,-0.7906f,-0.5386f,0.2057f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.5339f,-0.007f,0.0111f,0.8454f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.0111f,-0.8454f,0.5339f,0.007f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.3314f,0.8744f,0.2542f],left_rotation:[0.1656f,-0.0995f,0.4673f,0.8627f]}}
particle minecraft:campfire_cosy_smoke -29.33 65.12 -10.15 0.007 0.022 0.041 1 0 force
particle minecraft:cloud -29.33 65.32 -10.15 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud -27.82 65.32 -10.96 0.35 0.18 0.35 0.02 3 force
