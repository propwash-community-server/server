scoreboard players set #gx drift -67388
scoreboard players set #gdx drift 762
scoreboard players set #gz drift 55546
scoreboard players set #gdz drift 482
scoreboard players set #gr drift -8598
scoreboard players set #gdr drift -82
function drift:glide/move/kaze
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0059f,-0.0001f,0.0214f,0.9998f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.8593f,-0.0498f,0.2038f,0.4664f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.1559f,0.4476f,0.8693f,0.1404f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.8847f,0.0116f,0.0061f,0.4661f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.0061f,0.4661f,0.8847f,0.0116f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4066f,0.8446f,0.0999f],left_rotation:[0.0466f,0.1791f,-0.9396f,0.2878f]}}
particle minecraft:campfire_cosy_smoke -68.64 65.12 54.62 -0.042 0.022 -0.06 1 0 force
particle minecraft:cloud -68.64 65.32 54.62 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud -68.75 65.32 56.29 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx drift -77022
scoreboard players set #gdx drift 595
scoreboard players set #gz drift 47817
scoreboard players set #gdz drift 756
scoreboard players set #gr drift -7367
scoreboard players set #gdr drift -149
function drift:glide/move/onyx
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0.011f,0.0002f,0.022f,0.9997f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.884f,-0.0549f,0.264f,0.3819f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.2253f,0.3562f,0.8946f,0.1481f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.8847f,0.0116f,0.0061f,0.4661f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.0061f,0.4661f,0.8847f,0.0116f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4073f,0.8371f,0.2689f],left_rotation:[0.1479f,0.137f,-0.6333f,0.7472f]}}
particle minecraft:campfire_cosy_smoke -78.14 65.12 46.6 -0.012 0.022 -0.08 1 0 force
particle minecraft:cloud -78.14 65.32 46.6 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud -78.62 65.32 48.24 0.35 0.18 0.35 0.02 3 force
