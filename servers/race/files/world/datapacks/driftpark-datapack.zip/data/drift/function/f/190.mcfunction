scoreboard players set #gx drift 70675
scoreboard players set #gdx drift -883
scoreboard players set #gz drift -35810
scoreboard players set #gdz drift -715
scoreboard players set #gr drift 10538
scoreboard players set #gdr drift -86
function drift:glide/move/kaze
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0058f,-0.0001f,0.0222f,0.9997f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.0711f,-0.1722f,0.0658f,0.9803f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.0369f,0.9788f,0.0896f,0.1806f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.0638f,0.0008f,0.0131f,0.9979f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.0131f,0.9979f,0.0638f,0.0008f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4079f,0.8439f,0.1f],left_rotation:[0.002f,0.1851f,-0.9812f,0.0544f]}}
particle minecraft:cloud 71.72 65.32 -34.66 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke 71.72 65.42 -34.66 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke 72.16 65.12 -36.27 0.05 0.02 0.004 1 0 force
particle minecraft:cloud 72.16 65.32 -36.27 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke 72.16 65.42 -36.27 0.45 0.2 0.45 0.008 1 force
scoreboard players set #gx drift 81544
scoreboard players set #gdx drift -602
scoreboard players set #gz drift -25377
scoreboard players set #gdz drift -855
scoreboard players set #gr drift 11561
scoreboard players set #gdr drift -105
function drift:glide/move/onyx
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0001f,0f,0.0223f,0.9998f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.8561f,-0.0566f,0.2163f,0.4659f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.1685f,0.4457f,0.8668f,0.1469f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.0638f,0.0008f,0.0131f,0.9979f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.0131f,0.9979f,0.0638f,0.0008f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4079f,0.8427f,0.2498f],left_rotation:[0.0715f,0.1768f,-0.8928f,0.4081f]}}
particle minecraft:cloud 82.45 65.32 -23.99 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 82.45 65.42 -23.99 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke 83.19 65.12 -25.54 0.043 0.022 0.002 1 0 force
particle minecraft:cloud 83.19 65.32 -25.54 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 83.19 65.42 -25.54 0.45 0.2 0.45 0.008 1 force
