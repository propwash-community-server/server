scoreboard players set #gx drift -88958
scoreboard players set #gdx drift 458
scoreboard players set #gz drift 22176
scoreboard players set #gdz drift 1216
scoreboard players set #gr drift -2830
scoreboard players set #gdr drift -85
function drift:glide/move/kaze
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.977f,-0.0633f,-0.0487f,0.1975f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.0697f,-0.2038f,0.9758f,0.039f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.9914f,-0.013f,0.0017f,0.1303f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.0017f,-0.1303f,0.9914f,0.013f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.3894f,0.8514f,0.11f],left_rotation:[0.1643f,-0.097f,0.5182f,0.8337f]}}
scoreboard players set #gx drift -94471
scoreboard players set #gdx drift 315
scoreboard players set #gz drift 5359
scoreboard players set #gdz drift 1162
scoreboard players set #gr drift -2442
scoreboard players set #gdr drift 9
function drift:glide/move/onyx
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0059f,-0.0001f,0.01f,0.9999f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.9958f,-0.0535f,-0.0726f,0.0142f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.0745f,-0.0219f,0.9957f,0.0508f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.9914f,-0.013f,0.0017f,0.1303f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.0017f,-0.1303f,0.9914f,0.013f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.3872f,0.8553f,0.2399f],left_rotation:[0.1469f,-0.1126f,0.6133f,0.7679f]}}
particle minecraft:campfire_cosy_smoke -94.28 65.12 3.72 0.027 0.013 -0.084 1 0 force
