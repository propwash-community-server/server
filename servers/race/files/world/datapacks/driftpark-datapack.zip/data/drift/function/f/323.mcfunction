scoreboard players set #gx drift -26081
scoreboard players set #gdx drift -725
scoreboard players set #gz drift -11786
scoreboard players set #gdz drift -186
scoreboard players set #gr drift 14156
scoreboard players set #gdr drift 147
function drift:glide/move/kaze
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0003f,0f,-0.0223f,0.9998f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.7169f,0.135f,0.2317f,0.6435f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.1653f,-0.6227f,0.7351f,0.2111f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.8679f,0.0114f,0.0065f,0.4966f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.0065f,0.4966f,0.8679f,0.0114f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.3314f,0.8757f,0.1095f],left_rotation:[0.1378f,-0.1315f,0.6454f,0.7397f]}}
particle minecraft:campfire_cosy_smoke -25.92 65.12 -10.24 0.003 0.022 0.029 1 0 force
particle minecraft:cloud -25.92 65.32 -10.24 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud -24.61 65.32 -11.28 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx drift -16109
scoreboard players set #gdx drift -668
scoreboard players set #gz drift -10543
scoreboard players set #gdz drift 114
scoreboard players set #gr drift 12527
scoreboard players set #gdr drift 136
function drift:glide/move/onyx
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.1395f,0.2926f,0.0989f,0.9408f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.0006f,-0.9356f,0.171f,0.3089f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.8679f,0.0114f,0.0065f,0.4966f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.0065f,0.4966f,0.8679f,0.0114f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.3313f,0.8782f,0.2408f],left_rotation:[0.1729f,-0.0675f,0.3162f,0.9304f]}}
particle minecraft:campfire_cosy_smoke -15.45 65.12 -9.03 0.014 0.022 0.022 1 0 force
particle minecraft:cloud -15.45 65.32 -9.03 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud -14.46 65.32 -10.42 0.35 0.18 0.35 0.02 3 force
