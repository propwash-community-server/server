scoreboard players set #gx drift 15569
scoreboard players set #gdx drift 1298
scoreboard players set #gz drift 63285
scoreboard players set #gdz drift -71
scoreboard players set #gr drift -9827
scoreboard players set #gdr drift -101
function drift:glide/move/kaze
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0f,0f,0.0075f,1f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.3811f,-0.061f,0.0315f,0.922f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.0653f,0.9237f,-0.3768f,0.0213f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.3847f,-0.005f,0.0121f,0.923f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.0121f,-0.923f,0.3847f,0.005f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.3828f,0.8544f,0.11f],left_rotation:[0.1762f,-0.0731f,0.3897f,0.901f]}}
scoreboard players set #gx drift -2619
scoreboard players set #gdx drift 1300
scoreboard players set #gz drift 63801
scoreboard players set #gdz drift -12
scoreboard players set #gr drift -9075
scoreboard players set #gdr drift -10
function drift:glide/move/onyx
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0f,0f,-0.0003f,1f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.0991f,-0.003f,0.0523f,0.9937f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.0519f,-0.9937f,0.0994f,0.0074f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.3847f,-0.005f,0.0121f,0.923f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.0121f,-0.923f,0.3847f,0.005f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.3695f,0.8602f,0.25f],left_rotation:[0.1908f,0.0037f,-0.0198f,0.9814f]}}
