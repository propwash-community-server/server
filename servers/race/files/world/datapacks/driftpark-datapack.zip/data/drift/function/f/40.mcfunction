scoreboard players set #gx drift -3918
scoreboard players set #gdx drift 1299
scoreboard players set #gz drift 63849
scoreboard players set #gdz drift -27
scoreboard players set #gr drift -9076
scoreboard players set #gdr drift -5
function drift:glide/move/kaze
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0f,0f,-0.0008f,1f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.9074f,-0.0466f,0.024f,0.417f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.0197f,-0.4167f,0.9075f,0.0486f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.9102f,-0.0119f,0.0054f,0.4139f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.0054f,-0.4139f,0.9102f,0.0119f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.3686f,0.8606f,0.11f],left_rotation:[0.1908f,0.004f,-0.022f,0.9814f]}}
scoreboard players set #gx drift -22101
scoreboard players set #gdx drift 1299
scoreboard players set #gz drift 64530
scoreboard players set #gdz drift -61
scoreboard players set #gr drift -9134
scoreboard players set #gdr drift 15
function drift:glide/move/onyx
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0f,0f,0.0041f,1f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.7998f,-0.0376f,0.0371f,0.5979f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.0256f,-0.5973f,0.8002f,0.0462f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.9102f,-0.0119f,0.0054f,0.4139f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.0054f,-0.4139f,0.9102f,0.0119f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.3771f,0.8569f,0.25f],left_rotation:[0.1904f,0.0132f,-0.0596f,0.9798f]}}
