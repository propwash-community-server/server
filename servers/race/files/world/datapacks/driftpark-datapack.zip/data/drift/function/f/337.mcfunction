scoreboard players set #gx drift -35411
scoreboard players set #gdx drift -616
scoreboard players set #gz drift -16148
scoreboard players set #gdz drift -469
scoreboard players set #gr drift 15803
scoreboard players set #gdr drift 58
function drift:glide/move/kaze
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0059f,0.0001f,-0.0211f,0.9998f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.5524f,0.1428f,0.1629f,0.8049f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.0792f,-0.7922f,0.5705f,0.2016f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.4738f,0.0062f,0.0115f,0.8806f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.0115f,0.8806f,0.4738f,0.0062f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.3333f,0.8761f,0.0999f],left_rotation:[0.0582f,-0.1757f,0.9191f,0.348f]}}
particle minecraft:campfire_cosy_smoke -35.7 65.12 -14.62 -0.005 0.022 0.042 1 0 force
particle minecraft:cloud -35.7 65.32 -14.62 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -35.7 65.42 -14.62 0.45 0.2 0.45 0.008 1 force
particle minecraft:cloud -34.15 65.32 -15.25 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx drift -26291
scoreboard players set #gdx drift -748
scoreboard players set #gz drift -10911
scoreboard players set #gdz drift -192
scoreboard players set #gr drift 14584
scoreboard players set #gdr drift 147
function drift:glide/move/onyx
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0003f,0f,-0.0223f,0.9998f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.6637f,0.1723f,0.2429f,0.6862f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.1721f,-0.6644f,0.6855f,0.243f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.4738f,0.0062f,0.0115f,0.8806f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.0115f,0.8806f,0.4738f,0.0062f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.3314f,0.8758f,0.2495f],left_rotation:[0.1691f,-0.0877f,0.4129f,0.8906f]}}
particle minecraft:campfire_cosy_smoke -26.2 65.12 -9.26 0.011 0.022 0.029 1 0 force
particle minecraft:cloud -26.2 65.32 -9.26 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud -24.79 65.32 -10.22 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -24.79 65.42 -10.22 0.45 0.2 0.45 0.008 1 force
