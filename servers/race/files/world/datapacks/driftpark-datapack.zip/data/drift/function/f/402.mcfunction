scoreboard players set #gx drift -78268
scoreboard players set #gdx drift -661
scoreboard players set #gz drift -45878
scoreboard players set #gdz drift 117
scoreboard players set #gr drift 3917
scoreboard players set #gdr drift -176
function drift:glide/move/kaze
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.7338f,-0.1393f,0.2509f,0.6157f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.1876f,0.5927f,0.7525f,0.2172f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.563f,0.0074f,0.0108f,0.8263f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.0108f,0.8263f,0.563f,0.0074f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4078f,0.8413f,0.1207f],left_rotation:[0.1645f,0.1082f,-0.5018f,0.8423f]}}
particle minecraft:cloud -76.79 65.32 -46.37 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -78.09 65.12 -47.42 0.01 0.022 -0.036 1 0 force
particle minecraft:cloud -78.09 65.32 -47.42 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx drift -67808
scoreboard players set #gdx drift -772
scoreboard players set #gz drift -46221
scoreboard players set #gdz drift -182
scoreboard players set #gr drift 6208
scoreboard players set #gdr drift -184
function drift:glide/move/onyx
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0002f,0f,0.0223f,0.9998f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.4668f,-0.2313f,0.1927f,0.8315f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.1064f,0.8158f,0.4937f,0.2817f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.563f,0.0074f,0.0108f,0.8263f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.0108f,0.8263f,0.563f,0.0074f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4079f,0.8428f,0.2497f],left_rotation:[0.1719f,0.0824f,-0.3844f,0.9033f]}}
particle minecraft:cloud -66.16 65.32 -46.13 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -66.96 65.12 -47.64 0.025 0.022 -0.032 1 0 force
particle minecraft:cloud -66.96 65.32 -47.64 0.35 0.18 0.35 0.02 3 force
