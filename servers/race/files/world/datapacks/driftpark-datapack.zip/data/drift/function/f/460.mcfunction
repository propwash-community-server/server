scoreboard players set #gx drift -96714
scoreboard players set #gdx drift 97
scoreboard players set #gz drift -9143
scoreboard players set #gdz drift 1061
scoreboard players set #gr drift -2600
scoreboard players set #gdr drift -7
function drift:glide/move/kaze
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0058f,-0.0001f,0.0176f,0.9998f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.8529f,-0.0297f,0.156f,0.4973f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.1046f,0.4837f,0.8607f,0.1195f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.8312f,0.0109f,0.0073f,0.5558f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.0073f,0.5558f,0.8312f,0.0109f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4f,0.8477f,0.1f],left_rotation:[0.0421f,-0.1802f,0.9642f,0.1899f]}}
particle minecraft:cloud -96.54 65.32 -10.69 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -98.04 65.12 -9.95 -0.049 0.018 -0.04 1 0 force
particle minecraft:cloud -98.04 65.32 -9.95 0.35 0.18 0.35 0.02 2 force
scoreboard players set #gx drift -97086
scoreboard players set #gdx drift -149
scoreboard players set #gz drift -23060
scoreboard players set #gdz drift 923
scoreboard players set #gr drift -1972
scoreboard players set #gdr drift -86
function drift:glide/move/onyx
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0058f,-0.0001f,0.018f,0.9998f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.6377f,-0.1261f,0.1797f,0.7383f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.1031f,0.7235f,0.6545f,0.1938f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.8312f,0.0109f,0.0073f,0.5558f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.0073f,0.5558f,0.8312f,0.0109f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4008f,0.849f,0.2399f],left_rotation:[0.0634f,0.1739f,-0.9105f,0.3698f]}}
particle minecraft:cloud -96.76 65.32 -24.68 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -98.37 65.12 -24.1 -0.03 0.022 -0.042 1 0 force
particle minecraft:cloud -98.37 65.32 -24.1 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -98.37 65.42 -24.1 0.45 0.2 0.45 0.008 1 force
