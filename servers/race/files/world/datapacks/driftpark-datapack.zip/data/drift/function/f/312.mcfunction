scoreboard players set #gx drift -18238
scoreboard players set #gdx drift -678
scoreboard players set #gz drift -11159
scoreboard players set #gdz drift 49
scoreboard players set #gr drift 12529
scoreboard players set #gdr drift 121
function drift:glide/move/kaze
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0051f,0.0001f,-0.0223f,0.9997f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.4294f,0.2171f,0.1691f,0.8602f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.0796f,-0.8471f,0.4546f,0.2634f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.6852f,-0.009f,0.0095f,0.7283f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.0095f,-0.7283f,0.6852f,0.009f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.3313f,0.8767f,0.1012f],left_rotation:[0.1427f,-0.119f,0.5949f,0.782f]}}
particle minecraft:cloud -17.65 65.32 -9.72 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -16.69 65.12 -11.08 0.064 0.022 -0.04 1 0 force
particle minecraft:cloud -16.69 65.32 -11.08 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx drift -9303
scoreboard players set #gdx drift -601
scoreboard players set #gz drift -13197
scoreboard players set #gdz drift 357
scoreboard players set #gr drift 10601
scoreboard players set #gdr drift 161
function drift:glide/move/onyx
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0.0067f,-0.0001f,-0.0223f,0.9997f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.9241f,0.0132f,0.3271f,0.1971f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.3082f,-0.1638f,0.9306f,0.1104f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.6852f,-0.009f,0.0095f,0.7283f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.0095f,-0.7283f,0.6852f,0.009f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.3315f,0.8722f,0.2614f],left_rotation:[0.1936f,-0.0381f,0.1461f,0.9694f]}}
particle minecraft:cloud -8.18 65.32 -11.99 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -8.18 65.42 -11.99 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke -7.71 65.12 -13.63 0.032 0.022 -0.047 1 0 force
particle minecraft:cloud -7.71 65.32 -13.63 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -7.71 65.42 -13.63 0.45 0.2 0.45 0.008 1 force
