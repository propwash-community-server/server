scoreboard players set #gx drift 24610
scoreboard players set #gdx drift -851
scoreboard players set #gz drift -48730
scoreboard players set #gdz drift 245
scoreboard players set #gr drift 4187
scoreboard players set #gdr drift -182
function drift:glide/move/kaze
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0.0042f,0.0001f,0.0223f,0.9997f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.9461f,-0.1049f,-0.2204f,0.213f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.244f,0.2374f,-0.9403f,0.006f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.9775f,-0.0128f,0.0028f,0.2104f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.0028f,-0.2104f,0.9775f,0.0128f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4079f,0.8417f,0.1173f],left_rotation:[0.1067f,0.1632f,-0.7961f,0.5729f]}}
particle minecraft:campfire_cosy_smoke 26.11 65.12 -49.15 0.075 0.022 0.015 1 0 force
particle minecraft:cloud 26.11 65.32 -49.15 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud 24.86 65.32 -50.26 0.35 0.18 0.35 0.02 3 force
particle minecraft:flame 25.83 65.22 -50.84 0.05 0.04 0.05 0.02 6 force
particle minecraft:large_smoke 25.83 65.22 -50.84 0.05 0.04 0.05 0.01 2 force
playsound driftpark:lap.kaze.04.097 neutral @a 28.12 65.5 -49.52 12 1
playsound driftpark:lap.kaze.04.098 neutral @a 21.29 65.5 -47.64 12 1
playsound driftpark:lap.kaze.04.099 neutral @a 15.5 65.5 -44.73 12 1
playsound driftpark:lap.kaze.04.100 neutral @a 11.03 65.5 -41.04 12 1
playsound driftpark:lap.kaze.04.101 neutral @a 7.29 65.5 -36.22 12 1
playsound driftpark:lap.kaze.04.102 neutral @a 3.84 65.5 -30.4 12 1
playsound driftpark:lap.kaze.04.103 neutral @a 0.01 65.5 -24.02 12 1
playsound driftpark:lap.kaze.04.104 neutral @a -4.54 65.5 -18.27 12 1
playsound driftpark:lap.kaze.04.105 neutral @a -9.2 65.5 -14.33 12 1
playsound driftpark:lap.kaze.04.106 neutral @a -13.84 65.5 -12.05 12 1
scoreboard players set #gx drift 37282
scoreboard players set #gdx drift -951
scoreboard players set #gz drift -50933
scoreboard players set #gdz drift -45
scoreboard players set #gr drift 5937
scoreboard players set #gdr drift -138
function drift:glide/move/onyx
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0.0039f,0.0001f,0.0223f,0.9997f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.0962f,-0.2498f,0.0293f,0.9631f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.0717f,0.9653f,-0.0705f,0.2411f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.9775f,-0.0128f,0.0028f,0.2104f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.0028f,-0.2104f,0.9775f,0.0128f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4078f,0.8407f,0.2566f],left_rotation:[0.1179f,0.1549f,-0.7533f,0.6282f]}}
particle minecraft:campfire_cosy_smoke 38.93 65.12 -50.92 0.078 0.022 0.032 1 0 force
particle minecraft:cloud 38.93 65.32 -50.92 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud 38.06 65.32 -52.39 0.35 0.18 0.35 0.02 3 force
