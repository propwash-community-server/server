scoreboard players set #gx drift -19
scoreboard players set #gdx drift 1299
scoreboard players set #gz drift 63770
scoreboard players set #gdz drift -26
scoreboard players set #gr drift -9103
scoreboard players set #gdr drift -20
function drift:glide/move/kaze
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0f,0f,0.0008f,1f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.3534f,-0.0184f,0.049f,0.934f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.0489f,-0.934f,0.3535f,0.0186f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.3577f,-0.0047f,0.0122f,0.9337f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.0122f,-0.9337f,0.3577f,0.0047f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.3714f,0.8594f,0.11f],left_rotation:[0.1908f,0.0003f,0f,0.9816f]}}
scoreboard players set #gx drift -18206
scoreboard players set #gdx drift 1298
scoreboard players set #gz drift 64338
scoreboard players set #gdz drift -69
scoreboard players set #gr drift -9102
scoreboard players set #gdr drift 4
function drift:glide/move/onyx
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0f,0f,0.0013f,1f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.1338f,0.0025f,0.0531f,0.9896f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.0506f,-0.9894f,0.1348f,0.0165f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.3577f,-0.0047f,0.0122f,0.9337f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.0122f,-0.9337f,0.3577f,0.0047f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.3722f,0.8591f,0.25f],left_rotation:[0.1901f,0.0167f,-0.0835f,0.9781f]}}
