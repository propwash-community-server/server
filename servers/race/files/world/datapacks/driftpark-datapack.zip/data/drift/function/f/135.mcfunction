scoreboard players set #gx drift 88871
scoreboard players set #gdx drift 216
scoreboard players set #gz drift 16794
scoreboard players set #gdz drift -1036
scoreboard players set #gr drift 16628
scoreboard players set #gdr drift -105
function drift:glide/move/kaze
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0011f,0f,0.0223f,0.9998f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.4363f,-0.1468f,0.1325f,0.8778f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.041f,0.8687f,0.4542f,0.1935f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.4428f,0.0058f,0.0117f,0.8965f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.0117f,0.8965f,0.4428f,0.0058f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4079f,0.8429f,0.1081f],left_rotation:[0.0262f,0.1879f,-0.9654f,0.1788f]}}
particle minecraft:campfire_cosy_smoke 88.37 65.12 18.27 -0.052 0.021 0.063 1 0 force
particle minecraft:cloud 88.37 65.32 18.27 0.35 0.18 0.35 0.02 2 force
particle minecraft:cloud 89.99 65.32 17.87 0.35 0.18 0.35 0.02 2 force
scoreboard players set #gx drift 84605
scoreboard players set #gdx drift 488
scoreboard players set #gz drift 30771
scoreboard players set #gdz drift -910
scoreboard players set #gr drift 17836
scoreboard players set #gdr drift -115
function drift:glide/move/onyx
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0f,0f,0.0223f,0.9998f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.8972f,-0.0366f,0.2249f,0.3784f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.1864f,0.3568f,0.906f,0.1311f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.4428f,0.0058f,0.0117f,0.8965f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.0117f,0.8965f,0.4428f,0.0058f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4079f,0.8427f,0.2501f],left_rotation:[0.0788f,0.1738f,-0.8752f,0.4445f]}}
particle minecraft:campfire_cosy_smoke 83.79 65.12 32.21 -0.066 0.022 0.042 1 0 force
particle minecraft:cloud 83.79 65.32 32.21 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud 85.5 65.32 32.16 0.35 0.18 0.35 0.02 3 force
