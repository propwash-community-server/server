kill 425483f9-2934-53dd-805b-82336df4bdbc
kill 77d4edec-4f89-5806-8a73-69da291cf64a
kill a18c987f-26df-590a-b51c-8f6379e10218
kill 8bd36e4e-1a75-51ba-b224-63055ff644c2
kill 7b07c259-0b81-5b46-b286-5b101f183bf9
kill 04fc5281-333c-5c0d-ba69-0b625cbc7206
kill 6ed9ae07-2229-5b6f-8ff8-189708e0cf64
kill f74f363c-8714-5fe5-bb64-beafe6b6ac28
kill 97428e5f-5a51-575c-8305-607c4b0f68cb
kill 186c432f-da2b-5bec-ba8a-9d97f056504e
kill b7fef3cd-3066-54f8-9318-2747261e9dd9
kill 0d17ad00-82d8-5739-af58-9e93f268e98c
summon minecraft:item_display -52 65 62 {UUID:[I;1112835065,691295197,-2141486541,1844755900],Tags:["drift","drift.car","drift.kaze","drift.kaze.body"],item:{id:"minecraft:paper",count:1,components:{"minecraft:item_model":"driftpark:car_kaze"}},item_display:"none",teleport_duration:8,interpolation_duration:1,shadow_radius:1.9f,shadow_strength:0.9f,view_range:4.0f,width:5.8f,height:2.0f,transformation:{translation:[0f,0f,0f],left_rotation:[-0.0058f,-0.0001f,0.0182f,0.9998f],scale:[4f,4f,4f],right_rotation:[0f,0f,0f,1f]}}
tp 425483f9-2934-53dd-805b-82336df4bdbc -52 65 62 -98.12 0
summon minecraft:item_display -52 65 62 {UUID:[I;2010443244,1334401030,-1972147750,689763914],Tags:["drift","drift.car","drift.kaze","drift.kaze.fl"],item:{id:"minecraft:paper",count:1,components:{"minecraft:item_model":"driftpark:wheel_kaze_front"}},item_display:"none",teleport_duration:8,interpolation_duration:1,view_range:4.0f,width:5.8f,height:1.0f,transformation:{translation:[0.84f,0.325f,1.26f],left_rotation:[-0.0087f,-0.1656f,0.0516f,0.9848f],scale:[1f,1f,1f],right_rotation:[0f,0f,0f,1f]}}
tp 77d4edec-4f89-5806-8a73-69da291cf64a -52 65 62 -98.12 0
summon minecraft:item_display -52 65 62 {UUID:[I;-1584621441,652171530,-1256419485,2044789272],Tags:["drift","drift.car","drift.kaze","drift.kaze.fr"],item:{id:"minecraft:paper",count:1,components:{"minecraft:item_model":"driftpark:wheel_kaze_front"}},item_display:"none",teleport_duration:8,interpolation_duration:1,view_range:4.0f,width:5.8f,height:1.0f,transformation:{translation:[-0.84f,0.325f,1.26f],left_rotation:[0.0516f,0.9848f,0.0087f,0.1656f],scale:[1f,1f,1f],right_rotation:[0f,0f,0f,1f]}}
tp a18c987f-26df-590a-b51c-8f6379e10218 -52 65 62 -98.12 0
summon minecraft:item_display -52 65 62 {UUID:[I;-1949077938,443896250,-1306238203,1609974978],Tags:["drift","drift.car","drift.kaze","drift.kaze.rl"],item:{id:"minecraft:paper",count:1,components:{"minecraft:item_model":"driftpark:wheel_kaze_rear"}},item_display:"none",teleport_duration:8,interpolation_duration:1,view_range:4.0f,width:5.8f,height:1.0f,transformation:{translation:[0.835f,0.325f,-1.26f],left_rotation:[0f,0f,0.0131f,0.9999f],scale:[1f,1f,1f],right_rotation:[0f,0f,0f,1f]}}
tp 8bd36e4e-1a75-51ba-b224-63055ff644c2 -52 65 62 -98.12 0
summon minecraft:item_display -52 65 62 {UUID:[I;2064106073,193026886,-1299817712,521681913],Tags:["drift","drift.car","drift.kaze","drift.kaze.rr"],item:{id:"minecraft:paper",count:1,components:{"minecraft:item_model":"driftpark:wheel_kaze_rear"}},item_display:"none",teleport_duration:8,interpolation_duration:1,view_range:4.0f,width:5.8f,height:1.0f,transformation:{translation:[-0.835f,0.325f,-1.26f],left_rotation:[0.0131f,0.9999f,0f,0f],scale:[1f,1f,1f],right_rotation:[0f,0f,0f,1f]}}
tp 7b07c259-0b81-5b46-b286-5b101f183bf9 -52 65 62 -98.12 0
summon minecraft:item_display -52 65 62 {UUID:[I;83645057,859593741,-1167520926,1555853830],Tags:["drift","drift.car","drift.kaze","drift.kaze.steer"],item:{id:"minecraft:paper",count:1,components:{"minecraft:item_model":"driftpark:steer_kaze"}},item_display:"none",teleport_duration:8,interpolation_duration:1,view_range:0.75f,width:2.4f,height:1.4f,transformation:{translation:[-0.401f,0.8472f,0.1f],left_rotation:[0.0165f,-0.1843f,0.9813f,0.0521f],scale:[1f,1f,1f],right_rotation:[0f,0f,0f,1f]}}
tp 04fc5281-333c-5c0d-ba69-0b625cbc7206 -52 65 62 -98.12 0
summon minecraft:item_display -65.483 65 57.742 {UUID:[I;1859759623,573135727,-1879566185,148950884],Tags:["drift","drift.car","drift.onyx","drift.onyx.body"],item:{id:"minecraft:paper",count:1,components:{"minecraft:item_model":"driftpark:car_onyx"}},item_display:"none",teleport_duration:8,interpolation_duration:1,shadow_radius:1.9f,shadow_strength:0.9f,view_range:4.0f,width:5.8f,height:2.0f,transformation:{translation:[0f,0f,0f],left_rotation:[-0.0059f,-0.0001f,0.021f,0.9998f],scale:[4f,4f,4f],right_rotation:[0f,0f,0f,1f]}}
tp 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 -65.483 65 57.742 -91.98 0
summon minecraft:item_display -65.483 65 57.742 {UUID:[I;-145803716,-2028707867,-1151025489,-424235992],Tags:["drift","drift.car","drift.onyx","drift.onyx.fl"],item:{id:"minecraft:paper",count:1,components:{"minecraft:item_model":"driftpark:wheel_onyx_front"}},item_display:"none",teleport_duration:8,interpolation_duration:1,view_range:4.0f,width:5.8f,height:1.0f,transformation:{translation:[0.865f,0.33f,1.365f],left_rotation:[-0.0118f,-0.2248f,0.051f,0.973f],scale:[1f,1f,1f],right_rotation:[0f,0f,0f,1f]}}
tp f74f363c-8714-5fe5-bb64-beafe6b6ac28 -65.483 65 57.742 -91.98 0
summon minecraft:item_display -65.483 65 57.742 {UUID:[I;-1757245857,1515280220,-2096799620,1259301067],Tags:["drift","drift.car","drift.onyx","drift.onyx.fr"],item:{id:"minecraft:paper",count:1,components:{"minecraft:item_model":"driftpark:wheel_onyx_front"}},item_display:"none",teleport_duration:8,interpolation_duration:1,view_range:4.0f,width:5.8f,height:1.0f,transformation:{translation:[-0.865f,0.33f,1.365f],left_rotation:[0.051f,0.973f,0.0118f,0.2248f],scale:[1f,1f,1f],right_rotation:[0f,0f,0f,1f]}}
tp 97428e5f-5a51-575c-8305-607c4b0f68cb -65.483 65 57.742 -91.98 0
summon minecraft:item_display -65.483 65 57.742 {UUID:[I;409748271,-634692628,-1165320809,-262778802],Tags:["drift","drift.car","drift.onyx","drift.onyx.rl"],item:{id:"minecraft:paper",count:1,components:{"minecraft:item_model":"driftpark:wheel_onyx_rear"}},item_display:"none",teleport_duration:8,interpolation_duration:1,view_range:4.0f,width:5.8f,height:1.0f,transformation:{translation:[0.855f,0.33f,-1.365f],left_rotation:[0f,0f,0.0131f,0.9999f],scale:[1f,1f,1f],right_rotation:[0f,0f,0f,1f]}}
tp 186c432f-da2b-5bec-ba8a-9d97f056504e -65.483 65 57.742 -91.98 0
summon minecraft:item_display -65.483 65 57.742 {UUID:[I;-1208028211,812012792,-1827133625,639540697],Tags:["drift","drift.car","drift.onyx","drift.onyx.rr"],item:{id:"minecraft:paper",count:1,components:{"minecraft:item_model":"driftpark:wheel_onyx_rear"}},item_display:"none",teleport_duration:8,interpolation_duration:1,view_range:4.0f,width:5.8f,height:1.0f,transformation:{translation:[-0.855f,0.33f,-1.365f],left_rotation:[0.0131f,0.9999f,0f,0f],scale:[1f,1f,1f],right_rotation:[0f,0f,0f,1f]}}
tp b7fef3cd-3066-54f8-9318-2747261e9dd9 -65.483 65 57.742 -91.98 0
summon minecraft:item_display -65.483 65 57.742 {UUID:[I;219655424,-2099751111,-1353146733,-228005492],Tags:["drift","drift.car","drift.onyx","drift.onyx.steer"],item:{id:"minecraft:paper",count:1,components:{"minecraft:item_model":"driftpark:steer_onyx"}},item_display:"none",teleport_duration:8,interpolation_duration:1,view_range:0.75f,width:2.4f,height:1.4f,transformation:{translation:[-0.4059f,0.8466f,0.2399f],left_rotation:[0.0808f,0.1665f,-0.8654f,0.4657f],scale:[1f,1f,1f],right_rotation:[0f,0f,0f,1f]}}
tp 0d17ad00-82d8-5739-af58-9e93f268e98c -65.483 65 57.742 -91.98 0
scoreboard players set #t drift 0
function drift:glide/sync
