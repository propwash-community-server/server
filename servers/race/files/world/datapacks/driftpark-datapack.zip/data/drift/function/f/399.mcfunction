scoreboard players set #gx drift -76203
scoreboard players set #gdx drift -701
scoreboard players set #gz drift -46112
scoreboard players set #gdz drift 58
scoreboard players set #gr drift 4509
scoreboard players set #gdr drift -195
function drift:glide/move/kaze
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0.0059f,0.0001f,0.0223f,0.9997f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.7174f,-0.1466f,0.2482f,0.6342f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.1829f,0.6116f,0.7368f,0.2228f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.179f,-0.0023f,0.0129f,0.9838f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.0129f,-0.9838f,0.179f,0.0023f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4078f,0.8413f,0.1201f],left_rotation:[0.1655f,0.1061f,-0.4918f,0.8482f]}}
particle minecraft:campfire_cosy_smoke -74.69 65.12 -46.45 0.066 0.022 0.023 1 0 force
particle minecraft:cloud -74.69 65.32 -46.45 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -74.69 65.42 -46.45 0.45 0.2 0.45 0.008 1 force
particle minecraft:cloud -75.86 65.32 -47.63 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx drift -65546
scoreboard players set #gdx drift -743
scoreboard players set #gz drift -45555
scoreboard players set #gdz drift -242
scoreboard players set #gr drift 6680
scoreboard players set #gdr drift -145
function drift:glide/move/onyx
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0025f,-0.0001f,0.0223f,0.9997f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.1635f,-0.2789f,0.104f,0.9406f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.0057f,0.9348f,0.1937f,0.2976f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.179f,-0.0023f,0.0129f,0.9838f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.0129f,-0.9838f,0.179f,0.0023f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.408f,0.8439f,0.2456f],left_rotation:[0.167f,0.087f,-0.4144f,0.8904f]}}
particle minecraft:campfire_cosy_smoke -63.91 65.12 -45.33 0.043 0.022 0.049 1 0 force
particle minecraft:cloud -63.91 65.32 -45.33 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -63.91 65.42 -45.33 0.45 0.2 0.45 0.008 1 force
particle minecraft:cloud -64.58 65.32 -46.9 0.35 0.18 0.35 0.02 3 force
