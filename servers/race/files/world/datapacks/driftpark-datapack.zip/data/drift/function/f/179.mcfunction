scoreboard players set #gx drift 78977
scoreboard players set #gdx drift -648
scoreboard players set #gz drift -27352
scoreboard players set #gdz drift -810
scoreboard players set #gr drift 11595
scoreboard players set #gdr drift -99
function drift:glide/move/kaze
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0038f,-0.0001f,0.0223f,0.9997f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.9675f,0.0218f,0.1941f,0.1606f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.1783f,0.141f,0.9705f,0.0798f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.9853f,0.0129f,0.0022f,0.1705f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.0022f,0.1705f,0.9853f,0.0129f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4079f,0.8435f,0.1034f],left_rotation:[0.0216f,0.1858f,-0.9698f,0.1566f]}}
particle minecraft:campfire_cosy_smoke 79.79 65.12 -26.03 0.011 0.021 0.078 1 0 force
particle minecraft:cloud 79.79 65.32 -26.03 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke 79.79 65.42 -26.03 0.45 0.2 0.45 0.008 1 force
particle minecraft:cloud 80.52 65.32 -27.53 0.35 0.18 0.35 0.02 2 force
scoreboard players set #gx drift 87012
scoreboard players set #gdx drift -409
scoreboard players set #gz drift -14995
scoreboard players set #gdz drift -1004
scoreboard players set #gr drift 12849
scoreboard players set #gdr drift -125
function drift:glide/move/onyx
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0.0014f,0f,0.0223f,0.9998f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.6939f,-0.1923f,-0.1187f,0.6837f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.1912f,0.7f,-0.6775f,0.1204f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.9853f,0.0129f,0.0022f,0.1705f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.0022f,0.1705f,0.9853f,0.0129f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4079f,0.842f,0.2523f],left_rotation:[0.0761f,0.1764f,-0.8829f,0.4284f]}}
particle minecraft:campfire_cosy_smoke 87.59 65.12 -13.44 -0.003 0.022 0.077 1 0 force
particle minecraft:cloud 87.59 65.32 -13.44 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud 88.65 65.32 -14.78 0.35 0.18 0.35 0.02 3 force
