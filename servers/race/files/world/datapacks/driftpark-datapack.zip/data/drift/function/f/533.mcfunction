scoreboard players set #gx drift -60761
scoreboard players set #gdx drift 909
scoreboard players set #gz drift 59058
scoreboard players set #gdz drift 381
scoreboard players set #gr drift -9207
scoreboard players set #gdr drift -74
function drift:glide/move/kaze
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0059f,-0.0001f,0.0196f,0.9998f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.846f,-0.1382f,-0.1296f,0.4985f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.1827f,0.5148f,-0.8361f,0.05f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.8561f,-0.0112f,0.0068f,0.5166f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.0068f,-0.5166f,0.8561f,0.0112f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4035f,0.846f,0.0999f],left_rotation:[0.0115f,0.1847f,-0.9777f,0.0993f]}}
particle minecraft:campfire_cosy_smoke -62.1 65.12 58.27 -0.049 0.021 -0.058 1 0 force
particle minecraft:cloud -62.1 65.32 58.27 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -62.1 65.42 58.27 0.45 0.2 0.45 0.008 1 force
particle minecraft:cloud -62.04 65.32 59.94 0.35 0.18 0.35 0.02 2 force
scoreboard players set #gx drift -72124
scoreboard players set #gdx drift 653
scoreboard players set #gz drift 53097
scoreboard players set #gdz drift 560
scoreboard players set #gr drift -8411
scoreboard players set #gdr drift -99
function drift:glide/move/onyx
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0036f,-0.0001f,0.0222f,0.9997f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.8346f,-0.1715f,-0.1857f,0.4894f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.2381f,0.5116f,-0.8212f,0.0847f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.8561f,-0.0112f,0.0068f,0.5166f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.0068f,-0.5166f,0.8561f,0.0112f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4079f,0.8445f,0.2437f],left_rotation:[0.1151f,0.1477f,-0.7472f,0.6377f]}}
particle minecraft:campfire_cosy_smoke -73.44 65.12 52.1 -0.025 0.022 -0.062 1 0 force
particle minecraft:cloud -73.44 65.32 52.1 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud -73.62 65.32 53.8 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -73.62 65.42 53.8 0.45 0.2 0.45 0.008 1 force
