scoreboard players set #gx drift -83451
scoreboard players set #gdx drift 525
scoreboard players set #gz drift 35161
scoreboard players set #gdz drift 1083
scoreboard players set #gr drift -4537
scoreboard players set #gdr drift -191
function drift:glide/move/kaze
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0.0111f,0.0001f,0.0128f,0.9999f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.4109f,-0.1261f,0.1162f,0.8954f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.0228f,0.8881f,0.4264f,0.17f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.3577f,0.0047f,0.0122f,0.9337f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.0122f,0.9337f,0.3577f,0.0047f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.3918f,0.8476f,0.1291f],left_rotation:[0.0208f,-0.2007f,0.9765f,0.076f]}}
particle minecraft:cloud -83.8 65.32 33.65 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -84.97 65.12 34.83 -0.055 0.019 -0.028 1 0 force
particle minecraft:cloud -84.97 65.32 34.83 0.35 0.18 0.35 0.02 2 force
scoreboard players set #gx drift -90544
scoreboard players set #gdx drift 428
scoreboard players set #gz drift 18598
scoreboard players set #gdz drift 1230
scoreboard players set #gr drift -2762
scoreboard players set #gdr drift -57
function drift:glide/move/onyx
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0005f,0f,0.0113f,0.9999f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.3031f,-0.0444f,0.0692f,0.9494f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.0302f,0.9473f,0.3095f,0.0765f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.3577f,0.0047f,0.0122f,0.9337f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.0122f,0.9337f,0.3577f,0.0047f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.3894f,0.8516f,0.2492f],left_rotation:[0.1611f,-0.1014f,0.5418f,0.8187f]}}
