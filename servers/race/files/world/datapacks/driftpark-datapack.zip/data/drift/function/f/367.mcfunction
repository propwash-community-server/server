scoreboard players set #gx drift -53737
scoreboard players set #gdx drift -675
scoreboard players set #gz drift -36658
scoreboard players set #gdz drift -675
scoreboard players set #gr drift 10291
scoreboard players set #gdr drift -223
function drift:glide/move/kaze
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0.0112f,0.0002f,0.0199f,0.9997f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.4242f,-0.201f,0.1583f,0.8687f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.0679f,0.8568f,0.4476f,0.2467f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.9126f,-0.0119f,0.0053f,0.4086f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.0053f,-0.4086f,0.9126f,0.0119f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4038f,0.8419f,0.1293f],left_rotation:[0.1291f,0.1551f,-0.7272f,0.6561f]}}
particle minecraft:campfire_cosy_smoke -52.65 65.12 -35.55 0.035 0.022 0.075 1 0 force
particle minecraft:cloud -52.65 65.32 -35.55 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud -52.27 65.32 -37.18 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -52.27 65.42 -37.18 0.45 0.2 0.45 0.008 1 force
scoreboard players set #gx drift -45017
scoreboard players set #gdx drift -520
scoreboard players set #gz drift -25827
scoreboard players set #gdz drift -791
scoreboard players set #gr drift 13925
scoreboard players set #gdr drift -317
function drift:glide/move/onyx
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0059f,0f,-0.0028f,1f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.7464f,0.0042f,0.0743f,0.6614f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.0052f,0.6572f,0.75f,0.0743f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.9126f,-0.0119f,0.0053f,0.4086f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.0053f,-0.4086f,0.9126f,0.0119f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.3651f,0.865f,0.2399f],left_rotation:[0.164f,-0.0856f,0.4497f,0.8738f]}}
particle minecraft:flame -43.24 65.24 -24.04 0.05 0.04 0.05 0.02 6 force
particle minecraft:large_smoke -43.24 65.24 -24.04 0.05 0.04 0.05 0.01 2 force
particle minecraft:flame -43.52 65.24 -23.81 0.05 0.04 0.05 0.02 6 force
particle minecraft:large_smoke -43.52 65.24 -23.81 0.05 0.04 0.05 0.01 2 force
