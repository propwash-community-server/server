scoreboard players set #gx drift -78929
scoreboard players set #gdx drift -645
scoreboard players set #gz drift -45761
scoreboard players set #gdz drift 136
scoreboard players set #gr drift 3741
scoreboard players set #gdr drift -207
function drift:glide/move/kaze
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.9082f,-0.1412f,-0.2485f,0.3058f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.282f,0.3336f,-0.8984f,0.0465f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.9447f,-0.0124f,0.0043f,0.3277f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.0043f,-0.3277f,0.9447f,0.0124f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4078f,0.8413f,0.1207f],left_rotation:[0.1632f,0.1101f,-0.5116f,0.8364f]}}
particle minecraft:campfire_cosy_smoke -77.47 65.12 -46.29 0.059 0.022 0.026 1 0 force
particle minecraft:cloud -77.47 65.32 -46.29 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -77.47 65.42 -46.29 0.45 0.2 0.45 0.008 1 force
particle minecraft:cloud -78.8 65.32 -47.31 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx drift -68580
scoreboard players set #gdx drift -777
scoreboard players set #gz drift -46403
scoreboard players set #gdz drift -160
scoreboard players set #gr drift 6024
scoreboard players set #gdr drift -190
function drift:glide/move/onyx
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0.0006f,0f,0.0223f,0.9998f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.9475f,-0.0864f,-0.2904f,0.1019f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.3027f,-0.1329f,0.9437f,0.0127f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.9447f,-0.0124f,0.0043f,0.3277f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.0043f,-0.3277f,0.9447f,0.0124f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4079f,0.8424f,0.2511f],left_rotation:[0.1741f,0.0796f,-0.3679f,0.9099f]}}
particle minecraft:campfire_cosy_smoke -66.93 65.12 -46.36 0.065 0.022 0.047 1 0 force
particle minecraft:cloud -66.93 65.32 -46.36 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -66.93 65.42 -46.36 0.45 0.2 0.45 0.008 1 force
particle minecraft:cloud -67.78 65.32 -47.85 0.35 0.18 0.35 0.02 3 force
