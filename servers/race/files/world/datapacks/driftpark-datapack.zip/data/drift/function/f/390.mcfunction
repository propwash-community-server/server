scoreboard players set #gx drift -69528
scoreboard players set #gdx drift -755
scoreboard players set #gz drift -45680
scoreboard players set #gdz drift -134
scoreboard players set #gr drift 6264
scoreboard players set #gdr drift -195
function drift:glide/move/kaze
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0.0014f,0f,0.0223f,0.9998f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.0164f,-0.2687f,0.0589f,0.9613f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.0418f,0.9604f,0.0447f,0.2719f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.5868f,0.0077f,0.0106f,0.8096f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.0106f,0.8096f,0.5868f,0.0077f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4079f,0.8424f,0.1124f],left_rotation:[0.1475f,0.1232f,-0.595f,0.7804f]}}
particle minecraft:cloud -67.98 65.32 -45.54 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -67.98 65.42 -45.54 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke -68.75 65.12 -47.02 0.029 0.022 -0.028 1 0 force
particle minecraft:cloud -68.75 65.32 -47.02 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx drift -59264
scoreboard players set #gdx drift -682
scoreboard players set #gz drift -42463
scoreboard players set #gdz drift -436
scoreboard players set #gr drift 8058
scoreboard players set #gdr drift -165
function drift:glide/move/onyx
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0.0069f,0.0002f,0.0223f,0.9997f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.61f,-0.2665f,-0.1509f,0.7308f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.2286f,0.7507f,-0.5853f,0.2039f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.5868f,0.0077f,0.0106f,0.8096f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.0106f,0.8096f,0.5868f,0.0077f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4077f,0.8391f,0.2619f],left_rotation:[0.1823f,0.0763f,-0.3381f,0.9201f]}}
particle minecraft:cloud -57.73 65.32 -41.85 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -57.73 65.42 -41.85 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke -58.01 65.12 -43.54 0.031 0.022 -0.027 1 0 force
particle minecraft:cloud -58.01 65.32 -43.54 0.35 0.18 0.35 0.02 3 force
