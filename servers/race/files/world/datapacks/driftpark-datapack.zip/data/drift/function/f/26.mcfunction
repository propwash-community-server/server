scoreboard players set #gx drift -22105
scoreboard players set #gdx drift 1299
scoreboard players set #gz drift 64401
scoreboard players set #gdz drift -36
scoreboard players set #gr drift -9136
scoreboard players set #gdr drift 10
function drift:glide/move/kaze
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0f,0f,0.0041f,1f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.5504f,-0.0235f,0.0472f,0.8333f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.0401f,-0.8329f,0.5509f,0.0342f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.5534f,-0.0072f,0.0109f,0.8328f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.0109f,-0.8328f,0.5534f,0.0072f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.3771f,0.8569f,0.11f],left_rotation:[0.1904f,0.0118f,-0.0525f,0.9802f]}}
scoreboard players set #gx drift -39761
scoreboard players set #gdx drift 1199
scoreboard players set #gz drift 64500
scoreboard players set #gdz drift 78
scoreboard players set #gr drift -10011
scoreboard players set #gdr drift 73
function drift:glide/move/onyx
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0059f,-0.0001f,0.0148f,0.9999f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.4341f,-0.1138f,0.0032f,0.8936f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.0907f,0.8982f,-0.4246f,0.0688f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.5534f,-0.0072f,0.0109f,0.8328f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.0109f,-0.8328f,0.5534f,0.0072f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.3954f,0.8515f,0.2399f],left_rotation:[0.1152f,-0.1448f,0.7869f,0.5887f]}}
particle minecraft:campfire_cosy_smoke -41 65.12 65.59 -0.043 0.015 0.036 1 0 force
