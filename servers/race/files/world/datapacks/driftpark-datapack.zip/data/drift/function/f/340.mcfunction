scoreboard players set #gx drift -37248
scoreboard players set #gdx drift -603
scoreboard players set #gz drift -17623
scoreboard players set #gdz drift -535
scoreboard players set #gr drift 15915
scoreboard players set #gdr drift -13
function drift:glide/move/kaze
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0059f,0.0001f,-0.0192f,0.9998f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.0989f,0.1795f,0.0717f,0.9761f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.0305f,-0.974f,0.1183f,0.1909f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.9555f,0.0125f,0.0039f,0.2946f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.0039f,0.2946f,0.9555f,0.0125f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.3367f,0.8748f,0.0999f],left_rotation:[0.0184f,-0.1841f,0.9734f,0.1353f]}}
particle minecraft:cloud -37.56 65.32 -16.1 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -36 65.12 -16.7 0.065 0.022 0.004 1 0 force
particle minecraft:cloud -36 65.32 -16.7 0.35 0.18 0.35 0.02 2 force
scoreboard players set #gx drift -28521
scoreboard players set #gdx drift -727
scoreboard players set #gz drift -11550
scoreboard players set #gdz drift -254
scoreboard players set #gr drift 15033
scoreboard players set #gdr drift 133
function drift:glide/move/onyx
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0.0017f,0f,-0.0223f,0.9998f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.4597f,0.2269f,0.1868f,0.838f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.0998f,-0.823f,0.4861f,0.2765f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.9555f,0.0125f,0.0039f,0.2946f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.0039f,0.2946f,0.9555f,0.0125f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.3314f,0.8747f,0.253f],left_rotation:[0.1675f,-0.0949f,0.4452f,0.8745f]}}
particle minecraft:cloud -28.56 65.32 -9.9 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -27.08 65.12 -10.74 0.063 0.022 -0.009 1 0 force
particle minecraft:cloud -27.08 65.32 -10.74 0.35 0.18 0.35 0.02 3 force
