scoreboard players set #gx drift -72753
scoreboard players set #gdx drift 607
scoreboard players set #gz drift 51289
scoreboard players set #gdz drift 576
scoreboard players set #gr drift -7783
scoreboard players set #gdr drift -129
function drift:glide/move/kaze
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0.002f,0f,0.0222f,0.9998f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.1078f,-0.2159f,0.0781f,0.9673f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.0231f,0.9644f,0.1311f,0.2284f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.058f,0.0008f,0.0131f,0.9982f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.0131f,0.9982f,0.058f,0.0008f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4079f,0.8423f,0.1134f],left_rotation:[0.0824f,0.1743f,-0.8676f,0.4583f]}}
particle minecraft:campfire_cosy_smoke -73.86 65.12 50.2 -0.023 0.022 -0.065 1 0 force
particle minecraft:cloud -73.86 65.32 50.2 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud -74.21 65.32 51.83 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx drift -81319
scoreboard players set #gdx drift 501
scoreboard players set #gz drift 40625
scoreboard players set #gdz drift 995
scoreboard players set #gr drift -5864
scoreboard players set #gdr drift -202
function drift:glide/move/onyx
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0.0111f,0.0002f,0.018f,0.9998f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.0912f,-0.2263f,0.0754f,0.9668f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.0258f,0.9642f,0.1155f,0.2371f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.058f,0.0008f,0.0131f,0.9982f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.0131f,0.9982f,0.058f,0.0008f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4005f,0.8403f,0.2691f],left_rotation:[0.1021f,0.174f,-0.8263f,0.5258f]}}
particle minecraft:campfire_cosy_smoke -82.08 65.12 39.16 0.003 0.022 -0.089 1 0 force
particle minecraft:cloud -82.08 65.32 39.16 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud -82.97 65.32 40.62 0.35 0.18 0.35 0.02 3 force
