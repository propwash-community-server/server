scoreboard players set #gx drift -53061
scoreboard players set #gdx drift -676
scoreboard players set #gz drift -35956
scoreboard players set #gdz drift -702
scoreboard players set #gr drift 10529
scoreboard players set #gdr drift -238
function drift:glide/move/kaze
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0.0112f,0.0002f,0.0191f,0.9998f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.729f,-0.2004f,-0.1472f,0.6378f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.215f,0.6568f,-0.7119f,0.1249f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.6328f,0.0083f,0.0101f,0.7742f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.0101f,0.7742f,0.6328f,0.0083f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4024f,0.8426f,0.1293f],left_rotation:[0.1183f,0.1635f,-0.7711f,0.6039f]}}
particle minecraft:cloud -52.02 65.32 -34.81 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -51.58 65.12 -36.42 0.04 0.022 -0.002 1 0 force
particle minecraft:cloud -51.58 65.32 -36.42 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -51.58 65.42 -36.42 0.45 0.2 0.45 0.008 1 force
scoreboard players set #gx drift -44508
scoreboard players set #gdx drift -509
scoreboard players set #gz drift -25040
scoreboard players set #gdz drift -788
scoreboard players set #gr drift 14228
scoreboard players set #gdr drift -303
function drift:glide/move/onyx
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0059f,0f,-0.0045f,1f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.4475f,-0.048f,0.0345f,0.8923f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.0591f,0.8936f,-0.445f,0.0012f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.6328f,0.0083f,0.0101f,0.7742f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.0101f,0.7742f,0.6328f,0.0083f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.3623f,0.8661f,0.2399f],left_rotation:[0.1792f,-0.0462f,0.2366f,0.9538f]}}
particle minecraft:flame -42.83 65.24 -23.16 0.05 0.04 0.05 0.02 6 force
particle minecraft:large_smoke -42.83 65.24 -23.16 0.05 0.04 0.05 0.01 2 force
particle minecraft:flame -43.11 65.24 -22.94 0.05 0.04 0.05 0.02 6 force
particle minecraft:large_smoke -43.11 65.24 -22.94 0.05 0.04 0.05 0.01 2 force
