scoreboard players set #gx drift -92931
scoreboard players set #gdx drift 342
scoreboard players set #gz drift 9993
scoreboard players set #gdz drift 1196
scoreboard players set #gr drift -2342
scoreboard players set #gdr drift -28
function drift:glide/move/kaze
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0059f,-0.0001f,0.0103f,0.9999f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.9525f,0.034f,0.0674f,0.2952f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.0367f,0.2897f,0.9541f,0.0659f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.9327f,0.0122f,0.0047f,0.3604f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.0047f,0.3604f,0.9327f,0.0122f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.3877f,0.8534f,0.0999f],left_rotation:[0.1641f,-0.0855f,0.472f,0.862f]}}
scoreboard players set #gx drift -96973
scoreboard players set #gdx drift 178
scoreboard players set #gz drift -5858
scoreboard players set #gdz drift 1091
scoreboard players set #gr drift -2863
scoreboard players set #gdr drift 49
function drift:glide/move/onyx
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0059f,-0.0001f,0.0163f,0.9999f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.8458f,-0.0306f,0.1532f,0.5102f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.1005f,0.4969f,0.8536f,0.1197f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.9327f,0.0122f,0.0047f,0.3604f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.0047f,0.3604f,0.9327f,0.0122f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.3979f,0.8504f,0.2399f],left_rotation:[0.0464f,-0.1792f,0.9589f,0.2152f]}}
particle minecraft:campfire_cosy_smoke -96.9 65.12 -7.51 0.03 0.018 -0.069 1 0 force
particle minecraft:cloud -96.9 65.32 -7.51 0.35 0.18 0.35 0.02 2 force
particle minecraft:cloud -98.4 65.32 -6.69 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -98.4 65.42 -6.69 0.45 0.2 0.45 0.008 1 force
