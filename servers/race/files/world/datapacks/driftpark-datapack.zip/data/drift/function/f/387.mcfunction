scoreboard players set #gx drift -67289
scoreboard players set #gdx drift -740
scoreboard players set #gz drift -45153
scoreboard players set #gdz drift -196
scoreboard players set #gr drift 6791
scoreboard players set #gdr drift -156
function drift:glide/move/kaze
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0009f,0f,0.0223f,0.9998f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.3549f,-0.2657f,-0.0469f,0.8951f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.1413f,0.905f,-0.329f,0.2298f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.1504f,-0.002f,0.0129f,0.9885f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.0129f,-0.9885f,0.1504f,0.002f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4079f,0.8429f,0.1084f],left_rotation:[0.1394f,0.1289f,-0.634f,0.7497f]}}
particle minecraft:campfire_cosy_smoke -65.76 65.12 -44.87 0.055 0.022 0.045 1 0 force
particle minecraft:cloud -65.76 65.32 -44.87 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud -66.39 65.32 -46.42 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -66.39 65.42 -46.42 0.45 0.2 0.45 0.008 1 force
scoreboard players set #gx drift -57216
scoreboard players set #gdx drift -685
scoreboard players set #gz drift -40994
scoreboard players set #gdz drift -519
scoreboard players set #gr drift 8597
scoreboard players set #gdr drift -197
function drift:glide/move/onyx
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0.01f,0.0002f,0.0222f,0.9997f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.8974f,-0.1524f,-0.267f,0.3164f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.3017f,0.3462f,-0.8864f,0.0589f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.1504f,-0.002f,0.0129f,0.9885f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.0129f,-0.9885f,0.1504f,0.002f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4076f,0.8375f,0.2672f],left_rotation:[0.1859f,0.0755f,-0.3282f,0.9231f]}}
particle minecraft:campfire_cosy_smoke -55.74 65.12 -40.24 0.033 0.022 0.071 1 0 force
particle minecraft:cloud -55.74 65.32 -40.24 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud -55.86 65.32 -41.95 0.35 0.18 0.35 0.02 3 force
