scoreboard players set #gx drift 30822
scoreboard players set #gdx drift -903
scoreboard players set #gz drift -49895
scoreboard players set #gdz drift 105
scoreboard players set #gr drift 5312
scoreboard players set #gdr drift -149
function drift:glide/move/kaze
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0f,0f,0.0223f,0.9998f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.854f,-0.154f,-0.1698f,0.467f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.2198f,0.4874f,-0.8425f,0.0651f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.8819f,-0.0115f,0.0062f,0.4712f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.0062f,-0.4712f,0.8819f,0.0115f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4079f,0.8427f,0.1101f],left_rotation:[0.081f,0.1728f,-0.8694f,0.4557f]}}
particle minecraft:cloud 32.37 65.32 -50.01 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 31.37 65.12 -51.35 0.029 0.022 -0.044 1 0 force
particle minecraft:cloud 31.37 65.32 -51.35 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx drift 44137
scoreboard players set #gdx drift -1001
scoreboard players set #gz drift -49986
scoreboard players set #gdz drift -205
scoreboard players set #gr drift 6970
scoreboard players set #gdr drift -151
function drift:glide/move/onyx
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0.0069f,0.0002f,0.0223f,0.9997f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.1372f,-0.2292f,0.0872f,0.9597f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.0132f,0.9558f,0.162f,0.2448f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.8819f,-0.0115f,0.0062f,0.4712f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.0062f,-0.4712f,0.8819f,0.0115f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4077f,0.8392f,0.2618f],left_rotation:[0.1099f,0.1642f,-0.7894f,0.5812f]}}
particle minecraft:cloud 45.76 65.32 -49.68 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 45.17 65.12 -51.28 0.034 0.022 -0.02 1 0 force
particle minecraft:cloud 45.17 65.32 -51.28 0.35 0.18 0.35 0.02 3 force
