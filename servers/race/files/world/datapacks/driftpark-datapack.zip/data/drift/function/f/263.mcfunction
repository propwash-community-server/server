scoreboard players set #gx drift 8186
scoreboard players set #gdx drift -449
scoreboard players set #gz drift -37538
scoreboard players set #gdz drift 649
scoreboard players set #gr drift 1416
scoreboard players set #gdr drift 164
function drift:glide/move/kaze
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0058f,-0.0001f,0.0148f,0.9999f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.9758f,0.0305f,0.1306f,0.1726f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.1132f,0.1598f,0.978f,0.0719f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.9306f,0.0122f,0.0048f,0.3658f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.0048f,0.3658f,0.9306f,0.0122f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.3954f,0.8499f,0.1f],left_rotation:[0.0836f,-0.1651f,0.8897f,0.4174f]}}
particle minecraft:campfire_cosy_smoke 9.32 65.12 -38.6 0.057 0.017 -0.021 1 0 force
particle minecraft:cloud 9.32 65.32 -38.6 0.35 0.18 0.35 0.02 2 force
particle minecraft:cloud 7.7 65.32 -39.01 0.35 0.18 0.35 0.02 2 force
scoreboard players set #gx drift 15015
scoreboard players set #gdx drift -651
scoreboard players set #gz drift -45483
scoreboard players set #gdz drift 435
scoreboard players set #gr drift 1498
scoreboard players set #gdr drift -131
function drift:glide/move/onyx
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0.0064f,0.0001f,0.0223f,0.9997f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.9097f,-0.1408f,-0.2608f,0.2908f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.2928f,0.3198f,-0.8999f,0.046f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.9306f,0.0122f,0.0048f,0.3658f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.0048f,0.3658f,0.9306f,0.0122f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4078f,0.8394f,0.261f],left_rotation:[0.1737f,0.093f,-0.4239f,0.884f]}}
particle minecraft:campfire_cosy_smoke 16.21 65.12 -46.63 0.062 0.022 -0.008 1 0 force
particle minecraft:cloud 16.21 65.32 -46.63 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud 14.55 65.32 -47.07 0.35 0.18 0.35 0.02 3 force
