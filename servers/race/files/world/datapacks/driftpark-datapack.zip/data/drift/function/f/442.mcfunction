scoreboard players set #gx drift -95470
scoreboard players set #gdx drift -203
scoreboard players set #gz drift -26400
scoreboard players set #gdz drift 852
scoreboard players set #gr drift -1266
scoreboard players set #gdr drift -88
function drift:glide/move/kaze
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0059f,-0.0001f,0.0172f,0.9998f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.4598f,-0.1937f,-0.0425f,0.8656f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.1337f,0.8748f,-0.442f,0.1465f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.5191f,-0.0068f,0.0112f,0.8546f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.0112f,-0.8546f,0.5191f,0.0068f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.3994f,0.848f,0.0999f],left_rotation:[0.0275f,0.183f,-0.9662f,0.1795f]}}
particle minecraft:cloud -94.94 65.32 -27.86 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -96.57 65.12 -27.49 -0.029 0.022 -0.041 1 0 force
particle minecraft:cloud -96.57 65.32 -27.49 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -96.57 65.42 -27.49 0.45 0.2 0.45 0.008 1 force
scoreboard players set #gx drift -92087
scoreboard players set #gdx drift -384
scoreboard players set #gz drift -37190
scoreboard players set #gdz drift 646
scoreboard players set #gr drift -683
scoreboard players set #gdr drift -59
function drift:glide/move/onyx
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0059f,-0.0001f,0.0198f,0.9998f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.3695f,-0.2184f,0.1493f,0.8908f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.0565f,0.88f,0.3945f,0.2584f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.5191f,-0.0068f,0.0112f,0.8546f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.0112f,-0.8546f,0.5191f,0.0068f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4038f,0.8476f,0.2398f],left_rotation:[0.1297f,0.1319f,-0.6731f,0.7161f]}}
particle minecraft:cloud -91.41 65.32 -38.7 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -91.41 65.42 -38.7 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke -93.1 65.12 -38.49 -0.017 0.022 -0.023 1 0 force
particle minecraft:cloud -93.1 65.32 -38.49 0.35 0.18 0.35 0.02 3 force
