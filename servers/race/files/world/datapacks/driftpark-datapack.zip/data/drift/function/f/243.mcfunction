scoreboard players set #gx drift 19729
scoreboard players set #gdx drift -754
scoreboard players set #gz drift -47000
scoreboard players set #gdz drift 345
scoreboard players set #gr drift 3028
scoreboard players set #gdr drift -197
function drift:glide/move/kaze
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0.0062f,0.0001f,0.0223f,0.9997f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.1668f,-0.2458f,0.0982f,0.9498f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.0011f,0.9447f,0.1935f,0.2646f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.1961f,0.0026f,0.0128f,0.9805f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.0128f,0.9805f,0.1961f,0.0026f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4078f,0.8413f,0.1206f],left_rotation:[0.1378f,0.1406f,-0.669f,0.7167f]}}
particle minecraft:campfire_cosy_smoke 21.11 65.12 -47.71 0.078 0.022 0.011 1 0 force
particle minecraft:cloud 21.11 65.32 -47.71 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 21.11 65.42 -47.71 0.45 0.2 0.45 0.008 1 force
particle minecraft:cloud 19.67 65.32 -48.55 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 19.67 65.42 -48.55 0.45 0.2 0.45 0.008 1 force
scoreboard players set #gx drift 31653
scoreboard players set #gdx drift -924
scoreboard players set #gz drift -50876
scoreboard players set #gdz drift 85
scoreboard players set #gr drift 5074
scoreboard players set #gdr drift -148
function drift:glide/move/onyx
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0.0001f,0f,0.0223f,0.9998f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.9635f,0.0334f,0.2534f,0.0793f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.2465f,0.0531f,0.9653f,0.0677f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.1961f,0.0026f,0.0128f,0.9805f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.0128f,0.9805f,0.1961f,0.0026f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4079f,0.8426f,0.2502f],left_rotation:[0.1214f,0.1474f,-0.7292f,0.6572f]}}
particle minecraft:campfire_cosy_smoke 33.29 65.12 -51.11 0.073 0.022 0.036 1 0 force
particle minecraft:cloud 33.29 65.32 -51.11 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud 32.21 65.32 -52.43 0.35 0.18 0.35 0.02 3 force
