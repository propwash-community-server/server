scoreboard players set #gx drift -10935
scoreboard players set #gdx drift -580
scoreboard players set #gz drift -13300
scoreboard players set #gdz drift 296
scoreboard players set #gr drift 10496
scoreboard players set #gdr drift 167
function drift:glide/move/kaze
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0.0055f,-0.0001f,-0.0223f,0.9997f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.2946f,0.2898f,-0.0364f,0.9099f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.1322f,-0.9188f,-0.2657f,0.2604f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.6637f,-0.0087f,0.0098f,0.7479f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.0098f,-0.7479f,0.6637f,0.0087f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.3314f,0.8744f,0.1194f],left_rotation:[0.1689f,-0.0998f,0.4608f,0.8655f]}}
particle minecraft:cloud -9.88 65.32 -12.16 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -9.45 65.12 -13.77 0.039 0.022 -0.044 1 0 force
particle minecraft:cloud -9.45 65.32 -13.77 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -9.45 65.42 -13.77 0.45 0.2 0.45 0.008 1 force
scoreboard players set #gx drift -2116
scoreboard players set #gdx drift -588
scoreboard players set #gz drift -19639
scoreboard players set #gdz drift 692
scoreboard players set #gr drift 8112
scoreboard players set #gdr drift 231
function drift:glide/move/onyx
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0.0113f,-0.0002f,-0.0216f,0.9997f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.2461f,0.3136f,-0.0272f,0.9167f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.1237f,-0.9246f,-0.2145f,0.2895f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.6637f,-0.0087f,0.0098f,0.7479f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.0098f,-0.7479f,0.6637f,0.0087f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.3327f,0.8693f,0.2694f],left_rotation:[0.192f,-0.0624f,0.2623f,0.9436f]}}
particle minecraft:cloud -0.59 65.32 -19.01 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -0.85 65.12 -20.7 0.023 0.022 -0.065 1 0 force
particle minecraft:cloud -0.85 65.32 -20.7 0.35 0.18 0.35 0.02 3 force
