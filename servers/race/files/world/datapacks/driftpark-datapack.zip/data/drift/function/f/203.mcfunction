scoreboard players set #gx drift 57591
scoreboard players set #gdx drift -1109
scoreboard players set #gz drift -44204
scoreboard players set #gdz drift -538
scoreboard players set #gr drift 9210
scoreboard players set #gdr drift -132
function drift:glide/move/kaze
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0.0088f,0.0002f,0.022f,0.9997f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.9577f,0.0117f,0.1916f,0.2142f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.1702f,0.1953f,0.9618f,0.0889f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.9737f,0.0127f,0.003f,0.2274f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.003f,0.2274f,0.9737f,0.0127f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4075f,0.8408f,0.1251f],left_rotation:[0.0167f,0.1987f,-0.9719f,0.1249f]}}
particle minecraft:campfire_cosy_smoke 58.87 65.12 -43.32 0.056 0.021 0.066 1 0 force
particle minecraft:cloud 58.87 65.32 -43.32 0.35 0.18 0.35 0.02 2 force
particle minecraft:cloud 58.93 65.32 -44.99 0.35 0.18 0.35 0.02 2 force
particle minecraft:flame 59.99 65.22 -44.62 0.05 0.04 0.05 0.02 5 force
particle minecraft:large_smoke 59.99 65.22 -44.62 0.05 0.04 0.05 0.01 2 force
scoreboard players set #gx drift 72033
scoreboard players set #gdx drift -883
scoreboard players set #gz drift -35663
scoreboard players set #gdz drift -723
scoreboard players set #gr drift 10289
scoreboard players set #gdr drift -96
function drift:glide/move/onyx
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0057f,-0.0001f,0.0223f,0.9997f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.6454f,-0.1884f,-0.0944f,0.7342f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.1721f,0.7482f,-0.6291f,0.1216f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.9737f,0.0127f,0.003f,0.2274f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.003f,0.2274f,0.9737f,0.0127f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.408f,0.8455f,0.2402f],left_rotation:[0.048f,0.1789f,-0.9368f,0.2968f]}}
particle minecraft:campfire_cosy_smoke 73.22 65.12 -34.51 0.041 0.022 0.067 1 0 force
particle minecraft:cloud 73.22 65.32 -34.51 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud 73.6 65.32 -36.18 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 73.6 65.42 -36.18 0.45 0.2 0.45 0.008 1 force
