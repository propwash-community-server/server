scoreboard players set #gx drift -56431
scoreboard players set #gdx drift -670
scoreboard players set #gz drift -39190
scoreboard players set #gdz drift -562
scoreboard players set #gr drift 9411
scoreboard players set #gdr drift -205
function drift:glide/move/kaze
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0.0111f,0.0002f,0.0219f,0.9997f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.5457f,-0.2519f,-0.1076f,0.792f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.1914f,0.8076f,-0.5222f,0.196f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.8045f,0.0105f,0.0078f,0.5938f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.0078f,0.5938f,0.8045f,0.0105f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4072f,0.8403f,0.129f],left_rotation:[0.1534f,0.1309f,-0.6025f,0.7722f]}}
particle minecraft:campfire_cosy_smoke -55.18 65.12 -38.26 0.035 0.022 0.068 1 0 force
particle minecraft:cloud -55.18 65.32 -38.26 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud -55.06 65.32 -39.93 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx drift -47115
scoreboard players set #gdx drift -539
scoreboard players set #gz drift -29055
scoreboard players set #gdz drift -829
scoreboard players set #gr drift 12642
scoreboard players set #gdr drift -317
function drift:glide/move/onyx
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0059f,0f,0.0045f,1f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.1911f,-0.1542f,0.0235f,0.9691f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.0782f,0.972f,-0.176f,0.135f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.8045f,0.0105f,0.0078f,0.5938f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.0078f,0.5938f,0.8045f,0.0105f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.3777f,0.8595f,0.2399f],left_rotation:[0.0447f,-0.1796f,0.9557f,0.2291f]}}
particle minecraft:campfire_cosy_smoke -46.48 65.12 -27.53 0.002 0.017 0.082 1 0 force
particle minecraft:cloud -46.48 65.32 -27.53 0.35 0.18 0.35 0.02 2 force
particle minecraft:cloud -45.47 65.32 -28.9 0.35 0.18 0.35 0.02 2 force
