scoreboard players set #gx drift 42964
scoreboard players set #gdx drift -975
scoreboard players set #gz drift -49307
scoreboard players set #gdz drift -178
scoreboard players set #gr drift 7193
scoreboard players set #gdr drift -150
function drift:glide/move/kaze
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0.0065f,0.0001f,0.0223f,0.9997f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.6951f,-0.1111f,0.1891f,0.6846f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.1182f,0.6685f,0.7106f,0.1848f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.706f,0.0092f,0.0093f,0.7081f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.0093f,0.7081f,0.706f,0.0092f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4078f,0.8412f,0.1211f],left_rotation:[0.0665f,0.1856f,-0.9072f,0.3717f]}}
particle minecraft:campfire_cosy_smoke 44.47 65.12 -48.92 0.06 0.022 0.039 1 0 force
particle minecraft:cloud 44.47 65.32 -48.92 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud 43.95 65.32 -50.51 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 43.95 65.42 -50.51 0.45 0.2 0.45 0.008 1 force
scoreboard players set #gx drift 57860
scoreboard players set #gdx drift -1108
scoreboard players set #gz drift -44747
scoreboard players set #gdz drift -565
scoreboard players set #gr drift 8864
scoreboard players set #gdr drift -133
function drift:glide/move/onyx
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0.0088f,0.0002f,0.022f,0.9997f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.911f,-0.1257f,-0.1779f,0.3502f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.2156f,0.3708f,-0.9028f,0.0307f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.706f,0.0092f,0.0093f,0.7081f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.0093f,0.7081f,0.706f,0.0092f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4074f,0.8383f,0.2651f],left_rotation:[0.0646f,0.1887f,-0.9122f,0.3579f]}}
particle minecraft:campfire_cosy_smoke 59.3 65.12 -43.93 0.054 0.022 0.071 1 0 force
particle minecraft:cloud 59.3 65.32 -43.93 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud 59.25 65.32 -45.64 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 59.25 65.42 -45.64 0.45 0.2 0.45 0.008 1 force
particle minecraft:flame 60.37 65.24 -44.99 0.05 0.04 0.05 0.02 6 force
particle minecraft:large_smoke 60.37 65.24 -44.99 0.05 0.04 0.05 0.01 2 force
particle minecraft:flame 60.37 65.24 -44.63 0.05 0.04 0.05 0.02 6 force
particle minecraft:large_smoke 60.37 65.24 -44.63 0.05 0.04 0.05 0.01 2 force
