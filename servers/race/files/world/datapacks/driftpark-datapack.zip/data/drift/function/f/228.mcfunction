scoreboard players set #gx drift 32629
scoreboard players set #gdx drift -904
scoreboard players set #gz drift -50041
scoreboard players set #gdz drift 62
scoreboard players set #gr drift 5605
scoreboard players set #gdr drift -145
function drift:glide/move/kaze
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0.0006f,0f,0.0223f,0.9998f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.5024f,-0.2163f,-0.0676f,0.8344f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.1557f,0.8461f,-0.4824f,0.1647f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.5241f,-0.0069f,0.0111f,0.8516f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.0111f,-0.8516f,0.5241f,0.0069f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4079f,0.8426f,0.111f],left_rotation:[0.0769f,0.1752f,-0.8803f,0.4342f]}}
particle minecraft:cloud 34.18 65.32 -50.08 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 33.25 65.12 -51.47 0.019 0.022 -0.033 1 0 force
particle minecraft:cloud 33.25 65.32 -51.47 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx drift 46162
scoreboard players set #gdx drift -1016
scoreboard players set #gz drift -49492
scoreboard players set #gdz drift -266
scoreboard players set #gr drift 7280
scoreboard players set #gdr drift -160
function drift:glide/move/onyx
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0.0079f,0.0002f,0.0223f,0.9997f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.5948f,-0.1532f,0.187f,0.7666f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.1075f,0.7512f,0.6142f,0.2165f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.5241f,-0.0069f,0.0111f,0.8516f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.0111f,-0.8516f,0.5241f,0.0069f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4077f,0.8386f,0.2636f],left_rotation:[0.105f,0.1685f,-0.808f,0.5547f]}}
particle minecraft:cloud 47.77 65.32 -49.09 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 47.77 65.42 -49.09 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke 47.26 65.12 -50.73 0.043 0.022 -0.02 1 0 force
particle minecraft:cloud 47.26 65.32 -50.73 0.35 0.18 0.35 0.02 3 force
