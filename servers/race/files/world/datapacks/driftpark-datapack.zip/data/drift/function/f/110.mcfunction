scoreboard players set #gx drift 77140
scoreboard players set #gdx drift 712
scoreboard players set #gz drift 39753
scoreboard players set #gdz drift -819
scoreboard players set #gr drift -16457
scoreboard players set #gdr drift -127
function drift:glide/move/kaze
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.6957f,-0.174f,-0.0997f,0.6897f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.1728f,0.704f,-0.6813f,0.1018f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.7101f,-0.0093f,0.0092f,0.704f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.0092f,-0.704f,0.7101f,0.0093f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4079f,0.8418f,0.1164f],left_rotation:[0.032f,0.1918f,-0.9594f,0.2043f]}}
particle minecraft:cloud 75.99 65.32 40.79 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke 77.6 65.12 41.24 0.009 0.022 0.046 1 0 force
particle minecraft:cloud 77.6 65.32 41.24 0.35 0.18 0.35 0.02 2 force
scoreboard players set #gx drift 65607
scoreboard players set #gdx drift 971
scoreboard players set #gz drift 50622
scoreboard players set #gdz drift -648
scoreboard players set #gr drift -15168
scoreboard players set #gdr drift -114
function drift:glide/move/onyx
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0.0013f,0f,0.0223f,0.9998f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.2039f,-0.2182f,0.0081f,0.9543f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.0921f,0.9587f,-0.1821f,0.198f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.7101f,-0.0093f,0.0092f,0.704f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.0092f,-0.704f,0.7101f,0.0093f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4079f,0.8421f,0.2522f],left_rotation:[0.0631f,0.1814f,-0.9116f,0.3635f]}}
particle minecraft:cloud 64.18 65.32 51.46 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 65.69 65.12 52.27 -0.013 0.022 0.046 1 0 force
particle minecraft:cloud 65.69 65.32 52.27 0.35 0.18 0.35 0.02 3 force
