scoreboard players set #gx drift -36640
scoreboard players set #gdx drift -608
scoreboard players set #gz drift -17109
scoreboard players set #gdz drift -513
scoreboard players set #gr drift 15899
scoreboard players set #gdr drift 15
function drift:glide/move/kaze
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0059f,0.0001f,-0.0199f,0.9998f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.9513f,-0.0055f,0.2024f,0.2324f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.1791f,-0.2124f,0.956f,0.0945f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.0348f,-0.0005f,0.0131f,0.9993f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.0131f,-0.9993f,0.0348f,0.0005f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.3354f,0.8753f,0.0999f],left_rotation:[0.0342f,-0.1819f,0.9578f,0.22f]}}
particle minecraft:campfire_cosy_smoke -36.95 65.12 -15.59 -0.005 0.022 0.048 1 0 force
particle minecraft:cloud -36.95 65.32 -15.59 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud -35.39 65.32 -16.19 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx drift -27785
scoreboard players set #gdx drift -736
scoreboard players set #gz drift -11317
scoreboard players set #gdz drift -234
scoreboard players set #gr drift 14895
scoreboard players set #gdr drift 138
function drift:glide/move/onyx
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0.0011f,0f,-0.0223f,0.9998f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.9532f,0.0737f,-0.2865f,0.0628f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.2947f,0.0933f,0.9507f,0.0261f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.0348f,-0.0005f,0.0131f,0.9993f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.0131f,-0.9993f,0.0348f,0.0005f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.3314f,0.8751f,0.2518f],left_rotation:[0.1686f,-0.0915f,0.4295f,0.8825f]}}
particle minecraft:campfire_cosy_smoke -27.79 65.12 -9.66 0 0.022 0.036 1 0 force
particle minecraft:cloud -27.79 65.32 -9.66 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud -26.32 65.32 -10.55 0.35 0.18 0.35 0.02 3 force
