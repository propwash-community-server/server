scoreboard players set #gx drift 89921
scoreboard players set #gdx drift -99
scoreboard players set #gz drift 921
scoreboard players set #gdz drift -1062
scoreboard players set #gr drift 14947
scoreboard players set #gdr drift -117
function drift:glide/move/kaze
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0009f,0f,0.0223f,0.9998f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.9181f,-0.0164f,0.1956f,0.3444f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.1605f,0.3257f,0.9249f,0.113f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.9348f,0.0122f,0.0046f,0.355f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.0046f,0.355f,0.9348f,0.0122f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4079f,0.8429f,0.1084f],left_rotation:[0.0236f,0.1884f,-0.9678f,0.1652f]}}
particle minecraft:cloud 89.87 65.32 2.47 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke 91.31 65.12 1.62 0.036 0.021 0.04 1 0 force
particle minecraft:cloud 91.31 65.32 1.62 0.35 0.18 0.35 0.02 2 force
scoreboard players set #gx drift 89923
scoreboard players set #gdx drift 196
scoreboard players set #gz drift 15926
scoreboard players set #gdz drift -1060
scoreboard players set #gr drift 16167
scoreboard players set #gdr drift -116
function drift:glide/move/onyx
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.001f,0f,0.0223f,0.9998f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.8856f,-0.1394f,-0.1749f,0.407f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.2186f,0.4276f,-0.8758f,0.0471f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.9348f,0.0122f,0.0046f,0.355f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.0046f,0.355f,0.9348f,0.0122f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4079f,0.8432f,0.2483f],left_rotation:[0.0713f,0.1759f,-0.8925f,0.409f]}}
particle minecraft:cloud 89.56 65.32 17.54 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 89.56 65.42 17.54 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke 91.18 65.12 17 0.032 0.022 0.048 1 0 force
particle minecraft:cloud 91.18 65.32 17 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 91.18 65.42 17 0.45 0.2 0.45 0.008 1 force
