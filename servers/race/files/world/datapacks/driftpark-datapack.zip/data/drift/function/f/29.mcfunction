scoreboard players set #gx drift -18208
scoreboard players set #gdx drift 1299
scoreboard players set #gz drift 64282
scoreboard players set #gdz drift -45
scoreboard players set #gr drift -9115
scoreboard players set #gdr drift 3
function drift:glide/move/kaze
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0f,0f,0.0013f,1f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.1933f,0.0183f,0.0497f,0.9797f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.053f,0.9799f,0.1925f,0.0019f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.1904f,0.0025f,0.0128f,0.9816f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.0128f,0.9816f,0.1904f,0.0025f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.3722f,0.8591f,0.11f],left_rotation:[0.1903f,0.0145f,-0.0723f,0.979f]}}
scoreboard players set #gx drift -36132
scoreboard players set #gdx drift 1231
scoreboard players set #gz drift 64692
scoreboard players set #gdz drift 36
scoreboard players set #gr drift -9773
scoreboard players set #gdr drift 83
function drift:glide/move/onyx
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0059f,-0.0001f,0.0131f,0.9999f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.3359f,-0.0452f,0.0719f,0.9381f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.0263f,0.9357f,0.3425f,0.0807f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.1904f,0.0025f,0.0128f,0.9816f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.0128f,0.9816f,0.1904f,0.0025f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.3926f,0.8528f,0.2399f],left_rotation:[0.1537f,-0.1031f,0.5687f,0.8015f]}}
particle minecraft:campfire_cosy_smoke -37.65 65.12 64.04 -0.062 0.012 -0.043 1 0 force
