scoreboard players set #gx drift -80204
scoreboard players set #gdx drift -613
scoreboard players set #gz drift -45472
scoreboard players set #gdz drift 172
scoreboard players set #gr drift 3351
scoreboard players set #gdr drift -217
function drift:glide/move/kaze
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0.006f,0.0001f,0.0223f,0.9997f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.6516f,-0.1666f,0.2284f,0.7039f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.1557f,0.6838f,0.6727f,0.236f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.9811f,0.0128f,0.0025f,0.1933f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.0025f,0.1933f,0.9811f,0.0128f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4078f,0.8413f,0.1204f],left_rotation:[0.1598f,0.1147f,-0.5358f,0.8211f]}}
particle minecraft:campfire_cosy_smoke -78.78 65.12 -46.1 0.072 0.022 0.015 1 0 force
particle minecraft:cloud -78.78 65.32 -46.1 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud -80.18 65.32 -47.03 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -80.18 65.42 -47.03 0.45 0.2 0.45 0.008 1 force
scoreboard players set #gx drift -70138
scoreboard players set #gdx drift -778
scoreboard players set #gz drift -46702
scoreboard players set #gdz drift -116
scoreboard players set #gr drift 5638
scoreboard players set #gdr drift -181
function drift:glide/move/onyx
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0.0021f,0f,0.0223f,0.9998f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.7238f,-0.1546f,0.2657f,0.6177f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.2023f,0.5932f,0.744f,0.2315f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.9811f,0.0128f,0.0025f,0.1933f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.0025f,0.1933f,0.9811f,0.0128f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4078f,0.8416f,0.2537f],left_rotation:[0.1787f,0.0726f,-0.3285f,0.9246f]}}
particle minecraft:campfire_cosy_smoke -68.49 65.12 -46.77 0.061 0.022 0.039 1 0 force
particle minecraft:cloud -68.49 65.32 -46.77 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud -69.43 65.32 -48.2 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -69.43 65.42 -48.2 0.45 0.2 0.45 0.008 1 force
