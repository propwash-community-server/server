scoreboard players set #gx drift -54412
scoreboard players set #gdx drift -674
scoreboard players set #gz drift -37333
scoreboard players set #gdz drift -647
scoreboard players set #gr drift 10068
scoreboard players set #gdr drift -232
function drift:glide/move/kaze
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0.0112f,0.0002f,0.0206f,0.9997f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.9478f,-0.1015f,-0.2413f,0.182f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.2618f,0.2084f,-0.9423f,0.0024f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.1561f,0.002f,0.0129f,0.9876f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.0129f,0.9876f,0.1561f,0.002f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.405f,0.8413f,0.1293f],left_rotation:[0.1376f,0.1477f,-0.6885f,0.6966f]}}
particle minecraft:cloud -53.28 65.32 -36.27 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -52.97 65.12 -37.91 0.049 0.022 -0.015 1 0 force
particle minecraft:cloud -52.97 65.32 -37.91 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx drift -45537
scoreboard players set #gdx drift -517
scoreboard players set #gz drift -26619
scoreboard players set #gdz drift -806
scoreboard players set #gr drift 13607
scoreboard players set #gdr drift -322
function drift:glide/move/onyx
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0059f,0f,-0.0011f,1f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.8297f,-0.0867f,-0.0358f,0.5502f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.0938f,-0.557f,0.8252f,0f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.1561f,0.002f,0.0129f,0.9876f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.0129f,0.9876f,0.1561f,0.002f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.3681f,0.8637f,0.2399f],left_rotation:[0.141f,-0.1198f,0.6347f,0.7503f]}}
particle minecraft:campfire_cosy_smoke -43.94 65.12 -26.19 0.046 0.012 0.004 1 0 force
