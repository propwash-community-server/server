scoreboard players set #gx drift 85629
scoreboard players set #gdx drift 409
scoreboard players set #gz drift 26688
scoreboard players set #gdz drift -943
scoreboard players set #gr drift 17734
scoreboard players set #gdr drift -109
function drift:glide/move/kaze
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.002f,0f,0.0223f,0.9998f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.0384f,-0.1955f,0.0457f,0.9789f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.0569f,0.9795f,-0.0181f,0.1925f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.0406f,-0.0005f,0.0131f,0.9991f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.0131f,-0.9991f,0.0406f,0.0005f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4079f,0.8431f,0.1065f],left_rotation:[0.0314f,0.1862f,-0.9601f,0.2063f]}}
particle minecraft:campfire_cosy_smoke 84.86 65.12 28.04 -0.055 0.022 0.057 1 0 force
particle minecraft:cloud 84.86 65.32 28.04 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke 84.86 65.42 28.04 0.45 0.2 0.45 0.008 1 force
particle minecraft:cloud 86.52 65.32 27.96 0.35 0.18 0.35 0.02 2 force
scoreboard players set #gx drift 78473
scoreboard players set #gdx drift 710
scoreboard players set #gz drift 39464
scoreboard players set #gdz drift -834
scoreboard players set #gr drift -16942
scoreboard players set #gdr drift -128
function drift:glide/move/onyx
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0.0038f,0.0001f,0.0223f,0.9997f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.5647f,-0.149f,0.172f,0.7933f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.0895f,0.7796f,0.5835f,0.2092f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.0406f,-0.0005f,0.0131f,0.9991f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.0131f,-0.9991f,0.0406f,0.0005f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4078f,0.8408f,0.2565f],left_rotation:[0.0797f,0.1775f,-0.876f,0.4413f]}}
particle minecraft:campfire_cosy_smoke 77.37 65.12 40.7 -0.084 0.022 0.028 1 0 force
particle minecraft:cloud 77.37 65.32 40.7 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud 79.05 65.32 41.01 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 79.05 65.42 41.01 0.45 0.2 0.45 0.008 1 force
