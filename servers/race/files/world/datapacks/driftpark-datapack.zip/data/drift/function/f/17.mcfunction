scoreboard players set #gx drift -33647
scoreboard players set #gdx drift 1248
scoreboard players set #gz drift 64406
scoreboard players set #gdz drift 37
scoreboard players set #gr drift -9491
scoreboard players set #gdr drift 66
function drift:glide/move/kaze
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0059f,-0.0001f,0.0118f,0.9999f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.218f,-0.0259f,0.0595f,0.9738f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.0425f,0.9729f,0.2219f,0.049f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.2189f,0.0029f,0.0128f,0.9757f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.0128f,0.9757f,0.2189f,0.0029f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.3903f,0.8522f,0.0999f],left_rotation:[0.1748f,-0.0607f,0.3445f,0.9204f]}}
scoreboard players set #gx drift -50026
scoreboard players set #gdx drift 1090
scoreboard players set #gz drift 63128
scoreboard players set #gdz drift 215
scoreboard players set #gr drift -10217
scoreboard players set #gdr drift -24
function drift:glide/move/onyx
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0059f,-0.0001f,0.0178f,0.9998f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.2926f,-0.1545f,0.1039f,0.9379f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.0059f,0.9322f,0.3105f,0.1861f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.2189f,0.0029f,0.0128f,0.9757f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.0128f,0.9757f,0.2189f,0.0029f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4005f,0.8492f,0.2399f],left_rotation:[0.006f,0.1849f,-0.9805f,0.0668f]}}
particle minecraft:campfire_cosy_smoke -51.59 65.12 62.59 -0.07 0.02 -0.044 1 0 force
particle minecraft:cloud -51.59 65.32 62.59 0.35 0.18 0.35 0.02 2 force
particle minecraft:cloud -51.23 65.32 64.26 0.35 0.18 0.35 0.02 2 force
