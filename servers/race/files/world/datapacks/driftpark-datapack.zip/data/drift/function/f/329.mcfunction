scoreboard players set #gx drift -30318
scoreboard players set #gdx drift -669
scoreboard players set #gz drift -13199
scoreboard players set #gdz drift -300
scoreboard players set #gr drift 15014
scoreboard players set #gdr drift 141
function drift:glide/move/kaze
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0.0021f,0f,-0.0223f,0.9998f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.2511f,0.2264f,0.1168f,0.9338f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.0193f,-0.9267f,0.2762f,0.2541f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.5091f,-0.0067f,0.0113f,0.8606f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.0113f,-0.8606f,0.5091f,0.0067f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.3314f,0.8751f,0.1136f],left_rotation:[0.1215f,-0.1497f,0.7336f,0.6516f]}}
particle minecraft:campfire_cosy_smoke -30.39 65.12 -11.65 -0.006 0.022 0.043 1 0 force
particle minecraft:cloud -30.39 65.32 -11.65 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud -28.94 65.32 -12.48 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx drift -20303
scoreboard players set #gdx drift -733
scoreboard players set #gz drift -10173
scoreboard players set #gdz drift -14
scoreboard players set #gr drift 13370
scoreboard players set #gdr drift 138
function drift:glide/move/onyx
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0045f,0.0001f,-0.0223f,0.9997f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.2268f,0.2743f,0.1236f,0.9263f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.0269f,-0.9184f,0.2569f,0.2997f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.5091f,-0.0067f,0.0113f,0.8606f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.0113f,-0.8606f,0.5091f,0.0067f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.3313f,0.8778f,0.2423f],left_rotation:[0.1679f,-0.0809f,0.3866f,0.9032f]}}
particle minecraft:campfire_cosy_smoke -19.87 65.12 -8.58 0.007 0.022 0.037 1 0 force
particle minecraft:cloud -19.87 65.32 -8.58 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -19.87 65.42 -8.58 0.45 0.2 0.45 0.008 1 force
particle minecraft:cloud -18.69 65.32 -9.81 0.35 0.18 0.35 0.02 3 force
