scoreboard players set #gx drift -49698
scoreboard players set #gdx drift -656
scoreboard players set #gz drift -32114
scoreboard players set #gdz drift -790
scoreboard players set #gr drift 11779
scoreboard players set #gdr drift -257
function drift:glide/move/kaze
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.001f,0f,0.0122f,0.9999f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.8733f,-0.1339f,-0.1451f,0.4454f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.1927f,0.4631f,-0.864f,0.0428f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.4219f,0.0055f,0.0119f,0.9066f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.0119f,0.9066f,0.4219f,0.0055f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.3908f,0.851f,0.1082f],left_rotation:[0.0276f,0.1878f,-0.9676f,0.1663f]}}
particle minecraft:campfire_cosy_smoke -48.93 65.12 -30.76 0.014 0.021 0.068 1 0 force
particle minecraft:cloud -48.93 65.32 -30.76 0.35 0.18 0.35 0.02 2 force
particle minecraft:cloud -48.15 65.32 -32.24 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -48.15 65.42 -32.24 0.45 0.2 0.45 0.008 1 force
scoreboard players set #gx drift -41935
scoreboard players set #gdx drift -517
scoreboard players set #gz drift -21284
scoreboard players set #gdz drift -729
scoreboard players set #gr drift 15477
scoreboard players set #gdr drift -210
function drift:glide/move/onyx
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0058f,0.0001f,-0.0117f,0.9999f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.667f,0.0323f,0.1001f,0.7376f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.0231f,-0.7311f,0.6741f,0.1026f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.4219f,0.0055f,0.0119f,0.9066f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.0119f,0.9066f,0.4219f,0.0055f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.3497f,0.8713f,0.24f],left_rotation:[0.1273f,0.1344f,-0.7292f,0.6588f]}}
particle minecraft:campfire_cosy_smoke -42.11 65.12 -19.64 -0.007 0.014 0.06 1 0 force
