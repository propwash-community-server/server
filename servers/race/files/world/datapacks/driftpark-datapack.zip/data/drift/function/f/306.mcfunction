scoreboard players set #gx drift -14431
scoreboard players set #gdx drift -601
scoreboard players set #gz drift -11868
scoreboard players set #gdz drift 165
scoreboard players set #gr drift 11585
scoreboard players set #gdr drift 163
function drift:glide/move/kaze
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0036f,0.0001f,-0.0223f,0.9997f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.1736f,0.2613f,0.1034f,0.9439f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.0048f,-0.9382f,0.202f,0.281f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.7381f,0.0097f,0.0088f,0.6745f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.0088f,0.6745f,0.7381f,0.0097f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.3313f,0.8764f,0.1038f],left_rotation:[0.1503f,-0.1117f,0.5504f,0.8136f]}}
particle minecraft:cloud -13.62 65.32 -10.55 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -12.89 65.12 -12.05 0.054 0.022 -0.053 1 0 force
particle minecraft:cloud -12.89 65.32 -12.05 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx drift -5691
scoreboard players set #gdx drift -601
scoreboard players set #gz drift -15907
scoreboard players set #gdz drift 521
scoreboard players set #gr drift 9455
scoreboard players set #gdr drift 206
function drift:glide/move/onyx
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0.0103f,-0.0002f,-0.0222f,0.9997f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.9411f,0.0732f,-0.326f,0.0511f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.3332f,0.0856f,0.9386f,0.0253f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.7381f,0.0097f,0.0088f,0.6745f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.0088f,0.6745f,0.7381f,0.0097f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.3316f,0.8703f,0.2677f],left_rotation:[0.1993f,-0.0257f,0.0822f,0.9762f]}}
particle minecraft:cloud -4.35 65.32 -14.94 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -4.21 65.12 -16.65 0.027 0.022 -0.061 1 0 force
particle minecraft:cloud -4.21 65.32 -16.65 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -4.21 65.42 -16.65 0.45 0.2 0.45 0.008 1 force
