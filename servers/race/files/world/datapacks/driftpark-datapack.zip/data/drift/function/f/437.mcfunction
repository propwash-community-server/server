scoreboard players set #gx drift -94260
scoreboard players set #gdx drift -267
scoreboard players set #gz drift -30445
scoreboard players set #gdz drift 779
scoreboard players set #gr drift -874
scoreboard players set #gdr drift -71
function drift:glide/move/kaze
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0059f,-0.0001f,0.0174f,0.9998f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.6208f,-0.1876f,-0.0849f,0.7564f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.1648f,0.7695f,-0.6045f,0.1234f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.7142f,-0.0093f,0.0092f,0.6998f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.0092f,-0.6998f,0.7142f,0.0093f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.3998f,0.8478f,0.0999f],left_rotation:[0.0405f,0.1805f,-0.9508f,0.2486f]}}
particle minecraft:campfire_cosy_smoke -93.63 65.12 -31.87 0.044 0.022 -0.046 1 0 force
particle minecraft:cloud -93.63 65.32 -31.87 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud -95.28 65.32 -31.61 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx drift -89993
scoreboard players set #gdx drift -441
scoreboard players set #gz drift -40137
scoreboard players set #gdz drift 550
scoreboard players set #gr drift -283
scoreboard players set #gdr drift -99
function drift:glide/move/onyx
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0058f,-0.0001f,0.0213f,0.9998f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.9315f,-0.0127f,0.2863f,0.224f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.2643f,0.1951f,0.938f,0.1107f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.7142f,-0.0093f,0.0092f,0.6998f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.0092f,-0.6998f,0.7142f,0.0093f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4065f,0.8463f,0.2399f],left_rotation:[0.1543f,0.1022f,-0.5073f,0.8417f]}}
particle minecraft:campfire_cosy_smoke -89.21 65.12 -41.59 0.054 0.022 -0.033 1 0 force
particle minecraft:cloud -89.21 65.32 -41.59 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud -90.92 65.32 -41.51 0.35 0.18 0.35 0.02 3 force
