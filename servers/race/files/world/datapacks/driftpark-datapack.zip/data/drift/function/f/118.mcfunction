scoreboard players set #gx drift 82251
scoreboard players set #gdx drift 543
scoreboard players set #gz drift 32982
scoreboard players set #gdz drift -876
scoreboard players set #gr drift -17444
scoreboard players set #gdr drift -116
function drift:glide/move/kaze
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0.0033f,0.0001f,0.0223f,0.9997f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.2316f,-0.1773f,0.0981f,0.9515f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.0014f,0.9464f,0.2515f,0.2027f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.2358f,0.0031f,0.0127f,0.9717f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.0127f,0.9717f,0.2358f,0.0031f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4079f,0.8419f,0.1157f],left_rotation:[0.0358f,0.1907f,-0.9552f,0.2236f]}}
particle minecraft:cloud 81.29 65.32 34.21 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke 82.96 65.12 34.37 0.014 0.022 0.05 1 0 force
particle minecraft:cloud 82.96 65.32 34.37 0.35 0.18 0.35 0.02 2 force
scoreboard players set #gx drift 72956
scoreboard players set #gdx drift 844
scoreboard players set #gz drift 45022
scoreboard players set #gdz drift -761
scoreboard players set #gr drift -16082
scoreboard players set #gdr drift -117
function drift:glide/move/onyx
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0.0031f,0.0001f,0.0223f,0.9997f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.739f,-0.0999f,0.1983f,0.6361f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.1325f,0.6187f,0.7536f,0.1782f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.2358f,0.0031f,0.0127f,0.9717f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.0127f,0.9717f,0.2358f,0.0031f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4078f,0.8411f,0.2553f],left_rotation:[0.0701f,0.1808f,-0.8981f,0.3949f]}}
particle minecraft:cloud 71.68 65.32 46.08 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 71.68 65.42 46.08 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke 73.3 65.12 46.64 -0.008 0.022 0.053 1 0 force
particle minecraft:cloud 73.3 65.32 46.64 0.35 0.18 0.35 0.02 3 force
