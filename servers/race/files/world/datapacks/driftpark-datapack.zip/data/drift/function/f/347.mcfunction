scoreboard players set #gx drift -41385
scoreboard players set #gdx drift -578
scoreboard players set #gz drift -21772
scoreboard players set #gdz drift -663
scoreboard players set #gr drift 15252
scoreboard players set #gdr drift -170
function drift:glide/move/kaze
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0058f,0.0001f,-0.0117f,0.9999f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.5023f,0.0403f,0.0844f,0.8596f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.0055f,-0.8555f,0.5093f,0.0933f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.8376f,0.011f,0.0071f,0.5461f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.0071f,0.5461f,0.8376f,0.011f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.3497f,0.8697f,0.1f],left_rotation:[0.143f,0.1176f,-0.6418f,0.7442f]}}
particle minecraft:campfire_cosy_smoke -41.52 65.12 -20.22 -0.015 0.013 0.06 1 0 force
scoreboard players set #gx drift -33360
scoreboard players set #gdx drift -653
scoreboard players set #gz drift -13722
scoreboard players set #gdz drift -391
scoreboard players set #gr drift 15887
scoreboard players set #gdr drift 107
function drift:glide/move/onyx
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0048f,0.0001f,-0.0222f,0.9997f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.8085f,0.187f,-0.1883f,0.5253f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.2445f,-0.548f,-0.7933f,0.103f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.8376f,0.011f,0.0071f,0.5461f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.0071f,0.5461f,0.8376f,0.011f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.3314f,0.8779f,0.2418f],left_rotation:[0.1312f,-0.1321f,0.6658f,0.7226f]}}
particle minecraft:campfire_cosy_smoke -33.65 65.12 -12.09 -0.002 0.022 0.037 1 0 force
particle minecraft:cloud -33.65 65.32 -12.09 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -33.65 65.42 -12.09 0.45 0.2 0.45 0.008 1 force
particle minecraft:cloud -32.05 65.32 -12.71 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -32.05 65.42 -12.71 0.45 0.2 0.45 0.008 1 force
