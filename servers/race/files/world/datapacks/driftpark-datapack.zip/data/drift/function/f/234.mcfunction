scoreboard players set #gx drift 27231
scoreboard players set #gdx drift -883
scoreboard players set #gz drift -49351
scoreboard players set #gdz drift 187
scoreboard players set #gr drift 4697
scoreboard players set #gdr drift -164
function drift:glide/move/kaze
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0.0025f,0.0001f,0.0223f,0.9997f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.8251f,-0.0759f,0.2238f,0.5133f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.1711f,0.4926f,0.8376f,0.163f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.8439f,0.011f,0.007f,0.5364f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.007f,0.5364f,0.8439f,0.011f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4079f,0.8421f,0.1144f],left_rotation:[0.0937f,0.1691f,-0.8363f,0.5131f]}}
particle minecraft:cloud 28.76 65.32 -49.63 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 27.62 65.12 -50.86 0.016 0.022 -0.038 1 0 force
particle minecraft:cloud 27.62 65.32 -50.86 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx drift 40178
scoreboard players set #gdx drift -973
scoreboard players set #gz drift -50664
scoreboard players set #gdz drift -112
scoreboard players set #gr drift 6377
scoreboard players set #gdr drift -151
function drift:glide/move/onyx
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0.0052f,0.0001f,0.0223f,0.9997f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.7547f,-0.1949f,-0.1563f,0.6067f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.2209f,0.6264f,-0.7384f,0.1167f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.8439f,0.011f,0.007f,0.5364f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.007f,0.5364f,0.8439f,0.011f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4078f,0.84f,0.2589f],left_rotation:[0.1161f,0.1578f,-0.7632f,0.6157f]}}
particle minecraft:cloud 41.82 65.32 -50.52 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 41.07 65.12 -52.06 0.026 0.022 -0.022 1 0 force
particle minecraft:cloud 41.07 65.32 -52.06 0.35 0.18 0.35 0.02 3 force
