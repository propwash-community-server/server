scoreboard players set #gx drift -96371
scoreboard players set #gdx drift 149
scoreboard players set #gz drift -5935
scoreboard players set #gdz drift 1087
scoreboard players set #gr drift -2569
scoreboard players set #gdr drift 31
function drift:glide/move/kaze
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0059f,-0.0001f,0.0163f,0.9999f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.9594f,-0.0824f,-0.1087f,0.2468f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.1353f,-0.2596f,0.956f,0.0179f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.9822f,-0.0129f,0.0025f,0.1876f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.0025f,-0.1876f,0.9822f,0.0129f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.3978f,0.8487f,0.0999f],left_rotation:[0.08f,-0.1669f,0.8996f,0.3956f]}}
particle minecraft:campfire_cosy_smoke -96.19 65.12 -7.48 0.028 0.017 -0.067 1 0 force
particle minecraft:cloud -96.19 65.32 -7.48 0.35 0.18 0.35 0.02 1 force
particle minecraft:cloud -97.69 65.32 -6.75 0.35 0.18 0.35 0.02 1 force
scoreboard players set #gx drift -97476
scoreboard players set #gdx drift -90
scoreboard players set #gz drift -20251
scoreboard players set #gdz drift 961
scoreboard players set #gr drift -2239
scoreboard players set #gdr drift -82
function drift:glide/move/onyx
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0059f,-0.0001f,0.0186f,0.9998f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.9744f,0.0401f,0.2121f,0.0624f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.2067f,0.0404f,0.9756f,0.0621f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.9822f,-0.0129f,0.0025f,0.1876f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.0025f,-0.1876f,0.9822f,0.0129f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4019f,0.8485f,0.2398f],left_rotation:[0.0572f,0.176f,-0.9226f,0.3384f]}}
particle minecraft:campfire_cosy_smoke -97.22 65.12 -21.89 0.051 0.022 -0.067 1 0 force
particle minecraft:cloud -97.22 65.32 -21.89 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud -98.81 65.32 -21.23 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -98.81 65.42 -21.23 0.45 0.2 0.45 0.008 1 force
