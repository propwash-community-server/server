scoreboard players set #gx drift -72545
scoreboard players set #gdx drift -747
scoreboard players set #gz drift -46087
scoreboard players set #gdz drift -48
scoreboard players set #gr drift 5503
scoreboard players set #gdr drift -208
function drift:glide/move/kaze
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0.0041f,0.0001f,0.0223f,0.9997f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.9586f,0.0462f,0.2796f,0.0285f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.2782f,-0.0008f,0.959f,0.0543f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.4166f,-0.0055f,0.0119f,0.909f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.0119f,-0.909f,0.4166f,0.0055f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4079f,0.8418f,0.117f],left_rotation:[0.159f,0.1126f,-0.5307f,0.8249f]}}
particle minecraft:cloud -70.99 65.32 -46.15 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -71.95 65.12 -47.52 0.017 0.022 -0.033 1 0 force
particle minecraft:cloud -71.95 65.32 -47.52 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx drift -62001
scoreboard players set #gdx drift -694
scoreboard players set #gz drift -44058
scoreboard players set #gdz drift -341
scoreboard players set #gr drift 7453
scoreboard players set #gdr drift -161
function drift:glide/move/onyx
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0.0019f,0f,0.0223f,0.9998f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.6825f,-0.1664f,0.2487f,0.6668f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.18f,0.6444f,0.7037f,0.2391f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.4166f,-0.0055f,0.0119f,0.909f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.0119f,-0.909f,0.4166f,0.0055f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4079f,0.8417f,0.2533f],left_rotation:[0.1723f,0.0863f,-0.3999f,0.8961f]}}
particle minecraft:cloud -60.41 65.32 -43.61 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -60.86 65.12 -45.26 0.018 0.022 -0.013 1 0 force
particle minecraft:cloud -60.86 65.32 -45.26 0.35 0.18 0.35 0.02 3 force
