scoreboard players set #gx drift -75725
scoreboard players set #gdx drift 588
scoreboard players set #gz drift 48010
scoreboard players set #gdz drift 712
scoreboard players set #gr drift -7122
scoreboard players set #gdr drift -142
function drift:glide/move/kaze
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0.0107f,0.0002f,0.0222f,0.9997f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.1258f,-0.2398f,0.023f,0.9624f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.0781f,0.9652f,-0.1013f,0.2279f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.1904f,-0.0025f,0.0128f,0.9816f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.0128f,-0.9816f,0.1904f,0.0025f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4076f,0.8402f,0.1284f],left_rotation:[0.1052f,0.1717f,-0.8118f,0.5481f]}}
particle minecraft:cloud -76.7 65.32 46.8 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -77.23 65.12 48.38 -0.05 0.022 0.006 1 0 force
particle minecraft:cloud -77.23 65.32 48.38 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx drift -83754
scoreboard players set #gdx drift 480
scoreboard players set #gz drift 35306
scoreboard players set #gdz drift 1108
scoreboard players set #gr drift -4854
scoreboard players set #gdr drift -201
function drift:glide/move/onyx
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0.0111f,0.0001f,0.0128f,0.9999f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.1756f,-0.1952f,0.0186f,0.9647f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.0827f,0.9681f,-0.156f,0.1779f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.1904f,-0.0025f,0.0128f,0.9816f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.0128f,-0.9816f,0.1904f,0.0025f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.3917f,0.8445f,0.2691f],left_rotation:[0.0267f,0.2f,-0.9672f,0.1542f]}}
particle minecraft:cloud -84.25 65.32 33.73 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -85.38 65.12 35.01 -0.053 0.021 -0.028 1 0 force
particle minecraft:cloud -85.38 65.32 35.01 0.35 0.18 0.35 0.02 2 force
