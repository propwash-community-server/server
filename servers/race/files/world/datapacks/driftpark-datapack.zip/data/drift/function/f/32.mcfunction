scoreboard players set #gx drift -14311
scoreboard players set #gdx drift 1299
scoreboard players set #gz drift 64144
scoreboard players set #gdz drift -46
scoreboard players set #gr drift -9108
scoreboard players set #gdr drift 3
function drift:glide/move/kaze
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0f,0f,-0.0016f,1f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.8255f,0.047f,0.0239f,0.5619f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.035f,0.5625f,0.8251f,0.0395f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.8247f,0.0108f,0.0074f,0.5654f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.0074f,0.5654f,0.8247f,0.0108f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.3673f,0.8612f,0.11f],left_rotation:[0.1905f,0.0112f,-0.061f,0.9797f]}}
scoreboard players set #gx drift -32408
scoreboard players set #gdx drift 1262
scoreboard players set #gz drift 64769
scoreboard players set #gdz drift 1
scoreboard players set #gr drift -9517
scoreboard players set #gdr drift 75
function drift:glide/move/onyx
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0058f,-0.0001f,0.0111f,0.9999f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.9067f,0.0328f,0.0541f,0.417f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.0105f,0.4136f,0.9083f,0.0623f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.8247f,0.0108f,0.0074f,0.5654f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.0074f,0.5654f,0.8247f,0.0108f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.3891f,0.8544f,0.2399f],left_rotation:[0.1763f,-0.0563f,0.3198f,0.9292f]}}
