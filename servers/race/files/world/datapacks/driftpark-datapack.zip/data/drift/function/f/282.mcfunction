scoreboard players set #gx drift -540
scoreboard players set #gdx drift -561
scoreboard players set #gz drift -23208
scoreboard players set #gdz drift 791
scoreboard players set #gr drift 6673
scoreboard players set #gdr drift 264
function drift:glide/move/kaze
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0.0065f,-0.0001f,-0.0203f,0.9998f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.7146f,0.2062f,-0.1457f,0.6524f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.2151f,-0.6713f,-0.6969f,0.1322f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.776f,0.0102f,0.0083f,0.6305f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.0083f,0.6305f,0.776f,0.0102f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.3349f,0.8728f,0.1211f],left_rotation:[0.1211f,-0.1556f,0.7486f,0.6331f]}}
particle minecraft:cloud 0.99 65.32 -22.96 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 0.33 65.12 -24.49 0.02 0.022 -0.082 1 0 force
particle minecraft:cloud 0.33 65.32 -24.49 0.35 0.18 0.35 0.02 3 force
particle minecraft:flame 1.45 65.22 -24.61 0.05 0.04 0.05 0.02 6 force
particle minecraft:large_smoke 1.45 65.22 -24.61 0.05 0.04 0.05 0.01 2 force
scoreboard players set #gx drift 5526
scoreboard players set #gdx drift -339
scoreboard players set #gz drift -34414
scoreboard players set #gdz drift 782
scoreboard players set #gr drift 2433
scoreboard players set #gdr drift 362
function drift:glide/move/onyx
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0059f,0f,0.0072f,1f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.973f,-0.0527f,0.0044f,0.2246f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.0192f,-0.2253f,0.9728f,0.0493f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.776f,0.0102f,0.0083f,0.6305f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.0083f,0.6305f,0.776f,0.0102f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.3823f,0.8575f,0.2399f],left_rotation:[0.1847f,-0.0113f,0.074f,0.9799f]}}
particle minecraft:flame 6.4 65.24 -36.78 0.05 0.04 0.05 0.02 5 force
particle minecraft:large_smoke 6.4 65.24 -36.78 0.05 0.04 0.05 0.01 2 force
particle minecraft:flame 6.72 65.24 -36.63 0.05 0.04 0.05 0.02 5 force
particle minecraft:large_smoke 6.72 65.24 -36.63 0.05 0.04 0.05 0.01 2 force
playsound driftpark:lap.onyx.05.103 neutral @a 5.85 65.5 -35.2 12 1
playsound driftpark:lap.onyx.05.104 neutral @a 3.14 65.5 -28.73 12 1
playsound driftpark:lap.onyx.05.105 neutral @a -0.37 65.5 -21.89 12 1
playsound driftpark:lap.onyx.05.106 neutral @a -5.09 65.5 -16.46 12 1
playsound driftpark:lap.onyx.05.107 neutral @a -9.9 65.5 -12.84 12 1
playsound driftpark:lap.onyx.05.108 neutral @a -14.81 65.5 -10.83 12 1
playsound driftpark:lap.onyx.05.109 neutral @a -20.3 65.5 -10.17 12 1
playsound driftpark:lap.onyx.05.110 neutral @a -26.29 65.5 -10.91 12 1
