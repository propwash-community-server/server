scoreboard players set #gx drift -57025
scoreboard players set #gdx drift 974
scoreboard players set #gz drift 60502
scoreboard players set #gdz drift 327
scoreboard players set #gr drift -9492
scoreboard players set #gdr drift -67
function drift:glide/move/kaze
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0058f,-0.0001f,0.0188f,0.9998f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.8516f,-0.041f,0.1773f,0.4917f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.1266f,0.4757f,0.8606f,0.1307f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.8707f,0.0114f,0.0064f,0.4916f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.0064f,0.4916f,0.8707f,0.0114f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4021f,0.8467f,0.0999f],left_rotation:[-0.0017f,0.1851f,-0.9823f,0.0281f]}}
particle minecraft:campfire_cosy_smoke -58.4 65.12 59.78 -0.059 0.02 -0.048 1 0 force
particle minecraft:cloud -58.4 65.32 59.78 0.35 0.18 0.35 0.02 2 force
particle minecraft:cloud -58.26 65.32 61.45 0.35 0.18 0.35 0.02 2 force
scoreboard players set #gx drift -69378
scoreboard players set #gdx drift 740
scoreboard players set #gz drift 55277
scoreboard players set #gdz drift 518
scoreboard players set #gr drift -8799
scoreboard players set #gdr drift -89
function drift:glide/move/onyx
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0059f,-0.0001f,0.0218f,0.9997f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.828f,-0.0772f,0.2297f,0.5056f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.1779f,0.4843f,0.8407f,0.1646f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.8707f,0.0114f,0.0064f,0.4916f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.0064f,0.4916f,0.8707f,0.0114f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4072f,0.8459f,0.2399f],left_rotation:[0.0988f,0.1564f,-0.8071f,0.5606f]}}
particle minecraft:campfire_cosy_smoke -70.76 65.12 54.37 -0.038 0.022 -0.061 1 0 force
particle minecraft:cloud -70.76 65.32 54.37 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud -70.82 65.32 56.08 0.35 0.18 0.35 0.02 3 force
