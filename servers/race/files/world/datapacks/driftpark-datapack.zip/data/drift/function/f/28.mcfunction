scoreboard players set #gx drift -19506
scoreboard players set #gdx drift 1299
scoreboard players set #gz drift 64325
scoreboard players set #gdz drift -43
scoreboard players set #gr drift -9119
scoreboard players set #gdr drift 4
function drift:glide/move/kaze
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0f,0f,0.0022f,1f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.8953f,-0.0433f,0.0305f,0.4424f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.0158f,-0.4416f,0.8956f,0.0505f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.8978f,-0.0118f,0.0058f,0.4402f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.0058f,-0.4402f,0.8978f,0.0118f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.3738f,0.8583f,0.11f],left_rotation:[0.1903f,0.0145f,-0.0701f,0.9791f]}}
scoreboard players set #gx drift -37353
scoreboard players set #gdx drift 1220
scoreboard players set #gz drift 64641
scoreboard players set #gdz drift 51
scoreboard players set #gr drift -9859
scoreboard players set #gdr drift 86
function drift:glide/move/onyx
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0059f,-0.0001f,0.0137f,0.9999f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.8205f,-0.0875f,-0.0347f,0.5638f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.0941f,0.5706f,-0.8158f,0.0018f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.8978f,-0.0118f,0.0058f,0.4402f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.0058f,-0.4402f,0.8978f,0.0118f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.3936f,0.8524f,0.2399f],left_rotation:[0.1424f,-0.1182f,0.6485f,0.7384f]}}
particle minecraft:campfire_cosy_smoke -38.62 65.12 65.7 -0.06 0.013 0.044 1 0 force
