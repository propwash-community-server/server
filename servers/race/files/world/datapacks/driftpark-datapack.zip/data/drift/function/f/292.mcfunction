scoreboard players set #gx drift -6290
scoreboard players set #gdx drift -582
scoreboard players set #gz drift -16578
scoreboard players set #gdz drift 504
scoreboard players set #gr drift 9004
scoreboard players set #gdr drift 203
function drift:glide/move/kaze
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0.0103f,-0.0002f,-0.0222f,0.9997f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.8411f,0.1884f,-0.2369f,0.4483f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.2853f,-0.4757f,-0.8259f,0.101f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.9832f,0.0129f,0.0024f,0.1819f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.0024f,0.1819f,0.9832f,0.0129f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.3315f,0.8732f,0.1277f],left_rotation:[0.1825f,-0.0841f,0.3701f,0.907f]}}
particle minecraft:cloud -4.98 65.32 -15.74 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -4.98 65.12 -17.41 0.035 0.022 -0.058 1 0 force
particle minecraft:cloud -4.98 65.32 -17.41 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx drift 2001
scoreboard players set #gdx drift -403
scoreboard players set #gz drift -26167
scoreboard players set #gdz drift 872
scoreboard players set #gr drift 5945
scoreboard players set #gdr drift 288
function drift:glide/move/onyx
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0057f,0.0001f,-0.0136f,0.9999f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.7059f,0.1192f,0.2042f,0.6677f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.1352f,-0.6499f,0.7223f,0.194f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.9832f,0.0129f,0.0024f,0.1819f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.0024f,0.1819f,0.9832f,0.0129f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.3464f,0.8725f,0.2403f],left_rotation:[0.0914f,-0.1612f,0.8414f,0.5077f]}}
particle minecraft:cloud 3.65 65.32 -26.15 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 2.78 65.12 -27.62 0.005 0.022 -0.079 1 0 force
particle minecraft:cloud 2.78 65.32 -27.62 0.35 0.18 0.35 0.02 3 force
