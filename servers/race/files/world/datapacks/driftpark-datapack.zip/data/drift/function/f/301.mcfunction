scoreboard players set #gx drift -11515
scoreboard players set #gdx drift -581
scoreboard players set #gz drift -13004
scoreboard players set #gdz drift 272
scoreboard players set #gr drift 10663
scoreboard players set #gdr drift 199
function drift:glide/move/kaze
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0.0049f,-0.0001f,-0.0223f,0.9997f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.9239f,0.127f,-0.2601f,0.2501f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.2879f,-0.2789f,-0.9157f,0.0306f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.5486f,0.0072f,0.0109f,0.836f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.0109f,0.836f,0.5486f,0.0072f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.3314f,0.8745f,0.1184f],left_rotation:[0.1659f,-0.1036f,0.4819f,0.8541f]}}
particle minecraft:campfire_cosy_smoke -10.5 65.12 -11.83 0.018 0.022 0.022 1 0 force
particle minecraft:cloud -10.5 65.32 -11.83 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud -10.02 65.32 -13.43 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -10.02 65.42 -13.43 0.45 0.2 0.45 0.008 1 force
scoreboard players set #gx drift -2704
scoreboard players set #gdx drift -593
scoreboard players set #gz drift -18946
scoreboard players set #gdz drift 666
scoreboard players set #gr drift 8343
scoreboard players set #gdr drift 241
function drift:glide/move/onyx
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0.0112f,-0.0002f,-0.0218f,0.9997f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.9472f,-0.054f,0.3159f,0.0036f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.3173f,0.0296f,0.9468f,0.0453f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.5486f,0.0072f,0.0109f,0.836f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.0109f,0.836f,0.5486f,0.0072f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.3324f,0.8695f,0.2692f],left_rotation:[0.195f,-0.0518f,0.2098f,0.9567f]}}
particle minecraft:campfire_cosy_smoke -1.2 65.12 -18.26 0.037 0.022 0.012 1 0 force
particle minecraft:cloud -1.2 65.32 -18.26 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud -1.4 65.32 -19.96 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -1.4 65.42 -19.96 0.45 0.2 0.45 0.008 1 force
