scoreboard players set #gx drift -25353
scoreboard players set #gdx drift -728
scoreboard players set #gz drift -11621
scoreboard players set #gdz drift -165
scoreboard players set #gr drift 13985
scoreboard players set #gdr drift 171
function drift:glide/move/kaze
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0009f,0f,-0.0223f,0.9998f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.8809f,0.156f,-0.2185f,0.3899f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.2606f,-0.415f,-0.8693f,0.0643f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.2527f,-0.0033f,0.0127f,0.9675f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.0127f,-0.9675f,0.2527f,0.0033f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.3314f,0.8758f,0.1084f],left_rotation:[0.1377f,-0.1307f,0.6434f,0.7416f]}}
particle minecraft:cloud -25.15 65.32 -10.08 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -23.87 65.12 -11.16 0.073 0.022 -0.021 1 0 force
particle minecraft:cloud -23.87 65.32 -11.16 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx drift -15449
scoreboard players set #gdx drift -660
scoreboard players set #gz drift -10678
scoreboard players set #gdz drift 135
scoreboard players set #gr drift 12354
scoreboard players set #gdr drift 174
function drift:glide/move/onyx
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0053f,0.0001f,-0.0223f,0.9997f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.8597f,0.0806f,0.2993f,0.4061f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.2582f,-0.3769f,0.8729f,0.1714f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.2527f,-0.0033f,0.0127f,0.9675f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.0127f,-0.9675f,0.2527f,0.0033f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.3313f,0.8782f,0.2409f],left_rotation:[0.1736f,-0.0657f,0.3066f,0.9336f]}}
particle minecraft:cloud -14.74 65.32 -9.18 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -13.8 65.12 -10.61 0.046 0.022 -0.041 1 0 force
particle minecraft:cloud -13.8 65.32 -10.61 0.35 0.18 0.35 0.02 3 force
