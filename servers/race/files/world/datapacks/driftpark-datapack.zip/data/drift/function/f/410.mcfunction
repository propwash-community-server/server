scoreboard players set #gx drift -83103
scoreboard players set #gdx drift -528
scoreboard players set #gz drift -44445
scoreboard players set #gdz drift 254
scoreboard players set #gr drift 2340
scoreboard players set #gdr drift -212
function drift:glide/move/kaze
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0.0025f,0.0001f,0.0223f,0.9997f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.7189f,-0.218f,-0.1633f,0.6396f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.2314f,0.6602f,-0.6999f,0.1436f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.9984f,-0.0131f,0.0007f,0.0551f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.0007f,-0.0551f,0.9984f,0.0131f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4079f,0.8421f,0.1142f],left_rotation:[0.145f,0.1276f,-0.6148f,0.7647f]}}
particle minecraft:cloud -81.82 65.32 -45.32 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -81.82 65.42 -45.32 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke -83.35 65.12 -45.98 -0.004 0.022 -0.038 1 0 force
particle minecraft:cloud -83.35 65.32 -45.98 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -83.35 65.42 -45.98 0.45 0.2 0.45 0.008 1 force
scoreboard players set #gx drift -74012
scoreboard players set #gdx drift -762
scoreboard players set #gz drift -47061
scoreboard players set #gdz drift -5
scoreboard players set #gr drift 4664
scoreboard players set #gdr drift -214
function drift:glide/move/onyx
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0.005f,0.0001f,0.0223f,0.9997f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.2657f,-0.2841f,0.1403f,0.9105f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.0454f,0.9008f,0.297f,0.3136f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.9984f,-0.0131f,0.0007f,0.0551f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.0007f,-0.0551f,0.9984f,0.0131f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4078f,0.8401f,0.2586f],left_rotation:[0.1873f,0.057f,-0.2433f,0.95f]}}
particle minecraft:cloud -72.4 65.32 -47.41 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -73.57 65.12 -48.65 0.02 0.022 -0.031 1 0 force
particle minecraft:cloud -73.57 65.32 -48.65 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -73.57 65.42 -48.65 0.45 0.2 0.45 0.008 1 force
particle minecraft:flame -72.31 65.24 -48.91 0.05 0.04 0.05 0.02 5 force
particle minecraft:large_smoke -72.31 65.24 -48.91 0.05 0.04 0.05 0.01 2 force
particle minecraft:flame -72.06 65.24 -48.65 0.05 0.04 0.05 0.02 5 force
particle minecraft:large_smoke -72.06 65.24 -48.65 0.05 0.04 0.05 0.01 2 force
