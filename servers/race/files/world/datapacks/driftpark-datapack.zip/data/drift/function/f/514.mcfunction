scoreboard players set #gx drift -74547
scoreboard players set #gdx drift 594
scoreboard players set #gz drift 49405
scoreboard players set #gdz drift 655
scoreboard players set #gr drift -7402
scoreboard players set #gdr drift -135
function drift:glide/move/kaze
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0.0096f,0.0002f,0.0222f,0.9997f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.594f,-0.2164f,-0.0993f,0.7684f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.1806f,0.7831f,-0.5745f,0.1552f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.6594f,-0.0086f,0.0098f,0.7517f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.0098f,-0.7517f,0.6594f,0.0086f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4078f,0.8404f,0.1266f],left_rotation:[0.0999f,0.1736f,-0.8265f,0.5261f]}}
particle minecraft:cloud -75.58 65.32 48.24 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -76.04 65.12 49.85 -0.037 0.022 0.003 1 0 force
particle minecraft:cloud -76.04 65.32 49.85 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -76.04 65.42 49.85 0.45 0.2 0.45 0.008 1 force
scoreboard players set #gx drift -82792
scoreboard players set #gdx drift 489
scoreboard players set #gz drift 37501
scoreboard players set #gdz drift 1063
scoreboard players set #gr drift -5257
scoreboard players set #gdr drift -199
function drift:glide/move/onyx
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0.0111f,0.0002f,0.0151f,0.9998f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.6283f,-0.1935f,-0.0927f,0.7478f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.1718f,0.7617f,-0.6114f,0.1285f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.6594f,-0.0086f,0.0098f,0.7517f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.0098f,-0.7517f,0.6594f,0.0086f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.3957f,0.8426f,0.2691f],left_rotation:[0.0608f,0.1924f,-0.9246f,0.3232f]}}
particle minecraft:cloud -83.4 65.32 35.96 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -84.44 65.12 37.32 -0.044 0.022 -0.013 1 0 force
particle minecraft:cloud -84.44 65.32 37.32 0.35 0.18 0.35 0.02 3 force
