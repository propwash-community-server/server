scoreboard players set #gx drift 73281
scoreboard players set #gdx drift 810
scoreboard players set #gz drift 43702
scoreboard players set #gdz drift -768
scoreboard players set #gr drift -15846
scoreboard players set #gdr drift -119
function drift:glide/move/kaze
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0.0032f,0.0001f,0.0223f,0.9997f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.8454f,-0.1419f,-0.1363f,0.4966f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.1892f,0.5137f,-0.8351f,0.0538f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.8621f,-0.0113f,0.0066f,0.5066f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.0066f,-0.5066f,0.8621f,0.0113f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4079f,0.842f,0.1156f],left_rotation:[0.0249f,0.1924f,-0.9663f,0.1689f]}}
particle minecraft:campfire_cosy_smoke 72.02 65.12 44.61 -0.079 0.021 0.017 1 0 force
particle minecraft:cloud 72.02 65.32 44.61 0.35 0.18 0.35 0.02 2 force
particle minecraft:cloud 73.58 65.32 45.23 0.35 0.18 0.35 0.02 2 force
scoreboard players set #gx drift 60554
scoreboard players set #gdx drift 1045
scoreboard players set #gz drift 53591
scoreboard players set #gdz drift -555
scoreboard players set #gr drift -14625
scoreboard players set #gdr drift -111
function drift:glide/move/onyx
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0.004f,0.0001f,0.0223f,0.9997f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.4568f,-0.2113f,-0.0513f,0.8626f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.1422f,0.8728f,-0.4371f,0.1644f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.8621f,-0.0113f,0.0066f,0.5066f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.0066f,-0.5066f,0.8621f,0.0113f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4078f,0.8406f,0.2569f],left_rotation:[0.0623f,0.1845f,-0.9144f,0.3549f]}}
particle minecraft:campfire_cosy_smoke 59.06 65.12 54.29 -0.09 0.022 0.01 1 0 force
particle minecraft:cloud 59.06 65.32 54.29 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 59.06 65.42 54.29 0.45 0.2 0.45 0.008 1 force
particle minecraft:cloud 60.48 65.32 55.24 0.35 0.18 0.35 0.02 3 force
playsound driftpark:lap.onyx.02.081 neutral @a 60.55 65.5 53.59 12 1
playsound driftpark:lap.onyx.02.082 neutral @a 68.48 65.5 48.63 12 1
playsound driftpark:lap.onyx.02.083 neutral @a 75.43 65.5 42.7 12 1
playsound driftpark:lap.onyx.02.084 neutral @a 81.19 65.5 36.08 12 1
playsound driftpark:lap.onyx.02.085 neutral @a 85.56 65.5 28.94 12 1
playsound driftpark:lap.onyx.02.086 neutral @a 88.64 65.5 21.12 12 1
playsound driftpark:lap.onyx.02.087 neutral @a 90.45 65.5 12.73 12 1
playsound driftpark:lap.onyx.02.088 neutral @a 90.93 65.5 4.09 12 1
playsound driftpark:lap.onyx.02.089 neutral @a 90.03 65.5 -4.53 12 1
