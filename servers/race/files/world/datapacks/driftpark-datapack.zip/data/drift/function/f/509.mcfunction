scoreboard players set #gx drift -77462
scoreboard players set #gdx drift 574
scoreboard players set #gz drift 45700
scoreboard players set #gdz drift 798
scoreboard players set #gr drift -6637
scoreboard players set #gdr drift -171
function drift:glide/move/kaze
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0.0111f,0.0002f,0.0215f,0.9997f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.7656f,-0.1857f,-0.1506f,0.5973f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.2142f,0.6164f,-0.7503f,0.1063f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.8247f,-0.0108f,0.0074f,0.5654f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.0074f,-0.5654f,0.8247f,0.0108f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4066f,0.8406f,0.1291f],left_rotation:[0.1025f,0.1737f,-0.8214f,0.5335f]}}
particle minecraft:campfire_cosy_smoke -78.33 65.12 44.41 -0.013 0.022 -0.068 1 0 force
particle minecraft:cloud -78.33 65.32 44.41 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud -79 65.32 45.94 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx drift -85279
scoreboard players set #gdx drift 524
scoreboard players set #gz drift 31894
scoreboard players set #gdz drift 1152
scoreboard players set #gr drift -4224
scoreboard players set #gdr drift -210
function drift:glide/move/onyx
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0.0104f,0.0001f,0.0108f,0.9999f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.8152f,-0.1303f,-0.0971f,0.5559f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.156f,0.5692f,-0.806f,0.0453f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.8247f,-0.0108f,0.0074f,0.5654f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.0074f,-0.5654f,0.8247f,0.0108f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.3884f,0.8464f,0.2679f],left_rotation:[0.0376f,-0.1975f,0.9661f,0.1622f]}}
particle minecraft:campfire_cosy_smoke -85.6 65.12 30.27 -0.002 0.018 -0.085 1 0 force
particle minecraft:cloud -85.6 65.32 30.27 0.35 0.18 0.35 0.02 2 force
particle minecraft:cloud -86.86 65.32 31.42 0.35 0.18 0.35 0.02 2 force
