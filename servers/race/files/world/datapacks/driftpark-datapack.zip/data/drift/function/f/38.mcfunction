scoreboard players set #gx drift -6516
scoreboard players set #gdx drift 1299
scoreboard players set #gz drift 63907
scoreboard players set #gdz drift -30
scoreboard players set #gr drift -9075
scoreboard players set #gdr drift 1
function drift:glide/move/kaze
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0f,0f,-0.0019f,1f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.5735f,-0.0275f,0.0446f,0.8175f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.0411f,-0.8173f,0.5738f,0.0326f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.5774f,-0.0076f,0.0107f,0.8164f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.0107f,-0.8164f,0.5774f,0.0076f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.3667f,0.8614f,0.11f],left_rotation:[0.1907f,0.0049f,-0.0292f,0.9812f]}}
scoreboard players set #gx drift -24700
scoreboard players set #gdx drift 1300
scoreboard players set #gz drift 64636
scoreboard players set #gdz drift -50
scoreboard players set #gr drift -9182
scoreboard players set #gdr drift 27
function drift:glide/move/onyx
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0003f,0f,0.006f,1f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.3993f,-0.0189f,0.0488f,0.9153f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.0471f,-0.9152f,0.3995f,0.0229f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.5774f,-0.0076f,0.0107f,0.8164f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.0107f,-0.8164f,0.5774f,0.0076f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.3804f,0.8556f,0.2496f],left_rotation:[0.1905f,0.0049f,-0.0134f,0.9816f]}}
