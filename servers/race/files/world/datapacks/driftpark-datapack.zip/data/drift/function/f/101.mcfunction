scoreboard players set #gx drift 69859
scoreboard players set #gdx drift 882
scoreboard players set #gz drift 46653
scoreboard players set #gdz drift -718
scoreboard players set #gr drift -15380
scoreboard players set #gdr drift -111
function drift:glide/move/kaze
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0.0026f,0.0001f,0.0223f,0.9997f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.0166f,-0.1859f,0.0564f,0.9808f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.0463f,0.9803f,0.0363f,0.1887f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.0174f,0.0002f,0.0131f,0.9998f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.0131f,0.9998f,0.0174f,0.0002f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4079f,0.8421f,0.1144f],left_rotation:[0.0204f,0.1922f,-0.9701f,0.1469f]}}
particle minecraft:campfire_cosy_smoke 68.53 65.12 47.46 -0.088 0.021 0.012 1 0 force
particle minecraft:cloud 68.53 65.32 47.46 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke 68.53 65.42 47.46 0.45 0.2 0.45 0.008 1 force
particle minecraft:cloud 70.03 65.32 48.2 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke 70.03 65.42 48.2 0.45 0.2 0.45 0.008 1 force
scoreboard players set #gx drift 56178
scoreboard players set #gdx drift 1126
scoreboard players set #gz drift 55665
scoreboard players set #gdz drift -496
scoreboard players set #gr drift -14188
scoreboard players set #gdr drift -118
function drift:glide/move/onyx
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0.0073f,0.0002f,0.0223f,0.9997f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.5089f,-0.1515f,0.1553f,0.833f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.0686f,0.8213f,0.5277f,0.2058f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.0174f,0.0002f,0.0131f,0.9998f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.0131f,0.9998f,0.0174f,0.0002f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4077f,0.8389f,0.2626f],left_rotation:[0.0625f,0.1879f,-0.9153f,0.3507f]}}
particle minecraft:campfire_cosy_smoke 54.63 65.12 56.25 -0.093 0.022 0 1 0 force
particle minecraft:cloud 54.63 65.32 56.25 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud 55.98 65.32 57.31 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 55.98 65.42 57.31 0.45 0.2 0.45 0.008 1 force
