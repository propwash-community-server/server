scoreboard players set #gx drift 12039
scoreboard players set #gdx drift -509
scoreboard players set #gz drift -42037
scoreboard players set #gdz drift 489
scoreboard players set #gr drift 1233
scoreboard players set #gdr drift -75
function drift:glide/move/kaze
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0024f,-0.0001f,0.0219f,0.9998f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.9709f,-0.0682f,-0.2205f,0.0632f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.2284f,-0.0867f,0.9691f,0.0335f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.1676f,0.0022f,0.0129f,0.9858f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.0129f,0.9858f,0.1676f,0.0022f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4073f,0.8435f,0.1059f],left_rotation:[0.0826f,0.1694f,-0.8629f,0.4689f]}}
particle minecraft:campfire_cosy_smoke 13.14 65.12 -43.14 0.057 0.022 -0.01 1 0 force
particle minecraft:cloud 13.14 65.32 -43.14 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud 11.5 65.32 -43.49 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx drift 20971
scoreboard players set #gdx drift -810
scoreboard players set #gz drift -48484
scoreboard players set #gdz drift 322
scoreboard players set #gr drift 3024
scoreboard players set #gdr drift -195
function drift:glide/move/onyx
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0.0057f,0.0001f,0.0223f,0.9997f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.9561f,0.0372f,0.2845f,0.0586f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.2799f,0.0291f,0.9575f,0.0631f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.1676f,0.0022f,0.0129f,0.9858f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.0129f,0.9858f,0.1676f,0.0022f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4078f,0.8398f,0.2599f],left_rotation:[0.1641f,0.108f,-0.5022f,0.8421f]}}
particle minecraft:campfire_cosy_smoke 22.42 65.12 -49.28 0.073 0.022 0.012 1 0 force
particle minecraft:cloud 22.42 65.32 -49.28 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 22.42 65.42 -49.28 0.45 0.2 0.45 0.008 1 force
particle minecraft:cloud 20.94 65.32 -50.14 0.35 0.18 0.35 0.02 3 force
