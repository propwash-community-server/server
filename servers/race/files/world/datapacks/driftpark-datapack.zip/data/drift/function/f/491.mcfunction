scoreboard players set #gx drift -87065
scoreboard players set #gdx drift 498
scoreboard players set #gz drift 27017
scoreboard players set #gdz drift 1200
scoreboard players set #gr drift -3283
scoreboard players set #gdr drift -159
function drift:glide/move/kaze
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0.0018f,0f,0.0112f,0.9999f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.6502f,-0.0323f,0.0973f,0.7529f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.0187f,0.7468f,0.6571f,0.1008f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.6008f,0.0079f,0.0105f,0.7993f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.0105f,0.7993f,0.6008f,0.0079f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.3892f,0.8511f,0.1131f],left_rotation:[0.1362f,-0.1362f,0.7091f,0.6782f]}}
particle minecraft:campfire_cosy_smoke -87.07 65.12 25.46 0.016 0.013 -0.092 1 0 force
scoreboard players set #gx drift -93204
scoreboard players set #gdx drift 342
scoreboard players set #gz drift 10070
scoreboard players set #gdz drift 1198
scoreboard players set #gr drift -2465
scoreboard players set #gdr drift -26
function drift:glide/move/onyx
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0059f,-0.0001f,0.0103f,0.9999f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.5211f,-0.0267f,0.0779f,0.8495f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.0109f,0.846f,0.5268f,0.0817f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.6008f,0.0079f,0.0105f,0.7993f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.0105f,0.7993f,0.6008f,0.0079f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.3877f,0.8551f,0.2399f],left_rotation:[0.1564f,-0.099f,0.5427f,0.8193f]}}
