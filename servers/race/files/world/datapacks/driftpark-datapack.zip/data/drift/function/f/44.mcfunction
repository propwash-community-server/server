scoreboard players set #gx drift 1280
scoreboard players set #gdx drift 1299
scoreboard players set #gz drift 63744
scoreboard players set #gdz drift -27
scoreboard players set #gr drift -9123
scoreboard players set #gdr drift -27
function drift:glide/move/kaze
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0f,0f,0.0014f,1f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.8093f,0.0416f,0.0318f,0.5851f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.0296f,0.585f,0.8094f,0.0432f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.8079f,0.0106f,0.0077f,0.5891f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.0077f,0.5891f,0.8079f,0.0106f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.3724f,0.859f,0.11f],left_rotation:[0.1908f,-0.0021f,0.0134f,0.9815f]}}
scoreboard players set #gx drift -16907
scoreboard players set #gdx drift 1298
scoreboard players set #gz drift 64269
scoreboard players set #gdz drift -70
scoreboard players set #gr drift -9098
scoreboard players set #gdr drift 3
function drift:glide/move/onyx
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0f,0f,0.0003f,1f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.9223f,0.0519f,0.0114f,0.3827f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.0287f,0.3836f,0.922f,0.0447f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.8079f,0.0106f,0.0077f,0.5891f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.0077f,0.5891f,0.8079f,0.0106f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.3705f,0.8598f,0.25f],left_rotation:[0.1901f,0.0161f,-0.0825f,0.9782f]}}
