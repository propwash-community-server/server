scoreboard players set #gx drift 78544
scoreboard players set #gdx drift 671
scoreboard players set #gz drift 38106
scoreboard players set #gdz drift -836
scoreboard players set #gr drift -16712
scoreboard players set #gdr drift -117
function drift:glide/move/kaze
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.9483f,-0.1004f,-0.1752f,0.2449f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.2019f,0.2647f,-0.943f,0.0012f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.9682f,-0.0127f,0.0033f,0.2499f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.0033f,-0.2499f,0.9682f,0.0127f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4079f,0.8418f,0.1166f],left_rotation:[0.0344f,0.1915f,-0.9567f,0.2164f]}}
particle minecraft:cloud 77.44 65.32 39.2 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke 79.07 65.12 39.57 0.007 0.022 0.049 1 0 force
particle minecraft:cloud 79.07 65.32 39.57 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke 79.07 65.42 39.57 0.45 0.2 0.45 0.008 1 force
scoreboard players set #gx drift 67535
scoreboard players set #gdx drift 943
scoreboard players set #gz drift 49311
scoreboard players set #gdz drift -679
scoreboard players set #gr drift -15388
scoreboard players set #gdr drift -116
function drift:glide/move/onyx
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0.0018f,0f,0.0223f,0.9998f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.6494f,-0.1941f,-0.1013f,0.7282f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.1784f,0.7429f,-0.6326f,0.1269f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.9682f,-0.0127f,0.0033f,0.2499f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.0033f,-0.2499f,0.9682f,0.0127f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4079f,0.8418f,0.2531f],left_rotation:[0.0643f,0.1815f,-0.9094f,0.3686f]}}
particle minecraft:cloud 66.14 65.32 50.2 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 66.14 65.42 50.2 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke 67.68 65.12 50.96 -0.016 0.022 0.054 1 0 force
particle minecraft:cloud 67.68 65.32 50.96 0.35 0.18 0.35 0.02 3 force
