scoreboard players set #gx drift -28238
scoreboard players set #gdx drift -704
scoreboard players set #gz drift -12405
scoreboard players set #gdz drift -246
scoreboard players set #gr drift 14607
scoreboard players set #gdr drift 134
function drift:glide/move/kaze
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0.0017f,0f,-0.0223f,0.9998f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.4906f,0.1953f,0.1784f,0.8302f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.0921f,-0.8161f,0.5139f,0.248f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.9667f,-0.0127f,0.0033f,0.2555f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.0033f,-0.2555f,0.9667f,0.0127f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.3314f,0.8752f,0.113f],left_rotation:[0.1346f,-0.1376f,0.6704f,0.7166f]}}
particle minecraft:cloud -28.2 65.32 -10.85 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -26.81 65.12 -11.78 0.068 0.022 -0.017 1 0 force
particle minecraft:cloud -26.81 65.32 -11.78 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx drift -18159
scoreboard players set #gdx drift -703
scoreboard players set #gz drift -10263
scoreboard players set #gdz drift 51
scoreboard players set #gr drift 12971
scoreboard players set #gdr drift 119
function drift:glide/move/onyx
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0051f,0.0001f,-0.0223f,0.9997f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.2413f,0.2763f,0.1291f,0.9213f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.033f,-0.9128f,0.2717f,0.3032f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.9667f,-0.0127f,0.0033f,0.2555f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.0033f,-0.2555f,0.9667f,0.0127f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.3313f,0.8781f,0.2412f],left_rotation:[0.1705f,-0.074f,0.3507f,0.9179f]}}
particle minecraft:cloud -17.62 65.32 -8.7 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -16.52 65.12 -10.02 0.057 0.022 -0.03 1 0 force
particle minecraft:cloud -16.52 65.32 -10.02 0.35 0.18 0.35 0.02 3 force
