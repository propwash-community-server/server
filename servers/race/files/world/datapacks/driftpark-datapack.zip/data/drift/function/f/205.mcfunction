scoreboard players set #gx drift 55382
scoreboard players set #gdx drift -1091
scoreboard players set #gz drift -45252
scoreboard players set #gdz drift -483
scoreboard players set #gr drift 8948
scoreboard players set #gdr drift -136
function drift:glide/move/kaze
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0.0111f,0.0002f,0.0221f,0.9997f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.7185f,-0.0892f,0.1743f,0.6674f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.1051f,0.6527f,0.7318f,0.1652f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.7263f,0.0095f,0.009f,0.6873f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.009f,0.6873f,0.7263f,0.0095f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4076f,0.8401f,0.1291f],left_rotation:[0.0242f,0.2003f,-0.9662f,0.1603f]}}
particle minecraft:campfire_cosy_smoke 56.7 65.12 -44.43 0.052 0.021 0.063 1 0 force
particle minecraft:cloud 56.7 65.32 -44.43 0.35 0.18 0.35 0.02 2 force
particle minecraft:cloud 56.68 65.32 -46.1 0.35 0.18 0.35 0.02 2 force
scoreboard players set #gx drift 70248
scoreboard players set #gdx drift -923
scoreboard players set #gz drift -37099
scoreboard players set #gdz drift -703
scoreboard players set #gr drift 10108
scoreboard players set #gdr drift -84
function drift:glide/move/onyx
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.9245f,-0.1163f,-0.1732f,0.3189f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.2077f,0.3388f,-0.9174f,0.0198f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.7263f,0.0095f,0.009f,0.6873f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.009f,0.6873f,0.7263f,0.0095f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.408f,0.8455f,0.24f],left_rotation:[0.0444f,0.1797f,-0.9425f,0.2782f]}}
particle minecraft:campfire_cosy_smoke 71.47 65.12 -35.99 0.042 0.022 0.084 1 0 force
particle minecraft:cloud 71.47 65.32 -35.99 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud 71.8 65.32 -37.67 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 71.8 65.42 -37.67 0.45 0.2 0.45 0.008 1 force
