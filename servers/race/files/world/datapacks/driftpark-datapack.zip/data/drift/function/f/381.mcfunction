scoreboard players set #gx drift -63081
scoreboard players set #gdx drift -673
scoreboard players set #gz drift -43586
scoreboard players set #gdz drift -307
scoreboard players set #gr drift 7721
scoreboard players set #gdr drift -142
function drift:glide/move/kaze
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0.0001f,0f,0.0223f,0.9998f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.8203f,-0.1838f,-0.195f,0.5052f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.2491f,0.5285f,-0.8055f,0.0986f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.9906f,0.013f,0.0018f,0.136f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.0018f,0.136f,0.9906f,0.013f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4079f,0.8427f,0.1102f],left_rotation:[0.1378f,0.1321f,-0.647f,0.7382f]}}
particle minecraft:campfire_cosy_smoke -61.62 65.12 -43.06 0.036 0.022 0.05 1 0 force
particle minecraft:cloud -61.62 65.32 -43.06 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -61.62 65.42 -43.06 0.45 0.2 0.45 0.008 1 force
particle minecraft:cloud -61.99 65.32 -44.69 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx drift -53103
scoreboard players set #gdx drift -677
scoreboard players set #gz drift -37279
scoreboard players set #gdz drift -696
scoreboard players set #gr drift 9895
scoreboard players set #gdr drift -230
function drift:glide/move/onyx
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0.0112f,0.0002f,0.0199f,0.9997f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.3294f,-0.2442f,0.1475f,0.9001f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.0537f,0.8895f,0.3569f,0.2802f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.9906f,0.013f,0.0018f,0.136f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.0018f,0.136f,0.9906f,0.013f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4037f,0.8388f,0.2693f],left_rotation:[0.167f,0.1133f,-0.517f,0.8318f]}}
particle minecraft:campfire_cosy_smoke -51.84 65.12 -36.21 0.026 0.022 0.07 1 0 force
particle minecraft:cloud -51.84 65.32 -36.21 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -51.84 65.42 -36.21 0.45 0.2 0.45 0.008 1 force
particle minecraft:cloud -51.57 65.32 -37.9 0.35 0.18 0.35 0.02 3 force
