scoreboard players set #gx drift -70283
scoreboard players set #gdx drift -756
scoreboard players set #gz drift -45814
scoreboard players set #gdz drift -113
scoreboard players set #gr drift 6069
scoreboard players set #gdr drift -179
function drift:glide/move/kaze
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0.0021f,0f,0.0223f,0.9998f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.8929f,-0.0498f,0.2728f,0.3548f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.237f,0.328f,0.9031f,0.144f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.9348f,-0.0122f,0.0046f,0.355f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.0046f,-0.355f,0.9348f,0.0122f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4079f,0.8422f,0.1137f],left_rotation:[0.1506f,0.1205f,-0.5783f,0.7927f]}}
particle minecraft:campfire_cosy_smoke -68.73 65.12 -45.73 0.058 0.022 0.032 1 0 force
particle minecraft:cloud -68.73 65.32 -45.73 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud -69.55 65.32 -47.18 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx drift -59946
scoreboard players set #gdx drift -681
scoreboard players set #gz drift -42899
scoreboard players set #gdz drift -409
scoreboard players set #gr drift 7894
scoreboard players set #gdr drift -142
function drift:glide/move/onyx
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0.0059f,0.0001f,0.0223f,0.9997f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.4444f,-0.2397f,0.1885f,0.8423f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.101f,0.8271f,0.4721f,0.2878f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.9348f,-0.0122f,0.0046f,0.355f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.0046f,-0.355f,0.9348f,0.0122f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4078f,0.8397f,0.2602f],left_rotation:[0.1804f,0.0783f,-0.35f,0.9159f]}}
particle minecraft:campfire_cosy_smoke -58.39 65.12 -42.33 0.04 0.022 0.064 1 0 force
particle minecraft:cloud -58.39 65.32 -42.33 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud -58.72 65.32 -44.01 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -58.72 65.42 -44.01 0.45 0.2 0.45 0.008 1 force
playsound driftpark:lap.onyx.07.116 neutral @a -55.84 65.5 -39.87 12 1
playsound driftpark:lap.onyx.07.117 neutral @a -61.31 65.5 -43.7 12 1
playsound driftpark:lap.onyx.07.118 neutral @a -67.05 65.5 -46.02 12 1
playsound driftpark:lap.onyx.07.119 neutral @a -73.25 65.5 -47.03 12 1
playsound driftpark:lap.onyx.07.120 neutral @a -79.1 65.5 -46.65 12 1
playsound driftpark:lap.onyx.07.121 neutral @a -84.03 65.5 -45 12 1
playsound driftpark:lap.onyx.07.122 neutral @a -88.13 65.5 -42.12 12 1
playsound driftpark:lap.onyx.07.123 neutral @a -91.69 65.5 -37.82 12 1
playsound driftpark:lap.onyx.07.124 neutral @a -94.52 65.5 -32.29 12 1
