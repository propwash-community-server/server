scoreboard players set #gx drift 21291
scoreboard players set #gdx drift -790
scoreboard players set #gz drift -47644
scoreboard players set #gdz drift 314
scoreboard players set #gr drift 3433
scoreboard players set #gdr drift -192
function drift:glide/move/kaze
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0.0057f,0.0001f,0.0223f,0.9997f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.6479f,-0.1506f,0.2091f,0.7168f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.1349f,0.6988f,0.6673f,0.2196f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.6637f,0.0087f,0.0098f,0.7479f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.0098f,0.7479f,0.6637f,0.0087f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4078f,0.8414f,0.1199f],left_rotation:[0.1279f,0.1491f,-0.7151f,0.6709f]}}
particle minecraft:campfire_cosy_smoke 22.72 65.12 -48.25 0.078 0.022 0.005 1 0 force
particle minecraft:cloud 22.72 65.32 -48.25 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud 21.34 65.32 -49.2 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx drift 33508
scoreboard players set #gdx drift -929
scoreboard players set #gz drift -50982
scoreboard players set #gdz drift 42
scoreboard players set #gr drift 5364
scoreboard players set #gdr drift -144
function drift:glide/move/onyx
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0.0012f,0f,0.0223f,0.9998f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.877f,-0.1535f,-0.2016f,0.4083f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.2457f,0.4317f,-0.8657f,0.0621f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.6637f,0.0087f,0.0098f,0.7479f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.0098f,0.7479f,0.6637f,0.0087f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4079f,0.8421f,0.2521f],left_rotation:[0.119f,0.1507f,-0.7426f,0.6417f]}}
particle minecraft:campfire_cosy_smoke 35.15 65.12 -51.13 0.079 0.022 0.022 1 0 force
particle minecraft:cloud 35.15 65.32 -51.13 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud 34.14 65.32 -52.51 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 34.14 65.42 -52.51 0.45 0.2 0.45 0.008 1 force
