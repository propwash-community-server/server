scoreboard players set #gx drift -42067
scoreboard players set #gdx drift 1168
scoreboard players set #gz drift 63795
scoreboard players set #gdz drift 127
scoreboard players set #gr drift -9888
scoreboard players set #gdr drift 43
function drift:glide/move/kaze
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0059f,-0.0001f,0.0158f,0.9999f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.4716f,-0.0672f,0.096f,0.874f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.0047f,0.8687f,0.4812f,0.1171f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.4789f,0.0063f,0.0115f,0.8778f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.0115f,0.8778f,0.4789f,0.0063f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.397f,0.8491f,0.0999f],left_rotation:[0.1103f,-0.1486f,0.8072f,0.5606f]}}
particle minecraft:campfire_cosy_smoke -43.23 65.12 64.82 -0.061 0.015 0.041 1 0 force
scoreboard players set #gx drift -57280
scoreboard players set #gdx drift 994
scoreboard players set #gz drift 61238
scoreboard players set #gdz drift 309
scoreboard players set #gr drift -9836
scoreboard players set #gdr drift -65
function drift:glide/move/onyx
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0058f,-0.0001f,0.0188f,0.9998f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.505f,-0.1438f,0.149f,0.8379f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.0618f,0.8269f,0.5229f,0.1976f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.4789f,0.0063f,0.0115f,0.8778f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.0115f,0.8778f,0.4789f,0.0063f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4021f,0.8484f,0.2399f],left_rotation:[0.0423f,0.1802f,-0.9476f,0.2604f]}}
particle minecraft:cloud -58.8 65.32 60.6 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -58.56 65.12 62.29 -0.052 0.022 0.026 1 0 force
particle minecraft:cloud -58.56 65.32 62.29 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -58.56 65.42 62.29 0.45 0.2 0.45 0.008 1 force
