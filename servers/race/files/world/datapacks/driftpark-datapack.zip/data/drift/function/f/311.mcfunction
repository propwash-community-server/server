scoreboard players set #gx drift -17572
scoreboard players set #gdx drift -666
scoreboard players set #gz drift -11229
scoreboard players set #gdz drift 70
scoreboard players set #gr drift 12376
scoreboard players set #gdr drift 153
function drift:glide/move/kaze
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.9586f,-0.0352f,0.2745f,0.0674f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.2689f,-0.0389f,0.9602f,0.0653f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.8819f,0.0115f,0.0062f,0.4712f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.0062f,0.4712f,0.8819f,0.0115f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.3313f,0.8767f,0.1011f],left_rotation:[0.1444f,-0.1168f,0.5832f,0.7908f]}}
particle minecraft:campfire_cosy_smoke -16.95 65.12 -9.81 0.009 0.022 0.023 1 0 force
particle minecraft:cloud -16.95 65.32 -9.81 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud -16.02 65.32 -11.2 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx drift -8700
scoreboard players set #gdx drift -604
scoreboard players set #gz drift -13582
scoreboard players set #gdz drift 385
scoreboard players set #gr drift 10415
scoreboard players set #gdr drift 186
function drift:glide/move/onyx
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0.0074f,-0.0002f,-0.0223f,0.9997f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.6425f,0.2755f,-0.1803f,0.6919f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.254f,-0.7147f,-0.6171f,0.2095f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.8819f,0.0115f,0.0062f,0.4712f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.0062f,0.4712f,0.8819f,0.0115f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.3315f,0.8718f,0.2626f],left_rotation:[0.195f,-0.0346f,0.128f,0.9718f]}}
particle minecraft:campfire_cosy_smoke -7.54 65.12 -12.41 0.012 0.022 0.028 1 0 force
particle minecraft:cloud -7.54 65.32 -12.41 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud -7.12 65.32 -14.07 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -7.12 65.42 -14.07 0.45 0.2 0.45 0.008 1 force
