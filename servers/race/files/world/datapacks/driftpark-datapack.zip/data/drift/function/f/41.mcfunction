scoreboard players set #gx drift -2618
scoreboard players set #gdx drift 1299
scoreboard players set #gz drift 63822
scoreboard players set #gdz drift -26
scoreboard players set #gr drift -9081
scoreboard players set #gdr drift -9
function drift:glide/move/kaze
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0f,0f,-0.0003f,1f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.1656f,0.0105f,0.0513f,0.9848f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.0519f,0.9848f,0.1654f,0.0068f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.1619f,0.0021f,0.0129f,0.9867f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.0129f,0.9867f,0.1619f,0.0021f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.3695f,0.8602f,0.11f],left_rotation:[0.1908f,0.0032f,-0.017f,0.9815f]}}
scoreboard players set #gx drift -20803
scoreboard players set #gdx drift 1299
scoreboard players set #gz drift 64470
scoreboard players set #gdz drift -64
scoreboard players set #gr drift -9119
scoreboard players set #gdr drift 10
function drift:glide/move/onyx
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0f,0f,0.0032f,1f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.3734f,0.0275f,0.0453f,0.9262f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.0518f,0.9265f,0.3725f,0.0116f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.1619f,0.0021f,0.0129f,0.9867f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.0129f,0.9867f,0.1619f,0.0021f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.3754f,0.8576f,0.25f],left_rotation:[0.1902f,0.0154f,-0.0728f,0.9789f]}}
