scoreboard players set #gx drift -73355
scoreboard players set #gdx drift 602
scoreboard players set #gz drift 50688
scoreboard players set #gdz drift 601
scoreboard players set #gr drift -7669
scoreboard players set #gdr drift -114
function drift:glide/move/kaze
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0.0051f,0.0001f,0.0223f,0.9997f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.9014f,-0.1349f,-0.1898f,0.3651f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.2293f,0.387f,-0.8922f,0.0409f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.9484f,-0.0124f,0.0041f,0.3167f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.0041f,-0.3167f,0.9484f,0.0124f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4078f,0.8415f,0.1189f],left_rotation:[0.0892f,0.1744f,-0.8523f,0.485f]}}
particle minecraft:cloud -74.44 65.32 49.57 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -74.82 65.12 51.2 -0.043 0.022 0.01 1 0 force
particle minecraft:cloud -74.82 65.32 51.2 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx drift -81815
scoreboard players set #gdx drift 496
scoreboard players set #gz drift 39607
scoreboard players set #gdz drift 1018
scoreboard players set #gr drift -5663
scoreboard players set #gdr drift -201
function drift:glide/move/onyx
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0.0111f,0.0002f,0.0171f,0.9998f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.9128f,-0.1282f,-0.1922f,0.3367f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.2287f,0.3587f,-0.9044f,0.0329f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.9484f,-0.0124f,0.0041f,0.3167f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.0041f,-0.3167f,0.9484f,0.0124f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.399f,0.841f,0.2691f],left_rotation:[0.0897f,0.1807f,-0.8619f,0.4651f]}}
particle minecraft:cloud -82.53 65.32 38.11 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -82.53 65.42 38.11 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke -83.47 65.12 39.54 -0.049 0.022 -0.013 1 0 force
particle minecraft:cloud -83.47 65.32 39.54 0.35 0.18 0.35 0.02 3 force
