scoreboard players set #gx drift -72146
scoreboard players set #gdx drift 617
scoreboard players set #gz drift 51866
scoreboard players set #gdz drift 556
scoreboard players set #gr drift -7912
scoreboard players set #gdr drift -109
function drift:glide/move/kaze
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0009f,0f,0.0222f,0.9998f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.9574f,0.0124f,0.227f,0.1779f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.2095f,0.155f,0.9614f,0.0882f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.9787f,0.0128f,0.0027f,0.2047f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.0027f,0.2047f,0.9787f,0.0128f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4079f,0.8429f,0.1084f],left_rotation:[0.0774f,0.1734f,-0.8778f,0.4398f]}}
particle minecraft:cloud -73.27 65.32 50.8 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -73.59 65.12 52.44 -0.036 0.022 0.002 1 0 force
particle minecraft:cloud -73.59 65.32 52.44 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -73.59 65.42 52.44 0.45 0.2 0.45 0.008 1 force
scoreboard players set #gx drift -80818
scoreboard players set #gdx drift 506
scoreboard players set #gz drift 41620
scoreboard players set #gdz drift 972
scoreboard players set #gr drift -6066
scoreboard players set #gdr drift -202
function drift:glide/move/onyx
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0.0111f,0.0002f,0.0188f,0.9998f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.9562f,0.0138f,0.2449f,0.1594f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.2295f,0.1345f,0.9601f,0.0866f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.9787f,0.0128f,0.0027f,0.2047f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.0027f,0.2047f,0.9787f,0.0128f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4019f,0.8397f,0.2691f],left_rotation:[0.113f,0.1671f,-0.79f,0.579f]}}
particle minecraft:cloud -81.63 65.32 40.18 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -82.47 65.12 41.67 -0.035 0.022 -0.02 1 0 force
particle minecraft:cloud -82.47 65.32 41.67 0.35 0.18 0.35 0.02 3 force
