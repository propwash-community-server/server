scoreboard players set #gx drift -92743
scoreboard players set #gdx drift -327
scoreboard players set #gz drift -34103
scoreboard players set #gdz drift 699
scoreboard players set #gr drift -546
scoreboard players set #gdr drift -53
function drift:glide/move/kaze
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0059f,-0.0001f,0.0185f,0.9998f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.4928f,-0.2115f,-0.0618f,0.8418f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.1506f,0.8529f,-0.4733f,0.1609f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.865f,-0.0113f,0.0066f,0.5016f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.0066f,-0.5016f,0.865f,0.0113f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4017f,0.8469f,0.0999f],left_rotation:[0.0648f,0.1733f,-0.9071f,0.378f]}}
particle minecraft:cloud -92.04 65.32 -35.49 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -93.7 65.12 -35.33 -0.027 0.022 -0.033 1 0 force
particle minecraft:cloud -93.7 65.32 -35.33 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx drift -87648
scoreboard players set #gdx drift -486
scoreboard players set #gz drift -42555
scoreboard players set #gdz drift 438
scoreboard players set #gr drift 333
scoreboard players set #gdr drift -140
function drift:glide/move/onyx
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0058f,-0.0001f,0.0222f,0.9997f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.4291f,-0.2887f,-0.0841f,0.8517f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.1741f,0.8652f,-0.4012f,0.2452f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.865f,-0.0113f,0.0066f,0.5016f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.0066f,-0.5016f,0.865f,0.0113f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4079f,0.8456f,0.2401f],left_rotation:[0.1667f,0.0806f,-0.3881f,0.9028f]}}
particle minecraft:cloud -86.71 65.32 -43.92 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -88.42 65.12 -44.02 -0.025 0.022 -0.026 1 0 force
particle minecraft:cloud -88.42 65.32 -44.02 0.35 0.18 0.35 0.02 3 force
