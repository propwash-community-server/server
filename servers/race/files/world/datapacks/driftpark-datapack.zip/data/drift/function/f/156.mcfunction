scoreboard players set #gx drift 89005
scoreboard players set #gdx drift -226
scoreboard players set #gz drift -5438
scoreboard players set #gdz drift -1051
scoreboard players set #gr drift 14257
scoreboard players set #gdr drift -107
function drift:glide/move/kaze
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0002f,0f,0.0223f,0.9998f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.3572f,-0.1959f,-0.0194f,0.9131f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.1155f,0.9201f,-0.3385f,0.1594f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.3685f,-0.0048f,0.0122f,0.9295f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.0122f,-0.9295f,0.3685f,0.0048f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4079f,0.8427f,0.1096f],left_rotation:[0.0247f,0.189f,-0.9668f,0.1703f]}}
particle minecraft:cloud 89.14 65.32 -3.89 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke 90.46 65.12 -4.91 0.036 0.021 0.024 1 0 force
particle minecraft:cloud 90.46 65.32 -4.91 0.35 0.18 0.35 0.02 2 force
scoreboard players set #gx drift 90789
scoreboard players set #gdx drift 71
scoreboard players set #gz drift 9503
scoreboard players set #gdz drift -1082
scoreboard players set #gr drift 15491
scoreboard players set #gdr drift -116
function drift:glide/move/onyx
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0001f,0f,0.0223f,0.9998f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.4227f,-0.1719f,0.1422f,0.8784f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.0507f,0.8683f,0.4431f,0.2172f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.3685f,-0.0048f,0.0122f,0.9295f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.0122f,-0.9295f,0.3685f,0.0048f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4079f,0.8427f,0.2498f],left_rotation:[0.0707f,0.1771f,-0.8947f,0.4039f]}}
particle minecraft:cloud 90.61 65.32 11.15 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 90.61 65.42 11.15 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke 92.16 65.12 10.42 0.03 0.022 0.031 1 0 force
particle minecraft:cloud 92.16 65.32 10.42 0.35 0.18 0.35 0.02 3 force
