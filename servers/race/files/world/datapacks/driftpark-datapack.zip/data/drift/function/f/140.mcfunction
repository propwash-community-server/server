scoreboard players set #gx drift 89747
scoreboard players set #gdx drift 113
scoreboard players set #gz drift 11560
scoreboard players set #gdz drift -1060
scoreboard players set #gr drift 16069
scoreboard players set #gdr drift -116
function drift:glide/move/kaze
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0004f,0f,0.0223f,0.9998f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.6402f,-0.109f,0.1644f,0.7425f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.0872f,0.7293f,0.6551f,0.1769f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.6506f,0.0085f,0.0099f,0.7593f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.0099f,0.7593f,0.6506f,0.0085f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4079f,0.8428f,0.1093f],left_rotation:[0.0254f,0.1887f,-0.9662f,0.1739f]}}
particle minecraft:cloud 89.39 65.32 13.07 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke 89.39 65.42 13.07 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke 90.97 65.12 12.52 0.025 0.021 0.031 1 0 force
particle minecraft:cloud 90.97 65.32 12.52 0.35 0.18 0.35 0.02 2 force
scoreboard players set #gx drift 86867
scoreboard players set #gdx drift 393
scoreboard players set #gz drift 26095
scoreboard players set #gdz drift -973
scoreboard players set #gr drift 17265
scoreboard players set #gdr drift -108
function drift:glide/move/onyx
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.9667f,0.0264f,0.2251f,0.119f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.2138f,0.096f,0.9692f,0.0751f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.6506f,0.0085f,0.0099f,0.7593f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.0099f,0.7593f,0.6506f,0.0085f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4079f,0.8437f,0.2466f],left_rotation:[0.0759f,0.173f,-0.8808f,0.4341f]}}
particle minecraft:cloud 86.2 65.32 27.61 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 86.2 65.42 27.61 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke 87.9 65.12 27.39 0.014 0.022 0.052 1 0 force
particle minecraft:cloud 87.9 65.32 27.39 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 87.9 65.42 27.39 0.45 0.2 0.45 0.008 1 force
