scoreboard players set #gx drift -51706
scoreboard players set #gdx drift -678
scoreboard players set #gz drift -34473
scoreboard players set #gdz drift -754
scoreboard players set #gr drift 11015
scoreboard players set #gdr drift -245
function drift:glide/move/kaze
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0.0092f,0.0002f,0.017f,0.9998f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.3086f,-0.2305f,-0.0204f,0.9226f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.1175f,0.9299f,-0.286f,0.1994f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.9368f,0.0123f,0.0046f,0.3496f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.0046f,0.3496f,0.9368f,0.0123f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.3989f,0.8448f,0.1257f],left_rotation:[0.0895f,0.1786f,-0.8607f,0.4683f]}}
particle minecraft:cloud -50.76 65.32 -33.24 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -50.19 65.12 -34.81 0.046 0.022 -0.009 1 0 force
particle minecraft:cloud -50.19 65.32 -34.81 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx drift -43481
scoreboard players set #gdx drift -513
scoreboard players set #gz drift -23505
scoreboard players set #gdz drift -762
scoreboard players set #gr drift 14789
scoreboard players set #gdr drift -271
function drift:glide/move/onyx
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0059f,0f,-0.0076f,1f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.0553f,0.0253f,0.051f,0.9968f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.0535f,-0.997f,-0.053f,0.0197f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.9368f,0.0123f,0.0046f,0.3496f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.0046f,0.3496f,0.9368f,0.0123f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.3569f,0.8684f,0.2399f],left_rotation:[0.1815f,0.0359f,-0.2054f,0.961f]}}
