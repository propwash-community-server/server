scoreboard players set #gx drift 89459
scoreboard players set #gdx drift 155
scoreboard players set #gz drift 13669
scoreboard players set #gdz drift -1052
scoreboard players set #gr drift 16291
scoreboard players set #gdr drift -106
function drift:glide/move/kaze
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0007f,0f,0.0223f,0.9998f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.9271f,-0.0113f,0.1971f,0.3186f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.1646f,0.2997f,0.9334f,0.1089f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.9447f,0.0124f,0.0043f,0.3277f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.0043f,0.3277f,0.9447f,0.0124f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4079f,0.8428f,0.1088f],left_rotation:[0.0256f,0.1884f,-0.966f,0.1754f]}}
particle minecraft:cloud 89.05 65.32 15.17 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke 90.64 65.12 14.68 0.025 0.021 0.036 1 0 force
particle minecraft:cloud 90.64 65.32 14.68 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke 90.64 65.42 14.68 0.45 0.2 0.45 0.008 1 force
scoreboard players set #gx drift 86015
scoreboard players set #gdx drift 435
scoreboard players set #gz drift 28004
scoreboard players set #gdz drift -949
scoreboard players set #gr drift 17496
scoreboard players set #gdr drift -122
function drift:glide/move/onyx
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0021f,0f,0.0223f,0.9998f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.8988f,-0.1346f,-0.1832f,0.3749f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.2236f,0.3962f,-0.8896f,0.0408f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.9447f,0.0124f,0.0043f,0.3277f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.0043f,0.3277f,0.9447f,0.0124f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4079f,0.8437f,0.2464f],left_rotation:[0.0769f,0.1724f,-0.8781f,0.4397f]}}
particle minecraft:cloud 85.29 65.32 29.49 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 86.99 65.12 29.34 0.01 0.022 0.041 1 0 force
particle minecraft:cloud 86.99 65.32 29.34 0.35 0.18 0.35 0.02 3 force
