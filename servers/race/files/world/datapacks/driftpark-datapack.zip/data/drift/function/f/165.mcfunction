scoreboard players set #gx drift 86234
scoreboard players set #gdx drift -406
scoreboard players set #gz drift -14685
scoreboard players set #gdz drift -987
scoreboard players set #gr drift 13207
scoreboard players set #gdr drift -124
function drift:glide/move/kaze
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0.0014f,0f,0.0223f,0.9998f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.9057f,-0.1228f,-0.1576f,0.3738f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.1978f,0.3925f,-0.8978f,0.0282f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.9263f,-0.0121f,0.0049f,0.3766f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.0049f,-0.3766f,0.9263f,0.0121f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4079f,0.8424f,0.1123f],left_rotation:[0.0302f,0.1898f,-0.9613f,0.1973f]}}
particle minecraft:campfire_cosy_smoke 86.65 65.12 -13.19 -0.01 0.022 0.088 1 0 force
particle minecraft:cloud 86.65 65.32 -13.19 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke 86.65 65.42 -13.19 0.45 0.2 0.45 0.008 1 force
particle minecraft:cloud 87.77 65.32 -14.43 0.35 0.18 0.35 0.02 2 force
scoreboard players set #gx drift 90655
scoreboard players set #gdx drift -126
scoreboard players set #gz drift -227
scoreboard players set #gdz drift -1079
scoreboard players set #gr drift 14475
scoreboard players set #gdr drift -117
function drift:glide/move/onyx
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.001f,0f,0.0223f,0.9998f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.2977f,-0.2218f,-0.0148f,0.9284f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.1125f,0.9351f,-0.276f,0.1917f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.9263f,-0.0121f,0.0049f,0.3766f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.0049f,-0.3766f,0.9263f,0.0121f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4079f,0.8432f,0.2482f],left_rotation:[0.0691f,0.1768f,-0.8977f,0.3976f]}}
particle minecraft:campfire_cosy_smoke 90.77 65.12 1.42 -0.027 0.022 0.075 1 0 force
particle minecraft:cloud 90.77 65.32 1.42 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud 92.17 65.32 0.44 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 92.17 65.42 0.44 0.45 0.2 0.45 0.008 1 force
