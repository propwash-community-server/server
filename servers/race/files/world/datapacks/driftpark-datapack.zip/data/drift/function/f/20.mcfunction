scoreboard players set #gx drift -29872
scoreboard players set #gdx drift 1280
scoreboard players set #gz drift 64486
scoreboard players set #gdz drift 6
scoreboard players set #gr drift -9315
scoreboard players set #gdr drift 46
function drift:glide/move/kaze
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0046f,0f,0.0096f,0.9999f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.8401f,0.0355f,0.0416f,0.5396f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.0149f,0.5382f,0.841f,0.0526f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.8408f,0.011f,0.0071f,0.5413f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.0071f,0.5413f,0.8408f,0.011f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.3865f,0.8537f,0.1021f],left_rotation:[0.1847f,-0.0247f,0.1491f,0.9711f]}}
scoreboard players set #gx drift -46715
scoreboard players set #gdx drift 1129
scoreboard players set #gz drift 63724
scoreboard players set #gdz drift 168
scoreboard players set #gr drift -10259
scoreboard players set #gdr drift 17
function drift:glide/move/onyx
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0059f,-0.0001f,0.0172f,0.9998f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.8776f,-0.0252f,0.1656f,0.4492f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.1193f,0.4343f,0.8851f,0.1176f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.8408f,0.011f,0.0071f,0.5413f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.0071f,0.5413f,0.8408f,0.011f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.3994f,0.8497f,0.2398f],left_rotation:[0.0269f,-0.183f,0.9766f,0.1093f]}}
particle minecraft:cloud -48.28 65.32 63.2 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -47.91 65.12 64.87 -0.041 0.019 0.035 1 0 force
particle minecraft:cloud -47.91 65.32 64.87 0.35 0.18 0.35 0.02 2 force
