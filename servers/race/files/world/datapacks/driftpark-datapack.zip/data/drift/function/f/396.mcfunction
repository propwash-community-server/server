scoreboard players set #gx drift -74033
scoreboard players set #gdx drift -733
scoreboard players set #gz drift -46161
scoreboard players set #gdz drift -5
scoreboard players set #gr drift 5106
scoreboard players set #gdr drift -212
function drift:glide/move/kaze
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0.005f,0.0001f,0.0223f,0.9997f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.6f,-0.185f,0.2185f,0.747f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.1412f,0.7281f,0.6228f,0.2491f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.8181f,-0.0107f,0.0075f,0.575f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.0075f,-0.575f,0.8181f,0.0107f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4078f,0.8415f,0.1186f],left_rotation:[0.1628f,0.1086f,-0.5075f,0.8391f]}}
particle minecraft:cloud -72.49 65.32 -46.33 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -73.54 65.12 -47.63 0.014 0.022 -0.021 1 0 force
particle minecraft:cloud -73.54 65.32 -47.63 0.35 0.18 0.35 0.02 3 force
particle minecraft:flame -72.5 65.22 -48.05 0.05 0.04 0.05 0.02 6 force
particle minecraft:large_smoke -72.5 65.22 -48.05 0.05 0.04 0.05 0.01 2 force
scoreboard players set #gx drift -63389
scoreboard players set #gdx drift -706
scoreboard players set #gz drift -44716
scoreboard players set #gdz drift -298
scoreboard players set #gr drift 7151
scoreboard players set #gdr drift -165
function drift:glide/move/onyx
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0014f,0f,0.0223f,0.9998f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.092f,-0.2957f,0.0264f,0.9505f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.0734f,0.9529f,-0.0614f,0.2876f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.8181f,-0.0107f,0.0075f,0.575f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.0075f,-0.575f,0.8181f,0.0107f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4079f,0.8434f,0.2476f],left_rotation:[0.1674f,0.0887f,-0.4209f,0.8871f]}}
particle minecraft:cloud -61.78 65.32 -44.35 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -62.32 65.12 -45.98 0.032 0.022 -0.025 1 0 force
particle minecraft:cloud -62.32 65.32 -45.98 0.35 0.18 0.35 0.02 3 force
