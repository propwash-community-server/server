scoreboard players set #gx drift -46013
scoreboard players set #gdx drift -592
scoreboard players set #gz drift -27456
scoreboard players set #gdz drift -760
scoreboard players set #gr drift 13413
scoreboard players set #gdr drift -278
function drift:glide/move/kaze
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0059f,0f,0.0007f,1f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.4691f,-0.0528f,0.0878f,0.8772f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.0039f,0.8728f,0.4772f,0.1024f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.9004f,-0.0118f,0.0057f,0.435f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.0057f,-0.435f,0.9004f,0.0118f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.3713f,0.8607f,0.0999f],left_rotation:[0.1295f,-0.1321f,0.7028f,0.6869f]}}
particle minecraft:campfire_cosy_smoke -45.65 65.12 -25.94 -0.006 0.013 0.063 1 0 force
scoreboard players set #gx drift -38455
scoreboard players set #gdx drift -613
scoreboard players set #gz drift -17490
scoreboard players set #gdz drift -568
scoreboard players set #gr drift 16263
scoreboard players set #gdr drift -55
function drift:glide/move/onyx
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0058f,0.0001f,-0.0183f,0.9998f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.8138f,0.1556f,-0.137f,0.543f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.1948f,-0.5604f,-0.8019f,0.0709f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.9004f,-0.0118f,0.0057f,0.435f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.0057f,-0.435f,0.9004f,0.0118f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.3382f,0.8758f,0.2399f],left_rotation:[0.0428f,-0.18f,0.9471f,0.2622f]}}
particle minecraft:campfire_cosy_smoke -38.85 65.12 -15.88 0 0.022 0.044 1 0 force
particle minecraft:cloud -38.85 65.32 -15.88 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud -37.22 65.32 -16.39 0.35 0.18 0.35 0.02 3 force
