scoreboard players set #gx drift 86989
scoreboard players set #gdx drift -368
scoreboard players set #gz drift -12682
scoreboard players set #gdz drift -1006
scoreboard players set #gr drift 13442
scoreboard players set #gdr drift -123
function drift:glide/move/kaze
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0.001f,0f,0.0223f,0.9998f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.5939f,-0.1847f,-0.0737f,0.7796f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.156f,0.7916f,-0.5778f,0.1233f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.6101f,-0.008f,0.0104f,0.7923f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.0104f,-0.7923f,0.6101f,0.008f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4079f,0.8425f,0.1118f],left_rotation:[0.0286f,0.1897f,-0.963f,0.1893f]}}
particle minecraft:campfire_cosy_smoke 87.34 65.12 -11.17 -0.011 0.022 0.072 1 0 force
particle minecraft:cloud 87.34 65.32 -11.17 0.35 0.18 0.35 0.02 2 force
particle minecraft:cloud 88.51 65.32 -12.36 0.35 0.18 0.35 0.02 2 force
scoreboard players set #gx drift 90842
scoreboard players set #gdx drift -82
scoreboard players set #gz drift 1929
scoreboard players set #gdz drift -1077
scoreboard players set #gr drift 14698
scoreboard players set #gdr drift -106
function drift:glide/move/onyx
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0007f,0f,0.0223f,0.9998f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.2008f,-0.2f,0.0969f,0.9541f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.0029f,0.9492f,0.2229f,0.2222f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.6101f,-0.008f,0.0104f,0.7923f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.0104f,-0.7923f,0.6101f,0.008f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4079f,0.843f,0.2489f],left_rotation:[0.069f,0.1772f,-0.898f,0.3968f]}}
particle minecraft:campfire_cosy_smoke 90.9 65.12 3.58 -0.026 0.022 0.085 1 0 force
particle minecraft:cloud 90.9 65.32 3.58 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud 92.33 65.32 2.65 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 92.33 65.42 2.65 0.45 0.2 0.45 0.008 1 force
playsound driftpark:lap.onyx.03.088 neutral @a 90.93 65.5 4.09 12 1
playsound driftpark:lap.onyx.03.089 neutral @a 90.03 65.5 -4.53 12 1
playsound driftpark:lap.onyx.03.090 neutral @a 87.77 65.5 -12.96 12 1
playsound driftpark:lap.onyx.03.091 neutral @a 84.29 65.5 -20.85 12 1
playsound driftpark:lap.onyx.03.092 neutral @a 79.68 65.5 -27.9 12 1
playsound driftpark:lap.onyx.03.093 neutral @a 73.73 65.5 -34.19 12 1
playsound driftpark:lap.onyx.03.094 neutral @a 66.43 65.5 -39.84 12 1
playsound driftpark:lap.onyx.03.095 neutral @a 57.86 65.5 -44.75 12 1
playsound driftpark:lap.onyx.03.096 neutral @a 49.24 65.5 -48.51 12 1
