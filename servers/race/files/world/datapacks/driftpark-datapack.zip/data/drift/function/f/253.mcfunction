scoreboard players set #gx drift 13108
scoreboard players set #gdx drift -545
scoreboard players set #gz drift -42974
scoreboard players set #gdz drift 464
scoreboard players set #gr drift 1414
scoreboard players set #gdr drift -94
function drift:glide/move/kaze
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0.0024f,0.0001f,0.0222f,0.9998f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.4945f,-0.2328f,-0.0754f,0.834f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.1635f,0.8465f,-0.4728f,0.1821f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.6417f,0.0084f,0.01f,0.7668f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.01f,0.7668f,0.6417f,0.0084f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4078f,0.8422f,0.1142f],left_rotation:[0.1068f,0.161f,-0.7928f,0.5781f]}}
particle minecraft:campfire_cosy_smoke 14.24 65.12 -44.04 0.057 0.022 -0.019 1 0 force
particle minecraft:cloud 14.24 65.32 -44.04 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud 12.62 65.32 -44.45 0.35 0.18 0.35 0.02 3 force
scoreboard players set #gx drift 22642
scoreboard players set #gdx drift -842
scoreboard players set #gz drift -49077
scoreboard players set #gdz drift 287
scoreboard players set #gr drift 3413
scoreboard players set #gdr drift -183
function drift:glide/move/onyx
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0.0051f,0.0001f,0.0223f,0.9997f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.8562f,-0.1725f,-0.2197f,0.4345f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.2666f,0.46f,-0.8428f,0.0835f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.6417f,0.0084f,0.01f,0.7668f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.01f,0.7668f,0.6417f,0.0084f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4078f,0.8401f,0.2588f],left_rotation:[0.1553f,0.1192f,-0.5619f,0.8037f]}}
particle minecraft:campfire_cosy_smoke 24.14 65.12 -49.77 0.073 0.022 0.006 1 0 force
particle minecraft:cloud 24.14 65.32 -49.77 0.35 0.18 0.35 0.02 3 force
particle minecraft:cloud 22.73 65.32 -50.73 0.35 0.18 0.35 0.02 3 force
