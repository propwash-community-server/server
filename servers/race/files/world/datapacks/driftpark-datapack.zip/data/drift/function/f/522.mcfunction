scoreboard players set #gx drift -69553
scoreboard players set #gdx drift 701
scoreboard players set #gz drift 54031
scoreboard players set #gdz drift 516
scoreboard players set #gr drift -8321
scoreboard players set #gdr drift -98
function drift:glide/move/kaze
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0059f,-0.0001f,0.0219f,0.9997f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.2834f,-0.1868f,0.1126f,0.9339f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.0151f,0.9272f,0.3045f,0.2176f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.3029f,0.004f,0.0125f,0.9529f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.0125f,0.9529f,0.3029f,0.004f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4074f,0.8442f,0.0999f],left_rotation:[0.0604f,0.1749f,-0.9138f,0.3615f]}}
particle minecraft:cloud -70.76 65.32 53.05 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -70.76 65.42 53.05 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke -70.95 65.12 54.71 -0.03 0.022 0.009 1 0 force
particle minecraft:cloud -70.95 65.32 54.71 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -70.95 65.42 54.71 0.45 0.2 0.45 0.008 1 force
scoreboard players set #gx drift -78752
scoreboard players set #gdx drift 554
scoreboard players set #gz drift 45359
scoreboard players set #gdz drift 858
scoreboard players set #gr drift -6844
scoreboard players set #gdr drift -180
function drift:glide/move/onyx
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0.0112f,0.0002f,0.0212f,0.9997f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.3478f,-0.2224f,0.1441f,0.8993f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.0504f,0.8891f,0.3731f,0.2602f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.3029f,0.004f,0.0125f,0.9529f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.0125f,0.9529f,0.3029f,0.004f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4058f,0.8377f,0.2693f],left_rotation:[0.142f,0.1435f,-0.6664f,0.7178f]}}
particle minecraft:cloud -79.75 65.32 44.04 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -80.38 65.12 45.63 -0.035 0.022 -0.012 1 0 force
particle minecraft:cloud -80.38 65.32 45.63 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -80.38 65.42 45.63 0.45 0.2 0.45 0.008 1 force
