scoreboard players set #gx drift -93261
scoreboard players set #gdx drift 330
scoreboard players set #gz drift 8804
scoreboard players set #gdz drift 1188
scoreboard players set #gr drift -2316
scoreboard players set #gdr drift -25
function drift:glide/move/kaze
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0058f,-0.0001f,0.0101f,0.9999f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.0364f,-0.0574f,0.0504f,0.9964f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.0541f,0.9966f,-0.0305f,0.0539f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.1043f,-0.0014f,0.013f,0.9945f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.013f,-0.9945f,0.1043f,0.0014f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.3874f,0.8536f,0.1f],left_rotation:[0.1631f,-0.0874f,0.4817f,0.8565f]}}
scoreboard players set #gx drift -97131
scoreboard players set #gdx drift 158
scoreboard players set #gz drift -6941
scoreboard players set #gdz drift 1084
scoreboard players set #gr drift -2909
scoreboard players set #gdr drift 46
function drift:glide/move/onyx
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0059f,-0.0001f,0.0167f,0.9998f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.2768f,-0.1655f,0.0068f,0.9465f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.0926f,0.951f,-0.2609f,0.1374f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.1043f,-0.0014f,0.013f,0.9945f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.013f,-0.9945f,0.1043f,0.0014f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.3987f,0.85f,0.2399f],left_rotation:[0.03f,-0.1826f,0.9745f,0.1269f]}}
particle minecraft:cloud -97.07 65.32 -8.59 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -98.57 65.12 -7.76 -0.042 0.019 -0.037 1 0 force
particle minecraft:cloud -98.57 65.32 -7.76 0.35 0.18 0.35 0.02 2 force
