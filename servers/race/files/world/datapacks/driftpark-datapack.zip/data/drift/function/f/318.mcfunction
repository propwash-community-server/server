scoreboard players set #gx drift -22442
scoreboard players set #gdx drift -724
scoreboard players set #gz drift -11178
scoreboard players set #gdz drift -78
scoreboard players set #gr drift 13377
scoreboard players set #gdr drift 143
function drift:glide/move/kaze
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0033f,0.0001f,-0.0223f,0.9997f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.2331f,0.2423f,0.1163f,0.9346f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.0188f,-0.9275f,0.2598f,0.2681f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.7182f,0.0094f,0.0091f,0.6957f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.0091f,0.6957f,0.7182f,0.0094f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.3313f,0.8763f,0.1044f],left_rotation:[0.1365f,-0.1287f,0.6413f,0.744f]}}
particle minecraft:cloud -22.07 65.32 -9.67 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -20.92 65.12 -10.87 0.071 0.022 -0.029 1 0 force
particle minecraft:cloud -20.92 65.32 -10.87 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -20.92 65.42 -10.87 0.45 0.2 0.45 0.008 1 force
scoreboard players set #gx drift -12943
scoreboard players set #gdx drift -616
scoreboard players set #gz drift -11413
scoreboard players set #gdz drift 216
scoreboard players set #gr drift 11663
scoreboard players set #gdr drift 205
function drift:glide/move/onyx
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0.0001f,0f,-0.0223f,0.9998f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.9287f,0.1186f,-0.2885f,0.2008f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.3111f,-0.2322f,-0.9213f,0.0217f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.7182f,0.0094f,0.0091f,0.6957f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.0091f,0.6957f,0.7182f,0.0094f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.3314f,0.8756f,0.2501f],left_rotation:[0.1797f,-0.0642f,0.2887f,0.9382f]}}
particle minecraft:cloud -12.06 65.32 -10.01 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -12.06 65.42 -10.01 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke -11.29 65.12 -11.54 0.054 0.022 -0.051 1 0 force
particle minecraft:cloud -11.29 65.32 -11.54 0.35 0.18 0.35 0.02 3 force
