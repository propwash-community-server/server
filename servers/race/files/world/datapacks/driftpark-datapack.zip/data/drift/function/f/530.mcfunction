scoreboard players set #gx drift -63385
scoreboard players set #gdx drift 857
scoreboard players set #gz drift 57836
scoreboard players set #gdz drift 420
scoreboard players set #gr drift -8987
scoreboard players set #gdr drift -79
function drift:glide/move/kaze
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0059f,-0.0001f,0.0203f,0.9998f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.9509f,0.0056f,0.1963f,0.2391f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.1722f,0.2198f,0.9556f,0.0943f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.9724f,0.0127f,0.0031f,0.233f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.0031f,0.233f,0.9724f,0.0127f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4047f,0.8455f,0.0999f],left_rotation:[0.0234f,0.1836f,-0.9689f,0.164f]}}
particle minecraft:cloud -64.69 65.32 57 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -64.7 65.12 58.67 -0.048 0.022 0.025 1 0 force
particle minecraft:cloud -64.7 65.32 58.67 0.35 0.18 0.35 0.02 2 force
scoreboard players set #gx drift -73999
scoreboard players set #gdx drift 617
scoreboard players set #gz drift 51316
scoreboard players set #gdz drift 616
scoreboard players set #gr drift -8064
scoreboard players set #gdr drift -112
function drift:glide/move/onyx
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0.0051f,0.0001f,0.0223f,0.9997f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.9561f,0.0183f,0.2601f,0.1337f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.2475f,0.1071f,0.9595f,0.0821f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.9724f,0.0127f,0.0031f,0.233f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.0031f,0.233f,0.9724f,0.0127f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4078f,0.8401f,0.2588f],left_rotation:[0.1318f,0.1449f,-0.6953f,0.6915f]}}
particle minecraft:cloud -75.26 65.32 50.24 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -75.26 65.42 50.24 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke -75.53 65.12 51.93 -0.043 0.022 0.007 1 0 force
particle minecraft:cloud -75.53 65.32 51.93 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -75.53 65.42 51.93 0.45 0.2 0.45 0.008 1 force
