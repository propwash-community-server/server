scoreboard players set #gx drift -30987
scoreboard players set #gdx drift -654
scoreboard players set #gz drift -13499
scoreboard players set #gdz drift -317
scoreboard players set #gr drift 15155
scoreboard players set #gdr drift 114
function drift:glide/move/kaze
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0.0006f,0f,-0.0223f,0.9998f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.7324f,0.2006f,-0.1494f,0.6333f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.2168f,-0.6525f,-0.7153f,0.1247f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.6977f,0.0091f,0.0094f,0.7162f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.0094f,0.7162f,0.6977f,0.0091f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.3314f,0.8755f,0.111f],left_rotation:[0.1139f,-0.1538f,0.7621f,0.6185f]}}
particle minecraft:cloud -31.1 65.32 -11.95 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -29.63 65.12 -12.74 0.059 0.022 0.006 1 0 force
particle minecraft:cloud -29.63 65.32 -12.74 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -29.63 65.42 -12.74 0.45 0.2 0.45 0.008 1 force
scoreboard players set #gx drift -21036
scoreboard players set #gdx drift -740
scoreboard players set #gz drift -10187
scoreboard players set #gdz drift -36
scoreboard players set #gr drift 13508
scoreboard players set #gdr drift 138
function drift:glide/move/onyx
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0041f,0.0001f,-0.0223f,0.9997f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.7095f,0.2377f,-0.1825f,0.6378f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.2506f,-0.6605f,-0.6884f,0.1645f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.6977f,0.0091f,0.0094f,0.7162f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.0094f,0.7162f,0.6977f,0.0091f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.3313f,0.8776f,0.2429f],left_rotation:[0.1674f,-0.0829f,0.3964f,0.8989f]}}
particle minecraft:cloud -20.64 65.32 -8.58 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -19.43 65.12 -9.79 0.064 0.022 -0.035 1 0 force
particle minecraft:cloud -19.43 65.32 -9.79 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -19.43 65.42 -9.79 0.45 0.2 0.45 0.008 1 force
