scoreboard players set #gx drift 68887
scoreboard players set #gdx drift -926
scoreboard players set #gz drift -37230
scoreboard players set #gdz drift -694
scoreboard players set #gr drift 10367
scoreboard players set #gdr drift -94
function drift:glide/move/kaze
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.4327f,-0.1803f,-0.0292f,0.8828f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.1221f,0.8908f,-0.4162f,0.1358f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.448f,-0.0059f,0.0117f,0.8939f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.0117f,-0.8939f,0.448f,0.0059f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4079f,0.8439f,0.1f],left_rotation:[-0.0011f,0.1851f,-0.982f,0.038f]}}
particle minecraft:cloud 69.96 65.32 -36.11 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke 70.36 65.12 -37.73 0.046 0.02 -0.014 1 0 force
particle minecraft:cloud 70.36 65.32 -37.73 0.35 0.18 0.35 0.02 2 force
scoreboard players set #gx drift 80324
scoreboard players set #gdx drift -643
scoreboard players set #gz drift -27075
scoreboard players set #gdz drift -828
scoreboard players set #gr drift 11340
scoreboard players set #gdr drift -101
function drift:glide/move/onyx
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0028f,-0.0001f,0.0223f,0.9997f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.5136f,-0.1549f,0.1591f,0.8288f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.0728f,0.8166f,0.5327f,0.2097f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.448f,-0.0059f,0.0117f,0.8939f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.0117f,-0.8939f,0.448f,0.0059f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.408f,0.8441f,0.2452f],left_rotation:[0.068f,0.1753f,-0.8991f,0.3954f]}}
particle minecraft:cloud 81.28 65.32 -25.73 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 81.96 65.12 -27.3 0.049 0.022 0.008 1 0 force
particle minecraft:cloud 81.96 65.32 -27.3 0.35 0.18 0.35 0.02 3 force
