data merge entity 7f895ae6-3a84-58c6-84f5-016612fdd486 {start_interpolation:0,transformation:{translation:[0.007f,1.808f,0.268f],left_rotation:[0.5475f,0.0256f,0.0032f,0.8364f]}}
data merge entity d5b82b8d-86e1-5276-8680-ed7a08615c7a {start_interpolation:0,transformation:{translation:[0.198f,2.002f,0.692f],left_rotation:[0.621f,0.2725f,-0.0771f,0.7308f]}}
data merge entity a4c123d3-dfeb-5763-b680-e521fb79538b {start_interpolation:0,transformation:{translation:[-0.162f,1.99f,0.706f],left_rotation:[0.6199f,-0.2994f,0.0482f,0.7237f],scale:[1f,1f,1.007f]}}
data merge entity 14895439-b1c6-5868-83ed-85b5ca16af52 {start_interpolation:0,transformation:{translation:[0.101f,1.799f,0.237f],left_rotation:[-0.1131f,0.1056f,0.1127f,0.9815f]}}
data merge entity ed503232-ebe9-57f4-8f88-a4efe27a7f4d {start_interpolation:0,transformation:{translation:[-0.088f,1.793f,0.244f],left_rotation:[-0.1147f,-0.102f,-0.118f,0.9811f]}}
data merge entity 75e3c547-3dab-50d7-a8aa-ffff4a07edfb {start_interpolation:0,transformation:{translation:[0.209f,1.382f,0.324f],left_rotation:[0.3952f,0.0001f,-0.019f,0.9184f]}}
data merge entity b4028d78-85e3-5bdd-b8d1-be173b14689d {start_interpolation:0,transformation:{translation:[-0.201f,1.377f,0.333f],left_rotation:[0.4041f,-0.0202f,0.0069f,0.9144f]}}
