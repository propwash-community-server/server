data merge entity 11ae4677-4219-56c2-add0-4c64d57ac56a {start_interpolation:0,transformation:{translation:[-0.049f,1.756f,-0.174f],left_rotation:[0.32f,-0.1799f,-0.0017f,0.9302f]}}
data merge entity 7d2a9e32-11f2-50e1-9212-e206c5741830 {start_interpolation:0,transformation:{translation:[0.067f,2.109f,0.167f],left_rotation:[0.4627f,0.3792f,-0.0371f,0.8004f]}}
data merge entity dde4ca15-7054-52aa-b829-17380091a80f {start_interpolation:0,transformation:{translation:[-0.27f,2.151f,0.046f],left_rotation:[0.4557f,-0.1825f,0.1668f,0.8551f]}}
data merge entity f4c9c580-42de-5f18-958e-fe8f13f48db0 {start_interpolation:0,transformation:{translation:[0.044f,1.721f,-0.16f],left_rotation:[0.4037f,0.6254f,0.2936f,0.5998f]}}
data merge entity 593cd5be-38e3-598f-a4f4-75287916d917 {start_interpolation:0,transformation:{translation:[-0.134f,1.744f,-0.223f],left_rotation:[-0.3533f,-0.1406f,-0.096f,0.9199f]}}
data merge entity b93e033a-5262-5632-b8ab-3de10d1c99fe {start_interpolation:0,transformation:{translation:[-0.024f,1.501f,-0.534f],left_rotation:[0.691f,0.6673f,-0.1779f,0.2135f]}}
data merge entity e73b8616-4bc3-571b-bb40-c31cce9d3a8c {start_interpolation:0,transformation:{translation:[-0.256f,1.422f,0.051f],left_rotation:[0.2749f,0.0169f,0.0646f,0.9592f]}}
