data merge entity 11ae4677-4219-56c2-add0-4c64d57ac56a {start_interpolation:0,transformation:{translation:[-0.039f,1.762f,-0.236f],left_rotation:[0.3138f,-0.1416f,0.004f,0.9389f]}}
data merge entity 7d2a9e32-11f2-50e1-9212-e206c5741830 {start_interpolation:0,transformation:{translation:[0.089f,2.125f,0.089f],left_rotation:[0.4486f,0.3554f,-0.0604f,0.8178f],scale:[1f,1f,0.991f]}}
data merge entity dde4ca15-7054-52aa-b829-17380091a80f {start_interpolation:0,transformation:{translation:[-0.257f,2.154f,-0.008f],left_rotation:[0.4428f,-0.1934f,0.1653f,0.8598f]}}
data merge entity f4c9c580-42de-5f18-958e-fe8f13f48db0 {start_interpolation:0,transformation:{translation:[0.056f,1.73f,-0.228f],left_rotation:[0.0749f,0.8719f,0.481f,0.0538f]}}
data merge entity 593cd5be-38e3-598f-a4f4-75287916d917 {start_interpolation:0,transformation:{translation:[-0.127f,1.746f,-0.279f],left_rotation:[-0.3614f,-0.1388f,-0.0915f,0.9175f]}}
data merge entity b93e033a-5262-5632-b8ab-3de10d1c99fe {start_interpolation:0,transformation:{translation:[0.021f,1.499f,-0.6f],left_rotation:[-0.0865f,-0.9231f,0.3743f,0.0181f]}}
data merge entity e73b8616-4bc3-571b-bb40-c31cce9d3a8c {start_interpolation:0,transformation:{translation:[-0.245f,1.428f,0.002f],left_rotation:[0.2418f,0.0143f,0.0535f,0.9688f]}}
