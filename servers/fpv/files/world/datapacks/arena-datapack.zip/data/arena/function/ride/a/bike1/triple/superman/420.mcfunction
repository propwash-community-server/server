data merge entity 11ae4677-4219-56c2-add0-4c64d57ac56a {start_interpolation:0,transformation:{translation:[0f,1.707f,-0.584f],left_rotation:[0.2613f,0f,0f,0.9653f]}}
data merge entity 7d2a9e32-11f2-50e1-9212-e206c5741830 {start_interpolation:0,transformation:{left_rotation:[0.3431f,0.2429f,-0.1423f,0.8961f]}}
data merge entity dde4ca15-7054-52aa-b829-17380091a80f {start_interpolation:0,transformation:{left_rotation:[0.3431f,-0.2429f,0.1423f,0.8961f]}}
data merge entity f4c9c580-42de-5f18-958e-fe8f13f48db0 {start_interpolation:0,transformation:{translation:[0.095f,1.681f,-0.599f]}}
data merge entity 593cd5be-38e3-598f-a4f4-75287916d917 {start_interpolation:0,transformation:{translation:[-0.095f,1.681f,-0.599f]}}
data merge entity b93e033a-5262-5632-b8ab-3de10d1c99fe {start_interpolation:0,transformation:{translation:[0.202f,1.403f,-0.274f],left_rotation:[0.0568f,-0.0009f,-0.0117f,0.9983f]}}
data merge entity e73b8616-4bc3-571b-bb40-c31cce9d3a8c {start_interpolation:0,transformation:{translation:[-0.202f,1.403f,-0.274f],left_rotation:[0.0568f,0.0009f,0.0117f,0.9983f]}}
