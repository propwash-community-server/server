data merge entity 7f895ae6-3a84-58c6-84f5-016612fdd486 {start_interpolation:0,transformation:{translation:[0.05f,1.764f,-0.076f],left_rotation:[0.3548f,0.1852f,0.0095f,0.9164f]}}
data merge entity d5b82b8d-86e1-5276-8680-ed7a08615c7a {start_interpolation:0,transformation:{translation:[0.271f,2.143f,0.172f],left_rotation:[0.4885f,0.1871f,-0.1601f,0.8371f]}}
data merge entity a4c123d3-dfeb-5763-b680-e521fb79538b {start_interpolation:0,transformation:{translation:[-0.064f,2.089f,0.291f],left_rotation:[0.4936f,-0.3835f,0.0197f,0.7803f]}}
data merge entity 14895439-b1c6-5868-83ed-85b5ca16af52 {start_interpolation:0,transformation:{translation:[0.135f,1.756f,-0.127f],left_rotation:[-0.3181f,0.1372f,0.1018f,0.9325f]}}
data merge entity ed503232-ebe9-57f4-8f88-a4efe27a7f4d {start_interpolation:0,transformation:{translation:[-0.042f,1.728f,-0.064f],left_rotation:[0.5471f,-0.594f,-0.1955f,0.5565f]}}
data merge entity 75e3c547-3dab-50d7-a8aa-ffff4a07edfb {start_interpolation:0,transformation:{translation:[0.257f,1.414f,0.122f],left_rotation:[0.3144f,-0.0148f,-0.0667f,0.9468f]}}
data merge entity b4028d78-85e3-5bdd-b8d1-be173b14689d {start_interpolation:0,transformation:{translation:[0.148f,1.585f,-0.434f],left_rotation:[0.7381f,-0.6187f,0.0905f,0.2534f]}}
