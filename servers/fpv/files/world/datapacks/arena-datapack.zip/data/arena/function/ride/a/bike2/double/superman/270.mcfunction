data merge entity 7f895ae6-3a84-58c6-84f5-016612fdd486 {start_interpolation:0,transformation:{translation:[0f,1.975f,-0.002f],left_rotation:[0.7034f,0f,0f,0.7108f]}}
data merge entity d5b82b8d-86e1-5276-8680-ed7a08615c7a {start_interpolation:0,transformation:{translation:[0.18f,1.98f,0.468f],left_rotation:[0.5118f,0.1559f,0.0744f,0.8415f],scale:[1f,1f,1.004f]}}
data merge entity a4c123d3-dfeb-5763-b680-e521fb79538b {start_interpolation:0,transformation:{translation:[-0.18f,1.98f,0.468f],left_rotation:[0.5118f,-0.1559f,-0.0744f,0.8415f],scale:[1f,1f,1.004f]}}
data merge entity 14895439-b1c6-5868-83ed-85b5ca16af52 {start_interpolation:0,transformation:{translation:[0.095f,1.975f,-0.032f],left_rotation:[-0.2642f,0.2892f,0.1778f,0.9027f]}}
data merge entity ed503232-ebe9-57f4-8f88-a4efe27a7f4d {start_interpolation:0,transformation:{translation:[-0.095f,1.975f,-0.032f],left_rotation:[-0.2642f,-0.2892f,-0.1778f,0.9027f]}}
data merge entity 75e3c547-3dab-50d7-a8aa-ffff4a07edfb {start_interpolation:0,transformation:{translation:[0.303f,1.624f,0.133f],left_rotation:[0.3186f,0.2248f,-0.0697f,0.9182f]}}
data merge entity b4028d78-85e3-5bdd-b8d1-be173b14689d {start_interpolation:0,transformation:{translation:[-0.303f,1.624f,0.133f],left_rotation:[0.3186f,-0.2248f,0.0697f,0.9182f]}}
