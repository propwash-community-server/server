data merge entity 11ae4677-4219-56c2-add0-4c64d57ac56a {start_interpolation:0,transformation:{translation:[0f,1.81f,-0.64f],left_rotation:[0.4979f,0f,0f,0.8672f]}}
data merge entity 7d2a9e32-11f2-50e1-9212-e206c5741830 {start_interpolation:0,transformation:{translation:[0.18f,2.047f,-0.234f],left_rotation:[0.3112f,0.1738f,0.0251f,0.934f]}}
data merge entity dde4ca15-7054-52aa-b829-17380091a80f {start_interpolation:0,transformation:{translation:[-0.18f,2.047f,-0.234f],left_rotation:[0.3112f,-0.1738f,-0.0251f,0.934f]}}
data merge entity f4c9c580-42de-5f18-958e-fe8f13f48db0 {start_interpolation:0,transformation:{translation:[0.095f,1.794f,-0.666f],left_rotation:[-0.4373f,0.2964f,0.0757f,0.8457f]}}
data merge entity 593cd5be-38e3-598f-a4f4-75287916d917 {start_interpolation:0,transformation:{translation:[-0.095f,1.794f,-0.666f],left_rotation:[-0.4373f,-0.2964f,-0.0757f,0.8457f]}}
data merge entity b93e033a-5262-5632-b8ab-3de10d1c99fe {start_interpolation:0,transformation:{translation:[0.265f,1.528f,-0.36f],left_rotation:[0.033f,0.1723f,-0.0874f,0.9806f]}}
data merge entity e73b8616-4bc3-571b-bb40-c31cce9d3a8c {start_interpolation:0,transformation:{translation:[-0.265f,1.528f,-0.36f],left_rotation:[0.033f,-0.1723f,0.0874f,0.9806f]}}
