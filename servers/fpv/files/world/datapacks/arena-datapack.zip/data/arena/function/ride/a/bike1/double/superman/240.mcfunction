data merge entity 11ae4677-4219-56c2-add0-4c64d57ac56a {start_interpolation:0,transformation:{translation:[0f,1.744f,-0.537f],left_rotation:[0.3107f,0f,0f,0.9505f]}}
data merge entity 7d2a9e32-11f2-50e1-9212-e206c5741830 {start_interpolation:0,transformation:{translation:[0.18f,2.124f,-0.259f],left_rotation:[0.3665f,0.2378f,-0.117f,0.8919f]}}
data merge entity dde4ca15-7054-52aa-b829-17380091a80f {start_interpolation:0,transformation:{translation:[-0.18f,2.124f,-0.259f],left_rotation:[0.3665f,-0.2378f,0.117f,0.8919f]}}
data merge entity f4c9c580-42de-5f18-958e-fe8f13f48db0 {start_interpolation:0,transformation:{translation:[0.095f,1.72f,-0.554f],left_rotation:[-0.3859f,0.1394f,0.0683f,0.9094f]}}
data merge entity 593cd5be-38e3-598f-a4f4-75287916d917 {start_interpolation:0,transformation:{translation:[-0.095f,1.72f,-0.554f],left_rotation:[-0.3859f,-0.1394f,-0.0683f,0.9094f]}}
data merge entity b93e033a-5262-5632-b8ab-3de10d1c99fe {start_interpolation:0,transformation:{translation:[0.197f,1.415f,-0.254f],left_rotation:[0.0563f,0.0104f,-0.0088f,0.9983f]}}
data merge entity e73b8616-4bc3-571b-bb40-c31cce9d3a8c {start_interpolation:0,transformation:{translation:[-0.197f,1.415f,-0.254f],left_rotation:[0.0563f,-0.0104f,0.0088f,0.9983f]}}
