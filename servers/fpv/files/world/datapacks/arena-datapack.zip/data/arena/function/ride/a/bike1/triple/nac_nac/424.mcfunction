data merge entity 11ae4677-4219-56c2-add0-4c64d57ac56a {start_interpolation:0,transformation:{translation:[-0.05f,1.719f,-0.337f],left_rotation:[0.2529f,-0.1851f,0.0107f,0.9495f]}}
data merge entity 7d2a9e32-11f2-50e1-9212-e206c5741830 {start_interpolation:0,transformation:{translation:[0.064f,2.116f,-0.049f],left_rotation:[0.4058f,0.3791f,-0.0613f,0.8294f]}}
data merge entity dde4ca15-7054-52aa-b829-17380091a80f {start_interpolation:0,transformation:{translation:[-0.271f,2.142f,-0.177f],left_rotation:[0.3945f,-0.1685f,0.1795f,0.8853f]}}
data merge entity f4c9c580-42de-5f18-958e-fe8f13f48db0 {start_interpolation:0,transformation:{translation:[0.042f,1.686f,-0.317f],left_rotation:[0.4833f,0.6117f,0.1296f,0.6128f]}}
data merge entity 593cd5be-38e3-598f-a4f4-75287916d917 {start_interpolation:0,transformation:{translation:[-0.135f,1.7f,-0.385f],left_rotation:[-0.4177f,-0.1475f,-0.0863f,0.8924f]}}
data merge entity b93e033a-5262-5632-b8ab-3de10d1c99fe {start_interpolation:0,transformation:{translation:[-0.148f,1.466f,-0.648f],left_rotation:[0.7061f,0.6052f,-0.1573f,0.3323f]}}
data merge entity e73b8616-4bc3-571b-bb40-c31cce9d3a8c {start_interpolation:0,transformation:{translation:[-0.257f,1.42f,-0.068f],left_rotation:[0.2095f,0.0219f,0.0647f,0.9754f]}}
