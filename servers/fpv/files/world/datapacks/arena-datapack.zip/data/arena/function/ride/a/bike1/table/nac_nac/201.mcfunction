data merge entity 11ae4677-4219-56c2-add0-4c64d57ac56a {start_interpolation:0,transformation:{translation:[-0.05f,1.766f,-0.023f],left_rotation:[0.3747f,-0.1849f,-0.0136f,0.9084f]}}
data merge entity 7d2a9e32-11f2-50e1-9212-e206c5741830 {start_interpolation:0,transformation:{translation:[0.064f,2.075f,0.358f],left_rotation:[0.5105f,0.3838f,-0.0113f,0.7693f]}}
data merge entity dde4ca15-7054-52aa-b829-17380091a80f {start_interpolation:0,transformation:{translation:[-0.271f,2.134f,0.241f],left_rotation:[0.5067f,-0.1905f,0.156f,0.8262f]}}
data merge entity f4c9c580-42de-5f18-958e-fe8f13f48db0 {start_interpolation:0,transformation:{translation:[0.042f,1.729f,-0.012f],left_rotation:[0.5591f,0.5895f,0.2084f,0.5444f]}}
data merge entity 593cd5be-38e3-598f-a4f4-75287916d917 {start_interpolation:0,transformation:{translation:[-0.135f,1.76f,-0.074f],left_rotation:[-0.2976f,-0.135f,-0.1048f,0.9393f]}}
data merge entity b93e033a-5262-5632-b8ab-3de10d1c99fe {start_interpolation:0,transformation:{translation:[-0.148f,1.603f,-0.388f],left_rotation:[0.7435f,0.6205f,-0.077f,0.2372f]}}
data merge entity e73b8616-4bc3-571b-bb40-c31cce9d3a8c {start_interpolation:0,transformation:{translation:[-0.257f,1.408f,0.159f],left_rotation:[0.335f,0.0133f,0.067f,0.9397f]}}
