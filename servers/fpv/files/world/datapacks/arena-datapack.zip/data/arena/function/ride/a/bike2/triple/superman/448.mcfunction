data merge entity 7f895ae6-3a84-58c6-84f5-016612fdd486 {start_interpolation:0,transformation:{translation:[0f,1.968f,-0.473f],left_rotation:[0.6823f,0f,0f,0.7311f]}}
data merge entity d5b82b8d-86e1-5276-8680-ed7a08615c7a {start_interpolation:0,transformation:{translation:[0.18f,2f,-0.004f],left_rotation:[0.3135f,0.1427f,0.0827f,0.9352f]}}
data merge entity a4c123d3-dfeb-5763-b680-e521fb79538b {start_interpolation:0,transformation:{translation:[-0.18f,2f,-0.004f],left_rotation:[0.3135f,-0.1427f,-0.0827f,0.9352f]}}
data merge entity 14895439-b1c6-5868-83ed-85b5ca16af52 {start_interpolation:0,transformation:{translation:[0.095f,1.966f,-0.503f],left_rotation:[0.653f,0.0225f,0.1068f,0.7495f]}}
data merge entity ed503232-ebe9-57f4-8f88-a4efe27a7f4d {start_interpolation:0,transformation:{translation:[-0.095f,1.966f,-0.503f],left_rotation:[0.653f,-0.0225f,-0.1068f,0.7495f]}}
data merge entity 75e3c547-3dab-50d7-a8aa-ffff4a07edfb {start_interpolation:0,transformation:{translation:[0.153f,1.911f,-0.936f],left_rotation:[0.8373f,0.0516f,0.0962f,0.5358f]}}
data merge entity b4028d78-85e3-5bdd-b8d1-be173b14689d {start_interpolation:0,transformation:{translation:[-0.153f,1.911f,-0.936f],left_rotation:[0.8373f,-0.0516f,-0.0962f,0.5358f]}}
