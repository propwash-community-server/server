data merge entity 7f895ae6-3a84-58c6-84f5-016612fdd486 {start_interpolation:0,transformation:{translation:[0.049f,1.757f,-0.163f],left_rotation:[0.3226f,0.183f,0.0027f,0.9287f]}}
data merge entity d5b82b8d-86e1-5276-8680-ed7a08615c7a {start_interpolation:0,transformation:{translation:[0.27f,2.151f,0.058f],left_rotation:[0.4586f,0.1821f,-0.1664f,0.8537f]}}
data merge entity a4c123d3-dfeb-5763-b680-e521fb79538b {start_interpolation:0,transformation:{translation:[-0.065f,2.107f,0.18f],left_rotation:[0.4656f,-0.3811f,0.0344f,0.798f]}}
data merge entity 14895439-b1c6-5868-83ed-85b5ca16af52 {start_interpolation:0,transformation:{translation:[0.135f,1.745f,-0.213f],left_rotation:[-0.3505f,0.1405f,0.0967f,0.9209f]}}
data merge entity ed503232-ebe9-57f4-8f88-a4efe27a7f4d {start_interpolation:0,transformation:{translation:[-0.043f,1.721f,-0.149f],left_rotation:[0.4687f,-0.6103f,-0.2316f,0.5951f]}}
data merge entity 75e3c547-3dab-50d7-a8aa-ffff4a07edfb {start_interpolation:0,transformation:{translation:[0.256f,1.421f,0.059f],left_rotation:[0.2796f,-0.0169f,-0.0655f,0.9577f]}}
data merge entity b4028d78-85e3-5bdd-b8d1-be173b14689d {start_interpolation:0,transformation:{translation:[0.088f,1.522f,-0.519f],left_rotation:[0.7179f,-0.6363f,0.1445f,0.2428f]}}
