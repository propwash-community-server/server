data merge entity dde4ca15-7054-52aa-b829-17380091a80f {start_interpolation:0,transformation:{scale:[1f,1f,1.011f]}}
