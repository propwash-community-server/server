data merge entity 11ae4677-4219-56c2-add0-4c64d57ac56a {start_interpolation:0,transformation:{translation:[-0.05f,1.766f,0.025f],left_rotation:[0.3926f,-0.1846f,-0.0172f,0.9008f]}}
data merge entity 7d2a9e32-11f2-50e1-9212-e206c5741830 {start_interpolation:0,transformation:{translation:[0.064f,2.059f,0.418f],left_rotation:[0.5256f,0.384f,-0.0037f,0.7591f]}}
data merge entity dde4ca15-7054-52aa-b829-17380091a80f {start_interpolation:0,transformation:{translation:[-0.271f,2.123f,0.303f],left_rotation:[0.5229f,-0.1936f,0.1522f,0.816f]}}
data merge entity f4c9c580-42de-5f18-958e-fe8f13f48db0 {start_interpolation:0,transformation:{translation:[0.042f,1.729f,0.034f],left_rotation:[0.5695f,0.5853f,0.2202f,0.5334f]}}
data merge entity 593cd5be-38e3-598f-a4f4-75287916d917 {start_interpolation:0,transformation:{translation:[-0.135f,1.762f,-0.026f],left_rotation:[-0.279f,-0.1329f,-0.1074f,0.945f]}}
data merge entity b93e033a-5262-5632-b8ab-3de10d1c99fe {start_interpolation:0,transformation:{translation:[-0.148f,1.617f,-0.347f],left_rotation:[0.748f,0.622f,-0.0649f,0.2223f]}}
data merge entity e73b8616-4bc3-571b-bb40-c31cce9d3a8c {start_interpolation:0,transformation:{translation:[-0.257f,1.401f,0.193f],left_rotation:[0.3535f,0.012f,0.0673f,0.9329f]}}
