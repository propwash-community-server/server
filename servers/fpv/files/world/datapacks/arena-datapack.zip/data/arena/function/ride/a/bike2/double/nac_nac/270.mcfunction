data merge entity 7f895ae6-3a84-58c6-84f5-016612fdd486 {start_interpolation:0,transformation:{translation:[0.038f,1.765f,0.23f],left_rotation:[0.4865f,0.1366f,0.0221f,0.8626f]}}
data merge entity d5b82b8d-86e1-5276-8680-ed7a08615c7a {start_interpolation:0,transformation:{translation:[0.255f,2.043f,0.589f],left_rotation:[0.5974f,0.2224f,-0.1251f,0.7602f]}}
data merge entity a4c123d3-dfeb-5763-b680-e521fb79538b {start_interpolation:0,transformation:{translation:[-0.091f,1.981f,0.666f],left_rotation:[0.5953f,-0.3588f,-0.006f,0.719f]}}
data merge entity 14895439-b1c6-5868-83ed-85b5ca16af52 {start_interpolation:0,transformation:{translation:[0.126f,1.765f,0.184f],left_rotation:[-0.1806f,0.1187f,0.1159f,0.9695f]}}
data merge entity ed503232-ebe9-57f4-8f88-a4efe27a7f4d {start_interpolation:0,transformation:{translation:[-0.057f,1.733f,0.225f],left_rotation:[0.0713f,-0.782f,-0.6187f,0.0245f]}}
data merge entity 75e3c547-3dab-50d7-a8aa-ffff4a07edfb {start_interpolation:0,transformation:{translation:[0.244f,1.366f,0.326f],left_rotation:[0.4191f,-0.0038f,-0.0543f,0.9063f]}}
data merge entity b4028d78-85e3-5bdd-b8d1-be173b14689d {start_interpolation:0,transformation:{translation:[-0.021f,1.634f,-0.202f],left_rotation:[-0.0645f,0.9777f,-0.1965f,0.0371f]}}
