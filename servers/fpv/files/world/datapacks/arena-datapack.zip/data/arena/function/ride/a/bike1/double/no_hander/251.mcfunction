data merge entity 11ae4677-4219-56c2-add0-4c64d57ac56a {start_interpolation:0,transformation:{translation:[0f,1.801f,0.039f],left_rotation:[0.2309f,0f,0f,0.973f]}}
data merge entity 7d2a9e32-11f2-50e1-9212-e206c5741830 {start_interpolation:0,transformation:{translation:[0.18f,2.221f,0.25f],left_rotation:[-0.3411f,0.4796f,0.2534f,0.7677f]}}
data merge entity dde4ca15-7054-52aa-b829-17380091a80f {start_interpolation:0,transformation:{translation:[-0.18f,2.221f,0.25f],left_rotation:[-0.3411f,-0.4796f,-0.2534f,0.7677f]}}
data merge entity f4c9c580-42de-5f18-958e-fe8f13f48db0 {start_interpolation:0,transformation:{translation:[0.095f,1.774f,0.025f],left_rotation:[-0.2555f,0.0369f,0.0849f,0.9624f]}}
data merge entity 593cd5be-38e3-598f-a4f4-75287916d917 {start_interpolation:0,transformation:{translation:[-0.095f,1.774f,0.025f],left_rotation:[-0.2555f,-0.0369f,-0.0849f,0.9624f]}}
data merge entity b93e033a-5262-5632-b8ab-3de10d1c99fe {start_interpolation:0,transformation:{translation:[0.175f,1.398f,0.239f],left_rotation:[0.3717f,0.0018f,0.0147f,0.9282f]}}
data merge entity e73b8616-4bc3-571b-bb40-c31cce9d3a8c {start_interpolation:0,transformation:{translation:[-0.175f,1.398f,0.239f],left_rotation:[0.3717f,-0.0018f,-0.0147f,0.9282f]}}
