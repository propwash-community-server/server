data merge entity 11ae4677-4219-56c2-add0-4c64d57ac56a {start_interpolation:0,transformation:{translation:[0f,1.886f,-0.666f],left_rotation:[0.6265f,0f,0f,0.7794f]}}
data merge entity 7d2a9e32-11f2-50e1-9212-e206c5741830 {start_interpolation:0,transformation:{translation:[0.18f,1.987f,-0.207f],left_rotation:[0.2488f,0.1486f,0.0721f,0.9544f],scale:[1f,1f,1.064f]}}
data merge entity dde4ca15-7054-52aa-b829-17380091a80f {start_interpolation:0,transformation:{translation:[-0.18f,1.987f,-0.207f],left_rotation:[0.2488f,-0.1486f,-0.0721f,0.9544f],scale:[1f,1f,1.064f]}}
data merge entity f4c9c580-42de-5f18-958e-fe8f13f48db0 {start_interpolation:0,transformation:{translation:[0.095f,1.879f,-0.696f],left_rotation:[0.5062f,0.0201f,0.1081f,0.8554f]}}
data merge entity 593cd5be-38e3-598f-a4f4-75287916d917 {start_interpolation:0,transformation:{translation:[-0.095f,1.879f,-0.696f],left_rotation:[0.5062f,-0.0201f,-0.1081f,0.8554f]}}
data merge entity b93e033a-5262-5632-b8ab-3de10d1c99fe {start_interpolation:0,transformation:{translation:[0.167f,1.675f,-1.079f],left_rotation:[0.8336f,0.0663f,0.0883f,0.5412f]}}
data merge entity e73b8616-4bc3-571b-bb40-c31cce9d3a8c {start_interpolation:0,transformation:{translation:[-0.167f,1.675f,-1.079f],left_rotation:[0.8336f,-0.0663f,-0.0883f,0.5412f]}}
