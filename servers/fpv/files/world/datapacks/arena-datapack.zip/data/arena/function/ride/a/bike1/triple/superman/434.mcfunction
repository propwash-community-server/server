data merge entity 11ae4677-4219-56c2-add0-4c64d57ac56a {start_interpolation:0,transformation:{translation:[0f,2.024f,-0.248f],left_rotation:[0.737f,0f,0f,0.6758f]}}
data merge entity 7d2a9e32-11f2-50e1-9212-e206c5741830 {start_interpolation:0,transformation:{translation:[0.18f,1.983f,0.22f],left_rotation:[0.3852f,0.1358f,0.0936f,0.908f]}}
data merge entity dde4ca15-7054-52aa-b829-17380091a80f {start_interpolation:0,transformation:{translation:[-0.18f,1.983f,0.22f],left_rotation:[0.3852f,-0.1358f,-0.0936f,0.908f]}}
data merge entity f4c9c580-42de-5f18-958e-fe8f13f48db0 {start_interpolation:0,transformation:{translation:[0.095f,2.027f,-0.278f],left_rotation:[0.7093f,0.0141f,0.1082f,0.6965f]}}
data merge entity 593cd5be-38e3-598f-a4f4-75287916d917 {start_interpolation:0,transformation:{translation:[-0.095f,2.027f,-0.278f],left_rotation:[0.7093f,-0.0141f,-0.1082f,0.6965f]}}
data merge entity b93e033a-5262-5632-b8ab-3de10d1c99fe {start_interpolation:0,transformation:{translation:[0.153f,2.04f,-0.714f],left_rotation:[0.8764f,0.044f,0.0999f,0.4691f]}}
data merge entity e73b8616-4bc3-571b-bb40-c31cce9d3a8c {start_interpolation:0,transformation:{translation:[-0.153f,2.04f,-0.714f],left_rotation:[0.8764f,-0.044f,-0.0999f,0.4691f]}}
