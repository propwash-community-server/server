data merge entity 11ae4677-4219-56c2-add0-4c64d57ac56a {start_interpolation:0,transformation:{translation:[0f,1.791f,-0.724f],left_rotation:[0.5143f,0f,0f,0.8576f]}}
data merge entity 7d2a9e32-11f2-50e1-9212-e206c5741830 {start_interpolation:0,transformation:{translation:[0.18f,2.013f,-0.309f],left_rotation:[0.2657f,0.1658f,0.0408f,0.9488f],scale:[1f,1f,1.011f]}}
data merge entity dde4ca15-7054-52aa-b829-17380091a80f {start_interpolation:0,transformation:{translation:[-0.18f,2.013f,-0.309f],left_rotation:[0.2657f,-0.1658f,-0.0408f,0.9488f],scale:[1f,1f,1.011f]}}
data merge entity f4c9c580-42de-5f18-958e-fe8f13f48db0 {start_interpolation:0,transformation:{translation:[0.095f,1.777f,-0.751f],left_rotation:[-0.5132f,0.3074f,0.131f,0.7906f]}}
data merge entity 593cd5be-38e3-598f-a4f4-75287916d917 {start_interpolation:0,transformation:{translation:[-0.095f,1.777f,-0.751f],left_rotation:[-0.5132f,-0.3074f,-0.131f,0.7906f]}}
data merge entity b93e033a-5262-5632-b8ab-3de10d1c99fe {start_interpolation:0,transformation:{translation:[0.325f,1.584f,-0.429f],left_rotation:[0.1613f,0.2061f,-0.1369f,0.9554f]}}
data merge entity e73b8616-4bc3-571b-bb40-c31cce9d3a8c {start_interpolation:0,transformation:{translation:[-0.325f,1.584f,-0.429f],left_rotation:[0.1613f,-0.2061f,0.1369f,0.9554f]}}
