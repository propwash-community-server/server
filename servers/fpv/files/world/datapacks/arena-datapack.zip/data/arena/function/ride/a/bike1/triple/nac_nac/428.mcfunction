data merge entity 11ae4677-4219-56c2-add0-4c64d57ac56a {start_interpolation:0,transformation:{translation:[-0.05f,1.757f,-0.152f],left_rotation:[0.326f,-0.1854f,-0.0038f,0.927f]}}
data merge entity 7d2a9e32-11f2-50e1-9212-e206c5741830 {start_interpolation:0,transformation:{translation:[0.064f,2.104f,0.195f],left_rotation:[0.469f,0.3827f,-0.0317f,0.7953f]}}
data merge entity dde4ca15-7054-52aa-b829-17380091a80f {start_interpolation:0,transformation:{translation:[-0.271f,2.15f,0.072f],left_rotation:[0.4621f,-0.182f,0.1659f,0.8519f]}}
data merge entity f4c9c580-42de-5f18-958e-fe8f13f48db0 {start_interpolation:0,transformation:{translation:[0.042f,1.721f,-0.137f],left_rotation:[0.5294f,0.5998f,0.1768f,0.5733f]}}
data merge entity 593cd5be-38e3-598f-a4f4-75287916d917 {start_interpolation:0,transformation:{translation:[-0.135f,1.746f,-0.202f],left_rotation:[-0.3471f,-0.1403f,-0.0975f,0.9221f]}}
data merge entity b93e033a-5262-5632-b8ab-3de10d1c99fe {start_interpolation:0,transformation:{translation:[-0.148f,1.555f,-0.498f],left_rotation:[0.7298f,0.6156f,-0.1098f,0.2764f]}}
data merge entity e73b8616-4bc3-571b-bb40-c31cce9d3a8c {start_interpolation:0,transformation:{translation:[-0.257f,1.42f,0.067f],left_rotation:[0.2847f,0.0168f,0.0662f,0.9562f]}}
