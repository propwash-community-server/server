data merge entity 7f895ae6-3a84-58c6-84f5-016612fdd486 {start_interpolation:0,transformation:{translation:[0.011f,1.818f,0.179f],left_rotation:[0.5117f,0.039f,0.0038f,0.8583f]}}
data merge entity d5b82b8d-86e1-5276-8680-ed7a08615c7a {start_interpolation:0,transformation:{translation:[0.206f,2.05f,0.581f],left_rotation:[0.5939f,0.2631f,-0.0933f,0.7546f]}}
data merge entity a4c123d3-dfeb-5763-b680-e521fb79538b {start_interpolation:0,transformation:{translation:[-0.153f,2.033f,0.603f],left_rotation:[0.5927f,-0.3051f,0.0515f,0.7436f],scale:[1f,1f,1.004f]}}
data merge entity 14895439-b1c6-5868-83ed-85b5ca16af52 {start_interpolation:0,transformation:{translation:[0.105f,1.808f,0.147f],left_rotation:[-0.155f,0.1109f,0.1094f,0.9756f]}}
data merge entity ed503232-ebe9-57f4-8f88-a4efe27a7f4d {start_interpolation:0,transformation:{translation:[-0.085f,1.799f,0.159f],left_rotation:[-0.1581f,-0.1062f,-0.1179f,0.9746f]}}
data merge entity 75e3c547-3dab-50d7-a8aa-ffff4a07edfb {start_interpolation:0,transformation:{translation:[0.214f,1.399f,0.269f],left_rotation:[0.3679f,-0.0009f,-0.0234f,0.9296f]}}
data merge entity b4028d78-85e3-5bdd-b8d1-be173b14689d {start_interpolation:0,transformation:{translation:[-0.201f,1.393f,0.283f],left_rotation:[0.3818f,-0.031f,0.0061f,0.9237f]}}
