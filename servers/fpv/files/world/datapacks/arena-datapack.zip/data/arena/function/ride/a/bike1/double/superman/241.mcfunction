data merge entity 11ae4677-4219-56c2-add0-4c64d57ac56a {start_interpolation:0,transformation:{translation:[0f,1.773f,-0.577f],left_rotation:[0.3952f,0f,0f,0.9186f]}}
data merge entity 7d2a9e32-11f2-50e1-9212-e206c5741830 {start_interpolation:0,transformation:{translation:[0.18f,2.096f,-0.235f],left_rotation:[0.3554f,0.2069f,-0.0488f,0.9102f],scale:[1f,1f,0.994f]}}
data merge entity dde4ca15-7054-52aa-b829-17380091a80f {start_interpolation:0,transformation:{translation:[-0.18f,2.096f,-0.235f],left_rotation:[0.3554f,-0.2069f,0.0488f,0.9102f],scale:[1f,1f,0.994f]}}
data merge entity f4c9c580-42de-5f18-958e-fe8f13f48db0 {start_interpolation:0,transformation:{translation:[0.095f,1.753f,-0.598f],left_rotation:[-0.3413f,0.1729f,0.0468f,0.9227f]}}
data merge entity 593cd5be-38e3-598f-a4f4-75287916d917 {start_interpolation:0,transformation:{translation:[-0.095f,1.753f,-0.598f],left_rotation:[-0.3413f,-0.1729f,-0.0468f,0.9227f]}}
data merge entity b93e033a-5262-5632-b8ab-3de10d1c99fe {start_interpolation:0,transformation:{translation:[0.185f,1.417f,-0.328f],left_rotation:[-0.0316f,0.0545f,-0.0066f,0.998f]}}
data merge entity e73b8616-4bc3-571b-bb40-c31cce9d3a8c {start_interpolation:0,transformation:{translation:[-0.185f,1.417f,-0.328f],left_rotation:[-0.0316f,-0.0545f,0.0066f,0.998f]}}
