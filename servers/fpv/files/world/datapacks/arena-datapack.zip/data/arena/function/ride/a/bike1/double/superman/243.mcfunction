data merge entity 11ae4677-4219-56c2-add0-4c64d57ac56a {start_interpolation:0,transformation:{translation:[0f,1.85f,-0.681f],left_rotation:[0.5817f,0f,0f,0.8134f]}}
data merge entity 7d2a9e32-11f2-50e1-9212-e206c5741830 {start_interpolation:0,transformation:{translation:[0.18f,2.002f,-0.236f],left_rotation:[0.2619f,0.1556f,0.0623f,0.9504f],scale:[1f,1f,1.036f]}}
data merge entity dde4ca15-7054-52aa-b829-17380091a80f {start_interpolation:0,transformation:{translation:[-0.18f,2.002f,-0.236f],left_rotation:[0.2619f,-0.1556f,-0.0623f,0.9504f],scale:[1f,1f,1.036f]}}
data merge entity f4c9c580-42de-5f18-958e-fe8f13f48db0 {start_interpolation:0,transformation:{translation:[0.095f,1.84f,-0.709f],left_rotation:[-0.3115f,0.005f,0.1164f,0.9431f]}}
data merge entity 593cd5be-38e3-598f-a4f4-75287916d917 {start_interpolation:0,transformation:{translation:[-0.095f,1.84f,-0.709f],left_rotation:[-0.3115f,-0.005f,-0.1164f,0.9431f]}}
data merge entity b93e033a-5262-5632-b8ab-3de10d1c99fe {start_interpolation:0,transformation:{translation:[0.193f,1.498f,-0.451f],left_rotation:[0.6612f,0.0969f,0.0482f,0.7424f]}}
data merge entity e73b8616-4bc3-571b-bb40-c31cce9d3a8c {start_interpolation:0,transformation:{translation:[-0.193f,1.498f,-0.451f],left_rotation:[0.6612f,-0.0969f,-0.0482f,0.7424f]}}
