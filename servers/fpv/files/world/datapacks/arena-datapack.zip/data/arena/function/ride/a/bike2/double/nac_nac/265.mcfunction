data merge entity 7f895ae6-3a84-58c6-84f5-016612fdd486 {start_interpolation:0,transformation:{translation:[0.05f,1.766f,0.026f],left_rotation:[0.393f,0.1846f,0.0173f,0.9007f]}}
data merge entity d5b82b8d-86e1-5276-8680-ed7a08615c7a {start_interpolation:0,transformation:{translation:[0.271f,2.123f,0.305f],left_rotation:[0.5233f,0.1936f,-0.1521f,0.8158f]}}
data merge entity a4c123d3-dfeb-5763-b680-e521fb79538b {start_interpolation:0,transformation:{translation:[-0.064f,2.059f,0.419f],left_rotation:[0.526f,-0.384f,0.0036f,0.7589f]}}
data merge entity 14895439-b1c6-5868-83ed-85b5ca16af52 {start_interpolation:0,transformation:{translation:[0.135f,1.762f,-0.025f],left_rotation:[-0.2786f,0.1328f,0.1075f,0.9451f]}}
data merge entity ed503232-ebe9-57f4-8f88-a4efe27a7f4d {start_interpolation:0,transformation:{translation:[-0.042f,1.729f,0.035f],left_rotation:[0.57f,-0.5852f,-0.2202f,0.533f]}}
data merge entity 75e3c547-3dab-50d7-a8aa-ffff4a07edfb {start_interpolation:0,transformation:{translation:[0.257f,1.401f,0.194f],left_rotation:[0.354f,-0.012f,-0.0673f,0.9328f]}}
data merge entity b4028d78-85e3-5bdd-b8d1-be173b14689d {start_interpolation:0,transformation:{translation:[0.148f,1.617f,-0.346f],left_rotation:[0.7481f,-0.622f,0.0644f,0.2222f]}}
