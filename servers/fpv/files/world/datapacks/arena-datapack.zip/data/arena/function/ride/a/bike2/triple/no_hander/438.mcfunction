data merge entity 7f895ae6-3a84-58c6-84f5-016612fdd486 {start_interpolation:0,transformation:{left_rotation:[0.2444f,0f,0f,0.9697f]}}
data merge entity d5b82b8d-86e1-5276-8680-ed7a08615c7a {start_interpolation:0,transformation:{left_rotation:[0.332f,0.2432f,-0.1513f,0.8988f]}}
data merge entity a4c123d3-dfeb-5763-b680-e521fb79538b {start_interpolation:0,transformation:{left_rotation:[0.332f,-0.2432f,0.1513f,0.8988f]}}
