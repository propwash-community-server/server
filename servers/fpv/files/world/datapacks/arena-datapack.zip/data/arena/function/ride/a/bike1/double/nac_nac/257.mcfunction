data merge entity 11ae4677-4219-56c2-add0-4c64d57ac56a {start_interpolation:0,transformation:{left_rotation:[0.5618f,-0.0041f,-0.0005f,0.8272f]}}
data merge entity 7d2a9e32-11f2-50e1-9212-e206c5741830 {start_interpolation:0,transformation:{scale:[1f,1f,1.012f]}}
data merge entity dde4ca15-7054-52aa-b829-17380091a80f {start_interpolation:0,transformation:{scale:[1f,1f,1.012f]}}
data merge entity b93e033a-5262-5632-b8ab-3de10d1c99fe {start_interpolation:0,transformation:{left_rotation:[0.3926f,0.0034f,-0.0099f,0.9196f]}}
