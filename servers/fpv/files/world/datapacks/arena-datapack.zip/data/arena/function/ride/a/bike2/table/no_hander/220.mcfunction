data merge entity 7f895ae6-3a84-58c6-84f5-016612fdd486 {start_interpolation:0,transformation:{translation:[0f,1.812f,0.058f],left_rotation:[0.3059f,0f,0f,0.9521f]}}
data merge entity d5b82b8d-86e1-5276-8680-ed7a08615c7a {start_interpolation:0,transformation:{translation:[0.18f,2.195f,0.332f],left_rotation:[0.0404f,0.4179f,0.0218f,0.9073f],scale:[1f,1f,0.7f]}}
data merge entity a4c123d3-dfeb-5763-b680-e521fb79538b {start_interpolation:0,transformation:{translation:[-0.18f,2.195f,0.332f],left_rotation:[0.0404f,-0.4179f,-0.0218f,0.9073f],scale:[1f,1f,0.7f]}}
data merge entity 14895439-b1c6-5868-83ed-85b5ca16af52 {start_interpolation:0,transformation:{translation:[0.095f,1.788f,0.041f],left_rotation:[-0.2332f,0.0551f,0.0914f,0.9666f]}}
data merge entity ed503232-ebe9-57f4-8f88-a4efe27a7f4d {start_interpolation:0,transformation:{translation:[-0.095f,1.788f,0.041f],left_rotation:[-0.2332f,-0.0551f,-0.0914f,0.9666f]}}
data merge entity 75e3c547-3dab-50d7-a8aa-ffff4a07edfb {start_interpolation:0,transformation:{translation:[0.184f,1.403f,0.234f],left_rotation:[0.3626f,0.0006f,0.0059f,0.9319f]}}
data merge entity b4028d78-85e3-5bdd-b8d1-be173b14689d {start_interpolation:0,transformation:{translation:[-0.184f,1.403f,0.234f],left_rotation:[0.3626f,-0.0006f,-0.0059f,0.9319f]}}
