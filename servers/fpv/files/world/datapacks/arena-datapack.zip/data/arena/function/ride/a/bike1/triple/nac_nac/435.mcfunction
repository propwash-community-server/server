data merge entity 11ae4677-4219-56c2-add0-4c64d57ac56a {start_interpolation:0,transformation:{translation:[-0.038f,1.778f,0.143f],left_rotation:[0.4556f,-0.1373f,-0.0172f,0.8794f]}}
data merge entity 7d2a9e32-11f2-50e1-9212-e206c5741830 {start_interpolation:0,transformation:{translation:[0.091f,2.025f,0.563f],left_rotation:[0.5694f,0.3587f,-0.0067f,0.7396f]}}
data merge entity dde4ca15-7054-52aa-b829-17380091a80f {start_interpolation:0,transformation:{translation:[-0.255f,2.081f,0.481f],left_rotation:[0.5701f,-0.2178f,0.1329f,0.781f]}}
data merge entity f4c9c580-42de-5f18-958e-fe8f13f48db0 {start_interpolation:0,transformation:{translation:[0.057f,1.746f,0.14f],left_rotation:[0.0704f,0.8035f,0.5905f,0.027f]}}
data merge entity 593cd5be-38e3-598f-a4f4-75287916d917 {start_interpolation:0,transformation:{translation:[-0.126f,1.775f,0.097f],left_rotation:[-0.2149f,-0.1228f,-0.1116f,0.9624f]}}
data merge entity b93e033a-5262-5632-b8ab-3de10d1c99fe {start_interpolation:0,transformation:{translation:[0.021f,1.617f,-0.279f],left_rotation:[-0.0658f,-0.9701f,0.2311f,0.0348f]}}
data merge entity e73b8616-4bc3-571b-bb40-c31cce9d3a8c {start_interpolation:0,transformation:{translation:[-0.244f,1.387f,0.267f],left_rotation:[0.3867f,0.0057f,0.0541f,0.9206f]}}
