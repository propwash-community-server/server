data merge entity 7f895ae6-3a84-58c6-84f5-016612fdd486 {start_interpolation:0,transformation:{translation:[0.025f,1.772f,-0.295f],left_rotation:[0.3164f,0.0906f,-0.0063f,0.9443f]}}
data merge entity d5b82b8d-86e1-5276-8680-ed7a08615c7a {start_interpolation:0,transformation:{translation:[0.235f,2.156f,-0.046f],left_rotation:[0.4334f,0.2132f,-0.1577f,0.8613f],scale:[1f,1f,1.002f]}}
data merge entity a4c123d3-dfeb-5763-b680-e521fb79538b {start_interpolation:0,transformation:{translation:[-0.12f,2.139f,0.017f],left_rotation:[0.4369f,-0.3227f,0.087f,0.8351f],scale:[1f,1f,0.996f]}}
data merge entity 14895439-b1c6-5868-83ed-85b5ca16af52 {start_interpolation:0,transformation:{translation:[0.116f,1.752f,-0.329f],left_rotation:[-0.3608f,0.1352f,0.0875f,0.9186f]}}
data merge entity ed503232-ebe9-57f4-8f88-a4efe27a7f4d {start_interpolation:0,transformation:{translation:[-0.071f,1.743f,-0.296f],left_rotation:[-0.3782f,-0.2492f,-0.1357f,0.8812f]}}
data merge entity 75e3c547-3dab-50d7-a8aa-ffff4a07edfb {start_interpolation:0,transformation:{translation:[0.23f,1.433f,-0.048f],left_rotation:[0.2056f,-0.0101f,-0.0387f,0.9778f]}}
data merge entity b4028d78-85e3-5bdd-b8d1-be173b14689d {start_interpolation:0,transformation:{translation:[-0.259f,1.446f,-0.032f],left_rotation:[0.2345f,-0.1157f,0.0889f,0.9611f]}}
