data merge entity 11ae4677-4219-56c2-add0-4c64d57ac56a {start_interpolation:0,transformation:{translation:[0f,1.819f,0.182f],left_rotation:[0.4464f,0f,0f,0.8948f]}}
data merge entity 7d2a9e32-11f2-50e1-9212-e206c5741830 {start_interpolation:0,transformation:{translation:[0.18f,2.101f,0.557f],left_rotation:[0.4794f,0.3313f,-0.1343f,0.8015f],scale:[1f,1f,0.922f]}}
data merge entity dde4ca15-7054-52aa-b829-17380091a80f {start_interpolation:0,transformation:{translation:[-0.18f,2.101f,0.557f],left_rotation:[0.4794f,-0.3313f,0.1343f,0.8015f],scale:[1f,1f,0.922f]}}
data merge entity f4c9c580-42de-5f18-958e-fe8f13f48db0 {start_interpolation:0,transformation:{translation:[0.095f,1.801f,0.158f],left_rotation:[-0.16f,0.079f,0.1025f,0.9786f]}}
data merge entity 593cd5be-38e3-598f-a4f4-75287916d917 {start_interpolation:0,transformation:{translation:[-0.095f,1.801f,0.158f],left_rotation:[-0.16f,-0.079f,-0.1025f,0.9786f]}}
data merge entity b93e033a-5262-5632-b8ab-3de10d1c99fe {start_interpolation:0,transformation:{translation:[0.194f,1.392f,0.289f],left_rotation:[0.3811f,-0.0001f,-0.0044f,0.9245f]}}
data merge entity e73b8616-4bc3-571b-bb40-c31cce9d3a8c {start_interpolation:0,transformation:{translation:[-0.194f,1.392f,0.289f],left_rotation:[0.3811f,0.0001f,0.0044f,0.9245f]}}
