data merge entity 11ae4677-4219-56c2-add0-4c64d57ac56a {start_interpolation:0,transformation:{translation:[-0.011f,1.73f,-0.486f],left_rotation:[0.2679f,-0.0405f,0.0068f,0.9626f]}}
data merge entity 7d2a9e32-11f2-50e1-9212-e206c5741830 {start_interpolation:0,transformation:{translation:[0.152f,2.131f,-0.23f],left_rotation:[0.3749f,0.2809f,-0.1268f,0.8743f]}}
data merge entity dde4ca15-7054-52aa-b829-17380091a80f {start_interpolation:0,transformation:{translation:[-0.207f,2.134f,-0.259f],left_rotation:[0.3729f,-0.2269f,0.1571f,0.8859f]}}
data merge entity f4c9c580-42de-5f18-958e-fe8f13f48db0 {start_interpolation:0,transformation:{translation:[0.084f,1.704f,-0.494f],left_rotation:[-0.4134f,0.1345f,0.0874f,0.8963f]}}
data merge entity 593cd5be-38e3-598f-a4f4-75287916d917 {start_interpolation:0,transformation:{translation:[-0.105f,1.705f,-0.51f],left_rotation:[-0.4105f,-0.1363f,-0.0774f,0.8983f]}}
data merge entity b93e033a-5262-5632-b8ab-3de10d1c99fe {start_interpolation:0,transformation:{translation:[0.202f,1.421f,-0.178f],left_rotation:[0.1299f,0.0297f,-0.0156f,0.991f]}}
data merge entity e73b8616-4bc3-571b-bb40-c31cce9d3a8c {start_interpolation:0,transformation:{translation:[-0.215f,1.419f,-0.194f],left_rotation:[0.1143f,0.0075f,0.0241f,0.9931f]}}
