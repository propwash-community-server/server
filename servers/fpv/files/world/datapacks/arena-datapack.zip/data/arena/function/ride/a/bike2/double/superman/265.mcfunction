data merge entity 7f895ae6-3a84-58c6-84f5-016612fdd486 {start_interpolation:0,transformation:{translation:[0f,2.001f,-0.357f],left_rotation:[0.7114f,0f,0f,0.7028f]}}
data merge entity d5b82b8d-86e1-5276-8680-ed7a08615c7a {start_interpolation:0,transformation:{translation:[0.18f,1.996f,0.113f],left_rotation:[0.3512f,0.1392f,0.0885f,0.9216f]}}
data merge entity a4c123d3-dfeb-5763-b680-e521fb79538b {start_interpolation:0,transformation:{translation:[-0.18f,1.996f,0.113f],left_rotation:[0.3512f,-0.1392f,-0.0885f,0.9216f]}}
data merge entity 14895439-b1c6-5868-83ed-85b5ca16af52 {start_interpolation:0,transformation:{translation:[0.095f,2.002f,-0.387f],left_rotation:[0.6829f,0.0181f,0.1076f,0.7223f]}}
data merge entity ed503232-ebe9-57f4-8f88-a4efe27a7f4d {start_interpolation:0,transformation:{translation:[-0.095f,2.002f,-0.387f],left_rotation:[0.6829f,-0.0181f,-0.1076f,0.7223f]}}
data merge entity 75e3c547-3dab-50d7-a8aa-ffff4a07edfb {start_interpolation:0,transformation:{translation:[0.153f,1.982f,-0.822f],left_rotation:[0.8584f,0.0476f,0.0982f,0.5013f]}}
data merge entity b4028d78-85e3-5bdd-b8d1-be173b14689d {start_interpolation:0,transformation:{translation:[-0.153f,1.982f,-0.822f],left_rotation:[0.8584f,-0.0476f,-0.0982f,0.5013f]}}
