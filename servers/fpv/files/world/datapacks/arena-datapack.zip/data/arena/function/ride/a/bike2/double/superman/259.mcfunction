data merge entity 7f895ae6-3a84-58c6-84f5-016612fdd486 {start_interpolation:0,transformation:{translation:[0f,1.859f,-0.679f],left_rotation:[0.5949f,0f,0f,0.8038f]}}
data merge entity d5b82b8d-86e1-5276-8680-ed7a08615c7a {start_interpolation:0,transformation:{translation:[0.18f,1.997f,-0.23f],left_rotation:[0.2568f,0.1534f,0.0658f,0.9519f],scale:[1f,1f,1.044f]}}
data merge entity a4c123d3-dfeb-5763-b680-e521fb79538b {start_interpolation:0,transformation:{translation:[-0.18f,1.997f,-0.23f],left_rotation:[0.2568f,-0.1534f,-0.0658f,0.9519f],scale:[1f,1f,1.044f]}}
data merge entity 14895439-b1c6-5868-83ed-85b5ca16af52 {start_interpolation:0,transformation:{translation:[0.095f,1.851f,-0.708f],left_rotation:[-0.1029f,-0.0117f,0.1125f,0.9882f]}}
data merge entity ed503232-ebe9-57f4-8f88-a4efe27a7f4d {start_interpolation:0,transformation:{translation:[-0.095f,1.851f,-0.708f],left_rotation:[-0.1029f,0.0117f,-0.1125f,0.9882f]}}
data merge entity 75e3c547-3dab-50d7-a8aa-ffff4a07edfb {start_interpolation:0,transformation:{translation:[0.192f,1.431f,-0.617f],left_rotation:[0.787f,0.0904f,0.0702f,0.6062f]}}
data merge entity b4028d78-85e3-5bdd-b8d1-be173b14689d {start_interpolation:0,transformation:{translation:[-0.192f,1.431f,-0.617f],left_rotation:[0.787f,-0.0904f,-0.0702f,0.6062f]}}
