data merge entity 7f895ae6-3a84-58c6-84f5-016612fdd486 {start_interpolation:0,transformation:{translation:[0.05f,1.747f,-0.216f],left_rotation:[0.3012f,0.1854f,-0.0012f,0.9354f]}}
data merge entity d5b82b8d-86e1-5276-8680-ed7a08615c7a {start_interpolation:0,transformation:{translation:[0.271f,2.152f,-0.013f],left_rotation:[0.4393f,0.1775f,-0.1707f,0.8639f]}}
data merge entity a4c123d3-dfeb-5763-b680-e521fb79538b {start_interpolation:0,transformation:{translation:[-0.064f,2.112f,0.112f],left_rotation:[0.4477f,-0.3817f,0.0418f,0.8075f]}}
data merge entity 14895439-b1c6-5868-83ed-85b5ca16af52 {start_interpolation:0,transformation:{translation:[0.135f,1.733f,-0.265f],left_rotation:[-0.3714f,0.1429f,0.0937f,0.9126f]}}
data merge entity ed503232-ebe9-57f4-8f88-a4efe27a7f4d {start_interpolation:0,transformation:{translation:[-0.042f,1.712f,-0.199f],left_rotation:[0.514f,-0.6043f,-0.1608f,0.5872f]}}
data merge entity 75e3c547-3dab-50d7-a8aa-ffff4a07edfb {start_interpolation:0,transformation:{translation:[0.257f,1.422f,0.021f],left_rotation:[0.2592f,-0.0186f,-0.0657f,0.9634f]}}
data merge entity b4028d78-85e3-5bdd-b8d1-be173b14689d {start_interpolation:0,transformation:{translation:[0.148f,1.528f,-0.551f],left_rotation:[0.7222f,-0.6124f,0.1261f,0.2957f]}}
