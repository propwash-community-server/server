data merge entity 7f895ae6-3a84-58c6-84f5-016612fdd486 {start_interpolation:0,transformation:{translation:[0.05f,1.761f,-0.112f],left_rotation:[0.3411f,0.1853f,0.0068f,0.9216f]}}
data merge entity d5b82b8d-86e1-5276-8680-ed7a08615c7a {start_interpolation:0,transformation:{translation:[0.271f,2.147f,0.124f],left_rotation:[0.476f,0.1847f,-0.1629f,0.8443f]}}
data merge entity a4c123d3-dfeb-5763-b680-e521fb79538b {start_interpolation:0,transformation:{translation:[-0.064f,2.097f,0.245f],left_rotation:[0.4819f,-0.3832f,0.0254f,0.7876f]}}
data merge entity 14895439-b1c6-5868-83ed-85b5ca16af52 {start_interpolation:0,transformation:{translation:[0.135f,1.752f,-0.163f],left_rotation:[-0.332f,0.1387f,0.0998f,0.9277f]}}
data merge entity ed503232-ebe9-57f4-8f88-a4efe27a7f4d {start_interpolation:0,transformation:{translation:[-0.042f,1.725f,-0.099f],left_rotation:[0.5387f,-0.5968f,-0.1866f,0.5646f]}}
data merge entity 75e3c547-3dab-50d7-a8aa-ffff4a07edfb {start_interpolation:0,transformation:{translation:[0.257f,1.417f,0.096f],left_rotation:[0.3003f,-0.0158f,-0.0665f,0.9514f]}}
data merge entity b4028d78-85e3-5bdd-b8d1-be173b14689d {start_interpolation:0,transformation:{translation:[0.148f,1.571f,-0.465f],left_rotation:[0.7342f,-0.6173f,0.0998f,0.2644f]}}
