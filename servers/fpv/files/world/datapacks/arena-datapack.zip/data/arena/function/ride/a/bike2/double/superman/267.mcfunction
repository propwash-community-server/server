data merge entity 7f895ae6-3a84-58c6-84f5-016612fdd486 {start_interpolation:0,transformation:{translation:[0f,2.025f,-0.242f],left_rotation:[0.7383f,0f,0f,0.6745f]}}
data merge entity d5b82b8d-86e1-5276-8680-ed7a08615c7a {start_interpolation:0,transformation:{translation:[0.18f,1.982f,0.226f],left_rotation:[0.3869f,0.1357f,0.0938f,0.9073f]}}
data merge entity a4c123d3-dfeb-5763-b680-e521fb79538b {start_interpolation:0,transformation:{translation:[-0.18f,1.982f,0.226f],left_rotation:[0.3869f,-0.1357f,-0.0938f,0.9073f]}}
data merge entity 14895439-b1c6-5868-83ed-85b5ca16af52 {start_interpolation:0,transformation:{translation:[0.095f,2.028f,-0.272f],left_rotation:[0.7105f,0.0139f,0.1082f,0.6951f]}}
data merge entity ed503232-ebe9-57f4-8f88-a4efe27a7f4d {start_interpolation:0,transformation:{translation:[-0.095f,2.028f,-0.272f],left_rotation:[0.7105f,-0.0139f,-0.1082f,0.6951f]}}
data merge entity 75e3c547-3dab-50d7-a8aa-ffff4a07edfb {start_interpolation:0,transformation:{translation:[0.153f,2.042f,-0.708f],left_rotation:[0.8773f,0.0438f,0.1f,0.4674f]}}
data merge entity b4028d78-85e3-5bdd-b8d1-be173b14689d {start_interpolation:0,transformation:{translation:[-0.153f,2.042f,-0.708f],left_rotation:[0.8773f,-0.0438f,-0.1f,0.4674f]}}
