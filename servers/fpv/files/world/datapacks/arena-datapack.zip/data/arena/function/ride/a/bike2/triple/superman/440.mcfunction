data merge entity 7f895ae6-3a84-58c6-84f5-016612fdd486 {start_interpolation:0,transformation:{translation:[0f,1.747f,-0.641f],left_rotation:[0.3832f,0f,0f,0.9237f]}}
data merge entity d5b82b8d-86e1-5276-8680-ed7a08615c7a {start_interpolation:0,transformation:{translation:[0.18f,2.079f,-0.308f],left_rotation:[0.3301f,0.2021f,-0.0455f,0.9209f],scale:[1f,1f,0.993f]}}
data merge entity a4c123d3-dfeb-5763-b680-e521fb79538b {start_interpolation:0,transformation:{translation:[-0.18f,2.079f,-0.308f],left_rotation:[0.3301f,-0.2021f,0.0455f,0.9209f],scale:[1f,1f,0.993f]}}
data merge entity 14895439-b1c6-5868-83ed-85b5ca16af52 {start_interpolation:0,transformation:{translation:[0.095f,1.726f,-0.662f],left_rotation:[-0.3625f,0.1807f,0.0405f,0.9134f]}}
data merge entity ed503232-ebe9-57f4-8f88-a4efe27a7f4d {start_interpolation:0,transformation:{translation:[-0.095f,1.726f,-0.662f],left_rotation:[-0.3625f,-0.1807f,-0.0405f,0.9134f]}}
data merge entity 75e3c547-3dab-50d7-a8aa-ffff4a07edfb {start_interpolation:0,transformation:{translation:[0.185f,1.403f,-0.377f],left_rotation:[-0.0636f,0.0615f,-0.0096f,0.996f]}}
data merge entity b4028d78-85e3-5bdd-b8d1-be173b14689d {start_interpolation:0,transformation:{translation:[-0.185f,1.403f,-0.377f],left_rotation:[-0.0636f,-0.0615f,0.0096f,0.996f]}}
