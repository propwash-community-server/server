data merge entity 7f895ae6-3a84-58c6-84f5-016612fdd486 {start_interpolation:0,transformation:{translation:[0.046f,1.727f,-0.333f],left_rotation:[0.262f,0.169f,-0.0102f,0.9501f]}}
data merge entity d5b82b8d-86e1-5276-8680-ed7a08615c7a {start_interpolation:0,transformation:{translation:[0.266f,2.145f,-0.16f],left_rotation:[0.4003f,0.175f,-0.1773f,0.8819f]}}
data merge entity a4c123d3-dfeb-5763-b680-e521fb79538b {start_interpolation:0,transformation:{translation:[-0.073f,2.12f,-0.042f],left_rotation:[0.4101f,-0.3694f,0.0658f,0.8313f]}}
data merge entity 14895439-b1c6-5868-83ed-85b5ca16af52 {start_interpolation:0,transformation:{translation:[0.132f,1.708f,-0.379f],left_rotation:[-0.4099f,0.1456f,0.0862f,0.8963f]}}
data merge entity ed503232-ebe9-57f4-8f88-a4efe27a7f4d {start_interpolation:0,transformation:{translation:[-0.047f,1.695f,-0.317f],left_rotation:[0.2052f,-0.7231f,-0.4453f,0.4865f]}}
data merge entity 75e3c547-3dab-50d7-a8aa-ffff4a07edfb {start_interpolation:0,transformation:{translation:[0.253f,1.422f,-0.067f],left_rotation:[0.208f,-0.0198f,-0.0604f,0.9761f]}}
data merge entity b4028d78-85e3-5bdd-b8d1-be173b14689d {start_interpolation:0,transformation:{translation:[-0.107f,1.466f,-0.688f],left_rotation:[0.4978f,-0.7927f,0.3078f,0.1708f]}}
