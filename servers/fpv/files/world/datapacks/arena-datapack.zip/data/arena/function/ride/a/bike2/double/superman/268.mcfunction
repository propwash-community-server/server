data merge entity 7f895ae6-3a84-58c6-84f5-016612fdd486 {start_interpolation:0,transformation:{translation:[0f,2.032f,-0.189f],left_rotation:[0.7497f,0f,0f,0.6618f]}}
data merge entity d5b82b8d-86e1-5276-8680-ed7a08615c7a {start_interpolation:0,transformation:{translation:[0.18f,1.974f,0.278f],left_rotation:[0.4038f,0.1341f,0.0962f,0.8999f]}}
data merge entity a4c123d3-dfeb-5763-b680-e521fb79538b {start_interpolation:0,transformation:{translation:[-0.18f,1.974f,0.278f],left_rotation:[0.4038f,-0.1341f,-0.0962f,0.8999f]}}
data merge entity 14895439-b1c6-5868-83ed-85b5ca16af52 {start_interpolation:0,transformation:{translation:[0.095f,2.036f,-0.219f],left_rotation:[0.6952f,0.0082f,0.1091f,0.7105f]}}
data merge entity ed503232-ebe9-57f4-8f88-a4efe27a7f4d {start_interpolation:0,transformation:{translation:[-0.095f,2.036f,-0.219f],left_rotation:[0.6952f,-0.0082f,-0.1091f,0.7105f]}}
data merge entity 75e3c547-3dab-50d7-a8aa-ffff4a07edfb {start_interpolation:0,transformation:{translation:[0.158f,2.032f,-0.654f],left_rotation:[0.8967f,0.0452f,0.0998f,0.4289f]}}
data merge entity b4028d78-85e3-5bdd-b8d1-be173b14689d {start_interpolation:0,transformation:{translation:[-0.158f,2.032f,-0.654f],left_rotation:[0.8967f,-0.0452f,-0.0998f,0.4289f]}}
