data merge entity 11ae4677-4219-56c2-add0-4c64d57ac56a {start_interpolation:0,transformation:{translation:[0f,1.733f,-0.421f],left_rotation:[0.0686f,0f,0f,0.9976f]}}
data merge entity 7d2a9e32-11f2-50e1-9212-e206c5741830 {start_interpolation:0,transformation:{translation:[0.18f,2.198f,-0.356f],left_rotation:[-0.4062f,0.4971f,0.1144f,0.7581f],scale:[1f,1f,0.801f]}}
data merge entity dde4ca15-7054-52aa-b829-17380091a80f {start_interpolation:0,transformation:{translation:[-0.18f,2.198f,-0.356f],left_rotation:[-0.4062f,-0.4971f,-0.1144f,0.7581f],scale:[1f,1f,0.801f]}}
data merge entity f4c9c580-42de-5f18-958e-fe8f13f48db0 {start_interpolation:0,transformation:{translation:[0.095f,1.703f,-0.425f],left_rotation:[-0.4251f,0.0581f,0.0775f,0.9f]}}
data merge entity 593cd5be-38e3-598f-a4f4-75287916d917 {start_interpolation:0,transformation:{translation:[-0.095f,1.703f,-0.425f],left_rotation:[-0.4251f,-0.0581f,-0.0775f,0.9f]}}
data merge entity b93e033a-5262-5632-b8ab-3de10d1c99fe {start_interpolation:0,transformation:{translation:[0.178f,1.427f,-0.092f],left_rotation:[0.1883f,0.0036f,0.0114f,0.982f]}}
data merge entity e73b8616-4bc3-571b-bb40-c31cce9d3a8c {start_interpolation:0,transformation:{translation:[-0.178f,1.427f,-0.092f],left_rotation:[0.1883f,-0.0036f,-0.0114f,0.982f]}}
