data merge entity 7f895ae6-3a84-58c6-84f5-016612fdd486 {start_interpolation:0,transformation:{translation:[0f,1.774f,-0.29f],left_rotation:[0.1356f,0f,0f,0.9908f]}}
data merge entity d5b82b8d-86e1-5276-8680-ed7a08615c7a {start_interpolation:0,transformation:{translation:[0.18f,2.226f,-0.164f],left_rotation:[-0.3038f,0.4749f,0.1028f,0.8195f],scale:[1f,1f,0.714f]}}
data merge entity a4c123d3-dfeb-5763-b680-e521fb79538b {start_interpolation:0,transformation:{translation:[-0.18f,2.226f,-0.164f],left_rotation:[-0.3038f,-0.4749f,-0.1028f,0.8195f],scale:[1f,1f,0.714f]}}
data merge entity 14895439-b1c6-5868-83ed-85b5ca16af52 {start_interpolation:0,transformation:{translation:[0.095f,1.745f,-0.298f],left_rotation:[-0.3729f,0.0574f,0.0812f,0.9225f]}}
data merge entity ed503232-ebe9-57f4-8f88-a4efe27a7f4d {start_interpolation:0,transformation:{translation:[-0.095f,1.745f,-0.298f],left_rotation:[-0.3729f,-0.0574f,-0.0812f,0.9225f]}}
data merge entity 75e3c547-3dab-50d7-a8aa-ffff4a07edfb {start_interpolation:0,transformation:{translation:[0.18f,1.433f,0f],left_rotation:[0.2383f,0.0025f,0.0099f,0.9711f]}}
data merge entity b4028d78-85e3-5bdd-b8d1-be173b14689d {start_interpolation:0,transformation:{translation:[-0.18f,1.433f,0f],left_rotation:[0.2383f,-0.0025f,-0.0099f,0.9711f]}}
