data merge entity 11ae4677-4219-56c2-add0-4c64d57ac56a {start_interpolation:0,transformation:{translation:[0f,1.786f,-0.201f],left_rotation:[0.1365f,0f,0f,0.9906f]}}
data merge entity 7d2a9e32-11f2-50e1-9212-e206c5741830 {start_interpolation:0,transformation:{translation:[0.18f,2.238f,-0.074f],left_rotation:[-0.4132f,0.5017f,0.2063f,0.7314f],scale:[1f,1f,1f]}}
data merge entity dde4ca15-7054-52aa-b829-17380091a80f {start_interpolation:0,transformation:{translation:[-0.18f,2.238f,-0.074f],left_rotation:[-0.4132f,-0.5017f,-0.2063f,0.7314f],scale:[1f,1f,1f]}}
data merge entity f4c9c580-42de-5f18-958e-fe8f13f48db0 {start_interpolation:0,transformation:{translation:[0.095f,1.757f,-0.209f],left_rotation:[-0.3466f,0.0449f,0.081f,0.9334f]}}
data merge entity 593cd5be-38e3-598f-a4f4-75287916d917 {start_interpolation:0,transformation:{translation:[-0.095f,1.757f,-0.209f],left_rotation:[-0.3466f,-0.0449f,-0.081f,0.9334f]}}
data merge entity b93e033a-5262-5632-b8ab-3de10d1c99fe {start_interpolation:0,transformation:{translation:[0.175f,1.428f,0.073f],left_rotation:[0.281f,0.0032f,0.0145f,0.9596f]}}
data merge entity e73b8616-4bc3-571b-bb40-c31cce9d3a8c {start_interpolation:0,transformation:{translation:[-0.175f,1.428f,0.073f],left_rotation:[0.281f,-0.0032f,-0.0145f,0.9596f]}}
