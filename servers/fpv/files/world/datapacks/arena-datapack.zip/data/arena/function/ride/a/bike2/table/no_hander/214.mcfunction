data merge entity 7f895ae6-3a84-58c6-84f5-016612fdd486 {start_interpolation:0,transformation:{translation:[0f,1.778f,-0.242f],left_rotation:[0.1203f,0f,0f,0.9927f]}}
data merge entity d5b82b8d-86e1-5276-8680-ed7a08615c7a {start_interpolation:0,transformation:{translation:[0.18f,2.235f,-0.129f],left_rotation:[-0.4246f,0.5049f,0.1975f,0.7251f],scale:[1f,1f,0.998f]}}
data merge entity a4c123d3-dfeb-5763-b680-e521fb79538b {start_interpolation:0,transformation:{translation:[-0.18f,2.235f,-0.129f],left_rotation:[-0.4246f,-0.5049f,-0.1975f,0.7251f],scale:[1f,1f,0.998f]}}
data merge entity 14895439-b1c6-5868-83ed-85b5ca16af52 {start_interpolation:0,transformation:{translation:[0.095f,1.749f,-0.249f],left_rotation:[-0.362f,0.0463f,0.0802f,0.9276f]}}
data merge entity ed503232-ebe9-57f4-8f88-a4efe27a7f4d {start_interpolation:0,transformation:{translation:[-0.095f,1.749f,-0.249f],left_rotation:[-0.362f,-0.0463f,-0.0802f,0.9276f]}}
data merge entity 75e3c547-3dab-50d7-a8aa-ffff4a07edfb {start_interpolation:0,transformation:{translation:[0.175f,1.43f,0.043f],left_rotation:[0.2649f,0.0035f,0.0144f,0.9641f]}}
data merge entity b4028d78-85e3-5bdd-b8d1-be173b14689d {start_interpolation:0,transformation:{translation:[-0.175f,1.43f,0.043f],left_rotation:[0.2649f,-0.0035f,-0.0144f,0.9641f]}}
