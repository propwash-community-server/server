data merge entity 7f895ae6-3a84-58c6-84f5-016612fdd486 {start_interpolation:0,transformation:{translation:[0f,1.816f,0.038f],left_rotation:[0.315f,0f,0f,0.9491f]}}
data merge entity d5b82b8d-86e1-5276-8680-ed7a08615c7a {start_interpolation:0,transformation:{translation:[0.18f,2.193f,0.319f],left_rotation:[0.1428f,0.3973f,-0.0498f,0.9052f],scale:[1f,1f,0.7f]}}
data merge entity a4c123d3-dfeb-5763-b680-e521fb79538b {start_interpolation:0,transformation:{translation:[-0.18f,2.193f,0.319f],left_rotation:[0.1428f,-0.3973f,0.0498f,0.9052f],scale:[1f,1f,0.7f]}}
data merge entity 14895439-b1c6-5868-83ed-85b5ca16af52 {start_interpolation:0,transformation:{translation:[0.095f,1.792f,0.02f],left_rotation:[-0.2367f,0.0606f,0.0923f,0.9653f]}}
data merge entity ed503232-ebe9-57f4-8f88-a4efe27a7f4d {start_interpolation:0,transformation:{translation:[-0.095f,1.792f,0.02f],left_rotation:[-0.2367f,-0.0606f,-0.0923f,0.9653f]}}
data merge entity 75e3c547-3dab-50d7-a8aa-ffff4a07edfb {start_interpolation:0,transformation:{translation:[0.186f,1.409f,0.216f],left_rotation:[0.351f,0.0004f,0.0039f,0.9364f]}}
data merge entity b4028d78-85e3-5bdd-b8d1-be173b14689d {start_interpolation:0,transformation:{translation:[-0.186f,1.409f,0.216f],left_rotation:[0.351f,-0.0004f,-0.0039f,0.9364f]}}
