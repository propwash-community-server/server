data merge entity 11ae4677-4219-56c2-add0-4c64d57ac56a {start_interpolation:0,transformation:{translation:[-0.05f,1.766f,-0.036f],left_rotation:[0.3698f,-0.185f,-0.0126f,0.9104f]}}
data merge entity 7d2a9e32-11f2-50e1-9212-e206c5741830 {start_interpolation:0,transformation:{translation:[0.064f,2.079f,0.342f],left_rotation:[0.5064f,0.3838f,-0.0134f,0.7721f]}}
data merge entity dde4ca15-7054-52aa-b829-17380091a80f {start_interpolation:0,transformation:{translation:[-0.271f,2.136f,0.224f],left_rotation:[0.5022f,-0.1897f,0.157f,0.8289f]}}
data merge entity f4c9c580-42de-5f18-958e-fe8f13f48db0 {start_interpolation:0,transformation:{translation:[0.042f,1.729f,-0.025f],left_rotation:[0.5562f,0.5907f,0.2052f,0.5474f]}}
data merge entity 593cd5be-38e3-598f-a4f4-75287916d917 {start_interpolation:0,transformation:{translation:[-0.135f,1.759f,-0.087f],left_rotation:[-0.3027f,-0.1355f,-0.1041f,0.9376f]}}
data merge entity b93e033a-5262-5632-b8ab-3de10d1c99fe {start_interpolation:0,transformation:{translation:[-0.148f,1.598f,-0.4f],left_rotation:[0.7422f,0.6201f,-0.0803f,0.2412f]}}
data merge entity e73b8616-4bc3-571b-bb40-c31cce9d3a8c {start_interpolation:0,transformation:{translation:[-0.257f,1.41f,0.15f],left_rotation:[0.33f,0.0137f,0.0669f,0.9415f]}}
