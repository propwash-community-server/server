data merge entity 7f895ae6-3a84-58c6-84f5-016612fdd486 {start_interpolation:0,transformation:{translation:[0f,1.801f,-0.038f],left_rotation:[0.2008f,0f,0f,0.9796f]}}
data merge entity d5b82b8d-86e1-5276-8680-ed7a08615c7a {start_interpolation:0,transformation:{translation:[0.18f,2.233f,0.147f],left_rotation:[-0.3646f,0.4872f,0.2385f,0.7568f]}}
data merge entity a4c123d3-dfeb-5763-b680-e521fb79538b {start_interpolation:0,transformation:{translation:[-0.18f,2.233f,0.147f],left_rotation:[-0.3646f,-0.4872f,-0.2385f,0.7568f]}}
data merge entity 14895439-b1c6-5868-83ed-85b5ca16af52 {start_interpolation:0,transformation:{translation:[0.095f,1.774f,-0.05f],left_rotation:[-0.285f,0.0395f,0.0837f,0.954f]}}
data merge entity ed503232-ebe9-57f4-8f88-a4efe27a7f4d {start_interpolation:0,transformation:{translation:[-0.095f,1.774f,-0.05f],left_rotation:[-0.285f,-0.0395f,-0.0837f,0.954f]}}
data merge entity 75e3c547-3dab-50d7-a8aa-ffff4a07edfb {start_interpolation:0,transformation:{translation:[0.175f,1.411f,0.186f],left_rotation:[0.3429f,0.0023f,0.0147f,0.9393f]}}
data merge entity b4028d78-85e3-5bdd-b8d1-be173b14689d {start_interpolation:0,transformation:{translation:[-0.175f,1.411f,0.186f],left_rotation:[0.3429f,-0.0023f,-0.0147f,0.9393f]}}
