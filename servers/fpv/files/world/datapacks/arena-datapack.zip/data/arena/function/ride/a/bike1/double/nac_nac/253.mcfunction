data merge entity 11ae4677-4219-56c2-add0-4c64d57ac56a {start_interpolation:0,transformation:{translation:[-0.049f,1.753f,0.195f],left_rotation:[0.4564f,-0.1786f,-0.0291f,0.8712f]}}
data merge entity 7d2a9e32-11f2-50e1-9212-e206c5741830 {start_interpolation:0,transformation:{translation:[0.067f,1.988f,0.625f],left_rotation:[0.5782f,0.381f,0.021f,0.7212f]}}
data merge entity dde4ca15-7054-52aa-b829-17380091a80f {start_interpolation:0,transformation:{translation:[-0.27f,2.065f,0.522f],left_rotation:[0.5795f,-0.2052f,0.1375f,0.7767f]}}
data merge entity f4c9c580-42de-5f18-958e-fe8f13f48db0 {start_interpolation:0,transformation:{translation:[0.043f,1.715f,0.198f],left_rotation:[0.5097f,0.5721f,0.363f,0.5301f]}}
data merge entity 593cd5be-38e3-598f-a4f4-75287916d917 {start_interpolation:0,transformation:{translation:[-0.134f,1.756f,0.143f],left_rotation:[-0.2107f,-0.1246f,-0.1162f,0.9626f]}}
data merge entity b93e033a-5262-5632-b8ab-3de10d1c99fe {start_interpolation:0,transformation:{translation:[-0.044f,1.62f,-0.223f],left_rotation:[0.7268f,0.6739f,-0.0673f,0.1147f]}}
data merge entity e73b8616-4bc3-571b-bb40-c31cce9d3a8c {start_interpolation:0,transformation:{translation:[-0.256f,1.367f,0.309f],left_rotation:[0.4168f,0.007f,0.0667f,0.9065f]}}
