data merge entity 11ae4677-4219-56c2-add0-4c64d57ac56a {start_interpolation:0,transformation:{translation:[0f,2.026f,-0.133f],left_rotation:[0.7468f,0f,0f,0.665f]}}
data merge entity 7d2a9e32-11f2-50e1-9212-e206c5741830 {start_interpolation:0,transformation:{translation:[0.18f,1.971f,0.334f],left_rotation:[0.4305f,0.1358f,0.096f,0.8871f],scale:[1f,1f,1.051f]}}
data merge entity dde4ca15-7054-52aa-b829-17380091a80f {start_interpolation:0,transformation:{translation:[-0.18f,1.971f,0.334f],left_rotation:[0.4305f,-0.1358f,-0.096f,0.8871f],scale:[1f,1f,1.051f]}}
data merge entity f4c9c580-42de-5f18-958e-fe8f13f48db0 {start_interpolation:0,transformation:{translation:[0.095f,2.029f,-0.163f],left_rotation:[0.2943f,-0.0292f,0.1091f,0.949f]}}
data merge entity 593cd5be-38e3-598f-a4f4-75287916d917 {start_interpolation:0,transformation:{translation:[-0.095f,2.029f,-0.163f],left_rotation:[0.2943f,0.0292f,-0.1091f,0.949f]}}
data merge entity b93e033a-5262-5632-b8ab-3de10d1c99fe {start_interpolation:0,transformation:{translation:[0.194f,1.676f,-0.406f],left_rotation:[0.9306f,0.0694f,0.0923f,0.3472f]}}
data merge entity e73b8616-4bc3-571b-bb40-c31cce9d3a8c {start_interpolation:0,transformation:{translation:[-0.194f,1.676f,-0.406f],left_rotation:[0.9306f,-0.0694f,-0.0923f,0.3472f]}}
