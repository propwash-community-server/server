data merge entity 7f895ae6-3a84-58c6-84f5-016612fdd486 {start_interpolation:0,transformation:{translation:[0.05f,1.766f,0.019f],left_rotation:[0.3902f,0.1847f,0.0168f,0.9018f]}}
data merge entity d5b82b8d-86e1-5276-8680-ed7a08615c7a {start_interpolation:0,transformation:{translation:[0.271f,2.124f,0.295f],left_rotation:[0.5208f,0.1932f,-0.1527f,0.8174f]}}
data merge entity a4c123d3-dfeb-5763-b680-e521fb79538b {start_interpolation:0,transformation:{translation:[-0.064f,2.062f,0.41f],left_rotation:[0.5237f,-0.384f,0.0047f,0.7605f]}}
data merge entity 14895439-b1c6-5868-83ed-85b5ca16af52 {start_interpolation:0,transformation:{translation:[0.135f,1.762f,-0.033f],left_rotation:[-0.2815f,0.1332f,0.1071f,0.9442f]}}
data merge entity ed503232-ebe9-57f4-8f88-a4efe27a7f4d {start_interpolation:0,transformation:{translation:[-0.042f,1.729f,0.028f],left_rotation:[0.5684f,-0.5859f,-0.2185f,0.5347f]}}
data merge entity 75e3c547-3dab-50d7-a8aa-ffff4a07edfb {start_interpolation:0,transformation:{translation:[0.257f,1.402f,0.189f],left_rotation:[0.3511f,-0.0122f,-0.0672f,0.9338f]}}
data merge entity b4028d78-85e3-5bdd-b8d1-be173b14689d {start_interpolation:0,transformation:{translation:[0.148f,1.615f,-0.352f],left_rotation:[0.7474f,-0.6218f,0.0663f,0.2244f]}}
