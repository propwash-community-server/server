data merge entity 7f895ae6-3a84-58c6-84f5-016612fdd486 {start_interpolation:0,transformation:{translation:[0.05f,1.766f,-0.026f],left_rotation:[0.3735f,0.185f,0.0133f,0.9089f]}}
data merge entity d5b82b8d-86e1-5276-8680-ed7a08615c7a {start_interpolation:0,transformation:{translation:[0.271f,2.134f,0.237f],left_rotation:[0.5056f,0.1903f,-0.1562f,0.8269f]}}
data merge entity a4c123d3-dfeb-5763-b680-e521fb79538b {start_interpolation:0,transformation:{translation:[-0.064f,2.076f,0.354f],left_rotation:[0.5095f,-0.3838f,0.0118f,0.77f]}}
data merge entity 14895439-b1c6-5868-83ed-85b5ca16af52 {start_interpolation:0,transformation:{translation:[0.135f,1.76f,-0.078f],left_rotation:[-0.2989f,0.1351f,0.1046f,0.9389f]}}
data merge entity ed503232-ebe9-57f4-8f88-a4efe27a7f4d {start_interpolation:0,transformation:{translation:[-0.042f,1.729f,-0.016f],left_rotation:[0.5584f,-0.5898f,-0.2076f,0.5452f]}}
data merge entity 75e3c547-3dab-50d7-a8aa-ffff4a07edfb {start_interpolation:0,transformation:{translation:[0.257f,1.408f,0.157f],left_rotation:[0.3338f,-0.0134f,-0.067f,0.9402f]}}
data merge entity b4028d78-85e3-5bdd-b8d1-be173b14689d {start_interpolation:0,transformation:{translation:[0.148f,1.602f,-0.391f],left_rotation:[0.7431f,-0.6204f,0.0778f,0.2382f]}}
