data merge entity 11ae4677-4219-56c2-add0-4c64d57ac56a {start_interpolation:0,transformation:{left_rotation:[0.2434f,0f,0f,0.9699f]}}
data merge entity 7d2a9e32-11f2-50e1-9212-e206c5741830 {start_interpolation:0,transformation:{translation:[0.18f,2.119f,-0.355f],left_rotation:[0.3321f,0.2458f,-0.1604f,0.8964f],scale:[1f,1f,1.02f]}}
data merge entity dde4ca15-7054-52aa-b829-17380091a80f {start_interpolation:0,transformation:{translation:[-0.18f,2.119f,-0.355f],left_rotation:[0.3321f,-0.2458f,0.1604f,0.8964f],scale:[1f,1f,1.02f]}}
data merge entity f4c9c580-42de-5f18-958e-fe8f13f48db0 {start_interpolation:0,transformation:{left_rotation:[-0.4288f,0.1313f,0.0738f,0.8908f]}}
data merge entity 593cd5be-38e3-598f-a4f4-75287916d917 {start_interpolation:0,transformation:{left_rotation:[-0.4288f,-0.1313f,-0.0738f,0.8908f]}}
data merge entity b93e033a-5262-5632-b8ab-3de10d1c99fe {start_interpolation:0,transformation:{left_rotation:[0.0679f,-0.0038f,-0.0116f,0.9976f]}}
data merge entity e73b8616-4bc3-571b-bb40-c31cce9d3a8c {start_interpolation:0,transformation:{left_rotation:[0.0679f,0.0038f,0.0116f,0.9976f]}}
