data merge entity 11ae4677-4219-56c2-add0-4c64d57ac56a {start_interpolation:0,transformation:{translation:[0f,1.974f,-0.455f],left_rotation:[0.6869f,0f,0f,0.7267f]}}
data merge entity 7d2a9e32-11f2-50e1-9212-e206c5741830 {start_interpolation:0,transformation:{translation:[0.18f,2f,0.014f],left_rotation:[0.3195f,0.1422f,0.0836f,0.9331f]}}
data merge entity dde4ca15-7054-52aa-b829-17380091a80f {start_interpolation:0,transformation:{translation:[-0.18f,2f,0.014f],left_rotation:[0.3195f,-0.1422f,-0.0836f,0.9331f]}}
data merge entity f4c9c580-42de-5f18-958e-fe8f13f48db0 {start_interpolation:0,transformation:{translation:[0.095f,1.972f,-0.485f],left_rotation:[0.6578f,0.0218f,0.1069f,0.7453f]}}
data merge entity 593cd5be-38e3-598f-a4f4-75287916d917 {start_interpolation:0,transformation:{translation:[-0.095f,1.972f,-0.485f],left_rotation:[0.6578f,-0.0218f,-0.1069f,0.7453f]}}
data merge entity b93e033a-5262-5632-b8ab-3de10d1c99fe {start_interpolation:0,transformation:{translation:[0.153f,1.923f,-0.919f],left_rotation:[0.8407f,0.051f,0.0965f,0.5304f]}}
data merge entity e73b8616-4bc3-571b-bb40-c31cce9d3a8c {start_interpolation:0,transformation:{translation:[-0.153f,1.923f,-0.919f],left_rotation:[0.8407f,-0.051f,-0.0965f,0.5304f]}}
