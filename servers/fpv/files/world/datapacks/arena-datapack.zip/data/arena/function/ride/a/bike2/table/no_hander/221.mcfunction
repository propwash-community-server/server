data merge entity 7f895ae6-3a84-58c6-84f5-016612fdd486 {start_interpolation:0,transformation:{translation:[0f,1.826f,0.106f],left_rotation:[0.4113f,0f,0f,0.9115f]}}
data merge entity d5b82b8d-86e1-5276-8680-ed7a08615c7a {start_interpolation:0,transformation:{translation:[0.18f,2.136f,0.459f],left_rotation:[0.4375f,0.3336f,-0.1448f,0.8224f],scale:[1f,1f,0.893f]}}
data merge entity a4c123d3-dfeb-5763-b680-e521fb79538b {start_interpolation:0,transformation:{translation:[-0.18f,2.136f,0.459f],left_rotation:[0.4375f,-0.3336f,0.1448f,0.8224f],scale:[1f,1f,0.893f]}}
data merge entity 14895439-b1c6-5868-83ed-85b5ca16af52 {start_interpolation:0,transformation:{translation:[0.095f,1.806f,0.084f],left_rotation:[-0.1916f,0.0794f,0.0996f,0.9732f]}}
data merge entity ed503232-ebe9-57f4-8f88-a4efe27a7f4d {start_interpolation:0,transformation:{translation:[-0.095f,1.806f,0.084f],left_rotation:[-0.1916f,-0.0794f,-0.0996f,0.9732f]}}
data merge entity 75e3c547-3dab-50d7-a8aa-ffff4a07edfb {start_interpolation:0,transformation:{translation:[0.194f,1.407f,0.241f],left_rotation:[0.3562f,-0.0002f,-0.0036f,0.9344f]}}
data merge entity b4028d78-85e3-5bdd-b8d1-be173b14689d {start_interpolation:0,transformation:{translation:[-0.194f,1.407f,0.241f],left_rotation:[0.3562f,0.0002f,0.0036f,0.9344f]}}
