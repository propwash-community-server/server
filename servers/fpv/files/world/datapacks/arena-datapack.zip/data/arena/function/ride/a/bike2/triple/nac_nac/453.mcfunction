data merge entity 7f895ae6-3a84-58c6-84f5-016612fdd486 {start_interpolation:0,transformation:{translation:[0.042f,1.773f,0.134f],left_rotation:[0.4461f,0.1521f,0.0194f,0.8817f]}}
data merge entity d5b82b8d-86e1-5276-8680-ed7a08615c7a {start_interpolation:0,transformation:{translation:[0.261f,2.086f,0.462f],left_rotation:[0.5648f,0.2116f,-0.1372f,0.7857f]}}
data merge entity a4c123d3-dfeb-5763-b680-e521fb79538b {start_interpolation:0,transformation:{translation:[-0.082f,2.025f,0.552f],left_rotation:[0.5645f,-0.3667f,0.0011f,0.7395f]}}
data merge entity 14895439-b1c6-5868-83ed-85b5ca16af52 {start_interpolation:0,transformation:{translation:[0.129f,1.771f,0.087f],left_rotation:[-0.2242f,0.1247f,0.1118f,0.96f]}}
data merge entity ed503232-ebe9-57f4-8f88-a4efe27a7f4d {start_interpolation:0,transformation:{translation:[-0.052f,1.739f,0.135f],left_rotation:[0.1401f,-0.7224f,-0.6615f,0.1446f]}}
data merge entity 75e3c547-3dab-50d7-a8aa-ffff4a07edfb {start_interpolation:0,transformation:{translation:[0.248f,1.386f,0.264f],left_rotation:[0.3873f,-0.0068f,-0.0585f,0.9201f]}}
data merge entity b4028d78-85e3-5bdd-b8d1-be173b14689d {start_interpolation:0,transformation:{translation:[-0.047f,1.701f,-0.304f],left_rotation:[0.1931f,-0.9595f,0.205f,0f]}}
