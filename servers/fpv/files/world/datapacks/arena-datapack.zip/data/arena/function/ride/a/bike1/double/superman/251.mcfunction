data merge entity 11ae4677-4219-56c2-add0-4c64d57ac56a {start_interpolation:0,transformation:{translation:[0f,2.023f,-0.255f],left_rotation:[0.7355f,0f,0f,0.6775f]}}
data merge entity 7d2a9e32-11f2-50e1-9212-e206c5741830 {start_interpolation:0,transformation:{translation:[0.18f,1.984f,0.214f],left_rotation:[0.3832f,0.136f,0.0933f,0.9088f]}}
data merge entity dde4ca15-7054-52aa-b829-17380091a80f {start_interpolation:0,transformation:{translation:[-0.18f,1.984f,0.214f],left_rotation:[0.3832f,-0.136f,-0.0933f,0.9088f]}}
data merge entity f4c9c580-42de-5f18-958e-fe8f13f48db0 {start_interpolation:0,transformation:{translation:[0.095f,2.025f,-0.284f],left_rotation:[0.7077f,0.0144f,0.1082f,0.698f]}}
data merge entity 593cd5be-38e3-598f-a4f4-75287916d917 {start_interpolation:0,transformation:{translation:[-0.095f,2.025f,-0.284f],left_rotation:[0.7077f,-0.0144f,-0.1082f,0.698f]}}
data merge entity b93e033a-5262-5632-b8ab-3de10d1c99fe {start_interpolation:0,transformation:{translation:[0.153f,2.036f,-0.72f],left_rotation:[0.8753f,0.0442f,0.0998f,0.471f]}}
data merge entity e73b8616-4bc3-571b-bb40-c31cce9d3a8c {start_interpolation:0,transformation:{translation:[-0.153f,2.036f,-0.72f],left_rotation:[0.8753f,-0.0442f,-0.0998f,0.471f]}}
