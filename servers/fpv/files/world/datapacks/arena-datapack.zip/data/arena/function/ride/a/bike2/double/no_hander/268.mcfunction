data merge entity 7f895ae6-3a84-58c6-84f5-016612fdd486 {start_interpolation:0,transformation:{translation:[0f,1.802f,0.096f],left_rotation:[0.2749f,0f,0f,0.9615f]}}
data merge entity d5b82b8d-86e1-5276-8680-ed7a08615c7a {start_interpolation:0,transformation:{translation:[0.18f,2.201f,0.344f],left_rotation:[-0.2361f,0.462f,0.2125f,0.828f],scale:[1f,1f,0.795f]}}
data merge entity a4c123d3-dfeb-5763-b680-e521fb79538b {start_interpolation:0,transformation:{translation:[-0.18f,2.201f,0.344f],left_rotation:[-0.2361f,-0.462f,-0.2125f,0.828f],scale:[1f,1f,0.795f]}}
data merge entity 14895439-b1c6-5868-83ed-85b5ca16af52 {start_interpolation:0,transformation:{translation:[0.095f,1.777f,0.08f],left_rotation:[-0.2289f,0.041f,0.0879f,0.9686f]}}
data merge entity ed503232-ebe9-57f4-8f88-a4efe27a7f4d {start_interpolation:0,transformation:{translation:[-0.095f,1.777f,0.08f],left_rotation:[-0.2289f,-0.041f,-0.0879f,0.9686f]}}
data merge entity 75e3c547-3dab-50d7-a8aa-ffff4a07edfb {start_interpolation:0,transformation:{translation:[0.178f,1.389f,0.272f],left_rotation:[0.3876f,0.0012f,0.0118f,0.9217f]}}
data merge entity b4028d78-85e3-5bdd-b8d1-be173b14689d {start_interpolation:0,transformation:{translation:[-0.178f,1.389f,0.272f],left_rotation:[0.3876f,-0.0012f,-0.0118f,0.9217f]}}
