data merge entity 11ae4677-4219-56c2-add0-4c64d57ac56a {start_interpolation:0,transformation:{translation:[0f,1.834f,0.102f],left_rotation:[0.4495f,0f,0f,0.8933f]}}
data merge entity 7d2a9e32-11f2-50e1-9212-e206c5741830 {start_interpolation:0,transformation:{translation:[0.18f,2.114f,0.48f],left_rotation:[0.5075f,0.3054f,-0.1307f,0.7951f],scale:[1f,1f,1.002f]}}
data merge entity dde4ca15-7054-52aa-b829-17380091a80f {start_interpolation:0,transformation:{translation:[-0.18f,2.114f,0.48f],left_rotation:[0.5075f,-0.3054f,0.1307f,0.7951f],scale:[1f,1f,1.002f]}}
data merge entity f4c9c580-42de-5f18-958e-fe8f13f48db0 {start_interpolation:0,transformation:{translation:[0.095f,1.816f,0.078f],left_rotation:[-0.1806f,0.0921f,0.102f,0.9739f]}}
data merge entity 593cd5be-38e3-598f-a4f4-75287916d917 {start_interpolation:0,transformation:{translation:[-0.095f,1.816f,0.078f],left_rotation:[-0.1806f,-0.0921f,-0.102f,0.9739f]}}
data merge entity b93e033a-5262-5632-b8ab-3de10d1c99fe {start_interpolation:0,transformation:{translation:[0.197f,1.414f,0.225f],left_rotation:[0.3422f,-0.0004f,-0.007f,0.9396f]}}
data merge entity e73b8616-4bc3-571b-bb40-c31cce9d3a8c {start_interpolation:0,transformation:{translation:[-0.197f,1.414f,0.225f],left_rotation:[0.3422f,0.0004f,0.007f,0.9396f]}}
