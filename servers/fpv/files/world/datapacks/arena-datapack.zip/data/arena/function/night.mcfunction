time set 18000
tellraw @s {"text":"Night – arena lights on.","color":"gray"}
