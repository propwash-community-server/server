data merge entity 11ae4677-4219-56c2-add0-4c64d57ac56a {start_interpolation:0,transformation:{translation:[-0.05f,1.742f,-0.244f],left_rotation:[0.2901f,-0.1854f,0.0034f,0.9389f]}}
data merge entity 7d2a9e32-11f2-50e1-9212-e206c5741830 {start_interpolation:0,transformation:{translation:[0.064f,2.115f,0.075f],left_rotation:[0.4381f,0.3812f,-0.0464f,0.8128f]}}
data merge entity dde4ca15-7054-52aa-b829-17380091a80f {start_interpolation:0,transformation:{translation:[-0.271f,2.151f,-0.051f],left_rotation:[0.429f,-0.1755f,0.1727f,0.8691f]}}
data merge entity f4c9c580-42de-5f18-958e-fe8f13f48db0 {start_interpolation:0,transformation:{translation:[0.042f,1.707f,-0.227f],left_rotation:[0.507f,0.6061f,0.1536f,0.5933f]}}
data merge entity 593cd5be-38e3-598f-a4f4-75287916d917 {start_interpolation:0,transformation:{translation:[-0.135f,1.727f,-0.293f],left_rotation:[-0.3822f,-0.144f,-0.092f,0.9081f]}}
data merge entity b93e033a-5262-5632-b8ab-3de10d1c99fe {start_interpolation:0,transformation:{translation:[-0.148f,1.514f,-0.574f],left_rotation:[0.7187f,0.6109f,-0.1334f,0.3042f]}}
data merge entity e73b8616-4bc3-571b-bb40-c31cce9d3a8c {start_interpolation:0,transformation:{translation:[-0.257f,1.423f,0f],left_rotation:[0.2477f,0.0194f,0.0655f,0.9664f]}}
