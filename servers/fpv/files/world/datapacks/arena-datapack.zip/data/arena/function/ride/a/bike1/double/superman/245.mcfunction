data merge entity 11ae4677-4219-56c2-add0-4c64d57ac56a {start_interpolation:0,transformation:{translation:[0f,1.914f,-0.612f],left_rotation:[0.6451f,0f,0f,0.7641f]}}
data merge entity 7d2a9e32-11f2-50e1-9212-e206c5741830 {start_interpolation:0,transformation:{translation:[0.18f,1.993f,-0.149f],left_rotation:[0.2666f,0.1466f,0.0755f,0.9496f]}}
data merge entity dde4ca15-7054-52aa-b829-17380091a80f {start_interpolation:0,transformation:{translation:[-0.18f,1.993f,-0.149f],left_rotation:[0.2666f,-0.1466f,-0.0755f,0.9496f]}}
data merge entity f4c9c580-42de-5f18-958e-fe8f13f48db0 {start_interpolation:0,transformation:{translation:[0.095f,1.909f,-0.641f],left_rotation:[0.6149f,0.0278f,0.1055f,0.781f]}}
data merge entity 593cd5be-38e3-598f-a4f4-75287916d917 {start_interpolation:0,transformation:{translation:[-0.095f,1.909f,-0.641f],left_rotation:[0.6149f,-0.0278f,-0.1055f,0.781f]}}
data merge entity b93e033a-5262-5632-b8ab-3de10d1c99fe {start_interpolation:0,transformation:{translation:[0.153f,1.811f,-1.067f],left_rotation:[0.8096f,0.0563f,0.0935f,0.5768f]}}
data merge entity e73b8616-4bc3-571b-bb40-c31cce9d3a8c {start_interpolation:0,transformation:{translation:[-0.153f,1.811f,-1.067f],left_rotation:[0.8096f,-0.0563f,-0.0935f,0.5768f]}}
