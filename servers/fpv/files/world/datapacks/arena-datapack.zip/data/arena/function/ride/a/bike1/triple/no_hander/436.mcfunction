data merge entity 11ae4677-4219-56c2-add0-4c64d57ac56a {start_interpolation:0,transformation:{left_rotation:[0.5115f,0f,0f,0.8593f]}}
data merge entity 7d2a9e32-11f2-50e1-9212-e206c5741830 {start_interpolation:0,transformation:{translation:[0.18f,2.063f,0.558f],left_rotation:[0.5794f,0.2835f,-0.0839f,0.7595f],scale:[1f,1f,1.021f]}}
data merge entity dde4ca15-7054-52aa-b829-17380091a80f {start_interpolation:0,transformation:{translation:[-0.18f,2.063f,0.558f],left_rotation:[0.5794f,-0.2835f,0.0839f,0.7595f],scale:[1f,1f,1.021f]}}
