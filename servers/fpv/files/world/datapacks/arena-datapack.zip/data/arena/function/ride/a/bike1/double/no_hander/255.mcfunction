data merge entity 11ae4677-4219-56c2-add0-4c64d57ac56a {start_interpolation:0,transformation:{left_rotation:[0.5252f,0f,0f,0.851f]}}
data merge entity 7d2a9e32-11f2-50e1-9212-e206c5741830 {start_interpolation:0,transformation:{translation:[0.18f,2.036f,0.644f],left_rotation:[0.5885f,0.2914f,-0.0883f,0.749f],scale:[1f,1f,1.029f]}}
data merge entity dde4ca15-7054-52aa-b829-17380091a80f {start_interpolation:0,transformation:{translation:[-0.18f,2.036f,0.644f],left_rotation:[0.5885f,-0.2914f,0.0883f,0.749f],scale:[1f,1f,1.029f]}}
data merge entity f4c9c580-42de-5f18-958e-fe8f13f48db0 {start_interpolation:0,transformation:{translation:[0.095f,1.811f,0.198f],left_rotation:[-0.1221f,0.0983f,0.1087f,0.9816f]}}
data merge entity 593cd5be-38e3-598f-a4f4-75287916d917 {start_interpolation:0,transformation:{translation:[-0.095f,1.811f,0.198f],left_rotation:[-0.1221f,-0.0983f,-0.1087f,0.9816f]}}
data merge entity b93e033a-5262-5632-b8ab-3de10d1c99fe {start_interpolation:0,transformation:{translation:[0.199f,1.395f,0.294f],left_rotation:[0.3749f,0f,-0.0093f,0.927f]}}
data merge entity e73b8616-4bc3-571b-bb40-c31cce9d3a8c {start_interpolation:0,transformation:{translation:[-0.199f,1.395f,0.294f],left_rotation:[0.3749f,0f,0.0093f,0.927f]}}
