execute unless entity @e[type=minecraft:marker,tag=arena.anchor] run return run tellraw @s {"text":"No arena anchor loaded. Go to the arena world first.","color":"red"}
execute as @e[type=minecraft:marker,tag=arena.anchor,limit=1] at @s positioned 0 65 0.5 run function arena:ride/reset_prepare
tellraw @s {"text":"Vehicles respawn in a second, the race loop starts from the beginning.","color":"green"}
