data merge entity 7f895ae6-3a84-58c6-84f5-016612fdd486 {start_interpolation:0,transformation:{translation:[0.048f,1.753f,0.202f],left_rotation:[0.4606f,0.1749f,0.0288f,0.8697f]}}
data merge entity d5b82b8d-86e1-5276-8680-ed7a08615c7a {start_interpolation:0,transformation:{translation:[0.269f,2.061f,0.533f],left_rotation:[0.5825f,0.2069f,-0.1362f,0.7742f]}}
data merge entity a4c123d3-dfeb-5763-b680-e521fb79538b {start_interpolation:0,transformation:{translation:[-0.069f,1.985f,0.633f],left_rotation:[0.581f,-0.379f,-0.0204f,0.72f]}}
data merge entity 14895439-b1c6-5868-83ed-85b5ca16af52 {start_interpolation:0,transformation:{translation:[0.134f,1.756f,0.151f],left_rotation:[-0.2064f,0.1239f,0.1164f,0.9636f]}}
data merge entity ed503232-ebe9-57f4-8f88-a4efe27a7f4d {start_interpolation:0,transformation:{translation:[-0.045f,1.716f,0.204f],left_rotation:[0.4391f,-0.5786f,-0.444f,0.5248f]}}
data merge entity 75e3c547-3dab-50d7-a8aa-ffff4a07edfb {start_interpolation:0,transformation:{translation:[0.255f,1.365f,0.314f],left_rotation:[0.4187f,-0.0065f,-0.0656f,0.9057f]}}
data merge entity b4028d78-85e3-5bdd-b8d1-be173b14689d {start_interpolation:0,transformation:{translation:[-0.026f,1.619f,-0.225f],left_rotation:[0.6786f,-0.7236f,0.0909f,0.0877f]}}
