data merge entity 11ae4677-4219-56c2-add0-4c64d57ac56a {start_interpolation:0,transformation:{translation:[-0.05f,1.757f,0.155f],left_rotation:[0.4402f,-0.1835f,-0.0271f,0.8785f]}}
data merge entity 7d2a9e32-11f2-50e1-9212-e206c5741830 {start_interpolation:0,transformation:{translation:[0.064f,2.006f,0.577f],left_rotation:[0.5655f,0.3836f,0.0168f,0.7299f]}}
data merge entity dde4ca15-7054-52aa-b829-17380091a80f {start_interpolation:0,transformation:{translation:[-0.271f,2.081f,0.47f],left_rotation:[0.5658f,-0.2014f,0.1416f,0.7869f]}}
data merge entity f4c9c580-42de-5f18-958e-fe8f13f48db0 {start_interpolation:0,transformation:{translation:[0.042f,1.718f,0.16f],left_rotation:[0.5975f,0.5727f,0.251f,0.502f]}}
data merge entity 593cd5be-38e3-598f-a4f4-75287916d917 {start_interpolation:0,transformation:{translation:[-0.135f,1.758f,0.103f],left_rotation:[-0.2281f,-0.1269f,-0.1144f,0.9585f]}}
data merge entity b93e033a-5262-5632-b8ab-3de10d1c99fe {start_interpolation:0,transformation:{translation:[-0.148f,1.648f,-0.231f],left_rotation:[0.7588f,0.6245f,-0.0314f,0.1822f]}}
data merge entity e73b8616-4bc3-571b-bb40-c31cce9d3a8c {start_interpolation:0,transformation:{translation:[-0.257f,1.375f,0.283f],left_rotation:[0.4029f,0.0084f,0.0678f,0.9127f]}}
