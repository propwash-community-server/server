data merge entity 7f895ae6-3a84-58c6-84f5-016612fdd486 {start_interpolation:0,transformation:{translation:[0.05f,1.727f,-0.309f],left_rotation:[0.2644f,0.1852f,-0.0084f,0.9464f]}}
data merge entity d5b82b8d-86e1-5276-8680-ed7a08615c7a {start_interpolation:0,transformation:{translation:[0.271f,2.146f,-0.139f],left_rotation:[0.4052f,0.1707f,-0.1775f,0.8805f]}}
data merge entity a4c123d3-dfeb-5763-b680-e521fb79538b {start_interpolation:0,transformation:{translation:[-0.064f,2.116f,-0.011f],left_rotation:[0.4157f,-0.3798f,0.0568f,0.8244f]}}
data merge entity 14895439-b1c6-5868-83ed-85b5ca16af52 {start_interpolation:0,transformation:{translation:[0.135f,1.709f,-0.357f],left_rotation:[-0.4069f,0.1465f,0.0881f,0.8973f]}}
data merge entity ed503232-ebe9-57f4-8f88-a4efe27a7f4d {start_interpolation:0,transformation:{translation:[-0.042f,1.693f,-0.29f],left_rotation:[0.4906f,-0.6101f,-0.137f,0.6069f]}}
data merge entity 75e3c547-3dab-50d7-a8aa-ffff4a07edfb {start_interpolation:0,transformation:{translation:[0.257f,1.421f,-0.047f],left_rotation:[0.2213f,-0.0212f,-0.065f,0.9728f]}}
data merge entity b4028d78-85e3-5bdd-b8d1-be173b14689d {start_interpolation:0,transformation:{translation:[0.148f,1.482f,-0.625f],left_rotation:[0.7101f,-0.607f,0.15f,0.3237f]}}
