data merge entity 11ae4677-4219-56c2-add0-4c64d57ac56a {start_interpolation:0,transformation:{translation:[0f,2.031f,-0.201f],left_rotation:[0.7476f,0f,0f,0.6641f]}}
data merge entity 7d2a9e32-11f2-50e1-9212-e206c5741830 {start_interpolation:0,transformation:{translation:[0.18f,1.976f,0.266f],left_rotation:[0.3997f,0.1343f,0.0957f,0.9017f]}}
data merge entity dde4ca15-7054-52aa-b829-17380091a80f {start_interpolation:0,transformation:{translation:[-0.18f,1.976f,0.266f],left_rotation:[0.3997f,-0.1343f,-0.0957f,0.9017f]}}
data merge entity f4c9c580-42de-5f18-958e-fe8f13f48db0 {start_interpolation:0,transformation:{translation:[0.095f,2.035f,-0.231f],left_rotation:[0.7164f,0.0118f,0.1085f,0.6891f]}}
data merge entity 593cd5be-38e3-598f-a4f4-75287916d917 {start_interpolation:0,transformation:{translation:[-0.095f,2.035f,-0.231f],left_rotation:[0.7164f,-0.0118f,-0.1085f,0.6891f]}}
data merge entity b93e033a-5262-5632-b8ab-3de10d1c99fe {start_interpolation:0,transformation:{translation:[0.153f,2.057f,-0.666f],left_rotation:[0.8855f,0.0428f,0.1004f,0.4517f]}}
data merge entity e73b8616-4bc3-571b-bb40-c31cce9d3a8c {start_interpolation:0,transformation:{translation:[-0.153f,2.057f,-0.666f],left_rotation:[0.8855f,-0.0428f,-0.1004f,0.4517f]}}
