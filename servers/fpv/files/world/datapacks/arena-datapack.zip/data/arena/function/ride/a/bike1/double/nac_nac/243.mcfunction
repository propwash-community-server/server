data merge entity 11ae4677-4219-56c2-add0-4c64d57ac56a {start_interpolation:0,transformation:{translation:[-0.05f,1.731f,-0.293f],left_rotation:[0.2709f,-0.1845f,0.0072f,0.9447f]}}
data merge entity 7d2a9e32-11f2-50e1-9212-e206c5741830 {start_interpolation:0,transformation:{translation:[0.065f,2.116f,0.01f],left_rotation:[0.4213f,0.3797f,-0.0545f,0.8218f],scale:[1f,1f,0.988f]}}
data merge entity dde4ca15-7054-52aa-b829-17380091a80f {start_interpolation:0,transformation:{translation:[-0.271f,2.148f,-0.117f],left_rotation:[0.4111f,-0.1721f,0.1763f,0.8777f]}}
data merge entity f4c9c580-42de-5f18-958e-fe8f13f48db0 {start_interpolation:0,transformation:{translation:[0.042f,1.697f,-0.275f],left_rotation:[0.475f,0.6131f,0.1598f,0.6106f]}}
data merge entity 593cd5be-38e3-598f-a4f4-75287916d917 {start_interpolation:0,transformation:{translation:[-0.135f,1.714f,-0.342f],left_rotation:[-0.4007f,-0.1458f,-0.089f,0.9001f]}}
data merge entity b93e033a-5262-5632-b8ab-3de10d1c99fe {start_interpolation:0,transformation:{translation:[-0.128f,1.478f,-0.616f],left_rotation:[0.7108f,0.6136f,-0.1573f,0.3058f]}}
data merge entity e73b8616-4bc3-571b-bb40-c31cce9d3a8c {start_interpolation:0,transformation:{translation:[-0.257f,1.422f,-0.036f],left_rotation:[0.2275f,0.0206f,0.0649f,0.9714f]}}
