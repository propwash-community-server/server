data merge entity 11ae4677-4219-56c2-add0-4c64d57ac56a {start_interpolation:0,transformation:{translation:[0f,2.036f,-0.158f],left_rotation:[0.7573f,0f,0f,0.6531f]}}
data merge entity 7d2a9e32-11f2-50e1-9212-e206c5741830 {start_interpolation:0,transformation:{translation:[0.18f,1.967f,0.307f],left_rotation:[0.4127f,0.1329f,0.0976f,0.8958f]}}
data merge entity dde4ca15-7054-52aa-b829-17380091a80f {start_interpolation:0,transformation:{translation:[-0.18f,1.967f,0.307f],left_rotation:[0.4127f,-0.1329f,-0.0976f,0.8958f]}}
data merge entity f4c9c580-42de-5f18-958e-fe8f13f48db0 {start_interpolation:0,transformation:{translation:[0.095f,2.041f,-0.188f],left_rotation:[0.7301f,0.0108f,0.1086f,0.6746f]}}
data merge entity 593cd5be-38e3-598f-a4f4-75287916d917 {start_interpolation:0,transformation:{translation:[-0.095f,2.041f,-0.188f],left_rotation:[0.7301f,-0.0108f,-0.1086f,0.6746f]}}
data merge entity b93e033a-5262-5632-b8ab-3de10d1c99fe {start_interpolation:0,transformation:{translation:[0.153f,2.08f,-0.622f],left_rotation:[0.8903f,0.0409f,0.1012f,0.4422f]}}
data merge entity e73b8616-4bc3-571b-bb40-c31cce9d3a8c {start_interpolation:0,transformation:{translation:[-0.153f,2.08f,-0.622f],left_rotation:[0.8903f,-0.0409f,-0.1012f,0.4422f]}}
