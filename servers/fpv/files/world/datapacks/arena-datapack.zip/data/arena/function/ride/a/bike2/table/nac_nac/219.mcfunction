data merge entity 7f895ae6-3a84-58c6-84f5-016612fdd486 {start_interpolation:0,transformation:{translation:[0.046f,1.771f,0.077f],left_rotation:[0.4187f,0.168f,0.0184f,0.8922f]}}
data merge entity d5b82b8d-86e1-5276-8680-ed7a08615c7a {start_interpolation:0,transformation:{translation:[0.266f,2.107f,0.38f],left_rotation:[0.5434f,0.2026f,-0.1452f,0.8016f]}}
data merge entity a4c123d3-dfeb-5763-b680-e521fb79538b {start_interpolation:0,transformation:{translation:[-0.073f,2.045f,0.483f],left_rotation:[0.5445f,-0.3751f,0.0027f,0.7502f]}}
data merge entity 14895439-b1c6-5868-83ed-85b5ca16af52 {start_interpolation:0,transformation:{translation:[0.132f,1.768f,0.028f],left_rotation:[-0.2526f,0.1289f,0.1095f,0.9527f]}}
data merge entity ed503232-ebe9-57f4-8f88-a4efe27a7f4d {start_interpolation:0,transformation:{translation:[-0.047f,1.735f,0.082f],left_rotation:[0.281f,-0.639f,-0.5647f,0.4402f]}}
data merge entity 75e3c547-3dab-50d7-a8aa-ffff4a07edfb {start_interpolation:0,transformation:{translation:[0.253f,1.395f,0.227f],left_rotation:[0.3696f,-0.0093f,-0.0628f,0.927f]}}
data merge entity b4028d78-85e3-5bdd-b8d1-be173b14689d {start_interpolation:0,transformation:{translation:[-0.108f,1.645f,-0.345f],left_rotation:[0.5137f,-0.8367f,0.1707f,0.0832f]}}
