scoreboard objectives add arena dummy
scoreboard objectives add arena.alive minecraft.custom:minecraft.time_since_death
function arena:ride/load
