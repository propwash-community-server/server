data merge entity 11ae4677-4219-56c2-add0-4c64d57ac56a {start_interpolation:0,transformation:{translation:[-0.006f,1.829f,0.148f],left_rotation:[0.5095f,-0.0219f,-0.0017f,0.8602f]}}
data merge entity 7d2a9e32-11f2-50e1-9212-e206c5741830 {start_interpolation:0,transformation:{translation:[0.165f,2.051f,0.566f],left_rotation:[0.5851f,0.2942f,-0.0639f,0.753f],scale:[1f,1f,1.007f]}}
data merge entity dde4ca15-7054-52aa-b829-17380091a80f {start_interpolation:0,transformation:{translation:[-0.195f,2.06f,0.553f],left_rotation:[0.5857f,-0.2701f,0.0876f,0.7591f],scale:[1f,1f,1.008f]}}
data merge entity f4c9c580-42de-5f18-958e-fe8f13f48db0 {start_interpolation:0,transformation:{translation:[0.089f,1.813f,0.125f],left_rotation:[-0.1591f,0.1077f,0.1123f,0.9749f]}}
data merge entity 593cd5be-38e3-598f-a4f4-75287916d917 {start_interpolation:0,transformation:{translation:[-0.1f,1.817f,0.118f],left_rotation:[-0.1578f,-0.1106f,-0.1076f,0.9753f]}}
data merge entity b93e033a-5262-5632-b8ab-3de10d1c99fe {start_interpolation:0,transformation:{translation:[0.201f,1.406f,0.251f],left_rotation:[0.3575f,0.0168f,-0.0085f,0.9337f]}}
data merge entity e73b8616-4bc3-571b-bb40-c31cce9d3a8c {start_interpolation:0,transformation:{translation:[-0.208f,1.409f,0.243f],left_rotation:[0.3497f,0.0007f,0.0179f,0.9367f]}}
