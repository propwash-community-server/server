data merge entity 7f895ae6-3a84-58c6-84f5-016612fdd486 {start_interpolation:0,transformation:{translation:[0.032f,1.73f,-0.398f],left_rotation:[0.2616f,0.1167f,-0.0121f,0.958f]}}
data merge entity d5b82b8d-86e1-5276-8680-ed7a08615c7a {start_interpolation:0,transformation:{translation:[0.247f,2.142f,-0.206f],left_rotation:[0.3893f,0.1928f,-0.173f,0.8839f]}}
data merge entity a4c123d3-dfeb-5763-b680-e521fb79538b {start_interpolation:0,transformation:{translation:[-0.103f,2.128f,-0.123f],left_rotation:[0.396f,-0.3352f,0.0919f,0.8499f],scale:[1f,1f,0.993f]}}
data merge entity 14895439-b1c6-5868-83ed-85b5ca16af52 {start_interpolation:0,transformation:{translation:[0.122f,1.707f,-0.435f],left_rotation:[-0.4128f,0.142f,0.0818f,0.896f]}}
data merge entity ed503232-ebe9-57f4-8f88-a4efe27a7f4d {start_interpolation:0,transformation:{translation:[-0.063f,1.7f,-0.392f],left_rotation:[0.0099f,-0.9586f,-0.2835f,0.024f]}}
data merge entity 75e3c547-3dab-50d7-a8aa-ffff4a07edfb {start_interpolation:0,transformation:{translation:[0.238f,1.423f,-0.12f],left_rotation:[0.17f,-0.0149f,-0.0459f,0.9843f]}}
data merge entity b4028d78-85e3-5bdd-b8d1-be173b14689d {start_interpolation:0,transformation:{translation:[-0.06f,1.331f,-0.631f],left_rotation:[0.0112f,-0.9078f,0.4175f,0.038f]}}
