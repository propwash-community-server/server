data merge entity 11ae4677-4219-56c2-add0-4c64d57ac56a {start_interpolation:0,transformation:{translation:[0f,1.801f,-0.041f],left_rotation:[0.2008f,0f,0f,0.9796f]}}
data merge entity 7d2a9e32-11f2-50e1-9212-e206c5741830 {start_interpolation:0,transformation:{translation:[0.18f,2.233f,0.144f],left_rotation:[-0.3622f,0.4869f,0.236f,0.759f],scale:[1f,1f,0.989f]}}
data merge entity dde4ca15-7054-52aa-b829-17380091a80f {start_interpolation:0,transformation:{translation:[-0.18f,2.233f,0.144f],left_rotation:[-0.3622f,-0.4869f,-0.236f,0.759f],scale:[1f,1f,0.989f]}}
data merge entity f4c9c580-42de-5f18-958e-fe8f13f48db0 {start_interpolation:0,transformation:{translation:[0.095f,1.774f,-0.053f],left_rotation:[-0.2859f,0.0399f,0.0838f,0.9538f]}}
data merge entity 593cd5be-38e3-598f-a4f4-75287916d917 {start_interpolation:0,transformation:{translation:[-0.095f,1.774f,-0.053f],left_rotation:[-0.2859f,-0.0399f,-0.0838f,0.9538f]}}
data merge entity b93e033a-5262-5632-b8ab-3de10d1c99fe {start_interpolation:0,transformation:{translation:[0.175f,1.412f,0.184f],left_rotation:[0.3416f,0.0023f,0.0145f,0.9397f]}}
data merge entity e73b8616-4bc3-571b-bb40-c31cce9d3a8c {start_interpolation:0,transformation:{translation:[-0.175f,1.412f,0.184f],left_rotation:[0.3416f,-0.0023f,-0.0145f,0.9397f]}}
