data merge entity 7f895ae6-3a84-58c6-84f5-016612fdd486 {start_interpolation:0,transformation:{translation:[0f,1.849f,0.228f],left_rotation:[0.5883f,0f,0f,0.8086f]}}
data merge entity d5b82b8d-86e1-5276-8680-ed7a08615c7a {start_interpolation:0,transformation:{translation:[0.18f,1.993f,0.675f],left_rotation:[0.6151f,0.2558f,-0.0348f,0.745f],scale:[1f,1f,1.005f]}}
data merge entity a4c123d3-dfeb-5763-b680-e521fb79538b {start_interpolation:0,transformation:{translation:[-0.18f,1.993f,0.675f],left_rotation:[0.6151f,-0.2558f,0.0348f,0.745f],scale:[1f,1f,1.005f]}}
data merge entity 14895439-b1c6-5868-83ed-85b5ca16af52 {start_interpolation:0,transformation:{translation:[0.095f,1.839f,0.2f],left_rotation:[-0.0869f,0.1171f,0.1031f,0.9839f]}}
data merge entity ed503232-ebe9-57f4-8f88-a4efe27a7f4d {start_interpolation:0,transformation:{translation:[-0.095f,1.839f,0.2f],left_rotation:[-0.0869f,-0.1171f,-0.1031f,0.9839f]}}
data merge entity 75e3c547-3dab-50d7-a8aa-ffff4a07edfb {start_interpolation:0,transformation:{translation:[0.193f,1.415f,0.264f],left_rotation:[0.3326f,0.0177f,-0.0013f,0.9429f]}}
data merge entity b4028d78-85e3-5bdd-b8d1-be173b14689d {start_interpolation:0,transformation:{translation:[-0.193f,1.415f,0.264f],left_rotation:[0.3326f,-0.0177f,0.0013f,0.9429f]}}
