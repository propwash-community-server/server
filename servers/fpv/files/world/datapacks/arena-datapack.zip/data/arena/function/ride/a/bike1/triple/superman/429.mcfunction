data merge entity 11ae4677-4219-56c2-add0-4c64d57ac56a {start_interpolation:0,transformation:{translation:[0f,1.955f,-0.51f],left_rotation:[0.6727f,0f,0f,0.7399f]}}
data merge entity 7d2a9e32-11f2-50e1-9212-e206c5741830 {start_interpolation:0,transformation:{translation:[0.18f,2f,-0.042f],left_rotation:[0.3013f,0.1438f,0.0809f,0.9391f]}}
data merge entity dde4ca15-7054-52aa-b829-17380091a80f {start_interpolation:0,transformation:{translation:[-0.18f,2f,-0.042f],left_rotation:[0.3013f,-0.1438f,-0.0809f,0.9391f]}}
data merge entity f4c9c580-42de-5f18-958e-fe8f13f48db0 {start_interpolation:0,transformation:{translation:[0.095f,1.952f,-0.54f],left_rotation:[0.6432f,0.0239f,0.1065f,0.7579f]}}
data merge entity 593cd5be-38e3-598f-a4f4-75287916d917 {start_interpolation:0,transformation:{translation:[-0.095f,1.952f,-0.54f],left_rotation:[0.6432f,-0.0239f,-0.1065f,0.7579f]}}
data merge entity b93e033a-5262-5632-b8ab-3de10d1c99fe {start_interpolation:0,transformation:{translation:[0.153f,1.886f,-0.971f],left_rotation:[0.8303f,0.0528f,0.0955f,0.5466f]}}
data merge entity e73b8616-4bc3-571b-bb40-c31cce9d3a8c {start_interpolation:0,transformation:{translation:[-0.153f,1.886f,-0.971f],left_rotation:[0.8303f,-0.0528f,-0.0955f,0.5466f]}}
