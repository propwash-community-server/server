data merge entity 11ae4677-4219-56c2-add0-4c64d57ac56a {start_interpolation:0,transformation:{translation:[-0.047f,1.769f,0.068f],left_rotation:[0.4129f,-0.1738f,-0.0187f,0.8938f]}}
data merge entity 7d2a9e32-11f2-50e1-9212-e206c5741830 {start_interpolation:0,transformation:{translation:[0.07f,2.047f,0.471f],left_rotation:[0.5407f,0.3782f,-0.0016f,0.7514f]}}
data merge entity dde4ca15-7054-52aa-b829-17380091a80f {start_interpolation:0,transformation:{translation:[-0.268f,2.11f,0.365f],left_rotation:[0.5393f,-0.1999f,0.147f,0.8047f]}}
data merge entity f4c9c580-42de-5f18-958e-fe8f13f48db0 {start_interpolation:0,transformation:{translation:[0.045f,1.733f,0.074f],left_rotation:[0.3675f,0.6118f,0.4593f,0.5288f]}}
data merge entity 593cd5be-38e3-598f-a4f4-75287916d917 {start_interpolation:0,transformation:{translation:[-0.133f,1.766f,0.018f],left_rotation:[-0.2584f,-0.1299f,-0.1093f,0.951f]}}
data merge entity b93e033a-5262-5632-b8ab-3de10d1c99fe {start_interpolation:0,transformation:{translation:[0.061f,1.597f,-0.344f],left_rotation:[0.6338f,0.7514f,-0.1453f,0.1122f]}}
data merge entity e73b8616-4bc3-571b-bb40-c31cce9d3a8c {start_interpolation:0,transformation:{translation:[-0.254f,1.395f,0.221f],left_rotation:[0.3675f,0.01f,0.0645f,0.9277f]}}
