data merge entity 11ae4677-4219-56c2-add0-4c64d57ac56a {start_interpolation:0,transformation:{translation:[0f,1.99f,-0.401f],left_rotation:[0.7006f,0f,0f,0.7136f]}}
data merge entity 7d2a9e32-11f2-50e1-9212-e206c5741830 {start_interpolation:0,transformation:{translation:[0.18f,1.999f,0.069f],left_rotation:[0.337f,0.1406f,0.0863f,0.9269f]}}
data merge entity dde4ca15-7054-52aa-b829-17380091a80f {start_interpolation:0,transformation:{translation:[-0.18f,1.999f,0.069f],left_rotation:[0.337f,-0.1406f,-0.0863f,0.9269f]}}
data merge entity f4c9c580-42de-5f18-958e-fe8f13f48db0 {start_interpolation:0,transformation:{translation:[0.095f,1.989f,-0.431f],left_rotation:[0.6717f,0.0198f,0.1073f,0.7327f]}}
data merge entity 593cd5be-38e3-598f-a4f4-75287916d917 {start_interpolation:0,transformation:{translation:[-0.095f,1.989f,-0.431f],left_rotation:[0.6717f,-0.0198f,-0.1073f,0.7327f]}}
data merge entity b93e033a-5262-5632-b8ab-3de10d1c99fe {start_interpolation:0,transformation:{translation:[0.153f,1.956f,-0.866f],left_rotation:[0.8506f,0.0491f,0.0974f,0.5144f]}}
data merge entity e73b8616-4bc3-571b-bb40-c31cce9d3a8c {start_interpolation:0,transformation:{translation:[-0.153f,1.956f,-0.866f],left_rotation:[0.8506f,-0.0491f,-0.0974f,0.5144f]}}
