data merge entity 7f895ae6-3a84-58c6-84f5-016612fdd486 {start_interpolation:0,transformation:{translation:[0.015f,1.733f,-0.468f],left_rotation:[0.2687f,0.0517f,-0.008f,0.9618f]}}
data merge entity d5b82b8d-86e1-5276-8680-ed7a08615c7a {start_interpolation:0,transformation:{translation:[0.214f,2.137f,-0.245f],left_rotation:[0.3777f,0.2217f,-0.1599f,0.8846f],scale:[1f,1f,1.002f]}}
data merge entity a4c123d3-dfeb-5763-b680-e521fb79538b {start_interpolation:0,transformation:{translation:[-0.144f,2.133f,-0.207f],left_rotation:[0.3803f,-0.2897f,0.1214f,0.8699f],scale:[1f,1f,1f]}}
data merge entity 14895439-b1c6-5868-83ed-85b5ca16af52 {start_interpolation:0,transformation:{translation:[0.108f,1.708f,-0.494f],left_rotation:[-0.4089f,0.1369f,0.0781f,0.8989f]}}
data merge entity ed503232-ebe9-57f4-8f88-a4efe27a7f4d {start_interpolation:0,transformation:{translation:[-0.081f,1.706f,-0.474f],left_rotation:[-0.4141f,-0.1357f,-0.091f,0.8955f]}}
data merge entity 75e3c547-3dab-50d7-a8aa-ffff4a07edfb {start_interpolation:0,transformation:{translation:[0.219f,1.421f,-0.18f],left_rotation:[0.1248f,-0.0085f,-0.0273f,0.9918f]}}
data merge entity b4028d78-85e3-5bdd-b8d1-be173b14689d {start_interpolation:0,transformation:{translation:[-0.202f,1.424f,-0.159f],left_rotation:[0.1452f,-0.0397f,0.017f,0.9885f]}}
