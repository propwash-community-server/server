data merge entity 11ae4677-4219-56c2-add0-4c64d57ac56a {start_interpolation:0,transformation:{translation:[-0.05f,1.758f,-0.141f],left_rotation:[0.3302f,-0.1854f,-0.0046f,0.9255f]}}
data merge entity 7d2a9e32-11f2-50e1-9212-e206c5741830 {start_interpolation:0,transformation:{translation:[0.064f,2.102f,0.209f],left_rotation:[0.4726f,0.3828f,-0.0299f,0.7932f]}}
data merge entity dde4ca15-7054-52aa-b829-17380091a80f {start_interpolation:0,transformation:{translation:[-0.271f,2.149f,0.086f],left_rotation:[0.466f,-0.1827f,0.165f,0.8498f]}}
data merge entity f4c9c580-42de-5f18-958e-fe8f13f48db0 {start_interpolation:0,transformation:{translation:[0.042f,1.723f,-0.127f],left_rotation:[0.532f,0.599f,0.1795f,0.5709f]}}
data merge entity 593cd5be-38e3-598f-a4f4-75287916d917 {start_interpolation:0,transformation:{translation:[-0.135f,1.747f,-0.191f],left_rotation:[-0.3429f,-0.1399f,-0.0981f,0.9237f]}}
data merge entity b93e033a-5262-5632-b8ab-3de10d1c99fe {start_interpolation:0,transformation:{translation:[-0.148f,1.56f,-0.489f],left_rotation:[0.7311f,0.6161f,-0.107f,0.273f]}}
data merge entity e73b8616-4bc3-571b-bb40-c31cce9d3a8c {start_interpolation:0,transformation:{translation:[-0.257f,1.419f,0.075f],left_rotation:[0.289f,0.0165f,0.0663f,0.9549f]}}
