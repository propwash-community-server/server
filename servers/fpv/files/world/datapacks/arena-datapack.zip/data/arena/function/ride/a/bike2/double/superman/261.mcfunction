data merge entity 7f895ae6-3a84-58c6-84f5-016612fdd486 {start_interpolation:0,transformation:{translation:[0f,1.92f,-0.598f],left_rotation:[0.6491f,0f,0f,0.7607f]}}
data merge entity d5b82b8d-86e1-5276-8680-ed7a08615c7a {start_interpolation:0,transformation:{translation:[0.18f,1.994f,-0.133f],left_rotation:[0.2716f,0.1462f,0.0763f,0.9482f]}}
data merge entity a4c123d3-dfeb-5763-b680-e521fb79538b {start_interpolation:0,transformation:{translation:[-0.18f,1.994f,-0.133f],left_rotation:[0.2716f,-0.1462f,-0.0763f,0.9482f]}}
data merge entity 14895439-b1c6-5868-83ed-85b5ca16af52 {start_interpolation:0,transformation:{translation:[0.095f,1.915f,-0.627f],left_rotation:[0.619f,0.0272f,0.1057f,0.7778f]}}
data merge entity ed503232-ebe9-57f4-8f88-a4efe27a7f4d {start_interpolation:0,transformation:{translation:[-0.095f,1.915f,-0.627f],left_rotation:[0.619f,-0.0272f,-0.1057f,0.7778f]}}
data merge entity 75e3c547-3dab-50d7-a8aa-ffff4a07edfb {start_interpolation:0,transformation:{translation:[0.153f,1.822f,-1.053f],left_rotation:[0.8126f,0.0558f,0.0938f,0.5725f]}}
data merge entity b4028d78-85e3-5bdd-b8d1-be173b14689d {start_interpolation:0,transformation:{translation:[-0.153f,1.822f,-1.053f],left_rotation:[0.8126f,-0.0558f,-0.0938f,0.5725f]}}
