data merge entity 7f895ae6-3a84-58c6-84f5-016612fdd486 {start_interpolation:0,transformation:{translation:[0f,1.735f,-0.408f],left_rotation:[0.0638f,0f,0f,0.998f]}}
data merge entity d5b82b8d-86e1-5276-8680-ed7a08615c7a {start_interpolation:0,transformation:{translation:[0.18f,2.202f,-0.348f],left_rotation:[-0.4382f,0.5069f,0.1398f,0.729f],scale:[1f,1f,0.883f]}}
data merge entity a4c123d3-dfeb-5763-b680-e521fb79538b {start_interpolation:0,transformation:{translation:[-0.18f,2.202f,-0.348f],left_rotation:[-0.4382f,-0.5069f,-0.1398f,0.729f],scale:[1f,1f,0.883f]}}
data merge entity 14895439-b1c6-5868-83ed-85b5ca16af52 {start_interpolation:0,transformation:{translation:[0.095f,1.706f,-0.412f],left_rotation:[-0.4225f,0.055f,0.0774f,0.9014f]}}
data merge entity ed503232-ebe9-57f4-8f88-a4efe27a7f4d {start_interpolation:0,transformation:{translation:[-0.095f,1.706f,-0.412f],left_rotation:[-0.4225f,-0.055f,-0.0774f,0.9014f]}}
data merge entity 75e3c547-3dab-50d7-a8aa-ffff4a07edfb {start_interpolation:0,transformation:{translation:[0.177f,1.428f,-0.081f],left_rotation:[0.1954f,0.0039f,0.0126f,0.9806f]}}
data merge entity b4028d78-85e3-5bdd-b8d1-be173b14689d {start_interpolation:0,transformation:{translation:[-0.177f,1.428f,-0.081f],left_rotation:[0.1954f,-0.0039f,-0.0126f,0.9806f]}}
