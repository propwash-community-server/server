data merge entity 7f895ae6-3a84-58c6-84f5-016612fdd486 {start_interpolation:0,transformation:{left_rotation:[0.5349f,0.0057f,0.0005f,0.8449f]}}
data merge entity d5b82b8d-86e1-5276-8680-ed7a08615c7a {start_interpolation:0,transformation:{left_rotation:[0.6032f,0.2804f,-0.0734f,0.743f],scale:[1f,1f,1.012f]}}
data merge entity a4c123d3-dfeb-5763-b680-e521fb79538b {start_interpolation:0,transformation:{left_rotation:[0.603f,-0.2866f,0.067f,0.7415f],scale:[1f,1f,1.012f]}}
data merge entity 14895439-b1c6-5868-83ed-85b5ca16af52 {start_interpolation:0,transformation:{left_rotation:[-0.1263f,0.1064f,0.1092f,0.9802f]}}
data merge entity ed503232-ebe9-57f4-8f88-a4efe27a7f4d {start_interpolation:0,transformation:{left_rotation:[-0.1266f,-0.1056f,-0.1104f,0.9801f]}}
data merge entity 75e3c547-3dab-50d7-a8aa-ffff4a07edfb {start_interpolation:0,transformation:{left_rotation:[0.3628f,-0.0001f,-0.0123f,0.9318f]}}
data merge entity b4028d78-85e3-5bdd-b8d1-be173b14689d {start_interpolation:0,transformation:{translation:[-0.201f,1.401f,0.276f],left_rotation:[0.3649f,-0.0043f,0.0098f,0.931f]}}
