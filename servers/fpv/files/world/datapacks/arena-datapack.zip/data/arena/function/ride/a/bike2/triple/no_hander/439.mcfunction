data merge entity 7f895ae6-3a84-58c6-84f5-016612fdd486 {start_interpolation:0,transformation:{translation:[0f,1.709f,-0.555f],left_rotation:[0.2045f,0f,0f,0.9789f]}}
data merge entity d5b82b8d-86e1-5276-8680-ed7a08615c7a {start_interpolation:0,transformation:{translation:[0.18f,2.14f,-0.367f],left_rotation:[0.2849f,0.2591f,-0.202f,0.9005f]}}
data merge entity a4c123d3-dfeb-5763-b680-e521fb79538b {start_interpolation:0,transformation:{translation:[-0.18f,2.14f,-0.367f],left_rotation:[0.2849f,-0.2591f,0.202f,0.9005f]}}
data merge entity 14895439-b1c6-5868-83ed-85b5ca16af52 {start_interpolation:0,transformation:{translation:[0.095f,1.682f,-0.567f],left_rotation:[-0.4312f,0.1164f,0.0754f,0.8915f]}}
data merge entity ed503232-ebe9-57f4-8f88-a4efe27a7f4d {start_interpolation:0,transformation:{translation:[-0.095f,1.682f,-0.567f],left_rotation:[-0.4312f,-0.1164f,-0.0754f,0.8915f]}}
data merge entity 75e3c547-3dab-50d7-a8aa-ffff4a07edfb {start_interpolation:0,transformation:{translation:[0.198f,1.41f,-0.236f],left_rotation:[0.0883f,-0.0026f,-0.0078f,0.9961f]}}
data merge entity b4028d78-85e3-5bdd-b8d1-be173b14689d {start_interpolation:0,transformation:{translation:[-0.198f,1.41f,-0.236f],left_rotation:[0.0883f,0.0026f,0.0078f,0.9961f]}}
