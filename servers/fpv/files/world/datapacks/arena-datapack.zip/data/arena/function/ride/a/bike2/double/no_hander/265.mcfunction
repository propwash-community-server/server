data merge entity 7f895ae6-3a84-58c6-84f5-016612fdd486 {start_interpolation:0,transformation:{translation:[0f,1.801f,-0.049f],left_rotation:[0.1968f,0f,0f,0.9804f]}}
data merge entity d5b82b8d-86e1-5276-8680-ed7a08615c7a {start_interpolation:0,transformation:{translation:[0.18f,2.234f,0.133f],left_rotation:[-0.3677f,0.4882f,0.2365f,0.7553f]}}
data merge entity a4c123d3-dfeb-5763-b680-e521fb79538b {start_interpolation:0,transformation:{translation:[-0.18f,2.234f,0.133f],left_rotation:[-0.3677f,-0.4882f,-0.2365f,0.7553f]}}
data merge entity 14895439-b1c6-5868-83ed-85b5ca16af52 {start_interpolation:0,transformation:{translation:[0.095f,1.773f,-0.06f],left_rotation:[-0.2889f,0.0399f,0.0836f,0.9529f]}}
data merge entity ed503232-ebe9-57f4-8f88-a4efe27a7f4d {start_interpolation:0,transformation:{translation:[-0.095f,1.773f,-0.06f],left_rotation:[-0.2889f,-0.0399f,-0.0836f,0.9529f]}}
data merge entity 75e3c547-3dab-50d7-a8aa-ffff4a07edfb {start_interpolation:0,transformation:{translation:[0.175f,1.413f,0.179f],left_rotation:[0.3391f,0.0024f,0.0147f,0.9406f]}}
data merge entity b4028d78-85e3-5bdd-b8d1-be173b14689d {start_interpolation:0,transformation:{translation:[-0.175f,1.413f,0.179f],left_rotation:[0.3391f,-0.0024f,-0.0147f,0.9406f]}}
