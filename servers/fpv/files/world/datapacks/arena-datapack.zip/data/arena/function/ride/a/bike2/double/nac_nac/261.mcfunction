data merge entity 7f895ae6-3a84-58c6-84f5-016612fdd486 {start_interpolation:0,transformation:{translation:[0.05f,1.753f,-0.18f],left_rotation:[0.3149f,0.1854f,0.0015f,0.9308f]}}
data merge entity d5b82b8d-86e1-5276-8680-ed7a08615c7a {start_interpolation:0,transformation:{translation:[0.271f,2.151f,0.034f],left_rotation:[0.452f,0.18f,-0.168f,0.8574f]}}
data merge entity a4c123d3-dfeb-5763-b680-e521fb79538b {start_interpolation:0,transformation:{translation:[-0.064f,2.108f,0.158f],left_rotation:[0.4595f,-0.3823f,0.0362f,0.8009f]}}
data merge entity 14895439-b1c6-5868-83ed-85b5ca16af52 {start_interpolation:0,transformation:{translation:[0.135f,1.74f,-0.231f],left_rotation:[-0.358f,0.1415f,0.0958f,0.918f]}}
data merge entity ed503232-ebe9-57f4-8f88-a4efe27a7f4d {start_interpolation:0,transformation:{translation:[-0.042f,1.718f,-0.165f],left_rotation:[0.5226f,-0.6018f,-0.1697f,0.5796f]}}
data merge entity 75e3c547-3dab-50d7-a8aa-ffff4a07edfb {start_interpolation:0,transformation:{translation:[0.257f,1.421f,0.047f],left_rotation:[0.2733f,-0.0176f,-0.066f,0.9595f]}}
data merge entity b4028d78-85e3-5bdd-b8d1-be173b14689d {start_interpolation:0,transformation:{translation:[0.148f,1.543f,-0.522f],left_rotation:[0.7265f,-0.6142f,0.1171f,0.285f]}}
