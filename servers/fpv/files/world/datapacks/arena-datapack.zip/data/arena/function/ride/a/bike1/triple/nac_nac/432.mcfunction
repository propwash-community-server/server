data merge entity 11ae4677-4219-56c2-add0-4c64d57ac56a {start_interpolation:0,transformation:{translation:[-0.05f,1.766f,0.033f],left_rotation:[0.3956f,-0.1846f,-0.0179f,0.8995f]}}
data merge entity 7d2a9e32-11f2-50e1-9212-e206c5741830 {start_interpolation:0,transformation:{translation:[0.064f,2.057f,0.428f],left_rotation:[0.5282f,0.384f,-0.0024f,0.7573f]}}
data merge entity dde4ca15-7054-52aa-b829-17380091a80f {start_interpolation:0,transformation:{translation:[-0.271f,2.121f,0.314f],left_rotation:[0.5257f,-0.1941f,0.1515f,0.8143f]}}
data merge entity f4c9c580-42de-5f18-958e-fe8f13f48db0 {start_interpolation:0,transformation:{translation:[0.042f,1.729f,0.042f],left_rotation:[0.5716f,0.5846f,0.2219f,0.5314f]}}
data merge entity 593cd5be-38e3-598f-a4f4-75287916d917 {start_interpolation:0,transformation:{translation:[-0.135f,1.762f,-0.018f],left_rotation:[-0.2758f,-0.1325f,-0.1079f,0.9459f]}}
data merge entity b93e033a-5262-5632-b8ab-3de10d1c99fe {start_interpolation:0,transformation:{translation:[-0.148f,1.619f,-0.339f],left_rotation:[0.7487f,0.6221f,-0.0626f,0.22f]}}
data merge entity e73b8616-4bc3-571b-bb40-c31cce9d3a8c {start_interpolation:0,transformation:{translation:[-0.257f,1.4f,0.199f],left_rotation:[0.3567f,0.0118f,0.0673f,0.9317f]}}
