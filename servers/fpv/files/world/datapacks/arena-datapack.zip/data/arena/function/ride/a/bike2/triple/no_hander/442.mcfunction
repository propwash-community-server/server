data merge entity 7f895ae6-3a84-58c6-84f5-016612fdd486 {start_interpolation:0,transformation:{translation:[0f,1.724f,-0.434f],left_rotation:[0.0403f,0f,0f,0.9992f]}}
data merge entity d5b82b8d-86e1-5276-8680-ed7a08615c7a {start_interpolation:0,transformation:{translation:[0.18f,2.192f,-0.397f],left_rotation:[-0.4818f,0.5193f,0.1569f,0.6881f],scale:[1f,1f,1f]}}
data merge entity a4c123d3-dfeb-5763-b680-e521fb79538b {start_interpolation:0,transformation:{translation:[-0.18f,2.192f,-0.397f],left_rotation:[-0.4818f,-0.5193f,-0.1569f,0.6881f],scale:[1f,1f,1f]}}
data merge entity 14895439-b1c6-5868-83ed-85b5ca16af52 {start_interpolation:0,transformation:{translation:[0.095f,1.694f,-0.437f],left_rotation:[-0.4351f,0.0525f,0.0763f,0.8956f]}}
data merge entity ed503232-ebe9-57f4-8f88-a4efe27a7f4d {start_interpolation:0,transformation:{translation:[-0.095f,1.694f,-0.437f],left_rotation:[-0.4351f,-0.0525f,-0.0763f,0.8956f]}}
data merge entity 75e3c547-3dab-50d7-a8aa-ffff4a07edfb {start_interpolation:0,transformation:{translation:[0.175f,1.426f,-0.097f],left_rotation:[0.187f,0.0046f,0.0141f,0.9822f]}}
data merge entity b4028d78-85e3-5bdd-b8d1-be173b14689d {start_interpolation:0,transformation:{translation:[-0.175f,1.426f,-0.097f],left_rotation:[0.187f,-0.0046f,-0.0141f,0.9822f]}}
