data merge entity 7f895ae6-3a84-58c6-84f5-016612fdd486 {start_interpolation:0,transformation:{translation:[0.05f,1.764f,-0.073f],left_rotation:[0.356f,0.1852f,0.0098f,0.9159f]}}
data merge entity d5b82b8d-86e1-5276-8680-ed7a08615c7a {start_interpolation:0,transformation:{translation:[0.271f,2.142f,0.176f],left_rotation:[0.4897f,0.1873f,-0.1598f,0.8364f]}}
data merge entity a4c123d3-dfeb-5763-b680-e521fb79538b {start_interpolation:0,transformation:{translation:[-0.064f,2.088f,0.296f],left_rotation:[0.4947f,-0.3835f,0.0192f,0.7796f]}}
data merge entity 14895439-b1c6-5868-83ed-85b5ca16af52 {start_interpolation:0,transformation:{translation:[0.135f,1.756f,-0.124f],left_rotation:[-0.3168f,0.1371f,0.102f,0.933f]}}
data merge entity ed503232-ebe9-57f4-8f88-a4efe27a7f4d {start_interpolation:0,transformation:{translation:[-0.042f,1.728f,-0.061f],left_rotation:[0.5479f,-0.5937f,-0.1963f,0.5557f]}}
data merge entity 75e3c547-3dab-50d7-a8aa-ffff4a07edfb {start_interpolation:0,transformation:{translation:[0.257f,1.414f,0.124f],left_rotation:[0.3158f,-0.0147f,-0.0667f,0.9464f]}}
data merge entity b4028d78-85e3-5bdd-b8d1-be173b14689d {start_interpolation:0,transformation:{translation:[0.148f,1.586f,-0.431f],left_rotation:[0.7385f,-0.6188f,0.0897f,0.2524f]}}
