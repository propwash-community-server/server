data merge entity 11ae4677-4219-56c2-add0-4c64d57ac56a {start_interpolation:0,transformation:{translation:[0f,1.733f,-0.463f],left_rotation:[0.1429f,0f,0f,0.9897f]}}
data merge entity 7d2a9e32-11f2-50e1-9212-e206c5741830 {start_interpolation:0,transformation:{translation:[0.18f,2.184f,-0.331f],left_rotation:[0.0821f,0.341f,-0.1862f,0.9178f],scale:[1f,1f,0.704f]}}
data merge entity dde4ca15-7054-52aa-b829-17380091a80f {start_interpolation:0,transformation:{translation:[-0.18f,2.184f,-0.331f],left_rotation:[0.0821f,-0.341f,0.1862f,0.9178f],scale:[1f,1f,0.704f]}}
data merge entity f4c9c580-42de-5f18-958e-fe8f13f48db0 {start_interpolation:0,transformation:{translation:[0.095f,1.704f,-0.472f],left_rotation:[-0.4206f,0.085f,0.0788f,0.8998f]}}
data merge entity 593cd5be-38e3-598f-a4f4-75287916d917 {start_interpolation:0,transformation:{translation:[-0.095f,1.704f,-0.472f],left_rotation:[-0.4206f,-0.085f,-0.0788f,0.8998f]}}
data merge entity b93e033a-5262-5632-b8ab-3de10d1c99fe {start_interpolation:0,transformation:{translation:[0.189f,1.425f,-0.145f],left_rotation:[0.1503f,0.0003f,0.0011f,0.9886f]}}
data merge entity e73b8616-4bc3-571b-bb40-c31cce9d3a8c {start_interpolation:0,transformation:{translation:[-0.189f,1.425f,-0.145f],left_rotation:[0.1503f,-0.0003f,-0.0011f,0.9886f]}}
