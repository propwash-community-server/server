data merge entity 11ae4677-4219-56c2-add0-4c64d57ac56a {start_interpolation:0,transformation:{translation:[-0.05f,1.76f,-0.122f],left_rotation:[0.3372f,-0.1853f,-0.006f,0.923f]}}
data merge entity 7d2a9e32-11f2-50e1-9212-e206c5741830 {start_interpolation:0,transformation:{translation:[0.064f,2.099f,0.232f],left_rotation:[0.4786f,0.3831f,-0.027f,0.7896f]}}
data merge entity dde4ca15-7054-52aa-b829-17380091a80f {start_interpolation:0,transformation:{translation:[-0.271f,2.148f,0.111f],left_rotation:[0.4724f,-0.184f,0.1637f,0.8463f]}}
data merge entity f4c9c580-42de-5f18-958e-fe8f13f48db0 {start_interpolation:0,transformation:{translation:[0.042f,1.724f,-0.109f],left_rotation:[0.5364f,0.5976f,0.1841f,0.5669f]}}
data merge entity 593cd5be-38e3-598f-a4f4-75287916d917 {start_interpolation:0,transformation:{translation:[-0.135f,1.75f,-0.173f],left_rotation:[-0.3358f,-0.1392f,-0.0992f,0.9263f]}}
data merge entity b93e033a-5262-5632-b8ab-3de10d1c99fe {start_interpolation:0,transformation:{translation:[-0.148f,1.567f,-0.473f],left_rotation:[0.7331f,0.6169f,-0.1023f,0.2675f]}}
data merge entity e73b8616-4bc3-571b-bb40-c31cce9d3a8c {start_interpolation:0,transformation:{translation:[-0.257f,1.418f,0.089f],left_rotation:[0.2963f,0.016f,0.0664f,0.9527f]}}
