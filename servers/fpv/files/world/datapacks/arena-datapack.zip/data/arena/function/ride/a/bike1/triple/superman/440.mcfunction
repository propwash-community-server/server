data merge entity 11ae4677-4219-56c2-add0-4c64d57ac56a {start_interpolation:0,transformation:{translation:[0f,1.88f,0.19f],left_rotation:[0.6236f,0f,0f,0.7818f]}}
data merge entity 7d2a9e32-11f2-50e1-9212-e206c5741830 {start_interpolation:0,transformation:{translation:[0.18f,1.984f,0.648f],left_rotation:[0.6037f,0.2245f,-0.002f,0.7649f]}}
data merge entity dde4ca15-7054-52aa-b829-17380091a80f {start_interpolation:0,transformation:{translation:[-0.18f,1.984f,0.648f],left_rotation:[0.6037f,-0.2245f,0.002f,0.7649f]}}
data merge entity f4c9c580-42de-5f18-958e-fe8f13f48db0 {start_interpolation:0,transformation:{translation:[0.095f,1.873f,0.161f],left_rotation:[-0.0685f,0.1403f,0.0949f,0.9832f]}}
data merge entity 593cd5be-38e3-598f-a4f4-75287916d917 {start_interpolation:0,transformation:{translation:[-0.095f,1.873f,0.161f],left_rotation:[-0.0685f,-0.1403f,-0.0949f,0.9832f]}}
data merge entity b93e033a-5262-5632-b8ab-3de10d1c99fe {start_interpolation:0,transformation:{translation:[0.186f,1.445f,0.208f],left_rotation:[0.2707f,0.0417f,0.0075f,0.9617f]}}
data merge entity e73b8616-4bc3-571b-bb40-c31cce9d3a8c {start_interpolation:0,transformation:{translation:[-0.186f,1.445f,0.208f],left_rotation:[0.2707f,-0.0417f,-0.0075f,0.9617f]}}
