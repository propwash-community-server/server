data merge entity 11ae4677-4219-56c2-add0-4c64d57ac56a {start_interpolation:0,transformation:{translation:[-0.05f,1.764f,0.076f],left_rotation:[0.4113f,-0.1842f,-0.0211f,0.8924f]}}
data merge entity 7d2a9e32-11f2-50e1-9212-e206c5741830 {start_interpolation:0,transformation:{translation:[0.064f,2.041f,0.481f],left_rotation:[0.5414f,0.384f,0.0043f,0.7479f]}}
data merge entity dde4ca15-7054-52aa-b829-17380091a80f {start_interpolation:0,transformation:{translation:[-0.271f,2.109f,0.369f],left_rotation:[0.5399f,-0.1967f,0.1481f,0.8049f]}}
data merge entity f4c9c580-42de-5f18-958e-fe8f13f48db0 {start_interpolation:0,transformation:{translation:[0.042f,1.726f,0.083f],left_rotation:[0.5808f,0.5806f,0.2322f,0.5213f]}}
data merge entity 593cd5be-38e3-598f-a4f4-75287916d917 {start_interpolation:0,transformation:{translation:[-0.135f,1.762f,0.024f],left_rotation:[-0.2592f,-0.1306f,-0.1102f,0.9506f]}}
data merge entity b93e033a-5262-5632-b8ab-3de10d1c99fe {start_interpolation:0,transformation:{translation:[-0.148f,1.631f,-0.302f],left_rotation:[0.7525f,0.6231f,-0.0517f,0.2068f]}}
data merge entity e73b8616-4bc3-571b-bb40-c31cce9d3a8c {start_interpolation:0,transformation:{translation:[-0.257f,1.392f,0.228f],left_rotation:[0.373f,0.0106f,0.0675f,0.9253f]}}
