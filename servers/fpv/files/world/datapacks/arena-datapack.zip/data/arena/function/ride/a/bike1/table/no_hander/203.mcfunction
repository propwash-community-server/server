data merge entity 11ae4677-4219-56c2-add0-4c64d57ac56a {start_interpolation:0,transformation:{translation:[0f,1.803f,-0.002f],left_rotation:[0.2202f,0f,0f,0.9755f]}}
data merge entity 7d2a9e32-11f2-50e1-9212-e206c5741830 {start_interpolation:0,transformation:{translation:[0.18f,2.227f,0.2f],left_rotation:[-0.3368f,0.481f,0.2355f,0.7745f],scale:[1f,1f,0.947f]}}
data merge entity dde4ca15-7054-52aa-b829-17380091a80f {start_interpolation:0,transformation:{translation:[-0.18f,2.227f,0.2f],left_rotation:[-0.3368f,-0.481f,-0.2355f,0.7745f],scale:[1f,1f,0.947f]}}
data merge entity f4c9c580-42de-5f18-958e-fe8f13f48db0 {start_interpolation:0,transformation:{translation:[0.095f,1.776f,-0.015f],left_rotation:[-0.2701f,0.0397f,0.0848f,0.9583f]}}
data merge entity 593cd5be-38e3-598f-a4f4-75287916d917 {start_interpolation:0,transformation:{translation:[-0.095f,1.776f,-0.015f],left_rotation:[-0.2701f,-0.0397f,-0.0848f,0.9583f]}}
data merge entity b93e033a-5262-5632-b8ab-3de10d1c99fe {start_interpolation:0,transformation:{translation:[0.176f,1.406f,0.21f],left_rotation:[0.3553f,0.002f,0.014f,0.9347f]}}
data merge entity e73b8616-4bc3-571b-bb40-c31cce9d3a8c {start_interpolation:0,transformation:{translation:[-0.176f,1.406f,0.21f],left_rotation:[0.3553f,-0.002f,-0.014f,0.9347f]}}
