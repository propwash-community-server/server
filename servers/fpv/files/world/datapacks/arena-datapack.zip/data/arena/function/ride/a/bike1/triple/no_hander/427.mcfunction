data merge entity 11ae4677-4219-56c2-add0-4c64d57ac56a {start_interpolation:0,transformation:{translation:[0f,1.77f,-0.279f],left_rotation:[0.1048f,0f,0f,0.9945f]}}
data merge entity 7d2a9e32-11f2-50e1-9212-e206c5741830 {start_interpolation:0,transformation:{translation:[0.18f,2.23f,-0.181f],left_rotation:[-0.4363f,0.5081f,0.1901f,0.7179f]}}
data merge entity dde4ca15-7054-52aa-b829-17380091a80f {start_interpolation:0,transformation:{translation:[-0.18f,2.23f,-0.181f],left_rotation:[-0.4363f,-0.5081f,-0.1901f,0.7179f]}}
data merge entity f4c9c580-42de-5f18-958e-fe8f13f48db0 {start_interpolation:0,transformation:{translation:[0.095f,1.741f,-0.286f],left_rotation:[-0.3762f,0.0475f,0.0795f,0.9219f]}}
data merge entity 593cd5be-38e3-598f-a4f4-75287916d917 {start_interpolation:0,transformation:{translation:[-0.095f,1.741f,-0.286f],left_rotation:[-0.3762f,-0.0475f,-0.0795f,0.9219f]}}
data merge entity b93e033a-5262-5632-b8ab-3de10d1c99fe {start_interpolation:0,transformation:{translation:[0.175f,1.431f,0.016f],left_rotation:[0.2501f,0.0037f,0.0144f,0.9681f]}}
data merge entity e73b8616-4bc3-571b-bb40-c31cce9d3a8c {start_interpolation:0,transformation:{translation:[-0.175f,1.431f,0.016f],left_rotation:[0.2501f,-0.0037f,-0.0144f,0.9681f]}}
