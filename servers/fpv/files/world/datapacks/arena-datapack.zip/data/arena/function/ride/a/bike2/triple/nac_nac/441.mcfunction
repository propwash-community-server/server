data merge entity 7f895ae6-3a84-58c6-84f5-016612fdd486 {start_interpolation:0,transformation:{translation:[0.045f,1.707f,-0.403f],left_rotation:[0.2355f,0.1649f,-0.0151f,0.9577f]}}
data merge entity d5b82b8d-86e1-5276-8680-ed7a08615c7a {start_interpolation:0,transformation:{translation:[0.265f,2.133f,-0.251f],left_rotation:[0.3749f,0.1712f,-0.182f,0.8928f]}}
data merge entity a4c123d3-dfeb-5763-b680-e521fb79538b {start_interpolation:0,transformation:{translation:[-0.075f,2.116f,-0.135f],left_rotation:[0.3859f,-0.365f,0.0778f,0.8437f]}}
data merge entity 14895439-b1c6-5868-83ed-85b5ca16af52 {start_interpolation:0,transformation:{translation:[0.131f,1.685f,-0.447f],left_rotation:[-0.4349f,0.1476f,0.0818f,0.8845f]}}
data merge entity ed503232-ebe9-57f4-8f88-a4efe27a7f4d {start_interpolation:0,transformation:{translation:[-0.048f,1.676f,-0.385f],left_rotation:[0.1606f,-0.7665f,-0.4666f,0.4111f]}}
data merge entity 75e3c547-3dab-50d7-a8aa-ffff4a07edfb {start_interpolation:0,transformation:{translation:[0.252f,1.417f,-0.119f],left_rotation:[0.1782f,-0.0211f,-0.0589f,0.982f]}}
data merge entity b4028d78-85e3-5bdd-b8d1-be173b14689d {start_interpolation:0,transformation:{translation:[-0.109f,1.45f,-0.758f],left_rotation:[0.4113f,-0.8261f,0.3545f,0.1508f]}}
