data merge entity 11ae4677-4219-56c2-add0-4c64d57ac56a {start_interpolation:0,transformation:{translation:[-0.007f,1.823f,0.187f],left_rotation:[0.5202f,-0.0257f,-0.0024f,0.8536f]}}
data merge entity 7d2a9e32-11f2-50e1-9212-e206c5741830 {start_interpolation:0,transformation:{translation:[0.162f,2.033f,0.612f],left_rotation:[0.5963f,0.2977f,-0.0578f,0.7433f],scale:[1f,1f,1.007f]}}
data merge entity dde4ca15-7054-52aa-b829-17380091a80f {start_interpolation:0,transformation:{translation:[-0.198f,2.044f,0.597f],left_rotation:[0.5972f,-0.2699f,0.0859f,0.7505f]}}
data merge entity f4c9c580-42de-5f18-958e-fe8f13f48db0 {start_interpolation:0,transformation:{translation:[0.088f,1.806f,0.164f],left_rotation:[-0.1462f,0.1057f,0.1147f,0.9769f]}}
data merge entity 593cd5be-38e3-598f-a4f4-75287916d917 {start_interpolation:0,transformation:{translation:[-0.101f,1.812f,0.156f],left_rotation:[-0.1446f,-0.1092f,-0.1093f,0.9774f]}}
data merge entity b93e033a-5262-5632-b8ab-3de10d1c99fe {start_interpolation:0,transformation:{translation:[0.201f,1.396f,0.279f],left_rotation:[0.3745f,0.02f,-0.0076f,0.927f]}}
data merge entity e73b8616-4bc3-571b-bb40-c31cce9d3a8c {start_interpolation:0,transformation:{translation:[-0.209f,1.401f,0.27f],left_rotation:[0.3654f,0.0005f,0.019f,0.9307f]}}
