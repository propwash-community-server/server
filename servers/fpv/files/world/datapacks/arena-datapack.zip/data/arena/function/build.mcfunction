forceload add ~ ~
kill @e[type=minecraft:marker,tag=arena.builder]
summon minecraft:marker ~ ~ ~ {Tags:["arena","arena.builder"]}
forceload add -96 -64 31 63
forceload add 32 -64 95 63
tellraw @s {"text":"Building PROPWASH ARENA in this world …","color":"yellow"}
schedule function arena:build/step0 100t
