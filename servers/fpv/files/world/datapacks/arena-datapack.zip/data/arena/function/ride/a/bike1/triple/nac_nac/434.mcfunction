data merge entity 11ae4677-4219-56c2-add0-4c64d57ac56a {start_interpolation:0,transformation:{translation:[-0.048f,1.765f,0.114f],left_rotation:[0.4288f,-0.1758f,-0.0224f,0.8858f]}}
data merge entity 7d2a9e32-11f2-50e1-9212-e206c5741830 {start_interpolation:0,transformation:{translation:[0.069f,2.027f,0.528f],left_rotation:[0.5545f,0.3795f,0.0067f,0.7406f]}}
data merge entity dde4ca15-7054-52aa-b829-17380091a80f {start_interpolation:0,transformation:{translation:[-0.269f,2.096f,0.423f],left_rotation:[0.554f,-0.2019f,0.1436f,0.7948f]}}
data merge entity f4c9c580-42de-5f18-958e-fe8f13f48db0 {start_interpolation:0,transformation:{translation:[0.045f,1.728f,0.119f],left_rotation:[0.4198f,0.5943f,0.4227f,0.5403f]}}
data merge entity 593cd5be-38e3-598f-a4f4-75287916d917 {start_interpolation:0,transformation:{translation:[-0.134f,1.764f,0.064f],left_rotation:[-0.2411f,-0.128f,-0.1119f,0.9555f]}}
data merge entity b93e033a-5262-5632-b8ab-3de10d1c99fe {start_interpolation:0,transformation:{translation:[0.026f,1.6f,-0.301f],left_rotation:[0.675f,0.7198f,-0.117f,0.1123f]}}
data merge entity e73b8616-4bc3-571b-bb40-c31cce9d3a8c {start_interpolation:0,transformation:{translation:[-0.255f,1.386f,0.254f],left_rotation:[0.3856f,0.0089f,0.0653f,0.9203f]}}
