data merge entity 11ae4677-4219-56c2-add0-4c64d57ac56a {start_interpolation:0,transformation:{translation:[-0.05f,1.767f,-0.011f],left_rotation:[0.3791f,-0.1849f,-0.0145f,0.9066f]}}
data merge entity 7d2a9e32-11f2-50e1-9212-e206c5741830 {start_interpolation:0,transformation:{translation:[0.064f,2.071f,0.373f],left_rotation:[0.5143f,0.3839f,-0.0095f,0.7669f]}}
data merge entity dde4ca15-7054-52aa-b829-17380091a80f {start_interpolation:0,transformation:{translation:[-0.271f,2.131f,0.256f],left_rotation:[0.5107f,-0.1913f,0.1551f,0.8238f]}}
data merge entity f4c9c580-42de-5f18-958e-fe8f13f48db0 {start_interpolation:0,transformation:{translation:[0.042f,1.729f,-0.001f],left_rotation:[0.5617f,0.5885f,0.2112f,0.5417f]}}
data merge entity 593cd5be-38e3-598f-a4f4-75287916d917 {start_interpolation:0,transformation:{translation:[-0.135f,1.761f,-0.063f],left_rotation:[-0.2931f,-0.1345f,-0.1054f,0.9407f]}}
data merge entity b93e033a-5262-5632-b8ab-3de10d1c99fe {start_interpolation:0,transformation:{translation:[-0.148f,1.606f,-0.378f],left_rotation:[0.7446f,0.6209f,-0.074f,0.2336f]}}
data merge entity e73b8616-4bc3-571b-bb40-c31cce9d3a8c {start_interpolation:0,transformation:{translation:[-0.257f,1.406f,0.168f],left_rotation:[0.3396f,0.013f,0.0671f,0.9381f]}}
