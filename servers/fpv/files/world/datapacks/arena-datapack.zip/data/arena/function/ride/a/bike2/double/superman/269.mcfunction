data merge entity 7f895ae6-3a84-58c6-84f5-016612fdd486 {start_interpolation:0,transformation:{translation:[0f,2.021f,-0.114f],left_rotation:[0.7431f,0f,0f,0.6692f]}}
data merge entity d5b82b8d-86e1-5276-8680-ed7a08615c7a {start_interpolation:0,transformation:{translation:[0.18f,1.972f,0.353f],left_rotation:[0.4413f,0.1372f,0.095f,0.8817f],scale:[1f,1f,1.044f]}}
data merge entity a4c123d3-dfeb-5763-b680-e521fb79538b {start_interpolation:0,transformation:{translation:[-0.18f,1.972f,0.353f],left_rotation:[0.4413f,-0.1372f,-0.095f,0.8817f],scale:[1f,1f,1.044f]}}
data merge entity 14895439-b1c6-5868-83ed-85b5ca16af52 {start_interpolation:0,transformation:{translation:[0.095f,2.024f,-0.144f],left_rotation:[0.096f,-0.0339f,0.1079f,0.9889f]}}
data merge entity ed503232-ebe9-57f4-8f88-a4efe27a7f4d {start_interpolation:0,transformation:{translation:[-0.095f,2.024f,-0.144f],left_rotation:[0.096f,0.0339f,-0.1079f,0.9889f]}}
data merge entity 75e3c547-3dab-50d7-a8aa-ffff4a07edfb {start_interpolation:0,transformation:{translation:[0.192f,1.602f,-0.225f],left_rotation:[0.892f,0.0746f,0.0868f,0.4374f]}}
data merge entity b4028d78-85e3-5bdd-b8d1-be173b14689d {start_interpolation:0,transformation:{translation:[-0.192f,1.602f,-0.225f],left_rotation:[0.892f,-0.0746f,-0.0868f,0.4374f]}}
