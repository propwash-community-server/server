data merge entity 11ae4677-4219-56c2-add0-4c64d57ac56a {start_interpolation:0,transformation:{translation:[-0.006f,1.781f,-0.374f],left_rotation:[0.323f,-0.0221f,0.0028f,0.9461f]}}
data merge entity 7d2a9e32-11f2-50e1-9212-e206c5741830 {start_interpolation:0,transformation:{translation:[0.164f,2.151f,-0.079f],left_rotation:[0.4187f,0.2747f,-0.1217f,0.857f],scale:[1f,1f,1.006f]}}
data merge entity dde4ca15-7054-52aa-b829-17380091a80f {start_interpolation:0,transformation:{translation:[-0.195f,2.154f,-0.095f],left_rotation:[0.4181f,-0.2459f,0.14f,0.8632f]}}
data merge entity f4c9c580-42de-5f18-958e-fe8f13f48db0 {start_interpolation:0,transformation:{translation:[0.089f,1.756f,-0.389f],left_rotation:[-0.3564f,0.1284f,0.0885f,0.9212f]}}
data merge entity 593cd5be-38e3-598f-a4f4-75287916d917 {start_interpolation:0,transformation:{translation:[-0.101f,1.758f,-0.397f],left_rotation:[-0.3552f,-0.1302f,-0.0832f,0.9219f]}}
data merge entity b93e033a-5262-5632-b8ab-3de10d1c99fe {start_interpolation:0,transformation:{translation:[0.201f,1.435f,-0.11f],left_rotation:[0.1614f,0.0148f,-0.0122f,0.9867f]}}
data merge entity e73b8616-4bc3-571b-bb40-c31cce9d3a8c {start_interpolation:0,transformation:{translation:[-0.209f,1.435f,-0.118f],left_rotation:[0.153f,0.0045f,0.018f,0.988f]}}
