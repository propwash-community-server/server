data merge entity 11ae4677-4219-56c2-add0-4c64d57ac56a {start_interpolation:0,transformation:{translation:[-0.029f,1.729f,-0.417f],left_rotation:[0.2611f,-0.1035f,0.012f,0.9597f]}}
data merge entity 7d2a9e32-11f2-50e1-9212-e206c5741830 {start_interpolation:0,transformation:{translation:[0.111f,2.129f,-0.145f],left_rotation:[0.3916f,0.3261f,-0.0985f,0.8547f],scale:[1f,1f,0.994f]}}
data merge entity dde4ca15-7054-52aa-b829-17380091a80f {start_interpolation:0,transformation:{translation:[-0.241f,2.141f,-0.219f],left_rotation:[0.3857f,-0.1978f,0.1713f,0.8847f],scale:[1f,1f,1.002f]}}
data merge entity f4c9c580-42de-5f18-958e-fe8f13f48db0 {start_interpolation:0,transformation:{translation:[0.067f,1.7f,-0.412f],left_rotation:[-0.0623f,0.9621f,0.2331f,0.1267f]}}
data merge entity 593cd5be-38e3-598f-a4f4-75287916d917 {start_interpolation:0,transformation:{translation:[-0.119f,1.706f,-0.451f],left_rotation:[-0.4138f,-0.1411f,-0.0807f,0.8957f]}}
data merge entity b93e033a-5262-5632-b8ab-3de10d1c99fe {start_interpolation:0,transformation:{translation:[0.145f,1.312f,-0.602f],left_rotation:[-0.1117f,0.8064f,-0.3547f,0.4599f]}}
data merge entity e73b8616-4bc3-571b-bb40-c31cce9d3a8c {start_interpolation:0,transformation:{translation:[-0.234f,1.423f,-0.135f],left_rotation:[0.1595f,0.0137f,0.0421f,0.9862f]}}
