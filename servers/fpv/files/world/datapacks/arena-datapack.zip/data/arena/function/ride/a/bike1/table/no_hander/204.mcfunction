data merge entity 11ae4677-4219-56c2-add0-4c64d57ac56a {start_interpolation:0,transformation:{translation:[0f,1.81f,0.046f],left_rotation:[0.2861f,0f,0f,0.9582f]}}
data merge entity 7d2a9e32-11f2-50e1-9212-e206c5741830 {start_interpolation:0,transformation:{translation:[0.18f,2.203f,0.304f],left_rotation:[-0.0714f,0.437f,0.0896f,0.8921f],scale:[1f,1f,0.7f]}}
data merge entity dde4ca15-7054-52aa-b829-17380091a80f {start_interpolation:0,transformation:{translation:[-0.18f,2.203f,0.304f],left_rotation:[-0.0714f,-0.437f,-0.0896f,0.8921f],scale:[1f,1f,0.7f]}}
data merge entity f4c9c580-42de-5f18-958e-fe8f13f48db0 {start_interpolation:0,transformation:{translation:[0.095f,1.785f,0.03f],left_rotation:[-0.2413f,0.0512f,0.0898f,0.9649f]}}
data merge entity 593cd5be-38e3-598f-a4f4-75287916d917 {start_interpolation:0,transformation:{translation:[-0.095f,1.785f,0.03f],left_rotation:[-0.2413f,-0.0512f,-0.0898f,0.9649f]}}
data merge entity b93e033a-5262-5632-b8ab-3de10d1c99fe {start_interpolation:0,transformation:{translation:[0.182f,1.403f,0.23f],left_rotation:[0.362f,0.0009f,0.0078f,0.9321f]}}
data merge entity e73b8616-4bc3-571b-bb40-c31cce9d3a8c {start_interpolation:0,transformation:{translation:[-0.182f,1.403f,0.23f],left_rotation:[0.362f,-0.0009f,-0.0078f,0.9321f]}}
