data merge entity 7f895ae6-3a84-58c6-84f5-016612fdd486 {start_interpolation:0,transformation:{translation:[0f,1.784f,-0.379f],left_rotation:[0.3003f,0f,0f,0.9538f]}}
data merge entity d5b82b8d-86e1-5276-8680-ed7a08615c7a {start_interpolation:0,transformation:{translation:[0.18f,2.17f,-0.11f],left_rotation:[0.383f,0.2651f,-0.1637f,0.8696f],scale:[1f,1f,1.027f]}}
data merge entity a4c123d3-dfeb-5763-b680-e521fb79538b {start_interpolation:0,transformation:{translation:[-0.18f,2.17f,-0.11f],left_rotation:[0.383f,-0.2651f,0.1637f,0.8696f],scale:[1f,1f,1.027f]}}
data merge entity 14895439-b1c6-5868-83ed-85b5ca16af52 {start_interpolation:0,transformation:{translation:[0.095f,1.76f,-0.396f],left_rotation:[-0.3538f,0.1176f,0.0832f,0.9241f]}}
data merge entity ed503232-ebe9-57f4-8f88-a4efe27a7f4d {start_interpolation:0,transformation:{translation:[-0.095f,1.76f,-0.396f],left_rotation:[-0.3538f,-0.1176f,-0.0832f,0.9241f]}}
data merge entity 75e3c547-3dab-50d7-a8aa-ffff4a07edfb {start_interpolation:0,transformation:{translation:[0.199f,1.436f,-0.117f],left_rotation:[0.1528f,-0.0022f,-0.0089f,0.9882f]}}
data merge entity b4028d78-85e3-5bdd-b8d1-be173b14689d {start_interpolation:0,transformation:{translation:[-0.199f,1.436f,-0.117f],left_rotation:[0.1528f,0.0022f,0.0089f,0.9882f]}}
