data merge entity 11ae4677-4219-56c2-add0-4c64d57ac56a {start_interpolation:0,transformation:{translation:[-0.01f,1.805f,0.264f],left_rotation:[0.5424f,-0.0341f,-0.0044f,0.8394f]}}
data merge entity 7d2a9e32-11f2-50e1-9212-e206c5741830 {start_interpolation:0,transformation:{translation:[0.156f,1.99f,0.702f],left_rotation:[0.618f,0.3041f,-0.0438f,0.7237f],scale:[1f,1f,1.005f]}}
data merge entity dde4ca15-7054-52aa-b829-17380091a80f {start_interpolation:0,transformation:{translation:[-0.203f,2.006f,0.683f],left_rotation:[0.6194f,-0.2683f,0.082f,0.7333f]}}
data merge entity f4c9c580-42de-5f18-958e-fe8f13f48db0 {start_interpolation:0,transformation:{translation:[0.086f,1.788f,0.242f],left_rotation:[-0.1218f,0.1021f,0.1201f,0.98f]}}
data merge entity 593cd5be-38e3-598f-a4f4-75287916d917 {start_interpolation:0,transformation:{translation:[-0.104f,1.797f,0.232f],left_rotation:[-0.1193f,-0.1067f,-0.1129f,0.9806f]}}
data merge entity b93e033a-5262-5632-b8ab-3de10d1c99fe {start_interpolation:0,transformation:{translation:[0.201f,1.374f,0.336f],left_rotation:[0.4092f,0.0272f,-0.0057f,0.912f]}}
data merge entity e73b8616-4bc3-571b-bb40-c31cce9d3a8c {start_interpolation:0,transformation:{translation:[-0.212f,1.381f,0.324f],left_rotation:[0.3973f,0f,0.0219f,0.9174f]}}
