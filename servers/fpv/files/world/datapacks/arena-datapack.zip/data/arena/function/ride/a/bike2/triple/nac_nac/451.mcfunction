data merge entity 7f895ae6-3a84-58c6-84f5-016612fdd486 {start_interpolation:0,transformation:{translation:[0.05f,1.765f,0.062f],left_rotation:[0.4063f,0.1844f,0.02f,0.8947f]}}
data merge entity d5b82b8d-86e1-5276-8680-ed7a08615c7a {start_interpolation:0,transformation:{translation:[0.271f,2.113f,0.351f],left_rotation:[0.5353f,0.1959f,-0.1492f,0.808f]}}
data merge entity a4c123d3-dfeb-5763-b680-e521fb79538b {start_interpolation:0,transformation:{translation:[-0.064f,2.046f,0.464f],left_rotation:[0.5371f,-0.384f,-0.0021f,0.751f]}}
data merge entity 14895439-b1c6-5868-83ed-85b5ca16af52 {start_interpolation:0,transformation:{translation:[0.135f,1.763f,0.01f],left_rotation:[-0.2646f,0.1312f,0.1095f,0.9491f]}}
data merge entity ed503232-ebe9-57f4-8f88-a4efe27a7f4d {start_interpolation:0,transformation:{translation:[-0.042f,1.727f,0.07f],left_rotation:[0.5778f,-0.5819f,-0.2289f,0.5245f]}}
data merge entity 75e3c547-3dab-50d7-a8aa-ffff4a07edfb {start_interpolation:0,transformation:{translation:[0.257f,1.395f,0.219f],left_rotation:[0.3677f,-0.011f,-0.0674f,0.9274f]}}
data merge entity b4028d78-85e3-5bdd-b8d1-be173b14689d {start_interpolation:0,transformation:{translation:[0.148f,1.627f,-0.314f],left_rotation:[0.7513f,-0.6228f,0.0552f,0.2111f]}}
