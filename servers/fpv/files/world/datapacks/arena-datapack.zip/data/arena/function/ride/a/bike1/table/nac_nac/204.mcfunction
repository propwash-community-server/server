data merge entity 11ae4677-4219-56c2-add0-4c64d57ac56a {start_interpolation:0,transformation:{translation:[-0.036f,1.785f,0.1f],left_rotation:[0.4425f,-0.1322f,-0.014f,0.8868f]}}
data merge entity 7d2a9e32-11f2-50e1-9212-e206c5741830 {start_interpolation:0,transformation:{translation:[0.094f,2.045f,0.511f],left_rotation:[0.5572f,0.3556f,-0.0155f,0.7502f]}}
data merge entity dde4ca15-7054-52aa-b829-17380091a80f {start_interpolation:0,transformation:{translation:[-0.253f,2.096f,0.431f],left_rotation:[0.5572f,-0.2176f,0.1353f,0.7898f]}}
data merge entity f4c9c580-42de-5f18-958e-fe8f13f48db0 {start_interpolation:0,transformation:{translation:[0.058f,1.753f,0.098f],left_rotation:[0.0531f,0.8363f,0.5455f,0.0128f]}}
data merge entity 593cd5be-38e3-598f-a4f4-75287916d917 {start_interpolation:0,transformation:{translation:[-0.125f,1.78f,0.055f],left_rotation:[-0.2295f,-0.1242f,-0.1092f,0.9592f]}}
data merge entity b93e033a-5262-5632-b8ab-3de10d1c99fe {start_interpolation:0,transformation:{translation:[0.025f,1.577f,-0.305f],left_rotation:[-0.0463f,-0.9668f,0.2489f,0.0347f]}}
data merge entity e73b8616-4bc3-571b-bb40-c31cce9d3a8c {start_interpolation:0,transformation:{translation:[-0.242f,1.397f,0.237f],left_rotation:[0.3691f,0.0063f,0.0524f,0.9279f]}}
