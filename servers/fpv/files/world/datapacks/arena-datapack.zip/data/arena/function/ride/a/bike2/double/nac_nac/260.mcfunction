data merge entity 7f895ae6-3a84-58c6-84f5-016612fdd486 {start_interpolation:0,transformation:{translation:[0.05f,1.744f,-0.231f],left_rotation:[0.2951f,0.1854f,-0.0024f,0.9373f]}}
data merge entity d5b82b8d-86e1-5276-8680-ed7a08615c7a {start_interpolation:0,transformation:{translation:[0.271f,2.151f,-0.035f],left_rotation:[0.4336f,0.1764f,-0.1718f,0.8668f]}}
data merge entity a4c123d3-dfeb-5763-b680-e521fb79538b {start_interpolation:0,transformation:{translation:[-0.064f,2.114f,0.091f],left_rotation:[0.4424f,-0.3814f,0.0443f,0.8105f]}}
data merge entity 14895439-b1c6-5868-83ed-85b5ca16af52 {start_interpolation:0,transformation:{translation:[0.135f,1.73f,-0.281f],left_rotation:[-0.3774f,0.1435f,0.0928f,0.9101f]}}
data merge entity ed503232-ebe9-57f4-8f88-a4efe27a7f4d {start_interpolation:0,transformation:{translation:[-0.042f,1.71f,-0.215f],left_rotation:[0.5101f,-0.6053f,-0.1568f,0.5906f]}}
data merge entity 75e3c547-3dab-50d7-a8aa-ffff4a07edfb {start_interpolation:0,transformation:{translation:[0.257f,1.423f,0.01f],left_rotation:[0.2528f,-0.019f,-0.0656f,0.9651f]}}
data merge entity b4028d78-85e3-5bdd-b8d1-be173b14689d {start_interpolation:0,transformation:{translation:[0.148f,1.52f,-0.563f],left_rotation:[0.7203f,-0.6116f,0.1302f,0.3004f]}}
