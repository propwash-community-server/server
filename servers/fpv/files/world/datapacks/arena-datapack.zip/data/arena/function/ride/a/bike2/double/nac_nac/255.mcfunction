data merge entity 7f895ae6-3a84-58c6-84f5-016612fdd486 {start_interpolation:0,transformation:{left_rotation:[0.2692f,0.0091f,-0.0018f,0.963f]}}
data merge entity d5b82b8d-86e1-5276-8680-ed7a08615c7a {start_interpolation:0,transformation:{translation:[0.187f,2.126f,-0.289f],left_rotation:[0.3606f,0.2425f,-0.1467f,0.8886f]}}
data merge entity a4c123d3-dfeb-5763-b680-e521fb79538b {start_interpolation:0,transformation:{translation:[-0.173f,2.126f,-0.283f],left_rotation:[0.361f,-0.2551f,0.1398f,0.886f]}}
data merge entity 14895439-b1c6-5868-83ed-85b5ca16af52 {start_interpolation:0,transformation:{left_rotation:[-0.4132f,0.1344f,0.0761f,0.8974f]}}
data merge entity ed503232-ebe9-57f4-8f88-a4efe27a7f4d {start_interpolation:0,transformation:{translation:[-0.093f,1.698f,-0.543f],left_rotation:[-0.4137f,-0.1338f,-0.0783f,0.8971f]}}
data merge entity 75e3c547-3dab-50d7-a8aa-ffff4a07edfb {start_interpolation:0,transformation:{left_rotation:[0.088f,-0.0047f,-0.0153f,0.996f]}}
data merge entity b4028d78-85e3-5bdd-b8d1-be173b14689d {start_interpolation:0,transformation:{translation:[-0.203f,1.414f,-0.226f],left_rotation:[0.0915f,-0.0033f,0.0135f,0.9957f]}}
