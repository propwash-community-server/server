data merge entity 11ae4677-4219-56c2-add0-4c64d57ac56a {start_interpolation:0,transformation:{translation:[-0.05f,1.731f,-0.293f],left_rotation:[0.2708f,-0.1853f,0.0072f,0.9446f]}}
data merge entity 7d2a9e32-11f2-50e1-9212-e206c5741830 {start_interpolation:0,transformation:{translation:[0.064f,2.116f,0.01f],left_rotation:[0.4213f,0.3802f,-0.0542f,0.8216f]}}
data merge entity dde4ca15-7054-52aa-b829-17380091a80f {start_interpolation:0,transformation:{translation:[-0.271f,2.148f,-0.117f],left_rotation:[0.4111f,-0.1719f,0.1763f,0.8777f]}}
data merge entity f4c9c580-42de-5f18-958e-fe8f13f48db0 {start_interpolation:0,transformation:{translation:[0.042f,1.697f,-0.274f],left_rotation:[0.4947f,0.6091f,0.1411f,0.6035f]}}
data merge entity 593cd5be-38e3-598f-a4f4-75287916d917 {start_interpolation:0,transformation:{translation:[-0.135f,1.713f,-0.341f],left_rotation:[-0.4008f,-0.1459f,-0.089f,0.9001f]}}
data merge entity b93e033a-5262-5632-b8ab-3de10d1c99fe {start_interpolation:0,transformation:{translation:[-0.148f,1.49f,-0.613f],left_rotation:[0.7123f,0.608f,-0.1459f,0.3189f]}}
data merge entity e73b8616-4bc3-571b-bb40-c31cce9d3a8c {start_interpolation:0,transformation:{translation:[-0.257f,1.422f,-0.035f],left_rotation:[0.2279f,0.0207f,0.0651f,0.9713f]}}
