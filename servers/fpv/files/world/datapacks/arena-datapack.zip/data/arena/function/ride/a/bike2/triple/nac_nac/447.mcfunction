data merge entity 7f895ae6-3a84-58c6-84f5-016612fdd486 {start_interpolation:0,transformation:{translation:[0.05f,1.761f,-0.12f],left_rotation:[0.3381f,0.1853f,0.0062f,0.9227f]}}
data merge entity d5b82b8d-86e1-5276-8680-ed7a08615c7a {start_interpolation:0,transformation:{translation:[0.271f,2.148f,0.114f],left_rotation:[0.4733f,0.1841f,-0.1635f,0.8458f]}}
data merge entity a4c123d3-dfeb-5763-b680-e521fb79538b {start_interpolation:0,transformation:{translation:[-0.064f,2.099f,0.235f],left_rotation:[0.4794f,-0.3831f,0.0267f,0.7891f]}}
data merge entity 14895439-b1c6-5868-83ed-85b5ca16af52 {start_interpolation:0,transformation:{translation:[0.135f,1.75f,-0.171f],left_rotation:[-0.3349f,0.1391f,0.0993f,0.9266f]}}
data merge entity ed503232-ebe9-57f4-8f88-a4efe27a7f4d {start_interpolation:0,transformation:{translation:[-0.042f,1.725f,-0.107f],left_rotation:[0.5369f,-0.5974f,-0.1846f,0.5663f]}}
data merge entity 75e3c547-3dab-50d7-a8aa-ffff4a07edfb {start_interpolation:0,transformation:{translation:[0.257f,1.418f,0.09f],left_rotation:[0.2972f,-0.016f,-0.0664f,0.9524f]}}
data merge entity b4028d78-85e3-5bdd-b8d1-be173b14689d {start_interpolation:0,transformation:{translation:[0.148f,1.568f,-0.471f],left_rotation:[0.7334f,-0.617f,0.1017f,0.2668f]}}
