data merge entity 7f895ae6-3a84-58c6-84f5-016612fdd486 {start_interpolation:0,transformation:{translation:[0f,1.81f,0.144f],left_rotation:[0.363f,0f,0f,0.9318f]}}
data merge entity d5b82b8d-86e1-5276-8680-ed7a08615c7a {start_interpolation:0,transformation:{translation:[0.18f,2.156f,0.462f],left_rotation:[0.2303f,0.3901f,-0.0622f,0.8893f],scale:[1f,1f,0.7f]}}
data merge entity a4c123d3-dfeb-5763-b680-e521fb79538b {start_interpolation:0,transformation:{translation:[-0.18f,2.156f,0.462f],left_rotation:[0.2303f,-0.3901f,0.0622f,0.8893f],scale:[1f,1f,0.7f]}}
data merge entity 14895439-b1c6-5868-83ed-85b5ca16af52 {start_interpolation:0,transformation:{translation:[0.095f,1.788f,0.124f],left_rotation:[-0.1939f,0.0592f,0.0955f,0.9746f]}}
data merge entity ed503232-ebe9-57f4-8f88-a4efe27a7f4d {start_interpolation:0,transformation:{translation:[-0.095f,1.788f,0.124f],left_rotation:[-0.1939f,-0.0592f,-0.0955f,0.9746f]}}
data merge entity 75e3c547-3dab-50d7-a8aa-ffff4a07edfb {start_interpolation:0,transformation:{translation:[0.187f,1.389f,0.285f],left_rotation:[0.3877f,0.0002f,0.0029f,0.9218f]}}
data merge entity b4028d78-85e3-5bdd-b8d1-be173b14689d {start_interpolation:0,transformation:{translation:[-0.187f,1.389f,0.285f],left_rotation:[0.3877f,-0.0002f,-0.0029f,0.9218f]}}
