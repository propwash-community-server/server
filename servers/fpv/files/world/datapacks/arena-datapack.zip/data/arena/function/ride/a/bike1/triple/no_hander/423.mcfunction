data merge entity 11ae4677-4219-56c2-add0-4c64d57ac56a {start_interpolation:0,transformation:{translation:[0f,1.715f,-0.461f],left_rotation:[0.0347f,0f,0f,0.9994f]}}
data merge entity 7d2a9e32-11f2-50e1-9212-e206c5741830 {start_interpolation:0,transformation:{translation:[0.18f,2.184f,-0.428f],left_rotation:[-0.4747f,0.5163f,0.1414f,0.6987f],scale:[1f,1f,0.945f]}}
data merge entity dde4ca15-7054-52aa-b829-17380091a80f {start_interpolation:0,transformation:{translation:[-0.18f,2.184f,-0.428f],left_rotation:[-0.4747f,-0.5163f,-0.1414f,0.6987f],scale:[1f,1f,0.945f]}}
data merge entity f4c9c580-42de-5f18-958e-fe8f13f48db0 {start_interpolation:0,transformation:{translation:[0.095f,1.685f,-0.463f],left_rotation:[-0.444f,0.0549f,0.0759f,0.8911f]}}
data merge entity 593cd5be-38e3-598f-a4f4-75287916d917 {start_interpolation:0,transformation:{translation:[-0.095f,1.685f,-0.463f],left_rotation:[-0.444f,-0.0549f,-0.0759f,0.8911f]}}
data merge entity b93e033a-5262-5632-b8ab-3de10d1c99fe {start_interpolation:0,transformation:{translation:[0.176f,1.423f,-0.118f],left_rotation:[0.1748f,0.0045f,0.0134f,0.9845f]}}
data merge entity e73b8616-4bc3-571b-bb40-c31cce9d3a8c {start_interpolation:0,transformation:{translation:[-0.176f,1.423f,-0.118f],left_rotation:[0.1748f,-0.0045f,-0.0134f,0.9845f]}}
