data merge entity 7f895ae6-3a84-58c6-84f5-016612fdd486 {start_interpolation:0,transformation:{translation:[0f,1.754f,-0.344f],left_rotation:[0.0784f,0f,0f,0.9969f]}}
data merge entity d5b82b8d-86e1-5276-8680-ed7a08615c7a {start_interpolation:0,transformation:{translation:[0.18f,2.218f,-0.27f],left_rotation:[-0.4552f,0.5129f,0.1766f,0.706f]}}
data merge entity a4c123d3-dfeb-5763-b680-e521fb79538b {start_interpolation:0,transformation:{translation:[-0.18f,2.218f,-0.27f],left_rotation:[-0.4552f,-0.5129f,-0.1766f,0.706f]}}
data merge entity 14895439-b1c6-5868-83ed-85b5ca16af52 {start_interpolation:0,transformation:{translation:[0.095f,1.724f,-0.348f],left_rotation:[-0.4006f,0.0496f,0.0782f,0.9116f]}}
data merge entity ed503232-ebe9-57f4-8f88-a4efe27a7f4d {start_interpolation:0,transformation:{translation:[-0.095f,1.724f,-0.348f],left_rotation:[-0.4006f,-0.0496f,-0.0782f,0.9116f]}}
data merge entity 75e3c547-3dab-50d7-a8aa-ffff4a07edfb {start_interpolation:0,transformation:{translation:[0.175f,1.431f,-0.03f],left_rotation:[0.2244f,0.0041f,0.0143f,0.9744f]}}
data merge entity b4028d78-85e3-5bdd-b8d1-be173b14689d {start_interpolation:0,transformation:{translation:[-0.175f,1.431f,-0.03f],left_rotation:[0.2244f,-0.0041f,-0.0143f,0.9744f]}}
