data merge entity 11ae4677-4219-56c2-add0-4c64d57ac56a {start_interpolation:0,transformation:{translation:[0f,1.91f,-0.619f],left_rotation:[0.643f,0f,0f,0.7659f]}}
data merge entity 7d2a9e32-11f2-50e1-9212-e206c5741830 {start_interpolation:0,transformation:{translation:[0.18f,1.992f,-0.156f],left_rotation:[0.264f,0.1468f,0.0751f,0.9503f]}}
data merge entity dde4ca15-7054-52aa-b829-17380091a80f {start_interpolation:0,transformation:{translation:[-0.18f,1.992f,-0.156f],left_rotation:[0.264f,-0.1468f,-0.0751f,0.9503f]}}
data merge entity f4c9c580-42de-5f18-958e-fe8f13f48db0 {start_interpolation:0,transformation:{translation:[0.095f,1.905f,-0.649f],left_rotation:[0.6128f,0.028f,0.1055f,0.7827f]}}
data merge entity 593cd5be-38e3-598f-a4f4-75287916d917 {start_interpolation:0,transformation:{translation:[-0.095f,1.905f,-0.649f],left_rotation:[0.6128f,-0.028f,-0.1055f,0.7827f]}}
data merge entity b93e033a-5262-5632-b8ab-3de10d1c99fe {start_interpolation:0,transformation:{translation:[0.153f,1.805f,-1.073f],left_rotation:[0.808f,0.0566f,0.0933f,0.5789f]}}
data merge entity e73b8616-4bc3-571b-bb40-c31cce9d3a8c {start_interpolation:0,transformation:{translation:[-0.153f,1.805f,-1.073f],left_rotation:[0.808f,-0.0566f,-0.0933f,0.5789f]}}
