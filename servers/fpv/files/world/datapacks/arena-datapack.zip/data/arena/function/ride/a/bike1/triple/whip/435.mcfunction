data merge entity 808323a0-bdef-57da-99dd-aa87a4fc58fa {start_interpolation:0,transformation:{translation:[0.006f,0.55f,0f],left_rotation:[0.1458f,-0.002f,0.0032f,0.9893f]}}
data merge entity 756e3478-b092-536a-a12b-3b4c70f22a96 {start_interpolation:0,transformation:{left_rotation:[-0.6894f,-0.0032f,0.0007f,0.7244f]}}
data merge entity 1ea1e3d2-b16c-5678-aea9-b87ce9a50a74 {start_interpolation:0,transformation:{translation:[0.006f,0.985f,-0.607f],left_rotation:[-0.3841f,-0.0033f,0.0017f,0.9233f]}}
data merge entity 7d2a9e32-11f2-50e1-9212-e206c5741830 {start_interpolation:0,transformation:{scale:[1f,1f,1.01f]}}
data merge entity dde4ca15-7054-52aa-b829-17380091a80f {start_interpolation:0,transformation:{scale:[1f,1f,1.015f]}}
