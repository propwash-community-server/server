data merge entity 7f895ae6-3a84-58c6-84f5-016612fdd486 {start_interpolation:0,transformation:{translation:[0.05f,1.765f,-0.062f],left_rotation:[0.3602f,0.1851f,0.0106f,0.9143f]}}
data merge entity d5b82b8d-86e1-5276-8680-ed7a08615c7a {start_interpolation:0,transformation:{translation:[0.271f,2.14f,0.19f],left_rotation:[0.4935f,0.188f,-0.159f,0.8342f]}}
data merge entity a4c123d3-dfeb-5763-b680-e521fb79538b {start_interpolation:0,transformation:{translation:[-0.064f,2.085f,0.309f],left_rotation:[0.4982f,-0.3836f,0.0174f,0.7774f]}}
data merge entity 14895439-b1c6-5868-83ed-85b5ca16af52 {start_interpolation:0,transformation:{translation:[0.135f,1.757f,-0.113f],left_rotation:[-0.3126f,0.1366f,0.1026f,0.9344f]}}
data merge entity ed503232-ebe9-57f4-8f88-a4efe27a7f4d {start_interpolation:0,transformation:{translation:[-0.042f,1.728f,-0.05f],left_rotation:[0.5504f,-0.5928f,-0.1989f,0.5533f]}}
data merge entity 75e3c547-3dab-50d7-a8aa-ffff4a07edfb {start_interpolation:0,transformation:{translation:[0.257f,1.413f,0.132f],left_rotation:[0.32f,-0.0144f,-0.0668f,0.9449f]}}
data merge entity b4028d78-85e3-5bdd-b8d1-be173b14689d {start_interpolation:0,transformation:{translation:[0.148f,1.59f,-0.422f],left_rotation:[0.7396f,-0.6192f,0.0869f,0.2491f]}}
