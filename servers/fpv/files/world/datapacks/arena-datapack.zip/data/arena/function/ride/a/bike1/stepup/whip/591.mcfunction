data merge entity 808323a0-bdef-57da-99dd-aa87a4fc58fa {start_interpolation:0,transformation:{translation:[0.006f,0.55f,0f],left_rotation:[-0.1203f,-0.0011f,0.0037f,0.9927f]}}
data merge entity 33994f6e-dd4b-5d7f-92cf-ce9664b48c51 {start_interpolation:0,transformation:{left_rotation:[-0.1203f,-0.0006f,0.0033f,0.9927f]}}
data merge entity 908bd8c8-98e0-50e8-a8e5-b3ee5b786a89 {start_interpolation:0,transformation:{left_rotation:[-0.1203f,-0.0006f,0.0033f,0.9927f]}}
data merge entity af1a32b6-de7b-547d-b78d-2e5b0329e97c {start_interpolation:0,transformation:{left_rotation:[-0.1551f,-0.0012f,0.0036f,0.9879f]}}
data merge entity 1ea1e3d2-b16c-5678-aea9-b87ce9a50a74 {start_interpolation:0,transformation:{translation:[0.006f,0.668f,-0.783f],left_rotation:[0.2624f,0.0004f,0.0038f,0.965f]}}
data merge entity e73b8616-4bc3-571b-bb40-c31cce9d3a8c {start_interpolation:0,transformation:{left_rotation:[0.0758f,0.0067f,0.0228f,0.9968f]}}
