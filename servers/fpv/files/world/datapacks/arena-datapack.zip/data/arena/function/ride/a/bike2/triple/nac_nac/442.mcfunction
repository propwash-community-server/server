data merge entity 7f895ae6-3a84-58c6-84f5-016612fdd486 {start_interpolation:0,transformation:{translation:[0.05f,1.714f,-0.353f],left_rotation:[0.2466f,0.1847f,-0.0119f,0.9513f]}}
data merge entity d5b82b8d-86e1-5276-8680-ed7a08615c7a {start_interpolation:0,transformation:{translation:[0.271f,2.139f,-0.199f],left_rotation:[0.3886f,0.1674f,-0.1806f,0.8879f]}}
data merge entity a4c123d3-dfeb-5763-b680-e521fb79538b {start_interpolation:0,transformation:{translation:[-0.064f,2.115f,-0.07f],left_rotation:[0.4002f,-0.3784f,0.064f,0.8322f]}}
data merge entity 14895439-b1c6-5868-83ed-85b5ca16af52 {start_interpolation:0,transformation:{translation:[0.135f,1.695f,-0.401f],left_rotation:[-0.4236f,0.148f,0.0853f,0.8896f]}}
data merge entity ed503232-ebe9-57f4-8f88-a4efe27a7f4d {start_interpolation:0,transformation:{translation:[-0.042f,1.682f,-0.333f],left_rotation:[0.4704f,-0.6145f,-0.1337f,0.6191f]}}
data merge entity 75e3c547-3dab-50d7-a8aa-ffff4a07edfb {start_interpolation:0,transformation:{translation:[0.257f,1.419f,-0.08f],left_rotation:[0.2028f,-0.0223f,-0.0645f,0.9768f]}}
data merge entity b4028d78-85e3-5bdd-b8d1-be173b14689d {start_interpolation:0,transformation:{translation:[0.14f,1.452f,-0.661f],left_rotation:[0.7036f,-0.6063f,0.1665f,0.3311f]}}
