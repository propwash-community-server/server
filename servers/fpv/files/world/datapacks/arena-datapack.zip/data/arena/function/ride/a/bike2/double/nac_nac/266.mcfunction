data merge entity 7f895ae6-3a84-58c6-84f5-016612fdd486 {start_interpolation:0,transformation:{translation:[0.05f,1.764f,0.075f],left_rotation:[0.4109f,0.1842f,0.021f,0.8926f]}}
data merge entity d5b82b8d-86e1-5276-8680-ed7a08615c7a {start_interpolation:0,transformation:{translation:[0.271f,2.109f,0.367f],left_rotation:[0.5395f,0.1966f,-0.1482f,0.8052f]}}
data merge entity a4c123d3-dfeb-5763-b680-e521fb79538b {start_interpolation:0,transformation:{translation:[-0.064f,2.041f,0.479f],left_rotation:[0.541f,-0.384f,-0.0041f,0.7482f]}}
data merge entity 14895439-b1c6-5868-83ed-85b5ca16af52 {start_interpolation:0,transformation:{translation:[0.135f,1.762f,0.023f],left_rotation:[-0.2597f,0.1307f,0.1101f,0.9505f]}}
data merge entity ed503232-ebe9-57f4-8f88-a4efe27a7f4d {start_interpolation:0,transformation:{translation:[-0.042f,1.726f,0.082f],left_rotation:[0.5805f,-0.5807f,-0.2319f,0.5215f]}}
data merge entity 75e3c547-3dab-50d7-a8aa-ffff4a07edfb {start_interpolation:0,transformation:{translation:[0.257f,1.392f,0.228f],left_rotation:[0.3725f,-0.0106f,-0.0675f,0.9255f]}}
data merge entity b4028d78-85e3-5bdd-b8d1-be173b14689d {start_interpolation:0,transformation:{translation:[0.148f,1.63f,-0.303f],left_rotation:[0.7524f,-0.6231f,0.052f,0.2072f]}}
