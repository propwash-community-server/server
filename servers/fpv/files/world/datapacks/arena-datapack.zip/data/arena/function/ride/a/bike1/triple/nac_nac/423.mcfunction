data merge entity 11ae4677-4219-56c2-add0-4c64d57ac56a {start_interpolation:0,transformation:{translation:[-0.047f,1.709f,-0.383f],left_rotation:[0.2388f,-0.1749f,0.014f,0.9551f]}}
data merge entity 7d2a9e32-11f2-50e1-9212-e206c5741830 {start_interpolation:0,transformation:{translation:[0.07f,2.115f,-0.109f],left_rotation:[0.3912f,0.3717f,-0.0718f,0.8389f]}}
data merge entity dde4ca15-7054-52aa-b829-17380091a80f {start_interpolation:0,transformation:{translation:[-0.268f,2.136f,-0.232f],left_rotation:[0.3797f,-0.1688f,0.1817f,0.8912f]}}
data merge entity f4c9c580-42de-5f18-958e-fe8f13f48db0 {start_interpolation:0,transformation:{translation:[0.045f,1.677f,-0.364f],left_rotation:[0.2712f,0.6821f,0.3264f,0.5955f]}}
data merge entity 593cd5be-38e3-598f-a4f4-75287916d917 {start_interpolation:0,transformation:{translation:[-0.133f,1.688f,-0.429f],left_rotation:[-0.4313f,-0.148f,-0.0832f,0.8861f]}}
data merge entity b93e033a-5262-5632-b8ab-3de10d1c99fe {start_interpolation:0,transformation:{translation:[0.053f,1.396f,-0.702f],left_rotation:[0.6112f,0.7035f,-0.2779f,0.2331f]}}
data merge entity e73b8616-4bc3-571b-bb40-c31cce9d3a8c {start_interpolation:0,transformation:{translation:[-0.254f,1.418f,-0.103f],left_rotation:[0.1883f,0.0219f,0.0616f,0.9799f]}}
