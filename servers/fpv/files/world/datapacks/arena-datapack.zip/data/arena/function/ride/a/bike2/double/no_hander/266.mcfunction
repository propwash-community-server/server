data merge entity 7f895ae6-3a84-58c6-84f5-016612fdd486 {start_interpolation:0,transformation:{translation:[0f,1.802f,0.001f],left_rotation:[0.2164f,0f,0f,0.9763f]}}
data merge entity d5b82b8d-86e1-5276-8680-ed7a08615c7a {start_interpolation:0,transformation:{translation:[0.18f,2.228f,0.2f],left_rotation:[-0.3525f,0.4834f,0.2462f,0.7625f]}}
data merge entity a4c123d3-dfeb-5763-b680-e521fb79538b {start_interpolation:0,transformation:{translation:[-0.18f,2.228f,0.2f],left_rotation:[-0.3525f,-0.4834f,-0.2462f,0.7625f]}}
data merge entity 14895439-b1c6-5868-83ed-85b5ca16af52 {start_interpolation:0,transformation:{translation:[0.095f,1.775f,-0.011f],left_rotation:[-0.2698f,0.0382f,0.0843f,0.9585f]}}
data merge entity ed503232-ebe9-57f4-8f88-a4efe27a7f4d {start_interpolation:0,transformation:{translation:[-0.095f,1.775f,-0.011f],left_rotation:[-0.2698f,-0.0382f,-0.0843f,0.9585f]}}
data merge entity 75e3c547-3dab-50d7-a8aa-ffff4a07edfb {start_interpolation:0,transformation:{translation:[0.175f,1.405f,0.214f],left_rotation:[0.3578f,0.0021f,0.0147f,0.9337f]}}
data merge entity b4028d78-85e3-5bdd-b8d1-be173b14689d {start_interpolation:0,transformation:{translation:[-0.175f,1.405f,0.214f],left_rotation:[0.3578f,-0.0021f,-0.0147f,0.9337f]}}
