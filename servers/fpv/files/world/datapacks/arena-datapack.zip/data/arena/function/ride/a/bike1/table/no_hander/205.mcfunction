data merge entity 11ae4677-4219-56c2-add0-4c64d57ac56a {start_interpolation:0,transformation:{translation:[0f,1.823f,0.095f],left_rotation:[0.3895f,0f,0f,0.921f]}}
data merge entity 7d2a9e32-11f2-50e1-9212-e206c5741830 {start_interpolation:0,transformation:{translation:[0.18f,2.151f,0.432f],left_rotation:[0.3901f,0.347f,-0.142f,0.841f],scale:[1f,1f,0.826f]}}
data merge entity dde4ca15-7054-52aa-b829-17380091a80f {start_interpolation:0,transformation:{translation:[-0.18f,2.151f,0.432f],left_rotation:[0.3901f,-0.347f,0.142f,0.841f],scale:[1f,1f,0.826f]}}
data merge entity f4c9c580-42de-5f18-958e-fe8f13f48db0 {start_interpolation:0,transformation:{translation:[0.095f,1.802f,0.073f],left_rotation:[-0.2012f,0.0745f,0.0979f,0.9718f]}}
data merge entity 593cd5be-38e3-598f-a4f4-75287916d917 {start_interpolation:0,transformation:{translation:[-0.095f,1.802f,0.073f],left_rotation:[-0.2012f,-0.0745f,-0.0979f,0.9718f]}}
data merge entity b93e033a-5262-5632-b8ab-3de10d1c99fe {start_interpolation:0,transformation:{translation:[0.192f,1.406f,0.239f],left_rotation:[0.3571f,-0.0001f,-0.0019f,0.9341f]}}
data merge entity e73b8616-4bc3-571b-bb40-c31cce9d3a8c {start_interpolation:0,transformation:{translation:[-0.192f,1.406f,0.239f],left_rotation:[0.3571f,0.0001f,0.0019f,0.9341f]}}
