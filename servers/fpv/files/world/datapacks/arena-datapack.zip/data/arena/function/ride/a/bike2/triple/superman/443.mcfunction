data merge entity 7f895ae6-3a84-58c6-84f5-016612fdd486 {start_interpolation:0,transformation:{translation:[0f,1.848f,-0.74f],left_rotation:[0.6059f,0f,0f,0.7955f]}}
data merge entity d5b82b8d-86e1-5276-8680-ed7a08615c7a {start_interpolation:0,transformation:{translation:[0.18f,1.972f,-0.286f],left_rotation:[0.2216f,0.1504f,0.0681f,0.9611f],scale:[1f,1f,1.065f]}}
data merge entity a4c123d3-dfeb-5763-b680-e521fb79538b {start_interpolation:0,transformation:{translation:[-0.18f,1.972f,-0.286f],left_rotation:[0.2216f,-0.1504f,-0.0681f,0.9611f],scale:[1f,1f,1.065f]}}
data merge entity 14895439-b1c6-5868-83ed-85b5ca16af52 {start_interpolation:0,transformation:{translation:[0.095f,1.84f,-0.769f],left_rotation:[0.5173f,0.0265f,0.1064f,0.8487f]}}
data merge entity ed503232-ebe9-57f4-8f88-a4efe27a7f4d {start_interpolation:0,transformation:{translation:[-0.095f,1.84f,-0.769f],left_rotation:[0.5173f,-0.0265f,-0.1064f,0.8487f]}}
data merge entity 75e3c547-3dab-50d7-a8aa-ffff4a07edfb {start_interpolation:0,transformation:{translation:[0.162f,1.645f,-1.157f],left_rotation:[0.8067f,0.066f,0.0879f,0.5807f]}}
data merge entity b4028d78-85e3-5bdd-b8d1-be173b14689d {start_interpolation:0,transformation:{translation:[-0.162f,1.645f,-1.157f],left_rotation:[0.8067f,-0.066f,-0.0879f,0.5807f]}}
