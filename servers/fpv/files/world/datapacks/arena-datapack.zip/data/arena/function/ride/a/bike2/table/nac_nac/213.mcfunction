data merge entity 7f895ae6-3a84-58c6-84f5-016612fdd486 {start_interpolation:0,transformation:{translation:[0.041f,1.76f,-0.224f],left_rotation:[0.3135f,0.1522f,-0.003f,0.9373f]}}
data merge entity d5b82b8d-86e1-5276-8680-ed7a08615c7a {start_interpolation:0,transformation:{translation:[0.26f,2.154f,0.001f],left_rotation:[0.4446f,0.1898f,-0.1663f,0.8594f]}}
data merge entity a4c123d3-dfeb-5763-b680-e521fb79538b {start_interpolation:0,transformation:{translation:[-0.083f,2.121f,0.104f],left_rotation:[0.4509f,-0.362f,0.0548f,0.814f],scale:[1f,1f,0.99f]}}
data merge entity 14895439-b1c6-5868-83ed-85b5ca16af52 {start_interpolation:0,transformation:{translation:[0.129f,1.744f,-0.268f],left_rotation:[-0.3612f,0.1395f,0.0925f,0.9173f]}}
data merge entity ed503232-ebe9-57f4-8f88-a4efe27a7f4d {start_interpolation:0,transformation:{translation:[-0.052f,1.727f,-0.214f],left_rotation:[0.113f,-0.8171f,-0.5452f,0.1492f]}}
data merge entity 75e3c547-3dab-50d7-a8aa-ffff4a07edfb {start_interpolation:0,transformation:{translation:[0.248f,1.427f,0.012f],left_rotation:[0.249f,-0.0151f,-0.0566f,0.9667f]}}
data merge entity b4028d78-85e3-5bdd-b8d1-be173b14689d {start_interpolation:0,transformation:{translation:[-0.043f,1.56f,-0.621f],left_rotation:[0.1775f,-0.921f,0.3461f,0.0221f]}}
