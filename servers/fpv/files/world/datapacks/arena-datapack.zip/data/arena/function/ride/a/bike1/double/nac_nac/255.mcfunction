data merge entity 11ae4677-4219-56c2-add0-4c64d57ac56a {start_interpolation:0,transformation:{translation:[-0.025f,1.783f,0.246f],left_rotation:[0.5121f,-0.0898f,-0.0133f,0.8541f]}}
data merge entity 7d2a9e32-11f2-50e1-9212-e206c5741830 {start_interpolation:0,transformation:{translation:[0.119f,1.985f,0.683f],left_rotation:[0.6065f,0.334f,-0.0158f,0.7214f],scale:[1f,1f,0.996f]}}
data merge entity dde4ca15-7054-52aa-b829-17380091a80f {start_interpolation:0,transformation:{translation:[-0.235f,2.027f,0.633f],left_rotation:[0.6087f,-0.2424f,0.1084f,0.7476f]}}
data merge entity f4c9c580-42de-5f18-958e-fe8f13f48db0 {start_interpolation:0,transformation:{translation:[0.071f,1.758f,0.233f],left_rotation:[-0.1794f,0.2127f,0.1852f,0.9425f]}}
data merge entity 593cd5be-38e3-598f-a4f4-75287916d917 {start_interpolation:0,transformation:{translation:[-0.116f,1.779f,0.206f],left_rotation:[-0.1542f,-0.1132f,-0.1145f,0.9748f]}}
data merge entity b93e033a-5262-5632-b8ab-3de10d1c99fe {start_interpolation:0,transformation:{translation:[0.258f,1.376f,0.347f],left_rotation:[0.436f,0.1313f,-0.0611f,0.8882f]}}
data merge entity e73b8616-4bc3-571b-bb40-c31cce9d3a8c {start_interpolation:0,transformation:{translation:[-0.23f,1.372f,0.327f],left_rotation:[0.4109f,0.0015f,0.0398f,0.9108f]}}
