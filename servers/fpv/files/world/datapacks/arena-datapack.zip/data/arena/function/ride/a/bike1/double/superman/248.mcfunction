data merge entity 11ae4677-4219-56c2-add0-4c64d57ac56a {start_interpolation:0,transformation:{translation:[0f,1.981f,-0.43f],left_rotation:[0.6932f,0f,0f,0.7207f]}}
data merge entity 7d2a9e32-11f2-50e1-9212-e206c5741830 {start_interpolation:0,transformation:{translation:[0.18f,2f,0.039f],left_rotation:[0.3275f,0.1414f,0.0849f,0.9303f]}}
data merge entity dde4ca15-7054-52aa-b829-17380091a80f {start_interpolation:0,transformation:{translation:[-0.18f,2f,0.039f],left_rotation:[0.3275f,-0.1414f,-0.0849f,0.9303f]}}
data merge entity f4c9c580-42de-5f18-958e-fe8f13f48db0 {start_interpolation:0,transformation:{translation:[0.095f,1.98f,-0.46f],left_rotation:[0.6642f,0.0209f,0.1071f,0.7396f]}}
data merge entity 593cd5be-38e3-598f-a4f4-75287916d917 {start_interpolation:0,transformation:{translation:[-0.095f,1.98f,-0.46f],left_rotation:[0.6642f,-0.0209f,-0.1071f,0.7396f]}}
data merge entity b93e033a-5262-5632-b8ab-3de10d1c99fe {start_interpolation:0,transformation:{translation:[0.153f,1.938f,-0.895f],left_rotation:[0.8453f,0.0501f,0.0969f,0.5231f]}}
data merge entity e73b8616-4bc3-571b-bb40-c31cce9d3a8c {start_interpolation:0,transformation:{translation:[-0.153f,1.938f,-0.895f],left_rotation:[0.8453f,-0.0501f,-0.0969f,0.5231f]}}
