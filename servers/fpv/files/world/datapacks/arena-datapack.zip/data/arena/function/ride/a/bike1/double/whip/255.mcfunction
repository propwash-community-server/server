data merge entity 808323a0-bdef-57da-99dd-aa87a4fc58fa {start_interpolation:0,transformation:{translation:[0f,0.55f,0f]}}
data merge entity 7d2a9e32-11f2-50e1-9212-e206c5741830 {start_interpolation:0,transformation:{scale:[1f,1f,1.012f]}}
data merge entity dde4ca15-7054-52aa-b829-17380091a80f {start_interpolation:0,transformation:{scale:[1f,1f,1.012f]}}
