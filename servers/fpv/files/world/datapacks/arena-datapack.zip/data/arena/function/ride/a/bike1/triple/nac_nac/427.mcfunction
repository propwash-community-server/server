data merge entity 11ae4677-4219-56c2-add0-4c64d57ac56a {start_interpolation:0,transformation:{translation:[-0.05f,1.75f,-0.199f],left_rotation:[0.3075f,-0.1854f,-0.0001f,0.9333f]}}
data merge entity 7d2a9e32-11f2-50e1-9212-e206c5741830 {start_interpolation:0,transformation:{translation:[0.064f,2.111f,0.133f],left_rotation:[0.4531f,0.382f,-0.0393f,0.8045f]}}
data merge entity dde4ca15-7054-52aa-b829-17380091a80f {start_interpolation:0,transformation:{translation:[-0.271f,2.152f,0.008f],left_rotation:[0.4452f,-0.1787f,0.1694f,0.8609f]}}
data merge entity f4c9c580-42de-5f18-958e-fe8f13f48db0 {start_interpolation:0,transformation:{translation:[0.042f,1.715f,-0.184f],left_rotation:[0.518f,0.6032f,0.1649f,0.5837f]}}
data merge entity 593cd5be-38e3-598f-a4f4-75287916d917 {start_interpolation:0,transformation:{translation:[-0.135f,1.737f,-0.249f],left_rotation:[-0.3653f,-0.1423f,-0.0947f,0.9151f]}}
data merge entity b93e033a-5262-5632-b8ab-3de10d1c99fe {start_interpolation:0,transformation:{translation:[-0.148f,1.535f,-0.537f],left_rotation:[0.7242f,0.6133f,-0.122f,0.2908f]}}
data merge entity e73b8616-4bc3-571b-bb40-c31cce9d3a8c {start_interpolation:0,transformation:{translation:[-0.257f,1.422f,0.033f],left_rotation:[0.2657f,0.0182f,0.0659f,0.9616f]}}
