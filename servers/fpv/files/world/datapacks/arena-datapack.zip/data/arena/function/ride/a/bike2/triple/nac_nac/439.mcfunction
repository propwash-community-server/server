data merge entity 7f895ae6-3a84-58c6-84f5-016612fdd486 {start_interpolation:0,transformation:{translation:[0.013f,1.707f,-0.533f],left_rotation:[0.2453f,0.0458f,-0.0085f,0.9683f]}}
data merge entity d5b82b8d-86e1-5276-8680-ed7a08615c7a {start_interpolation:0,transformation:{translation:[0.21f,2.122f,-0.327f],left_rotation:[0.3538f,0.2203f,-0.1634f,0.8942f]}}
data merge entity a4c123d3-dfeb-5763-b680-e521fb79538b {start_interpolation:0,transformation:{translation:[-0.148f,2.119f,-0.294f],left_rotation:[0.3563f,-0.282f,0.1306f,0.8812f],scale:[1f,1f,1f]}}
data merge entity 14895439-b1c6-5868-83ed-85b5ca16af52 {start_interpolation:0,transformation:{translation:[0.106f,1.681f,-0.556f],left_rotation:[-0.4317f,0.1385f,0.0746f,0.8882f]}}
data merge entity ed503232-ebe9-57f4-8f88-a4efe27a7f4d {start_interpolation:0,transformation:{translation:[-0.083f,1.68f,-0.539f],left_rotation:[-0.4354f,-0.1373f,-0.086f,0.8855f]}}
data merge entity 75e3c547-3dab-50d7-a8aa-ffff4a07edfb {start_interpolation:0,transformation:{translation:[0.217f,1.41f,-0.228f],left_rotation:[0.0961f,-0.0087f,-0.0256f,0.995f]}}
data merge entity b4028d78-85e3-5bdd-b8d1-be173b14689d {start_interpolation:0,transformation:{translation:[-0.202f,1.413f,-0.21f],left_rotation:[0.114f,-0.0341f,0.0172f,0.9928f]}}
