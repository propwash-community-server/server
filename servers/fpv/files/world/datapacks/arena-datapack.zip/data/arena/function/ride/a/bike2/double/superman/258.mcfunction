data merge entity 7f895ae6-3a84-58c6-84f5-016612fdd486 {start_interpolation:0,transformation:{translation:[0f,1.819f,-0.648f],left_rotation:[0.5184f,0f,0f,0.8551f]}}
data merge entity d5b82b8d-86e1-5276-8680-ed7a08615c7a {start_interpolation:0,transformation:{translation:[0.18f,2.037f,-0.231f],left_rotation:[0.3014f,0.1689f,0.0361f,0.9377f],scale:[1f,1f,1.004f]}}
data merge entity a4c123d3-dfeb-5763-b680-e521fb79538b {start_interpolation:0,transformation:{translation:[-0.18f,2.037f,-0.231f],left_rotation:[0.3014f,-0.1689f,-0.0361f,0.9377f],scale:[1f,1f,1.004f]}}
data merge entity 14895439-b1c6-5868-83ed-85b5ca16af52 {start_interpolation:0,transformation:{translation:[0.095f,1.806f,-0.675f],left_rotation:[-0.4675f,0.3231f,0.1056f,0.816f]}}
data merge entity ed503232-ebe9-57f4-8f88-a4efe27a7f4d {start_interpolation:0,transformation:{translation:[-0.095f,1.806f,-0.675f],left_rotation:[-0.4675f,-0.3231f,-0.1056f,0.816f]}}
data merge entity 75e3c547-3dab-50d7-a8aa-ffff4a07edfb {start_interpolation:0,transformation:{translation:[0.304f,1.568f,-0.369f],left_rotation:[0.0958f,0.2026f,-0.1205f,0.9671f]}}
data merge entity b4028d78-85e3-5bdd-b8d1-be173b14689d {start_interpolation:0,transformation:{translation:[-0.304f,1.568f,-0.369f],left_rotation:[0.0958f,-0.2026f,0.1205f,0.9671f]}}
