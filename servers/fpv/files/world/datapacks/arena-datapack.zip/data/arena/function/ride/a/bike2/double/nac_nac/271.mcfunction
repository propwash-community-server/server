data merge entity 7f895ae6-3a84-58c6-84f5-016612fdd486 {start_interpolation:0,transformation:{translation:[0.022f,1.788f,0.25f],left_rotation:[0.5188f,0.0776f,0.0112f,0.8513f]}}
data merge entity d5b82b8d-86e1-5276-8680-ed7a08615c7a {start_interpolation:0,transformation:{translation:[0.228f,2.022f,0.644f],left_rotation:[0.6113f,0.2479f,-0.1032f,0.7444f]}}
data merge entity a4c123d3-dfeb-5763-b680-e521fb79538b {start_interpolation:0,transformation:{translation:[-0.127f,1.987f,0.688f],left_rotation:[0.6092f,-0.3275f,0.0217f,0.7219f]}}
data merge entity 14895439-b1c6-5868-83ed-85b5ca16af52 {start_interpolation:0,transformation:{translation:[0.114f,1.783f,0.212f],left_rotation:[-0.147f,0.1118f,0.1141f,0.9762f]}}
data merge entity ed503232-ebe9-57f4-8f88-a4efe27a7f4d {start_interpolation:0,transformation:{translation:[-0.074f,1.764f,0.235f],left_rotation:[-0.165f,-0.1208f,-0.1375f,0.9692f]}}
data merge entity 75e3c547-3dab-50d7-a8aa-ffff4a07edfb {start_interpolation:0,transformation:{translation:[0.226f,1.374f,0.327f],left_rotation:[0.4083f,-0.0011f,-0.036f,0.9121f]}}
data merge entity b4028d78-85e3-5bdd-b8d1-be173b14689d {start_interpolation:0,transformation:{translation:[-0.209f,1.365f,0.361f],left_rotation:[0.4406f,-0.0728f,0.0128f,0.8946f]}}
