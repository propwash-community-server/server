data merge entity 7f895ae6-3a84-58c6-84f5-016612fdd486 {start_interpolation:0,transformation:{translation:[0.03f,1.708f,-0.466f],left_rotation:[0.2373f,0.1098f,-0.0148f,0.9651f]}}
data merge entity d5b82b8d-86e1-5276-8680-ed7a08615c7a {start_interpolation:0,transformation:{translation:[0.244f,2.129f,-0.291f],left_rotation:[0.3653f,0.1908f,-0.1769f,0.8938f],scale:[1f,1f,1.002f]}}
data merge entity a4c123d3-dfeb-5763-b680-e521fb79538b {start_interpolation:0,transformation:{translation:[-0.107f,2.12f,-0.213f],left_rotation:[0.3723f,-0.3282f,0.1033f,0.862f],scale:[1f,1f,0.993f]}}
data merge entity 14895439-b1c6-5868-83ed-85b5ca16af52 {start_interpolation:0,transformation:{translation:[0.121f,1.683f,-0.5f],left_rotation:[-0.4356f,0.1435f,0.0777f,0.8852f]}}
data merge entity ed503232-ebe9-57f4-8f88-a4efe27a7f4d {start_interpolation:0,transformation:{translation:[-0.065f,1.679f,-0.459f],left_rotation:[-0.0164f,-0.9715f,-0.2304f,0.0524f]}}
data merge entity 75e3c547-3dab-50d7-a8aa-ffff4a07edfb {start_interpolation:0,transformation:{translation:[0.236f,1.415f,-0.171f],left_rotation:[0.1403f,-0.0154f,-0.0437f,0.989f]}}
data merge entity b4028d78-85e3-5bdd-b8d1-be173b14689d {start_interpolation:0,transformation:{translation:[-0.089f,1.286f,-0.655f],left_rotation:[-0.031f,-0.8923f,0.4212f,0.1593f]}}
