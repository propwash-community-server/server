data merge entity 11ae4677-4219-56c2-add0-4c64d57ac56a {start_interpolation:0,transformation:{translation:[0f,1.788f,-0.182f],left_rotation:[0.144f,0f,0f,0.9896f]}}
data merge entity 7d2a9e32-11f2-50e1-9212-e206c5741830 {start_interpolation:0,transformation:{translation:[0.18f,2.239f,-0.048f],left_rotation:[-0.4077f,0.5002f,0.21f,0.7345f]}}
data merge entity dde4ca15-7054-52aa-b829-17380091a80f {start_interpolation:0,transformation:{translation:[-0.18f,2.239f,-0.048f],left_rotation:[-0.4077f,-0.5002f,-0.21f,0.7345f]}}
data merge entity f4c9c580-42de-5f18-958e-fe8f13f48db0 {start_interpolation:0,transformation:{translation:[0.095f,1.76f,-0.191f],left_rotation:[-0.3396f,0.0443f,0.0813f,0.936f]}}
data merge entity 593cd5be-38e3-598f-a4f4-75287916d917 {start_interpolation:0,transformation:{translation:[-0.095f,1.76f,-0.191f],left_rotation:[-0.3396f,-0.0443f,-0.0813f,0.936f]}}
data merge entity b93e033a-5262-5632-b8ab-3de10d1c99fe {start_interpolation:0,transformation:{translation:[0.175f,1.427f,0.086f],left_rotation:[0.2882f,0.0031f,0.0145f,0.9575f]}}
data merge entity e73b8616-4bc3-571b-bb40-c31cce9d3a8c {start_interpolation:0,transformation:{translation:[-0.175f,1.427f,0.086f],left_rotation:[0.2882f,-0.0031f,-0.0145f,0.9575f]}}
