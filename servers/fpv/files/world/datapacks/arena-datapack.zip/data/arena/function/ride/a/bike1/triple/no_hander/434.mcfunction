data merge entity 11ae4677-4219-56c2-add0-4c64d57ac56a {start_interpolation:0,transformation:{translation:[0f,1.821f,0.054f],left_rotation:[0.3474f,0f,0f,0.9377f]}}
data merge entity 7d2a9e32-11f2-50e1-9212-e206c5741830 {start_interpolation:0,transformation:{translation:[0.18f,2.177f,0.36f],left_rotation:[0.284f,0.3692f,-0.1183f,0.877f]}}
data merge entity dde4ca15-7054-52aa-b829-17380091a80f {start_interpolation:0,transformation:{translation:[-0.18f,2.177f,0.36f],left_rotation:[0.284f,-0.3692f,0.1183f,0.877f]}}
data merge entity f4c9c580-42de-5f18-958e-fe8f13f48db0 {start_interpolation:0,transformation:{translation:[0.095f,1.798f,0.035f],left_rotation:[-0.2239f,0.0678f,0.0947f,0.9676f]}}
data merge entity 593cd5be-38e3-598f-a4f4-75287916d917 {start_interpolation:0,transformation:{translation:[-0.095f,1.798f,0.035f],left_rotation:[-0.2239f,-0.0678f,-0.0947f,0.9676f]}}
data merge entity b93e033a-5262-5632-b8ab-3de10d1c99fe {start_interpolation:0,transformation:{translation:[0.189f,1.41f,0.22f],left_rotation:[0.3498f,0.0001f,0.0009f,0.9368f]}}
data merge entity e73b8616-4bc3-571b-bb40-c31cce9d3a8c {start_interpolation:0,transformation:{translation:[-0.189f,1.41f,0.22f],left_rotation:[0.3498f,-0.0001f,-0.0009f,0.9368f]}}
