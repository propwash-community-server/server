data merge entity 7f895ae6-3a84-58c6-84f5-016612fdd486 {start_interpolation:0,transformation:{translation:[0.05f,1.755f,0.164f],left_rotation:[0.4435f,0.1833f,0.0278f,0.8769f]}}
data merge entity d5b82b8d-86e1-5276-8680-ed7a08615c7a {start_interpolation:0,transformation:{translation:[0.271f,2.078f,0.481f],left_rotation:[0.5688f,0.202f,-0.1409f,0.7848f]}}
data merge entity a4c123d3-dfeb-5763-b680-e521fb79538b {start_interpolation:0,transformation:{translation:[-0.064f,2.002f,0.588f],left_rotation:[0.5683f,-0.3836f,-0.0183f,0.7278f]}}
data merge entity 14895439-b1c6-5868-83ed-85b5ca16af52 {start_interpolation:0,transformation:{translation:[0.135f,1.757f,0.112f],left_rotation:[-0.2244f,0.1265f,0.1149f,0.9594f]}}
data merge entity ed503232-ebe9-57f4-8f88-a4efe27a7f4d {start_interpolation:0,transformation:{translation:[-0.042f,1.717f,0.169f],left_rotation:[0.5994f,-0.5718f,-0.2531f,0.4998f]}}
data merge entity 75e3c547-3dab-50d7-a8aa-ffff4a07edfb {start_interpolation:0,transformation:{translation:[0.257f,1.373f,0.289f],left_rotation:[0.4064f,-0.0081f,-0.0678f,0.9111f]}}
data merge entity b4028d78-85e3-5bdd-b8d1-be173b14689d {start_interpolation:0,transformation:{translation:[0.148f,1.65f,-0.222f],left_rotation:[0.7595f,-0.6246f,0.029f,0.1793f]}}
