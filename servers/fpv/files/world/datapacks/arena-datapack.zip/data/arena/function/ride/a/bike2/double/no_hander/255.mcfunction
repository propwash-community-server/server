data merge entity 7f895ae6-3a84-58c6-84f5-016612fdd486 {start_interpolation:0,transformation:{left_rotation:[0.2676f,0f,0f,0.9635f]}}
data merge entity d5b82b8d-86e1-5276-8680-ed7a08615c7a {start_interpolation:0,transformation:{translation:[0.18f,2.128f,-0.292f],left_rotation:[0.3549f,0.2481f,-0.1489f,0.889f],scale:[1f,1f,1.014f]}}
data merge entity a4c123d3-dfeb-5763-b680-e521fb79538b {start_interpolation:0,transformation:{translation:[-0.18f,2.128f,-0.292f],left_rotation:[0.3549f,-0.2481f,0.1489f,0.889f],scale:[1f,1f,1.014f]}}
