data merge entity 7f895ae6-3a84-58c6-84f5-016612fdd486 {start_interpolation:0,transformation:{translation:[0f,1.798f,-0.102f],left_rotation:[0.1757f,0f,0f,0.9845f]}}
data merge entity d5b82b8d-86e1-5276-8680-ed7a08615c7a {start_interpolation:0,transformation:{translation:[0.18f,2.239f,0.06f],left_rotation:[-0.3839f,0.4932f,0.226f,0.7472f]}}
data merge entity a4c123d3-dfeb-5763-b680-e521fb79538b {start_interpolation:0,transformation:{translation:[-0.18f,2.239f,0.06f],left_rotation:[-0.3839f,-0.4932f,-0.226f,0.7472f]}}
data merge entity 14895439-b1c6-5868-83ed-85b5ca16af52 {start_interpolation:0,transformation:{translation:[0.095f,1.769f,-0.113f],left_rotation:[-0.3094f,0.0417f,0.0827f,0.9464f]}}
data merge entity ed503232-ebe9-57f4-8f88-a4efe27a7f4d {start_interpolation:0,transformation:{translation:[-0.095f,1.769f,-0.113f],left_rotation:[-0.3094f,-0.0417f,-0.0827f,0.9464f]}}
data merge entity 75e3c547-3dab-50d7-a8aa-ffff4a07edfb {start_interpolation:0,transformation:{translation:[0.175f,1.42f,0.142f],left_rotation:[0.3187f,0.0027f,0.0146f,0.9477f]}}
data merge entity b4028d78-85e3-5bdd-b8d1-be173b14689d {start_interpolation:0,transformation:{translation:[-0.175f,1.42f,0.142f],left_rotation:[0.3187f,-0.0027f,-0.0146f,0.9477f]}}
