data merge entity 11ae4677-4219-56c2-add0-4c64d57ac56a {start_interpolation:0,transformation:{translation:[-0.05f,1.751f,-0.193f],left_rotation:[0.31f,-0.1854f,-0.0006f,0.9325f]}}
data merge entity 7d2a9e32-11f2-50e1-9212-e206c5741830 {start_interpolation:0,transformation:{translation:[0.064f,2.11f,0.141f],left_rotation:[0.4553f,0.3821f,-0.0382f,0.8033f]}}
data merge entity dde4ca15-7054-52aa-b829-17380091a80f {start_interpolation:0,transformation:{translation:[-0.271f,2.152f,0.017f],left_rotation:[0.4475f,-0.1791f,0.169f,0.8597f]}}
data merge entity f4c9c580-42de-5f18-958e-fe8f13f48db0 {start_interpolation:0,transformation:{translation:[0.042f,1.716f,-0.177f],left_rotation:[0.5195f,0.6027f,0.1665f,0.5823f]}}
data merge entity 593cd5be-38e3-598f-a4f4-75287916d917 {start_interpolation:0,transformation:{translation:[-0.135f,1.738f,-0.243f],left_rotation:[-0.3628f,-0.142f,-0.0951f,0.9161f]}}
data merge entity b93e033a-5262-5632-b8ab-3de10d1c99fe {start_interpolation:0,transformation:{translation:[-0.148f,1.538f,-0.532f],left_rotation:[0.725f,0.6136f,-0.1203f,0.2888f]}}
data merge entity e73b8616-4bc3-571b-bb40-c31cce9d3a8c {start_interpolation:0,transformation:{translation:[-0.257f,1.422f,0.038f],left_rotation:[0.2683f,0.018f,0.0659f,0.9609f]}}
