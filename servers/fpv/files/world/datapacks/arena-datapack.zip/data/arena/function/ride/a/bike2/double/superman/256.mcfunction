data merge entity 7f895ae6-3a84-58c6-84f5-016612fdd486 {start_interpolation:0,transformation:{translation:[0f,1.752f,-0.536f],left_rotation:[0.3264f,0f,0f,0.9452f]}}
data merge entity d5b82b8d-86e1-5276-8680-ed7a08615c7a {start_interpolation:0,transformation:{translation:[0.18f,2.122f,-0.246f],left_rotation:[0.3685f,0.2334f,-0.106f,0.8936f]}}
data merge entity a4c123d3-dfeb-5763-b680-e521fb79538b {start_interpolation:0,transformation:{translation:[-0.18f,2.122f,-0.246f],left_rotation:[0.3685f,-0.2334f,0.106f,0.8936f]}}
data merge entity 14895439-b1c6-5868-83ed-85b5ca16af52 {start_interpolation:0,transformation:{translation:[0.095f,1.728f,-0.555f],left_rotation:[-0.3754f,0.1426f,0.0652f,0.9135f]}}
data merge entity ed503232-ebe9-57f4-8f88-a4efe27a7f4d {start_interpolation:0,transformation:{translation:[-0.095f,1.728f,-0.555f],left_rotation:[-0.3754f,-0.1426f,-0.0652f,0.9135f]}}
data merge entity 75e3c547-3dab-50d7-a8aa-ffff4a07edfb {start_interpolation:0,transformation:{translation:[0.195f,1.416f,-0.261f],left_rotation:[0.0454f,0.0163f,-0.0076f,0.9988f]}}
data merge entity b4028d78-85e3-5bdd-b8d1-be173b14689d {start_interpolation:0,transformation:{translation:[-0.195f,1.416f,-0.261f],left_rotation:[0.0454f,-0.0163f,0.0076f,0.9988f]}}
