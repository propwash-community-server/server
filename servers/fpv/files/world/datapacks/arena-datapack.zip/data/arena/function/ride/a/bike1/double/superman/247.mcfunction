data merge entity 11ae4677-4219-56c2-add0-4c64d57ac56a {start_interpolation:0,transformation:{translation:[0f,1.962f,-0.491f],left_rotation:[0.6776f,0f,0f,0.7354f]}}
data merge entity 7d2a9e32-11f2-50e1-9212-e206c5741830 {start_interpolation:0,transformation:{translation:[0.18f,2f,-0.023f],left_rotation:[0.3075f,0.1432f,0.0818f,0.9371f]}}
data merge entity dde4ca15-7054-52aa-b829-17380091a80f {start_interpolation:0,transformation:{translation:[-0.18f,2f,-0.023f],left_rotation:[0.3075f,-0.1432f,-0.0818f,0.9371f]}}
data merge entity f4c9c580-42de-5f18-958e-fe8f13f48db0 {start_interpolation:0,transformation:{translation:[0.095f,1.959f,-0.521f],left_rotation:[0.6482f,0.0232f,0.1066f,0.7536f]}}
data merge entity 593cd5be-38e3-598f-a4f4-75287916d917 {start_interpolation:0,transformation:{translation:[-0.095f,1.959f,-0.521f],left_rotation:[0.6482f,-0.0232f,-0.1066f,0.7536f]}}
data merge entity b93e033a-5262-5632-b8ab-3de10d1c99fe {start_interpolation:0,transformation:{translation:[0.153f,1.899f,-0.953f],left_rotation:[0.8338f,0.0522f,0.0958f,0.5411f]}}
data merge entity e73b8616-4bc3-571b-bb40-c31cce9d3a8c {start_interpolation:0,transformation:{translation:[-0.153f,1.899f,-0.953f],left_rotation:[0.8338f,-0.0522f,-0.0958f,0.5411f]}}
