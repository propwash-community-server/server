data merge entity 11ae4677-4219-56c2-add0-4c64d57ac56a {start_interpolation:0,transformation:{translation:[-0.02f,1.809f,0.124f],left_rotation:[0.4782f,-0.072f,-0.0065f,0.8753f]}}
data merge entity 7d2a9e32-11f2-50e1-9212-e206c5741830 {start_interpolation:0,transformation:{translation:[0.131f,2.05f,0.54f],left_rotation:[0.5728f,0.3225f,-0.041f,0.7525f],scale:[1f,1f,0.999f]}}
data merge entity dde4ca15-7054-52aa-b829-17380091a80f {start_interpolation:0,transformation:{translation:[-0.225f,2.079f,0.497f],left_rotation:[0.5738f,-0.245f,0.1131f,0.7732f]}}
data merge entity f4c9c580-42de-5f18-958e-fe8f13f48db0 {start_interpolation:0,transformation:{translation:[0.076f,1.785f,0.111f],left_rotation:[-0.2073f,0.1187f,0.1271f,0.9627f]}}
data merge entity 593cd5be-38e3-598f-a4f4-75287916d917 {start_interpolation:0,transformation:{translation:[-0.112f,1.8f,0.088f],left_rotation:[-0.1931f,-0.1168f,-0.1082f,0.9682f]}}
data merge entity b93e033a-5262-5632-b8ab-3de10d1c99fe {start_interpolation:0,transformation:{translation:[0.205f,1.397f,0.273f],left_rotation:[0.3895f,0.0631f,-0.0108f,0.9188f]}}
data merge entity e73b8616-4bc3-571b-bb40-c31cce9d3a8c {start_interpolation:0,transformation:{translation:[-0.224f,1.404f,0.241f],left_rotation:[0.3599f,0.0026f,0.034f,0.9324f]}}
