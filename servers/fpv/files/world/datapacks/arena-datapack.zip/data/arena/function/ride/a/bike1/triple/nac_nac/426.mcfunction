data merge entity 11ae4677-4219-56c2-add0-4c64d57ac56a {start_interpolation:0,transformation:{translation:[-0.05f,1.741f,-0.246f],left_rotation:[0.2891f,-0.1854f,0.0036f,0.9392f]}}
data merge entity 7d2a9e32-11f2-50e1-9212-e206c5741830 {start_interpolation:0,transformation:{translation:[0.064f,2.115f,0.071f],left_rotation:[0.4372f,0.3811f,-0.0468f,0.8133f]}}
data merge entity dde4ca15-7054-52aa-b829-17380091a80f {start_interpolation:0,transformation:{translation:[-0.271f,2.151f,-0.055f],left_rotation:[0.4281f,-0.1753f,0.1729f,0.8695f]}}
data merge entity f4c9c580-42de-5f18-958e-fe8f13f48db0 {start_interpolation:0,transformation:{translation:[0.042f,1.707f,-0.229f],left_rotation:[0.5064f,0.6063f,0.1529f,0.5938f]}}
data merge entity 593cd5be-38e3-598f-a4f4-75287916d917 {start_interpolation:0,transformation:{translation:[-0.135f,1.726f,-0.296f],left_rotation:[-0.3832f,-0.1441f,-0.0919f,0.9077f]}}
data merge entity b93e033a-5262-5632-b8ab-3de10d1c99fe {start_interpolation:0,transformation:{translation:[-0.148f,1.513f,-0.576f],left_rotation:[0.7183f,0.6107f,-0.1341f,0.305f]}}
data merge entity e73b8616-4bc3-571b-bb40-c31cce9d3a8c {start_interpolation:0,transformation:{translation:[-0.257f,1.423f,-0.002f],left_rotation:[0.2467f,0.0195f,0.0655f,0.9667f]}}
