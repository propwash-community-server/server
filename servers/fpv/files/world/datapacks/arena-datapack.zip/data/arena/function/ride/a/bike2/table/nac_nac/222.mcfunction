data merge entity 7f895ae6-3a84-58c6-84f5-016612fdd486 {start_interpolation:0,transformation:{translation:[0.004f,1.832f,0.155f],left_rotation:[0.5151f,0.0152f,0.0012f,0.857f]}}
data merge entity d5b82b8d-86e1-5276-8680-ed7a08615c7a {start_interpolation:0,transformation:{translation:[0.191f,2.055f,0.566f],left_rotation:[0.5884f,0.2737f,-0.0833f,0.7563f],scale:[1f,1f,1.009f]}}
data merge entity a4c123d3-dfeb-5763-b680-e521fb79538b {start_interpolation:0,transformation:{translation:[-0.169f,2.049f,0.575f],left_rotation:[0.5879f,-0.2904f,0.0667f,0.752f],scale:[1f,1f,1.009f]}}
data merge entity 14895439-b1c6-5868-83ed-85b5ca16af52 {start_interpolation:0,transformation:{translation:[0.099f,1.819f,0.126f],left_rotation:[-0.1511f,0.1096f,0.1077f,0.9765f]}}
data merge entity ed503232-ebe9-57f4-8f88-a4efe27a7f4d {start_interpolation:0,transformation:{translation:[-0.091f,1.816f,0.131f],left_rotation:[-0.1519f,-0.1075f,-0.1109f,0.9762f]}}
data merge entity 75e3c547-3dab-50d7-a8aa-ffff4a07edfb {start_interpolation:0,transformation:{translation:[0.206f,1.409f,0.246f],left_rotation:[0.3496f,-0.0005f,-0.0157f,0.9368f]}}
data merge entity b4028d78-85e3-5bdd-b8d1-be173b14689d {start_interpolation:0,transformation:{translation:[-0.201f,1.407f,0.251f],left_rotation:[0.355f,-0.0115f,0.0092f,0.9347f]}}
