data merge entity 11ae4677-4219-56c2-add0-4c64d57ac56a {start_interpolation:0,transformation:{translation:[-0.05f,1.765f,0.064f],left_rotation:[0.407f,-0.1843f,-0.0202f,0.8944f]}}
data merge entity 7d2a9e32-11f2-50e1-9212-e206c5741830 {start_interpolation:0,transformation:{translation:[0.064f,2.045f,0.466f],left_rotation:[0.5378f,0.384f,0.0024f,0.7506f]}}
data merge entity dde4ca15-7054-52aa-b829-17380091a80f {start_interpolation:0,transformation:{translation:[-0.271f,2.112f,0.354f],left_rotation:[0.536f,-0.196f,0.1491f,0.8075f]}}
data merge entity f4c9c580-42de-5f18-958e-fe8f13f48db0 {start_interpolation:0,transformation:{translation:[0.042f,1.727f,0.072f],left_rotation:[0.5783f,0.5817f,0.2293f,0.5241f]}}
data merge entity 593cd5be-38e3-598f-a4f4-75287916d917 {start_interpolation:0,transformation:{translation:[-0.135f,1.763f,0.012f],left_rotation:[-0.2638f,-0.1311f,-0.1096f,0.9493f]}}
data merge entity b93e033a-5262-5632-b8ab-3de10d1c99fe {start_interpolation:0,transformation:{translation:[-0.148f,1.628f,-0.312f],left_rotation:[0.7515f,0.6229f,-0.0547f,0.2105f]}}
data merge entity e73b8616-4bc3-571b-bb40-c31cce9d3a8c {start_interpolation:0,transformation:{translation:[-0.257f,1.394f,0.22f],left_rotation:[0.3685f,0.0109f,0.0674f,0.9271f]}}
