$scoreboard players set #glide arena $(ticks)
function arena:ride/glide_sync
tellraw @s [{"text":"Vehicle glide buffer: ","color":"green"},{"score":{"name":"#glide","objective":"arena"},"color":"green"},{"text":" ticks","color":"green"}]
