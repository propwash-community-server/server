data merge entity 7f895ae6-3a84-58c6-84f5-016612fdd486 {start_interpolation:0,transformation:{translation:[0.049f,1.764f,0.103f],left_rotation:[0.4224f,0.181f,0.0225f,0.8879f]}}
data merge entity d5b82b8d-86e1-5276-8680-ed7a08615c7a {start_interpolation:0,transformation:{translation:[0.27f,2.1f,0.405f],left_rotation:[0.5493f,0.1994f,-0.1454f,0.7984f]}}
data merge entity a4c123d3-dfeb-5763-b680-e521fb79538b {start_interpolation:0,transformation:{translation:[-0.066f,2.031f,0.514f],left_rotation:[0.5501f,-0.3823f,-0.0072f,0.7424f]}}
data merge entity 14895439-b1c6-5868-83ed-85b5ca16af52 {start_interpolation:0,transformation:{translation:[0.134f,1.763f,0.051f],left_rotation:[-0.2476f,0.1291f,0.1115f,0.9537f]}}
data merge entity ed503232-ebe9-57f4-8f88-a4efe27a7f4d {start_interpolation:0,transformation:{translation:[-0.043f,1.726f,0.109f],left_rotation:[0.5178f,-0.5825f,-0.3107f,0.5441f]}}
data merge entity 75e3c547-3dab-50d7-a8aa-ffff4a07edfb {start_interpolation:0,transformation:{translation:[0.256f,1.387f,0.246f],left_rotation:[0.3824f,-0.0096f,-0.0667f,0.9215f]}}
data merge entity b4028d78-85e3-5bdd-b8d1-be173b14689d {start_interpolation:0,transformation:{translation:[0.074f,1.607f,-0.298f],left_rotation:[0.735f,-0.655f,0.0803f,0.1559f]}}
