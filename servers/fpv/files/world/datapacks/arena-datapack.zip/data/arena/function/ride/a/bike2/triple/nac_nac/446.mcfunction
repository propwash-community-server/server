data merge entity 7f895ae6-3a84-58c6-84f5-016612fdd486 {start_interpolation:0,transformation:{translation:[0.05f,1.755f,-0.168f],left_rotation:[0.3198f,0.1854f,0.0025f,0.9292f]}}
data merge entity d5b82b8d-86e1-5276-8680-ed7a08615c7a {start_interpolation:0,transformation:{translation:[0.271f,2.151f,0.05f],left_rotation:[0.4564f,0.1809f,-0.1671f,0.855f]}}
data merge entity a4c123d3-dfeb-5763-b680-e521fb79538b {start_interpolation:0,transformation:{translation:[-0.064f,2.107f,0.174f],left_rotation:[0.4637f,-0.3825f,0.0342f,0.7985f]}}
data merge entity 14895439-b1c6-5868-83ed-85b5ca16af52 {start_interpolation:0,transformation:{translation:[0.135f,1.743f,-0.218f],left_rotation:[-0.3532f,0.141f,0.0965f,0.9198f]}}
data merge entity ed503232-ebe9-57f4-8f88-a4efe27a7f4d {start_interpolation:0,transformation:{translation:[-0.042f,1.719f,-0.153f],left_rotation:[0.5256f,-0.6009f,-0.1728f,0.5769f]}}
data merge entity 75e3c547-3dab-50d7-a8aa-ffff4a07edfb {start_interpolation:0,transformation:{translation:[0.257f,1.421f,0.056f],left_rotation:[0.2783f,-0.0173f,-0.0661f,0.9581f]}}
data merge entity b4028d78-85e3-5bdd-b8d1-be173b14689d {start_interpolation:0,transformation:{translation:[0.148f,1.549f,-0.511f],left_rotation:[0.728f,-0.6148f,0.1139f,0.2812f]}}
