data merge entity 7f895ae6-3a84-58c6-84f5-016612fdd486 {start_interpolation:0,transformation:{translation:[0f,1.709f,-0.516f],left_rotation:[0.1093f,0f,0f,0.994f]}}
data merge entity d5b82b8d-86e1-5276-8680-ed7a08615c7a {start_interpolation:0,transformation:{translation:[0.18f,2.168f,-0.414f],left_rotation:[0.0097f,0.353f,-0.1724f,0.9196f],scale:[1f,1f,0.7f]}}
data merge entity a4c123d3-dfeb-5763-b680-e521fb79538b {start_interpolation:0,transformation:{translation:[-0.18f,2.168f,-0.414f],left_rotation:[0.0097f,-0.353f,0.1724f,0.9196f],scale:[1f,1f,0.7f]}}
data merge entity 14895439-b1c6-5868-83ed-85b5ca16af52 {start_interpolation:0,transformation:{translation:[0.095f,1.68f,-0.522f],left_rotation:[-0.4434f,0.0836f,0.0767f,0.8891f]}}
data merge entity ed503232-ebe9-57f4-8f88-a4efe27a7f4d {start_interpolation:0,transformation:{translation:[-0.095f,1.68f,-0.522f],left_rotation:[-0.4434f,-0.0836f,-0.0767f,0.8891f]}}
data merge entity 75e3c547-3dab-50d7-a8aa-ffff4a07edfb {start_interpolation:0,transformation:{translation:[0.188f,1.418f,-0.181f],left_rotation:[0.1308f,0.0007f,0.0022f,0.9914f]}}
data merge entity b4028d78-85e3-5bdd-b8d1-be173b14689d {start_interpolation:0,transformation:{translation:[-0.188f,1.418f,-0.181f],left_rotation:[0.1308f,-0.0007f,-0.0022f,0.9914f]}}
