data merge entity 11ae4677-4219-56c2-add0-4c64d57ac56a {start_interpolation:0,transformation:{translation:[0f,1.801f,0.086f],left_rotation:[0.2627f,0f,0f,0.9649f]}}
data merge entity 7d2a9e32-11f2-50e1-9212-e206c5741830 {start_interpolation:0,transformation:{translation:[0.18f,2.206f,0.324f],left_rotation:[-0.277f,0.468f,0.2331f,0.8062f],scale:[1f,1f,0.865f]}}
data merge entity dde4ca15-7054-52aa-b829-17380091a80f {start_interpolation:0,transformation:{translation:[-0.18f,2.206f,0.324f],left_rotation:[-0.277f,-0.468f,-0.2331f,0.8062f],scale:[1f,1f,0.865f]}}
data merge entity f4c9c580-42de-5f18-958e-fe8f13f48db0 {start_interpolation:0,transformation:{translation:[0.095f,1.775f,0.07f],left_rotation:[-0.2346f,0.0391f,0.0869f,0.9674f]}}
data merge entity 593cd5be-38e3-598f-a4f4-75287916d917 {start_interpolation:0,transformation:{translation:[-0.095f,1.775f,0.07f],left_rotation:[-0.2346f,-0.0391f,-0.0869f,0.9674f]}}
data merge entity b93e033a-5262-5632-b8ab-3de10d1c99fe {start_interpolation:0,transformation:{translation:[0.177f,1.39f,0.267f],left_rotation:[0.3858f,0.0013f,0.0129f,0.9225f]}}
data merge entity e73b8616-4bc3-571b-bb40-c31cce9d3a8c {start_interpolation:0,transformation:{translation:[-0.177f,1.39f,0.267f],left_rotation:[0.3858f,-0.0013f,-0.0129f,0.9225f]}}
