data merge entity 11ae4677-4219-56c2-add0-4c64d57ac56a {start_interpolation:0,transformation:{translation:[-0.022f,1.802f,0.165f],left_rotation:[0.4894f,-0.0779f,-0.0085f,0.8685f]}}
data merge entity 7d2a9e32-11f2-50e1-9212-e206c5741830 {start_interpolation:0,transformation:{translation:[0.127f,2.03f,0.588f],left_rotation:[0.5841f,0.3266f,-0.0329f,0.7423f],scale:[1f,1f,0.998f]}}
data merge entity dde4ca15-7054-52aa-b829-17380091a80f {start_interpolation:0,transformation:{translation:[-0.228f,2.063f,0.542f],left_rotation:[0.5855f,-0.2442f,0.1117f,0.7649f]}}
data merge entity f4c9c580-42de-5f18-958e-fe8f13f48db0 {start_interpolation:0,transformation:{translation:[0.074f,1.778f,0.151f],left_rotation:[-0.1981f,0.1255f,0.1333f,0.9629f]}}
data merge entity 593cd5be-38e3-598f-a4f4-75287916d917 {start_interpolation:0,transformation:{translation:[-0.114f,1.795f,0.127f],left_rotation:[-0.1803f,-0.1156f,-0.1102f,0.9706f]}}
data merge entity b93e033a-5262-5632-b8ab-3de10d1c99fe {start_interpolation:0,transformation:{translation:[0.209f,1.388f,0.304f],left_rotation:[0.4098f,0.0723f,-0.0153f,0.9092f]}}
data merge entity e73b8616-4bc3-571b-bb40-c31cce9d3a8c {start_interpolation:0,transformation:{translation:[-0.226f,1.394f,0.27f],left_rotation:[0.3769f,0.0023f,0.0359f,0.9256f]}}
