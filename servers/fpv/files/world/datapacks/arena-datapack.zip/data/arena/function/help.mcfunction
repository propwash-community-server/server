tellraw @s {"text":"PROPWASH ARENA","color":"gold","bold":true}
tellraw @s {"text":"/function arena:start · stop – run or pause the race loop","color":"gray","bold":false}
tellraw @s {"text":"/function arena:reset – respawn the bikes and the buggy, restart the loop","color":"gray","bold":false}
tellraw @s {"text":"/function arena:glide {ticks:8} – smoothing against lag and ping spikes (1–59 ticks, default 8)","color":"gray","bold":false}
tellraw @s {"text":"/function arena:fx {level:1} – particles: 0 off, 1 normal, 2 full","color":"gray","bold":false}
tellraw @s {"text":"/function arena:day · night – time of day","color":"gray","bold":false}
tellraw @s {"text":"/function arena:build – build the arena in this world","color":"gray","bold":false}
tellraw @s {"text":"/function arena:help – this overview","color":"gray","bold":false}
