data merge entity 7f895ae6-3a84-58c6-84f5-016612fdd486 {start_interpolation:0,transformation:{translation:[0f,1.926f,-0.583f],left_rotation:[0.653f,0f,0f,0.7574f]}}
data merge entity d5b82b8d-86e1-5276-8680-ed7a08615c7a {start_interpolation:0,transformation:{translation:[0.18f,1.995f,-0.118f],left_rotation:[0.2765f,0.1458f,0.077f,0.9468f]}}
data merge entity a4c123d3-dfeb-5763-b680-e521fb79538b {start_interpolation:0,transformation:{translation:[-0.18f,1.995f,-0.118f],left_rotation:[0.2765f,-0.1458f,-0.077f,0.9468f]}}
data merge entity 14895439-b1c6-5868-83ed-85b5ca16af52 {start_interpolation:0,transformation:{translation:[0.095f,1.922f,-0.613f],left_rotation:[0.623f,0.0267f,0.1058f,0.7746f]}}
data merge entity ed503232-ebe9-57f4-8f88-a4efe27a7f4d {start_interpolation:0,transformation:{translation:[-0.095f,1.922f,-0.613f],left_rotation:[0.623f,-0.0267f,-0.1058f,0.7746f]}}
data merge entity 75e3c547-3dab-50d7-a8aa-ffff4a07edfb {start_interpolation:0,transformation:{translation:[0.153f,1.833f,-1.04f],left_rotation:[0.8156f,0.0553f,0.0941f,0.5683f]}}
data merge entity b4028d78-85e3-5bdd-b8d1-be173b14689d {start_interpolation:0,transformation:{translation:[-0.153f,1.833f,-1.04f],left_rotation:[0.8156f,-0.0553f,-0.0941f,0.5683f]}}
