data merge entity 7f895ae6-3a84-58c6-84f5-016612fdd486 {start_interpolation:0,transformation:{translation:[0f,1.736f,-0.492f],left_rotation:[0.2208f,0f,0f,0.9753f]}}
data merge entity d5b82b8d-86e1-5276-8680-ed7a08615c7a {start_interpolation:0,transformation:{translation:[0.18f,2.16f,-0.29f],left_rotation:[0.2954f,0.2687f,-0.2023f,0.8942f],scale:[1f,1f,0.988f]}}
data merge entity a4c123d3-dfeb-5763-b680-e521fb79538b {start_interpolation:0,transformation:{translation:[-0.18f,2.16f,-0.29f],left_rotation:[0.2954f,-0.2687f,0.2023f,0.8942f],scale:[1f,1f,0.988f]}}
data merge entity 14895439-b1c6-5868-83ed-85b5ca16af52 {start_interpolation:0,transformation:{translation:[0.095f,1.709f,-0.505f],left_rotation:[-0.409f,0.1115f,0.0783f,0.9023f]}}
data merge entity ed503232-ebe9-57f4-8f88-a4efe27a7f4d {start_interpolation:0,transformation:{translation:[-0.095f,1.709f,-0.505f],left_rotation:[-0.409f,-0.1115f,-0.0783f,0.9023f]}}
data merge entity 75e3c547-3dab-50d7-a8aa-ffff4a07edfb {start_interpolation:0,transformation:{translation:[0.197f,1.422f,-0.188f],left_rotation:[0.1167f,-0.0021f,-0.0069f,0.9931f]}}
data merge entity b4028d78-85e3-5bdd-b8d1-be173b14689d {start_interpolation:0,transformation:{translation:[-0.197f,1.422f,-0.188f],left_rotation:[0.1167f,0.0021f,0.0069f,0.9931f]}}
