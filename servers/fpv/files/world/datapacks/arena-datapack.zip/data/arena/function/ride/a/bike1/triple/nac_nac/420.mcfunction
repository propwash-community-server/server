data merge entity 11ae4677-4219-56c2-add0-4c64d57ac56a {start_interpolation:0,transformation:{translation:[-0.004f,1.703f,-0.569f],left_rotation:[0.2492f,-0.0147f,0.0031f,0.9683f]}}
data merge entity 7d2a9e32-11f2-50e1-9212-e206c5741830 {start_interpolation:0,transformation:{translation:[0.169f,2.114f,-0.337f],left_rotation:[0.3454f,0.257f,-0.1428f,0.8912f]}}
data merge entity dde4ca15-7054-52aa-b829-17380091a80f {start_interpolation:0,transformation:{translation:[-0.19f,2.115f,-0.348f],left_rotation:[0.3447f,-0.2364f,0.1535f,0.8954f]}}
data merge entity f4c9c580-42de-5f18-958e-fe8f13f48db0 {start_interpolation:0,transformation:{translation:[0.091f,1.677f,-0.581f],left_rotation:[-0.4318f,0.1354f,0.0772f,0.8884f]}}
data merge entity 593cd5be-38e3-598f-a4f4-75287916d917 {start_interpolation:0,transformation:{translation:[-0.099f,1.677f,-0.587f],left_rotation:[-0.4311f,-0.1363f,-0.0735f,0.8889f]}}
data merge entity b93e033a-5262-5632-b8ab-3de10d1c99fe {start_interpolation:0,transformation:{translation:[0.203f,1.406f,-0.253f],left_rotation:[0.0782f,0.0076f,-0.0141f,0.9968f]}}
data merge entity e73b8616-4bc3-571b-bb40-c31cce9d3a8c {start_interpolation:0,transformation:{translation:[-0.208f,1.405f,-0.258f],left_rotation:[0.0725f,0.0056f,0.0168f,0.9972f]}}
