data merge entity 11ae4677-4219-56c2-add0-4c64d57ac56a {start_interpolation:0,transformation:{translation:[0f,1.827f,-0.752f],left_rotation:[0.5829f,0f,0f,0.8126f]}}
data merge entity 7d2a9e32-11f2-50e1-9212-e206c5741830 {start_interpolation:0,transformation:{translation:[0.18f,1.977f,-0.307f],left_rotation:[0.2255f,0.1536f,0.0639f,0.9599f],scale:[1f,1f,1.051f]}}
data merge entity dde4ca15-7054-52aa-b829-17380091a80f {start_interpolation:0,transformation:{translation:[-0.18f,1.977f,-0.307f],left_rotation:[0.2255f,-0.1536f,-0.0639f,0.9599f],scale:[1f,1f,1.051f]}}
data merge entity f4c9c580-42de-5f18-958e-fe8f13f48db0 {start_interpolation:0,transformation:{translation:[0.095f,1.817f,-0.78f],left_rotation:[0.0791f,-0.0046f,0.1129f,0.9904f]}}
data merge entity 593cd5be-38e3-598f-a4f4-75287916d917 {start_interpolation:0,transformation:{translation:[-0.095f,1.817f,-0.78f],left_rotation:[0.0791f,0.0046f,-0.1129f,0.9904f]}}
data merge entity b93e033a-5262-5632-b8ab-3de10d1c99fe {start_interpolation:0,transformation:{translation:[0.194f,1.394f,-0.849f],left_rotation:[0.8319f,0.088f,0.0749f,0.5428f]}}
data merge entity e73b8616-4bc3-571b-bb40-c31cce9d3a8c {start_interpolation:0,transformation:{translation:[-0.194f,1.394f,-0.849f],left_rotation:[0.8319f,-0.088f,-0.0749f,0.5428f]}}
