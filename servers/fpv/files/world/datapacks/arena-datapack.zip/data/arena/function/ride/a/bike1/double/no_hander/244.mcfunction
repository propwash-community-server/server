data merge entity 11ae4677-4219-56c2-add0-4c64d57ac56a {start_interpolation:0,transformation:{translation:[0f,1.759f,-0.325f],left_rotation:[0.0863f,0f,0f,0.9963f]}}
data merge entity 7d2a9e32-11f2-50e1-9212-e206c5741830 {start_interpolation:0,transformation:{translation:[0.18f,2.222f,-0.244f],left_rotation:[-0.4496f,0.5115f,0.1806f,0.7096f]}}
data merge entity dde4ca15-7054-52aa-b829-17380091a80f {start_interpolation:0,transformation:{translation:[-0.18f,2.222f,-0.244f],left_rotation:[-0.4496f,-0.5115f,-0.1806f,0.7096f]}}
data merge entity f4c9c580-42de-5f18-958e-fe8f13f48db0 {start_interpolation:0,transformation:{translation:[0.095f,1.729f,-0.33f],left_rotation:[-0.3934f,0.049f,0.0786f,0.9147f]}}
data merge entity 593cd5be-38e3-598f-a4f4-75287916d917 {start_interpolation:0,transformation:{translation:[-0.095f,1.729f,-0.33f],left_rotation:[-0.3934f,-0.049f,-0.0786f,0.9147f]}}
data merge entity b93e033a-5262-5632-b8ab-3de10d1c99fe {start_interpolation:0,transformation:{translation:[0.175f,1.431f,-0.016f],left_rotation:[0.2321f,0.004f,0.0143f,0.9726f]}}
data merge entity e73b8616-4bc3-571b-bb40-c31cce9d3a8c {start_interpolation:0,transformation:{translation:[-0.175f,1.431f,-0.016f],left_rotation:[0.2321f,-0.004f,-0.0143f,0.9726f]}}
