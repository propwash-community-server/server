data merge entity 7f895ae6-3a84-58c6-84f5-016612fdd486 {start_interpolation:0,transformation:{translation:[0f,1.814f,-0.753f],left_rotation:[0.5656f,0f,0f,0.8247f]}}
data merge entity d5b82b8d-86e1-5276-8680-ed7a08615c7a {start_interpolation:0,transformation:{translation:[0.18f,1.984f,-0.314f],left_rotation:[0.2323f,0.1562f,0.0598f,0.9582f],scale:[1f,1f,1.04f]}}
data merge entity a4c123d3-dfeb-5763-b680-e521fb79538b {start_interpolation:0,transformation:{translation:[-0.18f,1.984f,-0.314f],left_rotation:[0.2323f,-0.1562f,-0.0598f,0.9582f],scale:[1f,1f,1.04f]}}
data merge entity 14895439-b1c6-5868-83ed-85b5ca16af52 {start_interpolation:0,transformation:{translation:[0.095f,1.804f,-0.781f],left_rotation:[-0.2392f,-0.0043f,0.1135f,0.9643f]}}
data merge entity ed503232-ebe9-57f4-8f88-a4efe27a7f4d {start_interpolation:0,transformation:{translation:[-0.095f,1.804f,-0.781f],left_rotation:[-0.2392f,0.0043f,-0.1135f,0.9643f]}}
data merge entity 75e3c547-3dab-50d7-a8aa-ffff4a07edfb {start_interpolation:0,transformation:{translation:[0.19f,1.425f,-0.577f],left_rotation:[0.7131f,0.0946f,0.0594f,0.6921f]}}
data merge entity b4028d78-85e3-5bdd-b8d1-be173b14689d {start_interpolation:0,transformation:{translation:[-0.19f,1.425f,-0.577f],left_rotation:[0.7131f,-0.0946f,-0.0594f,0.6921f]}}
