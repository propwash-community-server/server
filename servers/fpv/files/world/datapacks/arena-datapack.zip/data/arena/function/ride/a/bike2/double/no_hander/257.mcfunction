data merge entity 7f895ae6-3a84-58c6-84f5-016612fdd486 {start_interpolation:0,transformation:{translation:[0f,1.734f,-0.451f],left_rotation:[0.1255f,0f,0f,0.9921f]}}
data merge entity d5b82b8d-86e1-5276-8680-ed7a08615c7a {start_interpolation:0,transformation:{translation:[0.18f,2.189f,-0.334f],left_rotation:[-0.0232f,0.3753f,-0.134f,0.9169f],scale:[1f,1f,0.7f]}}
data merge entity a4c123d3-dfeb-5763-b680-e521fb79538b {start_interpolation:0,transformation:{translation:[-0.18f,2.189f,-0.334f],left_rotation:[-0.0232f,-0.3753f,0.134f,0.9169f],scale:[1f,1f,0.7f]}}
data merge entity 14895439-b1c6-5868-83ed-85b5ca16af52 {start_interpolation:0,transformation:{translation:[0.095f,1.705f,-0.459f],left_rotation:[-0.4212f,0.0783f,0.0787f,0.9001f]}}
data merge entity ed503232-ebe9-57f4-8f88-a4efe27a7f4d {start_interpolation:0,transformation:{translation:[-0.095f,1.705f,-0.459f],left_rotation:[-0.4212f,-0.0783f,-0.0787f,0.9001f]}}
data merge entity 75e3c547-3dab-50d7-a8aa-ffff4a07edfb {start_interpolation:0,transformation:{translation:[0.186f,1.426f,-0.13f],left_rotation:[0.1605f,0.0011f,0.0034f,0.987f]}}
data merge entity b4028d78-85e3-5bdd-b8d1-be173b14689d {start_interpolation:0,transformation:{translation:[-0.186f,1.426f,-0.13f],left_rotation:[0.1605f,-0.0011f,-0.0034f,0.987f]}}
