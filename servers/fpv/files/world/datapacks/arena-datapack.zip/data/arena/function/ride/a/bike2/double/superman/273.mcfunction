data merge entity d5b82b8d-86e1-5276-8680-ed7a08615c7a {start_interpolation:0,transformation:{scale:[1f,1f,1.012f]}}
data merge entity a4c123d3-dfeb-5763-b680-e521fb79538b {start_interpolation:0,transformation:{scale:[1f,1f,1.012f]}}
data merge entity 75e3c547-3dab-50d7-a8aa-ffff4a07edfb {start_interpolation:0,transformation:{left_rotation:[0.3874f,0.0015f,-0.0097f,0.9219f]}}
data merge entity b4028d78-85e3-5bdd-b8d1-be173b14689d {start_interpolation:0,transformation:{left_rotation:[0.3874f,-0.0015f,0.0097f,0.9219f]}}
