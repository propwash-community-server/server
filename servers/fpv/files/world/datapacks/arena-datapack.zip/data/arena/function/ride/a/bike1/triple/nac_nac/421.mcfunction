data merge entity 11ae4677-4219-56c2-add0-4c64d57ac56a {start_interpolation:0,transformation:{translation:[-0.018f,1.71f,-0.509f],left_rotation:[0.2451f,-0.0637f,0.0108f,0.9673f]}}
data merge entity 7d2a9e32-11f2-50e1-9212-e206c5741830 {start_interpolation:0,transformation:{translation:[0.136f,2.122f,-0.263f],left_rotation:[0.3636f,0.2958f,-0.1227f,0.8748f],scale:[1f,1f,0.998f]}}
data merge entity dde4ca15-7054-52aa-b829-17380091a80f {start_interpolation:0,transformation:{translation:[-0.221f,2.126f,-0.309f],left_rotation:[0.3599f,-0.212f,0.1677f,0.893f],scale:[1f,1f,1.002f]}}
data merge entity f4c9c580-42de-5f18-958e-fe8f13f48db0 {start_interpolation:0,transformation:{translation:[0.078f,1.683f,-0.511f],left_rotation:[-0.4393f,0.1419f,0.0916f,0.8823f]}}
data merge entity 593cd5be-38e3-598f-a4f4-75287916d917 {start_interpolation:0,transformation:{translation:[-0.111f,1.685f,-0.535f],left_rotation:[-0.4304f,-0.1396f,-0.0756f,0.8886f]}}
data merge entity b93e033a-5262-5632-b8ab-3de10d1c99fe {start_interpolation:0,transformation:{translation:[0.204f,1.42f,-0.181f],left_rotation:[0.1379f,0.0506f,-0.0219f,0.9889f]}}
data merge entity e73b8616-4bc3-571b-bb40-c31cce9d3a8c {start_interpolation:0,transformation:{translation:[-0.223f,1.413f,-0.208f],left_rotation:[0.1111f,0.0104f,0.0306f,0.9933f]}}
