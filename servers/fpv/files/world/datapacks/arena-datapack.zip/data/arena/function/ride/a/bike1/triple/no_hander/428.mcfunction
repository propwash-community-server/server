data merge entity 11ae4677-4219-56c2-add0-4c64d57ac56a {start_interpolation:0,transformation:{translation:[0f,1.78f,-0.231f],left_rotation:[0.1245f,0f,0f,0.9922f]}}
data merge entity 7d2a9e32-11f2-50e1-9212-e206c5741830 {start_interpolation:0,transformation:{translation:[0.18f,2.236f,-0.115f],left_rotation:[-0.422f,0.5042f,0.2001f,0.7264f]}}
data merge entity dde4ca15-7054-52aa-b829-17380091a80f {start_interpolation:0,transformation:{translation:[-0.18f,2.236f,-0.115f],left_rotation:[-0.422f,-0.5042f,-0.2001f,0.7264f]}}
data merge entity f4c9c580-42de-5f18-958e-fe8f13f48db0 {start_interpolation:0,transformation:{translation:[0.095f,1.751f,-0.238f],left_rotation:[-0.3579f,0.0459f,0.0804f,0.9292f]}}
data merge entity 593cd5be-38e3-598f-a4f4-75287916d917 {start_interpolation:0,transformation:{translation:[-0.095f,1.751f,-0.238f],left_rotation:[-0.3579f,-0.0459f,-0.0804f,0.9292f]}}
data merge entity b93e033a-5262-5632-b8ab-3de10d1c99fe {start_interpolation:0,transformation:{translation:[0.175f,1.43f,0.051f],left_rotation:[0.2693f,0.0034f,0.0145f,0.9629f]}}
data merge entity e73b8616-4bc3-571b-bb40-c31cce9d3a8c {start_interpolation:0,transformation:{translation:[-0.175f,1.43f,0.051f],left_rotation:[0.2693f,-0.0034f,-0.0145f,0.9629f]}}
