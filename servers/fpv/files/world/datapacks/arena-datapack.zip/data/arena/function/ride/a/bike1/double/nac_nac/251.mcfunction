data merge entity 11ae4677-4219-56c2-add0-4c64d57ac56a {start_interpolation:0,transformation:{translation:[-0.05f,1.761f,0.111f],left_rotation:[0.4242f,-0.1839f,-0.0238f,0.8864f]}}
data merge entity 7d2a9e32-11f2-50e1-9212-e206c5741830 {start_interpolation:0,transformation:{translation:[0.064f,2.026f,0.524f],left_rotation:[0.5521f,0.3839f,0.0098f,0.74f]}}
data merge entity dde4ca15-7054-52aa-b829-17380091a80f {start_interpolation:0,transformation:{translation:[-0.271f,2.097f,0.414f],left_rotation:[0.5514f,-0.1988f,0.1453f,0.797f]}}
data merge entity f4c9c580-42de-5f18-958e-fe8f13f48db0 {start_interpolation:0,transformation:{translation:[0.042f,1.723f,0.117f],left_rotation:[0.5883f,0.5772f,0.2405f,0.5128f]}}
data merge entity 593cd5be-38e3-598f-a4f4-75287916d917 {start_interpolation:0,transformation:{translation:[-0.135f,1.761f,0.059f],left_rotation:[-0.2454f,-0.129f,-0.1121f,0.9542f]}}
data merge entity b93e033a-5262-5632-b8ab-3de10d1c99fe {start_interpolation:0,transformation:{translation:[-0.148f,1.639f,-0.27f],left_rotation:[0.7554f,0.6238f,-0.0427f,0.1959f]}}
data merge entity e73b8616-4bc3-571b-bb40-c31cce9d3a8c {start_interpolation:0,transformation:{translation:[-0.257f,1.385f,0.253f],left_rotation:[0.3863f,0.0096f,0.0676f,0.9198f]}}
