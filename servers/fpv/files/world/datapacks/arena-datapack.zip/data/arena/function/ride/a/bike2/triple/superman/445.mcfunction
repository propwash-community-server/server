data merge entity 7f895ae6-3a84-58c6-84f5-016612fdd486 {start_interpolation:0,transformation:{translation:[0f,1.902f,-0.638f],left_rotation:[0.6378f,0f,0f,0.7702f]}}
data merge entity d5b82b8d-86e1-5276-8680-ed7a08615c7a {start_interpolation:0,transformation:{translation:[0.18f,1.989f,-0.176f],left_rotation:[0.2576f,0.1473f,0.0741f,0.9521f]}}
data merge entity a4c123d3-dfeb-5763-b680-e521fb79538b {start_interpolation:0,transformation:{translation:[-0.18f,1.989f,-0.176f],left_rotation:[0.2576f,-0.1473f,-0.0741f,0.9521f]}}
data merge entity 14895439-b1c6-5868-83ed-85b5ca16af52 {start_interpolation:0,transformation:{translation:[0.095f,1.896f,-0.667f],left_rotation:[0.6075f,0.0288f,0.1053f,0.7868f]}}
data merge entity ed503232-ebe9-57f4-8f88-a4efe27a7f4d {start_interpolation:0,transformation:{translation:[-0.095f,1.896f,-0.667f],left_rotation:[0.6075f,-0.0288f,-0.1053f,0.7868f]}}
data merge entity 75e3c547-3dab-50d7-a8aa-ffff4a07edfb {start_interpolation:0,transformation:{translation:[0.153f,1.791f,-1.09f],left_rotation:[0.8041f,0.0572f,0.0929f,0.5844f]}}
data merge entity b4028d78-85e3-5bdd-b8d1-be173b14689d {start_interpolation:0,transformation:{translation:[-0.153f,1.791f,-1.09f],left_rotation:[0.8041f,-0.0572f,-0.0929f,0.5844f]}}
