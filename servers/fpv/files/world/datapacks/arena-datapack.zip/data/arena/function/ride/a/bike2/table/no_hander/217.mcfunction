data merge entity 7f895ae6-3a84-58c6-84f5-016612fdd486 {start_interpolation:0,transformation:{translation:[0f,1.799f,-0.088f],left_rotation:[0.1814f,0f,0f,0.9834f]}}
data merge entity d5b82b8d-86e1-5276-8680-ed7a08615c7a {start_interpolation:0,transformation:{translation:[0.18f,2.238f,0.08f],left_rotation:[-0.3795f,0.4919f,0.2288f,0.7495f]}}
data merge entity a4c123d3-dfeb-5763-b680-e521fb79538b {start_interpolation:0,transformation:{translation:[-0.18f,2.238f,0.08f],left_rotation:[-0.3795f,-0.4919f,-0.2288f,0.7495f]}}
data merge entity 14895439-b1c6-5868-83ed-85b5ca16af52 {start_interpolation:0,transformation:{translation:[0.095f,1.771f,-0.098f],left_rotation:[-0.3038f,0.0412f,0.0829f,0.9482f]}}
data merge entity ed503232-ebe9-57f4-8f88-a4efe27a7f4d {start_interpolation:0,transformation:{translation:[-0.095f,1.771f,-0.098f],left_rotation:[-0.3038f,-0.0412f,-0.0829f,0.9482f]}}
data merge entity 75e3c547-3dab-50d7-a8aa-ffff4a07edfb {start_interpolation:0,transformation:{translation:[0.175f,1.418f,0.152f],left_rotation:[0.3243f,0.0026f,0.0146f,0.9458f]}}
data merge entity b4028d78-85e3-5bdd-b8d1-be173b14689d {start_interpolation:0,transformation:{translation:[-0.175f,1.418f,0.152f],left_rotation:[0.3243f,-0.0026f,-0.0146f,0.9458f]}}
