data merge entity 11ae4677-4219-56c2-add0-4c64d57ac56a {start_interpolation:0,transformation:{translation:[-0.05f,1.762f,-0.104f],left_rotation:[0.3441f,-0.1853f,-0.0074f,0.9204f]}}
data merge entity 7d2a9e32-11f2-50e1-9212-e206c5741830 {start_interpolation:0,transformation:{translation:[0.064f,2.095f,0.256f],left_rotation:[0.4846f,0.3832f,-0.0241f,0.786f]}}
data merge entity dde4ca15-7054-52aa-b829-17380091a80f {start_interpolation:0,transformation:{translation:[-0.271f,2.146f,0.135f],left_rotation:[0.4788f,-0.1852f,0.1623f,0.8427f]}}
data merge entity f4c9c580-42de-5f18-958e-fe8f13f48db0 {start_interpolation:0,transformation:{translation:[0.042f,1.726f,-0.091f],left_rotation:[0.5406f,0.5962f,0.1886f,0.5628f]}}
data merge entity 593cd5be-38e3-598f-a4f4-75287916d917 {start_interpolation:0,transformation:{translation:[-0.135f,1.753f,-0.155f],left_rotation:[-0.3288f,-0.1384f,-0.1002f,0.9288f]}}
data merge entity b93e033a-5262-5632-b8ab-3de10d1c99fe {start_interpolation:0,transformation:{translation:[-0.148f,1.574f,-0.458f],left_rotation:[0.7351f,0.6176f,-0.0977f,0.2619f]}}
data merge entity e73b8616-4bc3-571b-bb40-c31cce9d3a8c {start_interpolation:0,transformation:{translation:[-0.257f,1.417f,0.102f],left_rotation:[0.3035f,0.0155f,0.0665f,0.9504f]}}
