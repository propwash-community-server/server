data merge entity 7f895ae6-3a84-58c6-84f5-016612fdd486 {start_interpolation:0,transformation:{translation:[0.009f,1.78f,-0.365f],left_rotation:[0.3218f,0.0308f,-0.0037f,0.9463f]}}
data merge entity d5b82b8d-86e1-5276-8680-ed7a08615c7a {start_interpolation:0,transformation:{translation:[0.201f,2.155f,-0.09f],left_rotation:[0.4202f,0.2414f,-0.143f,0.863f]}}
data merge entity a4c123d3-dfeb-5763-b680-e521fb79538b {start_interpolation:0,transformation:{translation:[-0.158f,2.15f,-0.068f],left_rotation:[0.4211f,-0.2811f,0.1175f,0.8543f]}}
data merge entity 14895439-b1c6-5868-83ed-85b5ca16af52 {start_interpolation:0,transformation:{translation:[0.103f,1.757f,-0.389f],left_rotation:[-0.3563f,0.1308f,0.0836f,0.9214f]}}
data merge entity ed503232-ebe9-57f4-8f88-a4efe27a7f4d {start_interpolation:0,transformation:{translation:[-0.087f,1.755f,-0.377f],left_rotation:[-0.3581f,-0.1285f,-0.091f,0.9203f]}}
data merge entity 75e3c547-3dab-50d7-a8aa-ffff4a07edfb {start_interpolation:0,transformation:{translation:[0.212f,1.435f,-0.11f],left_rotation:[0.1597f,-0.0052f,-0.0206f,0.9869f]}}
data merge entity b4028d78-85e3-5bdd-b8d1-be173b14689d {start_interpolation:0,transformation:{translation:[-0.201f,1.435f,-0.098f],left_rotation:[0.1713f,-0.022f,0.0125f,0.9849f]}}
