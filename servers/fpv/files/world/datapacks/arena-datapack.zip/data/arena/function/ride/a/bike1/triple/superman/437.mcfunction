data merge entity 11ae4677-4219-56c2-add0-4c64d57ac56a {start_interpolation:0,transformation:{translation:[0f,2.036f,-0.112f],left_rotation:[0.7621f,0f,0f,0.6474f]}}
data merge entity 7d2a9e32-11f2-50e1-9212-e206c5741830 {start_interpolation:0,transformation:{translation:[0.18f,1.96f,0.352f],left_rotation:[0.4299f,0.1326f,0.0989f,0.8876f],scale:[1f,1f,1.061f]}}
data merge entity dde4ca15-7054-52aa-b829-17380091a80f {start_interpolation:0,transformation:{translation:[-0.18f,1.96f,0.352f],left_rotation:[0.4299f,-0.1326f,-0.0989f,0.8876f],scale:[1f,1f,1.061f]}}
data merge entity f4c9c580-42de-5f18-958e-fe8f13f48db0 {start_interpolation:0,transformation:{translation:[0.095f,2.041f,-0.141f],left_rotation:[0.5789f,-0.0101f,0.1105f,0.8078f]}}
data merge entity 593cd5be-38e3-598f-a4f4-75287916d917 {start_interpolation:0,transformation:{translation:[-0.095f,2.041f,-0.141f],left_rotation:[0.5789f,0.0101f,-0.1105f,0.8078f]}}
data merge entity b93e033a-5262-5632-b8ab-3de10d1c99fe {start_interpolation:0,transformation:{translation:[0.179f,1.907f,-0.552f],left_rotation:[0.936f,0.055f,0.0974f,0.3337f]}}
data merge entity e73b8616-4bc3-571b-bb40-c31cce9d3a8c {start_interpolation:0,transformation:{translation:[-0.179f,1.907f,-0.552f],left_rotation:[0.936f,-0.055f,-0.0974f,0.3337f]}}
