data merge entity 7f895ae6-3a84-58c6-84f5-016612fdd486 {start_interpolation:0,transformation:{translation:[0.05f,1.766f,0.036f],left_rotation:[0.3967f,0.1843f,0.018f,0.8991f]}}
data merge entity d5b82b8d-86e1-5276-8680-ed7a08615c7a {start_interpolation:0,transformation:{translation:[0.271f,2.12f,0.317f],left_rotation:[0.5266f,0.1944f,-0.1513f,0.8136f]}}
data merge entity a4c123d3-dfeb-5763-b680-e521fb79538b {start_interpolation:0,transformation:{translation:[-0.064f,2.056f,0.432f],left_rotation:[0.5291f,-0.3839f,0.0021f,0.7568f]}}
data merge entity 14895439-b1c6-5868-83ed-85b5ca16af52 {start_interpolation:0,transformation:{translation:[0.135f,1.763f,-0.016f],left_rotation:[-0.2747f,0.1324f,0.108f,0.9462f]}}
data merge entity ed503232-ebe9-57f4-8f88-a4efe27a7f4d {start_interpolation:0,transformation:{translation:[-0.042f,1.729f,0.045f],left_rotation:[0.5656f,-0.5848f,-0.2294f,0.5343f]}}
data merge entity 75e3c547-3dab-50d7-a8aa-ffff4a07edfb {start_interpolation:0,transformation:{translation:[0.257f,1.399f,0.201f],left_rotation:[0.3577f,-0.0117f,-0.0672f,0.9314f]}}
data merge entity b4028d78-85e3-5bdd-b8d1-be173b14689d {start_interpolation:0,transformation:{translation:[0.141f,1.616f,-0.339f],left_rotation:[0.748f,-0.6247f,0.0657f,0.2144f]}}
