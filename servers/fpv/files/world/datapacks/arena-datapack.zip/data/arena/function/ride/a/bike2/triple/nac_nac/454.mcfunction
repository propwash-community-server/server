data merge entity 7f895ae6-3a84-58c6-84f5-016612fdd486 {start_interpolation:0,transformation:{translation:[0.027f,1.794f,0.158f],left_rotation:[0.4787f,0.0964f,0.0111f,0.8726f]}}
data merge entity d5b82b8d-86e1-5276-8680-ed7a08615c7a {start_interpolation:0,transformation:{translation:[0.238f,2.069f,0.523f],left_rotation:[0.5809f,0.2356f,-0.1192f,0.7699f]}}
data merge entity a4c123d3-dfeb-5763-b680-e521fb79538b {start_interpolation:0,transformation:{translation:[-0.116f,2.029f,0.58f],left_rotation:[0.5796f,-0.3366f,0.0246f,0.7417f]}}
data merge entity 14895439-b1c6-5868-83ed-85b5ca16af52 {start_interpolation:0,transformation:{translation:[0.118f,1.789f,0.118f],left_rotation:[-0.1916f,0.1179f,0.1106f,0.9681f]}}
data merge entity ed503232-ebe9-57f4-8f88-a4efe27a7f4d {start_interpolation:0,transformation:{translation:[-0.069f,1.768f,0.148f],left_rotation:[-0.1419f,-0.702f,-0.4005f,0.5715f]}}
data merge entity 75e3c547-3dab-50d7-a8aa-ffff4a07edfb {start_interpolation:0,transformation:{translation:[0.232f,1.392f,0.269f],left_rotation:[0.3802f,-0.0032f,-0.0417f,0.924f]}}
data merge entity b4028d78-85e3-5bdd-b8d1-be173b14689d {start_interpolation:0,transformation:{translation:[-0.358f,1.486f,-0.028f],left_rotation:[0.1572f,-0.4635f,0.1924f,0.8505f]}}
