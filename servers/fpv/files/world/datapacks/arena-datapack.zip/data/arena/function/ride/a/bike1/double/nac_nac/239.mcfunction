data merge entity 11ae4677-4219-56c2-add0-4c64d57ac56a {start_interpolation:0,transformation:{left_rotation:[0.2652f,-0.005f,0.001f,0.9642f]}}
data merge entity 7d2a9e32-11f2-50e1-9212-e206c5741830 {start_interpolation:0,transformation:{left_rotation:[0.3542f,0.2504f,-0.1415f,0.8898f]}}
data merge entity dde4ca15-7054-52aa-b829-17380091a80f {start_interpolation:0,transformation:{left_rotation:[0.354f,-0.2434f,0.1453f,0.8912f]}}
data merge entity b93e033a-5262-5632-b8ab-3de10d1c99fe {start_interpolation:0,transformation:{translation:[0.204f,1.411f,-0.239f],left_rotation:[0.083f,-0.0002f,-0.0137f,0.9965f]}}
