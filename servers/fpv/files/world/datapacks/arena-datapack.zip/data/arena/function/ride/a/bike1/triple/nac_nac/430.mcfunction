data merge entity 11ae4677-4219-56c2-add0-4c64d57ac56a {start_interpolation:0,transformation:{translation:[-0.05f,1.765f,-0.057f],left_rotation:[0.3619f,-0.1851f,-0.011f,0.9136f]}}
data merge entity 7d2a9e32-11f2-50e1-9212-e206c5741830 {start_interpolation:0,transformation:{translation:[0.064f,2.084f,0.315f],left_rotation:[0.4997f,0.3836f,-0.0167f,0.7764f]}}
data merge entity dde4ca15-7054-52aa-b829-17380091a80f {start_interpolation:0,transformation:{translation:[-0.271f,2.14f,0.196f],left_rotation:[0.495f,-0.1883f,0.1586f,0.8333f]}}
data merge entity f4c9c580-42de-5f18-958e-fe8f13f48db0 {start_interpolation:0,transformation:{translation:[0.042f,1.728f,-0.046f],left_rotation:[0.5514f,0.5924f,0.2001f,0.5522f]}}
data merge entity 593cd5be-38e3-598f-a4f4-75287916d917 {start_interpolation:0,transformation:{translation:[-0.135f,1.758f,-0.108f],left_rotation:[-0.3108f,-0.1364f,-0.1029f,0.935f]}}
data merge entity b93e033a-5262-5632-b8ab-3de10d1c99fe {start_interpolation:0,transformation:{translation:[-0.148f,1.591f,-0.418f],left_rotation:[0.7401f,0.6194f,-0.0857f,0.2477f]}}
data merge entity e73b8616-4bc3-571b-bb40-c31cce9d3a8c {start_interpolation:0,transformation:{translation:[-0.257f,1.412f,0.135f],left_rotation:[0.3218f,0.0143f,0.0668f,0.9443f]}}
