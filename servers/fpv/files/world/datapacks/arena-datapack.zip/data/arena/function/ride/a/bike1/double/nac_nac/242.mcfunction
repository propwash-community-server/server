data merge entity 11ae4677-4219-56c2-add0-4c64d57ac56a {start_interpolation:0,transformation:{translation:[-0.044f,1.726f,-0.349f],left_rotation:[0.2595f,-0.1611f,0.0112f,0.9521f]}}
data merge entity 7d2a9e32-11f2-50e1-9212-e206c5741830 {start_interpolation:0,transformation:{translation:[0.078f,2.121f,-0.062f],left_rotation:[0.406f,0.3642f,-0.0707f,0.8352f]}}
data merge entity dde4ca15-7054-52aa-b829-17380091a80f {start_interpolation:0,transformation:{translation:[-0.264f,2.144f,-0.174f],left_rotation:[0.3965f,-0.177f,0.1774f,0.8832f]}}
data merge entity f4c9c580-42de-5f18-958e-fe8f13f48db0 {start_interpolation:0,transformation:{translation:[0.049f,1.694f,-0.334f],left_rotation:[0.1443f,0.7861f,0.5108f,0.3167f]}}
data merge entity 593cd5be-38e3-598f-a4f4-75287916d917 {start_interpolation:0,transformation:{translation:[-0.131f,1.706f,-0.393f],left_rotation:[-0.4127f,-0.1452f,-0.0852f,0.8952f]}}
data merge entity b93e033a-5262-5632-b8ab-3de10d1c99fe {start_interpolation:0,transformation:{translation:[0.092f,1.502f,-0.727f],left_rotation:[0.3268f,0.8691f,-0.3565f,0.1037f]}}
data merge entity e73b8616-4bc3-571b-bb40-c31cce9d3a8c {start_interpolation:0,transformation:{translation:[-0.25f,1.422f,-0.079f],left_rotation:[0.2f,0.0192f,0.0582f,0.9779f]}}
