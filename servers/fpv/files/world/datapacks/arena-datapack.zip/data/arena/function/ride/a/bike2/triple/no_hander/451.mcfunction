data merge entity 7f895ae6-3a84-58c6-84f5-016612fdd486 {start_interpolation:0,transformation:{translation:[0f,1.805f,-0.01f],left_rotation:[0.2296f,0f,0f,0.9733f]}}
data merge entity d5b82b8d-86e1-5276-8680-ed7a08615c7a {start_interpolation:0,transformation:{translation:[0.18f,2.225f,0.2f],left_rotation:[-0.2911f,0.4739f,0.2051f,0.8053f],scale:[1f,1f,0.831f]}}
data merge entity a4c123d3-dfeb-5763-b680-e521fb79538b {start_interpolation:0,transformation:{translation:[-0.18f,2.225f,0.2f],left_rotation:[-0.2911f,-0.4739f,-0.2051f,0.8053f],scale:[1f,1f,0.831f]}}
data merge entity 14895439-b1c6-5868-83ed-85b5ca16af52 {start_interpolation:0,transformation:{translation:[0.095f,1.778f,-0.024f],left_rotation:[-0.2705f,0.0435f,0.0857f,0.9579f]}}
data merge entity ed503232-ebe9-57f4-8f88-a4efe27a7f4d {start_interpolation:0,transformation:{translation:[-0.095f,1.778f,-0.024f],left_rotation:[-0.2705f,-0.0435f,-0.0857f,0.9579f]}}
data merge entity 75e3c547-3dab-50d7-a8aa-ffff4a07edfb {start_interpolation:0,transformation:{translation:[0.178f,1.409f,0.201f],left_rotation:[0.3494f,0.0017f,0.0123f,0.9369f]}}
data merge entity b4028d78-85e3-5bdd-b8d1-be173b14689d {start_interpolation:0,transformation:{translation:[-0.178f,1.409f,0.201f],left_rotation:[0.3494f,-0.0017f,-0.0123f,0.9369f]}}
