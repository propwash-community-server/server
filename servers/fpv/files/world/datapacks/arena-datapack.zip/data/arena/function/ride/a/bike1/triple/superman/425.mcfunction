data merge entity 11ae4677-4219-56c2-add0-4c64d57ac56a {start_interpolation:0,transformation:{translation:[0f,1.858f,-0.724f],left_rotation:[0.6125f,0f,0f,0.7905f]}}
data merge entity 7d2a9e32-11f2-50e1-9212-e206c5741830 {start_interpolation:0,transformation:{translation:[0.18f,1.975f,-0.268f],left_rotation:[0.2267f,0.1497f,0.0693f,0.9599f],scale:[1f,1f,1.067f]}}
data merge entity dde4ca15-7054-52aa-b829-17380091a80f {start_interpolation:0,transformation:{translation:[-0.18f,1.975f,-0.268f],left_rotation:[0.2267f,-0.1497f,-0.0693f,0.9599f],scale:[1f,1f,1.067f]}}
data merge entity f4c9c580-42de-5f18-958e-fe8f13f48db0 {start_interpolation:0,transformation:{translation:[0.095f,1.85f,-0.753f],left_rotation:[0.5771f,0.0316f,0.1045f,0.8093f]}}
data merge entity 593cd5be-38e3-598f-a4f4-75287916d917 {start_interpolation:0,transformation:{translation:[-0.095f,1.85f,-0.753f],left_rotation:[0.5771f,-0.0316f,-0.1045f,0.8093f]}}
data merge entity b93e033a-5262-5632-b8ab-3de10d1c99fe {start_interpolation:0,transformation:{translation:[0.153f,1.713f,-1.167f],left_rotation:[0.7871f,0.0606f,0.0908f,0.6071f]}}
data merge entity e73b8616-4bc3-571b-bb40-c31cce9d3a8c {start_interpolation:0,transformation:{translation:[-0.153f,1.713f,-1.167f],left_rotation:[0.7871f,-0.0606f,-0.0908f,0.6071f]}}
