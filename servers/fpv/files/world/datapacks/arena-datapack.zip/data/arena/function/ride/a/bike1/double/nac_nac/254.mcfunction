data merge entity 11ae4677-4219-56c2-add0-4c64d57ac56a {start_interpolation:0,transformation:{translation:[-0.04f,1.761f,0.225f],left_rotation:[0.4804f,-0.1467f,-0.024f,0.8644f]}}
data merge entity 7d2a9e32-11f2-50e1-9212-e206c5741830 {start_interpolation:0,transformation:{translation:[0.085f,1.981f,0.66f],left_rotation:[0.5922f,0.3641f,0.0102f,0.7188f]}}
data merge entity dde4ca15-7054-52aa-b829-17380091a80f {start_interpolation:0,transformation:{translation:[-0.259f,2.047f,0.577f],left_rotation:[0.5943f,-0.2183f,0.1282f,0.7634f]}}
data merge entity f4c9c580-42de-5f18-958e-fe8f13f48db0 {start_interpolation:0,transformation:{translation:[0.053f,1.728f,0.221f],left_rotation:[0.1165f,0.7272f,0.6708f,0.0876f]}}
data merge entity 593cd5be-38e3-598f-a4f4-75287916d917 {start_interpolation:0,transformation:{translation:[-0.128f,1.763f,0.178f],left_rotation:[-0.1867f,-0.12f,-0.1161f,0.9681f]}}
data merge entity b93e033a-5262-5632-b8ab-3de10d1c99fe {start_interpolation:0,transformation:{translation:[0.031f,1.696f,-0.217f],left_rotation:[0.1363f,0.9735f,-0.1825f,-0.021f]}}
data merge entity e73b8616-4bc3-571b-bb40-c31cce9d3a8c {start_interpolation:0,transformation:{translation:[-0.247f,1.365f,0.324f],left_rotation:[0.4199f,0.0044f,0.0573f,0.9057f]}}
