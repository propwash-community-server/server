data merge entity 75e3c547-3dab-50d7-a8aa-ffff4a07edfb {start_interpolation:0,transformation:{left_rotation:[0.0796f,-0.0024f,-0.0122f,0.9967f]}}
data merge entity b4028d78-85e3-5bdd-b8d1-be173b14689d {start_interpolation:0,transformation:{left_rotation:[0.0796f,0.0024f,0.0122f,0.9967f]}}
