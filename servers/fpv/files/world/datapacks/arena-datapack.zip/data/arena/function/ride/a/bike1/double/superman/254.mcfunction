data merge entity 11ae4677-4219-56c2-add0-4c64d57ac56a {start_interpolation:0,transformation:{translation:[0f,1.987f,-0.027f],left_rotation:[0.7136f,0f,0f,0.7005f]}}
data merge entity 7d2a9e32-11f2-50e1-9212-e206c5741830 {start_interpolation:0,transformation:{translation:[0.18f,1.978f,0.443f],left_rotation:[0.4962f,0.1502f,0.0812f,0.8513f],scale:[1f,1f,1.011f]}}
data merge entity dde4ca15-7054-52aa-b829-17380091a80f {start_interpolation:0,transformation:{translation:[-0.18f,1.978f,0.443f],left_rotation:[0.4962f,-0.1502f,-0.0812f,0.8513f],scale:[1f,1f,1.011f]}}
data merge entity f4c9c580-42de-5f18-958e-fe8f13f48db0 {start_interpolation:0,transformation:{translation:[0.095f,1.987f,-0.057f],left_rotation:[-0.2975f,0.2641f,0.204f,0.8945f]}}
data merge entity 593cd5be-38e3-598f-a4f4-75287916d917 {start_interpolation:0,transformation:{translation:[-0.095f,1.987f,-0.057f],left_rotation:[-0.2975f,-0.2641f,-0.204f,0.8945f]}}
data merge entity b93e033a-5262-5632-b8ab-3de10d1c99fe {start_interpolation:0,transformation:{translation:[0.325f,1.662f,0.129f],left_rotation:[0.3967f,0.2336f,-0.0804f,0.8841f]}}
data merge entity e73b8616-4bc3-571b-bb40-c31cce9d3a8c {start_interpolation:0,transformation:{translation:[-0.325f,1.662f,0.129f],left_rotation:[0.3967f,-0.2336f,0.0804f,0.8841f]}}
