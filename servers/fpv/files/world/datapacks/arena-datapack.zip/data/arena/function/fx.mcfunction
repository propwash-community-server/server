$scoreboard players set #fx arena $(level)
execute unless score #fx arena matches 0..2 run scoreboard players set #fx arena 1
tellraw @s [{"text":"Particle level: ","color":"green"},{"score":{"name":"#fx","objective":"arena"},"color":"green"},{"text":" (0 off, 1 normal, 2 full)","color":"gray"}]
