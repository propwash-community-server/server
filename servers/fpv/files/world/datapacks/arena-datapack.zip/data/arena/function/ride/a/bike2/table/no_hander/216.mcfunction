data merge entity 7f895ae6-3a84-58c6-84f5-016612fdd486 {start_interpolation:0,transformation:{translation:[0f,1.794f,-0.139f],left_rotation:[0.1613f,0f,0f,0.9869f]}}
data merge entity d5b82b8d-86e1-5276-8680-ed7a08615c7a {start_interpolation:0,transformation:{translation:[0.18f,2.24f,0.011f],left_rotation:[-0.3948f,0.4964f,0.2187f,0.7415f]}}
data merge entity a4c123d3-dfeb-5763-b680-e521fb79538b {start_interpolation:0,transformation:{translation:[-0.18f,2.24f,0.011f],left_rotation:[-0.3948f,-0.4964f,-0.2187f,0.7415f]}}
data merge entity 14895439-b1c6-5868-83ed-85b5ca16af52 {start_interpolation:0,transformation:{translation:[0.095f,1.766f,-0.148f],left_rotation:[-0.3232f,0.0429f,0.0821f,0.9418f]}}
data merge entity ed503232-ebe9-57f4-8f88-a4efe27a7f4d {start_interpolation:0,transformation:{translation:[-0.095f,1.766f,-0.148f],left_rotation:[-0.3232f,-0.0429f,-0.0821f,0.9418f]}}
data merge entity 75e3c547-3dab-50d7-a8aa-ffff4a07edfb {start_interpolation:0,transformation:{translation:[0.175f,1.423f,0.116f],left_rotation:[0.3048f,0.0029f,0.0146f,0.9523f]}}
data merge entity b4028d78-85e3-5bdd-b8d1-be173b14689d {start_interpolation:0,transformation:{translation:[-0.175f,1.423f,0.116f],left_rotation:[0.3048f,-0.0029f,-0.0146f,0.9523f]}}
