data merge entity 11ae4677-4219-56c2-add0-4c64d57ac56a {start_interpolation:0,transformation:{translation:[0f,2.008f,-0.033f],left_rotation:[0.7404f,0f,0f,0.6722f]}}
data merge entity 7d2a9e32-11f2-50e1-9212-e206c5741830 {start_interpolation:0,transformation:{translation:[0.18f,1.963f,0.435f],left_rotation:[0.4786f,0.1407f,0.0924f,0.8617f],scale:[1f,1f,1.027f]}}
data merge entity dde4ca15-7054-52aa-b829-17380091a80f {start_interpolation:0,transformation:{translation:[-0.18f,1.963f,0.435f],left_rotation:[0.4786f,-0.1407f,-0.0924f,0.8617f],scale:[1f,1f,1.027f]}}
data merge entity f4c9c580-42de-5f18-958e-fe8f13f48db0 {start_interpolation:0,transformation:{translation:[0.095f,2.011f,-0.063f],left_rotation:[-0.237f,0.0391f,0.1456f,0.9597f]}}
data merge entity 593cd5be-38e3-598f-a4f4-75287916d917 {start_interpolation:0,transformation:{translation:[-0.095f,2.011f,-0.063f],left_rotation:[-0.237f,-0.0391f,-0.1456f,0.9597f]}}
data merge entity b93e033a-5262-5632-b8ab-3de10d1c99fe {start_interpolation:0,transformation:{translation:[0.226f,1.639f,0.132f],left_rotation:[0.6759f,0.118f,0.0231f,0.7271f]}}
data merge entity e73b8616-4bc3-571b-bb40-c31cce9d3a8c {start_interpolation:0,transformation:{translation:[-0.226f,1.639f,0.132f],left_rotation:[0.6759f,-0.118f,-0.0231f,0.7271f]}}
