data merge entity ac1d332c-cc5a-585a-945d-815d61434b7c {start_interpolation:0,transformation:{translation:[0f,0.55f,0f]}}
data merge entity d5b82b8d-86e1-5276-8680-ed7a08615c7a {start_interpolation:0,transformation:{scale:[1f,1f,1.008f]}}
data merge entity a4c123d3-dfeb-5763-b680-e521fb79538b {start_interpolation:0,transformation:{scale:[1f,1f,1.008f]}}
