data merge entity 11ae4677-4219-56c2-add0-4c64d57ac56a {start_interpolation:0,transformation:{translation:[-0.021f,1.775f,-0.307f],left_rotation:[0.3186f,-0.0772f,0.0061f,0.9447f]}}
data merge entity 7d2a9e32-11f2-50e1-9212-e206c5741830 {start_interpolation:0,transformation:{translation:[0.128f,2.142f,0.002f],left_rotation:[0.4347f,0.3138f,-0.0935f,0.8389f],scale:[1f,1f,0.998f]}}
data merge entity dde4ca15-7054-52aa-b829-17380091a80f {start_interpolation:0,transformation:{translation:[-0.228f,2.156f,-0.052f],left_rotation:[0.4319f,-0.2192f,0.1547f,0.8611f],scale:[1f,1f,1.002f]}}
data merge entity f4c9c580-42de-5f18-958e-fe8f13f48db0 {start_interpolation:0,transformation:{translation:[0.074f,1.747f,-0.311f],left_rotation:[-0.3745f,0.1468f,0.1073f,0.9092f]}}
data merge entity 593cd5be-38e3-598f-a4f4-75287916d917 {start_interpolation:0,transformation:{translation:[-0.113f,1.754f,-0.339f],left_rotation:[-0.359f,-0.1341f,-0.0868f,0.9196f]}}
data merge entity b93e033a-5262-5632-b8ab-3de10d1c99fe {start_interpolation:0,transformation:{translation:[0.208f,1.441f,-0.025f],left_rotation:[0.2317f,0.067f,-0.0276f,0.9701f]}}
data merge entity e73b8616-4bc3-571b-bb40-c31cce9d3a8c {start_interpolation:0,transformation:{translation:[-0.226f,1.434f,-0.059f],left_rotation:[0.197f,0.009f,0.0348f,0.9797f]}}
