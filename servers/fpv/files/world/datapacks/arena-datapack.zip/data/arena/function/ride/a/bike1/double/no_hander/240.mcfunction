data merge entity 11ae4677-4219-56c2-add0-4c64d57ac56a {start_interpolation:0,transformation:{translation:[0f,1.733f,-0.505f],left_rotation:[0.2341f,0f,0f,0.9722f]}}
data merge entity 7d2a9e32-11f2-50e1-9212-e206c5741830 {start_interpolation:0,transformation:{translation:[0.18f,2.152f,-0.291f],left_rotation:[0.3161f,0.26f,-0.1897f,0.8925f],scale:[1f,1f,1.015f]}}
data merge entity dde4ca15-7054-52aa-b829-17380091a80f {start_interpolation:0,transformation:{translation:[-0.18f,2.152f,-0.291f],left_rotation:[0.3161f,-0.26f,0.1897f,0.8925f],scale:[1f,1f,1.015f]}}
data merge entity f4c9c580-42de-5f18-958e-fe8f13f48db0 {start_interpolation:0,transformation:{translation:[0.095f,1.707f,-0.519f],left_rotation:[-0.4094f,0.1174f,0.0777f,0.9014f]}}
data merge entity 593cd5be-38e3-598f-a4f4-75287916d917 {start_interpolation:0,transformation:{translation:[-0.095f,1.707f,-0.519f],left_rotation:[-0.4094f,-0.1174f,-0.0777f,0.9014f]}}
data merge entity b93e033a-5262-5632-b8ab-3de10d1c99fe {start_interpolation:0,transformation:{translation:[0.199f,1.419f,-0.202f],left_rotation:[0.1068f,-0.0026f,-0.0084f,0.9942f]}}
data merge entity e73b8616-4bc3-571b-bb40-c31cce9d3a8c {start_interpolation:0,transformation:{translation:[-0.199f,1.419f,-0.202f],left_rotation:[0.1068f,0.0026f,0.0084f,0.9942f]}}
