data merge entity 11ae4677-4219-56c2-add0-4c64d57ac56a {start_interpolation:0,transformation:{translation:[-0.035f,1.708f,-0.442f],left_rotation:[0.2372f,-0.129f,0.0153f,0.9627f]}}
data merge entity 7d2a9e32-11f2-50e1-9212-e206c5741830 {start_interpolation:0,transformation:{translation:[0.096f,2.12f,-0.183f],left_rotation:[0.378f,0.3414f,-0.0943f,0.8554f],scale:[1f,1f,0.991f]}}
data merge entity dde4ca15-7054-52aa-b829-17380091a80f {start_interpolation:0,transformation:{translation:[-0.252f,2.131f,-0.275f],left_rotation:[0.3696f,-0.1836f,0.1791f,0.8931f]}}
data merge entity f4c9c580-42de-5f18-958e-fe8f13f48db0 {start_interpolation:0,transformation:{translation:[0.059f,1.679f,-0.431f],left_rotation:[0.0418f,0.943f,0.3296f,0.0185f]}}
data merge entity 593cd5be-38e3-598f-a4f4-75287916d917 {start_interpolation:0,transformation:{translation:[-0.125f,1.685f,-0.48f],left_rotation:[-0.4348f,-0.1449f,-0.0792f,0.8852f]}}
data merge entity b93e033a-5262-5632-b8ab-3de10d1c99fe {start_interpolation:0,transformation:{translation:[0.03f,1.336f,-0.705f],left_rotation:[-0.0445f,-0.8891f,0.455f,0.0219f]}}
data merge entity e73b8616-4bc3-571b-bb40-c31cce9d3a8c {start_interpolation:0,transformation:{translation:[-0.242f,1.417f,-0.151f],left_rotation:[0.1545f,0.0174f,0.049f,0.9866f]}}
