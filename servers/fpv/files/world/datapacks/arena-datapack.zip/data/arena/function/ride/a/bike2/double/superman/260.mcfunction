data merge entity 7f895ae6-3a84-58c6-84f5-016612fdd486 {start_interpolation:0,transformation:{translation:[0f,1.893f,-0.654f],left_rotation:[0.6321f,0f,0f,0.7749f]}}
data merge entity d5b82b8d-86e1-5276-8680-ed7a08615c7a {start_interpolation:0,transformation:{translation:[0.18f,1.988f,-0.194f],left_rotation:[0.2521f,0.1479f,0.0731f,0.9535f],scale:[1f,1f,1.066f]}}
data merge entity a4c123d3-dfeb-5763-b680-e521fb79538b {start_interpolation:0,transformation:{translation:[-0.18f,1.988f,-0.194f],left_rotation:[0.2521f,-0.1479f,-0.0731f,0.9535f],scale:[1f,1f,1.066f]}}
data merge entity 14895439-b1c6-5868-83ed-85b5ca16af52 {start_interpolation:0,transformation:{translation:[0.095f,1.887f,-0.684f],left_rotation:[0.5704f,0.0258f,0.1063f,0.814f]}}
data merge entity ed503232-ebe9-57f4-8f88-a4efe27a7f4d {start_interpolation:0,transformation:{translation:[-0.095f,1.887f,-0.684f],left_rotation:[0.5704f,-0.0258f,-0.1063f,0.814f]}}
data merge entity 75e3c547-3dab-50d7-a8aa-ffff4a07edfb {start_interpolation:0,transformation:{translation:[0.158f,1.743f,-1.095f],left_rotation:[0.815f,0.0608f,0.0911f,0.569f]}}
data merge entity b4028d78-85e3-5bdd-b8d1-be173b14689d {start_interpolation:0,transformation:{translation:[-0.158f,1.743f,-1.095f],left_rotation:[0.815f,-0.0608f,-0.0911f,0.569f]}}
