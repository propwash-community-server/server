data merge entity 7f895ae6-3a84-58c6-84f5-016612fdd486 {start_interpolation:0,transformation:{translation:[0.017f,1.814f,0.131f],left_rotation:[0.486f,0.0603f,0.0053f,0.8719f]}}
data merge entity d5b82b8d-86e1-5276-8680-ed7a08615c7a {start_interpolation:0,transformation:{translation:[0.219f,2.074f,0.512f],left_rotation:[0.5774f,0.2508f,-0.1076f,0.7695f]}}
data merge entity a4c123d3-dfeb-5763-b680-e521fb79538b {start_interpolation:0,transformation:{translation:[-0.139f,2.049f,0.548f],left_rotation:[0.5763f,-0.3161f,0.0461f,0.7523f],scale:[1f,1f,1f]}}
data merge entity 14895439-b1c6-5868-83ed-85b5ca16af52 {start_interpolation:0,transformation:{translation:[0.11f,1.804f,0.096f],left_rotation:[-0.1846f,0.1152f,0.1081f,0.97f]}}
data merge entity ed503232-ebe9-57f4-8f88-a4efe27a7f4d {start_interpolation:0,transformation:{translation:[-0.079f,1.791f,0.115f],left_rotation:[-0.1933f,-0.1114f,-0.1224f,0.9671f]}}
data merge entity 75e3c547-3dab-50d7-a8aa-ffff4a07edfb {start_interpolation:0,transformation:{translation:[0.221f,1.405f,0.243f],left_rotation:[0.3584f,-0.0021f,-0.0303f,0.9331f]}}
data merge entity b4028d78-85e3-5bdd-b8d1-be173b14689d {start_interpolation:0,transformation:{translation:[-0.202f,1.397f,0.268f],left_rotation:[0.3814f,-0.0501f,0.0066f,0.923f]}}
