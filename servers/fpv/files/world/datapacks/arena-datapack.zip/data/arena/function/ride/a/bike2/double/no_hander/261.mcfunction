data merge entity 7f895ae6-3a84-58c6-84f5-016612fdd486 {start_interpolation:0,transformation:{translation:[0f,1.774f,-0.26f],left_rotation:[0.1127f,0f,0f,0.9936f]}}
data merge entity d5b82b8d-86e1-5276-8680-ed7a08615c7a {start_interpolation:0,transformation:{translation:[0.18f,2.232f,-0.155f],left_rotation:[-0.4306f,0.5066f,0.1941f,0.7213f]}}
data merge entity a4c123d3-dfeb-5763-b680-e521fb79538b {start_interpolation:0,transformation:{translation:[-0.18f,2.232f,-0.155f],left_rotation:[-0.4306f,-0.5066f,-0.1941f,0.7213f]}}
data merge entity 14895439-b1c6-5868-83ed-85b5ca16af52 {start_interpolation:0,transformation:{translation:[0.095f,1.745f,-0.267f],left_rotation:[-0.3689f,0.0468f,0.0799f,0.9248f]}}
data merge entity ed503232-ebe9-57f4-8f88-a4efe27a7f4d {start_interpolation:0,transformation:{translation:[-0.095f,1.745f,-0.267f],left_rotation:[-0.3689f,-0.0468f,-0.0799f,0.9248f]}}
data merge entity 75e3c547-3dab-50d7-a8aa-ffff4a07edfb {start_interpolation:0,transformation:{translation:[0.175f,1.431f,0.03f],left_rotation:[0.2578f,0.0036f,0.0144f,0.9661f]}}
data merge entity b4028d78-85e3-5bdd-b8d1-be173b14689d {start_interpolation:0,transformation:{translation:[-0.175f,1.431f,0.03f],left_rotation:[0.2578f,-0.0036f,-0.0144f,0.9661f]}}
