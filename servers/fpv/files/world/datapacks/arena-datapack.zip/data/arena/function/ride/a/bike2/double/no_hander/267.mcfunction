data merge entity 7f895ae6-3a84-58c6-84f5-016612fdd486 {start_interpolation:0,transformation:{translation:[0f,1.801f,0.049f],left_rotation:[0.235f,0f,0f,0.972f]}}
data merge entity d5b82b8d-86e1-5276-8680-ed7a08615c7a {start_interpolation:0,transformation:{translation:[0.18f,2.219f,0.264f],left_rotation:[-0.3375f,0.4785f,0.2551f,0.7694f]}}
data merge entity a4c123d3-dfeb-5763-b680-e521fb79538b {start_interpolation:0,transformation:{translation:[-0.18f,2.219f,0.264f],left_rotation:[-0.3375f,-0.4785f,-0.2551f,0.7694f]}}
data merge entity 14895439-b1c6-5868-83ed-85b5ca16af52 {start_interpolation:0,transformation:{translation:[0.095f,1.774f,0.035f],left_rotation:[-0.2515f,0.0366f,0.0851f,0.9634f]}}
data merge entity ed503232-ebe9-57f4-8f88-a4efe27a7f4d {start_interpolation:0,transformation:{translation:[-0.095f,1.774f,0.035f],left_rotation:[-0.2515f,-0.0366f,-0.0851f,0.9634f]}}
data merge entity 75e3c547-3dab-50d7-a8aa-ffff4a07edfb {start_interpolation:0,transformation:{translation:[0.175f,1.396f,0.246f],left_rotation:[0.3755f,0.0018f,0.0147f,0.9267f]}}
data merge entity b4028d78-85e3-5bdd-b8d1-be173b14689d {start_interpolation:0,transformation:{translation:[-0.175f,1.396f,0.246f],left_rotation:[0.3755f,-0.0018f,-0.0147f,0.9267f]}}
