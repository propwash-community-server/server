data merge entity 11ae4677-4219-56c2-add0-4c64d57ac56a {start_interpolation:0,transformation:{translation:[0f,1.777f,-0.251f],left_rotation:[0.1181f,0f,0f,0.993f]}}
data merge entity 7d2a9e32-11f2-50e1-9212-e206c5741830 {start_interpolation:0,transformation:{translation:[0.18f,2.233f,-0.141f],left_rotation:[-0.423f,0.5046f,0.1929f,0.7274f],scale:[1f,1f,0.982f]}}
data merge entity dde4ca15-7054-52aa-b829-17380091a80f {start_interpolation:0,transformation:{translation:[-0.18f,2.233f,-0.141f],left_rotation:[-0.423f,-0.5046f,-0.1929f,0.7274f],scale:[1f,1f,0.982f]}}
data merge entity f4c9c580-42de-5f18-958e-fe8f13f48db0 {start_interpolation:0,transformation:{translation:[0.095f,1.747f,-0.258f],left_rotation:[-0.3652f,0.047f,0.0802f,0.9263f]}}
data merge entity 593cd5be-38e3-598f-a4f4-75287916d917 {start_interpolation:0,transformation:{translation:[-0.095f,1.747f,-0.258f],left_rotation:[-0.3652f,-0.047f,-0.0802f,0.9263f]}}
data merge entity b93e033a-5262-5632-b8ab-3de10d1c99fe {start_interpolation:0,transformation:{translation:[0.175f,1.43f,0.036f],left_rotation:[0.2609f,0.0035f,0.0142f,0.9652f]}}
data merge entity e73b8616-4bc3-571b-bb40-c31cce9d3a8c {start_interpolation:0,transformation:{translation:[-0.175f,1.43f,0.036f],left_rotation:[0.2609f,-0.0035f,-0.0142f,0.9652f]}}
