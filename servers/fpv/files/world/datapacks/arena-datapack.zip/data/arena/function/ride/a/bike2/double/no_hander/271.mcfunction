data merge entity 7f895ae6-3a84-58c6-84f5-016612fdd486 {start_interpolation:0,transformation:{left_rotation:[0.535f,0f,0f,0.8448f]}}
data merge entity d5b82b8d-86e1-5276-8680-ed7a08615c7a {start_interpolation:0,transformation:{translation:[0.18f,2.026f,0.657f],left_rotation:[0.599f,0.2883f,-0.08f,0.7427f],scale:[1f,1f,1.026f]}}
data merge entity a4c123d3-dfeb-5763-b680-e521fb79538b {start_interpolation:0,transformation:{translation:[-0.18f,2.026f,0.657f],left_rotation:[0.599f,-0.2883f,0.08f,0.7427f],scale:[1f,1f,1.026f]}}
data merge entity 14895439-b1c6-5868-83ed-85b5ca16af52 {start_interpolation:0,transformation:{left_rotation:[-0.1164f,0.1005f,0.1095f,0.982f]}}
data merge entity ed503232-ebe9-57f4-8f88-a4efe27a7f4d {start_interpolation:0,transformation:{left_rotation:[-0.1164f,-0.1005f,-0.1095f,0.982f]}}
data merge entity 75e3c547-3dab-50d7-a8aa-ffff4a07edfb {start_interpolation:0,transformation:{left_rotation:[0.375f,0.0001f,-0.0097f,0.927f]}}
data merge entity b4028d78-85e3-5bdd-b8d1-be173b14689d {start_interpolation:0,transformation:{left_rotation:[0.375f,-0.0001f,0.0097f,0.927f]}}
