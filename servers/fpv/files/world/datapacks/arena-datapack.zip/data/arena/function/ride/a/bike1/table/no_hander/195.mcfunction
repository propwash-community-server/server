data merge entity 11ae4677-4219-56c2-add0-4c64d57ac56a {start_interpolation:0,transformation:{left_rotation:[0.3108f,0f,0f,0.9505f]}}
data merge entity 7d2a9e32-11f2-50e1-9212-e206c5741830 {start_interpolation:0,transformation:{translation:[0.18f,2.164f,-0.107f],left_rotation:[0.3953f,0.2614f,-0.1525f,0.8672f],scale:[1f,1f,1.028f]}}
data merge entity dde4ca15-7054-52aa-b829-17380091a80f {start_interpolation:0,transformation:{translation:[-0.18f,2.164f,-0.107f],left_rotation:[0.3953f,-0.2614f,0.1525f,0.8672f],scale:[1f,1f,1.028f]}}
data merge entity f4c9c580-42de-5f18-958e-fe8f13f48db0 {start_interpolation:0,transformation:{left_rotation:[-0.3524f,0.1216f,0.0829f,0.9242f]}}
data merge entity 593cd5be-38e3-598f-a4f4-75287916d917 {start_interpolation:0,transformation:{left_rotation:[-0.3524f,-0.1216f,-0.0829f,0.9242f]}}
data merge entity b93e033a-5262-5632-b8ab-3de10d1c99fe {start_interpolation:0,transformation:{translation:[0.2f,1.436f,-0.124f],left_rotation:[0.1471f,-0.0024f,-0.0097f,0.9891f]}}
data merge entity e73b8616-4bc3-571b-bb40-c31cce9d3a8c {start_interpolation:0,transformation:{translation:[-0.2f,1.436f,-0.124f],left_rotation:[0.1471f,0.0024f,0.0097f,0.9891f]}}
