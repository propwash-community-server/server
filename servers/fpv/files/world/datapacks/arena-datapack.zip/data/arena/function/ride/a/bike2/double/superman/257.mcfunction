data merge entity 7f895ae6-3a84-58c6-84f5-016612fdd486 {start_interpolation:0,transformation:{translation:[0f,1.782f,-0.585f],left_rotation:[0.417f,0f,0f,0.9089f]}}
data merge entity d5b82b8d-86e1-5276-8680-ed7a08615c7a {start_interpolation:0,transformation:{translation:[0.18f,2.088f,-0.229f],left_rotation:[0.3505f,0.1996f,-0.0323f,0.9145f],scale:[1f,1f,0.993f]}}
data merge entity a4c123d3-dfeb-5763-b680-e521fb79538b {start_interpolation:0,transformation:{translation:[-0.18f,2.088f,-0.229f],left_rotation:[0.3505f,-0.1996f,0.0323f,0.9145f],scale:[1f,1f,0.993f]}}
data merge entity 14895439-b1c6-5868-83ed-85b5ca16af52 {start_interpolation:0,transformation:{translation:[0.095f,1.762f,-0.608f],left_rotation:[-0.3393f,0.1871f,0.0435f,0.9208f]}}
data merge entity ed503232-ebe9-57f4-8f88-a4efe27a7f4d {start_interpolation:0,transformation:{translation:[-0.095f,1.762f,-0.608f],left_rotation:[-0.3393f,-0.1871f,-0.0435f,0.9208f]}}
data merge entity 75e3c547-3dab-50d7-a8aa-ffff4a07edfb {start_interpolation:0,transformation:{translation:[0.186f,1.425f,-0.34f],left_rotation:[-0.0443f,0.0697f,-0.0102f,0.9965f]}}
data merge entity b4028d78-85e3-5bdd-b8d1-be173b14689d {start_interpolation:0,transformation:{translation:[-0.186f,1.425f,-0.34f],left_rotation:[-0.0443f,-0.0697f,0.0102f,0.9965f]}}
