data merge entity 7f895ae6-3a84-58c6-84f5-016612fdd486 {start_interpolation:0,transformation:{translation:[0.05f,1.738f,-0.263f],left_rotation:[0.2827f,0.1854f,-0.0048f,0.9411f]}}
data merge entity d5b82b8d-86e1-5276-8680-ed7a08615c7a {start_interpolation:0,transformation:{translation:[0.271f,2.15f,-0.077f],left_rotation:[0.4222f,0.1741f,-0.1741f,0.8724f]}}
data merge entity a4c123d3-dfeb-5763-b680-e521fb79538b {start_interpolation:0,transformation:{translation:[-0.064f,2.116f,0.05f],left_rotation:[0.4316f,-0.3808f,0.0494f,0.8162f]}}
data merge entity 14895439-b1c6-5868-83ed-85b5ca16af52 {start_interpolation:0,transformation:{translation:[0.135f,1.722f,-0.312f],left_rotation:[-0.3894f,0.1447f,0.0909f,0.9051f]}}
data merge entity ed503232-ebe9-57f4-8f88-a4efe27a7f4d {start_interpolation:0,transformation:{translation:[-0.042f,1.704f,-0.245f],left_rotation:[0.5023f,-0.6073f,-0.1488f,0.5972f]}}
data merge entity 75e3c547-3dab-50d7-a8aa-ffff4a07edfb {start_interpolation:0,transformation:{translation:[0.257f,1.422f,-0.013f],left_rotation:[0.2401f,-0.0199f,-0.0654f,0.9683f]}}
data merge entity b4028d78-85e3-5bdd-b8d1-be173b14689d {start_interpolation:0,transformation:{translation:[0.148f,1.505f,-0.589f],left_rotation:[0.7162f,-0.6098f,0.1382f,0.3099f]}}
