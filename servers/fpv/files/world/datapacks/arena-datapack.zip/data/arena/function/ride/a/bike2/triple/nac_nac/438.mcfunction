data merge entity 7f895ae6-3a84-58c6-84f5-016612fdd486 {start_interpolation:0,transformation:{left_rotation:[0.2448f,0.0068f,-0.0015f,0.9696f]}}
data merge entity d5b82b8d-86e1-5276-8680-ed7a08615c7a {start_interpolation:0,transformation:{translation:[0.185f,2.107f,-0.371f],left_rotation:[0.3354f,0.239f,-0.1504f,0.8987f]}}
data merge entity a4c123d3-dfeb-5763-b680-e521fb79538b {start_interpolation:0,transformation:{translation:[-0.175f,2.107f,-0.366f],left_rotation:[0.3358f,-0.2487f,0.1455f,0.8968f]}}
data merge entity ed503232-ebe9-57f4-8f88-a4efe27a7f4d {start_interpolation:0,transformation:{translation:[-0.093f,1.667f,-0.605f]}}
data merge entity 75e3c547-3dab-50d7-a8aa-ffff4a07edfb {start_interpolation:0,transformation:{left_rotation:[0.0621f,-0.0052f,-0.0153f,0.9979f]}}
data merge entity b4028d78-85e3-5bdd-b8d1-be173b14689d {start_interpolation:0,transformation:{translation:[-0.204f,1.401f,-0.271f],left_rotation:[0.0648f,-0.0009f,0.0141f,0.9978f]}}
