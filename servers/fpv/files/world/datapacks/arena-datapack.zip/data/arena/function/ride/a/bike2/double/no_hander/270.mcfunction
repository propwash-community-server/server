data merge entity 7f895ae6-3a84-58c6-84f5-016612fdd486 {start_interpolation:0,transformation:{translation:[0f,1.82f,0.191f],left_rotation:[0.4657f,0f,0f,0.8849f]}}
data merge entity d5b82b8d-86e1-5276-8680-ed7a08615c7a {start_interpolation:0,transformation:{translation:[0.18f,2.087f,0.579f],left_rotation:[0.5117f,0.32f,-0.1281f,0.787f],scale:[1f,1f,0.969f]}}
data merge entity a4c123d3-dfeb-5763-b680-e521fb79538b {start_interpolation:0,transformation:{translation:[-0.18f,2.087f,0.579f],left_rotation:[0.5117f,-0.32f,0.1281f,0.787f],scale:[1f,1f,0.969f]}}
data merge entity 14895439-b1c6-5868-83ed-85b5ca16af52 {start_interpolation:0,transformation:{translation:[0.095f,1.803f,0.167f],left_rotation:[-0.1513f,0.0837f,0.1041f,0.9794f]}}
data merge entity ed503232-ebe9-57f4-8f88-a4efe27a7f4d {start_interpolation:0,transformation:{translation:[-0.095f,1.803f,0.167f],left_rotation:[-0.1513f,-0.0837f,-0.1041f,0.9794f]}}
data merge entity 75e3c547-3dab-50d7-a8aa-ffff4a07edfb {start_interpolation:0,transformation:{translation:[0.196f,1.393f,0.289f],left_rotation:[0.3795f,-0.0001f,-0.0058f,0.9252f]}}
data merge entity b4028d78-85e3-5bdd-b8d1-be173b14689d {start_interpolation:0,transformation:{translation:[-0.196f,1.393f,0.289f],left_rotation:[0.3795f,0.0001f,0.0058f,0.9252f]}}
