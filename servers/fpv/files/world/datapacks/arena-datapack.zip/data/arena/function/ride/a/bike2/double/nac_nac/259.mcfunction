data merge entity 7f895ae6-3a84-58c6-84f5-016612fdd486 {start_interpolation:0,transformation:{translation:[0.05f,1.734f,-0.28f],left_rotation:[0.2757f,0.1852f,-0.0062f,0.9432f]}}
data merge entity d5b82b8d-86e1-5276-8680-ed7a08615c7a {start_interpolation:0,transformation:{translation:[0.271f,2.149f,-0.101f],left_rotation:[0.4157f,0.1728f,-0.1754f,0.8755f]}}
data merge entity a4c123d3-dfeb-5763-b680-e521fb79538b {start_interpolation:0,transformation:{translation:[-0.064f,2.116f,0.026f],left_rotation:[0.4256f,-0.3804f,0.0522f,0.8194f]}}
data merge entity 14895439-b1c6-5868-83ed-85b5ca16af52 {start_interpolation:0,transformation:{translation:[0.135f,1.717f,-0.329f],left_rotation:[-0.3961f,0.1454f,0.0898f,0.9022f]}}
data merge entity ed503232-ebe9-57f4-8f88-a4efe27a7f4d {start_interpolation:0,transformation:{translation:[-0.042f,1.7f,-0.262f],left_rotation:[0.4952f,-0.6089f,-0.1468f,0.602f]}}
data merge entity 75e3c547-3dab-50d7-a8aa-ffff4a07edfb {start_interpolation:0,transformation:{translation:[0.257f,1.422f,-0.026f],left_rotation:[0.2328f,-0.0204f,-0.0652f,0.9701f]}}
data merge entity b4028d78-85e3-5bdd-b8d1-be173b14689d {start_interpolation:0,transformation:{translation:[0.146f,1.495f,-0.603f],left_rotation:[0.7138f,-0.6095f,0.1443f,0.3134f]}}
