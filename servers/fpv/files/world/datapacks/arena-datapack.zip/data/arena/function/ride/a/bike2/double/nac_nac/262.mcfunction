data merge entity 7f895ae6-3a84-58c6-84f5-016612fdd486 {start_interpolation:0,transformation:{translation:[0.05f,1.76f,-0.128f],left_rotation:[0.3349f,0.1854f,0.0056f,0.9238f]}}
data merge entity d5b82b8d-86e1-5276-8680-ed7a08615c7a {start_interpolation:0,transformation:{translation:[0.271f,2.148f,0.103f],left_rotation:[0.4704f,0.1836f,-0.1641f,0.8474f]}}
data merge entity a4c123d3-dfeb-5763-b680-e521fb79538b {start_interpolation:0,transformation:{translation:[-0.064f,2.1f,0.225f],left_rotation:[0.4767f,-0.383f,0.028f,0.7908f]}}
data merge entity 14895439-b1c6-5868-83ed-85b5ca16af52 {start_interpolation:0,transformation:{translation:[0.135f,1.749f,-0.179f],left_rotation:[-0.3381f,0.1394f,0.0988f,0.9255f]}}
data merge entity ed503232-ebe9-57f4-8f88-a4efe27a7f4d {start_interpolation:0,transformation:{translation:[-0.042f,1.724f,-0.115f],left_rotation:[0.535f,-0.598f,-0.1826f,0.5682f]}}
data merge entity 75e3c547-3dab-50d7-a8aa-ffff4a07edfb {start_interpolation:0,transformation:{translation:[0.257f,1.418f,0.084f],left_rotation:[0.294f,-0.0162f,-0.0664f,0.9534f]}}
data merge entity b4028d78-85e3-5bdd-b8d1-be173b14689d {start_interpolation:0,transformation:{translation:[0.148f,1.565f,-0.478f],left_rotation:[0.7325f,-0.6166f,0.1038f,0.2693f]}}
