data merge entity 7f895ae6-3a84-58c6-84f5-016612fdd486 {start_interpolation:0,transformation:{translation:[0.05f,1.766f,-0.024f],left_rotation:[0.3742f,0.1849f,0.0135f,0.9086f]}}
data merge entity d5b82b8d-86e1-5276-8680-ed7a08615c7a {start_interpolation:0,transformation:{translation:[0.271f,2.134f,0.239f],left_rotation:[0.5062f,0.1904f,-0.1561f,0.8265f]}}
data merge entity a4c123d3-dfeb-5763-b680-e521fb79538b {start_interpolation:0,transformation:{translation:[-0.064f,2.075f,0.357f],left_rotation:[0.5101f,-0.3838f,0.0115f,0.7696f]}}
data merge entity 14895439-b1c6-5868-83ed-85b5ca16af52 {start_interpolation:0,transformation:{translation:[0.135f,1.76f,-0.076f],left_rotation:[-0.2981f,0.135f,0.1047f,0.9391f]}}
data merge entity ed503232-ebe9-57f4-8f88-a4efe27a7f4d {start_interpolation:0,transformation:{translation:[-0.042f,1.729f,-0.014f],left_rotation:[0.5588f,-0.5897f,-0.2081f,0.5447f]}}
data merge entity 75e3c547-3dab-50d7-a8aa-ffff4a07edfb {start_interpolation:0,transformation:{translation:[0.257f,1.408f,0.158f],left_rotation:[0.3345f,-0.0133f,-0.067f,0.9399f]}}
data merge entity b4028d78-85e3-5bdd-b8d1-be173b14689d {start_interpolation:0,transformation:{translation:[0.148f,1.602f,-0.39f],left_rotation:[0.7433f,-0.6205f,0.0773f,0.2376f]}}
