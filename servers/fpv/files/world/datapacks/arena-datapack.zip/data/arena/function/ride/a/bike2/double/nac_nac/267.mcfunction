data merge entity 7f895ae6-3a84-58c6-84f5-016612fdd486 {start_interpolation:0,transformation:{translation:[0.05f,1.761f,0.121f],left_rotation:[0.4278f,0.1838f,0.0245f,0.8847f]}}
data merge entity d5b82b8d-86e1-5276-8680-ed7a08615c7a {start_interpolation:0,transformation:{translation:[0.271f,2.094f,0.426f],left_rotation:[0.5547f,0.1994f,-0.1444f,0.7948f]}}
data merge entity a4c123d3-dfeb-5763-b680-e521fb79538b {start_interpolation:0,transformation:{translation:[-0.064f,2.022f,0.536f],left_rotation:[0.5552f,-0.3838f,-0.0114f,0.7378f]}}
data merge entity 14895439-b1c6-5868-83ed-85b5ca16af52 {start_interpolation:0,transformation:{translation:[0.135f,1.761f,0.069f],left_rotation:[-0.2415f,0.1285f,0.1126f,0.9552f]}}
data merge entity ed503232-ebe9-57f4-8f88-a4efe27a7f4d {start_interpolation:0,transformation:{translation:[-0.042f,1.722f,0.127f],left_rotation:[0.5904f,-0.5762f,-0.2429f,0.5104f]}}
data merge entity 75e3c547-3dab-50d7-a8aa-ffff4a07edfb {start_interpolation:0,transformation:{translation:[0.257f,1.383f,0.259f],left_rotation:[0.3901f,-0.0093f,-0.0677f,0.9183f]}}
data merge entity b4028d78-85e3-5bdd-b8d1-be173b14689d {start_interpolation:0,transformation:{translation:[0.148f,1.641f,-0.261f],left_rotation:[0.7562f,-0.624f,0.0401f,0.1928f]}}
