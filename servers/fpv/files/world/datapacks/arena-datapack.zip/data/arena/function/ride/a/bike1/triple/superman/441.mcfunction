data merge entity 11ae4677-4219-56c2-add0-4c64d57ac56a {start_interpolation:0,transformation:{translation:[0f,1.83f,0.268f],left_rotation:[0.5788f,0f,0f,0.8155f]}}
data merge entity 7d2a9e32-11f2-50e1-9212-e206c5741830 {start_interpolation:0,transformation:{translation:[0.18f,1.985f,0.712f],left_rotation:[0.6247f,0.2713f,-0.0477f,0.7307f],scale:[1f,1f,1.009f]}}
data merge entity dde4ca15-7054-52aa-b829-17380091a80f {start_interpolation:0,transformation:{translation:[-0.18f,1.985f,0.712f],left_rotation:[0.6247f,-0.2713f,0.0477f,0.7307f],scale:[1f,1f,1.009f]}}
data merge entity f4c9c580-42de-5f18-958e-fe8f13f48db0 {start_interpolation:0,transformation:{translation:[0.095f,1.82f,0.24f],left_rotation:[-0.0864f,0.1083f,0.1084f,0.9844f]}}
data merge entity 593cd5be-38e3-598f-a4f4-75287916d917 {start_interpolation:0,transformation:{translation:[-0.095f,1.82f,0.24f],left_rotation:[-0.0864f,-0.1083f,-0.1084f,0.9844f]}}
data merge entity b93e033a-5262-5632-b8ab-3de10d1c99fe {start_interpolation:0,transformation:{translation:[0.197f,1.397f,0.304f],left_rotation:[0.3672f,0.0084f,-0.0059f,0.9301f]}}
data merge entity e73b8616-4bc3-571b-bb40-c31cce9d3a8c {start_interpolation:0,transformation:{translation:[-0.197f,1.397f,0.304f],left_rotation:[0.3672f,-0.0084f,0.0059f,0.9301f]}}
