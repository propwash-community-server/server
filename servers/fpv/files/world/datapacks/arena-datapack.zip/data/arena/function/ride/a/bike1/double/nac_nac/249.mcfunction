data merge entity 11ae4677-4219-56c2-add0-4c64d57ac56a {start_interpolation:0,transformation:{translation:[-0.05f,1.766f,0.015f],left_rotation:[0.3888f,-0.1847f,-0.0165f,0.9025f]}}
data merge entity 7d2a9e32-11f2-50e1-9212-e206c5741830 {start_interpolation:0,transformation:{translation:[0.064f,2.063f,0.405f],left_rotation:[0.5225f,0.384f,-0.0053f,0.7613f]}}
data merge entity dde4ca15-7054-52aa-b829-17380091a80f {start_interpolation:0,transformation:{translation:[-0.271f,2.125f,0.29f],left_rotation:[0.5195f,-0.1929f,0.153f,0.8182f]}}
data merge entity f4c9c580-42de-5f18-958e-fe8f13f48db0 {start_interpolation:0,transformation:{translation:[0.042f,1.729f,0.024f],left_rotation:[0.5675f,0.5862f,0.2175f,0.5357f]}}
data merge entity 593cd5be-38e3-598f-a4f4-75287916d917 {start_interpolation:0,transformation:{translation:[-0.135f,1.762f,-0.037f],left_rotation:[-0.283f,-0.1333f,-0.1069f,0.9438f]}}
data merge entity b93e033a-5262-5632-b8ab-3de10d1c99fe {start_interpolation:0,transformation:{translation:[-0.148f,1.614f,-0.355f],left_rotation:[0.7471f,0.6217f,-0.0673f,0.2256f]}}
data merge entity e73b8616-4bc3-571b-bb40-c31cce9d3a8c {start_interpolation:0,transformation:{translation:[-0.257f,1.403f,0.186f],left_rotation:[0.3496f,0.0123f,0.0672f,0.9344f]}}
