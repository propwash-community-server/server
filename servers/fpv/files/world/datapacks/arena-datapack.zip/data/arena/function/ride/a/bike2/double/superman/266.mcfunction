data merge entity 7f895ae6-3a84-58c6-84f5-016612fdd486 {start_interpolation:0,transformation:{translation:[0f,2.015f,-0.298f],left_rotation:[0.7253f,0f,0f,0.6884f]}}
data merge entity d5b82b8d-86e1-5276-8680-ed7a08615c7a {start_interpolation:0,transformation:{translation:[0.18f,1.99f,0.171f],left_rotation:[0.3696f,0.1374f,0.0912f,0.9144f]}}
data merge entity a4c123d3-dfeb-5763-b680-e521fb79538b {start_interpolation:0,transformation:{translation:[-0.18f,1.99f,0.171f],left_rotation:[0.3696f,-0.1374f,-0.0912f,0.9144f]}}
data merge entity 14895439-b1c6-5868-83ed-85b5ca16af52 {start_interpolation:0,transformation:{translation:[0.095f,2.016f,-0.328f],left_rotation:[0.6972f,0.016f,0.1079f,0.7085f]}}
data merge entity ed503232-ebe9-57f4-8f88-a4efe27a7f4d {start_interpolation:0,transformation:{translation:[-0.095f,2.016f,-0.328f],left_rotation:[0.6972f,-0.016f,-0.1079f,0.7085f]}}
data merge entity 75e3c547-3dab-50d7-a8aa-ffff4a07edfb {start_interpolation:0,transformation:{translation:[0.153f,2.014f,-0.765f],left_rotation:[0.8682f,0.0457f,0.0991f,0.484f]}}
data merge entity b4028d78-85e3-5bdd-b8d1-be173b14689d {start_interpolation:0,transformation:{translation:[-0.153f,2.014f,-0.765f],left_rotation:[0.8682f,-0.0457f,-0.0991f,0.484f]}}
