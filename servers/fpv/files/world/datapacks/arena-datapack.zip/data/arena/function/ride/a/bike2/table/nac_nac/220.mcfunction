data merge entity 7f895ae6-3a84-58c6-84f5-016612fdd486 {start_interpolation:0,transformation:{translation:[0.033f,1.789f,0.108f],left_rotation:[0.4502f,0.1208f,0.0126f,0.8846f]}}
data merge entity d5b82b8d-86e1-5276-8680-ed7a08615c7a {start_interpolation:0,transformation:{translation:[0.249f,2.092f,0.447f],left_rotation:[0.5615f,0.2227f,-0.1315f,0.786f]}}
data merge entity a4c123d3-dfeb-5763-b680-e521fb79538b {start_interpolation:0,transformation:{translation:[-0.101f,2.045f,0.52f],left_rotation:[0.5611f,-0.3494f,0.0197f,0.7501f]}}
data merge entity 14895439-b1c6-5868-83ed-85b5ca16af52 {start_interpolation:0,transformation:{translation:[0.123f,1.784f,0.064f],left_rotation:[-0.2218f,0.1226f,0.1091f,0.9612f]}}
data merge entity ed503232-ebe9-57f4-8f88-a4efe27a7f4d {start_interpolation:0,transformation:{translation:[-0.062f,1.759f,0.103f],left_rotation:[0.0246f,-0.8709f,-0.4907f,0.0111f]}}
data merge entity 75e3c547-3dab-50d7-a8aa-ffff4a07edfb {start_interpolation:0,transformation:{translation:[0.239f,1.398f,0.24f],left_rotation:[0.3687f,-0.0054f,-0.049f,0.9282f]}}
data merge entity b4028d78-85e3-5bdd-b8d1-be173b14689d {start_interpolation:0,transformation:{translation:[-0.048f,1.531f,-0.274f],left_rotation:[0.024f,-0.9724f,0.2322f,-0.0021f]}}
