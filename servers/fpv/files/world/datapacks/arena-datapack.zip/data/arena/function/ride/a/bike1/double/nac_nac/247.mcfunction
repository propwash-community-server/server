data merge entity 11ae4677-4219-56c2-add0-4c64d57ac56a {start_interpolation:0,transformation:{translation:[-0.05f,1.763f,-0.088f],left_rotation:[0.3502f,-0.1852f,-0.0086f,0.9181f]}}
data merge entity 7d2a9e32-11f2-50e1-9212-e206c5741830 {start_interpolation:0,transformation:{translation:[0.064f,2.092f,0.276f],left_rotation:[0.4897f,0.3834f,-0.0216f,0.7828f]}}
data merge entity dde4ca15-7054-52aa-b829-17380091a80f {start_interpolation:0,transformation:{translation:[-0.271f,2.144f,0.156f],left_rotation:[0.4843f,-0.1863f,0.161f,0.8395f]}}
data merge entity f4c9c580-42de-5f18-958e-fe8f13f48db0 {start_interpolation:0,transformation:{translation:[0.042f,1.727f,-0.076f],left_rotation:[0.5443f,0.5949f,0.1925f,0.5592f]}}
data merge entity 593cd5be-38e3-598f-a4f4-75287916d917 {start_interpolation:0,transformation:{translation:[-0.135f,1.755f,-0.139f],left_rotation:[-0.3227f,-0.1377f,-0.1011f,0.9309f]}}
data merge entity b93e033a-5262-5632-b8ab-3de10d1c99fe {start_interpolation:0,transformation:{translation:[-0.148f,1.58f,-0.444f],left_rotation:[0.7368f,0.6182f,-0.0936f,0.2571f]}}
data merge entity e73b8616-4bc3-571b-bb40-c31cce9d3a8c {start_interpolation:0,transformation:{translation:[-0.257f,1.415f,0.113f],left_rotation:[0.3097f,0.0151f,0.0666f,0.9484f]}}
