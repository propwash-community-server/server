data merge entity 11ae4677-4219-56c2-add0-4c64d57ac56a {start_interpolation:0,transformation:{translation:[0f,1.798f,-0.099f],left_rotation:[0.177f,0f,0f,0.9842f]}}
data merge entity 7d2a9e32-11f2-50e1-9212-e206c5741830 {start_interpolation:0,transformation:{translation:[0.18f,2.238f,0.065f],left_rotation:[-0.3829f,0.4929f,0.2266f,0.7477f]}}
data merge entity dde4ca15-7054-52aa-b829-17380091a80f {start_interpolation:0,transformation:{translation:[-0.18f,2.238f,0.065f],left_rotation:[-0.3829f,-0.4929f,-0.2266f,0.7477f]}}
data merge entity f4c9c580-42de-5f18-958e-fe8f13f48db0 {start_interpolation:0,transformation:{translation:[0.095f,1.77f,-0.11f],left_rotation:[-0.3081f,0.0416f,0.0827f,0.9468f]}}
data merge entity 593cd5be-38e3-598f-a4f4-75287916d917 {start_interpolation:0,transformation:{translation:[-0.095f,1.77f,-0.11f],left_rotation:[-0.3081f,-0.0416f,-0.0827f,0.9468f]}}
data merge entity b93e033a-5262-5632-b8ab-3de10d1c99fe {start_interpolation:0,transformation:{translation:[0.175f,1.419f,0.144f],left_rotation:[0.32f,0.0026f,0.0146f,0.9473f]}}
data merge entity e73b8616-4bc3-571b-bb40-c31cce9d3a8c {start_interpolation:0,transformation:{translation:[-0.175f,1.419f,0.144f],left_rotation:[0.32f,-0.0026f,-0.0146f,0.9473f]}}
