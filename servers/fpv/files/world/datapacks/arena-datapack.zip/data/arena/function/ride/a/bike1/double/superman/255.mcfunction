data merge entity 11ae4677-4219-56c2-add0-4c64d57ac56a {start_interpolation:0,transformation:{translation:[0f,1.922f,0.1f],left_rotation:[0.6548f,0f,0f,0.7558f]}}
data merge entity 7d2a9e32-11f2-50e1-9212-e206c5741830 {start_interpolation:0,transformation:{translation:[0.18f,1.989f,0.565f],left_rotation:[0.5687f,0.1904f,0.0335f,0.7995f],scale:[1f,1f,0.993f]}}
data merge entity dde4ca15-7054-52aa-b829-17380091a80f {start_interpolation:0,transformation:{translation:[-0.18f,1.989f,0.565f],left_rotation:[0.5687f,-0.1904f,-0.0335f,0.7995f],scale:[1f,1f,0.993f]}}
data merge entity f4c9c580-42de-5f18-958e-fe8f13f48db0 {start_interpolation:0,transformation:{translation:[0.095f,1.918f,0.07f],left_rotation:[-0.1006f,0.1875f,0.094f,0.9726f]}}
data merge entity 593cd5be-38e3-598f-a4f4-75287916d917 {start_interpolation:0,transformation:{translation:[-0.095f,1.918f,0.07f],left_rotation:[-0.1006f,-0.1875f,-0.094f,0.9726f]}}
data merge entity b93e033a-5262-5632-b8ab-3de10d1c99fe {start_interpolation:0,transformation:{translation:[0.192f,1.495f,0.14f],left_rotation:[0.2096f,0.09f,0.0055f,0.9736f]}}
data merge entity e73b8616-4bc3-571b-bb40-c31cce9d3a8c {start_interpolation:0,transformation:{translation:[-0.192f,1.495f,0.14f],left_rotation:[0.2096f,-0.09f,-0.0055f,0.9736f]}}
