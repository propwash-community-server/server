time set 6000
tellraw @s {"text":"Noon.","color":"gray"}
