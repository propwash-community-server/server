data merge entity 7f895ae6-3a84-58c6-84f5-016612fdd486 {start_interpolation:0,transformation:{translation:[0.05f,1.766f,-0.012f],left_rotation:[0.3788f,0.1849f,0.0144f,0.9067f]}}
data merge entity d5b82b8d-86e1-5276-8680-ed7a08615c7a {start_interpolation:0,transformation:{translation:[0.271f,2.131f,0.255f],left_rotation:[0.5104f,0.1912f,-0.1551f,0.8239f]}}
data merge entity a4c123d3-dfeb-5763-b680-e521fb79538b {start_interpolation:0,transformation:{translation:[-0.064f,2.072f,0.372f],left_rotation:[0.514f,-0.3839f,0.0096f,0.767f]}}
data merge entity 14895439-b1c6-5868-83ed-85b5ca16af52 {start_interpolation:0,transformation:{translation:[0.135f,1.761f,-0.063f],left_rotation:[-0.2934f,0.1345f,0.1054f,0.9406f]}}
data merge entity ed503232-ebe9-57f4-8f88-a4efe27a7f4d {start_interpolation:0,transformation:{translation:[-0.042f,1.729f,-0.002f],left_rotation:[0.5616f,-0.5886f,-0.211f,0.5419f]}}
data merge entity 75e3c547-3dab-50d7-a8aa-ffff4a07edfb {start_interpolation:0,transformation:{translation:[0.257f,1.406f,0.167f],left_rotation:[0.3393f,-0.013f,-0.0671f,0.9382f]}}
data merge entity b4028d78-85e3-5bdd-b8d1-be173b14689d {start_interpolation:0,transformation:{translation:[0.148f,1.606f,-0.379f],left_rotation:[0.7445f,-0.6209f,0.0742f,0.2339f]}}
