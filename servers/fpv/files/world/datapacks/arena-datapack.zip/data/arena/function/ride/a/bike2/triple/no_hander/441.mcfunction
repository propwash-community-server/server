data merge entity 7f895ae6-3a84-58c6-84f5-016612fdd486 {start_interpolation:0,transformation:{translation:[0f,1.711f,-0.476f],left_rotation:[0.0395f,0f,0f,0.9992f]}}
data merge entity d5b82b8d-86e1-5276-8680-ed7a08615c7a {start_interpolation:0,transformation:{translation:[0.18f,2.179f,-0.439f],left_rotation:[-0.444f,0.5059f,0.1152f,0.7305f],scale:[1f,1f,0.844f]}}
data merge entity a4c123d3-dfeb-5763-b680-e521fb79538b {start_interpolation:0,transformation:{translation:[-0.18f,2.179f,-0.439f],left_rotation:[-0.444f,-0.5059f,-0.1152f,0.7305f],scale:[1f,1f,0.844f]}}
data merge entity 14895439-b1c6-5868-83ed-85b5ca16af52 {start_interpolation:0,transformation:{translation:[0.095f,1.681f,-0.479f],left_rotation:[-0.4475f,0.0585f,0.0759f,0.8891f]}}
data merge entity ed503232-ebe9-57f4-8f88-a4efe27a7f4d {start_interpolation:0,transformation:{translation:[-0.095f,1.681f,-0.479f],left_rotation:[-0.4475f,-0.0585f,-0.0759f,0.8891f]}}
data merge entity 75e3c547-3dab-50d7-a8aa-ffff4a07edfb {start_interpolation:0,transformation:{translation:[0.177f,1.422f,-0.132f],left_rotation:[0.166f,0.0041f,0.0119f,0.986f]}}
data merge entity b4028d78-85e3-5bdd-b8d1-be173b14689d {start_interpolation:0,transformation:{translation:[-0.177f,1.422f,-0.132f],left_rotation:[0.166f,-0.0041f,-0.0119f,0.986f]}}
