tp @e[type=minecraft:item_display,tag=drift.kaze] -85.14 65 -43.326 14.9 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0028f,-0.0001f,0.0223f,0.9997f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.9303f,-0.1206f,-0.2444f,0.2453f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.2715f,0.2724f,-0.9228f,0.0235f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.6724f,-0.0088f,0.0097f,0.7401f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.0097f,-0.7401f,0.6724f,0.0088f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4079f,0.8433f,0.1052f],left_rotation:[0.1414f,0.1241f,-0.6144f,0.7663f]}}
particle minecraft:campfire_cosy_smoke -83.46 65.12 -44.64 0.071 0.022 0.004 1 0 force
particle minecraft:cloud -83.46 65.32 -44.64 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -83.46 65.42 -44.64 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke -85.06 65.12 -45.13 -0.011 0.022 -0.03 1 0 force
particle minecraft:cloud -85.06 65.32 -45.13 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -85.06 65.42 -45.13 0.45 0.2 0.45 0.008 1 force
tp @e[type=minecraft:item_display,tag=drift.onyx] -76.991 65 -46.95 38.66 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0.0059f,0.0001f,0.0223f,0.9997f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.3839f,-0.2647f,0.1776f,0.8666f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.0875f,0.8527f,0.4138f,0.3065f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.6724f,-0.0088f,0.0097f,0.7401f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.0097f,-0.7401f,0.6724f,0.0088f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4078f,0.8397f,0.2601f],left_rotation:[0.1891f,0.0537f,-0.2256f,0.9542f]}}
particle minecraft:campfire_cosy_smoke -74.69 65.12 -47.53 0.066 0.022 0.024 1 0 force
particle minecraft:cloud -74.69 65.32 -47.53 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -74.69 65.42 -47.53 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke -75.99 65.12 -48.64 0.008 0.022 -0.033 1 0 force
particle minecraft:cloud -75.99 65.32 -48.64 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -75.99 65.42 -48.64 0.45 0.2 0.45 0.008 1 force
