tp @e[type=minecraft:item_display,tag=drift.kaze] -56.431 65 -39.19 94.11 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0.0112f,0.0002f,0.0216f,0.9997f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.9078f,-0.0371f,0.2684f,0.3201f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.2362f,0.2937f,0.9167f,0.1327f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.3631f,-0.0048f,0.0122f,0.9317f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.0122f,-0.9317f,0.3631f,0.0048f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4067f,0.8405f,0.1293f],left_rotation:[0.1498f,0.1353f,-0.6245f,0.7545f]}}
particle minecraft:campfire_cosy_smoke -54.55 65.12 -37.63 0.026 0.022 0.069 1 0 force
particle minecraft:cloud -54.55 65.32 -37.63 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -54.55 65.42 -37.63 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke -54.37 65.12 -39.29 0.031 0.022 -0.004 1 0 force
particle minecraft:cloud -54.37 65.32 -39.29 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -54.37 65.42 -39.29 0.45 0.2 0.45 0.008 1 force
tp @e[type=minecraft:item_display,tag=drift.onyx] -47.115 65 -29.055 126.42 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0059f,0f,0.0026f,1f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.9886f,-0.0608f,-0.1213f,0.0647f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.1288f,-0.0778f,0.9877f,0.0428f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.3631f,-0.0048f,0.0122f,0.9317f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.0122f,-0.9317f,0.3631f,0.0048f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.3745f,0.8609f,0.2399f],left_rotation:[0.0789f,-0.1674f,0.8911f,0.4143f]}}
particle minecraft:campfire_cosy_smoke -46.04 65.12 -26.67 0 0.016 0.073 1 0 force
particle minecraft:cloud -46.04 65.32 -26.67 0.35 0.18 0.35 0.02 1 force
particle minecraft:campfire_cosy_smoke -44.95 65.12 -27.99 0.051 0.016 0.007 1 0 force
particle minecraft:cloud -44.95 65.32 -27.99 0.35 0.18 0.35 0.02 1 force
