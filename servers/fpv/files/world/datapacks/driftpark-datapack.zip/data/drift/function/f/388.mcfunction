tp @e[type=minecraft:item_display,tag=drift.kaze] -68.776 65 -45.525 64.52 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0002f,0f,0.0223f,0.9998f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.6907f,-0.1461f,0.2285f,0.6703f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.1593f,0.65f,0.7099f,0.2195f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.915f,0.012f,0.0053f,0.4033f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.0053f,0.4033f,0.915f,0.012f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4079f,0.8427f,0.1097f],left_rotation:[0.1418f,0.1275f,-0.6233f,0.7584f]}}
particle minecraft:campfire_cosy_smoke -66.49 65.12 -45.11 0.06 0.022 0.04 1 0 force
particle minecraft:cloud -66.49 65.32 -45.11 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -66.49 65.42 -45.11 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke -67.16 65.12 -46.64 0.017 0.022 -0.029 1 0 force
particle minecraft:cloud -67.16 65.32 -46.64 0.35 0.18 0.35 0.02 3 force
tp @e[type=minecraft:item_display,tag=drift.onyx] -58.583 65 -42.001 82.27 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0.0092f,0.0002f,0.0222f,0.9997f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.0185f,-0.3017f,0.0608f,0.9513f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.0389f,0.9501f,0.0503f,0.3053f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.915f,0.012f,0.0053f,0.4033f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.0053f,0.4033f,0.915f,0.012f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4077f,0.838f,0.2658f],left_rotation:[0.1854f,0.0746f,-0.3251f,0.9243f]}}
particle minecraft:campfire_cosy_smoke -56.4 65.12 -40.81 0.042 0.022 0.056 1 0 force
particle minecraft:cloud -56.4 65.32 -40.81 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -56.58 65.12 -42.51 0.034 0.022 -0.009 1 0 force
particle minecraft:cloud -56.58 65.32 -42.51 0.35 0.18 0.35 0.02 3 force
