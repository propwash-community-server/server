tp @e[type=minecraft:item_display,tag=drift.kaze] 34.452 65 -50.102 59.03 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0.0029f,0.0001f,0.0223f,0.9997f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.944f,-0.1061f,-0.1983f,0.2415f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.2247f,0.2637f,-0.938f,0.0075f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.971f,-0.0127f,0.0031f,0.2386f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.0031f,-0.2386f,0.971f,0.0127f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4079f,0.842f,0.115f],left_rotation:[0.0748f,0.1786f,-0.8871f,0.4189f]}}
particle minecraft:campfire_cosy_smoke 36.92 65.12 -50.02 0.066 0.022 0.027 1 0 force
particle minecraft:cloud 36.92 65.32 -50.02 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 36.1 65.12 -51.47 0.033 0.022 -0.038 1 0 force
particle minecraft:cloud 36.1 65.32 -51.47 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 36.1 65.42 -51.47 0.45 0.2 0.45 0.008 1 force
tp @e[type=minecraft:item_display,tag=drift.onyx] 48.209 65 -48.863 75.83 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0.0094f,0.0002f,0.0223f,0.9997f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.1299f,-0.2345f,0.0226f,0.9631f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.0785f,0.9661f,-0.1059f,0.2221f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.971f,-0.0127f,0.0031f,0.2386f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.0031f,-0.2386f,0.971f,0.0127f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4077f,0.8379f,0.2661f],left_rotation:[0.0957f,0.1756f,-0.8387f,0.5065f]}}
particle minecraft:campfire_cosy_smoke 50.81 65.12 -47.99 0.053 0.022 0.062 1 0 force
particle minecraft:cloud 50.81 65.32 -47.99 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 50.81 65.42 -47.99 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke 50.44 65.12 -49.65 0.036 0.022 -0.028 1 0 force
particle minecraft:cloud 50.44 65.32 -49.65 0.35 0.18 0.35 0.02 3 force
