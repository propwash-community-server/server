tp @e[type=minecraft:item_display,tag=drift.kaze] 87.489 65 21.861 171.86 0
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.8714f,-0.1353f,-0.1464f,0.4483f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.1943f,0.4662f,-0.8619f,0.0445f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.89f,-0.0117f,0.006f,0.4558f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.006f,-0.4558f,0.89f,0.0117f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4079f,0.8431f,0.1069f],left_rotation:[0.029f,0.1868f,-0.9627f,0.1937f]}}
particle minecraft:campfire_cosy_smoke 86.49 65.12 24.25 -0.058 0.022 0.063 1 0 force
particle minecraft:cloud 86.49 65.32 24.25 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke 86.49 65.42 24.25 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke 88.14 65.12 24.05 0.021 0.022 0.044 1 0 force
particle minecraft:cloud 88.14 65.32 24.05 0.35 0.18 0.35 0.02 2 force
tp @e[type=minecraft:item_display,tag=drift.onyx] 81.815 65 35.214 -175.62 0
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.3941f,-0.2255f,-0.0412f,0.89f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.1349f,0.8992f,-0.3726f,0.1854f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.89f,-0.0117f,0.006f,0.4558f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.006f,-0.4558f,0.89f,0.0117f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4078f,0.8408f,0.2565f],left_rotation:[0.0826f,0.1761f,-0.8686f,0.4557f]}}
particle minecraft:campfire_cosy_smoke 80.2 65.12 37.41 -0.066 0.022 0.033 1 0 force
particle minecraft:cloud 80.2 65.32 37.41 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 80.2 65.42 37.41 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke 81.9 65.12 37.57 0.013 0.022 0.046 1 0 force
particle minecraft:cloud 81.9 65.32 37.57 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 81.9 65.42 37.57 0.45 0.2 0.45 0.008 1 force
