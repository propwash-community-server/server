tp @e[type=minecraft:item_display,tag=drift.kaze] 46.947 65 -48.361 77.94 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0.0089f,0.0002f,0.0223f,0.9997f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.5054f,-0.147f,0.1512f,0.8367f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.0641f,0.8255f,0.5236f,0.2009f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.5091f,0.0067f,0.0113f,0.8606f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.0113f,0.8606f,0.5091f,0.0067f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4078f,0.8406f,0.1254f],left_rotation:[0.052f,0.1927f,-0.9337f,0.2971f]}}
particle minecraft:campfire_cosy_smoke 49.41 65.12 -47.48 0.06 0.022 0.048 1 0 force
particle minecraft:cloud 49.41 65.32 -47.48 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 49.1 65.12 -49.12 0.043 0.022 -0.029 1 0 force
particle minecraft:cloud 49.1 65.32 -49.12 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 49.1 65.42 -49.12 0.45 0.2 0.45 0.008 1 force
tp @e[type=minecraft:item_display,tag=drift.onyx] 62.292 65 -42.396 93.32 0
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.9739f,-0.0715f,-0.196f,0.0889f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.2065f,-0.1099f,0.9718f,0.0304f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.5091f,0.0067f,0.0113f,0.8606f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.0113f,0.8606f,0.5091f,0.0067f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.408f,0.8456f,0.2399f],left_rotation:[0.0445f,0.1796f,-0.9425f,0.2785f]}}
particle minecraft:campfire_cosy_smoke 64.7 65.12 -40.81 0.054 0.022 0.074 1 0 force
particle minecraft:cloud 64.7 65.32 -40.81 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke 64.83 65.12 -42.52 0.054 0.022 -0.001 1 0 force
particle minecraft:cloud 64.83 65.32 -42.52 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke 64.83 65.42 -42.52 0.45 0.2 0.45 0.008 1 force
