tp @e[type=minecraft:item_display,tag=drift.kaze] 90.091 65 4.109 152.76 0
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.7514f,-0.1624f,-0.1107f,0.6299f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.1775f,0.645f,-0.7385f,0.0843f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.7687f,-0.0101f,0.0084f,0.6395f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.0084f,-0.6395f,0.7687f,0.0101f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4079f,0.8426f,0.1104f],left_rotation:[0.0242f,0.1895f,-0.9672f,0.1675f]}}
particle minecraft:campfire_cosy_smoke 89.93 65.12 6.72 -0.042 0.021 0.07 1 0 force
particle minecraft:cloud 89.93 65.32 6.72 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke 89.93 65.42 6.72 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke 91.43 65.12 5.98 0.035 0.021 0.042 1 0 force
particle minecraft:cloud 91.43 65.32 5.98 0.35 0.18 0.35 0.02 2 force
tp @e[type=minecraft:item_display,tag=drift.onyx] 89.212 65 19.065 164.92 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0015f,0f,0.0223f,0.9998f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.1018f,-0.2224f,0.0306f,0.9691f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.0711f,0.9713f,-0.079f,0.213f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.7687f,-0.0101f,0.0084f,0.6395f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.0084f,-0.6395f,0.7687f,0.0101f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4079f,0.8434f,0.2475f],left_rotation:[0.0726f,0.1749f,-0.8892f,0.4165f]}}
particle minecraft:campfire_cosy_smoke 88.45 65.12 21.68 -0.049 0.022 0.064 1 0 force
particle minecraft:cloud 88.45 65.32 21.68 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 88.45 65.42 21.68 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke 90.11 65.12 21.27 0.016 0.022 0.04 1 0 force
particle minecraft:cloud 90.11 65.32 21.27 0.35 0.18 0.35 0.02 3 force
