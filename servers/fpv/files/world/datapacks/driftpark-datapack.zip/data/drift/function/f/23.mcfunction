tp @e[type=minecraft:item_display,tag=drift.kaze] -24.704 65 64.458 -91.7 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.001f,0f,0.007f,1f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.977f,-0.0514f,0.0098f,0.2065f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.0119f,-0.2066f,0.977f,0.051f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.9787f,-0.0128f,0.0027f,0.2047f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.0027f,-0.2047f,0.9787f,0.0128f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.382f,0.855f,0.1082f],left_rotation:[0.1898f,-0.0005f,0.0162f,0.9817f]}}
tp @e[type=minecraft:item_display,tag=drift.onyx] -42.126 65 64.3 -101.36 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0059f,-0.0001f,0.0162f,0.9999f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.9387f,-0.0921f,-0.1089f,0.3138f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.1425f,-0.327f,0.9342f,0.0061f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.9787f,-0.0128f,0.0027f,0.2047f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.0027f,-0.2047f,0.9787f,0.0128f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.3977f,0.8504f,0.2399f],left_rotation:[0.0697f,-0.1714f,0.9218f,0.3405f]}}
particle minecraft:campfire_cosy_smoke -44.85 65.12 63.63 -0.074 0.017 -0.043 1 0 force
particle minecraft:cloud -44.85 65.32 63.63 0.35 0.18 0.35 0.02 1 force
particle minecraft:campfire_cosy_smoke -44.5 65.12 65.31 -0.052 0.017 0.034 1 0 force
particle minecraft:cloud -44.5 65.32 65.31 0.35 0.18 0.35 0.02 1 force
