tp @e[type=minecraft:item_display,tag=drift.kaze] 85.629 65 26.688 177.34 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0021f,0f,0.0223f,0.9998f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.9549f,-0.0952f,-0.1771f,0.2185f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.201f,-0.2383f,0.9502f,0.0046f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.975f,-0.0128f,0.0029f,0.2217f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.0029f,-0.2217f,0.975f,0.0128f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4079f,0.8431f,0.1064f],left_rotation:[0.0319f,0.1861f,-0.9595f,0.2091f]}}
particle minecraft:campfire_cosy_smoke 84.4 65.12 28.95 -0.051 0.022 0.038 1 0 force
particle minecraft:cloud 84.4 65.32 28.95 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke 84.4 65.42 28.95 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke 86.07 65.12 28.91 0.029 0.022 0.055 1 0 force
particle minecraft:cloud 86.07 65.32 28.91 0.35 0.18 0.35 0.02 2 force
tp @e[type=minecraft:item_display,tag=drift.onyx] 78.473 65 39.464 -169.42 0
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.6224f,-0.2038f,-0.0996f,0.7491f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.1788f,0.7637f,-0.6044f,0.1395f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.975f,-0.0128f,0.0029f,0.2217f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.0029f,-0.2217f,0.975f,0.0128f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4078f,0.8408f,0.2564f],left_rotation:[0.0784f,0.178f,-0.8791f,0.4352f]}}
particle minecraft:campfire_cosy_smoke 76.62 65.12 41.5 -0.083 0.022 0.023 1 0 force
particle minecraft:cloud 76.62 65.32 41.5 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 76.62 65.42 41.5 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke 78.29 65.12 41.85 0.012 0.022 0.056 1 0 force
particle minecraft:cloud 78.29 65.32 41.85 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 78.29 65.42 41.85 0.45 0.2 0.45 0.008 1 force
