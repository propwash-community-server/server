tp @e[type=minecraft:item_display,tag=drift.kaze] 22.098 65 -47.941 36.36 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0.0051f,0.0001f,0.0223f,0.9997f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.9228f,-0.0225f,0.2495f,0.2927f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.2201f,0.2681f,0.9303f,0.1196f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.9503f,0.0124f,0.0041f,0.3112f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.0041f,0.3112f,0.9503f,0.0124f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4078f,0.8415f,0.1188f],left_rotation:[0.117f,0.157f,-0.7595f,0.6203f]}}
particle minecraft:campfire_cosy_smoke 24.39 65.12 -48.74 0.081 0.022 0.015 1 0 force
particle minecraft:cloud 24.39 65.32 -48.74 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 24.39 65.42 -48.74 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke 23.07 65.12 -49.77 0.016 0.022 -0.038 1 0 force
particle minecraft:cloud 23.07 65.32 -49.77 0.35 0.18 0.35 0.02 3 force
tp @e[type=minecraft:item_display,tag=drift.onyx] 34.445 65 -51.002 55.2 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0.0029f,0.0001f,0.0223f,0.9997f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.5601f,-0.2323f,-0.0987f,0.789f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.1821f,0.8038f,-0.5388f,0.1747f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.9503f,0.0124f,0.0041f,0.3112f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.0041f,0.3112f,0.9503f,0.0124f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4078f,0.8412f,0.255f],left_rotation:[0.1185f,0.1532f,-0.7484f,0.6343f]}}
particle minecraft:campfire_cosy_smoke 37.04 65.12 -51.07 0.079 0.022 0.037 1 0 force
particle minecraft:cloud 37.04 65.32 -51.07 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 36.1 65.12 -52.49 0.031 0.022 -0.039 1 0 force
particle minecraft:cloud 36.1 65.32 -52.49 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 36.1 65.42 -52.49 0.45 0.2 0.45 0.008 1 force
