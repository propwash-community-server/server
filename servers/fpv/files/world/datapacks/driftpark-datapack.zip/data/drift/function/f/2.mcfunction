tp @e[type=minecraft:item_display,tag=drift.kaze] -49.887 65 62.501 -98.89 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0058f,-0.0001f,0.0179f,0.9998f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.5041f,-0.1628f,-0.0352f,0.8474f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.1244f,0.8558f,-0.4898f,0.1107f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.5041f,-0.0066f,0.0113f,0.8635f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.0113f,-0.8635f,0.5041f,0.0066f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4007f,0.8474f,0.1f],left_rotation:[0.0287f,-0.1828f,0.9757f,0.1173f]}}
particle minecraft:campfire_cosy_smoke -52.37 65.12 61.63 -0.062 0.019 -0.05 1 0 force
particle minecraft:cloud -52.37 65.32 61.63 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -52.37 65.42 61.63 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke -52.12 65.12 63.28 -0.041 0.019 0.035 1 0 force
particle minecraft:cloud -52.12 65.32 63.28 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -52.12 65.42 63.28 0.45 0.2 0.45 0.008 1 force
tp @e[type=minecraft:item_display,tag=drift.onyx] -63.79 65 58.639 -93.47 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0059f,-0.0001f,0.0206f,0.9998f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.4921f,-0.2156f,-0.064f,0.841f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.1528f,0.8523f,-0.4722f,0.165f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.5041f,-0.0066f,0.0113f,0.8635f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.0113f,-0.8635f,0.5041f,0.0066f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4052f,0.8469f,0.2399f],left_rotation:[0.0718f,0.1705f,-0.8892f,0.4183f]}}
particle minecraft:campfire_cosy_smoke -66.1 65.12 57.41 -0.045 0.022 -0.066 1 0 force
particle minecraft:cloud -66.1 65.32 57.41 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -66.1 65.42 57.41 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke -66.02 65.12 59.12 -0.033 0.022 0.016 1 0 force
particle minecraft:cloud -66.02 65.32 59.12 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -66.02 65.42 59.12 0.45 0.2 0.45 0.008 1 force
