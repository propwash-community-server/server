tp @e[type=minecraft:item_display,tag=drift.kaze] 86.234 65 -14.685 132.07 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0.0012f,0f,0.0223f,0.9998f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.5974f,-0.1197f,0.1594f,0.7768f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.0786f,0.7643f,0.6133f,0.1832f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.6054f,0.0079f,0.0104f,0.7958f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.0104f,0.7958f,0.6054f,0.0079f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4079f,0.8424f,0.1121f],left_rotation:[0.0294f,0.1897f,-0.9622f,0.1933f]}}
particle minecraft:campfire_cosy_smoke 87 65.12 -12.18 -0.013 0.022 0.075 1 0 force
particle minecraft:cloud 87 65.32 -12.18 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke 87 65.42 -12.18 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke 88.15 65.12 -13.4 0.041 0.022 0.029 1 0 force
particle minecraft:cloud 88.15 65.32 -13.4 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke 88.15 65.42 -13.4 0.45 0.2 0.45 0.008 1 force
tp @e[type=minecraft:item_display,tag=drift.onyx] 90.655 65 -0.227 144.75 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0009f,0f,0.0223f,0.9998f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.9737f,0.0424f,0.2182f,0.0501f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.2141f,0.0274f,0.9746f,0.0597f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.6054f,0.0079f,0.0104f,0.7958f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.0104f,0.7958f,0.6054f,0.0079f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4079f,0.8432f,0.2484f],left_rotation:[0.069f,0.1769f,-0.8979f,0.3972f]}}
particle minecraft:campfire_cosy_smoke 90.84 65.12 2.5 -0.03 0.022 0.084 1 0 force
particle minecraft:cloud 90.84 65.32 2.5 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 92.26 65.12 1.54 0.044 0.022 0.04 1 0 force
particle minecraft:cloud 92.26 65.32 1.54 0.35 0.18 0.35 0.02 3 force
