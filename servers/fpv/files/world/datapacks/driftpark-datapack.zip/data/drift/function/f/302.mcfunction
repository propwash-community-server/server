tp @e[type=minecraft:item_display,tag=drift.kaze] -12.677 65 -12.482 110.34 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0.0038f,-0.0001f,-0.0223f,0.9997f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.7244f,0.1431f,0.2489f,0.6267f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.1844f,-0.604f,0.7435f,0.2201f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.9503f,-0.0124f,0.0041f,0.3112f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.0041f,-0.3112f,0.9503f,0.0124f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.3314f,0.8747f,0.1166f],left_rotation:[0.1626f,-0.1068f,0.5013f,0.8431f]}}
particle minecraft:campfire_cosy_smoke -11.12 65.12 -11.52 0.019 0.022 0.021 1 0 force
particle minecraft:cloud -11.12 65.32 -11.52 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -11.12 65.42 -11.52 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke -10.59 65.12 -13.1 0.033 0.022 -0.045 1 0 force
particle minecraft:cloud -10.59 65.32 -13.1 0.35 0.18 0.35 0.02 3 force
tp @e[type=minecraft:item_display,tag=drift.onyx] -3.894 65 -17.642 88.21 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0.0112f,-0.0002f,-0.022f,0.9997f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.2435f,0.2953f,0.1359f,0.9138f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.0406f,-0.9046f,0.2758f,0.3226f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.9503f,-0.0124f,0.0041f,0.3112f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.0041f,-0.3112f,0.9503f,0.0124f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.3321f,0.8696f,0.2692f],left_rotation:[0.1971f,-0.0431f,0.1671f,0.9651f]}}
particle minecraft:campfire_cosy_smoke -1.82 65.12 -17.53 0.025 0.022 0.008 1 0 force
particle minecraft:cloud -1.82 65.32 -17.53 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -1.95 65.12 -19.24 0.034 0.022 -0.075 1 0 force
particle minecraft:cloud -1.95 65.32 -19.24 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -1.95 65.42 -19.24 0.45 0.2 0.45 0.008 1 force
