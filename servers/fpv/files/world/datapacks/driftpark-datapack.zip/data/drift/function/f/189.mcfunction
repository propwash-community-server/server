tp @e[type=minecraft:item_display,tag=drift.kaze] 70.675 65 -35.81 105.38 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0057f,-0.0001f,0.0223f,0.9997f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.9276f,-0.1088f,-0.1501f,0.3244f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.185f,0.342f,-0.9212f,0.0119f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.9466f,-0.0124f,0.0042f,0.3222f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.0042f,-0.3222f,0.9466f,0.0124f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4079f,0.8439f,0.1002f],left_rotation:[0.0038f,0.1852f,-0.9806f,0.064f]}}
particle minecraft:campfire_cosy_smoke 72.56 65.12 -33.92 0.036 0.02 0.079 1 0 force
particle minecraft:cloud 72.56 65.32 -33.92 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke 72.56 65.42 -33.92 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke 73.03 65.12 -35.52 0.059 0.02 0.006 1 0 force
particle minecraft:cloud 73.03 65.32 -35.52 0.35 0.18 0.35 0.02 2 force
tp @e[type=minecraft:item_display,tag=drift.onyx] 81.544 65 -25.377 115.61 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0.0011f,0f,0.0223f,0.9998f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.2312f,-0.2246f,0.0004f,0.9466f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.0991f,0.9518f,-0.2089f,0.2015f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.9466f,-0.0124f,0.0042f,0.3222f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.0042f,-0.3222f,0.9466f,0.0124f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4079f,0.8421f,0.2519f],left_rotation:[0.0736f,0.1772f,-0.8886f,0.4166f]}}
particle minecraft:campfire_cosy_smoke 83.01 65.12 -23.1 0.017 0.022 0.089 1 0 force
particle minecraft:cloud 83.01 65.32 -23.1 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 83.77 65.12 -24.63 0.046 0.022 0.009 1 0 force
particle minecraft:cloud 83.77 65.32 -24.63 0.35 0.18 0.35 0.02 3 force
