tp @e[type=minecraft:item_display,tag=drift.kaze] -87.977 65 -41.017 5.08 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0058f,-0.0001f,0.0221f,0.9997f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.8725f,-0.0625f,0.2621f,0.4075f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.2207f,0.3822f,0.8839f,0.1546f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.7303f,0.0096f,0.0089f,0.683f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.0089f,0.683f,0.7303f,0.0096f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4077f,0.844f,0.1f],left_rotation:[0.1355f,0.1261f,-0.637f,0.7483f]}}
particle minecraft:campfire_cosy_smoke -86.55 65.12 -42.67 0.067 0.022 -0.024 1 0 force
particle minecraft:cloud -86.55 65.32 -42.67 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -86.55 65.42 -42.67 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke -88.2 65.12 -42.85 -0.007 0.022 -0.024 1 0 force
particle minecraft:cloud -88.2 65.32 -42.85 0.35 0.18 0.35 0.02 3 force
tp @e[type=minecraft:item_display,tag=drift.onyx] -81.073 65 -46.163 26.82 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0.006f,0.0001f,0.0223f,0.9997f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.2331f,-0.2849f,0.1289f,0.9208f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.0328f,0.9123f,0.2643f,0.311f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.7303f,0.0096f,0.0089f,0.683f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.0089f,0.683f,0.7303f,0.0096f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4078f,0.8396f,0.2604f],left_rotation:[0.1858f,0.0647f,-0.2809f,0.9393f]}}
particle minecraft:campfire_cosy_smoke -78.99 65.12 -47.17 0.061 0.022 0.012 1 0 force
particle minecraft:cloud -78.99 65.32 -47.17 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -78.99 65.42 -47.17 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke -80.49 65.12 -48 0.001 0.022 -0.02 1 0 force
particle minecraft:cloud -80.49 65.32 -48 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -80.49 65.42 -48 0.45 0.2 0.45 0.008 1 force
