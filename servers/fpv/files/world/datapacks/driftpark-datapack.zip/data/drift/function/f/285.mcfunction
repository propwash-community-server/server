tp @e[type=minecraft:item_display,tag=drift.kaze] -2.809 65 -20.213 76.89 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0.0112f,-0.0002f,-0.0214f,0.9997f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.96f,-0.0435f,0.2739f,0.0384f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.2714f,-0.0098f,0.9607f,0.0572f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.9953f,-0.013f,0.0013f,0.0957f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.0013f,-0.0957f,0.9953f,0.013f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.333f,0.8724f,0.1292f],left_rotation:[0.1577f,-0.1258f,0.5775f,0.7911f]}}
particle minecraft:campfire_cosy_smoke -0.75 65.12 -20.47 0.032 0.022 0.013 1 0 force
particle minecraft:cloud -0.75 65.32 -20.47 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -1.2 65.12 -22.08 0.023 0.022 -0.065 1 0 force
particle minecraft:cloud -1.2 65.32 -22.08 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -1.2 65.42 -22.08 0.45 0.2 0.45 0.008 1 force
tp @e[type=minecraft:item_display,tag=drift.onyx] 4.184 65 -31.219 39.31 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0059f,0f,0.0017f,1f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.5454f,0.041f,0.0897f,0.8323f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.0027f,-0.8275f,0.5528f,0.0986f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.9953f,-0.013f,0.0013f,0.0957f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.0013f,-0.0957f,0.9953f,0.013f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.373f,0.8616f,0.2399f],left_rotation:[0.1345f,0.1271f,-0.6724f,0.7167f]}}
particle minecraft:campfire_cosy_smoke 6.04 65.12 -32.69 0.058 0.012 -0.02 1 0 force
particle minecraft:campfire_cosy_smoke 4.64 65.12 -33.68 -0.007 0.012 -0.064 1 0 force
