tp @e[type=minecraft:item_display,tag=drift.kaze] -6.516 65 63.907 -90.75 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0f,0f,-0.0025f,1f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.9389f,0.0504f,0.0147f,0.3402f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.021f,0.3406f,0.9388f,0.048f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.9388f,0.0123f,0.0045f,0.3441f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.0045f,0.3441f,0.9388f,0.0123f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.3658f,0.8618f,0.11f],left_rotation:[0.1907f,0.0054f,-0.0323f,0.9811f]}}
tp @e[type=minecraft:item_display,tag=drift.onyx] -24.7 65 64.636 -91.82 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.001f,0f,0.007f,1f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.987f,0.0515f,0.0095f,0.1519f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.0064f,0.1518f,0.987f,0.052f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.9388f,0.0123f,0.0045f,0.3441f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.0045f,0.3441f,0.9388f,0.0123f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.382f,0.8553f,0.2482f],left_rotation:[0.1898f,-0.0014f,0.021f,0.9816f]}}
