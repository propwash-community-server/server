tp @e[type=minecraft:item_display,tag=drift.kaze] -76.203 65 -46.112 45.09 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0.0057f,0.0001f,0.0223f,0.9997f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.2297f,-0.2876f,-0.0149f,0.9297f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.1126f,0.9364f,-0.2008f,0.265f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.9964f,-0.013f,0.0011f,0.0841f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.0011f,-0.0841f,0.9964f,0.013f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4078f,0.8414f,0.1198f],left_rotation:[0.1651f,0.1064f,-0.494f,0.847f]}}
particle minecraft:campfire_cosy_smoke -73.96 65.12 -46.43 0.07 0.022 0.026 1 0 force
particle minecraft:cloud -73.96 65.32 -46.43 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -75.1 65.12 -47.65 0.017 0.022 -0.032 1 0 force
particle minecraft:cloud -75.1 65.32 -47.65 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -75.1 65.42 -47.65 0.45 0.2 0.45 0.008 1 force
tp @e[type=minecraft:item_display,tag=drift.onyx] -65.546 65 -45.555 66.8 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0029f,-0.0001f,0.0223f,0.9997f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.7906f,-0.2091f,-0.2112f,0.5353f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.2686f,0.5605f,-0.773f,0.1272f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.9964f,-0.013f,0.0011f,0.0841f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.0011f,-0.0841f,0.9964f,0.013f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.408f,0.8441f,0.2449f],left_rotation:[0.1663f,0.0874f,-0.4178f,0.8889f]}}
particle minecraft:campfire_cosy_smoke -63.18 65.12 -45.02 0.06 0.022 0.051 1 0 force
particle minecraft:cloud -63.18 65.32 -45.02 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -63.18 65.42 -45.02 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke -63.81 65.12 -46.61 0.013 0.022 -0.025 1 0 force
particle minecraft:cloud -63.81 65.32 -46.61 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -63.81 65.42 -46.61 0.45 0.2 0.45 0.008 1 force
