tp @e[type=minecraft:item_display,tag=drift.kaze] 7.777 65 63.59 -93.36 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0f,0f,0.0036f,1f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.1118f,-0.0175f,0.0507f,0.9923f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.0533f,0.9924f,-0.1106f,0.0058f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.1159f,-0.0015f,0.013f,0.9932f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.013f,-0.9932f,0.1159f,0.0015f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.3762f,0.8573f,0.11f],left_rotation:[0.1898f,-0.0194f,0.1069f,0.9758f]}}
tp @e[type=minecraft:item_display,tag=drift.onyx] -10.417 65 63.924 -90.79 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0f,0f,-0.0028f,1f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.1412f,0.0128f,0.051f,0.9886f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.0526f,0.9887f,0.1407f,0.002f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.1159f,-0.0015f,0.013f,0.9932f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.013f,-0.9932f,0.1159f,0.0015f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.3651f,0.8621f,0.25f],left_rotation:[0.1906f,0.0089f,-0.0511f,0.9803f]}}
