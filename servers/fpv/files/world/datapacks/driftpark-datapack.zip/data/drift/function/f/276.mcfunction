tp @e[type=minecraft:item_display,tag=drift.kaze] 2.026 65 -27.245 53.2 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0059f,0.0001f,-0.0088f,0.9999f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.6557f,0.0945f,0.1559f,0.7327f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.0797f,-0.7203f,0.6693f,0.1639f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.6192f,-0.0081f,0.0103f,0.7851f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.0103f,-0.7851f,0.6192f,0.0081f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.3548f,0.8676f,0.0999f],left_rotation:[0.0008f,-0.1851f,0.9825f,0.0213f]}}
particle minecraft:campfire_cosy_smoke 4.03 65.12 -28.24 0.054 0.02 -0.003 1 0 force
particle minecraft:cloud 4.03 65.32 -28.24 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke 2.97 65.12 -29.52 -0.004 0.02 -0.062 1 0 force
particle minecraft:cloud 2.97 65.32 -29.52 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke 2.97 65.42 -29.52 0.45 0.2 0.45 0.008 1 force
tp @e[type=minecraft:item_display,tag=drift.onyx] 7.452 65 -38.058 10.89 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0058f,-0.0001f,0.0161f,0.9999f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.6279f,-0.0943f,0.147f,0.7585f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.0681f,0.7472f,0.6413f,0.1609f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.6192f,-0.0081f,0.0103f,0.7851f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.0103f,-0.7851f,0.6192f,0.0081f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.3976f,0.8505f,0.2399f],left_rotation:[0.014f,-0.1845f,0.9818f,0.0428f]}}
particle minecraft:campfire_cosy_smoke 8.99 65.12 -39.96 0.062 0.021 -0.026 1 0 force
particle minecraft:cloud 8.99 65.32 -39.96 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke 8.99 65.42 -39.96 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke 7.31 65.12 -40.24 -0.012 0.021 -0.038 1 0 force
particle minecraft:cloud 7.31 65.32 -40.24 0.35 0.18 0.35 0.02 2 force
