tp @e[type=minecraft:item_display,tag=drift.kaze] -94.26 65 -30.445 -8.74 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0059f,-0.0001f,0.0176f,0.9998f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.9106f,-0.0237f,0.2068f,0.357f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.1704f,0.3373f,0.9181f,0.1195f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.8621f,0.0113f,0.0066f,0.5066f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.0066f,0.5066f,0.8621f,0.0113f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4001f,0.8477f,0.0999f],left_rotation:[0.0444f,0.1796f,-0.9451f,0.2694f]}}
particle minecraft:campfire_cosy_smoke -93.34 65.12 -32.62 0.057 0.022 -0.037 1 0 force
particle minecraft:cloud -93.34 65.32 -32.62 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -93.34 65.42 -32.62 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke -94.99 65.12 -32.39 -0.035 0.022 -0.023 1 0 force
particle minecraft:cloud -94.99 65.32 -32.39 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -94.99 65.42 -32.39 0.45 0.2 0.45 0.008 1 force
tp @e[type=minecraft:item_display,tag=drift.onyx] -89.993 65 -40.137 -2.83 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0058f,-0.0001f,0.0216f,0.9998f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.2956f,-0.2542f,0.14f,0.9101f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.0451f,0.9004f,0.324f,0.2867f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.8621f,0.0113f,0.0066f,0.5066f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.0066f,0.5066f,0.8621f,0.0113f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4069f,0.8461f,0.2401f],left_rotation:[0.1578f,0.0968f,-0.4772f,0.8591f]}}
particle minecraft:campfire_cosy_smoke -88.73 65.12 -42.11 0.069 0.022 -0.034 1 0 force
particle minecraft:cloud -88.73 65.32 -42.11 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -88.73 65.42 -42.11 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke -90.44 65.12 -42.06 -0.022 0.022 -0.022 1 0 force
particle minecraft:cloud -90.44 65.32 -42.06 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -90.44 65.42 -42.06 0.45 0.2 0.45 0.008 1 force
