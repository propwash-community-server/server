tp @e[type=minecraft:item_display,tag=drift.kaze] 87.975 65 -9.615 137.94 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0.0003f,0f,0.0223f,0.9998f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.3867f,-0.1537f,0.124f,0.9008f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.03f,0.8927f,0.405f,0.1952f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.39f,0.0051f,0.0121f,0.9207f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.0121f,0.9207f,0.39f,0.0051f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4079f,0.8426f,0.1106f],left_rotation:[0.026f,0.1894f,-0.9656f,0.1764f]}}
particle minecraft:campfire_cosy_smoke 88.49 65.12 -7.04 -0.009 0.021 0.069 1 0 force
particle minecraft:cloud 88.49 65.32 -7.04 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke 89.75 65.12 -8.13 0.046 0.021 0.035 1 0 force
particle minecraft:cloud 89.75 65.32 -8.13 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke 89.75 65.42 -8.13 0.45 0.2 0.45 0.008 1 force
tp @e[type=minecraft:item_display,tag=drift.onyx] 90.946 65 5.172 150.37 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0.0003f,0f,0.0223f,0.9998f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.9229f,-0.0189f,0.2219f,0.314f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.1901f,0.2925f,0.93f,0.116f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.39f,0.0051f,0.0121f,0.9207f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.0121f,0.9207f,0.39f,0.0051f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4079f,0.8425f,0.2506f],left_rotation:[0.0702f,0.1778f,-0.8961f,0.4006f]}}
particle minecraft:campfire_cosy_smoke 90.86 65.12 7.91 -0.028 0.022 0.066 1 0 force
particle minecraft:cloud 90.86 65.32 7.91 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 90.86 65.42 7.91 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke 92.36 65.12 7.09 0.038 0.022 0.028 1 0 force
particle minecraft:cloud 92.36 65.32 7.09 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 92.36 65.42 7.09 0.45 0.2 0.45 0.008 1 force
