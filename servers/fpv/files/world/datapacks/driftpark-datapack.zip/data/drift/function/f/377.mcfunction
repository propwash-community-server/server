tp @e[type=minecraft:item_display,tag=drift.kaze] -61.083 65 -42.532 81.83 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0.0059f,0.0001f,0.0223f,0.9997f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.568f,-0.1853f,0.2031f,0.7757f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.1227f,0.7587f,0.5906f,0.2461f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.6054f,-0.0079f,0.0104f,0.7958f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.0104f,-0.7958f,0.6054f,0.0079f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4078f,0.8413f,0.1202f],left_rotation:[0.1507f,0.1262f,-0.5955f,0.779f]}}
particle minecraft:campfire_cosy_smoke -59.02 65.12 -41.46 0.034 0.022 0.066 1 0 force
particle minecraft:cloud -59.02 65.32 -41.46 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -59.22 65.12 -43.12 0.026 0.022 -0.018 1 0 force
particle minecraft:cloud -59.22 65.32 -43.12 0.35 0.18 0.35 0.02 3 force
tp @e[type=minecraft:item_display,tag=drift.onyx] -51.22 65 -34.903 106.45 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0.0058f,0.0001f,0.0156f,0.9999f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.9525f,0.009f,0.2486f,0.1757f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.2315f,0.1505f,0.9568f,0.091f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.6054f,-0.0079f,0.0104f,0.7958f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.0104f,-0.7958f,0.6054f,0.0079f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.3965f,0.8451f,0.2599f],left_rotation:[0.1159f,0.1587f,-0.7735f,0.6026f]}}
particle minecraft:campfire_cosy_smoke -49.53 65.12 -32.8 0.014 0.022 0.075 1 0 force
particle minecraft:cloud -49.53 65.32 -32.8 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -49.53 65.42 -32.8 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke -48.98 65.12 -34.41 0.048 0.022 0.008 1 0 force
particle minecraft:cloud -48.98 65.32 -34.41 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -48.98 65.42 -34.41 0.45 0.2 0.45 0.008 1 force
particle minecraft:flame -48.16 65.24 -33.42 0.05 0.04 0.05 0.02 6 force
particle minecraft:large_smoke -48.16 65.24 -33.42 0.05 0.04 0.05 0.01 2 force
particle minecraft:flame -48.28 65.24 -33.08 0.05 0.04 0.05 0.02 6 force
particle minecraft:large_smoke -48.28 65.24 -33.08 0.05 0.04 0.05 0.01 2 force
