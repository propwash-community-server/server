tp @e[type=minecraft:item_display,tag=drift.kaze] -83.974 65 34.055 -43.5 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0.0112f,0.0001f,0.0111f,0.9999f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.8093f,-0.039f,0.1478f,0.5672f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.089f,0.5548f,0.8179f,0.1243f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.7797f,0.0102f,0.0082f,0.626f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.0082f,0.626f,0.7797f,0.0102f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.389f,0.8489f,0.1293f],left_rotation:[0.0561f,-0.1939f,0.9467f,0.2511f]}}
particle minecraft:campfire_cosy_smoke -84.74 65.12 31.39 0.003 0.017 -0.077 1 0 force
particle minecraft:cloud -84.74 65.32 31.39 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -85.99 65.12 32.5 -0.052 0.017 -0.03 1 0 force
particle minecraft:cloud -85.99 65.32 32.5 0.35 0.18 0.35 0.02 2 force
tp @e[type=minecraft:item_display,tag=drift.onyx] -90.962 65 17.365 -27.09 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0027f,0f,0.0112f,0.9999f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.7333f,-0.0036f,0.0813f,0.675f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.0108f,0.6702f,0.7377f,0.0806f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.7797f,0.0102f,0.0082f,0.626f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.0082f,0.626f,0.7797f,0.0102f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.3892f,0.8529f,0.2453f],left_rotation:[0.1602f,-0.0986f,0.5332f,0.8248f]}}
