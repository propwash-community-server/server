tp @e[type=minecraft:item_display,tag=drift.kaze] -38.528 65 64.136 -97.48 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0059f,-0.0001f,0.0148f,0.9999f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.0323f,-0.0879f,0.0497f,0.9944f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.0545f,0.9946f,-0.0232f,0.085f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.029f,-0.0004f,0.0131f,0.9995f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.0131f,-0.9995f,0.029f,0.0004f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.3954f,0.8499f,0.0999f],left_rotation:[0.1334f,-0.1282f,0.7016f,0.6881f]}}
particle minecraft:campfire_cosy_smoke -41.13 65.12 63.39 -0.057 0.014 -0.052 1 0 force
particle minecraft:campfire_cosy_smoke -40.9 65.12 65.05 -0.062 0.014 0.036 1 0 force
tp @e[type=minecraft:item_display,tag=drift.onyx] -54.253 65 62.126 -100.32 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0059f,-0.0001f,0.0184f,0.9998f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.0244f,-0.1946f,0.0582f,0.9788f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.0443f,0.9781f,0.0449f,0.1982f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.029f,-0.0004f,0.0131f,0.9995f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.0131f,-0.9995f,0.029f,0.0004f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4015f,0.8487f,0.2398f],left_rotation:[0.0356f,0.1816f,-0.9567f,0.2247f]}}
particle minecraft:campfire_cosy_smoke -56.81 65.12 61.24 -0.049 0.022 -0.045 1 0 force
particle minecraft:cloud -56.81 65.32 61.24 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -56.53 65.12 62.92 -0.053 0.022 0.031 1 0 force
particle minecraft:cloud -56.53 65.32 62.92 0.35 0.18 0.35 0.02 2 force
