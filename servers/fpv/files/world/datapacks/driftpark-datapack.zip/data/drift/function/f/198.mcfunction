tp @e[type=minecraft:item_display,tag=drift.kaze] 61.972 65 -41.848 96.73 0
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.8766f,-0.032f,0.1806f,0.445f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.1348f,0.4284f,0.8848f,0.1244f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.8873f,0.0116f,0.006f,0.4609f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.006f,0.4609f,0.8873f,0.0116f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4079f,0.844f,0.0999f],left_rotation:[0.0003f,0.185f,-0.9817f,0.0453f]}}
particle minecraft:campfire_cosy_smoke 64.2 65.12 -40.22 0.048 0.02 0.072 1 0 force
particle minecraft:cloud 64.2 65.32 -40.22 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke 64.43 65.12 -41.87 0.049 0.02 -0.001 1 0 force
particle minecraft:cloud 64.43 65.32 -41.87 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke 64.43 65.42 -41.87 0.45 0.2 0.45 0.008 1 force
tp @e[type=minecraft:item_display,tag=drift.onyx] 75.348 65 -32.67 106.54 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.005f,-0.0001f,0.0223f,0.9997f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.8205f,-0.1586f,-0.1471f,0.5292f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.2035f,0.5476f,-0.8083f,0.0732f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.8873f,0.0116f,0.006f,0.4609f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.006f,0.4609f,0.8873f,0.0116f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.408f,0.8452f,0.2413f],left_rotation:[0.0576f,0.1767f,-0.9198f,0.3457f]}}
particle minecraft:campfire_cosy_smoke 77.22 65.12 -30.66 0.031 0.022 0.075 1 0 force
particle minecraft:cloud 77.22 65.32 -30.66 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 77.22 65.42 -30.66 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke 77.73 65.12 -32.29 0.047 0.022 -0.004 1 0 force
particle minecraft:cloud 77.73 65.32 -32.29 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 77.73 65.42 -32.29 0.45 0.2 0.45 0.008 1 force
