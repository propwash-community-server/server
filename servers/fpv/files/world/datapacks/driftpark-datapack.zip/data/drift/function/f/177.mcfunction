tp @e[type=minecraft:item_display,tag=drift.kaze] 79.604 65 -26.535 116.97 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0014f,0f,0.0223f,0.9998f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.9163f,-0.1172f,-0.1581f,0.3488f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.1956f,0.3673f,-0.909f,0.0215f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.9368f,-0.0123f,0.0046f,0.3496f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.0046f,-0.3496f,0.9368f,0.0123f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4079f,0.843f,0.1075f],left_rotation:[0.0244f,0.1878f,-0.9671f,0.1698f]}}
particle minecraft:campfire_cosy_smoke 80.97 65.12 -24.35 0.018 0.022 0.071 1 0 force
particle minecraft:cloud 80.97 65.32 -24.35 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke 80.97 65.42 -24.35 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke 81.76 65.12 -25.83 0.055 0.022 0.004 1 0 force
particle minecraft:cloud 81.76 65.32 -25.83 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke 81.76 65.42 -25.83 0.45 0.2 0.45 0.008 1 force
tp @e[type=minecraft:item_display,tag=drift.onyx] 87.402 65 -13.982 129.63 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0.001f,0f,0.0223f,0.9998f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.2646f,-0.2249f,-0.0077f,0.9377f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.1063f,0.9437f,-0.2424f,0.1983f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.9368f,-0.0123f,0.0046f,0.3496f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.0046f,-0.3496f,0.9368f,0.0123f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4079f,0.8422f,0.2518f],left_rotation:[0.0744f,0.1768f,-0.8867f,0.4207f]}}
particle minecraft:campfire_cosy_smoke 88.28 65.12 -11.39 -0.017 0.022 0.087 1 0 force
particle minecraft:cloud 88.28 65.32 -11.39 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 88.28 65.42 -11.39 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke 89.4 65.12 -12.68 0.042 0.022 0.024 1 0 force
particle minecraft:cloud 89.4 65.32 -12.68 0.35 0.18 0.35 0.02 3 force
