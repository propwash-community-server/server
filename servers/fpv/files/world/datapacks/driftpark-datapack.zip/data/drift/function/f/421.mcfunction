tp @e[type=minecraft:item_display,tag=drift.kaze] -88.868 65 -40.069 2.63 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0059f,-0.0001f,0.0218f,0.9997f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.0233f,-0.26f,0.0479f,0.9641f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.0532f,0.9644f,0.0039f,0.2589f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.2863f,0.0037f,0.0125f,0.9581f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.0125f,0.9581f,0.2863f,0.0037f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4072f,0.8443f,0.0999f],left_rotation:[0.1292f,0.1325f,-0.673f,0.7161f]}}
particle minecraft:campfire_cosy_smoke -87.51 65.12 -41.81 0.07 0.022 -0.026 1 0 force
particle minecraft:cloud -87.51 65.32 -41.81 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -87.51 65.42 -41.81 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke -89.18 65.12 -41.91 -0.025 0.022 -0.022 1 0 force
particle minecraft:cloud -89.18 65.32 -41.91 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -89.18 65.42 -41.91 0.45 0.2 0.45 0.008 1 force
tp @e[type=minecraft:item_display,tag=drift.onyx] -82.306 65 -45.749 22.94 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0.0057f,0.0001f,0.0223f,0.9997f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.796f,-0.2123f,-0.2242f,0.5206f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.2801f,0.547f,-0.7781f,0.1298f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.2863f,0.0037f,0.0125f,0.9581f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.0125f,0.9581f,0.2863f,0.0037f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4078f,0.8398f,0.2598f],left_rotation:[0.1828f,0.0716f,-0.3168f,0.928f]}}
particle minecraft:campfire_cosy_smoke -80.33 65.12 -46.89 0.064 0.022 0.01 1 0 force
particle minecraft:cloud -80.33 65.32 -46.89 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -81.88 65.12 -47.61 -0.007 0.022 -0.025 1 0 force
particle minecraft:cloud -81.88 65.32 -47.61 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -81.88 65.42 -47.61 0.45 0.2 0.45 0.008 1 force
