tp @e[type=minecraft:item_display,tag=drift.kaze] -95.47 65 -26.4 -12.66 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0059f,-0.0001f,0.0171f,0.9998f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.9554f,0.0092f,0.1993f,0.2179f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.1775f,0.1982f,0.9596f,0.0911f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.9605f,0.0126f,0.0036f,0.2779f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.0036f,0.2779f,0.9605f,0.0126f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.3993f,0.848f,0.0999f],left_rotation:[0.0295f,0.1827f,-0.9642f,0.19f]}}
particle minecraft:campfire_cosy_smoke -94.71 65.12 -28.69 0.048 0.022 -0.059 1 0 force
particle minecraft:cloud -94.71 65.32 -28.69 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -94.71 65.42 -28.69 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke -96.34 65.12 -28.35 -0.031 0.022 -0.043 1 0 force
particle minecraft:cloud -96.34 65.32 -28.35 0.35 0.18 0.35 0.02 2 force
tp @e[type=minecraft:item_display,tag=drift.onyx] -92.087 65 -37.19 -6.83 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0059f,-0.0001f,0.0201f,0.9998f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.626f,-0.2356f,-0.1301f,0.7319f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.2078f,0.7496f,-0.6047f,0.1711f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.9605f,0.0126f,0.0036f,0.2779f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.0036f,0.2779f,0.9605f,0.0126f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4044f,0.8473f,0.2398f],left_rotation:[0.1353f,0.1261f,-0.6406f,0.7452f]}}
particle minecraft:campfire_cosy_smoke -90.99 65.12 -39.32 0.053 0.022 -0.03 1 0 force
particle minecraft:cloud -90.99 65.32 -39.32 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -90.99 65.42 -39.32 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke -92.69 65.12 -39.13 -0.023 0.022 -0.018 1 0 force
particle minecraft:cloud -92.69 65.32 -39.13 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -92.69 65.42 -39.13 0.45 0.2 0.45 0.008 1 force
