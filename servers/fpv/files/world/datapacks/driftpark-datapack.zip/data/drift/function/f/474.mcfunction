tp @e[type=minecraft:item_display,tag=drift.kaze] -93.579 65 7.624 -23.02 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0059f,-0.0001f,0.0099f,0.9999f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.4705f,-0.0279f,0.0744f,0.8788f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.0175f,0.8758f,0.476f,0.0775f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.4113f,0.0054f,0.0119f,0.9114f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.0119f,0.9114f,0.4113f,0.0054f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.3869f,0.8538f,0.0999f],left_rotation:[0.1596f,-0.0936f,0.5136f,0.8378f]}}
tp @e[type=minecraft:item_display,tag=drift.onyx] -97.274 65 -8.018 -29.29 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0058f,-0.0001f,0.0176f,0.9998f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.2263f,-0.1576f,0.0919f,0.9568f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.0082f,0.9524f,0.2441f,0.1823f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.4113f,0.0054f,0.0119f,0.9114f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.0119f,0.9114f,0.4113f,0.0054f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4001f,0.8493f,0.24f],left_rotation:[-0.0005f,0.1851f,-0.9822f,0.0318f]}}
particle minecraft:campfire_cosy_smoke -97.34 65.12 -10.74 0.034 0.02 -0.069 1 0 force
particle minecraft:cloud -97.34 65.32 -10.74 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -97.34 65.42 -10.74 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke -98.84 65.12 -9.9 -0.041 0.02 -0.034 1 0 force
particle minecraft:cloud -98.84 65.32 -9.9 0.35 0.18 0.35 0.02 2 force
