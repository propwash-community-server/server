tp @e[type=minecraft:item_display,tag=drift.kaze] 14.873 65 -44.305 17.93 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0.0064f,0.0001f,0.0223f,0.9997f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.9038f,-0.0398f,0.2639f,0.3345f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.2302f,0.3086f,0.913f,0.135f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.9832f,-0.0129f,0.0024f,0.1819f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.0024f,-0.1819f,0.9832f,0.0129f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4078f,0.8412f,0.121f],left_rotation:[0.1409f,0.1378f,-0.6537f,0.7307f]}}
particle minecraft:campfire_cosy_smoke 16.72 65.12 -45.69 0.063 0.022 -0.015 1 0 force
particle minecraft:cloud 16.72 65.32 -45.69 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 15.15 65.12 -46.24 -0.005 0.022 -0.04 1 0 force
particle minecraft:cloud 15.15 65.32 -46.24 0.35 0.18 0.35 0.02 3 force
tp @e[type=minecraft:item_display,tag=drift.onyx] 25.257 65 -49.83 39.68 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0.0032f,0.0001f,0.0223f,0.9997f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.0627f,-0.2644f,0.0371f,0.9617f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.0638f,0.9631f,-0.0352f,0.2592f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.9832f,-0.0129f,0.0024f,0.1819f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.0024f,-0.1819f,0.9832f,0.0129f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4078f,0.8411f,0.2555f],left_rotation:[0.1388f,0.1355f,-0.6533f,0.7318f]}}
particle minecraft:campfire_cosy_smoke 27.73 65.12 -50.54 0.067 0.022 0.015 1 0 force
particle minecraft:cloud 27.73 65.32 -50.54 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 26.45 65.12 -51.67 0.023 0.022 -0.035 1 0 force
particle minecraft:cloud 26.45 65.32 -51.67 0.35 0.18 0.35 0.02 3 force
