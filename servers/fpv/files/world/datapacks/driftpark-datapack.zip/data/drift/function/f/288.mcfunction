tp @e[type=minecraft:item_display,tag=drift.kaze] -4.544 65 -18.265 83.81 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0.0112f,-0.0002f,-0.022f,0.9997f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.6525f,0.1737f,0.2371f,0.6985f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.165f,-0.6774f,0.6744f,0.2432f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.6417f,-0.0084f,0.01f,0.7668f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.01f,-0.7668f,0.6417f,0.0084f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.332f,0.8728f,0.1292f],left_rotation:[0.1755f,-0.0995f,0.445f,0.8725f]}}
particle minecraft:campfire_cosy_smoke -2.54 65.12 -18.25 0.025 0.022 0.012 1 0 force
particle minecraft:cloud -2.54 65.32 -18.25 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -2.54 65.42 -18.25 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke -2.79 65.12 -19.91 0.022 0.022 -0.077 1 0 force
particle minecraft:cloud -2.79 65.32 -19.91 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -2.79 65.42 -19.91 0.45 0.2 0.45 0.008 1 force
tp @e[type=minecraft:item_display,tag=drift.onyx] 3.142 65 -28.726 50.22 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0058f,0f,-0.0043f,1f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.2135f,0.169f,0.0168f,0.9621f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.0842f,-0.9656f,-0.1969f,0.1475f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.6417f,-0.0084f,0.01f,0.7668f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.01f,-0.7668f,0.6417f,0.0084f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.3625f,0.866f,0.24f],left_rotation:[0.0203f,0.184f,-0.9777f,0.0995f]}}
particle minecraft:campfire_cosy_smoke 5.11 65.12 -29.91 0.053 0.018 -0.011 1 0 force
particle minecraft:cloud 5.11 65.32 -29.91 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke 5.11 65.42 -29.91 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke 3.94 65.12 -31.16 -0.002 0.018 -0.079 1 0 force
particle minecraft:cloud 3.94 65.32 -31.16 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke 3.94 65.42 -31.16 0.45 0.2 0.45 0.008 1 force
