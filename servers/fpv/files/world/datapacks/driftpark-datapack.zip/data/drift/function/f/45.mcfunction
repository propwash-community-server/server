tp @e[type=minecraft:item_display,tag=drift.kaze] 3.879 65 63.688 -91.84 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0f,0f,0.0019f,1f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.7761f,-0.0427f,0.0304f,0.6284f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.0355f,-0.6287f,0.7759f,0.0386f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.7797f,-0.0102f,0.0082f,0.626f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.0082f,-0.626f,0.7797f,0.0102f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.3733f,0.8586f,0.11f],left_rotation:[0.1907f,-0.0052f,0.0307f,0.9811f]}}
tp @e[type=minecraft:item_display,tag=drift.onyx] -14.311 65 64.128 -90.92 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0f,0f,-0.0006f,1f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.6061f,-0.0248f,0.0469f,0.7936f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.0362f,-0.7931f,0.6068f,0.0388f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.7797f,-0.0102f,0.0082f,0.626f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.0082f,-0.626f,0.7797f,0.0102f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.3689f,0.8605f,0.25f],left_rotation:[0.1902f,0.015f,-0.0782f,0.9785f]}}
