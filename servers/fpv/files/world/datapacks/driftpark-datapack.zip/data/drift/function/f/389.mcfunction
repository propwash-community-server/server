tp @e[type=minecraft:item_display,tag=drift.kaze] -69.528 65 -45.68 62.64 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0.0006f,0f,0.0223f,0.9998f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.8826f,-0.1563f,-0.2239f,0.3827f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.2653f,0.4083f,-0.8711f,0.0644f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.6283f,-0.0082f,0.0102f,0.7779f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.0102f,-0.7779f,0.6283f,0.0082f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4079f,0.8425f,0.1111f],left_rotation:[0.1445f,0.1256f,-0.6101f,0.7688f]}}
particle minecraft:campfire_cosy_smoke -67.23 65.12 -45.33 0.063 0.022 0.049 1 0 force
particle minecraft:cloud -67.23 65.32 -45.33 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -67.23 65.42 -45.33 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke -67.95 65.12 -46.84 0.025 0.022 -0.025 1 0 force
particle minecraft:cloud -67.95 65.32 -46.84 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -67.95 65.42 -46.84 0.45 0.2 0.45 0.008 1 force
tp @e[type=minecraft:item_display,tag=drift.onyx] -59.264 65 -42.463 80.58 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0.0081f,0.0002f,0.0223f,0.9997f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.9014f,-0.0449f,0.3041f,0.3051f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.2737f,0.2748f,0.9111f,0.1399f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.6283f,-0.0082f,0.0102f,0.7779f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.0102f,-0.7779f,0.6283f,0.0082f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4077f,0.8385f,0.2639f],left_rotation:[0.1841f,0.075f,-0.3288f,0.9232f]}}
particle minecraft:campfire_cosy_smoke -57.07 65.12 -41.34 0.047 0.022 0.053 1 0 force
particle minecraft:cloud -57.07 65.32 -41.34 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -57.07 65.42 -41.34 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke -57.3 65.12 -43.04 0.036 0.022 -0.016 1 0 force
particle minecraft:cloud -57.3 65.32 -43.04 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -57.3 65.42 -43.04 0.45 0.2 0.45 0.008 1 force
