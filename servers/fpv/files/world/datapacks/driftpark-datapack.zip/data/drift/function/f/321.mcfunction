tp @e[type=minecraft:item_display,tag=drift.kaze] -25.353 65 -11.621 139.85 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0016f,0f,-0.0223f,0.9998f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.0093f,0.2634f,0.0517f,0.9632f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.0492f,-0.9631f,0.0183f,0.2639f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.9999f,-0.0131f,0.0001f,0.0087f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.0001f,-0.0087f,0.9999f,0.0131f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.3314f,0.876f,0.1073f],left_rotation:[0.1373f,-0.1302f,0.6434f,0.7418f]}}
particle minecraft:campfire_cosy_smoke -24.38 65.12 -9.94 0.007 0.022 0.036 1 0 force
particle minecraft:cloud -24.38 65.32 -9.94 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -24.38 65.42 -9.94 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke -23.13 65.12 -11.05 0.075 0.022 -0.022 1 0 force
particle minecraft:cloud -23.13 65.32 -11.05 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -23.13 65.42 -11.05 0.45 0.2 0.45 0.008 1 force
tp @e[type=minecraft:item_display,tag=drift.onyx] -15.449 65 -10.678 123.54 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0048f,0.0001f,-0.0223f,0.9997f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.8224f,0.2008f,-0.2367f,0.4767f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.2882f,-0.5043f,-0.8058f,0.1155f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.9999f,-0.0131f,0.0001f,0.0087f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.0001f,-0.0087f,0.9999f,0.0131f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.3313f,0.878f,0.2417f],left_rotation:[0.1743f,-0.0651f,0.3023f,0.9349f]}}
particle minecraft:campfire_cosy_smoke -14.06 65.12 -9.36 0.015 0.022 0.018 1 0 force
particle minecraft:cloud -14.06 65.32 -9.36 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -14.06 65.42 -9.36 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke -13.15 65.12 -10.81 0.049 0.022 -0.042 1 0 force
particle minecraft:cloud -13.15 65.32 -10.81 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -13.15 65.42 -10.81 0.45 0.2 0.45 0.008 1 force
