tp @e[type=minecraft:item_display,tag=drift.kaze] -69.553 65 54.031 -83.21 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0059f,-0.0001f,0.0221f,0.9997f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.8271f,-0.1589f,-0.1531f,0.5169f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.2083f,0.5358f,-0.815f,0.0728f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.8408f,-0.011f,0.0071f,0.5413f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.0071f,-0.5413f,0.8408f,0.011f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4076f,0.8441f,0.0999f],left_rotation:[0.0647f,0.1734f,-0.9047f,0.3837f]}}
particle minecraft:campfire_cosy_smoke -71.42 65.12 52.5 -0.025 0.022 -0.058 1 0 force
particle minecraft:cloud -71.42 65.32 52.5 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -71.64 65.12 54.16 -0.042 0.022 0.021 1 0 force
particle minecraft:cloud -71.64 65.32 54.16 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -71.64 65.42 54.16 0.45 0.2 0.45 0.008 1 force
tp @e[type=minecraft:item_display,tag=drift.onyx] -78.752 65 45.359 -68.44 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0.0112f,0.0002f,0.0207f,0.9997f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.781f,-0.1941f,-0.1752f,0.5672f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.2357f,0.5887f,-0.7649f,0.1131f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.8408f,-0.011f,0.0071f,0.5413f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.0071f,-0.5413f,0.8408f,0.011f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.405f,0.8381f,0.2693f],left_rotation:[0.1371f,0.1481f,-0.6907f,0.6944f]}}
particle minecraft:campfire_cosy_smoke -80.24 65.12 43.12 -0.007 0.022 -0.077 1 0 force
particle minecraft:cloud -80.24 65.32 43.12 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -80.24 65.42 43.12 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke -80.92 65.12 44.68 -0.035 0.022 0.001 1 0 force
particle minecraft:cloud -80.92 65.32 44.68 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -80.92 65.42 44.68 0.45 0.2 0.45 0.008 1 force
