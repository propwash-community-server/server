tp @e[type=minecraft:item_display,tag=drift.kaze] 47.966 65 -48.064 79.48 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0.0094f,0.0002f,0.0223f,0.9997f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.676f,-0.1828f,-0.1009f,0.7067f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.1758f,0.7212f,-0.6605f,0.1128f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.6977f,-0.0091f,0.0094f,0.7162f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.0094f,-0.7162f,0.6977f,0.0091f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4078f,0.8405f,0.1261f],left_rotation:[0.0484f,0.1941f,-0.9392f,0.279f]}}
particle minecraft:campfire_cosy_smoke 50.42 65.12 -47.12 0.061 0.022 0.051 1 0 force
particle minecraft:cloud 50.42 65.32 -47.12 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 50.16 65.12 -48.77 0.047 0.022 -0.015 1 0 force
particle minecraft:cloud 50.16 65.32 -48.77 0.35 0.18 0.35 0.02 3 force
tp @e[type=minecraft:item_display,tag=drift.onyx] 63.357 65 -41.777 94.47 0
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.3353f,-0.1702f,0.119f,0.9189f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.023f,0.9115f,0.3551f,0.2063f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.6977f,-0.0091f,0.0094f,0.7162f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.0094f,-0.7162f,0.6977f,0.0091f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.408f,0.8456f,0.2399f],left_rotation:[0.0427f,0.18f,-0.9452f,0.269f]}}
particle minecraft:campfire_cosy_smoke 65.73 65.12 -40.16 0.043 0.022 0.081 1 0 force
particle minecraft:cloud 65.73 65.32 -40.16 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke 65.73 65.42 -40.16 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke 65.89 65.12 -41.86 0.059 0.022 -0.013 1 0 force
particle minecraft:cloud 65.89 65.32 -41.86 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke 65.89 65.42 -41.86 0.45 0.2 0.45 0.008 1 force
