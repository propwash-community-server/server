tp @e[type=minecraft:item_display,tag=drift.kaze] 65.059 65 -39.94 99.92 0
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.3119f,-0.1478f,0.1055f,0.9326f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.008f,0.9267f,0.3291f,0.1814f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.3084f,0.004f,0.0125f,0.9512f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.0125f,0.9512f,0.3084f,0.004f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4079f,0.8439f,0.0999f],left_rotation:[-0.003f,0.185f,-0.9823f,0.0279f]}}
particle minecraft:campfire_cosy_smoke 67.18 65.12 -38.21 0.048 0.02 0.079 1 0 force
particle minecraft:cloud 67.18 65.32 -38.21 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke 67.49 65.12 -39.85 0.059 0.02 -0.016 1 0 force
particle minecraft:cloud 67.49 65.32 -39.85 0.35 0.18 0.35 0.02 2 force
tp @e[type=minecraft:item_display,tag=drift.onyx] 77.61 65 -30.327 109.4 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0045f,-0.0001f,0.0223f,0.9997f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.9518f,0.0055f,0.2193f,0.2144f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.198f,0.1926f,0.9564f,0.0945f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.3084f,0.004f,0.0125f,0.9512f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.0125f,0.9512f,0.3084f,0.004f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.408f,0.8449f,0.2422f],left_rotation:[0.063f,0.1754f,-0.909f,0.3729f]}}
particle minecraft:campfire_cosy_smoke 79.35 65.12 -28.23 0.02 0.022 0.071 1 0 force
particle minecraft:cloud 79.35 65.32 -28.23 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 79.35 65.42 -28.23 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke 79.94 65.12 -29.84 0.043 0.022 0.009 1 0 force
particle minecraft:cloud 79.94 65.32 -29.84 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 79.94 65.42 -29.84 0.45 0.2 0.45 0.008 1 force
