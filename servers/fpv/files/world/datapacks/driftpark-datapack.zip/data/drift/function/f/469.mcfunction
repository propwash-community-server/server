tp @e[type=minecraft:item_display,tag=drift.kaze] -94.99 65 1.838 -23.33 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0059f,-0.0001f,0.0125f,0.9999f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.2369f,-0.0646f,0.0699f,0.9668f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.0313f,0.9648f,0.245f,0.0899f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.1733f,0.0023f,0.0129f,0.9848f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.0129f,0.9848f,0.1733f,0.0023f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.3913f,0.8518f,0.0999f],left_rotation:[0.1408f,-0.1201f,0.6561f,0.7317f]}}
particle minecraft:campfire_cosy_smoke -94.99 65.12 -0.83 0.029 0.013 -0.073 1 0 force
particle minecraft:campfire_cosy_smoke -96.52 65.12 -0.16 -0.042 0.013 -0.033 1 0 force
tp @e[type=minecraft:item_display,tag=drift.onyx] -97.699 65 -13.282 -27.94 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0059f,-0.0001f,0.0188f,0.9998f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.0446f,-0.201f,0.0443f,0.9776f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.0582f,0.9783f,-0.0238f,0.1974f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.1733f,0.0023f,0.0129f,0.9848f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.0129f,0.9848f,0.1733f,0.0023f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4022f,0.8484f,0.2399f],left_rotation:[0.0402f,0.1806f,-0.9505f,0.2494f]}}
particle minecraft:campfire_cosy_smoke -97.61 65.12 -15.96 0.034 0.022 -0.07 1 0 force
particle minecraft:cloud -97.61 65.32 -15.96 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -99.14 65.12 -15.18 -0.033 0.022 -0.037 1 0 force
particle minecraft:cloud -99.14 65.32 -15.18 0.35 0.18 0.35 0.02 3 force
