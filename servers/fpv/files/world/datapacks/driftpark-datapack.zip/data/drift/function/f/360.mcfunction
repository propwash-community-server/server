tp @e[type=minecraft:item_display,tag=drift.kaze] -49.698 65 -32.114 117.79 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0043f,0f,0.0103f,0.9999f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.6603f,-0.0946f,0.1576f,0.7282f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.0819f,0.7156f,0.6738f,0.1646f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.7649f,-0.01f,0.0084f,0.644f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.0084f,-0.644f,0.7649f,0.01f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.3876f,0.8531f,0.1026f],left_rotation:[0.0033f,0.1866f,-0.9817f,0.0376f]}}
particle minecraft:campfire_cosy_smoke -48.35 65.12 -29.94 0.015 0.02 0.066 1 0 force
particle minecraft:cloud -48.35 65.32 -29.94 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -48.35 65.42 -29.94 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke -47.5 65.12 -31.38 0.05 0.02 0.006 1 0 force
particle minecraft:cloud -47.5 65.32 -31.38 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -47.5 65.42 -31.38 0.45 0.2 0.45 0.008 1 force
tp @e[type=minecraft:item_display,tag=drift.onyx] -41.935 65 -21.284 154.77 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0058f,0.0001f,-0.013f,0.9999f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.8823f,0.0982f,-0.0757f,0.454f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.1238f,-0.4644f,-0.8769f,0.006f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.7649f,-0.01f,0.0084f,0.644f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.0084f,-0.644f,0.7649f,0.01f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.3475f,0.8722f,0.2399f],left_rotation:[0.0995f,0.156f,-0.842f,0.5068f]}}
particle minecraft:campfire_cosy_smoke -41.64 65.12 -18.94 -0.018 0.016 0.055 1 0 force
particle minecraft:cloud -41.64 65.32 -18.94 0.35 0.18 0.35 0.02 1 force
particle minecraft:campfire_cosy_smoke -40.06 65.12 -19.61 0.061 0.016 0.019 1 0 force
particle minecraft:cloud -40.06 65.32 -19.61 0.35 0.18 0.35 0.02 1 force
