tp @e[type=minecraft:item_display,tag=drift.kaze] 89.921 65 0.921 149.47 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0007f,0f,0.0223f,0.9998f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.0928f,-0.1931f,0.0352f,0.9762f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.0672f,0.9778f,-0.073f,0.1844f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.0986f,-0.0013f,0.013f,0.995f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.013f,-0.995f,0.0986f,0.0013f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4079f,0.8428f,0.1089f],left_rotation:[0.0236f,0.1887f,-0.9678f,0.1649f]}}
particle minecraft:campfire_cosy_smoke 89.92 65.12 3.53 -0.028 0.021 0.08 1 0 force
particle minecraft:cloud 89.92 65.32 3.53 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke 91.37 65.12 2.71 0.034 0.021 0.024 1 0 force
particle minecraft:cloud 91.37 65.32 2.71 0.35 0.18 0.35 0.02 2 force
tp @e[type=minecraft:item_display,tag=drift.onyx] 89.923 65 15.926 161.67 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0011f,0f,0.0223f,0.9998f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.6201f,-0.1335f,0.1796f,0.7519f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.1016f,0.7372f,0.6376f,0.1994f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.0986f,-0.0013f,0.013f,0.995f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.013f,-0.995f,0.0986f,0.0013f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4079f,0.8432f,0.2481f],left_rotation:[0.0716f,0.1757f,-0.892f,0.4104f]}}
particle minecraft:campfire_cosy_smoke 89.31 65.12 18.58 -0.047 0.022 0.056 1 0 force
particle minecraft:cloud 89.31 65.32 18.58 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 89.31 65.42 18.58 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke 90.94 65.12 18.08 0.029 0.022 0.037 1 0 force
particle minecraft:cloud 90.94 65.32 18.08 0.35 0.18 0.35 0.02 3 force
