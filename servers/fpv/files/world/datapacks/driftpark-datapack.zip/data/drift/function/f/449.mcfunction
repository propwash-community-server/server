tp @e[type=minecraft:item_display,tag=drift.kaze] -96.69 65 -19.205 -19.69 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0059f,-0.0001f,0.0186f,0.9998f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.6806f,-0.1685f,-0.0882f,0.7076f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.1631f,0.7207f,-0.6666f,0.0979f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.7342f,-0.0096f,0.0089f,0.6788f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.0089f,-0.6788f,0.7342f,0.0096f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4018f,0.8468f,0.0999f],left_rotation:[0.0131f,0.1846f,-0.977f,0.1058f]}}
particle minecraft:campfire_cosy_smoke -96.22 65.12 -21.66 0.048 0.021 -0.063 1 0 force
particle minecraft:cloud -96.22 65.32 -21.66 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -96.22 65.42 -21.66 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke -97.81 65.12 -21.12 -0.042 0.021 -0.041 1 0 force
particle minecraft:cloud -97.81 65.32 -21.12 0.35 0.18 0.35 0.02 2 force
tp @e[type=minecraft:item_display,tag=drift.onyx] -94.822 65 -31.528 -11.78 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0059f,-0.0001f,0.0178f,0.9998f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.7518f,-0.1881f,-0.1449f,0.6151f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.2104f,0.6337f,-0.7362f,0.1101f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.7342f,-0.0096f,0.0089f,0.6788f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.0089f,-0.6788f,0.7342f,0.0096f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4005f,0.8492f,0.2399f],left_rotation:[0.0921f,0.1605f,-0.8345f,0.519f]}}
particle minecraft:campfire_cosy_smoke -93.96 65.12 -33.85 0.062 0.022 -0.051 1 0 force
particle minecraft:cloud -93.96 65.32 -33.85 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -95.64 65.12 -33.52 -0.017 0.022 -0.024 1 0 force
particle minecraft:cloud -95.64 65.32 -33.52 0.35 0.18 0.35 0.02 3 force
