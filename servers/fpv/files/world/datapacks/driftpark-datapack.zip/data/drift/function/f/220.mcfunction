tp @e[type=minecraft:item_display,tag=drift.kaze] 39.112 65 -49.881 66.06 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0.0052f,0.0001f,0.0223f,0.9997f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.975f,-0.0537f,-0.2158f,0.0004f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.2171f,-0.0231f,0.9747f,0.0485f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.9999f,0.0131f,0.0001f,0.0087f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.0001f,0.0087f,0.9999f,0.0131f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4078f,0.8415f,0.1189f],left_rotation:[0.0714f,0.1824f,-0.8963f,0.3979f]}}
particle minecraft:campfire_cosy_smoke 41.59 65.12 -49.5 0.059 0.022 0.047 1 0 force
particle minecraft:cloud 41.59 65.32 -49.5 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 41.59 65.42 -49.5 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke 40.96 65.12 -51.04 0.028 0.022 -0.024 1 0 force
particle minecraft:cloud 40.96 65.32 -51.04 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 40.96 65.42 -51.04 0.45 0.2 0.45 0.008 1 force
tp @e[type=minecraft:item_display,tag=drift.onyx] 53.479 65 -46.842 83.26 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0.0109f,0.0002f,0.0222f,0.9997f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.3884f,-0.2209f,-0.0375f,0.8938f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.1317f,0.9027f,-0.3673f,0.1813f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.9999f,0.0131f,0.0001f,0.0087f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.0001f,0.0087f,0.9999f,0.0131f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4075f,0.8371f,0.2688f],left_rotation:[0.0766f,0.1864f,-0.8887f,0.4119f]}}
particle minecraft:campfire_cosy_smoke 56.05 65.12 -45.64 0.056 0.022 0.064 1 0 force
particle minecraft:cloud 56.05 65.32 -45.64 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 55.89 65.12 -47.34 0.047 0.022 -0.013 1 0 force
particle minecraft:cloud 55.89 65.32 -47.34 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 55.89 65.42 -47.34 0.45 0.2 0.45 0.008 1 force
