tp @e[type=minecraft:item_display,tag=drift.kaze] -2.236 65 -20.92 74.32 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0.011f,-0.0002f,-0.0211f,0.9997f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.2879f,0.2687f,-0.0273f,0.9188f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.124f,-0.9267f,-0.2613f,0.2399f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.3523f,0.0046f,0.0123f,0.9358f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.0123f,0.9358f,0.3523f,0.0046f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.3335f,0.8722f,0.129f],left_rotation:[0.1486f,-0.1363f,0.6312f,0.749f]}}
particle minecraft:campfire_cosy_smoke -0.16 65.12 -21.27 0.045 0.022 0.004 1 0 force
particle minecraft:cloud -0.16 65.32 -21.27 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -0.68 65.12 -22.86 0.007 0.022 -0.076 1 0 force
particle minecraft:cloud -0.68 65.32 -22.86 0.35 0.18 0.35 0.02 3 force
tp @e[type=minecraft:item_display,tag=drift.onyx] 4.518 65 -32.034 35.51 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0059f,0f,0.0036f,1f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.9457f,0.0668f,-0.0346f,0.3163f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.0681f,0.3217f,0.9438f,0.0322f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.3523f,0.0046f,0.0123f,0.9358f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.0123f,0.9358f,0.3523f,0.0046f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.3762f,0.8602f,0.2399f],left_rotation:[0.1631f,0.0874f,-0.4581f,0.8694f]}}
