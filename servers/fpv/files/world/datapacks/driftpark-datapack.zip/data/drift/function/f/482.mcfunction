tp @e[type=minecraft:item_display,tag=drift.kaze] -90.69 65 17.274 -25.9 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0027f,0f,0.0112f,0.9999f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.996f,0.0497f,0.0557f,0.0501f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.0507f,0.0446f,0.9962f,0.0547f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.9928f,0.013f,0.0016f,0.1188f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.0016f,0.1188f,0.9928f,0.013f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.3892f,0.8521f,0.1053f],left_rotation:[0.1678f,-0.085f,0.4635f,0.8659f]}}
tp @e[type=minecraft:item_display,tag=drift.onyx] -95.65 65 0.791 -25.51 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0058f,-0.0001f,0.0132f,0.9999f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.9592f,0.0247f,0.1105f,0.259f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.0838f,0.2488f,0.9619f,0.076f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.9928f,0.013f,0.0016f,0.1188f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.0016f,0.1188f,0.9928f,0.013f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.3926f,0.8528f,0.2399f],left_rotation:[0.1159f,-0.1443f,0.7821f,0.5951f]}}
particle minecraft:campfire_cosy_smoke -95.76 65.12 -1.98 0.023 0.015 -0.079 1 0 force
particle minecraft:campfire_cosy_smoke -97.3 65.12 -1.23 -0.058 0.015 -0.034 1 0 force
