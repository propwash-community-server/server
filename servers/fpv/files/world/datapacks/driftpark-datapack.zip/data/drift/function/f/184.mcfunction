tp @e[type=minecraft:item_display,tag=drift.kaze] 74.769 65 -32.094 110.04 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.005f,-0.0001f,0.0223f,0.9997f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.978f,-0.0688f,-0.1778f,0.0843f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.1876f,-0.1035f,0.9762f,0.0337f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.9968f,-0.013f,0.001f,0.0783f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.001f,-0.0783f,0.9968f,0.013f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4079f,0.8438f,0.1013f],left_rotation:[0.0131f,0.1854f,-0.9761f,0.113f]}}
particle minecraft:campfire_cosy_smoke 76.45 65.12 -30.08 0.026 0.021 0.078 1 0 force
particle minecraft:cloud 76.45 65.32 -30.08 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke 76.45 65.42 -30.08 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke 77.05 65.12 -31.64 0.055 0.021 0.008 1 0 force
particle minecraft:cloud 77.05 65.32 -31.64 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke 77.05 65.42 -31.64 0.45 0.2 0.45 0.008 1 force
tp @e[type=minecraft:item_display,tag=drift.onyx] 84.286 65 -20.853 121.24 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0.0021f,0f,0.0223f,0.9998f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.4808f,-0.2185f,-0.0623f,0.8469f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.1517f,0.8581f,-0.4604f,0.1692f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.9968f,-0.013f,0.001f,0.0783f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.001f,-0.0783f,0.9968f,0.013f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4078f,0.8417f,0.2535f],left_rotation:[0.0785f,0.1761f,-0.8777f,0.4387f]}}
particle minecraft:campfire_cosy_smoke 85.52 65.12 -18.42 -0.005 0.022 0.074 1 0 force
particle minecraft:cloud 85.52 65.32 -18.42 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 85.52 65.42 -18.42 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke 86.44 65.12 -19.87 0.045 0.022 0.02 1 0 force
particle minecraft:cloud 86.44 65.32 -19.87 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 86.44 65.42 -19.87 0.45 0.2 0.45 0.008 1 force
