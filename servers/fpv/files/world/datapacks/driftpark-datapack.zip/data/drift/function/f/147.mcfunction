tp @e[type=minecraft:item_display,tag=drift.kaze] 90.056 65 3.045 151.7 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0f,0f,0.0223f,0.9998f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.4119f,-0.1491f,0.1278f,0.8898f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.0349f,0.8813f,0.4298f,0.1932f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.4166f,0.0055f,0.0119f,0.909f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.0119f,0.909f,0.4166f,0.0055f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4079f,0.8427f,0.11f],left_rotation:[0.0239f,0.1893f,-0.9675f,0.1661f]}}
particle minecraft:campfire_cosy_smoke 89.95 65.12 5.66 -0.031 0.021 0.077 1 0 force
particle minecraft:cloud 89.95 65.32 5.66 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke 91.43 65.12 4.89 0.043 0.021 0.045 1 0 force
particle minecraft:cloud 91.43 65.32 4.89 0.35 0.18 0.35 0.02 2 force
tp @e[type=minecraft:item_display,tag=drift.onyx] 89.469 65 18.026 163.87 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0013f,0f,0.0223f,0.9998f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.9109f,-0.0273f,0.2226f,0.3465f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.1874f,0.325f,0.9187f,0.1232f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.4166f,0.0055f,0.0119f,0.909f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.0119f,0.909f,0.4166f,0.0055f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4079f,0.8434f,0.2477f],left_rotation:[0.0722f,0.1752f,-0.8903f,0.4141f]}}
particle minecraft:campfire_cosy_smoke 88.76 65.12 20.65 -0.044 0.022 0.072 1 0 force
particle minecraft:cloud 88.76 65.32 20.65 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 90.41 65.12 20.21 0.032 0.022 0.033 1 0 force
particle minecraft:cloud 90.41 65.32 20.21 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 90.41 65.42 20.21 0.45 0.2 0.45 0.008 1 force
