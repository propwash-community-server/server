tp @e[type=minecraft:item_display,tag=drift.kaze] 87.155 65 22.848 172.92 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0018f,0f,0.0223f,0.9998f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.6602f,-0.1063f,0.1691f,0.7241f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.0939f,0.7103f,0.675f,0.1763f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.6724f,0.0088f,0.0097f,0.7401f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.0097f,0.7401f,0.6724f,0.0088f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4079f,0.8431f,0.1068f],left_rotation:[0.0296f,0.1867f,-0.962f,0.197f]}}
particle minecraft:campfire_cosy_smoke 86.1 65.12 25.21 -0.059 0.022 0.053 1 0 force
particle minecraft:cloud 86.1 65.32 25.21 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke 86.1 65.42 25.21 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke 87.77 65.12 25.04 0.026 0.022 0.052 1 0 force
particle minecraft:cloud 87.77 65.32 25.04 0.35 0.18 0.35 0.02 2 force
tp @e[type=minecraft:item_display,tag=drift.onyx] 81.189 65 36.08 -174.45 0
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.9613f,0.018f,0.2283f,0.1532f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.2135f,0.13f,0.9647f,0.083f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.6724f,0.0088f,0.0097f,0.7401f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.0097f,0.7401f,0.6724f,0.0088f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4078f,0.8407f,0.2566f],left_rotation:[0.0823f,0.1763f,-0.8696f,0.4538f]}}
particle minecraft:campfire_cosy_smoke 79.52 65.12 38.24 -0.082 0.022 0.038 1 0 force
particle minecraft:cloud 79.52 65.32 38.24 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 79.52 65.42 38.24 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke 81.22 65.12 38.44 0.009 0.022 0.039 1 0 force
particle minecraft:cloud 81.22 65.32 38.44 0.35 0.18 0.35 0.02 3 force
