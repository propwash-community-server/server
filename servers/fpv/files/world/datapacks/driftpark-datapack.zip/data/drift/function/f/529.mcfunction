tp @e[type=minecraft:item_display,tag=drift.kaze] -63.385 65 57.836 -89.87 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0059f,-0.0001f,0.0206f,0.9998f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.0173f,-0.1906f,0.0567f,0.9799f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.046f,0.9793f,0.0374f,0.1934f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.029f,0.0004f,0.0131f,0.9995f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.0131f,0.9995f,0.029f,0.0004f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4051f,0.8453f,0.0999f],left_rotation:[0.0278f,0.183f,-0.9647f,0.1873f]}}
particle minecraft:campfire_cosy_smoke -65.52 65.12 56.55 -0.037 0.022 -0.064 1 0 force
particle minecraft:cloud -65.52 65.32 56.55 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -65.52 65.42 56.55 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke -65.55 65.12 58.22 -0.047 0.022 0.011 1 0 force
particle minecraft:cloud -65.55 65.32 58.22 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -65.55 65.42 58.22 0.45 0.2 0.45 0.008 1 force
tp @e[type=minecraft:item_display,tag=drift.onyx] -73.999 65 51.316 -80.64 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0.008f,0.0002f,0.0223f,0.9997f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.1231f,-0.2491f,0.0867f,0.9567f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.0134f,0.9529f,0.15f,0.2634f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.029f,0.0004f,0.0131f,0.9995f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.0131f,0.9995f,0.029f,0.0004f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4077f,0.8386f,0.2638f],left_rotation:[0.1378f,0.1431f,-0.675f,0.7106f]}}
particle minecraft:campfire_cosy_smoke -75.84 65.12 49.57 -0.022 0.022 -0.062 1 0 force
particle minecraft:cloud -75.84 65.32 49.57 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -76.16 65.12 51.25 -0.032 0.022 0.014 1 0 force
particle minecraft:cloud -76.16 65.32 51.25 0.35 0.18 0.35 0.02 3 force
