tp @e[type=minecraft:item_display,tag=drift.kaze] 2.493 65 -28.044 50.36 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0058f,0f,-0.0065f,1f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.8806f,0.1182f,-0.1168f,0.4438f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.1641f,-0.4585f,-0.873f,0.0263f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.9196f,0.012f,0.0051f,0.3927f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.0051f,0.3927f,0.9196f,0.012f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.3588f,0.866f,0.1f],left_rotation:[0.0272f,0.1831f,-0.9738f,0.1319f]}}
particle minecraft:campfire_cosy_smoke 4.48 65.12 -29.11 0.042 0.018 -0.013 1 0 force
particle minecraft:cloud 4.48 65.32 -29.11 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke 4.48 65.42 -29.11 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke 3.35 65.12 -30.34 -0.007 0.018 -0.076 1 0 force
particle minecraft:cloud 3.35 65.32 -30.34 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke 3.35 65.42 -30.34 0.45 0.2 0.45 0.008 1 force
tp @e[type=minecraft:item_display,tag=drift.onyx] 7.918 65 -38.705 9.41 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0058f,-0.0001f,0.0173f,0.9998f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.456f,-0.1884f,-0.0387f,0.869f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.1302f,0.8778f,-0.4387f,0.1415f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.9196f,0.012f,0.0051f,0.3927f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.0051f,0.3927f,0.9196f,0.012f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.3997f,0.8495f,0.2399f],left_rotation:[0.017f,0.1843f,-0.9749f,0.1238f]}}
particle minecraft:campfire_cosy_smoke 9.44 65.12 -40.61 0.065 0.022 -0.026 1 0 force
particle minecraft:cloud 9.44 65.32 -40.61 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 9.44 65.42 -40.61 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke 7.74 65.12 -40.85 -0.008 0.022 -0.03 1 0 force
particle minecraft:cloud 7.74 65.32 -40.85 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 7.74 65.42 -40.85 0.45 0.2 0.45 0.008 1 force
