tp @e[type=minecraft:item_display,tag=drift.kaze] 59.815 65 -43.056 94.51 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0014f,0f,0.0221f,0.9998f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.5324f,-0.1213f,0.1415f,0.8257f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.0555f,0.8154f,0.548f,0.1779f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.5339f,0.007f,0.0111f,0.8454f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.0111f,0.8454f,0.5339f,0.007f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4077f,0.8431f,0.1076f],left_rotation:[0.0057f,0.1894f,-0.9792f,0.073f]}}
particle minecraft:campfire_cosy_smoke 62.13 65.12 -41.5 0.052 0.02 0.062 1 0 force
particle minecraft:cloud 62.13 65.32 -41.5 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke 62.13 65.42 -41.5 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke 62.29 65.12 -43.16 0.054 0.02 -0.016 1 0 force
particle minecraft:cloud 62.29 65.32 -43.16 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke 62.29 65.42 -43.16 0.45 0.2 0.45 0.008 1 force
tp @e[type=minecraft:item_display,tag=drift.onyx] 73.732 65 -34.186 104.68 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0054f,-0.0001f,0.0223f,0.9997f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.9753f,-0.0649f,-0.204f,0.054f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.2108f,-0.0757f,0.9739f,0.0373f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.5339f,0.007f,0.0111f,0.8454f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.0111f,0.8454f,0.5339f,0.007f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.408f,0.8453f,0.2408f],left_rotation:[0.0537f,0.1776f,-0.9269f,0.3262f]}}
particle minecraft:campfire_cosy_smoke 75.68 65.12 -32.23 0.037 0.022 0.073 1 0 force
particle minecraft:cloud 75.68 65.32 -32.23 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 75.68 65.42 -32.23 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke 76.14 65.12 -33.88 0.049 0.022 -0.007 1 0 force
particle minecraft:cloud 76.14 65.32 -33.88 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 76.14 65.42 -33.88 0.45 0.2 0.45 0.008 1 force
