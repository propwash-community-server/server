tp @e[type=minecraft:item_display,tag=drift.kaze] -55.06 65 61.143 -96.33 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0059f,-0.0001f,0.0186f,0.9998f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.6971f,-0.1591f,-0.0845f,0.694f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.1579f,0.7067f,-0.6842f,0.0867f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.7019f,-0.0092f,0.0093f,0.7122f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.0093f,-0.7122f,0.7019f,0.0092f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4017f,0.8469f,0.0998f],left_rotation:[-0.0047f,0.185f,-0.9827f,0.0115f]}}
particle minecraft:campfire_cosy_smoke -57.44 65.12 60.13 -0.06 0.02 -0.061 1 0 force
particle minecraft:cloud -57.44 65.32 60.13 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -57.44 65.42 60.13 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke -57.27 65.12 61.79 -0.039 0.02 0.023 1 0 force
particle minecraft:cloud -57.27 65.32 61.79 0.35 0.18 0.35 0.02 2 force
tp @e[type=minecraft:item_display,tag=drift.onyx] -67.879 65 56.301 -89.72 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0059f,-0.0001f,0.0216f,0.9997f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.7011f,-0.2003f,-0.1312f,0.6716f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.2026f,0.6891f,-0.6839f,0.1277f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.7019f,-0.0092f,0.0093f,0.7122f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.0093f,-0.7122f,0.7019f,0.0092f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.407f,0.8461f,0.2399f],left_rotation:[0.0945f,0.1591f,-0.8225f,0.5379f]}}
particle minecraft:campfire_cosy_smoke -70.04 65.12 54.91 -0.036 0.022 -0.059 1 0 force
particle minecraft:cloud -70.04 65.32 54.91 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -70.07 65.12 56.62 -0.039 0.022 0.01 1 0 force
particle minecraft:cloud -70.07 65.32 56.62 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -70.07 65.42 56.62 0.45 0.2 0.45 0.008 1 force
