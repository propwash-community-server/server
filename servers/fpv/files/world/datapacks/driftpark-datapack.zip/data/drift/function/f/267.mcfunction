tp @e[type=minecraft:item_display,tag=drift.kaze] 5.992 65 -34.135 25.24 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0059f,-0.0001f,0.0088f,0.9999f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.0927f,-0.027f,0.0551f,0.9938f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.049f,0.9935f,0.096f,0.0369f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.1389f,0.0018f,0.013f,0.9902f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.013f,0.9902f,0.1389f,0.0018f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.3852f,0.8546f,0.0999f],left_rotation:[0.1778f,-0.0511f,0.2883f,0.9395f]}}
tp @e[type=minecraft:item_display,tag=drift.onyx] 11.97 65 -43.187 9.06 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0.0024f,0.0001f,0.0222f,0.9998f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.0751f,-0.2624f,0.075f,0.9591f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.0254f,0.9565f,0.1031f,0.2717f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.1389f,0.0018f,0.013f,0.9902f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.013f,0.9902f,0.1389f,0.0018f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4078f,0.8415f,0.2542f],left_rotation:[0.1457f,0.1269f,-0.6108f,0.7679f]}}
particle minecraft:campfire_cosy_smoke 13.62 65.12 -44.91 0.066 0.022 -0.025 1 0 force
particle minecraft:cloud 13.62 65.32 -44.91 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 11.94 65.12 -45.21 -0.008 0.022 -0.037 1 0 force
particle minecraft:cloud 11.94 65.32 -45.21 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 11.94 65.42 -45.21 0.45 0.2 0.45 0.008 1 force
