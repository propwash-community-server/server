tp @e[type=minecraft:item_display,tag=drift.kaze] 24.61 65 -48.73 41.87 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0.0037f,0.0001f,0.0223f,0.9997f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.4531f,-0.1828f,0.1574f,0.8582f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.0681f,0.8464f,0.4748f,0.2314f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.4583f,0.006f,0.0116f,0.8887f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.0116f,0.8887f,0.4583f,0.006f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4079f,0.8418f,0.1164f],left_rotation:[0.102f,0.1655f,-0.8113f,0.5514f]}}
particle minecraft:campfire_cosy_smoke 26.98 65.12 -49.33 0.071 0.022 0.018 1 0 force
particle minecraft:cloud 26.98 65.32 -49.33 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 25.77 65.12 -50.48 0.013 0.022 -0.034 1 0 force
particle minecraft:cloud 25.77 65.32 -50.48 0.35 0.18 0.35 0.02 3 force
tp @e[type=minecraft:item_display,tag=drift.onyx] 37.282 65 -50.933 59.37 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0.0043f,0.0001f,0.0223f,0.9997f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.9557f,-0.0922f,-0.2335f,0.1536f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.251f,-0.1789f,0.9513f,0.0077f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.4583f,0.006f,0.0116f,0.8887f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.0116f,0.8887f,0.4583f,0.006f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4078f,0.8405f,0.2573f],left_rotation:[0.1174f,0.1557f,-0.7561f,0.6248f]}}
particle minecraft:campfire_cosy_smoke 39.89 65.12 -50.81 0.077 0.022 0.04 1 0 force
particle minecraft:cloud 39.89 65.32 -50.81 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 39.06 65.12 -52.3 0.037 0.022 -0.028 1 0 force
particle minecraft:cloud 39.06 65.32 -52.3 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 39.06 65.42 -52.3 0.45 0.2 0.45 0.008 1 force
