tp @e[type=minecraft:item_display,tag=drift.kaze] 67.015 65 -38.607 101.78 0
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.7394f,-0.0748f,0.1659f,0.6482f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.0987f,0.6344f,0.7513f,0.1529f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.7459f,0.0098f,0.0087f,0.6659f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.0087f,0.6659f,0.7459f,0.0098f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4079f,0.8439f,0.0999f],left_rotation:[-0.0022f,0.1851f,-0.9822f,0.0323f]}}
particle minecraft:campfire_cosy_smoke 69.06 65.12 -36.82 0.043 0.02 0.083 1 0 force
particle minecraft:cloud 69.06 65.32 -36.82 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke 69.06 65.42 -36.82 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke 69.42 65.12 -38.45 0.055 0.02 0.001 1 0 force
particle minecraft:cloud 69.42 65.32 -38.45 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke 69.42 65.42 -38.45 0.45 0.2 0.45 0.008 1 force
tp @e[type=minecraft:item_display,tag=drift.onyx] 79.012 65 -28.72 111.4 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0038f,-0.0001f,0.0223f,0.9997f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.9328f,-0.1139f,-0.1897f,0.2845f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.2206f,0.306f,-0.926f,0.0165f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.7459f,0.0098f,0.0087f,0.6659f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.0087f,0.6659f,0.7459f,0.0098f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.408f,0.8446f,0.2434f],left_rotation:[0.0663f,0.1749f,-0.9022f,0.3885f]}}
particle minecraft:campfire_cosy_smoke 80.66 65.12 -26.57 0.01 0.022 0.086 1 0 force
particle minecraft:cloud 80.66 65.32 -26.57 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 80.66 65.42 -26.57 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke 81.31 65.12 -28.15 0.057 0.022 0.012 1 0 force
particle minecraft:cloud 81.31 65.32 -28.15 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 81.31 65.42 -28.15 0.45 0.2 0.45 0.008 1 force
