tp @e[type=minecraft:item_display,tag=drift.kaze] -58.435 65 -40.788 88.29 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0.01f,0.0002f,0.0222f,0.9997f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.8732f,-0.1628f,-0.2242f,0.401f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.2676f,0.4268f,-0.8609f,0.072f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.3954f,0.0052f,0.012f,0.9184f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.012f,0.9184f,0.3954f,0.0052f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4077f,0.8403f,0.1272f],left_rotation:[0.1565f,0.1256f,-0.5786f,0.7906f]}}
particle minecraft:campfire_cosy_smoke -56.46 65.12 -39.44 0.029 0.022 0.073 1 0 force
particle minecraft:cloud -56.46 65.32 -39.44 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -56.46 65.42 -39.44 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke -56.46 65.12 -41.11 0.029 0.022 -0.021 1 0 force
particle minecraft:cloud -56.46 65.32 -41.11 0.35 0.18 0.35 0.02 3 force
tp @e[type=minecraft:item_display,tag=drift.onyx] -48.787 65 -31.543 117.17 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0059f,0f,0.0083f,0.9999f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.6429f,-0.1755f,-0.0817f,0.7411f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.1601f,0.7538f,-0.628f,0.1089f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.3954f,0.0052f,0.012f,0.9184f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.012f,0.9184f,0.3954f,0.0052f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.3843f,0.8566f,0.2399f],left_rotation:[0.0209f,0.1839f,-0.9744f,0.1273f]}}
particle minecraft:campfire_cosy_smoke -47.42 65.12 -29.26 0.014 0.02 0.083 1 0 force
particle minecraft:cloud -47.42 65.32 -29.26 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -47.42 65.42 -29.26 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke -46.56 65.12 -30.74 0.045 0.02 0.001 1 0 force
particle minecraft:cloud -46.56 65.32 -30.74 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -46.56 65.42 -30.74 0.45 0.2 0.45 0.008 1 force
