tp @e[type=minecraft:item_display,tag=drift.kaze] -96.92 65 -13.293 -24.52 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0059f,-0.0001f,0.0188f,0.9998f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.6996f,-0.0837f,0.1603f,0.6912f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.0885f,0.6782f,0.7123f,0.1577f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.6681f,0.0087f,0.0097f,0.744f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.0097f,0.744f,0.6681f,0.0087f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4021f,0.8467f,0.0999f],left_rotation:[-0.0037f,0.185f,-0.9826f,0.0175f]}}
particle minecraft:campfire_cosy_smoke -96.69 65.12 -15.84 0.029 0.02 -0.064 1 0 force
particle minecraft:cloud -96.69 65.32 -15.84 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -96.69 65.42 -15.84 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke -98.22 65.12 -15.17 -0.046 0.02 -0.042 1 0 force
particle minecraft:cloud -98.22 65.32 -15.17 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -98.22 65.42 -15.17 0.45 0.2 0.45 0.008 1 force
tp @e[type=minecraft:item_display,tag=drift.onyx] -96.343 65 -26.618 -16.26 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0059f,-0.0001f,0.0171f,0.9998f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.411f,-0.176f,0.1411f,0.8833f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.049f,0.8733f,0.4318f,0.2202f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.6681f,0.0087f,0.0097f,0.744f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.0097f,0.744f,0.6681f,0.0087f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.3994f,0.8497f,0.2399f],left_rotation:[0.0736f,0.1698f,-0.8879f,0.4213f]}}
particle minecraft:campfire_cosy_smoke -95.68 65.12 -29.06 0.043 0.022 -0.059 1 0 force
particle minecraft:cloud -95.68 65.32 -29.06 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -97.33 65.12 -28.61 -0.031 0.022 -0.041 1 0 force
particle minecraft:cloud -97.33 65.32 -28.61 0.35 0.18 0.35 0.02 3 force
