tp @e[type=minecraft:item_display,tag=drift.kaze] -23.894 65 -11.356 136.66 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0027f,0.0001f,-0.0223f,0.9997f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.7422f,0.2094f,-0.168f,0.614f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.2335f,-0.635f,-0.7243f,0.1326f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.8591f,-0.0112f,0.0067f,0.5116f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.0067f,-0.5116f,0.8591f,0.0112f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.3313f,0.8762f,0.1053f],left_rotation:[0.1365f,-0.1294f,0.6434f,0.7421f]}}
particle minecraft:campfire_cosy_smoke -22.84 65.12 -9.74 0.011 0.022 0.029 1 0 force
particle minecraft:cloud -22.84 65.32 -9.74 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -21.65 65.12 -10.92 0.065 0.022 -0.033 1 0 force
particle minecraft:cloud -21.65 65.32 -10.92 0.35 0.18 0.35 0.02 3 force
tp @e[type=minecraft:item_display,tag=drift.onyx] -14.177 65 -11.005 120.39 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0018f,0f,-0.0223f,0.9998f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.7131f,0.1611f,0.266f,0.6283f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.2014f,-0.6038f,0.7339f,0.2369f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.8591f,-0.0112f,0.0067f,0.5116f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.0067f,-0.5116f,0.8591f,0.0112f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.3313f,0.8765f,0.2468f],left_rotation:[0.1774f,-0.0651f,0.2971f,0.936f]}}
particle minecraft:campfire_cosy_smoke -12.73 65.12 -9.77 0.007 0.022 0.023 1 0 force
particle minecraft:cloud -12.73 65.32 -9.77 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -11.91 65.12 -11.27 0.054 0.022 -0.051 1 0 force
particle minecraft:cloud -11.91 65.32 -11.27 0.35 0.18 0.35 0.02 3 force
