tp @e[type=minecraft:item_display,tag=drift.kaze] 60.904 65 -42.459 95.63 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0046f,-0.0001f,0.0222f,0.9997f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.6583f,-0.167f,-0.079f,0.7298f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.1561f,0.7421f,-0.6443f,0.0987f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.6767f,-0.0089f,0.0096f,0.7362f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.0096f,-0.7362f,0.6767f,0.0089f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4079f,0.8437f,0.1022f],left_rotation:[0.0027f,0.1863f,-0.9808f,0.0576f]}}
particle minecraft:campfire_cosy_smoke 63.18 65.12 -40.87 0.051 0.02 0.077 1 0 force
particle minecraft:cloud 63.18 65.32 -40.87 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke 63.18 65.42 -40.87 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke 63.37 65.12 -42.52 0.057 0.02 -0.009 1 0 force
particle minecraft:cloud 63.37 65.32 -42.52 0.35 0.18 0.35 0.02 2 force
tp @e[type=minecraft:item_display,tag=drift.onyx] 74.55 65 -33.433 105.6 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0052f,-0.0001f,0.0223f,0.9997f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.3017f,-0.1817f,0.1153f,0.9288f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.0183f,0.9218f,0.3224f,0.2144f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.6767f,-0.0089f,0.0096f,0.7362f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.0096f,-0.7362f,0.6767f,0.0089f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.408f,0.8452f,0.2411f],left_rotation:[0.0557f,0.1772f,-0.9234f,0.336f]}}
particle minecraft:campfire_cosy_smoke 76.46 65.12 -31.45 0.033 0.022 0.079 1 0 force
particle minecraft:cloud 76.46 65.32 -31.45 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 76.95 65.12 -33.09 0.05 0.022 0.006 1 0 force
particle minecraft:cloud 76.95 65.32 -33.09 0.35 0.18 0.35 0.02 3 force
