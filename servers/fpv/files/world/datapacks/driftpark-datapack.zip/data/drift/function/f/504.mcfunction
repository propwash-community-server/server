tp @e[type=minecraft:item_display,tag=drift.kaze] -79.706 65 42.231 -58.99 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0.0111f,0.0002f,0.0188f,0.9998f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.8937f,-0.1339f,-0.1719f,0.3922f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.2141f,0.4125f,-0.8845f,0.0407f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.9388f,-0.0123f,0.0045f,0.3441f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.0045f,-0.3441f,0.9388f,0.0123f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.402f,0.8428f,0.1291f],left_rotation:[0.0662f,0.1906f,-0.9125f,0.356f]}}
particle minecraft:campfire_cosy_smoke -80.9 65.12 39.88 -0.015 0.022 -0.078 1 0 force
particle minecraft:cloud -80.9 65.32 39.88 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -80.9 65.42 39.88 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke -81.81 65.12 41.28 -0.043 0.022 -0.01 1 0 force
particle minecraft:cloud -81.81 65.32 41.28 0.35 0.18 0.35 0.02 3 force
tp @e[type=minecraft:item_display,tag=drift.onyx] -87.331 65 27.126 -34.52 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0.0004f,0f,0.0113f,0.9999f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.9422f,-0.0792f,-0.0704f,0.3177f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.1042f,-0.3269f,0.9391f,0.0194f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.9388f,-0.0123f,0.0045f,0.3441f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.0045f,-0.3441f,0.9388f,0.0123f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.3893f,0.8512f,0.2507f],left_rotation:[0.1302f,-0.14f,0.7338f,0.6519f]}}
particle minecraft:campfire_cosy_smoke -87.87 65.12 24.27 0.013 0.014 -0.083 1 0 force
particle minecraft:campfire_cosy_smoke -89.31 65.12 25.2 -0.062 0.014 -0.048 1 0 force
