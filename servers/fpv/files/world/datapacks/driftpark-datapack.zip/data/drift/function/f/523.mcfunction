tp @e[type=minecraft:item_display,tag=drift.kaze] -68.131 65 55.052 -85.11 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0059f,-0.0001f,0.0218f,0.9997f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.9761f,-0.0599f,-0.2069f,0.0299f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.2112f,-0.0518f,0.9751f,0.0424f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.999f,-0.0131f,0.0006f,0.0435f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.0006f,-0.0435f,0.999f,0.0131f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4072f,0.8443f,0.0999f],left_rotation:[0.056f,0.1764f,-0.9228f,0.3378f]}}
particle minecraft:campfire_cosy_smoke -70.07 65.12 53.58 -0.04 0.022 -0.061 1 0 force
particle minecraft:cloud -70.07 65.32 53.58 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -70.07 65.42 53.58 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke -70.24 65.12 55.25 -0.037 0.022 0.005 1 0 force
particle minecraft:cloud -70.24 65.32 55.25 0.35 0.18 0.35 0.02 3 force
tp @e[type=minecraft:item_display,tag=drift.onyx] -77.613 65 47.031 -71.99 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0.0111f,0.0002f,0.0215f,0.9997f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.9577f,-0.0827f,-0.2545f,0.1058f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.267f,-0.1332f,0.9543f,0.0175f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.999f,-0.0131f,0.0006f,0.0435f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.0006f,-0.0435f,0.999f,0.0131f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4065f,0.8375f,0.2691f],left_rotation:[0.1452f,0.14f,-0.6486f,0.7339f]}}
particle minecraft:campfire_cosy_smoke -79.24 65.12 44.93 -0.023 0.022 -0.069 1 0 force
particle minecraft:cloud -79.24 65.32 44.93 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -79.24 65.42 44.93 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke -79.82 65.12 46.54 -0.043 0.022 0.003 1 0 force
particle minecraft:cloud -79.82 65.32 46.54 0.35 0.18 0.35 0.02 3 force
