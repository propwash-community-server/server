tp @e[type=minecraft:item_display,tag=drift.kaze] 1.051 65 -25.634 58.71 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0057f,0.0001f,-0.0136f,0.9999f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.93f,0.0118f,0.2092f,0.3021f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.1786f,-0.2818f,0.9363f,0.1096f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.9306f,-0.0122f,0.0048f,0.3658f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.0048f,-0.3658f,0.9306f,0.0122f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.3464f,0.8709f,0.1003f],left_rotation:[0.0475f,-0.179f,0.9426f,0.278f]}}
particle minecraft:campfire_cosy_smoke 3.1 65.12 -26.48 0.05 0.022 -0.012 1 0 force
particle minecraft:cloud 3.1 65.32 -26.48 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke 3.1 65.42 -26.48 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke 2.16 65.12 -27.87 -0.003 0.022 -0.082 1 0 force
particle minecraft:cloud 2.16 65.32 -27.87 0.35 0.18 0.35 0.02 2 force
tp @e[type=minecraft:item_display,tag=drift.onyx] 6.545 65 -36.715 15.25 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0059f,-0.0001f,0.0135f,0.9999f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.0508f,-0.1236f,0.0465f,0.9899f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.0573f,0.9905f,-0.0381f,0.1189f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.9306f,-0.0122f,0.0048f,0.3658f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.0048f,-0.3658f,0.9306f,0.0122f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.3931f,0.8526f,0.2398f],left_rotation:[0.0867f,-0.1634f,0.8802f,0.437f]}}
particle minecraft:campfire_cosy_smoke 8.14 65.12 -38.58 0.064 0.017 -0.015 1 0 force
particle minecraft:cloud 8.14 65.32 -38.58 0.35 0.18 0.35 0.02 1 force
particle minecraft:campfire_cosy_smoke 6.47 65.12 -38.96 -0.012 0.017 -0.048 1 0 force
particle minecraft:cloud 6.47 65.32 -38.96 0.35 0.18 0.35 0.02 1 force
