tp @e[type=minecraft:item_display,tag=drift.kaze] 3.397 65 -29.622 44.35 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0059f,0f,-0.0022f,1f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.9898f,-0.0456f,0.1213f,0.0588f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.1158f,-0.0463f,0.9905f,0.0582f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.9921f,-0.013f,0.0016f,0.1245f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.0016f,-0.1245f,0.9921f,0.013f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.3661f,0.8629f,0.0999f],left_rotation:[0.0888f,0.1623f,-0.8642f,0.4679f]}}
particle minecraft:campfire_cosy_smoke 5.33 65.12 -30.84 0.058 0.015 -0.007 1 0 force
particle minecraft:campfire_cosy_smoke 4.07 65.12 -31.94 -0.016 0.015 -0.069 1 0 force
tp @e[type=minecraft:item_display,tag=drift.onyx] 8.875 65 -39.945 7.35 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0058f,-0.0001f,0.0194f,0.9998f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.339f,-0.1838f,0.1253f,0.9141f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.0299f,0.906f,0.3602f,0.2204f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.9921f,-0.013f,0.0016f,0.1245f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.0016f,-0.1245f,0.9921f,0.013f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4032f,0.8479f,0.2399f],left_rotation:[0.0681f,0.1721f,-0.8991f,0.3966f]}}
particle minecraft:campfire_cosy_smoke 10.38 65.12 -41.84 0.067 0.022 -0.028 1 0 force
particle minecraft:cloud 10.38 65.32 -41.84 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 8.69 65.12 -42.04 -0.024 0.022 -0.042 1 0 force
particle minecraft:cloud 8.69 65.32 -42.04 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 8.69 65.42 -42.04 0.45 0.2 0.45 0.008 1 force
