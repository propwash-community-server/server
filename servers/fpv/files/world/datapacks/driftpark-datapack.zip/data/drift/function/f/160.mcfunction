tp @e[type=minecraft:item_display,tag=drift.kaze] 87.666 65 -10.645 136.74 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0.0005f,0f,0.0223f,0.9998f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.9705f,-0.0796f,-0.1811f,0.1381f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.1966f,-0.1579f,0.9674f,0.0219f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.9906f,-0.013f,0.0018f,0.136f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.0018f,-0.136f,0.9906f,0.013f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4079f,0.8426f,0.1109f],left_rotation:[0.0265f,0.1895f,-0.965f,0.1791f]}}
particle minecraft:campfire_cosy_smoke 88.23 65.12 -8.08 -0.011 0.021 0.071 1 0 force
particle minecraft:cloud 88.23 65.32 -8.08 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke 89.47 65.12 -9.2 0.044 0.021 0.034 1 0 force
particle minecraft:cloud 89.47 65.32 -9.2 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke 89.47 65.42 -9.2 0.45 0.2 0.45 0.008 1 force
tp @e[type=minecraft:item_display,tag=drift.onyx] 90.933 65 4.089 149.21 0
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.5398f,-0.2095f,-0.0749f,0.8118f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.1607f,0.8242f,-0.5208f,0.1539f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.9906f,-0.013f,0.0018f,0.136f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.0018f,-0.136f,0.9906f,0.013f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4079f,0.8426f,0.2504f],left_rotation:[0.0699f,0.1778f,-0.8967f,0.3993f]}}
particle minecraft:campfire_cosy_smoke 90.9 65.12 6.83 -0.043 0.022 0.076 1 0 force
particle minecraft:cloud 90.9 65.32 6.83 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 90.9 65.42 6.83 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke 92.39 65.12 5.98 0.033 0.022 0.043 1 0 force
particle minecraft:cloud 92.39 65.32 5.98 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 92.39 65.42 5.98 0.45 0.2 0.45 0.008 1 force
