tp @e[type=minecraft:item_display,tag=drift.kaze] -94.179 65 5.286 -22.97 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0059f,-0.0001f,0.0104f,0.9999f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.8488f,0.0101f,0.0837f,0.522f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.0293f,0.516f,0.8524f,0.079f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.8147f,0.0107f,0.0076f,0.5797f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.0076f,0.5797f,0.8147f,0.0107f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.3878f,0.8534f,0.0999f],left_rotation:[0.1541f,-0.1024f,0.5606f,0.8072f]}}
particle minecraft:campfire_cosy_smoke -94.21 65.12 2.6 0.03 0.012 -0.071 1 0 force
particle minecraft:campfire_cosy_smoke -95.74 65.12 3.25 -0.05 0.012 -0.05 1 0 force
tp @e[type=minecraft:item_display,tag=drift.onyx] -97.502 65 -10.148 -29.19 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0059f,-0.0001f,0.0182f,0.9998f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.6681f,-0.1007f,0.1664f,0.7182f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.0919f,0.7047f,0.6824f,0.1715f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.8147f,0.0107f,0.0076f,0.5797f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.0076f,0.5797f,0.8147f,0.0107f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4012f,0.8488f,0.2399f],left_rotation:[0.0207f,0.1839f,-0.9719f,0.1452f]}}
particle minecraft:campfire_cosy_smoke -97.52 65.12 -12.85 0.034 0.021 -0.063 1 0 force
particle minecraft:cloud -97.52 65.32 -12.85 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -99.02 65.12 -12.03 -0.031 0.021 -0.029 1 0 force
particle minecraft:cloud -99.02 65.32 -12.03 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -99.02 65.42 -12.03 0.45 0.2 0.45 0.008 1 force
