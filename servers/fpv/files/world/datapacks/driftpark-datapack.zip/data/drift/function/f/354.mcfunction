tp @e[type=minecraft:item_display,tag=drift.kaze] -46.013 65 -27.456 134.13 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0059f,0f,-0.0011f,1f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.7247f,-0.0842f,-0.0128f,0.6838f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.0848f,0.6889f,-0.7199f,0.0085f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.655f,0.0086f,0.0099f,0.7555f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.0099f,0.7555f,0.655f,0.0086f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.3681f,0.862f,0.0999f],left_rotation:[0.1519f,-0.1057f,0.5597f,0.8078f]}}
tp @e[type=minecraft:item_display,tag=drift.onyx] -38.455 65 -17.49 162.63 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0059f,0.0001f,-0.0192f,0.9998f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.2412f,0.1924f,0.1044f,0.9455f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.0056f,-0.9397f,0.2627f,0.2188f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.655f,0.0086f,0.0099f,0.7555f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.0099f,0.7555f,0.655f,0.0086f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.3367f,0.8764f,0.2399f],left_rotation:[0.0622f,-0.1743f,0.9121f,0.3657f]}}
particle minecraft:campfire_cosy_smoke -38.24 65.12 -15.34 -0.004 0.022 0.049 1 0 force
particle minecraft:cloud -38.24 65.32 -15.34 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -38.24 65.42 -15.34 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke -36.6 65.12 -15.84 0.06 0.022 0.019 1 0 force
particle minecraft:cloud -36.6 65.32 -15.84 0.35 0.18 0.35 0.02 3 force
