tp @e[type=minecraft:item_display,tag=drift.kaze] -39.635 65 -19.882 156.86 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0058f,0.0001f,-0.0164f,0.9998f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.5101f,0.1527f,-0.0303f,0.8459f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.1194f,-0.8537f,-0.4969f,0.0999f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.8873f,-0.0116f,0.006f,0.4609f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.006f,-0.4609f,0.8873f,0.0116f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.3416f,0.8729f,0.0999f],left_rotation:[0.0474f,0.1789f,-0.9577f,0.2205f]}}
particle minecraft:campfire_cosy_smoke -39.32 65.12 -17.76 -0.017 0.019 0.04 1 0 force
particle minecraft:cloud -39.32 65.32 -17.76 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -39.32 65.42 -17.76 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke -37.78 65.12 -18.39 0.065 0.019 0.019 1 0 force
particle minecraft:cloud -37.78 65.32 -18.39 0.35 0.18 0.35 0.02 2 force
tp @e[type=minecraft:item_display,tag=drift.onyx] -31.367 65 -12.683 155.74 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0.0021f,0f,-0.0223f,0.9998f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.2547f,0.2539f,0.1265f,0.9245f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.03f,-0.9163f,0.2828f,0.2821f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.8873f,-0.0116f,0.006f,0.4609f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.006f,-0.4609f,0.8873f,0.0116f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.3314f,0.8746f,0.2536f],left_rotation:[0.1576f,-0.1111f,0.529f,0.8264f]}}
particle minecraft:campfire_cosy_smoke -30.83 65.12 -10.73 -0.006 0.022 0.023 1 0 force
particle minecraft:cloud -30.83 65.32 -10.73 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -29.29 65.12 -11.47 0.079 0.022 -0.011 1 0 force
particle minecraft:cloud -29.29 65.32 -11.47 0.35 0.18 0.35 0.02 3 force
