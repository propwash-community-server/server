tp @e[type=minecraft:item_display,tag=drift.kaze] -80.254 65 41.296 -57.03 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0.0111f,0.0002f,0.018f,0.9998f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.6131f,-0.1258f,0.17f,0.7612f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.0909f,0.7475f,0.6297f,0.1909f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.5774f,0.0076f,0.0107f,0.8164f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.0107f,0.8164f,0.5774f,0.0076f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4006f,0.8435f,0.1291f],left_rotation:[0.0545f,0.1942f,-0.9329f,0.2984f]}}
particle minecraft:campfire_cosy_smoke -81.39 65.12 38.9 -0.006 0.022 -0.081 1 0 force
particle minecraft:cloud -81.39 65.32 38.9 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -82.35 65.12 40.27 -0.041 0.022 -0.017 1 0 force
particle minecraft:cloud -82.35 65.32 40.27 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -82.35 65.42 40.27 0.45 0.2 0.45 0.008 1 force
tp @e[type=minecraft:item_display,tag=drift.onyx] -87.82 65 25.919 -32.95 0
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.5492f,-0.0403f,0.0896f,0.8299f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.0029f,0.8251f,0.5564f,0.0982f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.5774f,0.0076f,0.0107f,0.8164f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.0107f,0.8164f,0.5774f,0.0076f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.3893f,0.8514f,0.25f],left_rotation:[0.1409f,-0.1287f,0.6781f,0.7098f]}}
particle minecraft:campfire_cosy_smoke -88.31 65.12 23.06 0.006 0.013 -0.073 1 0 force
particle minecraft:campfire_cosy_smoke -89.77 65.12 23.95 -0.064 0.013 -0.045 1 0 force
