tp @e[type=minecraft:item_display,tag=drift.kaze] 68.887 65 -37.23 103.67 0
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.965f,0.0188f,0.1825f,0.1873f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.1638f,0.1691f,0.9684f,0.0826f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.9799f,0.0128f,0.0026f,0.199f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.0026f,0.199f,0.9799f,0.0128f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4079f,0.8439f,0.1f],left_rotation:[0.0003f,0.1851f,-0.9817f,0.0455f]}}
particle minecraft:campfire_cosy_smoke 70.85 65.12 -35.39 0.04 0.02 0.07 1 0 force
particle minecraft:cloud 70.85 65.32 -35.39 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke 70.85 65.42 -35.39 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke 71.27 65.12 -37 0.052 0.02 -0.012 1 0 force
particle minecraft:cloud 71.27 65.32 -37 0.35 0.18 0.35 0.02 2 force
tp @e[type=minecraft:item_display,tag=drift.onyx] 80.324 65 -27.075 113.4 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0014f,0f,0.0223f,0.9998f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.6696f,-0.1939f,-0.1095f,0.7085f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.1846f,0.7239f,-0.6529f,0.1246f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.9799f,0.0128f,0.0026f,0.199f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.0026f,0.199f,0.9799f,0.0128f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4079f,0.8434f,0.2475f],left_rotation:[0.0696f,0.1761f,-0.8961f,0.4013f]}}
particle minecraft:campfire_cosy_smoke 81.87 65.12 -24.87 0.007 0.022 0.074 1 0 force
particle minecraft:cloud 81.87 65.32 -24.87 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 82.59 65.12 -26.42 0.045 0.022 0.006 1 0 force
particle minecraft:cloud 82.59 65.32 -26.42 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 82.59 65.42 -26.42 0.45 0.2 0.45 0.008 1 force
