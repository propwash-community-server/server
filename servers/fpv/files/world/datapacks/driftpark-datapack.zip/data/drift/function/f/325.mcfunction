tp @e[type=minecraft:item_display,tag=drift.kaze] -28.238 65 -12.405 146.07 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0.0011f,0f,-0.0223f,0.9998f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.958f,0.0827f,-0.2531f,0.1064f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.2657f,0.1336f,0.9546f,0.0176f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.4991f,0.0065f,0.0113f,0.8664f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.0113f,0.8664f,0.4991f,0.0065f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.3314f,0.8754f,0.1118f],left_rotation:[0.1364f,-0.1349f,0.6582f,0.728f]}}
particle minecraft:campfire_cosy_smoke -27.45 65.12 -10.63 0.009 0.022 0.032 1 0 force
particle minecraft:cloud -27.45 65.32 -10.63 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -27.45 65.42 -10.63 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke -26.09 65.12 -11.59 0.069 0.022 -0.016 1 0 force
particle minecraft:cloud -26.09 65.32 -11.59 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -26.09 65.42 -11.59 0.45 0.2 0.45 0.008 1 force
tp @e[type=minecraft:item_display,tag=drift.onyx] -18.159 65 -10.263 129.71 0
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.9125f,0.0332f,0.3048f,0.2708f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.278f,-0.2403f,0.921f,0.1293f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.4991f,0.0065f,0.0113f,0.8664f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.0113f,0.8664f,0.4991f,0.0065f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.3313f,0.8782f,0.2411f],left_rotation:[0.1715f,-0.0713f,0.3365f,0.9232f]}}
particle minecraft:campfire_cosy_smoke -16.88 65.12 -8.79 0.008 0.022 0.034 1 0 force
particle minecraft:cloud -16.88 65.32 -8.79 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -15.82 65.12 -10.13 0.069 0.022 -0.036 1 0 force
particle minecraft:cloud -15.82 65.32 -10.13 0.35 0.18 0.35 0.02 3 force
