tp @e[type=minecraft:item_display,tag=drift.kaze] 44.938 65 -48.882 74.91 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0.0079f,0.0002f,0.0223f,0.9997f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.0145f,-0.2071f,0.0566f,0.9766f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.0457f,0.976f,0.0364f,0.2097f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.0058f,0.0001f,0.0131f,0.9999f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.0131f,0.9999f,0.0058f,0.0001f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4078f,0.8408f,0.1236f],left_rotation:[0.0586f,0.1897f,-0.9226f,0.3307f]}}
particle minecraft:campfire_cosy_smoke 47.41 65.12 -48.13 0.059 0.022 0.044 1 0 force
particle minecraft:cloud 47.41 65.32 -48.13 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 47.41 65.42 -48.13 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke 47.02 65.12 -49.75 0.033 0.022 -0.034 1 0 force
particle minecraft:cloud 47.02 65.32 -49.75 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 47.02 65.42 -49.75 0.45 0.2 0.45 0.008 1 force
tp @e[type=minecraft:item_display,tag=drift.onyx] 60.107 65 -43.597 91.08 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0014f,0f,0.0221f,0.9998f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.8896f,-0.0362f,0.2087f,0.4047f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.1674f,0.3849f,0.8983f,0.1299f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.0058f,0.0001f,0.0131f,0.9999f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.0131f,0.9999f,0.0058f,0.0001f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4077f,0.8435f,0.2476f],left_rotation:[0.0511f,0.1824f,-0.9328f,0.3065f]}}
particle minecraft:campfire_cosy_smoke 62.59 65.12 -42.09 0.059 0.022 0.069 1 0 force
particle minecraft:cloud 62.59 65.32 -42.09 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 62.59 65.42 -42.09 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke 62.66 65.12 -43.8 0.054 0.022 -0.011 1 0 force
particle minecraft:cloud 62.66 65.32 -43.8 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 62.66 65.42 -43.8 0.45 0.2 0.45 0.008 1 force
