tp @e[type=minecraft:item_display,tag=drift.kaze] -95.233 65 0.704 -23.61 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0058f,-0.0001f,0.0132f,0.9999f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.8712f,-0.0874f,-0.0496f,0.4806f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.1004f,-0.4885f,0.8668f,0.0037f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.9053f,-0.0119f,0.0056f,0.4245f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.0056f,-0.4245f,0.9053f,0.0119f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.3926f,0.8512f,0.0999f],left_rotation:[0.1339f,-0.1277f,0.6968f,0.693f]}}
particle minecraft:campfire_cosy_smoke -95.23 65.12 -1.96 0.027 0.014 -0.068 1 0 force
particle minecraft:campfire_cosy_smoke -96.76 65.12 -1.28 -0.054 0.014 -0.041 1 0 force
tp @e[type=minecraft:item_display,tag=drift.onyx] -97.728 65 -14.31 -27.21 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0058f,-0.0001f,0.0189f,0.9998f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.956f,-0.0948f,-0.1853f,0.2068f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.2081f,-0.2275f,0.9513f,0.0052f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.9053f,-0.0119f,0.0056f,0.4245f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.0056f,-0.4245f,0.9053f,0.0119f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4023f,0.8483f,0.24f],left_rotation:[0.0442f,0.1797f,-0.9448f,0.2704f]}}
particle minecraft:campfire_cosy_smoke -97.6 65.12 -16.97 0.029 0.022 -0.062 1 0 force
particle minecraft:cloud -97.6 65.32 -16.97 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -97.6 65.42 -16.97 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke -99.13 65.12 -16.21 -0.035 0.022 -0.024 1 0 force
particle minecraft:cloud -99.13 65.32 -16.21 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -99.13 65.42 -16.21 0.45 0.2 0.45 0.008 1 force
