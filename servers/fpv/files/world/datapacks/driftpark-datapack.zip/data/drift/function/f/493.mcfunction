tp @e[type=minecraft:item_display,tag=drift.kaze] -85.541 65 30.605 -37.93 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0.0063f,0.0001f,0.0109f,0.9999f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.1806f,-0.0977f,0.0716f,0.9761f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.0306f,0.9739f,0.1919f,0.1172f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.1159f,0.0015f,0.013f,0.9932f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.013f,0.9932f,0.1159f,0.0015f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.3887f,0.8502f,0.1209f],left_rotation:[0.1102f,-0.1633f,0.8245f,0.5304f]}}
particle minecraft:campfire_cosy_smoke -86.16 65.12 27.86 -0.001 0.015 -0.087 1 0 force
particle minecraft:campfire_cosy_smoke -87.51 65.12 28.85 -0.061 0.015 -0.033 1 0 force
particle minecraft:flame -87.87 65.22 27.79 0.05 0.04 0.05 0.02 6 force
particle minecraft:large_smoke -87.87 65.22 27.79 0.05 0.04 0.05 0.01 2 force
tp @e[type=minecraft:item_display,tag=drift.onyx] -92.142 65 13.686 -25.64 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0058f,-0.0001f,0.0107f,0.9999f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.0325f,-0.0603f,0.0544f,0.9962f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.05f,0.9959f,0.039f,0.0641f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.1159f,0.0015f,0.013f,0.9932f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.013f,0.9932f,0.1159f,0.0015f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.3884f,0.8547f,0.2401f],left_rotation:[0.1578f,-0.0968f,0.5318f,0.8264f]}}
