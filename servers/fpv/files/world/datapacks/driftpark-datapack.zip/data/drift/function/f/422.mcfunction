tp @e[type=minecraft:item_display,tag=drift.kaze] -89.301 65 -39.562 1.47 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0058f,-0.0001f,0.0216f,0.9998f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.8076f,-0.0947f,0.2435f,0.5287f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.1892f,0.5061f,0.822f,0.1801f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.9996f,-0.0131f,0.0003f,0.0261f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.0003f,-0.0261f,0.9996f,0.0131f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4068f,0.8445f,0.1001f],left_rotation:[0.1253f,0.1363f,-0.6941f,0.6957f]}}
particle minecraft:campfire_cosy_smoke -87.97 65.12 -41.34 0.06 0.022 -0.02 1 0 force
particle minecraft:cloud -87.97 65.32 -41.34 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -87.97 65.42 -41.34 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke -89.64 65.12 -41.42 -0.02 0.022 -0.03 1 0 force
particle minecraft:cloud -89.64 65.32 -41.42 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -89.64 65.42 -41.42 0.45 0.2 0.45 0.008 1 force
tp @e[type=minecraft:item_display,tag=drift.onyx] -82.898 65 -45.516 20.93 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0.0052f,0.0001f,0.0223f,0.9997f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.0608f,-0.3044f,0.0355f,0.9499f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.0641f,0.9514f,-0.0291f,0.2997f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.9996f,-0.0131f,0.0003f,0.0261f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.0003f,-0.0261f,0.9996f,0.0131f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4078f,0.84f,0.2589f],left_rotation:[0.1808f,0.0755f,-0.337f,0.9209f]}}
particle minecraft:campfire_cosy_smoke -80.97 65.12 -46.72 0.066 0.022 0.008 1 0 force
particle minecraft:cloud -80.97 65.32 -46.72 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -82.54 65.12 -47.39 -0.002 0.022 -0.025 1 0 force
particle minecraft:cloud -82.54 65.32 -47.39 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -82.54 65.42 -47.39 0.45 0.2 0.45 0.008 1 force
