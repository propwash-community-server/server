tp @e[type=minecraft:item_display,tag=drift.kaze] 12.039 65 -42.037 12.33 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0f,0f,0.0221f,0.9998f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.5127f,-0.1677f,0.1675f,0.8252f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.0817f,0.8121f,0.5331f,0.2225f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.9078f,-0.0119f,0.0055f,0.4192f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.0055f,-0.4192f,0.9078f,0.0119f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4077f,0.8428f,0.1101f],left_rotation:[0.0936f,0.1663f,-0.8333f,0.5188f]}}
particle minecraft:campfire_cosy_smoke 13.68 65.12 -43.59 0.06 0.022 -0.014 1 0 force
particle minecraft:cloud 13.68 65.32 -43.59 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 12.05 65.12 -43.98 -0.017 0.022 -0.03 1 0 force
particle minecraft:cloud 12.05 65.32 -43.98 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 12.05 65.42 -43.98 0.45 0.2 0.45 0.008 1 force
tp @e[type=minecraft:item_display,tag=drift.onyx] 20.971 65 -48.484 30.24 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0.0055f,0.0001f,0.0223f,0.9997f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.2004f,-0.2603f,0.1113f,0.9379f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.0134f,0.9314f,0.2289f,0.2827f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.9078f,-0.0119f,0.0055f,0.4192f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.0055f,-0.4192f,0.9078f,0.0119f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4078f,0.8399f,0.2594f],left_rotation:[0.1597f,0.1139f,-0.5333f,0.8229f]}}
particle minecraft:campfire_cosy_smoke 23.28 65.12 -49.53 0.079 0.022 0.003 1 0 force
particle minecraft:cloud 23.28 65.32 -49.53 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 23.28 65.42 -49.53 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke 21.83 65.12 -50.44 0.011 0.022 -0.03 1 0 force
particle minecraft:cloud 21.83 65.32 -50.44 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 21.83 65.42 -50.44 0.45 0.2 0.45 0.008 1 force
