tp @e[type=minecraft:item_display,tag=drift.kaze] 80.211 65 -25.708 118.13 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0001f,0f,0.0223f,0.9998f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.5758f,-0.1226f,0.1549f,0.7934f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.0723f,0.7815f,0.5918f,0.1838f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.5821f,0.0076f,0.0106f,0.813f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.0106f,0.813f,0.5821f,0.0076f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4079f,0.8427f,0.1098f],left_rotation:[0.026f,0.1889f,-0.9656f,0.1768f]}}
particle minecraft:campfire_cosy_smoke 81.54 65.12 -23.5 0.002 0.022 0.077 1 0 force
particle minecraft:cloud 81.54 65.32 -23.5 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke 82.35 65.12 -24.96 0.055 0.022 -0.001 1 0 force
particle minecraft:cloud 82.35 65.32 -24.96 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke 82.35 65.42 -24.96 0.45 0.2 0.45 0.008 1 force
tp @e[type=minecraft:item_display,tag=drift.onyx] 87.773 65 -12.959 130.86 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0.0009f,0f,0.0223f,0.9998f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.9743f,0.0501f,0.219f,0.0157f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.2185f,-0.0072f,0.9744f,0.052f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.5821f,0.0076f,0.0106f,0.813f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.0106f,0.813f,0.5821f,0.0076f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4079f,0.8423f,0.2515f],left_rotation:[0.0736f,0.1769f,-0.8884f,0.4171f]}}
particle minecraft:campfire_cosy_smoke 88.6 65.12 -10.34 -0.005 0.022 0.091 1 0 force
particle minecraft:cloud 88.6 65.32 -10.34 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 88.6 65.42 -10.34 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke 89.75 65.12 -11.61 0.036 0.022 0.026 1 0 force
particle minecraft:cloud 89.75 65.32 -11.61 0.35 0.18 0.35 0.02 3 force
