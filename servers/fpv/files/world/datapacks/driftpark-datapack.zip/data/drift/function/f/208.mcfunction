tp @e[type=minecraft:item_display,tag=drift.kaze] 51.081 65 -47.019 83.92 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0.0106f,0.0002f,0.0222f,0.9997f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.9789f,-0.0591f,-0.1935f,0.0289f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.1976f,-0.0494f,0.9781f,0.0435f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.9997f,-0.0131f,0.0003f,0.0203f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.0003f,-0.0203f,0.9997f,0.0131f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4078f,0.8402f,0.1282f],left_rotation:[0.0364f,0.1978f,-0.9545f,0.2201f]}}
particle minecraft:campfire_cosy_smoke 53.51 65.12 -45.89 0.049 0.022 0.051 1 0 force
particle minecraft:cloud 53.51 65.32 -45.89 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke 53.51 65.42 -45.89 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke 53.38 65.12 -47.56 0.053 0.022 -0.023 1 0 force
particle minecraft:cloud 53.38 65.32 -47.56 0.35 0.18 0.35 0.02 2 force
tp @e[type=minecraft:item_display,tag=drift.onyx] 66.432 65 -39.842 97.5 0
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.4205f,-0.2033f,-0.0376f,0.8834f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.1307f,0.8922f,-0.4015f,0.1602f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.9997f,-0.0131f,0.0003f,0.0203f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.0003f,-0.0203f,0.9997f,0.0131f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.408f,0.8456f,0.2399f],left_rotation:[0.0412f,0.1804f,-0.9474f,0.2611f]}}
particle minecraft:campfire_cosy_smoke 68.69 65.12 -38.12 0.042 0.022 0.069 1 0 force
particle minecraft:cloud 68.69 65.32 -38.12 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke 68.69 65.42 -38.12 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke 68.94 65.12 -39.81 0.057 0.022 -0.013 1 0 force
particle minecraft:cloud 68.94 65.32 -39.81 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke 68.94 65.42 -39.81 0.45 0.2 0.45 0.008 1 force
