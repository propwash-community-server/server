tp @e[type=minecraft:item_display,tag=drift.kaze] 12.972 65 63.407 -96.4 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0f,0f,0.0058f,1f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.919f,-0.0594f,-0.0059f,0.3898f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.0469f,-0.3926f,0.9178f,0.0369f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.9218f,-0.0121f,0.0051f,0.3873f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.0051f,-0.3873f,0.9218f,0.0121f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.38f,0.8556f,0.11f],left_rotation:[0.1847f,-0.0478f,0.2569f,0.9474f]}}
tp @e[type=minecraft:item_display,tag=drift.onyx] -5.218 65 63.828 -90.66 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0f,0f,-0.0019f,1f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.7783f,-0.0385f,0.0357f,0.6257f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.0299f,-0.6254f,0.7785f,0.0431f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.9218f,-0.0121f,0.0051f,0.3873f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.0051f,-0.3873f,0.9218f,0.0121f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.3667f,0.8614f,0.25f],left_rotation:[0.1907f,0.006f,-0.0345f,0.981f]}}
