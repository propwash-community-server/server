tp @e[type=minecraft:item_display,tag=drift.kaze] 81.687 65 33.853 -173.28 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0.0037f,0.0001f,0.0223f,0.9997f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.6795f,-0.1039f,0.1743f,0.705f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.1012f,0.6906f,0.6942f,0.1759f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.6936f,0.0091f,0.0094f,0.7203f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.0094f,0.7203f,0.6936f,0.0091f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4079f,0.8418f,0.1164f],left_rotation:[0.0364f,0.1911f,-0.9545f,0.2261f]}}
particle minecraft:campfire_cosy_smoke 80.09 65.12 35.9 -0.066 0.022 0.039 1 0 force
particle minecraft:cloud 80.09 65.32 35.9 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke 80.09 65.42 35.9 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke 81.75 65.12 36.13 0.013 0.022 0.04 1 0 force
particle minecraft:cloud 81.75 65.32 36.13 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke 81.75 65.42 36.13 0.45 0.2 0.45 0.008 1 force
playsound driftpark:lap.kaze.02.082 neutral @a 79.21 65.5 37.27 12 1
playsound driftpark:lap.kaze.02.083 neutral @a 83.82 65.5 30.34 12 1
playsound driftpark:lap.kaze.02.084 neutral @a 87.15 65.5 22.85 12 1
playsound driftpark:lap.kaze.02.085 neutral @a 89.28 65.5 14.72 12 1
playsound driftpark:lap.kaze.02.086 neutral @a 90.1 65.5 6.24 12 1
playsound driftpark:lap.kaze.02.087 neutral @a 89.56 65.5 -2.26 12 1
playsound driftpark:lap.kaze.02.088 neutral @a 87.67 65.5 -10.64 12 1
playsound driftpark:lap.kaze.02.089 neutral @a 84.5 65.5 -18.57 12 1
playsound driftpark:lap.kaze.02.090 neutral @a 80.21 65.5 -25.71 12 1
playsound driftpark:lap.kaze.02.091 neutral @a 74.77 65.5 -32.09 12 1
tp @e[type=minecraft:item_display,tag=drift.onyx] 72.093 65 45.771 -159.57 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0.0027f,0.0001f,0.0223f,0.9997f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.9572f,0.0115f,0.2205f,0.187f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.202f,0.1649f,0.9613f,0.089f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.6936f,0.0091f,0.0094f,0.7203f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.0094f,0.7203f,0.6936f,0.0091f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4078f,0.8413f,0.2547f],left_rotation:[0.0678f,0.1812f,-0.9028f,0.3842f]}}
particle minecraft:campfire_cosy_smoke 69.9 65.12 47.51 -0.082 0.022 0.016 1 0 force
particle minecraft:cloud 69.9 65.32 47.51 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 69.9 65.42 47.51 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke 71.49 65.12 48.14 -0.003 0.022 0.044 1 0 force
particle minecraft:cloud 71.49 65.32 48.14 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 71.49 65.42 48.14 0.45 0.2 0.45 0.008 1 force
