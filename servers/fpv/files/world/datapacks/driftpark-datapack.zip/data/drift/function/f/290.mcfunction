tp @e[type=minecraft:item_display,tag=drift.kaze] -5.708 65 -17.111 87.99 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0.011f,-0.0002f,-0.0222f,0.9997f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.9297f,0.0126f,0.2999f,0.2134f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.2791f,-0.1831f,0.9362f,0.1104f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.9408f,-0.0123f,0.0044f,0.3387f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.0044f,-0.3387f,0.9408f,0.0123f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.3316f,0.8729f,0.1289f],left_rotation:[0.181f,-0.0888f,0.3919f,0.8976f]}}
particle minecraft:campfire_cosy_smoke -3.76 65.12 -16.93 0.034 0.022 0.002 1 0 force
particle minecraft:cloud -3.76 65.32 -16.93 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -3.76 65.42 -16.93 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke -3.88 65.12 -18.6 0.026 0.022 -0.065 1 0 force
particle minecraft:cloud -3.88 65.32 -18.6 0.35 0.18 0.35 0.02 3 force
tp @e[type=minecraft:item_display,tag=drift.onyx] 2.396 65 -27.027 56.56 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0059f,0.0001f,-0.0088f,0.9999f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.2864f,0.1762f,0.1098f,0.9353f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.0121f,-0.9289f,0.3065f,0.2072f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.9408f,-0.0123f,0.0044f,0.3387f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.0044f,-0.3387f,0.9408f,0.0123f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.3548f,0.8692f,0.2399f],left_rotation:[0.045f,-0.1795f,0.9488f,0.2559f]}}
particle minecraft:campfire_cosy_smoke 4.42 65.12 -28.03 0.05 0.021 -0.004 1 0 force
particle minecraft:cloud 4.42 65.32 -28.03 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke 3.41 65.12 -29.41 -0.007 0.021 -0.083 1 0 force
particle minecraft:cloud 3.41 65.32 -29.41 0.35 0.18 0.35 0.02 2 force
