tp @e[type=minecraft:item_display,tag=drift.kaze] -73.355 65 50.688 -76.69 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0.008f,0.0002f,0.0223f,0.9997f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.5872f,-0.1503f,0.1815f,0.7744f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.1011f,0.7596f,0.6062f,0.2129f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.5534f,0.0072f,0.0109f,0.8328f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.0109f,0.8328f,0.5534f,0.0072f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4078f,0.8408f,0.1238f],left_rotation:[0.0952f,0.1744f,-0.8386f,0.5072f]}}
particle minecraft:campfire_cosy_smoke -75.01 65.12 48.92 -0.029 0.022 -0.067 1 0 force
particle minecraft:cloud -75.01 65.32 48.92 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -75.01 65.42 48.92 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke -75.43 65.12 50.54 -0.044 0.022 0.003 1 0 force
particle minecraft:cloud -75.43 65.32 50.54 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -75.43 65.42 50.54 0.45 0.2 0.45 0.008 1 force
tp @e[type=minecraft:item_display,tag=drift.onyx] -81.815 65 39.607 -56.63 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0.0111f,0.0002f,0.0162f,0.9998f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.5606f,-0.1463f,0.1683f,0.7975f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.0855f,0.7842f,0.579f,0.206f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.5534f,0.0072f,0.0109f,0.8328f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.0109f,0.8328f,0.5534f,0.0072f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.3974f,0.8418f,0.2691f],left_rotation:[0.0758f,0.1869f,-0.8953f,0.3972f]}}
particle minecraft:campfire_cosy_smoke -82.96 65.12 37.05 -0.01 0.022 -0.09 1 0 force
particle minecraft:cloud -82.96 65.32 37.05 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -83.95 65.12 38.44 -0.057 0.022 -0.023 1 0 force
particle minecraft:cloud -83.95 65.32 38.44 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -83.95 65.42 38.44 0.45 0.2 0.45 0.008 1 force
