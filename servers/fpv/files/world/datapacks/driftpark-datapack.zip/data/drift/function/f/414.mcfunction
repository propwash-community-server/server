tp @e[type=minecraft:item_display,tag=drift.kaze] -85.628 65 -42.996 13.28 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.004f,-0.0001f,0.0223f,0.9997f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.385f,-0.2668f,-0.0573f,0.8816f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.1502f,0.8925f,-0.3591f,0.2278f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.5388f,0.0071f,0.011f,0.8423f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.011f,0.8423f,0.5388f,0.0071f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4079f,0.8435f,0.1032f],left_rotation:[0.141f,0.1228f,-0.6116f,0.7688f]}}
particle minecraft:campfire_cosy_smoke -84 65.12 -44.38 0.059 0.022 -0.001 1 0 force
particle minecraft:cloud -84 65.32 -44.38 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -84 65.42 -44.38 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke -85.61 65.12 -44.81 -0.004 0.022 -0.033 1 0 force
particle minecraft:cloud -85.61 65.32 -44.81 0.35 0.18 0.35 0.02 3 force
tp @e[type=minecraft:item_display,tag=drift.onyx] -77.707 65 -46.869 36.68 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0.006f,0.0001f,0.0223f,0.9997f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.9438f,0.0258f,0.3176f,0.0878f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.3101f,0.0549f,0.9463f,0.0732f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.5388f,0.0071f,0.011f,0.8423f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.011f,0.8423f,0.5388f,0.0071f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4078f,0.8396f,0.2604f],left_rotation:[0.1892f,0.0541f,-0.2271f,0.9538f]}}
particle minecraft:campfire_cosy_smoke -75.44 65.12 -47.52 0.062 0.022 0.025 1 0 force
particle minecraft:cloud -75.44 65.32 -47.52 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -76.77 65.12 -48.59 0.003 0.022 -0.03 1 0 force
particle minecraft:cloud -76.77 65.32 -48.59 0.35 0.18 0.35 0.02 3 force
