tp @e[type=minecraft:item_display,tag=drift.kaze] -59.76 65 -41.711 84.89 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0.0081f,0.0002f,0.0223f,0.9997f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.9404f,-0.0025f,0.2771f,0.1972f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.2579f,0.1692f,0.9458f,0.1014f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.1216f,-0.0016f,0.013f,0.9925f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.013f,-0.9925f,0.1216f,0.0016f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4078f,0.8408f,0.1239f],left_rotation:[0.155f,0.1244f,-0.5787f,0.7909f]}}
particle minecraft:campfire_cosy_smoke -57.74 65.12 -40.51 0.039 0.022 0.065 1 0 force
particle minecraft:cloud -57.74 65.32 -40.51 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -57.74 65.42 -40.51 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke -57.84 65.12 -42.18 0.026 0.022 -0.018 1 0 force
particle minecraft:cloud -57.84 65.32 -42.18 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -57.84 65.42 -42.18 0.45 0.2 0.45 0.008 1 force
tp @e[type=minecraft:item_display,tag=drift.onyx] -49.978 65 -33.218 111.74 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.001f,0f,0.0122f,0.9999f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.9199f,-0.1224f,-0.1873f,0.3221f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.2222f,0.3435f,-0.9121f,0.0264f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.1216f,-0.0016f,0.013f,0.9925f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.013f,-0.9925f,0.1216f,0.0016f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.3908f,0.8512f,0.2482f],left_rotation:[0.0732f,0.1751f,-0.8964f,0.4006f]}}
particle minecraft:campfire_cosy_smoke -48.44 65.12 -31.02 0.017 0.022 0.084 1 0 force
particle minecraft:cloud -48.44 65.32 -31.02 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -48.44 65.42 -31.02 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke -47.73 65.12 -32.57 0.057 0.022 -0.001 1 0 force
particle minecraft:cloud -47.73 65.32 -32.57 0.35 0.18 0.35 0.02 3 force
