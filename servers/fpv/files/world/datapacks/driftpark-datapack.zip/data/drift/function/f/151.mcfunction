tp @e[type=minecraft:item_display,tag=drift.kaze] 89.701 65 -1.204 147.13 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.001f,0f,0.0223f,0.9998f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.5721f,-0.1846f,-0.067f,0.7963f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.151f,0.8077f,-0.5559f,0.1254f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.5868f,-0.0077f,0.0106f,0.8096f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.0106f,-0.8096f,0.5868f,0.0077f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4079f,0.8429f,0.1082f],left_rotation:[0.0237f,0.1883f,-0.9677f,0.1657f]}}
particle minecraft:campfire_cosy_smoke 89.8 65.12 1.41 -0.028 0.021 0.069 1 0 force
particle minecraft:cloud 89.8 65.32 1.41 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke 89.8 65.42 1.41 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke 91.22 65.12 0.53 0.045 0.021 0.042 1 0 force
particle minecraft:cloud 91.22 65.32 0.53 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke 91.22 65.42 0.53 0.45 0.2 0.45 0.008 1 force
tp @e[type=minecraft:item_display,tag=drift.onyx] 90.294 65 13.8 159.35 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0008f,0f,0.0223f,0.9998f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.1668f,-0.2046f,0.09f,0.9603f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.0105f,0.9562f,0.1892f,0.2233f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.5868f,-0.0077f,0.0106f,0.8096f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.0106f,-0.8096f,0.5868f,0.0077f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4079f,0.8431f,0.2486f],left_rotation:[0.0712f,0.1762f,-0.893f,0.408f]}}
particle minecraft:campfire_cosy_smoke 89.78 65.12 16.48 -0.046 0.022 0.063 1 0 force
particle minecraft:cloud 89.78 65.32 16.48 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 89.78 65.42 16.48 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke 91.4 65.12 15.91 0.031 0.022 0.033 1 0 force
particle minecraft:cloud 91.4 65.32 15.91 0.35 0.18 0.35 0.02 3 force
