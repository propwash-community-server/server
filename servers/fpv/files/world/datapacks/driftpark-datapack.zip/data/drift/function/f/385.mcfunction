tp @e[type=minecraft:item_display,tag=drift.kaze] -66.557 65 -44.937 69.61 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0025f,-0.0001f,0.0223f,0.9997f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.3942f,-0.2173f,0.1569f,0.8791f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.0653f,0.8675f,0.4192f,0.2599f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.3685f,0.0048f,0.0122f,0.9295f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.0122f,0.9295f,0.3685f,0.0048f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4079f,0.8432f,0.1057f],left_rotation:[0.136f,0.1302f,-0.6469f,0.7389f]}}
particle minecraft:campfire_cosy_smoke -64.33 65.12 -44.34 0.052 0.022 0.053 1 0 force
particle minecraft:cloud -64.33 65.32 -44.34 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -64.87 65.12 -45.92 0.013 0.022 -0.025 1 0 force
particle minecraft:cloud -64.87 65.32 -45.92 0.35 0.18 0.35 0.02 3 force
tp @e[type=minecraft:item_display,tag=drift.onyx] -56.531 65 -40.448 87.83 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0.0111f,0.0002f,0.0219f,0.9997f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.6032f,-0.2663f,-0.147f,0.7373f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.2253f,0.7568f,-0.5786f,0.2043f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.3685f,0.0048f,0.0122f,0.9295f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.0122f,0.9295f,0.3685f,0.0048f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4071f,0.8372f,0.269f],left_rotation:[0.1844f,0.0817f,-0.3573f,0.912f]}}
particle minecraft:campfire_cosy_smoke -54.43 65.12 -39.02 0.038 0.022 0.063 1 0 force
particle minecraft:cloud -54.43 65.32 -39.02 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -54.43 65.42 -39.02 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke -54.43 65.12 -40.73 0.039 0.022 -0.003 1 0 force
particle minecraft:cloud -54.43 65.32 -40.73 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -54.43 65.42 -40.73 0.45 0.2 0.45 0.008 1 force
