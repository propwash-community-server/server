tp @e[type=minecraft:item_display,tag=drift.kaze] 89.459 65 13.669 162.91 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0008f,0f,0.0223f,0.9998f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.0656f,-0.1933f,0.0405f,0.9781f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.0621f,0.9792f,-0.0456f,0.1875f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.0696f,-0.0009f,0.0131f,0.9975f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.0131f,-0.9975f,0.0696f,0.0009f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4079f,0.8429f,0.1086f],left_rotation:[0.0258f,0.1882f,-0.9658f,0.1763f]}}
particle minecraft:campfire_cosy_smoke 88.84 65.12 16.21 -0.05 0.021 0.07 1 0 force
particle minecraft:cloud 88.84 65.32 16.21 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke 88.84 65.42 16.21 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke 90.45 65.12 15.75 0.022 0.021 0.036 1 0 force
particle minecraft:cloud 90.45 65.32 15.75 0.35 0.18 0.35 0.02 2 force
tp @e[type=minecraft:item_display,tag=drift.onyx] 86.015 65 28.004 174.96 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0019f,0f,0.0223f,0.9998f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.5924f,-0.1428f,0.1771f,0.7728f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.0969f,0.7585f,0.6107f,0.2059f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.0696f,-0.0009f,0.0131f,0.9975f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.0131f,-0.9975f,0.0696f,0.0009f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4079f,0.8436f,0.2468f],left_rotation:[0.0774f,0.1724f,-0.877f,0.4418f]}}
particle minecraft:campfire_cosy_smoke 84.81 65.12 30.41 -0.064 0.022 0.047 1 0 force
particle minecraft:cloud 84.81 65.32 30.41 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 86.51 65.12 30.29 0.026 0.022 0.044 1 0 force
particle minecraft:cloud 86.51 65.32 30.29 0.35 0.18 0.35 0.02 3 force
