tp @e[type=minecraft:item_display,tag=drift.kaze] 28.122 65 -49.518 48.57 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0.0012f,0f,0.0223f,0.9998f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.9722f,0.0474f,0.2275f,0.0273f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.2259f,0.0035f,0.9726f,0.0545f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.9992f,0.0131f,0.0005f,0.0377f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.0005f,0.0377f,0.9992f,0.0131f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4079f,0.8424f,0.112f],left_rotation:[0.0866f,0.1713f,-0.8552f,0.4815f]}}
particle minecraft:campfire_cosy_smoke 30.56 65.12 -49.86 0.078 0.022 0.032 1 0 force
particle minecraft:cloud 30.56 65.32 -49.86 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 29.49 65.12 -51.15 0.018 0.022 -0.04 1 0 force
particle minecraft:cloud 29.49 65.32 -51.15 0.35 0.18 0.35 0.02 3 force
tp @e[type=minecraft:item_display,tag=drift.onyx] 41.157 65 -50.529 65.29 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0.006f,0.0001f,0.0223f,0.9997f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.3557f,-0.2449f,-0.0387f,0.9011f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.1336f,0.9102f,-0.3319f,0.2089f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.9992f,0.0131f,0.0005f,0.0377f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.0005f,0.0377f,0.9992f,0.0131f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4078f,0.8396f,0.2603f],left_rotation:[0.1137f,0.1605f,-0.7739f,0.6019f]}}
particle minecraft:campfire_cosy_smoke 43.78 65.12 -50.15 0.073 0.022 0.042 1 0 force
particle minecraft:cloud 43.78 65.32 -50.15 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 43.78 65.42 -50.15 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke 43.1 65.12 -51.72 0.032 0.022 -0.038 1 0 force
particle minecraft:cloud 43.1 65.32 -51.72 0.35 0.18 0.35 0.02 3 force
