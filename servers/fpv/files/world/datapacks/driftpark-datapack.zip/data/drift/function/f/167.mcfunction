tp @e[type=minecraft:item_display,tag=drift.kaze] 84.961 65 -17.615 128.44 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0.0017f,0f,0.0223f,0.9998f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.9705f,0.0265f,0.1988f,0.1337f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.1858f,0.1135f,0.9731f,0.0754f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.9898f,0.013f,0.0019f,0.1418f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.0019f,0.1418f,0.9898f,0.013f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4079f,0.8423f,0.1129f],left_rotation:[0.0317f,0.1898f,-0.9598f,0.2044f]}}
particle minecraft:campfire_cosy_smoke 85.88 65.12 -15.17 -0.008 0.022 0.078 1 0 force
particle minecraft:cloud 85.88 65.32 -15.17 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke 86.95 65.12 -16.46 0.045 0.022 0.011 1 0 force
particle minecraft:cloud 86.95 65.32 -16.46 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke 86.95 65.42 -16.46 0.45 0.2 0.45 0.008 1 force
tp @e[type=minecraft:item_display,tag=drift.onyx] 90.214 65 -3.458 141.36 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0007f,0f,0.0223f,0.9998f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.7181f,-0.1855f,-0.1228f,0.6594f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.1927f,0.676f,-0.7026f,0.1111f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.9898f,0.013f,0.0019f,0.1418f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.0019f,0.1418f,0.9898f,0.013f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4079f,0.8431f,0.2487f],left_rotation:[0.0694f,0.177f,-0.8971f,0.3988f]}}
particle minecraft:campfire_cosy_smoke 90.57 65.12 -0.74 -0.017 0.022 0.088 1 0 force
particle minecraft:cloud 90.57 65.32 -0.74 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 90.57 65.42 -0.74 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke 91.92 65.12 -1.78 0.035 0.022 0.021 1 0 force
particle minecraft:cloud 91.92 65.32 -1.78 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 91.92 65.42 -1.78 0.45 0.2 0.45 0.008 1 force
