tp @e[type=minecraft:item_display,tag=drift.kaze] -93.689 65 -31.957 -7.36 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0058f,-0.0001f,0.018f,0.9998f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.9329f,-0.1125f,-0.1817f,0.2898f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.2132f,0.3105f,-0.9262f,0.015f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.9999f,0.0131f,0f,0.0029f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0f,0.0029f,0.9999f,0.0131f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4008f,0.8473f,0.1f],left_rotation:[0.0537f,0.1771f,-0.9295f,0.319f]}}
particle minecraft:campfire_cosy_smoke -92.71 65.12 -34.09 0.061 0.022 -0.046 1 0 force
particle minecraft:cloud -92.71 65.32 -34.09 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -94.37 65.12 -33.89 -0.034 0.022 -0.026 1 0 force
particle minecraft:cloud -94.37 65.32 -33.89 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -94.37 65.42 -33.89 0.45 0.2 0.45 0.008 1 force
tp @e[type=minecraft:item_display,tag=drift.onyx] -89.082 65 -41.171 -0.73 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0059f,-0.0001f,0.022f,0.9997f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.9494f,0.0228f,0.2957f,0.1034f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.2865f,0.0729f,0.9522f,0.0768f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.9999f,0.0131f,0f,0.0029f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0f,0.0029f,0.9999f,0.0131f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4075f,0.8458f,0.2399f],left_rotation:[0.1633f,0.087f,-0.4237f,0.8867f]}}
particle minecraft:campfire_cosy_smoke -87.74 65.12 -43.06 0.068 0.022 -0.021 1 0 force
particle minecraft:cloud -87.74 65.32 -43.06 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -87.74 65.42 -43.06 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke -89.45 65.12 -43.08 -0.015 0.022 -0.021 1 0 force
particle minecraft:cloud -89.45 65.32 -43.08 0.35 0.18 0.35 0.02 3 force
