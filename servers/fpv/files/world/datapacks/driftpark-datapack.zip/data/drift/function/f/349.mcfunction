tp @e[type=minecraft:item_display,tag=drift.kaze] -43.114 65 -23.807 146.88 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0059f,0.0001f,-0.009f,0.9999f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.87f,-0.0265f,0.0598f,0.4887f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.0087f,-0.4851f,0.872f,0.0648f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.448f,0.0059f,0.0117f,0.8939f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.0117f,0.8939f,0.448f,0.0059f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.3544f,0.8678f,0.0999f],left_rotation:[0.1741f,0.0625f,-0.3486f,0.9188f]}}
tp @e[type=minecraft:item_display,tag=drift.onyx] -35.306 65 -14.964 161.46 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0058f,0.0001f,-0.0219f,0.9997f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.107f,0.2539f,0.0261f,0.9609f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.0747f,-0.9635f,-0.0809f,0.2441f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.448f,0.0059f,0.0117f,0.8939f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.0117f,0.8939f,0.448f,0.0059f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.3319f,0.8782f,0.24f],left_rotation:[0.1173f,-0.1432f,0.7321f,0.6556f]}}
particle minecraft:campfire_cosy_smoke -35 65.12 -12.91 -0.009 0.022 0.041 1 0 force
particle minecraft:cloud -35 65.32 -12.91 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -35 65.42 -12.91 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke -33.38 65.12 -13.47 0.071 0.022 0.008 1 0 force
particle minecraft:cloud -33.38 65.32 -13.47 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -33.38 65.42 -13.47 0.45 0.2 0.45 0.008 1 force
