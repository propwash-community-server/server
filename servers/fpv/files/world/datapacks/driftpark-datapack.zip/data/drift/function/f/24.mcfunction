tp @e[type=minecraft:item_display,tag=drift.kaze] -23.404 65 64.433 -91.5 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0003f,0f,0.006f,1f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.0556f,-0.0008f,0.0524f,0.9971f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.0521f,-0.9971f,0.0558f,0.0051f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.058f,-0.0008f,0.0131f,0.9982f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.0131f,-0.9982f,0.058f,0.0008f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.3804f,0.8555f,0.1096f],left_rotation:[0.1905f,0.0049f,-0.0133f,0.9816f]}}
tp @e[type=minecraft:item_display,tag=drift.onyx] -40.949 65 64.408 -100.75 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0059f,-0.0001f,0.0158f,0.9999f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.0637f,-0.1188f,0.0605f,0.989f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.0431f,0.9881f,0.0765f,0.1261f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.058f,-0.0008f,0.0131f,0.9982f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.0131f,-0.9982f,0.058f,0.0008f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.397f,0.8508f,0.2399f],left_rotation:[0.085f,-0.1644f,0.8866f,0.4238f]}}
particle minecraft:campfire_cosy_smoke -43.68 65.12 63.74 -0.067 0.016 -0.052 1 0 force
particle minecraft:cloud -43.68 65.32 63.74 0.35 0.18 0.35 0.02 1 force
particle minecraft:campfire_cosy_smoke -43.34 65.12 65.42 -0.051 0.016 0.041 1 0 force
particle minecraft:cloud -43.34 65.32 65.42 0.35 0.18 0.35 0.02 1 force
