tp @e[type=minecraft:item_display,tag=drift.kaze] -57.983 65 60.162 -94.23 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0058f,-0.0001f,0.0192f,0.9998f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.9826f,-0.054f,-0.1775f,0.0044f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.1789f,-0.023f,0.9824f,0.049f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.9998f,-0.0131f,0.0002f,0.0145f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.0002f,-0.0145f,0.9998f,0.0131f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4028f,0.8464f,0.0999f],left_rotation:[0.0046f,0.185f,-0.9808f,0.062f]}}
particle minecraft:campfire_cosy_smoke -60.28 65.12 59.05 -0.059 0.021 -0.06 1 0 force
particle minecraft:cloud -60.28 65.32 59.05 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -60.28 65.42 59.05 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke -60.18 65.12 60.72 -0.041 0.021 0.015 1 0 force
particle minecraft:cloud -60.18 65.32 60.72 0.35 0.18 0.35 0.02 2 force
tp @e[type=minecraft:item_display,tag=drift.onyx] -70.098 65 54.748 -87.04 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0059f,-0.0001f,0.0221f,0.9997f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.9683f,0.0465f,0.2435f,0.0299f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.2417f,0.0044f,0.9688f,0.0551f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.9998f,-0.0131f,0.0002f,0.0145f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.0002f,-0.0145f,0.9998f,0.0131f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4077f,0.8457f,0.2398f],left_rotation:[0.1069f,0.151f,-0.7764f,0.6024f]}}
particle minecraft:campfire_cosy_smoke -72.15 65.12 53.26 -0.036 0.022 -0.059 1 0 force
particle minecraft:cloud -72.15 65.32 53.26 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -72.26 65.12 54.97 -0.038 0.022 0.003 1 0 force
particle minecraft:cloud -72.26 65.32 54.97 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -72.26 65.42 54.97 0.45 0.2 0.45 0.008 1 force
