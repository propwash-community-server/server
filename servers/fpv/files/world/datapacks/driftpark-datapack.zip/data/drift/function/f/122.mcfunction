tp @e[type=minecraft:item_display,tag=drift.kaze] 84.757 65 28.538 179.68 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0011f,0f,0.0223f,0.9998f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.7146f,-0.1718f,-0.1053f,0.6699f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.1762f,0.6846f,-0.7005f,0.0976f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.7303f,-0.0096f,0.0089f,0.683f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.0089f,-0.683f,0.7303f,0.0096f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4079f,0.8429f,0.1081f],left_rotation:[0.0329f,0.1868f,-0.9584f,0.2131f]}}
particle minecraft:campfire_cosy_smoke 83.44 65.12 30.74 -0.067 0.022 0.04 1 0 force
particle minecraft:cloud 83.44 65.32 30.74 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke 83.44 65.42 30.74 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke 85.11 65.12 30.77 0.012 0.022 0.044 1 0 force
particle minecraft:cloud 85.11 65.32 30.77 0.35 0.18 0.35 0.02 2 force
tp @e[type=minecraft:item_display,tag=drift.onyx] 76.993 65 41.104 -166.88 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0.0036f,0.0001f,0.0223f,0.9997f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.1701f,-0.2247f,0.0146f,0.9594f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.0861f,0.9631f,-0.1474f,0.208f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.7303f,-0.0096f,0.0089f,0.683f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.0089f,-0.683f,0.7303f,0.0096f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4078f,0.8409f,0.2562f],left_rotation:[0.0756f,0.1791f,-0.8858f,0.4214f]}}
particle minecraft:campfire_cosy_smoke 75.04 65.12 43.07 -0.078 0.022 0.025 1 0 force
particle minecraft:cloud 75.04 65.32 43.07 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 75.04 65.42 43.07 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke 76.7 65.12 43.49 0.009 0.022 0.058 1 0 force
particle minecraft:cloud 76.7 65.32 43.49 0.35 0.18 0.35 0.02 3 force
