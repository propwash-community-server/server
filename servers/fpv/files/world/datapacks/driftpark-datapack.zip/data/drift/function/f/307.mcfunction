tp @e[type=minecraft:item_display,tag=drift.kaze] -15.647 65 -11.556 119.03 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0048f,0.0001f,-0.0223f,0.9997f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.6766f,0.2336f,-0.1554f,0.6808f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.2278f,-0.7009f,-0.6558f,0.1637f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.8439f,-0.011f,0.007f,0.5364f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.007f,-0.5364f,0.8439f,0.011f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.3313f,0.8766f,0.1017f],left_rotation:[0.1488f,-0.1117f,0.5542f,0.8113f]}}
particle minecraft:campfire_cosy_smoke -14.26 65.12 -10.36 0.012 0.022 0.032 1 0 force
particle minecraft:cloud -14.26 65.32 -10.36 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -13.48 65.12 -11.84 0.05 0.022 -0.05 1 0 force
particle minecraft:cloud -13.48 65.32 -11.84 0.35 0.18 0.35 0.02 3 force
tp @e[type=minecraft:item_display,tag=drift.onyx] -6.892 65 -14.895 98.44 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0.0099f,-0.0002f,-0.0223f,0.9997f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.4279f,0.2687f,0.1991f,0.8397f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.112f,-0.8234f,0.4585f,0.3151f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.8439f,-0.011f,0.007f,0.5364f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.007f,-0.5364f,0.8439f,0.011f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.3316f,0.8705f,0.267f],left_rotation:[0.1989f,-0.0251f,0.0792f,0.9765f]}}
particle minecraft:campfire_cosy_smoke -4.99 65.12 -14.37 0.034 0.022 0.006 1 0 force
particle minecraft:cloud -4.99 65.32 -14.37 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -4.79 65.12 -16.07 0.037 0.022 -0.062 1 0 force
particle minecraft:cloud -4.79 65.32 -16.07 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -4.79 65.42 -16.07 0.45 0.2 0.45 0.008 1 force
