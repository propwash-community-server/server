tp @e[type=minecraft:item_display,tag=drift.kaze] 86.801 65 23.825 174.1 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0019f,0f,0.0223f,0.9998f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.5266f,-0.1913f,-0.0587f,0.8262f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.1458f,0.837f,-0.5094f,0.137f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.5388f,-0.0071f,0.011f,0.8423f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.011f,-0.8423f,0.5388f,0.0071f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4079f,0.8431f,0.1067f],left_rotation:[0.0302f,0.1865f,-0.9614f,0.2001f]}}
particle minecraft:campfire_cosy_smoke 85.71 65.12 26.17 -0.051 0.022 0.05 1 0 force
particle minecraft:cloud 85.71 65.32 26.17 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke 87.37 65.12 26.03 0.013 0.022 0.042 1 0 force
particle minecraft:cloud 87.37 65.32 26.03 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke 87.37 65.42 26.03 0.45 0.2 0.45 0.008 1 force
tp @e[type=minecraft:item_display,tag=drift.onyx] 80.541 65 36.938 -173.17 0
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.098f,-0.2158f,0.0758f,0.9686f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.0256f,0.9659f,0.1212f,0.2273f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.5388f,-0.0071f,0.011f,0.8423f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.011f,-0.8423f,0.5388f,0.0071f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4078f,0.8408f,0.2566f],left_rotation:[0.0817f,0.1766f,-0.8711f,0.451f]}}
particle minecraft:campfire_cosy_smoke 78.83 65.12 39.07 -0.076 0.022 0.042 1 0 force
particle minecraft:cloud 78.83 65.32 39.07 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 78.83 65.42 39.07 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke 80.52 65.12 39.31 0.01 0.022 0.041 1 0 force
particle minecraft:cloud 80.52 65.32 39.31 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 80.52 65.42 39.31 0.45 0.2 0.45 0.008 1 force
