tp @e[type=minecraft:item_display,tag=drift.kaze] -29.636 65 -12.915 148.91 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0.0024f,-0.0001f,-0.0223f,0.9997f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.5531f,0.2411f,-0.1025f,0.7908f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.1862f,-0.806f,-0.5308f,0.1843f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.0058f,-0.0001f,0.0131f,0.9999f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.0131f,-0.9999f,0.0058f,0.0001f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.3314f,0.8751f,0.1142f],left_rotation:[0.1317f,-0.1413f,0.6873f,0.7003f]}}
particle minecraft:campfire_cosy_smoke -28.94 65.12 -11.1 -0.004 0.022 0.043 1 0 force
particle minecraft:cloud -28.94 65.32 -11.1 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -28.94 65.42 -11.1 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke -27.53 65.12 -12 0.075 0.022 -0.001 1 0 force
particle minecraft:cloud -27.53 65.32 -12 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -27.53 65.42 -12 0.45 0.2 0.45 0.008 1 force
tp @e[type=minecraft:item_display,tag=drift.onyx] -19.578 65 -10.182 132.31 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0049f,0.0001f,-0.0223f,0.9997f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.6717f,0.2504f,-0.1716f,0.6757f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.2436f,-0.6975f,-0.6491f,0.1812f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.0058f,-0.0001f,0.0131f,0.9999f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.0131f,-0.9999f,0.0058f,0.0001f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.3313f,0.878f,0.2416f],left_rotation:[0.1696f,-0.0764f,0.3631f,0.913f]}}
particle minecraft:campfire_cosy_smoke -18.35 65.12 -8.64 0 0.022 0.032 1 0 force
particle minecraft:cloud -18.35 65.32 -8.64 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -18.35 65.42 -8.64 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke -17.23 65.12 -9.93 0.055 0.022 -0.033 1 0 force
particle minecraft:cloud -17.23 65.32 -9.93 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -17.23 65.42 -9.93 0.45 0.2 0.45 0.008 1 force
