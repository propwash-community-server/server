tp @e[type=minecraft:item_display,tag=drift.kaze] 11.03 65 -41.037 11.04 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0046f,-0.0001f,0.0215f,0.9998f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.3921f,-0.2212f,-0.0386f,0.8921f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.1326f,0.9011f,-0.371f,0.1812f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.9953f,0.013f,0.0013f,0.0957f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.0013f,0.0957f,0.9953f,0.013f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4067f,0.8443f,0.1022f],left_rotation:[0.0716f,0.172f,-0.8899f,0.4163f]}}
particle minecraft:campfire_cosy_smoke 12.61 65.12 -42.66 0.069 0.022 -0.011 1 0 force
particle minecraft:cloud 12.61 65.32 -42.66 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 12.61 65.42 -42.66 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke 10.98 65.12 -43 -0.012 0.022 -0.042 1 0 force
particle minecraft:cloud 10.98 65.32 -43 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 10.98 65.42 -43 0.45 0.2 0.45 0.008 1 force
tp @e[type=minecraft:item_display,tag=drift.onyx] 19.366 65 -47.824 26.12 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0.006f,0.0001f,0.0223f,0.9997f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.3259f,-0.287f,-0.0459f,0.8996f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.1407f,0.9094f,-0.2975f,0.2544f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.9953f,0.013f,0.0013f,0.0957f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.0013f,0.0957f,0.9953f,0.013f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4078f,0.8396f,0.2603f],left_rotation:[0.168f,0.1022f,-0.4718f,0.8595f]}}
particle minecraft:campfire_cosy_smoke 21.58 65.12 -49 0.066 0.022 0.005 1 0 force
particle minecraft:cloud 21.58 65.32 -49 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 20.08 65.12 -49.81 0.007 0.022 -0.034 1 0 force
particle minecraft:cloud 20.08 65.32 -49.81 0.35 0.18 0.35 0.02 3 force
