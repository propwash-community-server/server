tp @e[type=minecraft:item_display,tag=drift.kaze] -11.713 65 64.054 -91 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0f,0f,-0.0024f,1f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.758f,-0.036f,0.0384f,0.6502f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.0297f,-0.6497f,0.7584f,0.0434f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.7612f,-0.01f,0.0085f,0.6484f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.0085f,-0.6484f,0.7612f,0.01f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.3659f,0.8617f,0.11f],left_rotation:[0.1906f,0.0094f,-0.0528f,0.9802f]}}
tp @e[type=minecraft:item_display,tag=drift.onyx] -29.874 65 64.761 -93.74 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0055f,-0.0001f,0.0104f,0.9999f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.635f,-0.0539f,0.0234f,0.7703f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.0574f,-0.772f,0.6328f,0.0126f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.7612f,-0.01f,0.0085f,0.6484f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.0085f,-0.6484f,0.7612f,0.01f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.3879f,0.8548f,0.2405f],left_rotation:[0.1805f,-0.0423f,0.2443f,0.9518f]}}
