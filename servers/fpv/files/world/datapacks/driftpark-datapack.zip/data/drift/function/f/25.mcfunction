tp @e[type=minecraft:item_display,tag=drift.kaze] -22.105 65 64.401 -91.36 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0f,0f,0.0051f,1f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.948f,0.0511f,0.0121f,0.3138f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.0209f,0.3143f,0.9479f,0.0482f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.9484f,0.0124f,0.0041f,0.3167f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.0041f,0.3167f,0.9484f,0.0124f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.3787f,0.8562f,0.11f],left_rotation:[0.1906f,0.0089f,-0.036f,0.981f]}}
tp @e[type=minecraft:item_display,tag=drift.onyx] -39.761 65 64.5 -100.11 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0058f,-0.0001f,0.0153f,0.9999f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.9737f,0.0301f,0.12f,0.1913f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.1005f,0.1797f,0.9759f,0.0721f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.9484f,0.0124f,0.0041f,0.3167f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.0041f,0.3167f,0.9484f,0.0124f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.3963f,0.8511f,0.24f],left_rotation:[0.1003f,-0.1556f,0.8418f,0.507f]}}
particle minecraft:campfire_cosy_smoke -42.5 65.12 63.83 -0.073 0.015 -0.054 1 0 force
particle minecraft:campfire_cosy_smoke -42.18 65.12 65.51 -0.061 0.015 0.034 1 0 force
