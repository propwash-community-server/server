tp @e[type=minecraft:item_display,tag=drift.kaze] -53.061 65 -35.956 105.29 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0.011f,0.0002f,0.0181f,0.9998f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.8079f,-0.0851f,0.225f,0.5379f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.1697f,0.5172f,0.8213f,0.1705f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.5821f,-0.0076f,0.0106f,0.813f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.0106f,-0.813f,0.5821f,0.0076f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4007f,0.8434f,0.129f],left_rotation:[0.1055f,0.1718f,-0.8157f,0.5422f]}}
particle minecraft:campfire_cosy_smoke -51.39 65.12 -34.03 0.017 0.022 0.081 1 0 force
particle minecraft:cloud -51.39 65.32 -34.03 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -50.88 65.12 -35.62 0.051 0.022 0.002 1 0 force
particle minecraft:cloud -50.88 65.32 -35.62 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -50.88 65.42 -35.62 0.45 0.2 0.45 0.008 1 force
tp @e[type=minecraft:item_display,tag=drift.onyx] -44.508 65 -25.04 142.28 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0059f,0f,-0.0061f,1f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.9778f,0.0508f,0.0129f,0.203f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.0084f,0.2028f,0.9778f,0.0517f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.5821f,-0.0076f,0.0106f,0.813f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.0106f,-0.813f,0.5821f,0.0076f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.3595f,0.8673f,0.2399f],left_rotation:[0.185f,-0.005f,0.0147f,0.9826f]}}
