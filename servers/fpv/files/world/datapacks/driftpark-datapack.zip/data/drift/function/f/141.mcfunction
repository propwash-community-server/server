tp @e[type=minecraft:item_display,tag=drift.kaze] 89.951 65 9.438 158.47 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0002f,0f,0.0223f,0.9998f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.8839f,-0.1302f,-0.148f,0.4241f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.1934f,0.442f,-0.8751f,0.038f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.9029f,-0.0118f,0.0056f,0.4297f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.0056f,-0.4297f,0.9029f,0.0118f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4079f,0.8427f,0.1096f],left_rotation:[0.0252f,0.1889f,-0.9663f,0.173f]}}
particle minecraft:campfire_cosy_smoke 89.54 65.12 12.02 -0.047 0.021 0.065 1 0 force
particle minecraft:cloud 89.54 65.32 12.02 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke 89.54 65.42 12.02 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke 91.1 65.12 11.44 0.029 0.021 0.041 1 0 force
particle minecraft:cloud 91.1 65.32 11.44 0.35 0.18 0.35 0.02 2 force
tp @e[type=minecraft:item_display,tag=drift.onyx] 87.633 65 24.138 170.51 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0019f,0f,0.0223f,0.9998f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.3625f,-0.224f,-0.032f,0.9041f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.1272f,0.9125f,-0.3409f,0.1871f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.9029f,-0.0118f,0.0056f,0.4297f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.0056f,-0.4297f,0.9029f,0.0118f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4079f,0.8436f,0.2467f],left_rotation:[0.0753f,0.1733f,-0.8823f,0.431f]}}
particle minecraft:campfire_cosy_smoke 86.62 65.12 26.65 -0.056 0.022 0.058 1 0 force
particle minecraft:cloud 86.62 65.32 26.65 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 88.31 65.12 26.4 0.012 0.022 0.046 1 0 force
particle minecraft:cloud 88.31 65.32 26.4 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 88.31 65.42 26.4 0.45 0.2 0.45 0.008 1 force
