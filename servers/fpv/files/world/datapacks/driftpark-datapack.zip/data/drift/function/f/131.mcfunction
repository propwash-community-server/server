tp @e[type=minecraft:item_display,tag=drift.kaze] 88.101 65 19.86 169.65 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0016f,0f,0.0223f,0.9998f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.9787f,0.0431f,0.194f,0.052f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.1896f,0.0319f,0.9795f,0.0595f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.9984f,0.0131f,0.0007f,0.0551f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.0007f,0.0551f,0.9984f,0.0131f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4079f,0.843f,0.1073f],left_rotation:[0.0279f,0.1872f,-0.9638f,0.1877f]}}
particle minecraft:campfire_cosy_smoke 87.19 65.12 22.29 -0.053 0.022 0.051 1 0 force
particle minecraft:cloud 87.19 65.32 22.29 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke 87.19 65.42 22.29 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke 88.84 65.12 22.02 0.028 0.022 0.044 1 0 force
particle minecraft:cloud 88.84 65.32 22.02 0.35 0.18 0.35 0.02 2 force
tp @e[type=minecraft:item_display,tag=drift.onyx] 83.005 65 33.462 -178.05 0
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.7829f,-0.1756f,-0.1473f,0.5783f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.2089f,0.597f,-0.7688f,0.0943f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.9984f,0.0131f,0.0007f,0.0551f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.0007f,0.0551f,0.9984f,0.0131f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4078f,0.8408f,0.2564f],left_rotation:[0.0825f,0.1761f,-0.8688f,0.4553f]}}
particle minecraft:campfire_cosy_smoke 81.49 65.12 35.71 -0.07 0.022 0.048 1 0 force
particle minecraft:cloud 81.49 65.32 35.71 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 83.2 65.12 35.8 0.003 0.022 0.052 1 0 force
particle minecraft:cloud 83.2 65.32 35.8 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 83.2 65.42 35.8 0.45 0.2 0.45 0.008 1 force
