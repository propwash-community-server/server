tp @e[type=minecraft:item_display,tag=drift.kaze] -75.725 65 48.01 -71.22 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0.011f,0.0002f,0.022f,0.9997f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.9618f,-0.0848f,-0.2258f,0.1298f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.2407f,-0.1542f,0.9581f,0.0158f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.9973f,-0.0131f,0.0009f,0.0725f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.0009f,-0.0725f,0.9973f,0.0131f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4074f,0.8402f,0.1289f],left_rotation:[0.1057f,0.1717f,-0.8105f,0.55f]}}
particle minecraft:campfire_cosy_smoke -77.25 65.12 46.03 -0.014 0.022 -0.079 1 0 force
particle minecraft:cloud -77.25 65.32 46.03 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -77.83 65.12 47.6 -0.051 0.022 -0.008 1 0 force
particle minecraft:cloud -77.83 65.32 47.6 0.35 0.18 0.35 0.02 3 force
tp @e[type=minecraft:item_display,tag=drift.onyx] -83.754 65 35.306 -48.54 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0.0112f,0.0001f,0.0118f,0.9999f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.9794f,-0.0672f,-0.1737f,0.0779f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.1828f,-0.0966f,0.9778f,0.0354f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.9973f,-0.0131f,0.0009f,0.0725f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.0009f,-0.0725f,0.9973f,0.0131f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.3901f,0.8452f,0.2692f],left_rotation:[0.0078f,0.2017f,-0.9775f,0.0611f]}}
particle minecraft:campfire_cosy_smoke -84.67 65.12 32.58 -0.001 0.02 -0.078 1 0 force
particle minecraft:cloud -84.67 65.32 32.58 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -84.67 65.42 32.58 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke -85.85 65.12 33.82 -0.044 0.02 -0.02 1 0 force
particle minecraft:cloud -85.85 65.32 33.82 0.35 0.18 0.35 0.02 2 force
