tp @e[type=minecraft:item_display,tag=drift.kaze] 88.871 65 16.794 166.28 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0012f,0f,0.0223f,0.9998f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.7334f,-0.1664f,-0.1073f,0.6503f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.1762f,0.6652f,-0.72f,0.0902f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.7498f,-0.0098f,0.0087f,0.6616f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.0087f,-0.6616f,0.7498f,0.0098f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4079f,0.843f,0.1079f],left_rotation:[0.0265f,0.1877f,-0.9651f,0.1806f]}}
particle minecraft:campfire_cosy_smoke 88.1 65.12 19.28 -0.043 0.022 0.059 1 0 force
particle minecraft:cloud 88.1 65.32 19.28 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke 89.73 65.12 18.92 0.018 0.022 0.034 1 0 force
particle minecraft:cloud 89.73 65.32 18.92 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke 89.73 65.42 18.92 0.45 0.2 0.45 0.008 1 force
tp @e[type=minecraft:item_display,tag=drift.onyx] 84.605 65 30.771 178.36 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0.0012f,0f,0.0223f,0.9998f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.1361f,-0.2271f,0.0222f,0.9641f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.0791f,0.967f,-0.113f,0.214f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.7498f,-0.0098f,0.0087f,0.6616f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.0087f,-0.6616f,0.7498f,0.0098f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4079f,0.8421f,0.2521f],left_rotation:[0.0797f,0.1747f,-0.8739f,0.4466f]}}
particle minecraft:campfire_cosy_smoke 83.25 65.12 33.1 -0.065 0.022 0.052 1 0 force
particle minecraft:cloud 83.25 65.32 33.1 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 83.25 65.42 33.1 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke 84.96 65.12 33.08 0.014 0.022 0.055 1 0 force
particle minecraft:cloud 84.96 65.32 33.08 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 84.96 65.42 33.08 0.45 0.2 0.45 0.008 1 force
