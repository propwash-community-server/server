tp @e[type=minecraft:item_display,tag=drift.kaze] -3.385 65 -19.535 79.13 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0.0113f,-0.0002f,-0.0216f,0.9997f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.2127f,0.2597f,0.115f,0.9349f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.0174f,-0.928f,0.2412f,0.2835f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.1676f,-0.0022f,0.0129f,0.9858f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.0129f,-0.9858f,0.1676f,0.0022f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.3326f,0.8725f,0.1294f],left_rotation:[0.1655f,-0.1156f,0.5256f,0.8264f]}}
particle minecraft:campfire_cosy_smoke -1.34 65.12 -19.7 0.043 0.022 0 1 0 force
particle minecraft:cloud -1.34 65.32 -19.7 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -1.34 65.42 -19.7 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke -1.72 65.12 -21.32 0.021 0.022 -0.073 1 0 force
particle minecraft:cloud -1.72 65.32 -21.32 0.35 0.18 0.35 0.02 3 force
tp @e[type=minecraft:item_display,tag=drift.onyx] 3.845 65 -30.396 43.06 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0059f,0f,-0.0002f,1f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.6643f,0.118f,-0.0354f,0.7373f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.1131f,-0.7451f,-0.6555f,0.0489f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.1676f,-0.0022f,0.0129f,0.9858f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.0129f,-0.9858f,0.1676f,0.0022f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.3696f,0.863f,0.2399f],left_rotation:[0.0986f,0.1566f,-0.8317f,0.5234f]}}
particle minecraft:campfire_cosy_smoke 5.74 65.12 -31.77 0.047 0.015 -0.008 1 0 force
particle minecraft:campfire_cosy_smoke 4.42 65.12 -32.86 -0.022 0.015 -0.072 1 0 force
