tp @e[type=minecraft:item_display,tag=drift.kaze] -60.761 65 59.058 -92.07 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0059f,-0.0001f,0.0199f,0.9998f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.7016f,-0.0906f,0.1688f,0.6863f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.0976f,0.6723f,0.715f,0.1649f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.7223f,0.0095f,0.0091f,0.6915f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.0091f,0.6915f,0.7223f,0.0095f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4039f,0.8459f,0.0999f],left_rotation:[0.0152f,0.1844f,-0.9754f,0.1195f]}}
particle minecraft:campfire_cosy_smoke -62.98 65.12 57.86 -0.05 0.021 -0.061 1 0 force
particle minecraft:cloud -62.98 65.32 57.86 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -62.98 65.42 57.86 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke -62.94 65.12 59.53 -0.05 0.021 0.018 1 0 force
particle minecraft:cloud -62.94 65.32 59.53 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -62.94 65.42 59.53 0.45 0.2 0.45 0.008 1 force
tp @e[type=minecraft:item_display,tag=drift.onyx] -72.124 65 53.097 -84.11 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0009f,0f,0.0222f,0.9998f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.7166f,-0.1272f,0.2208f,0.6493f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.1538f,0.6297f,0.7339f,0.2032f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.7223f,0.0095f,0.0091f,0.6915f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.0091f,0.6915f,0.7223f,0.0095f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4079f,0.8432f,0.2484f],left_rotation:[0.1197f,0.1474f,-0.734f,0.6521f]}}
particle minecraft:campfire_cosy_smoke -74.06 65.12 51.51 -0.02 0.022 -0.067 1 0 force
particle minecraft:cloud -74.06 65.32 51.51 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -74.06 65.42 51.51 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke -74.27 65.12 53.2 -0.037 0.022 0.012 1 0 force
particle minecraft:cloud -74.27 65.32 53.2 0.35 0.18 0.35 0.02 3 force
