tp @e[type=minecraft:item_display,tag=drift.kaze] -64.223 65 57.403 -89.17 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0059f,-0.0001f,0.0208f,0.9998f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.9409f,-0.1053f,-0.1718f,0.2722f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.2014f,0.2918f,-0.935f,0.0069f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.9572f,-0.0125f,0.0038f,0.289f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.0038f,-0.289f,0.9572f,0.0125f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4055f,0.8451f,0.0999f],left_rotation:[0.0324f,0.1822f,-0.9596f,0.2121f]}}
particle minecraft:campfire_cosy_smoke -66.33 65.12 56.08 -0.041 0.022 -0.054 1 0 force
particle minecraft:cloud -66.33 65.32 56.08 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -66.33 65.42 56.08 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke -66.38 65.12 57.75 -0.051 0.022 0.019 1 0 force
particle minecraft:cloud -66.38 65.32 57.75 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -66.38 65.42 57.75 0.45 0.2 0.45 0.008 1 force
tp @e[type=minecraft:item_display,tag=drift.onyx] -74.613 65 50.672 -79.32 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0.0096f,0.0002f,0.0222f,0.9997f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.8927f,-0.1485f,-0.221f,0.3635f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.2604f,0.3887f,-0.882f,0.0555f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.9572f,-0.0125f,0.0038f,0.289f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.0038f,-0.289f,0.9572f,0.0125f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4077f,0.8377f,0.2665f],left_rotation:[0.1424f,0.1408f,-0.6571f,0.7267f]}}
particle minecraft:campfire_cosy_smoke -76.43 65.12 48.87 -0.023 0.022 -0.081 1 0 force
particle minecraft:cloud -76.43 65.32 48.87 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -76.43 65.42 48.87 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke -76.78 65.12 50.54 -0.039 0.022 0.006 1 0 force
particle minecraft:cloud -76.78 65.32 50.54 0.35 0.18 0.35 0.02 3 force
