tp @e[type=minecraft:item_display,tag=drift.kaze] -21.722 65 -11.122 132.13 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0041f,0.0001f,-0.0223f,0.9997f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.6052f,0.2399f,-0.1241f,0.7488f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.2035f,-0.766f,-0.5833f,0.1776f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.971f,0.0127f,0.0031f,0.2386f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.0031f,0.2386f,0.971f,0.0127f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.3313f,0.8765f,0.1029f],left_rotation:[0.1375f,-0.1264f,0.632f,0.7521f]}}
particle minecraft:campfire_cosy_smoke -20.56 65.12 -9.6 0.012 0.022 0.03 1 0 force
particle minecraft:cloud -20.56 65.32 -9.6 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -19.47 65.12 -10.86 0.059 0.022 -0.027 1 0 force
particle minecraft:cloud -19.47 65.32 -10.86 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -19.47 65.42 -10.86 0.45 0.2 0.45 0.008 1 force
tp @e[type=minecraft:item_display,tag=drift.onyx] -12.333 65 -11.651 114.91 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0.0038f,-0.0001f,-0.0223f,0.9997f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.4884f,0.2395f,0.2082f,0.8129f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.1239f,-0.7955f,0.5163f,0.2921f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.971f,0.0127f,0.0031f,0.2386f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.0031f,0.2386f,0.971f,0.0127f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.3315f,0.8737f,0.2565f],left_rotation:[0.1864f,-0.0558f,0.2393f,0.9513f]}}
particle minecraft:campfire_cosy_smoke -10.76 65.12 -10.57 0.013 0.022 0.023 1 0 force
particle minecraft:cloud -10.76 65.32 -10.57 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -10.76 65.42 -10.57 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke -10.09 65.12 -12.14 0.038 0.022 -0.042 1 0 force
particle minecraft:cloud -10.09 65.32 -12.14 0.35 0.18 0.35 0.02 3 force
