tp @e[type=minecraft:item_display,tag=drift.kaze] 3.838 65 -30.4 41.19 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0059f,0f,-0.0002f,1f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.3148f,0.1078f,0.0195f,0.9428f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.0795f,-0.946f,-0.3052f,0.0753f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.3793f,0.005f,0.0121f,0.9252f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.0121f,0.9252f,0.3793f,0.005f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.3696f,0.8614f,0.0999f],left_rotation:[0.1194f,0.1414f,-0.751f,0.6339f]}}
particle minecraft:campfire_cosy_smoke 5.74 65.12 -31.69 0.057 0.013 -0.018 1 0 force
particle minecraft:campfire_cosy_smoke 4.42 65.12 -32.72 -0.019 0.013 -0.058 1 0 force
tp @e[type=minecraft:item_display,tag=drift.onyx] 9.367 65 -40.535 6.81 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0058f,-0.0001f,0.0202f,0.9998f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.6788f,-0.2009f,-0.1208f,0.6959f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.1946f,0.7124f,-0.6614f,0.1306f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.3793f,0.005f,0.0121f,0.9252f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.0121f,0.9252f,0.3793f,0.005f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4046f,0.8472f,0.2399f],left_rotation:[0.087f,0.1633f,-0.8479f,0.4967f]}}
particle minecraft:campfire_cosy_smoke 10.89 65.12 -42.41 0.074 0.022 -0.02 1 0 force
particle minecraft:cloud 10.89 65.32 -42.41 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 9.19 65.12 -42.62 -0.009 0.022 -0.025 1 0 force
particle minecraft:cloud 9.19 65.32 -42.62 0.35 0.18 0.35 0.02 3 force
