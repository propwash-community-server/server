tp @e[type=minecraft:item_display,tag=drift.kaze] -94.733 65 2.98 -23.16 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0059f,-0.0001f,0.0117f,0.9999f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.9956f,0.0507f,0.0753f,0.0234f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.0733f,0.0156f,0.9957f,0.0536f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.9959f,0.013f,0.0012f,0.0899f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.0012f,0.0899f,0.9959f,0.013f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.39f,0.8524f,0.0999f],left_rotation:[0.1463f,-0.1132f,0.6195f,0.7629f]}}
particle minecraft:campfire_cosy_smoke -94.74 65.12 0.3 0.024 0.013 -0.078 1 0 force
particle minecraft:campfire_cosy_smoke -96.28 65.12 0.97 -0.052 0.013 -0.043 1 0 force
tp @e[type=minecraft:item_display,tag=drift.onyx] -97.654 65 -12.246 -28.46 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0059f,-0.0001f,0.0186f,0.9998f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.9342f,-0.0077f,0.2027f,0.2934f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.173f,0.2737f,0.9402f,0.106f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.9959f,0.013f,0.0012f,0.0899f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.0012f,0.0899f,0.9959f,0.013f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4019f,0.8485f,0.2398f],left_rotation:[0.0351f,0.1816f,-0.9573f,0.2223f]}}
particle minecraft:campfire_cosy_smoke -97.61 65.12 -14.93 0.033 0.022 -0.074 1 0 force
particle minecraft:cloud -97.61 65.32 -14.93 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -97.61 65.42 -14.93 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke -99.12 65.12 -14.13 -0.028 0.022 -0.023 1 0 force
particle minecraft:cloud -99.12 65.32 -14.13 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -99.12 65.42 -14.13 0.45 0.2 0.45 0.008 1 force
