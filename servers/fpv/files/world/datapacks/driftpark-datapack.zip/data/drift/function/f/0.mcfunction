tp @e[type=minecraft:item_display,tag=drift.kaze] -52 65 62 -98.12 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0058f,-0.0001f,0.0182f,0.9998f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.0087f,-0.1656f,0.0516f,0.9848f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.0516f,0.9848f,0.0087f,0.1656f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0f,0f,0.0131f,0.9999f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.0131f,0.9999f,0f,0f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.401f,0.8472f,0.1f],left_rotation:[0.0165f,-0.1843f,0.9813f,0.0521f]}}
particle minecraft:campfire_cosy_smoke -54.44 65.12 61.07 -0.064 0.019 -0.053 1 0 force
particle minecraft:cloud -54.44 65.32 61.07 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -54.22 65.12 62.73 -0.056 0.019 0.019 1 0 force
particle minecraft:cloud -54.22 65.32 62.73 0.35 0.18 0.35 0.02 2 force
playsound driftpark:lap.kaze.00.068 neutral @a -52 65.5 62 12 1
playsound driftpark:lap.kaze.00.069 neutral @a -43.22 65.5 63.65 12 1
playsound driftpark:lap.kaze.00.070 neutral @a -33.65 65.5 64.41 12 1
playsound driftpark:lap.kaze.00.071 neutral @a -23.4 65.5 64.43 12 1
playsound driftpark:lap.kaze.00.072 neutral @a -13.01 65.5 64.1 12 1
playsound driftpark:lap.kaze.00.073 neutral @a -2.62 65.5 63.82 12 1
playsound driftpark:lap.kaze.00.074 neutral @a 7.78 65.5 63.59 12 1
playsound driftpark:lap.kaze.00.075 neutral @a 18.16 65.5 63.14 12 1
playsound driftpark:lap.kaze.00.076 neutral @a 28.52 65.5 62.19 12 1
tp @e[type=minecraft:item_display,tag=drift.onyx] -65.483 65 57.742 -91.98 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0059f,-0.0001f,0.021f,0.9998f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.0118f,-0.2248f,0.051f,0.973f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.051f,0.973f,0.0118f,0.2248f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0f,0f,0.0131f,0.9999f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.0131f,0.9999f,0f,0f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4059f,0.8466f,0.2399f],left_rotation:[0.0808f,0.1665f,-0.8654f,0.4657f]}}
particle minecraft:campfire_cosy_smoke -67.73 65.12 56.45 -0.05 0.022 -0.071 1 0 force
particle minecraft:cloud -67.73 65.32 56.45 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -67.7 65.12 58.16 -0.038 0.022 0.014 1 0 force
particle minecraft:cloud -67.7 65.32 58.16 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -67.7 65.42 58.16 0.45 0.2 0.45 0.008 1 force
playsound driftpark:lap.onyx.00.068 neutral @a -65.48 65.5 57.74 12 1
playsound driftpark:lap.onyx.00.069 neutral @a -58.26 65.5 60.92 12 1
playsound driftpark:lap.onyx.00.070 neutral @a -50.03 65.5 63.13 12 1
playsound driftpark:lap.onyx.00.071 neutral @a -40.95 65.5 64.41 12 1
playsound driftpark:lap.onyx.00.072 neutral @a -31.15 65.5 64.77 12 1
playsound driftpark:lap.onyx.00.073 neutral @a -20.8 65.5 64.47 12 1
playsound driftpark:lap.onyx.00.074 neutral @a -10.42 65.5 63.92 12 1
playsound driftpark:lap.onyx.00.075 neutral @a -0.02 65.5 63.78 12 1
playsound driftpark:lap.onyx.00.076 neutral @a 10.38 65.5 63.63 12 1
