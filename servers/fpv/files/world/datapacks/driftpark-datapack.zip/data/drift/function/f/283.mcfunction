tp @e[type=minecraft:item_display,tag=drift.kaze] -1.667 65 -21.655 71.87 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0.0096f,-0.0002f,-0.0208f,0.9997f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.814f,0.0919f,0.245f,0.5186f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.1919f,-0.4957f,0.8281f,0.178f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.8113f,-0.0106f,0.0077f,0.5844f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.0077f,-0.5844f,0.8113f,0.0106f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.3339f,0.8724f,0.1266f],left_rotation:[0.1363f,-0.1467f,0.6892f,0.6963f]}}
particle minecraft:campfire_cosy_smoke 0.42 65.12 -22.1 0.04 0.022 0.003 1 0 force
particle minecraft:cloud 0.42 65.32 -22.1 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 0.42 65.42 -22.1 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke -0.17 65.12 -23.66 0.009 0.022 -0.066 1 0 force
particle minecraft:cloud -0.17 65.32 -23.66 0.35 0.18 0.35 0.02 3 force
particle minecraft:flame 0.95 65.22 -23.72 0.05 0.04 0.05 0.02 6 force
particle minecraft:large_smoke 0.95 65.22 -23.72 0.05 0.04 0.05 0.01 2 force
tp @e[type=minecraft:item_display,tag=drift.onyx] 4.86 65 -32.834 31.67 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0059f,0f,0.0054f,1f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.0563f,0.0202f,0.0536f,0.9968f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.0509f,-0.9966f,0.0587f,0.0263f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.8113f,-0.0106f,0.0077f,0.5844f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.0077f,-0.5844f,0.8113f,0.0106f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.3793f,0.8588f,0.2399f],left_rotation:[0.1808f,0.0395f,-0.1995f,0.9623f]}}
particle minecraft:flame 6.2 65.24 -35.93 0.05 0.04 0.05 0.02 5 force
particle minecraft:large_smoke 6.2 65.24 -35.93 0.05 0.04 0.05 0.01 2 force
particle minecraft:flame 6.52 65.24 -35.76 0.05 0.04 0.05 0.02 5 force
particle minecraft:large_smoke 6.52 65.24 -35.76 0.05 0.04 0.05 0.01 2 force
