tp @e[type=minecraft:item_display,tag=drift.kaze] 84.022 65 -19.509 126.06 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0.0019f,0f,0.0223f,0.9998f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.7708f,-0.0776f,0.1854f,0.6046f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.1229f,0.5884f,0.7832f,0.159f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.7833f,0.0103f,0.0081f,0.6215f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.0081f,0.6215f,0.7833f,0.0103f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4079f,0.8423f,0.1133f],left_rotation:[0.0325f,0.19f,-0.9589f,0.2082f]}}
particle minecraft:campfire_cosy_smoke 85.04 65.12 -17.11 0.008 0.022 0.069 1 0 force
particle minecraft:cloud 85.04 65.32 -17.11 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke 85.04 65.42 -17.11 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke 86.05 65.12 -18.44 0.05 0.022 0.012 1 0 force
particle minecraft:cloud 86.05 65.32 -18.44 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke 86.05 65.42 -18.44 0.45 0.2 0.45 0.008 1 force
tp @e[type=minecraft:item_display,tag=drift.onyx] 89.815 65 -5.604 139.02 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0004f,0f,0.0223f,0.9998f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.9503f,-0.1005f,-0.1987f,0.2176f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.2227f,0.2397f,-0.945f,0.0012f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.7833f,0.0103f,0.0081f,0.6215f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.0081f,0.6215f,0.7833f,0.0103f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4079f,0.8429f,0.2493f],left_rotation:[0.0699f,0.1771f,-0.8961f,0.4008f]}}
particle minecraft:campfire_cosy_smoke 90.27 65.12 -2.9 -0.01 0.022 0.075 1 0 force
particle minecraft:cloud 90.27 65.32 -2.9 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 91.59 65.12 -3.99 0.044 0.022 0.019 1 0 force
particle minecraft:cloud 91.59 65.32 -3.99 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 91.59 65.42 -3.99 0.45 0.2 0.45 0.008 1 force
