tp @e[type=minecraft:item_display,tag=drift.kaze] -89.844 65 19.732 -26.98 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0005f,0f,0.0113f,0.9999f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.8349f,0.0143f,0.074f,0.5453f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.0171f,0.5405f,0.8379f,0.0734f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.7975f,0.0104f,0.0079f,0.6031f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.0079f,0.6031f,0.7975f,0.0104f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.3894f,0.8515f,0.1092f],left_rotation:[0.169f,-0.0876f,0.4713f,0.8612f]}}
tp @e[type=minecraft:item_display,tag=drift.onyx] -95.088 65 3.061 -24.8 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0059f,-0.0001f,0.0117f,0.9999f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.7068f,-0.0237f,0.0986f,0.7001f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.0255f,0.6936f,0.7132f,0.0981f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.7975f,0.0104f,0.0079f,0.6031f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.0079f,0.6031f,0.7975f,0.0104f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.39f,0.854f,0.2399f],left_rotation:[0.1325f,-0.1292f,0.7024f,0.6873f]}}
particle minecraft:campfire_cosy_smoke -95.2 65.12 0.28 0.027 0.014 -0.072 1 0 force
particle minecraft:campfire_cosy_smoke -96.75 65.12 1 -0.046 0.014 -0.03 1 0 force
