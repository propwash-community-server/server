tp @e[type=minecraft:item_display,tag=drift.kaze] -86.587 65 -42.272 9.7 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0051f,-0.0001f,0.0222f,0.9997f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.9511f,0.0136f,0.2727f,0.1444f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.259f,0.1165f,0.9549f,0.0863f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.0406f,0.0005f,0.0131f,0.9991f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.0131f,0.9991f,0.0406f,0.0005f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4079f,0.8438f,0.1013f],left_rotation:[0.1403f,0.1219f,-0.6109f,0.7696f]}}
particle minecraft:campfire_cosy_smoke -85.03 65.12 -43.76 0.056 0.022 -0.003 1 0 force
particle minecraft:cloud -85.03 65.32 -43.76 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -85.03 65.42 -43.76 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke -86.67 65.12 -44.09 -0.007 0.022 -0.022 1 0 force
particle minecraft:cloud -86.67 65.32 -44.09 0.35 0.18 0.35 0.02 3 force
tp @e[type=minecraft:item_display,tag=drift.onyx] -79.096 65 -46.646 32.9 0
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.3758f,-0.2651f,0.1745f,0.8707f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.0839f,0.8571f,0.4057f,0.3061f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.0406f,0.0005f,0.0131f,0.9991f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.0131f,0.9991f,0.0406f,0.0005f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4078f,0.8395f,0.2607f],left_rotation:[0.1887f,0.0564f,-0.2386f,0.951f]}}
particle minecraft:campfire_cosy_smoke -76.9 65.12 -47.44 0.073 0.022 0.021 1 0 force
particle minecraft:cloud -76.9 65.32 -47.44 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -76.9 65.42 -47.44 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke -78.31 65.12 -48.42 -0.003 0.022 -0.034 1 0 force
particle minecraft:cloud -78.31 65.32 -48.42 0.35 0.18 0.35 0.02 3 force
