tp @e[type=minecraft:item_display,tag=drift.kaze] -91.32 65 -36.72 -2.77 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0059f,-0.0001f,0.0201f,0.9998f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.0281f,-0.2333f,0.0606f,0.9701f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.041f,0.9691f,0.0527f,0.2375f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.9621f,-0.0126f,0.0036f,0.2723f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.0036f,-0.2723f,0.9621f,0.0126f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4043f,0.8457f,0.0998f],left_rotation:[0.0971f,0.1575f,-0.8152f,0.5489f]}}
particle minecraft:campfire_cosy_smoke -90.15 65.12 -38.67 0.057 0.022 -0.024 1 0 force
particle minecraft:cloud -90.15 65.32 -38.67 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -91.82 65.12 -38.61 -0.028 0.022 -0.031 1 0 force
particle minecraft:cloud -91.82 65.32 -38.61 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -91.82 65.42 -38.61 0.45 0.2 0.45 0.008 1 force
tp @e[type=minecraft:item_display,tag=drift.onyx] -85.629 65 -44.081 10.37 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0028f,-0.0001f,0.0223f,0.9997f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.904f,-0.0423f,0.2987f,0.3029f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.2686f,0.2732f,0.9134f,0.1375f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.9621f,-0.0126f,0.0036f,0.2723f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.0036f,-0.2723f,0.9621f,0.0126f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.408f,0.8441f,0.2452f],left_rotation:[0.1701f,0.0802f,-0.3791f,0.906f]}}
particle minecraft:campfire_cosy_smoke -83.97 65.12 -45.6 0.055 0.022 -0.009 1 0 force
particle minecraft:cloud -83.97 65.32 -45.6 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -83.97 65.42 -45.6 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke -85.64 65.12 -45.97 -0.004 0.022 -0.025 1 0 force
particle minecraft:cloud -85.64 65.32 -45.97 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -85.64 65.42 -45.97 0.45 0.2 0.45 0.008 1 force
