tp @e[type=minecraft:item_display,tag=drift.kaze] 0.54 65 -24.825 61.44 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0038f,0.0001f,-0.0159f,0.9999f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.0493f,0.2169f,0.0427f,0.974f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.0595f,-0.9749f,-0.0268f,0.2129f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.1101f,0.0014f,0.013f,0.9938f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.013f,0.9938f,0.1101f,0.0014f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.3424f,0.8722f,0.1035f],left_rotation:[0.0671f,-0.1747f,0.9054f,0.3812f]}}
particle minecraft:campfire_cosy_smoke 2.6 65.12 -25.6 0.037 0.022 -0.008 1 0 force
particle minecraft:cloud 2.6 65.32 -25.6 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 2.6 65.42 -25.6 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke 1.74 65.12 -27.03 0.005 0.022 -0.077 1 0 force
particle minecraft:cloud 1.74 65.32 -27.03 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 1.74 65.42 -27.03 0.45 0.2 0.45 0.008 1 force
tp @e[type=minecraft:item_display,tag=drift.onyx] 6.198 65 -35.96 17.98 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0059f,-0.0001f,0.012f,0.9999f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.9162f,0.0115f,0.1081f,0.3857f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.0682f,0.3765f,0.92f,0.0847f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.1101f,0.0014f,0.013f,0.9938f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.013f,0.9938f,0.1101f,0.0014f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.3906f,0.8538f,0.2398f],left_rotation:[0.1222f,-0.1389f,0.7532f,0.6312f]}}
particle minecraft:campfire_cosy_smoke 7.74 65.12 -37.85 0.047 0.015 -0.03 1 0 force
particle minecraft:campfire_cosy_smoke 6.09 65.12 -38.3 -0.019 0.015 -0.055 1 0 force
