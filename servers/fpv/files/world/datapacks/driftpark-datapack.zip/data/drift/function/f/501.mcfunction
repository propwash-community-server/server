tp @e[type=minecraft:item_display,tag=drift.kaze] -81.335 65 39.349 -53.13 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0.0111f,0.0002f,0.0162f,0.9998f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.9163f,-0.0176f,0.196f,0.3487f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.1605f,0.33f,0.9232f,0.114f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.9102f,0.0119f,0.0054f,0.4139f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.0054f,0.4139f,0.9102f,0.0119f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.3975f,0.8449f,0.1291f],left_rotation:[0.0273f,0.1999f,-0.9656f,0.1639f]}}
particle minecraft:campfire_cosy_smoke -82.36 65.12 36.87 0.007 0.021 -0.09 1 0 force
particle minecraft:cloud -82.36 65.32 36.87 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -82.36 65.42 36.87 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke -83.41 65.12 38.17 -0.06 0.021 -0.022 1 0 force
particle minecraft:cloud -83.41 65.32 38.17 0.35 0.18 0.35 0.02 2 force
tp @e[type=minecraft:item_display,tag=drift.onyx] -88.769 65 23.494 -30.47 0
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.8891f,0.015f,0.0866f,0.4492f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.0398f,0.4426f,0.8924f,0.0783f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.9102f,0.0119f,0.0054f,0.4139f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.0054f,0.4139f,0.9102f,0.0119f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.3894f,0.8514f,0.25f],left_rotation:[0.1546f,-0.1118f,0.5932f,0.7821f]}}
particle minecraft:campfire_cosy_smoke -89.18 65.12 20.62 0.004 0.012 -0.079 1 0 force
particle minecraft:campfire_cosy_smoke -90.67 65.12 21.47 -0.056 0.012 -0.04 1 0 force
