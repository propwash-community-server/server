tp @e[type=minecraft:item_display,tag=drift.kaze] 85.202 65 27.62 178.56 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0019f,0f,0.0223f,0.9998f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.4601f,-0.1463f,0.1383f,0.8647f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.0482f,0.855f,0.478f,0.1954f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.4686f,0.0061f,0.0116f,0.8833f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.0116f,0.8833f,0.4686f,0.0061f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4079f,0.8431f,0.1068f],left_rotation:[0.0324f,0.1862f,-0.959f,0.2113f]}}
particle minecraft:campfire_cosy_smoke 83.93 65.12 29.85 -0.054 0.022 0.051 1 0 force
particle minecraft:cloud 83.93 65.32 29.85 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke 85.6 65.12 29.84 0.016 0.022 0.039 1 0 force
particle minecraft:cloud 85.6 65.32 29.84 0.35 0.18 0.35 0.02 2 force
tp @e[type=minecraft:item_display,tag=drift.onyx] 77.743 65 40.289 -168.14 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0.0037f,0.0001f,0.0223f,0.9997f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.8837f,-0.0437f,0.2217f,0.41f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.1799f,0.3889f,0.8931f,0.1368f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.4686f,0.0061f,0.0116f,0.8833f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.0116f,0.8833f,0.4686f,0.0061f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4078f,0.8408f,0.2563f],left_rotation:[0.0771f,0.1785f,-0.8824f,0.4285f]}}
particle minecraft:campfire_cosy_smoke 75.84 65.12 42.29 -0.074 0.022 0.041 1 0 force
particle minecraft:cloud 75.84 65.32 42.29 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 75.84 65.42 42.29 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke 77.5 65.12 42.68 0.009 0.022 0.044 1 0 force
particle minecraft:cloud 77.5 65.32 42.68 0.35 0.18 0.35 0.02 3 force
