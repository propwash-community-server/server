tp @e[type=minecraft:item_display,tag=drift.kaze] -64.434 65 -44.18 74.14 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0014f,0f,0.0223f,0.9998f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.11f,-0.2538f,0.0838f,0.9573f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.0164f,0.9538f,0.1373f,0.2668f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.39f,-0.0051f,0.0121f,0.9207f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.0121f,-0.9207f,0.39f,0.0051f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4079f,0.843f,0.1076f],left_rotation:[0.136f,0.1319f,-0.6516f,0.7346f]}}
particle minecraft:campfire_cosy_smoke -62.28 65.12 -43.41 0.052 0.022 0.045 1 0 force
particle minecraft:cloud -62.28 65.32 -43.41 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -62.28 65.42 -43.41 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke -62.69 65.12 -45.02 0.022 0.022 -0.023 1 0 force
particle minecraft:cloud -62.69 65.32 -45.02 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -62.69 65.42 -45.02 0.45 0.2 0.45 0.008 1 force
tp @e[type=minecraft:item_display,tag=drift.onyx] -54.469 65 -38.636 94.27 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0.0112f,0.0002f,0.0206f,0.9997f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.9526f,-0.0806f,-0.2801f,0.0875f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.2909f,-0.1174f,0.9493f,0.0191f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.39f,-0.0051f,0.0121f,0.9207f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.0121f,-0.9207f,0.39f,0.0051f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4049f,0.8382f,0.2693f],left_rotation:[0.1734f,0.1033f,-0.4661f,0.8614f]}}
particle minecraft:campfire_cosy_smoke -52.47 65.12 -36.96 0.022 0.022 0.079 1 0 force
particle minecraft:cloud -52.47 65.32 -36.96 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -52.28 65.12 -38.66 0.038 0.022 -0.001 1 0 force
particle minecraft:cloud -52.28 65.32 -38.66 0.35 0.18 0.35 0.02 3 force
