tp @e[type=minecraft:item_display,tag=drift.kaze] -10.355 65 -13.62 103.04 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0.0067f,-0.0001f,-0.0223f,0.9997f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.9441f,0.098f,-0.2798f,0.1439f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.2965f,0.1741f,0.939f,0.0007f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.1961f,-0.0026f,0.0128f,0.9805f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.0128f,-0.9805f,0.1961f,0.0026f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.3314f,0.8741f,0.1214f],left_rotation:[0.174f,-0.0931f,0.4234f,0.8842f]}}
particle minecraft:campfire_cosy_smoke -8.66 65.12 -12.89 0.015 0.022 0.018 1 0 force
particle minecraft:cloud -8.66 65.32 -12.89 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -8.33 65.12 -14.52 0.038 0.022 -0.057 1 0 force
particle minecraft:cloud -8.33 65.32 -14.52 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -8.33 65.42 -14.52 0.45 0.2 0.45 0.008 1 force
tp @e[type=minecraft:item_display,tag=drift.onyx] -1.529 65 -20.362 78.49 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0.011f,-0.0002f,-0.0211f,0.9997f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.6702f,0.2485f,-0.1684f,0.6787f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.2407f,-0.7002f,-0.6478f,0.1794f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.1961f,-0.0026f,0.0128f,0.9805f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.0128f,-0.9805f,0.1961f,0.0026f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.3336f,0.8691f,0.2689f],left_rotation:[0.1812f,-0.0885f,0.3923f,0.8975f]}}
particle minecraft:campfire_cosy_smoke 0.63 65.12 -20.63 0.04 0.022 0.006 1 0 force
particle minecraft:cloud 0.63 65.32 -20.63 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 0.22 65.12 -22.28 0.022 0.022 -0.074 1 0 force
particle minecraft:cloud 0.22 65.32 -22.28 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 0.22 65.42 -22.28 0.45 0.2 0.45 0.008 1 force
