tp @e[type=minecraft:item_display,tag=drift.kaze] -79.153 65 43.139 -60.85 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0.0111f,0.0002f,0.0195f,0.9997f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.1448f,-0.207f,0.0853f,0.9638f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.0155f,0.9601f,0.1673f,0.2234f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.087f,0.0011f,0.013f,0.9961f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.013f,0.9961f,0.087f,0.0011f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4032f,0.8422f,0.1291f],left_rotation:[0.0767f,0.1866f,-0.8906f,0.4076f]}}
particle minecraft:campfire_cosy_smoke -80.4 65.12 40.84 -0.009 0.022 -0.089 1 0 force
particle minecraft:cloud -80.4 65.32 40.84 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -80.4 65.42 40.84 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke -81.26 65.12 42.27 -0.051 0.022 -0.011 1 0 force
particle minecraft:cloud -81.26 65.32 42.27 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -81.26 65.42 42.27 0.45 0.2 0.45 0.008 1 force
tp @e[type=minecraft:item_display,tag=drift.onyx] -86.831 65 28.328 -36.28 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0.0018f,0f,0.0112f,0.9999f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.0653f,-0.099f,0.0593f,0.9912f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.0446f,0.9904f,0.0761f,0.1064f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.087f,0.0011f,0.013f,0.9961f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.013f,0.9961f,0.087f,0.0011f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.3892f,0.8505f,0.2531f],left_rotation:[0.117f,-0.153f,0.7928f,0.5782f]}}
particle minecraft:campfire_cosy_smoke -87.43 65.12 25.48 0.002 0.015 -0.078 1 0 force
particle minecraft:campfire_cosy_smoke -88.84 65.12 26.44 -0.062 0.015 -0.04 1 0 force
