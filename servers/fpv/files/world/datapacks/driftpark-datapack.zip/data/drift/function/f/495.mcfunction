tp @e[type=minecraft:item_display,tag=drift.kaze] -84.497 65 32.927 -41.63 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0.0104f,0.0001f,0.0108f,0.9999f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.3362f,-0.1421f,0.0048f,0.931f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.093f,0.9356f,-0.3231f,0.1076f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.4007f,-0.0052f,0.012f,0.9161f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.012f,-0.9161f,0.4007f,0.0052f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.3884f,0.8493f,0.1279f],left_rotation:[0.0755f,-0.1863f,0.9156f,0.3481f]}}
particle minecraft:campfire_cosy_smoke -85.22 65.12 30.24 -0.002 0.016 -0.085 1 0 force
particle minecraft:cloud -85.22 65.32 30.24 0.35 0.18 0.35 0.02 1 force
particle minecraft:campfire_cosy_smoke -86.5 65.12 31.3 -0.049 0.016 -0.036 1 0 force
particle minecraft:cloud -86.5 65.32 31.3 0.35 0.18 0.35 0.02 1 force
tp @e[type=minecraft:item_display,tag=drift.onyx] -91.369 65 16.132 -26.57 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0039f,0f,0.0111f,0.9999f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.4648f,-0.0792f,0.0175f,0.8817f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.0751f,0.8847f,-0.459f,0.0308f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.4007f,-0.0052f,0.012f,0.9161f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.012f,-0.9161f,0.4007f,0.0052f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.389f,0.8535f,0.2432f],left_rotation:[0.1595f,-0.0976f,0.5311f,0.8264f]}}
