tp @e[type=minecraft:item_display,tag=drift.kaze] -78.595 65 44.02 -62.79 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0.0111f,0.0002f,0.0201f,0.9997f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.967f,0.0277f,0.2273f,0.112f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.2167f,0.0887f,0.9694f,0.0738f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.9843f,0.0129f,0.0023f,0.1762f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.0023f,0.1762f,0.9843f,0.0129f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4042f,0.8417f,0.1291f],left_rotation:[0.0855f,0.1827f,-0.8697f,0.4505f]}}
particle minecraft:campfire_cosy_smoke -79.89 65.12 41.77 -0.014 0.022 -0.088 1 0 force
particle minecraft:cloud -79.89 65.32 41.77 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -80.7 65.12 43.23 -0.048 0.022 -0.008 1 0 force
particle minecraft:cloud -80.7 65.32 43.23 0.35 0.18 0.35 0.02 3 force
tp @e[type=minecraft:item_display,tag=drift.onyx] -86.321 65 29.526 -38.19 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0.004f,0f,0.0111f,0.9999f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.9735f,0.0297f,0.1225f,0.1909f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.1031f,0.1791f,0.9757f,0.0725f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.9843f,0.0129f,0.0023f,0.1762f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.0023f,0.1762f,0.9843f,0.0129f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.389f,0.8495f,0.2569f],left_rotation:[0.101f,-0.1665f,0.8498f,0.4898f]}}
particle minecraft:campfire_cosy_smoke -86.98 65.12 26.68 0.014 0.015 -0.082 1 0 force
particle minecraft:campfire_cosy_smoke -88.36 65.12 27.69 -0.049 0.015 -0.035 1 0 force
