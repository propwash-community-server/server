tp @e[type=minecraft:item_display,tag=drift.kaze] 19.729 65 -47 30.28 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0.006f,0.0001f,0.0223f,0.9997f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.8636f,-0.1626f,-0.2044f,0.4313f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.2509f,0.4552f,-0.8512f,0.0728f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.8952f,-0.0117f,0.0058f,0.4454f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.0058f,-0.4454f,0.8952f,0.0117f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4078f,0.8413f,0.1203f],left_rotation:[0.133f,0.1449f,-0.6919f,0.6947f]}}
particle minecraft:campfire_cosy_smoke 21.91 65.12 -47.99 0.082 0.022 -0.004 1 0 force
particle minecraft:cloud 21.91 65.32 -47.99 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 21.91 65.42 -47.99 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke 20.5 65.12 -48.88 0.004 0.022 -0.044 1 0 force
particle minecraft:cloud 20.5 65.32 -48.88 0.35 0.18 0.35 0.02 3 force
tp @e[type=minecraft:item_display,tag=drift.onyx] 31.653 65 -50.876 50.74 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0.0006f,0f,0.0223f,0.9998f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.1701f,-0.2351f,0.0969f,0.9521f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.0026f,0.9471f,0.1958f,0.2543f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.8952f,-0.0117f,0.0058f,0.4454f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.0058f,-0.4454f,0.8952f,0.0117f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4079f,0.8424f,0.251f],left_rotation:[0.1198f,0.1492f,-0.7373f,0.6479f]}}
particle minecraft:campfire_cosy_smoke 34.22 65.12 -51.13 0.065 0.022 0.036 1 0 force
particle minecraft:cloud 34.22 65.32 -51.13 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 34.22 65.42 -51.13 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke 33.17 65.12 -52.48 0.026 0.022 -0.03 1 0 force
particle minecraft:cloud 33.17 65.32 -52.48 0.35 0.18 0.35 0.02 3 force
