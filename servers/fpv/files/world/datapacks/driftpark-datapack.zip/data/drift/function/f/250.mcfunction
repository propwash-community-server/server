tp @e[type=minecraft:item_display,tag=drift.kaze] 14.263 65 -43.872 16.5 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0.0063f,0.0001f,0.0223f,0.9997f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.6688f,-0.223f,-0.1393f,0.6954f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.2132f,0.7139f,-0.649f,0.154f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.0812f,-0.0011f,0.013f,0.9966f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.013f,-0.9966f,0.0812f,0.0011f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4078f,0.8412f,0.1208f],left_rotation:[0.1356f,0.1428f,-0.6802f,0.706f]}}
particle minecraft:campfire_cosy_smoke 16.07 65.12 -45.29 0.072 0.022 -0.015 1 0 force
particle minecraft:cloud 16.07 65.32 -45.29 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 14.48 65.12 -45.81 -0.005 0.022 -0.032 1 0 force
particle minecraft:cloud 14.48 65.32 -45.81 0.35 0.18 0.35 0.02 3 force
tp @e[type=minecraft:item_display,tag=drift.onyx] 24.373 65 -49.598 37.9 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0.0037f,0.0001f,0.0223f,0.9997f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.9128f,-0.0327f,0.2677f,0.3067f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.2369f,0.2802f,0.9213f,0.1288f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.0812f,-0.0011f,0.013f,0.9966f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.013f,-0.9966f,0.0812f,0.0011f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4078f,0.8408f,0.2564f],left_rotation:[0.1426f,0.1322f,-0.6342f,0.7483f]}}
particle minecraft:campfire_cosy_smoke 26.82 65.12 -50.37 0.076 0.022 0.01 1 0 force
particle minecraft:cloud 26.82 65.32 -50.37 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 26.82 65.42 -50.37 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke 25.5 65.12 -51.46 0.015 0.022 -0.03 1 0 force
particle minecraft:cloud 25.5 65.32 -51.46 0.35 0.18 0.35 0.02 3 force
