tp @e[type=minecraft:item_display,tag=drift.kaze] 76.969 65 -29.759 112.94 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0045f,-0.0001f,0.0223f,0.9997f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.755f,-0.0779f,0.1773f,0.6265f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.1124f,0.6113f,0.7674f,0.1576f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.7649f,0.01f,0.0084f,0.644f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.0084f,0.644f,0.7649f,0.01f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4079f,0.8436f,0.1022f],left_rotation:[0.0184f,0.1855f,-0.9724f,0.1406f]}}
particle minecraft:campfire_cosy_smoke 78.52 65.12 -27.67 0.027 0.021 0.073 1 0 force
particle minecraft:cloud 78.52 65.32 -27.67 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke 78.52 65.42 -27.67 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke 79.2 65.12 -29.2 0.044 0.021 0.002 1 0 force
particle minecraft:cloud 79.2 65.32 -29.2 0.35 0.18 0.35 0.02 2 force
tp @e[type=minecraft:item_display,tag=drift.onyx] 85.73 65 -17.975 124.85 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0.0017f,0f,0.0223f,0.9998f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.9411f,-0.1086f,-0.1991f,0.2506f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.2266f,0.273f,-0.9349f,0.0102f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.7649f,0.01f,0.0084f,0.644f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.0084f,0.644f,0.7649f,0.01f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4079f,0.8418f,0.2529f],left_rotation:[0.0776f,0.1761f,-0.8795f,0.4353f]}}
particle minecraft:campfire_cosy_smoke 86.82 65.12 -15.47 0.002 0.022 0.082 1 0 force
particle minecraft:cloud 86.82 65.32 -15.47 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 86.82 65.42 -15.47 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke 87.82 65.12 -16.85 0.048 0.022 0.019 1 0 force
particle minecraft:cloud 87.82 65.32 -16.85 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 87.82 65.42 -16.85 0.45 0.2 0.45 0.008 1 force
