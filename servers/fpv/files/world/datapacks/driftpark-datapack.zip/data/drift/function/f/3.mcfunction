tp @e[type=minecraft:item_display,tag=drift.kaze] -48.81 65 62.729 -99.17 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0059f,-0.0001f,0.0178f,0.9998f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.6871f,-0.0732f,0.1448f,0.7082f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.0712f,0.6969f,0.6986f,0.1458f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.7019f,0.0092f,0.0093f,0.7122f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.0093f,0.7122f,0.7019f,0.0092f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4004f,0.8475f,0.0999f],left_rotation:[0.0362f,-0.1815f,0.97f,0.1576f]}}
particle minecraft:campfire_cosy_smoke -51.31 65.12 61.88 -0.057 0.019 -0.057 1 0 force
particle minecraft:cloud -51.31 65.32 61.88 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -51.05 65.12 63.53 -0.053 0.019 0.019 1 0 force
particle minecraft:cloud -51.05 65.32 63.53 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -51.05 65.42 63.53 0.45 0.2 0.45 0.008 1 force
tp @e[type=minecraft:item_display,tag=drift.onyx] -62.916 65 59.068 -94.23 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0059f,-0.0001f,0.0203f,0.9998f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.6875f,-0.1151f,0.1901f,0.6913f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.1185f,0.6752f,0.7034f,0.188f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.7019f,0.0092f,0.0093f,0.7122f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.0093f,0.7122f,0.7019f,0.0092f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4048f,0.8471f,0.2399f],left_rotation:[0.0676f,0.1723f,-0.8995f,0.3957f]}}
particle minecraft:campfire_cosy_smoke -65.25 65.12 57.87 -0.049 0.022 -0.062 1 0 force
particle minecraft:cloud -65.25 65.32 57.87 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -65.15 65.12 59.58 -0.037 0.022 0.015 1 0 force
particle minecraft:cloud -65.15 65.32 59.58 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -65.15 65.42 59.58 0.45 0.2 0.45 0.008 1 force
