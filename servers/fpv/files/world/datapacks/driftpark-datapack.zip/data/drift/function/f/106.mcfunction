tp @e[type=minecraft:item_display,tag=drift.kaze] 74.883 65 42.154 -160.85 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0.0034f,0.0001f,0.0223f,0.9997f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.2586f,-0.1693f,0.1016f,0.9456f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.0027f,0.9401f,0.2778f,0.1974f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.2639f,0.0035f,0.0126f,0.9645f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.0126f,0.9645f,0.2639f,0.0035f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4079f,0.8419f,0.1158f],left_rotation:[0.0262f,0.1923f,-0.9651f,0.1756f]}}
particle minecraft:campfire_cosy_smoke 72.85 65.12 43.87 -0.076 0.021 0.022 1 0 force
particle minecraft:cloud 72.85 65.32 43.87 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke 72.85 65.42 43.87 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke 74.42 65.12 44.45 0.002 0.021 0.053 1 0 force
particle minecraft:cloud 74.42 65.32 44.45 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke 74.42 65.42 44.45 0.45 0.2 0.45 0.008 1 force
tp @e[type=minecraft:item_display,tag=drift.onyx] 62.623 65 52.464 -148.48 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0.0029f,0.0001f,0.0223f,0.9997f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.717f,-0.1037f,0.1911f,0.6624f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.1226f,0.6459f,0.7318f,0.1796f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.2639f,0.0035f,0.0126f,0.9645f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.0126f,0.9645f,0.2639f,0.0035f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4078f,0.8412f,0.255f],left_rotation:[0.062f,0.1835f,-0.9145f,0.3552f]}}
particle minecraft:campfire_cosy_smoke 60.12 65.12 53.77 -0.093 0.022 0.003 1 0 force
particle minecraft:cloud 60.12 65.32 53.77 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 61.56 65.12 54.69 -0.008 0.022 0.048 1 0 force
particle minecraft:cloud 61.56 65.32 54.69 0.35 0.18 0.35 0.02 3 force
