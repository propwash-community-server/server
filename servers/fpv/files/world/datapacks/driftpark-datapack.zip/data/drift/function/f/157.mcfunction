tp @e[type=minecraft:item_display,tag=drift.kaze] 88.531 65 -7.536 140.32 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0f,0f,0.0223f,0.9998f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.7881f,-0.07f,0.1842f,0.5831f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.1239f,0.567f,0.7998f,0.1532f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.801f,0.0105f,0.0078f,0.5985f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.0078f,0.5985f,0.801f,0.0105f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4079f,0.8427f,0.11f],left_rotation:[0.025f,0.1891f,-0.9664f,0.1721f]}}
particle minecraft:campfire_cosy_smoke 88.94 65.12 -4.94 -0.025 0.021 0.075 1 0 force
particle minecraft:cloud 88.94 65.32 -4.94 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke 88.94 65.42 -4.94 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke 90.25 65.12 -5.98 0.039 0.021 0.027 1 0 force
particle minecraft:cloud 90.25 65.32 -5.98 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke 90.25 65.42 -5.98 0.45 0.2 0.45 0.008 1 force
tp @e[type=minecraft:item_display,tag=drift.onyx] 90.91 65 7.338 152.59 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0.0001f,0f,0.0223f,0.9998f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.9573f,-0.0935f,-0.2024f,0.1838f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.2228f,-0.2061f,0.9528f,0.0066f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.801f,0.0105f,0.0078f,0.5985f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.0078f,0.5985f,0.801f,0.0105f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4079f,0.8427f,0.2501f],left_rotation:[0.0705f,0.1774f,-0.8951f,0.4029f]}}
particle minecraft:campfire_cosy_smoke 90.72 65.12 10.07 -0.047 0.022 0.081 1 0 force
particle minecraft:cloud 90.72 65.32 10.07 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 90.72 65.42 10.07 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke 92.25 65.12 9.31 0.026 0.022 0.046 1 0 force
particle minecraft:cloud 92.25 65.32 9.31 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 92.25 65.42 9.31 0.45 0.2 0.45 0.008 1 force
