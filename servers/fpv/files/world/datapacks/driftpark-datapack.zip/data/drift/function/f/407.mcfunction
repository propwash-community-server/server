tp @e[type=minecraft:item_display,tag=drift.kaze] -81.994 65 -44.905 27.48 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0.0057f,0.0001f,0.0223f,0.9997f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.436f,-0.2686f,-0.0758f,0.8556f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.1661f,0.8683f,-0.4101f,0.2242f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.7498f,0.0098f,0.0087f,0.6616f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.0087f,0.6616f,0.7498f,0.0098f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4078f,0.8414f,0.1198f],left_rotation:[0.1554f,0.1201f,-0.5645f,0.8017f]}}
particle minecraft:campfire_cosy_smoke -80.04 65.12 -45.84 0.064 0.022 0.016 1 0 force
particle minecraft:cloud -80.04 65.32 -45.84 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -80.04 65.42 -45.84 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke -81.5 65.12 -46.66 -0.003 0.022 -0.028 1 0 force
particle minecraft:cloud -81.5 65.32 -46.66 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -81.5 65.42 -46.66 0.45 0.2 0.45 0.008 1 force
tp @e[type=minecraft:item_display,tag=drift.onyx] -72.472 65 -46.984 50.65 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0.0035f,0.0001f,0.0223f,0.9997f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.0296f,-0.3052f,0.0646f,0.9496f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.0349f,0.9481f,0.0619f,0.31f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.7498f,0.0098f,0.0087f,0.6616f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.0087f,0.6616f,0.7498f,0.0098f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4078f,0.8409f,0.256f],left_rotation:[0.1829f,0.0653f,-0.2882f,0.9377f]}}
particle minecraft:campfire_cosy_smoke -70.05 65.12 -47.1 0.07 0.022 0.028 1 0 force
particle minecraft:cloud -70.05 65.32 -47.1 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -70.05 65.42 -47.1 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke -71.09 65.12 -48.45 0.023 0.022 -0.019 1 0 force
particle minecraft:cloud -71.09 65.32 -48.45 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -71.09 65.42 -48.45 0.45 0.2 0.45 0.008 1 force
