tp @e[type=minecraft:item_display,tag=drift.kaze] -59.098 65 -41.263 86.57 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0.0092f,0.0002f,0.0222f,0.9997f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.1199f,-0.2632f,0.0879f,0.9532f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.0118f,0.9492f,0.1483f,0.2773f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.9898f,-0.013f,0.0019f,0.1418f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.0019f,-0.1418f,0.9898f,0.013f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4078f,0.8405f,0.1258f],left_rotation:[0.1563f,0.1245f,-0.5759f,0.7928f]}}
particle minecraft:campfire_cosy_smoke -57.1 65.12 -39.99 0.026 0.022 0.059 1 0 force
particle minecraft:cloud -57.1 65.32 -39.99 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -57.1 65.42 -39.99 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke -57.15 65.12 -41.66 0.024 0.022 -0.023 1 0 force
particle minecraft:cloud -57.15 65.32 -41.66 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -57.15 65.42 -41.66 0.45 0.2 0.45 0.008 1 force
tp @e[type=minecraft:item_display,tag=drift.onyx] -49.375 65 -32.379 114.42 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0043f,0f,0.0103f,0.9999f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.5493f,-0.1374f,0.1579f,0.809f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.0737f,0.7969f,0.5668f,0.1959f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.9898f,-0.013f,0.0019f,0.1418f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.0019f,-0.1418f,0.9898f,0.013f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.3877f,0.8543f,0.2426f],left_rotation:[0.048f,0.1803f,-0.9439f,0.2724f]}}
particle minecraft:campfire_cosy_smoke -47.92 65.12 -30.14 0.009 0.022 0.086 1 0 force
particle minecraft:cloud -47.92 65.32 -30.14 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -47.14 65.12 -31.66 0.04 0.022 0.008 1 0 force
particle minecraft:cloud -47.14 65.32 -31.66 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -47.14 65.42 -31.66 0.45 0.2 0.45 0.008 1 force
