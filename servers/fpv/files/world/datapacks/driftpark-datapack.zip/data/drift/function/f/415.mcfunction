tp @e[type=minecraft:item_display,tag=drift.kaze] -86.111 65 -42.645 11.42 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0046f,-0.0001f,0.0223f,0.9997f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.4597f,-0.2092f,0.1757f,0.845f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.0878f,0.8312f,0.4842f,0.2587f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.9538f,-0.0125f,0.0039f,0.3001f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.3001f,0.9538f,0.0125f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4079f,0.8437f,0.1021f],left_rotation:[0.1408f,0.122f,-0.6095f,0.7706f]}}
particle minecraft:campfire_cosy_smoke -84.51 65.12 -44.08 0.065 0.022 -0.011 1 0 force
particle minecraft:cloud -84.51 65.32 -44.08 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -84.51 65.42 -44.08 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke -86.14 65.12 -44.46 -0.008 0.022 -0.023 1 0 force
particle minecraft:cloud -86.14 65.32 -44.46 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -86.14 65.42 -44.46 0.45 0.2 0.45 0.008 1 force
tp @e[type=minecraft:item_display,tag=drift.onyx] -78.411 65 -46.767 34.67 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0.0062f,0.0001f,0.0223f,0.9997f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.5504f,-0.287f,-0.1369f,0.772f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.2188f,0.7906f,-0.5232f,0.2308f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.9538f,-0.0125f,0.0039f,0.3001f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.0039f,-0.3001f,0.9538f,0.0125f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4078f,0.8395f,0.2606f],left_rotation:[0.189f,0.0551f,-0.2325f,0.9525f]}}
particle minecraft:campfire_cosy_smoke -76.18 65.12 -47.49 0.067 0.022 0.012 1 0 force
particle minecraft:cloud -76.18 65.32 -47.49 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -77.55 65.12 -48.51 0.011 0.022 -0.024 1 0 force
particle minecraft:cloud -77.55 65.32 -48.51 0.35 0.18 0.35 0.02 3 force
