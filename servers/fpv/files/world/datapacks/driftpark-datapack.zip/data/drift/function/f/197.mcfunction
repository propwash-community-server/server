tp @e[type=minecraft:item_display,tag=drift.kaze] 63.021 65 -41.225 97.88 0
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.2007f,-0.1817f,0.0164f,0.9625f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.0847f,0.9661f,-0.1827f,0.1616f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.2132f,-0.0028f,0.0128f,0.9769f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.0128f,-0.9769f,0.2132f,0.0028f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4079f,0.844f,0.0999f],left_rotation:[-0.0014f,0.185f,-0.9821f,0.036f]}}
particle minecraft:campfire_cosy_smoke 65.21 65.12 -39.56 0.041 0.02 0.08 1 0 force
particle minecraft:cloud 65.21 65.32 -39.56 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke 65.21 65.42 -39.56 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke 65.47 65.12 -41.21 0.048 0.02 0 1 0 force
particle minecraft:cloud 65.47 65.32 -41.21 0.35 0.18 0.35 0.02 2 force
tp @e[type=minecraft:item_display,tag=drift.onyx] 76.122 65 -31.898 107.4 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0049f,-0.0001f,0.0223f,0.9997f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.7214f,-0.1024f,0.1918f,0.6576f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.1237f,0.641f,0.7361f,0.1787f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.2132f,-0.0028f,0.0128f,0.9769f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.0128f,-0.9769f,0.2132f,0.0028f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.408f,0.8451f,0.2416f],left_rotation:[0.0595f,0.1763f,-0.916f,0.3554f]}}
particle minecraft:campfire_cosy_smoke 77.95 65.12 -29.86 0.029 0.022 0.076 1 0 force
particle minecraft:cloud 77.95 65.32 -29.86 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 78.49 65.12 -31.48 0.049 0.022 -0.009 1 0 force
particle minecraft:cloud 78.49 65.32 -31.48 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 78.49 65.42 -31.48 0.45 0.2 0.45 0.008 1 force
