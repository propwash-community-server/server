tp @e[type=minecraft:item_display,tag=drift.kaze] -95.863 65 -24.681 -14.41 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0058f,-0.0001f,0.0173f,0.9998f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.7157f,-0.0909f,0.1751f,0.67f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.1056f,0.6553f,0.7292f,0.1666f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.6894f,0.009f,0.0095f,0.7243f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.0095f,0.7243f,0.6894f,0.009f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.3996f,0.8479f,0.0999f],left_rotation:[0.0256f,0.1833f,-0.968f,0.1696f]}}
particle minecraft:campfire_cosy_smoke -95.17 65.12 -27.02 0.052 0.022 -0.055 1 0 force
particle minecraft:cloud -95.17 65.32 -27.02 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -95.17 65.42 -27.02 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke -96.79 65.12 -26.63 -0.03 0.022 -0.032 1 0 force
particle minecraft:cloud -96.79 65.32 -26.63 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -96.79 65.42 -26.63 0.45 0.2 0.45 0.008 1 force
tp @e[type=minecraft:item_display,tag=drift.onyx] -92.843 65 -35.88 -7.96 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0058f,-0.0001f,0.0194f,0.9998f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.9638f,0.0384f,0.2571f,0.0594f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.2523f,0.0327f,0.9651f,0.0627f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.6894f,0.009f,0.0095f,0.7243f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.0095f,0.7243f,0.6894f,0.009f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4033f,0.8478f,0.24f],left_rotation:[0.1239f,0.1375f,-0.7039f,0.6858f]}}
particle minecraft:campfire_cosy_smoke -91.81 65.12 -38.06 0.05 0.022 -0.033 1 0 force
particle minecraft:cloud -91.81 65.32 -38.06 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -91.81 65.42 -38.06 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke -93.5 65.12 -37.84 -0.019 0.022 -0.032 1 0 force
particle minecraft:cloud -93.5 65.32 -37.84 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -93.5 65.42 -37.84 0.45 0.2 0.45 0.008 1 force
