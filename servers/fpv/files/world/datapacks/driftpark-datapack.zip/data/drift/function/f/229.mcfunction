tp @e[type=minecraft:item_display,tag=drift.kaze] 30.822 65 -49.895 53.12 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0.0001f,0f,0.0223f,0.9998f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.674f,-0.1227f,0.1921f,0.7027f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.1193f,0.6863f,0.6906f,0.1942f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.6852f,0.009f,0.0095f,0.7283f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.0095f,0.7283f,0.6852f,0.009f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4079f,0.8427f,0.1102f],left_rotation:[0.0788f,0.1739f,-0.8752f,0.4446f]}}
particle minecraft:campfire_cosy_smoke 33.28 65.12 -50.06 0.07 0.022 0.034 1 0 force
particle minecraft:cloud 33.28 65.32 -50.06 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 32.31 65.12 -51.42 0.023 0.022 -0.031 1 0 force
particle minecraft:cloud 32.31 65.32 -51.42 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 32.31 65.42 -51.42 0.45 0.2 0.45 0.008 1 force
tp @e[type=minecraft:item_display,tag=drift.onyx] 44.137 65 -49.986 69.7 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0.0074f,0.0002f,0.0223f,0.9997f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.893f,-0.1423f,-0.1976f,0.3785f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.2385f,0.4014f,-0.8829f,0.0492f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.6852f,0.009f,0.0095f,0.7283f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.0095f,0.7283f,0.6852f,0.009f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4077f,0.8389f,0.2627f],left_rotation:[0.1076f,0.1663f,-0.7984f,0.5687f]}}
particle minecraft:campfire_cosy_smoke 46.76 65.12 -49.4 0.056 0.022 0.045 1 0 force
particle minecraft:cloud 46.76 65.32 -49.4 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 46.76 65.42 -49.4 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke 46.21 65.12 -51.02 0.047 0.022 -0.02 1 0 force
particle minecraft:cloud 46.21 65.32 -51.02 0.35 0.18 0.35 0.02 3 force
