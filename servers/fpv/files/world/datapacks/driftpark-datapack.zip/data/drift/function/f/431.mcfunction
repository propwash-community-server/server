tp @e[type=minecraft:item_display,tag=drift.kaze] -92.743 65 -34.103 -5.46 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0059f,-0.0001f,0.0188f,0.9998f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.9654f,0.0234f,0.2231f,0.1329f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.2103f,0.1102f,0.9683f,0.0779f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.7101f,0.0093f,0.0092f,0.704f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.0092f,0.704f,0.7101f,0.0093f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4022f,0.8467f,0.0999f],left_rotation:[0.0711f,0.1708f,-0.8923f,0.4117f]}}
particle minecraft:campfire_cosy_smoke -91.68 65.12 -36.16 0.059 0.022 -0.028 1 0 force
particle minecraft:cloud -91.68 65.32 -36.16 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -93.34 65.12 -36.02 -0.027 0.022 -0.022 1 0 force
particle minecraft:cloud -93.34 65.32 -36.02 0.35 0.18 0.35 0.02 3 force
tp @e[type=minecraft:item_display,tag=drift.onyx] -87.648 65 -42.555 3.33 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0055f,-0.0001f,0.0222f,0.9997f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.9407f,-0.1021f,-0.2843f,0.1541f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.302f,0.1849f,-0.9352f,0.0038f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.7101f,0.0093f,0.0092f,0.704f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.0092f,0.704f,0.7101f,0.0093f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.408f,0.8454f,0.2405f],left_rotation:[0.1679f,0.0786f,-0.3765f,0.9077f]}}
particle minecraft:campfire_cosy_smoke -86.17 65.12 -44.3 0.061 0.022 -0.022 1 0 force
particle minecraft:cloud -86.17 65.32 -44.3 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -86.17 65.42 -44.3 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke -87.87 65.12 -44.46 -0.015 0.022 -0.018 1 0 force
particle minecraft:cloud -87.87 65.32 -44.46 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -87.87 65.42 -44.46 0.45 0.2 0.45 0.008 1 force
