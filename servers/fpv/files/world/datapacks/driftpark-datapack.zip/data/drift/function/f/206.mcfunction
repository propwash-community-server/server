tp @e[type=minecraft:item_display,tag=drift.kaze] 53.21 65 -46.19 86.79 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0.0109f,0.0002f,0.0222f,0.9997f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.8315f,-0.1462f,-0.1335f,0.519f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.1888f,0.5359f,-0.8207f,0.0596f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.8531f,-0.0112f,0.0068f,0.5216f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.0068f,-0.5216f,0.8531f,0.0112f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4077f,0.8401f,0.1288f],left_rotation:[0.0282f,0.1996f,-0.9628f,0.1801f]}}
particle minecraft:campfire_cosy_smoke 55.63 65.12 -44.94 0.05 0.021 0.057 1 0 force
particle minecraft:cloud 55.63 65.32 -44.94 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke 55.63 65.42 -44.94 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke 55.57 65.12 -46.61 0.047 0.021 -0.016 1 0 force
particle minecraft:cloud 55.57 65.32 -46.61 0.35 0.18 0.35 0.02 2 force
tp @e[type=minecraft:item_display,tag=drift.onyx] 68.381 65 -38.493 99.3 0
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.0717f,-0.1964f,0.068f,0.9755f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.0342f,0.9738f,0.0927f,0.205f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.8531f,-0.0112f,0.0068f,0.5216f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.0068f,-0.5216f,0.8531f,0.0112f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.408f,0.8455f,0.24f],left_rotation:[0.043f,0.1801f,-0.9447f,0.2706f]}}
particle minecraft:campfire_cosy_smoke 70.57 65.12 -36.71 0.032 0.022 0.069 1 0 force
particle minecraft:cloud 70.57 65.32 -36.71 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 70.57 65.42 -36.71 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke 70.87 65.12 -38.39 0.045 0.022 -0.012 1 0 force
particle minecraft:cloud 70.87 65.32 -38.39 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 70.87 65.42 -38.39 0.45 0.2 0.45 0.008 1 force
