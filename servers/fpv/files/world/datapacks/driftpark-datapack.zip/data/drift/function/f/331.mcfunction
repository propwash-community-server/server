tp @e[type=minecraft:item_display,tag=drift.kaze] -32.28 65 -14.149 153.77 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0012f,0f,-0.0223f,0.9998f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.8941f,0.0429f,0.2418f,0.3746f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.2037f,-0.3513f,0.9035f,0.1371f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.8736f,-0.0114f,0.0064f,0.4865f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.0064f,-0.4865f,0.8736f,0.0114f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.3314f,0.8759f,0.108f],left_rotation:[0.1061f,-0.1572f,0.7887f,0.5847f]}}
particle minecraft:campfire_cosy_smoke -31.78 65.12 -12.27 0.004 0.022 0.034 1 0 force
particle minecraft:cloud -31.78 65.32 -12.27 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -30.3 65.12 -13.03 0.064 0.022 -0.002 1 0 force
particle minecraft:cloud -30.3 65.32 -13.03 0.35 0.18 0.35 0.02 3 force
tp @e[type=minecraft:item_display,tag=drift.onyx] -22.525 65 -10.282 138.08 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0037f,0.0001f,-0.0223f,0.9997f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.8937f,0.0518f,0.2945f,0.3345f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.2609f,-0.3054f,0.9041f,0.146f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.8736f,-0.0114f,0.0064f,0.4865f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.0064f,-0.4865f,0.8736f,0.0114f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.3313f,0.8774f,0.2436f],left_rotation:[0.1671f,-0.0843f,0.4027f,0.896f]}}
particle minecraft:campfire_cosy_smoke -21.42 65.12 -8.61 0.011 0.022 0.028 1 0 force
particle minecraft:cloud -21.42 65.32 -8.61 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -21.42 65.42 -8.61 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke -20.18 65.12 -9.79 0.076 0.022 -0.034 1 0 force
particle minecraft:cloud -20.18 65.32 -9.79 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -20.18 65.42 -9.79 0.45 0.2 0.45 0.008 1 force
particle minecraft:flame -19.92 65.24 -8.53 0.05 0.04 0.05 0.02 6 force
particle minecraft:large_smoke -19.92 65.24 -8.53 0.05 0.04 0.05 0.01 2 force
particle minecraft:flame -20.18 65.24 -8.28 0.05 0.04 0.05 0.02 6 force
particle minecraft:large_smoke -20.18 65.24 -8.28 0.05 0.04 0.05 0.01 2 force
