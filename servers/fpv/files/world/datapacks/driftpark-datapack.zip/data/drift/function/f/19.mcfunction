tp @e[type=minecraft:item_display,tag=drift.kaze] -29.872 65 64.486 -93.15 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0055f,-0.0001f,0.0104f,0.9999f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.3019f,-0.0372f,0.0431f,0.9516f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.0567f,0.9524f,-0.2996f,0.0057f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.3029f,-0.004f,0.0125f,0.9529f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.0125f,-0.9529f,0.3029f,0.004f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.3878f,0.8533f,0.1005f],left_rotation:[0.182f,-0.0355f,0.2082f,0.9604f]}}
tp @e[type=minecraft:item_display,tag=drift.onyx] -46.715 65 63.724 -102.59 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0059f,-0.0001f,0.0174f,0.9998f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.2097f,-0.1738f,0.0164f,0.962f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.0846f,0.9656f,-0.1926f,0.1528f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.3029f,-0.004f,0.0125f,0.9529f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.0125f,-0.9529f,0.3029f,0.004f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.3999f,0.8495f,0.2399f],left_rotation:[0.0144f,-0.1845f,0.9818f,0.042f]}}
particle minecraft:campfire_cosy_smoke -49.4 65.12 63.01 -0.057 0.019 -0.044 1 0 force
particle minecraft:cloud -49.4 65.32 63.01 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -49.03 65.12 64.68 -0.046 0.019 0.036 1 0 force
particle minecraft:cloud -49.03 65.32 64.68 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -49.03 65.42 64.68 0.45 0.2 0.45 0.008 1 force
