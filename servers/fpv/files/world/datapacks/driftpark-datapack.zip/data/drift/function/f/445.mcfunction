tp @e[type=minecraft:item_display,tag=drift.kaze] -96.199 65 -22.908 -16.16 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0059f,-0.0001f,0.0177f,0.9998f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.2807f,-0.1644f,0.1047f,0.9398f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.0065f,0.934f,0.2996f,0.1948f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.2302f,0.003f,0.0127f,0.9731f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.0127f,0.9731f,0.2302f,0.003f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4003f,0.8476f,0.0998f],left_rotation:[0.0214f,0.1838f,-0.9715f,0.1482f]}}
particle minecraft:campfire_cosy_smoke -95.58 65.12 -25.28 0.055 0.021 -0.049 1 0 force
particle minecraft:cloud -95.58 65.32 -25.28 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -95.58 65.42 -25.28 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke -97.19 65.12 -24.84 -0.03 0.021 -0.034 1 0 force
particle minecraft:cloud -97.19 65.32 -24.84 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -97.19 65.42 -24.84 0.45 0.2 0.45 0.008 1 force
tp @e[type=minecraft:item_display,tag=drift.onyx] -93.553 65 -34.494 -9.34 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0059f,-0.0001f,0.0188f,0.9998f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.5832f,-0.1636f,0.1912f,0.7724f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.1111f,0.7565f,0.6036f,0.2258f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.2302f,0.003f,0.0127f,0.9731f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.0127f,0.9731f,0.2302f,0.003f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4022f,0.8483f,0.2398f],left_rotation:[0.1127f,0.1467f,-0.7564f,0.6274f]}}
particle minecraft:campfire_cosy_smoke -92.57 65.12 -36.72 0.054 0.022 -0.043 1 0 force
particle minecraft:cloud -92.57 65.32 -36.72 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -92.57 65.42 -36.72 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke -94.26 65.12 -36.47 -0.015 0.022 -0.029 1 0 force
particle minecraft:cloud -94.26 65.32 -36.47 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -94.26 65.42 -36.47 0.45 0.2 0.45 0.008 1 force
playsound driftpark:lap.onyx.08.123 neutral @a -91.69 65.5 -37.82 12 1
playsound driftpark:lap.onyx.08.124 neutral @a -94.52 65.5 -32.29 12 1
playsound driftpark:lap.onyx.08.125 neutral @a -96.55 65.5 -25.75 12 1
playsound driftpark:lap.onyx.08.126 neutral @a -97.64 65.5 -18.31 12 1
playsound driftpark:lap.onyx.08.127 neutral @a -97.5 65.5 -10.15 12 1
playsound driftpark:lap.onyx.08.128 neutral @a -96.16 65.5 -1.45 12 1
playsound driftpark:lap.onyx.08.129 neutral @a -93.85 65.5 7.7 12 1
playsound driftpark:lap.onyx.08.130 neutral @a -90.96 65.5 17.36 12 1
playsound driftpark:lap.onyx.08.131 neutral @a -87.33 65.5 27.13 12 1
