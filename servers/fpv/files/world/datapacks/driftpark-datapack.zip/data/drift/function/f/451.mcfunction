tp @e[type=minecraft:item_display,tag=drift.kaze] -96.837 65 -17.28 -21.49 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0058f,-0.0001f,0.0189f,0.9998f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.9448f,-0.1004f,-0.1587f,0.2684f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.1878f,0.2865f,-0.9395f,0.0016f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.9763f,-0.0128f,0.0028f,0.216f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.0028f,-0.216f,0.9763f,0.0128f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4022f,0.8466f,0.1f],left_rotation:[0.0086f,0.1849f,-0.9792f,0.0829f]}}
particle minecraft:campfire_cosy_smoke -96.45 65.12 -19.77 0.032 0.021 -0.071 1 0 force
particle minecraft:cloud -96.45 65.32 -19.77 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -98.01 65.12 -19.18 -0.03 0.021 -0.041 1 0 force
particle minecraft:cloud -98.01 65.32 -19.18 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -98.01 65.42 -19.18 0.45 0.2 0.45 0.008 1 force
tp @e[type=minecraft:item_display,tag=drift.onyx] -95.381 65 -29.951 -13.13 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0059f,-0.0001f,0.0174f,0.9998f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.9725f,-0.0571f,-0.2252f,0.0144f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.2279f,-0.0382f,0.9719f,0.0448f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.9763f,-0.0128f,0.0028f,0.216f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.0028f,-0.216f,0.9763f,0.0128f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.3999f,0.8494f,0.2399f],left_rotation:[0.0842f,0.1648f,-0.859f,0.4773f]}}
particle minecraft:campfire_cosy_smoke -94.58 65.12 -32.31 0.052 0.022 -0.041 1 0 force
particle minecraft:cloud -94.58 65.32 -32.31 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -96.25 65.12 -31.94 -0.035 0.022 -0.041 1 0 force
particle minecraft:cloud -96.25 65.32 -31.94 0.35 0.18 0.35 0.02 3 force
