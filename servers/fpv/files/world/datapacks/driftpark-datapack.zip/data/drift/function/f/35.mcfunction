tp @e[type=minecraft:item_display,tag=drift.kaze] -9.115 65 63.974 -90.85 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0f,0f,-0.003f,1f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.9824f,-0.0508f,0.0133f,0.1794f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.0055f,-0.179f,0.9824f,0.0522f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.9843f,-0.0129f,0.0023f,0.1762f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.0023f,-0.1762f,0.9843f,0.0129f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.3648f,0.8622f,0.11f],left_rotation:[0.1907f,0.0062f,-0.0378f,0.9809f]}}
tp @e[type=minecraft:item_display,tag=drift.onyx] -27.301 65 64.716 -92.59 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0034f,0f,0.0088f,1f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.933f,-0.0532f,0.0074f,0.3559f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.03f,-0.3571f,0.9325f,0.0446f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.9843f,-0.0129f,0.0023f,0.1762f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.0023f,-0.1762f,0.9843f,0.0129f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.3851f,0.855f,0.2442f],left_rotation:[0.1865f,-0.0187f,0.1153f,0.9755f]}}
