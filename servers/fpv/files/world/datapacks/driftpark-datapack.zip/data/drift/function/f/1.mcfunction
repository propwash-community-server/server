tp @e[type=minecraft:item_display,tag=drift.kaze] -50.951 65 62.257 -98.51 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0058f,-0.0001f,0.018f,0.9998f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.949f,0.0075f,0.1701f,0.2655f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.1431f,0.249f,0.9534f,0.0922f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.9652f,0.0126f,0.0034f,0.2611f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.0034f,0.2611f,0.9652f,0.0126f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4008f,0.8473f,0.1f],left_rotation:[0.0222f,-0.1837f,0.9793f,0.0824f]}}
particle minecraft:campfire_cosy_smoke -53.41 65.12 61.36 -0.055 0.019 -0.057 1 0 force
particle minecraft:cloud -53.41 65.32 61.36 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -53.41 65.42 61.36 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke -53.18 65.12 63.01 -0.041 0.019 0.03 1 0 force
particle minecraft:cloud -53.18 65.32 63.01 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -53.18 65.42 63.01 0.45 0.2 0.45 0.008 1 force
tp @e[type=minecraft:item_display,tag=drift.onyx] -64.645 65 58.198 -92.8 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0059f,-0.0001f,0.0208f,0.9998f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.9382f,-0.0075f,0.2276f,0.2605f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.2015f,0.238f,0.9442f,0.1061f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.9652f,0.0126f,0.0034f,0.2611f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.0034f,0.2611f,0.9652f,0.0126f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4056f,0.8467f,0.2399f],left_rotation:[0.0763f,0.1686f,-0.8776f,0.4423f]}}
particle minecraft:campfire_cosy_smoke -66.93 65.12 56.94 -0.037 0.022 -0.062 1 0 force
particle minecraft:cloud -66.93 65.32 56.94 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -66.87 65.12 58.65 -0.046 0.022 0.018 1 0 force
particle minecraft:cloud -66.87 65.32 58.65 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -66.87 65.42 58.65 0.45 0.2 0.45 0.008 1 force
