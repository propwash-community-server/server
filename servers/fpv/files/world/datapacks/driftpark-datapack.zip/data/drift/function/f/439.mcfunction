tp @e[type=minecraft:item_display,tag=drift.kaze] -95.024 65 -28.062 -11.04 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0059f,-0.0001f,0.0172f,0.9998f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.9341f,-0.1095f,-0.1701f,0.2942f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.2019f,0.3136f,-0.9277f,0.0119f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.9696f,-0.0127f,0.0032f,0.2443f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.0032f,-0.2443f,0.9696f,0.0127f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.3994f,0.848f,0.0999f],left_rotation:[0.0343f,0.1818f,-0.9588f,0.2155f]}}
particle minecraft:campfire_cosy_smoke -94.2 65.12 -30.31 0.055 0.022 -0.044 1 0 force
particle minecraft:cloud -94.2 65.32 -30.31 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -94.2 65.42 -30.31 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke -95.84 65.12 -30.01 -0.027 0.022 -0.026 1 0 force
particle minecraft:cloud -95.84 65.32 -30.01 0.35 0.18 0.35 0.02 3 force
tp @e[type=minecraft:item_display,tag=drift.onyx] -91.282 65 -38.431 -5.25 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0058f,-0.0001f,0.0207f,0.9998f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.267f,-0.2467f,0.128f,0.9228f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.0317f,0.9144f,0.2944f,0.2761f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.9696f,-0.0127f,0.0032f,0.2443f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.0032f,-0.2443f,0.9696f,0.0127f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4055f,0.8468f,0.2399f],left_rotation:[0.1454f,0.1145f,-0.5756f,0.7965f]}}
particle minecraft:campfire_cosy_smoke -90.12 65.12 -40.5 0.063 0.022 -0.031 1 0 force
particle minecraft:cloud -90.12 65.32 -40.5 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -90.12 65.42 -40.5 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke -91.83 65.12 -40.36 -0.019 0.022 -0.032 1 0 force
particle minecraft:cloud -91.83 65.32 -40.36 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -91.83 65.42 -40.36 0.45 0.2 0.45 0.008 1 force
