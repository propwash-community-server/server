tp @e[type=minecraft:item_display,tag=drift.kaze] 73.196 65 -33.608 108.16 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0054f,-0.0001f,0.0223f,0.9997f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.8876f,-0.0293f,0.1862f,0.4202f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.1431f,0.4029f,0.8956f,0.1227f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.9004f,0.0118f,0.0057f,0.435f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.0057f,0.435f,0.9004f,0.0118f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4079f,0.8438f,0.1008f],left_rotation:[0.0094f,0.1853f,-0.9782f,0.0934f]}}
particle minecraft:campfire_cosy_smoke 74.96 65.12 -31.64 0.036 0.021 0.077 1 0 force
particle minecraft:cloud 74.96 65.32 -31.64 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke 74.96 65.42 -31.64 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke 75.5 65.12 -33.22 0.048 0.021 -0.009 1 0 force
particle minecraft:cloud 75.5 65.32 -33.22 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke 75.5 65.42 -33.22 0.45 0.2 0.45 0.008 1 force
tp @e[type=minecraft:item_display,tag=drift.onyx] 83.238 65 -22.706 118.93 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0.0023f,0.0001f,0.0223f,0.9997f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.837f,-0.1587f,-0.1618f,0.4981f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.215f,0.5179f,-0.8249f,0.0716f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.9004f,0.0118f,0.0057f,0.435f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.0057f,0.435f,0.9004f,0.0118f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4078f,0.8415f,0.2539f],left_rotation:[0.0776f,0.1768f,-0.8799f,0.4342f]}}
particle minecraft:campfire_cosy_smoke 84.57 65.12 -20.34 0.002 0.022 0.078 1 0 force
particle minecraft:cloud 84.57 65.32 -20.34 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 85.42 65.12 -21.81 0.049 0.022 0.005 1 0 force
particle minecraft:cloud 85.42 65.32 -21.81 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 85.42 65.42 -21.81 0.45 0.2 0.45 0.008 1 force
