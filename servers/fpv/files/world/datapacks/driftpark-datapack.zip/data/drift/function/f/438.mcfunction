tp @e[type=minecraft:item_display,tag=drift.kaze] -94.782 65 -28.871 -10.31 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0059f,-0.0001f,0.0173f,0.9998f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.5411f,-0.1346f,0.1533f,0.8158f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.0684f,0.8042f,0.5582f,0.1922f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.489f,0.0064f,0.0114f,0.8722f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.0114f,0.8722f,0.489f,0.0064f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.3996f,0.8479f,0.0999f],left_rotation:[0.0373f,0.1812f,-0.9551f,0.2314f]}}
particle minecraft:campfire_cosy_smoke -93.92 65.12 -31.1 0.058 0.022 -0.055 1 0 force
particle minecraft:cloud -93.92 65.32 -31.1 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -95.57 65.12 -30.82 -0.019 0.022 -0.038 1 0 force
particle minecraft:cloud -95.57 65.32 -30.82 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -95.57 65.42 -30.82 0.45 0.2 0.45 0.008 1 force
tp @e[type=minecraft:item_display,tag=drift.onyx] -90.863 65 -39.021 -4.46 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0059f,-0.0001f,0.021f,0.9998f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.6675f,-0.2368f,-0.1535f,0.6891f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.2268f,0.709f,-0.6463f,0.1679f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.489f,0.0064f,0.0114f,0.8722f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.0114f,0.8722f,0.489f,0.0064f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.406f,0.8466f,0.2398f],left_rotation:[0.1498f,0.1085f,-0.5423f,0.8196f]}}
particle minecraft:campfire_cosy_smoke -89.68 65.12 -41.06 0.069 0.022 -0.033 1 0 force
particle minecraft:cloud -89.68 65.32 -41.06 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -89.68 65.42 -41.06 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke -91.38 65.12 -40.94 -0.017 0.022 -0.025 1 0 force
particle minecraft:cloud -91.38 65.32 -40.94 0.35 0.18 0.35 0.02 3 force
