tp @e[type=minecraft:item_display,tag=drift.kaze] 87.338 65 -11.667 135.64 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0.0007f,0f,0.0223f,0.9998f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.12f,-0.1959f,0.0296f,0.9728f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.0725f,0.9751f,-0.1001f,0.1844f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.1274f,-0.0017f,0.013f,0.9918f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.013f,-0.9918f,0.1274f,0.0017f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4079f,0.8425f,0.1112f],left_rotation:[0.0271f,0.1896f,-0.9644f,0.1822f]}}
particle minecraft:campfire_cosy_smoke 87.96 65.12 -9.12 -0.022 0.021 0.071 1 0 force
particle minecraft:cloud 87.96 65.32 -9.12 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke 87.96 65.42 -9.12 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke 89.17 65.12 -10.26 0.051 0.021 0.029 1 0 force
particle minecraft:cloud 89.17 65.32 -10.26 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke 89.17 65.42 -10.26 0.45 0.2 0.45 0.008 1 force
tp @e[type=minecraft:item_display,tag=drift.onyx] 90.898 65 3.009 148.15 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0f,0f,0.0223f,0.9998f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.6466f,-0.126f,0.1832f,0.7297f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.1076f,0.7144f,0.6634f,0.1946f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.1274f,-0.0017f,0.013f,0.9918f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.013f,-0.9918f,0.1274f,0.0017f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4079f,0.8427f,0.25f],left_rotation:[0.0695f,0.1777f,-0.8973f,0.398f]}}
particle minecraft:campfire_cosy_smoke 90.92 65.12 5.74 -0.038 0.022 0.067 1 0 force
particle minecraft:cloud 90.92 65.32 5.74 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 90.92 65.42 5.74 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke 92.39 65.12 4.87 0.03 0.022 0.042 1 0 force
particle minecraft:cloud 92.39 65.32 4.87 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 92.39 65.42 4.87 0.45 0.2 0.45 0.008 1 force
