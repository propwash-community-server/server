tp @e[type=minecraft:item_display,tag=drift.kaze] -47.719 65 62.943 -99.35 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0059f,-0.0001f,0.0176f,0.9998f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.8636f,-0.1182f,-0.104f,0.479f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.1549f,0.4926f,-0.8559f,0.0281f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.8707f,-0.0114f,0.0064f,0.4916f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.0064f,-0.4916f,0.8707f,0.0114f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4001f,0.8476f,0.0999f],left_rotation:[0.0446f,-0.1796f,0.9615f,0.2032f]}}
particle minecraft:campfire_cosy_smoke -50.24 65.12 62.11 -0.068 0.018 -0.04 1 0 force
particle minecraft:cloud -50.24 65.32 62.11 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -50.24 65.42 62.11 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke -49.97 65.12 63.76 -0.044 0.018 0.02 1 0 force
particle minecraft:cloud -49.97 65.32 63.76 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -49.97 65.42 63.76 0.45 0.2 0.45 0.008 1 force
tp @e[type=minecraft:item_display,tag=drift.onyx] -62.026 65 59.483 -94.86 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0059f,-0.0001f,0.0201f,0.9998f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.8447f,-0.1529f,-0.1576f,0.4881f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.2098f,0.5073f,-0.8333f,0.065f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.8707f,-0.0114f,0.0064f,0.4916f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.0064f,-0.4916f,0.8707f,0.0114f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4044f,0.8473f,0.2399f],left_rotation:[0.0633f,0.1739f,-0.9092f,0.373f]}}
particle minecraft:campfire_cosy_smoke -64.39 65.12 58.32 -0.041 0.022 -0.059 1 0 force
particle minecraft:cloud -64.39 65.32 58.32 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -64.39 65.42 58.32 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke -64.26 65.12 60.03 -0.045 0.022 0.011 1 0 force
particle minecraft:cloud -64.26 65.32 60.03 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -64.26 65.42 60.03 0.45 0.2 0.45 0.008 1 force
