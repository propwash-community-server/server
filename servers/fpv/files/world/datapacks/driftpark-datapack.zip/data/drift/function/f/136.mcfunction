tp @e[type=minecraft:item_display,tag=drift.kaze] 89.283 65 14.716 164.07 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.001f,0f,0.0223f,0.9998f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.9613f,-0.0896f,-0.1761f,0.1921f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.1973f,-0.2116f,0.9572f,0.011f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.9811f,-0.0128f,0.0025f,0.1933f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.0025f,-0.1933f,0.9811f,0.0128f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4079f,0.8429f,0.1083f],left_rotation:[0.026f,0.1881f,-0.9657f,0.1774f]}}
particle minecraft:campfire_cosy_smoke 88.61 65.12 17.24 -0.046 0.021 0.069 1 0 force
particle minecraft:cloud 88.61 65.32 17.24 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke 88.61 65.42 17.24 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke 90.23 65.12 16.81 0.027 0.021 0.051 1 0 force
particle minecraft:cloud 90.23 65.32 16.81 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke 90.23 65.42 16.81 0.45 0.2 0.45 0.008 1 force
tp @e[type=minecraft:item_display,tag=drift.onyx] 85.563 65 28.939 176.08 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0011f,0f,0.0223f,0.9998f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.5954f,-0.2079f,-0.0929f,0.7705f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.1744f,0.7845f,-0.5768f,0.1465f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.9811f,-0.0128f,0.0025f,0.1933f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.0025f,-0.1933f,0.9811f,0.0128f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4079f,0.8432f,0.2481f],left_rotation:[0.0781f,0.1729f,-0.876f,0.4435f]}}
particle minecraft:campfire_cosy_smoke 84.31 65.12 31.32 -0.073 0.022 0.056 1 0 force
particle minecraft:cloud 84.31 65.32 31.32 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 84.31 65.42 31.32 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke 86.02 65.12 31.23 0.009 0.022 0.042 1 0 force
particle minecraft:cloud 86.02 65.32 31.23 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 86.02 65.42 31.23 0.45 0.2 0.45 0.008 1 force
