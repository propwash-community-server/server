tp @e[type=minecraft:item_display,tag=drift.kaze] 55.382 65 -45.252 89.48 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0.0108f,0.0002f,0.022f,0.9997f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.4567f,-0.1897f,-0.0396f,0.8682f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.1311f,0.8772f,-0.4393f,0.1428f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.4738f,-0.0062f,0.0115f,0.8806f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.0115f,-0.8806f,0.4738f,0.0062f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4074f,0.8403f,0.1286f],left_rotation:[0.0204f,0.2004f,-0.9692f,0.1419f]}}
particle minecraft:campfire_cosy_smoke 57.78 65.12 -43.89 0.056 0.021 0.072 1 0 force
particle minecraft:cloud 57.78 65.32 -43.89 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke 57.78 65.42 -43.89 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke 57.8 65.12 -45.56 0.062 0.021 -0.021 1 0 force
particle minecraft:cloud 57.8 65.32 -45.56 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke 57.8 65.42 -45.56 0.45 0.2 0.45 0.008 1 force
tp @e[type=minecraft:item_display,tag=drift.onyx] 70.248 65 -37.099 101.08 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0058f,-0.0001f,0.0222f,0.9997f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.5447f,-0.1386f,0.1573f,0.812f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.0729f,0.7999f,0.5623f,0.1966f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.4738f,-0.0062f,0.0115f,0.8806f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.0115f,-0.8806f,0.4738f,0.0062f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.408f,0.8455f,0.24f],left_rotation:[0.0462f,0.1792f,-0.9398f,0.2871f]}}
particle minecraft:campfire_cosy_smoke 72.36 65.12 -35.26 0.038 0.022 0.081 1 0 force
particle minecraft:cloud 72.36 65.32 -35.26 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 72.36 65.42 -35.26 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke 72.71 65.12 -36.93 0.049 0.022 0.001 1 0 force
particle minecraft:cloud 72.71 65.32 -36.93 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 72.71 65.42 -36.93 0.45 0.2 0.45 0.008 1 force
