tp @e[type=minecraft:item_display,tag=drift.kaze] -81.869 65 38.338 -51.14 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0.0111f,0.0002f,0.0151f,0.9998f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.0971f,-0.1856f,0.035f,0.9772f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.0675f,0.9789f,-0.0781f,0.1764f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.1619f,-0.0021f,0.0129f,0.9867f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.0129f,-0.9867f,0.1619f,0.0021f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.3958f,0.8458f,0.1291f],left_rotation:[0.0123f,0.2014f,-0.9754f,0.0891f]}}
particle minecraft:campfire_cosy_smoke -82.85 65.12 35.82 -0.007 0.02 -0.085 1 0 force
particle minecraft:cloud -82.85 65.32 35.82 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -83.94 65.12 37.08 -0.044 0.02 -0.026 1 0 force
particle minecraft:cloud -83.94 65.32 37.08 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -83.94 65.42 37.08 0.45 0.2 0.45 0.008 1 force
tp @e[type=minecraft:item_display,tag=drift.onyx] -89.228 65 22.276 -29.56 0
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.2066f,-0.0763f,0.0374f,0.9747f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.0648f,0.9762f,-0.1997f,0.055f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.1619f,-0.0021f,0.0129f,0.9867f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.0129f,-0.9867f,0.1619f,0.0021f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.3894f,0.8514f,0.25f],left_rotation:[0.1582f,-0.1068f,0.5675f,0.801f]}}
particle minecraft:campfire_cosy_smoke -89.61 65.12 19.4 0.006 0.012 -0.083 1 0 force
particle minecraft:campfire_cosy_smoke -91.11 65.12 20.23 -0.059 0.012 -0.046 1 0 force
