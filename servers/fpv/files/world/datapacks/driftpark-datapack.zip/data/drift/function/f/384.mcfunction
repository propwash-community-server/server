tp @e[type=minecraft:item_display,tag=drift.kaze] -65.836 65 -44.703 71.07 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0029f,-0.0001f,0.0223f,0.9997f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.6491f,-0.2302f,-0.1365f,0.7121f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.212f,0.7303f,-0.6285f,0.1633f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.801f,-0.0105f,0.0078f,0.5985f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.0078f,-0.5985f,0.801f,0.0105f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4079f,0.8433f,0.1049f],left_rotation:[0.1353f,0.1304f,-0.6496f,0.7367f]}}
particle minecraft:campfire_cosy_smoke -63.63 65.12 -44.04 0.041 0.022 0.047 1 0 force
particle minecraft:cloud -63.63 65.32 -44.04 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -63.63 65.42 -44.04 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke -64.13 65.12 -45.64 0.021 0.022 -0.023 1 0 force
particle minecraft:cloud -64.13 65.32 -45.64 0.35 0.18 0.35 0.02 3 force
tp @e[type=minecraft:item_display,tag=drift.onyx] -55.844 65 -39.872 89.92 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0.0112f,0.0002f,0.0216f,0.9997f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.8681f,-0.0726f,0.2922f,0.3946f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.2523f,0.3661f,0.8805f,0.1642f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.801f,-0.0105f,0.0078f,0.5985f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.0078f,-0.5985f,0.801f,0.0105f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4066f,0.8374f,0.2692f],left_rotation:[0.182f,0.0872f,-0.3845f,0.9008f]}}
particle minecraft:campfire_cosy_smoke -53.77 65.12 -38.36 0.037 0.022 0.065 1 0 force
particle minecraft:cloud -53.77 65.32 -38.36 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -53.71 65.12 -40.07 0.037 0.022 -0.016 1 0 force
particle minecraft:cloud -53.71 65.32 -40.07 0.35 0.18 0.35 0.02 3 force
