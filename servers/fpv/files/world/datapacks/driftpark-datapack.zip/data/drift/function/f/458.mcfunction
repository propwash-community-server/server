tp @e[type=minecraft:item_display,tag=drift.kaze] -96.792 65 -10.195 -25.86 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0059f,-0.0001f,0.0182f,0.9998f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.9854f,0.053f,0.1617f,0.0003f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.1626f,-0.0167f,0.9853f,0.0503f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.9981f,0.0131f,0.0008f,0.0609f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.0008f,0.0609f,0.9981f,0.0131f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4011f,0.8472f,0.0999f],left_rotation:[0.0224f,-0.1837f,0.9792f,0.0832f]}}
particle minecraft:campfire_cosy_smoke -96.66 65.12 -12.78 0.042 0.019 -0.066 1 0 force
particle minecraft:cloud -96.66 65.32 -12.78 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -96.66 65.42 -12.78 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke -98.17 65.12 -12.06 -0.044 0.019 -0.042 1 0 force
particle minecraft:cloud -98.17 65.32 -12.06 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -98.17 65.42 -12.06 0.45 0.2 0.45 0.008 1 force
tp @e[type=minecraft:item_display,tag=drift.onyx] -96.922 65 -23.97 -18.85 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0059f,-0.0001f,0.0175f,0.9998f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.9189f,-0.0215f,0.221f,0.3259f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.188f,0.3045f,0.9263f,0.1182f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.9981f,0.0131f,0.0008f,0.0609f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.0008f,0.0609f,0.9981f,0.0131f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4f,0.8494f,0.2398f],left_rotation:[0.0677f,0.1722f,-0.9014f,0.3915f]}}
particle minecraft:campfire_cosy_smoke -96.37 65.12 -26.48 0.043 0.022 -0.053 1 0 force
particle minecraft:cloud -96.37 65.32 -26.48 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -97.99 65.12 -25.95 -0.022 0.022 -0.037 1 0 force
particle minecraft:cloud -97.99 65.32 -25.95 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -97.99 65.42 -25.95 0.45 0.2 0.45 0.008 1 force
