tp @e[type=minecraft:item_display,tag=drift.kaze] 72.377 65 -34.351 107.25 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0055f,-0.0001f,0.0223f,0.9997f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.6374f,-0.1713f,-0.0762f,0.7473f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.1551f,0.7595f,-0.6229f,0.1052f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.655f,-0.0086f,0.0099f,0.7555f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.0099f,-0.7555f,0.655f,0.0086f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4079f,0.8439f,0.1004f],left_rotation:[0.0075f,0.1852f,-0.9791f,0.0835f]}}
particle minecraft:campfire_cosy_smoke 74.18 65.12 -32.41 0.027 0.021 0.067 1 0 force
particle minecraft:cloud 74.18 65.32 -32.41 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke 74.18 65.42 -32.41 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke 74.7 65.12 -33.99 0.054 0.021 0.007 1 0 force
particle minecraft:cloud 74.7 65.32 -33.99 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke 74.7 65.42 -33.99 0.45 0.2 0.45 0.008 1 force
tp @e[type=minecraft:item_display,tag=drift.onyx] 82.69 65 -23.611 117.85 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0.0024f,0.0001f,0.0223f,0.9997f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.2673f,-0.1965f,0.1119f,0.9367f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.0141f,0.9301f,0.2895f,0.2257f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.655f,-0.0086f,0.0099f,0.7555f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.0099f,-0.7555f,0.655f,0.0086f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4078f,0.8415f,0.2541f],left_rotation:[0.0768f,0.1772f,-0.882f,0.4298f]}}
particle minecraft:campfire_cosy_smoke 84.06 65.12 -21.27 0.012 0.022 0.084 1 0 force
particle minecraft:cloud 84.06 65.32 -21.27 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 84.06 65.42 -21.27 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke 84.89 65.12 -22.77 0.048 0.022 0.009 1 0 force
particle minecraft:cloud 84.89 65.32 -22.77 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 84.89 65.42 -22.77 0.45 0.2 0.45 0.008 1 force
