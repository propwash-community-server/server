tp @e[type=minecraft:item_display,tag=drift.kaze] -45.427 65 -26.705 136.89 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0059f,0f,-0.0028f,1f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.8509f,0.0208f,0.0665f,0.5208f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.0121f,0.5166f,0.8534f,0.0686f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.5582f,-0.0073f,0.0109f,0.8296f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.0109f,-0.8296f,0.5582f,0.0073f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.3651f,0.8633f,0.0999f],left_rotation:[0.1692f,-0.075f,0.3932f,0.9006f]}}
playsound driftpark:lap.kaze.06.112 neutral @a -44.85 65.5 -25.96 12 1
playsound driftpark:lap.kaze.06.113 neutral @a -49.7 65.5 -32.11 12 1
playsound driftpark:lap.kaze.06.114 neutral @a -55.09 65.5 -37.98 12 1
playsound driftpark:lap.kaze.06.115 neutral @a -60.42 65.5 -42.13 12 1
playsound driftpark:lap.kaze.06.116 neutral @a -65.84 65.5 -44.7 12 1
playsound driftpark:lap.kaze.06.117 neutral @a -71.79 65.5 -46.02 12 1
playsound driftpark:lap.kaze.06.118 neutral @a -77.59 65.5 -45.98 12 1
playsound driftpark:lap.kaze.06.119 neutral @a -82.56 65.5 -44.68 12 1
playsound driftpark:lap.kaze.06.120 neutral @a -86.59 65.5 -42.27 12 1
tp @e[type=minecraft:item_display,tag=drift.onyx] -37.836 65 -16.941 162.85 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0059f,0.0001f,-0.0199f,0.9998f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.9682f,-0.0302f,0.2265f,0.1017f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.2171f,-0.0784f,0.9704f,0.0714f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.5582f,-0.0073f,0.0109f,0.8296f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.0109f,-0.8296f,0.5582f,0.0073f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.3354f,0.8769f,0.2399f],left_rotation:[0.0778f,-0.1679f,0.8745f,0.4484f]}}
particle minecraft:campfire_cosy_smoke -37.61 65.12 -14.81 -0.011 0.022 0.034 1 0 force
particle minecraft:cloud -37.61 65.32 -14.81 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -37.61 65.42 -14.81 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke -35.98 65.12 -15.32 0.062 0.022 0.008 1 0 force
particle minecraft:cloud -35.98 65.32 -15.32 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -35.98 65.42 -15.32 0.45 0.2 0.45 0.008 1 force
