tp @e[type=minecraft:item_display,tag=drift.kaze] -96.592 65 -20.149 -18.86 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0059f,-0.0001f,0.0185f,0.9998f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.8605f,-0.0418f,0.1868f,0.4722f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.1382f,0.4552f,0.8696f,0.1324f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.847f,0.0111f,0.007f,0.5315f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.007f,0.5315f,0.847f,0.0111f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4015f,0.847f,0.0998f],left_rotation:[0.0152f,0.1844f,-0.9758f,0.1167f]}}
particle minecraft:campfire_cosy_smoke -96.09 65.12 -22.59 0.046 0.021 -0.055 1 0 force
particle minecraft:cloud -96.09 65.32 -22.59 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -97.68 65.12 -22.07 -0.033 0.021 -0.029 1 0 force
particle minecraft:cloud -97.68 65.32 -22.07 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -97.68 65.42 -22.07 0.45 0.2 0.45 0.008 1 force
tp @e[type=minecraft:item_display,tag=drift.onyx] -94.524 65 -32.294 -11.12 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0058f,-0.0001f,0.018f,0.9998f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.8395f,-0.0711f,0.2297f,0.4873f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.1798f,0.4658f,0.8516f,0.1597f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.847f,0.0111f,0.007f,0.5315f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.007f,0.5315f,0.847f,0.0111f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4009f,0.8489f,0.24f],left_rotation:[0.0967f,0.1578f,-0.8189f,0.5432f]}}
particle minecraft:campfire_cosy_smoke -93.63 65.12 -34.59 0.058 0.022 -0.049 1 0 force
particle minecraft:cloud -93.63 65.32 -34.59 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -93.63 65.42 -34.59 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke -95.31 65.12 -34.28 -0.026 0.022 -0.025 1 0 force
particle minecraft:cloud -95.31 65.32 -34.28 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -95.31 65.42 -34.28 0.45 0.2 0.45 0.008 1 force
