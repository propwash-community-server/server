tp @e[type=minecraft:item_display,tag=drift.kaze] 81.101 65 34.718 -172.01 0
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.5032f,-0.1954f,-0.0548f,0.84f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.1434f,0.8504f,-0.4854f,0.1435f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.5141f,-0.0067f,0.0112f,0.8576f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.0112f,-0.8576f,0.5141f,0.0067f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4079f,0.8418f,0.1165f],left_rotation:[0.0363f,0.1911f,-0.9546f,0.2257f]}}
particle minecraft:campfire_cosy_smoke 79.46 65.12 36.74 -0.079 0.022 0.044 1 0 force
particle minecraft:cloud 79.46 65.32 36.74 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke 79.46 65.42 36.74 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke 81.11 65.12 37 0.01 0.022 0.05 1 0 force
particle minecraft:cloud 81.11 65.32 37 0.35 0.18 0.35 0.02 2 force
tp @e[type=minecraft:item_display,tag=drift.onyx] 71.214 65 46.506 -158.43 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0.0026f,0.0001f,0.0223f,0.9997f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.0643f,-0.2096f,0.0675f,0.9733f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.0344f,0.9716f,0.0867f,0.2175f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.5141f,-0.0067f,0.0112f,0.8576f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.0112f,-0.8576f,0.5141f,0.0067f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4078f,0.8414f,0.2544f],left_rotation:[0.0668f,0.1814f,-0.9048f,0.3795f]}}
particle minecraft:campfire_cosy_smoke 68.98 65.12 48.2 -0.08 0.022 0.031 1 0 force
particle minecraft:cloud 68.98 65.32 48.2 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 68.98 65.42 48.2 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke 70.56 65.12 48.86 -0.005 0.022 0.053 1 0 force
particle minecraft:cloud 70.56 65.32 48.86 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 70.56 65.42 48.86 0.45 0.2 0.45 0.008 1 force
