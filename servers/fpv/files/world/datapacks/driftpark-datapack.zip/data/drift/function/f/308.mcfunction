tp @e[type=minecraft:item_display,tag=drift.kaze] -16.276 65 -11.428 120.79 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0053f,0.0001f,-0.0223f,0.9997f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.9429f,-0.0018f,0.28f,0.1805f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.2626f,-0.1521f,0.9479f,0.0973f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.2974f,0.0039f,0.0125f,0.9547f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.0125f,0.9547f,0.2974f,0.0039f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.3313f,0.8767f,0.1009f],left_rotation:[0.1479f,-0.1121f,0.5581f,0.8088f]}}
particle minecraft:campfire_cosy_smoke -14.91 65.12 -10.19 0.005 0.022 0.031 1 0 force
particle minecraft:cloud -14.91 65.32 -10.19 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -14.1 65.12 -11.65 0.041 0.022 -0.04 1 0 force
particle minecraft:cloud -14.1 65.32 -11.65 0.35 0.18 0.35 0.02 3 force
tp @e[type=minecraft:item_display,tag=drift.onyx] -7.492 65 -14.431 100.26 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0.0092f,-0.0002f,-0.0223f,0.9997f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.5755f,0.2947f,-0.1572f,0.7465f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.2365f,-0.7671f,-0.5477f,0.2359f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.2974f,0.0039f,0.0125f,0.9547f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.0125f,0.9547f,0.2974f,0.0039f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.3316f,0.8708f,0.2659f],left_rotation:[0.1982f,-0.0258f,0.0829f,0.9763f]}}
particle minecraft:campfire_cosy_smoke -5.62 65.12 -13.84 0.033 0.022 0.007 1 0 force
particle minecraft:cloud -5.62 65.32 -13.84 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -5.62 65.42 -13.84 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke -5.37 65.12 -15.53 0.028 0.022 -0.067 1 0 force
particle minecraft:cloud -5.37 65.32 -15.53 0.35 0.18 0.35 0.02 3 force
