tp @e[type=minecraft:item_display,tag=drift.kaze] 73.281 65 43.702 -158.46 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0.0031f,0.0001f,0.0223f,0.9997f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.7002f,-0.094f,0.172f,0.6865f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.1008f,0.6722f,0.7139f,0.1681f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.7142f,0.0093f,0.0092f,0.6998f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.0092f,0.6998f,0.7142f,0.0093f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4079f,0.842f,0.1153f],left_rotation:[0.0236f,0.1924f,-0.9674f,0.1627f]}}
particle minecraft:campfire_cosy_smoke 71.18 65.12 45.35 -0.073 0.021 0.026 1 0 force
particle minecraft:cloud 71.18 65.32 45.35 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke 71.18 65.42 45.35 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke 72.72 65.12 45.99 -0.003 0.021 0.049 1 0 force
particle minecraft:cloud 72.72 65.32 45.99 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke 72.72 65.42 45.99 0.45 0.2 0.45 0.008 1 force
tp @e[type=minecraft:item_display,tag=drift.onyx] 60.554 65 53.591 -146.25 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0.0053f,0.0001f,0.0223f,0.9997f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.9508f,0.0045f,0.2174f,0.2208f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.1954f,0.1991f,0.9556f,0.0954f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.7142f,0.0093f,0.0092f,0.6998f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.0092f,0.6998f,0.7142f,0.0093f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4078f,0.84f,0.2591f],left_rotation:[0.0628f,0.1857f,-0.9141f,0.355f]}}
particle minecraft:campfire_cosy_smoke 57.98 65.12 54.8 -0.093 0.022 -0.006 1 0 force
particle minecraft:cloud 57.98 65.32 54.8 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 59.38 65.12 55.78 -0.016 0.022 0.055 1 0 force
particle minecraft:cloud 59.38 65.32 55.78 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 59.38 65.42 55.78 0.45 0.2 0.45 0.008 1 force
