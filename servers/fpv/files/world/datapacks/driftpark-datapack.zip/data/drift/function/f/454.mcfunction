tp @e[type=minecraft:item_display,tag=drift.kaze] -96.926 65 -14.306 -23.77 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0058f,-0.0001f,0.0189f,0.9998f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.4845f,-0.1786f,-0.04f,0.8554f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.1302f,0.8643f,-0.4684f,0.1286f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.5437f,-0.0071f,0.011f,0.8392f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.011f,-0.8392f,0.5437f,0.0071f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4023f,0.8466f,0.1f],left_rotation:[0.0002f,0.1851f,-0.982f,0.0381f]}}
particle minecraft:campfire_cosy_smoke -96.66 65.12 -16.84 0.044 0.02 -0.076 1 0 force
particle minecraft:cloud -96.66 65.32 -16.84 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -98.19 65.12 -16.19 -0.028 0.02 -0.038 1 0 force
particle minecraft:cloud -98.19 65.32 -16.19 0.35 0.18 0.35 0.02 2 force
tp @e[type=minecraft:item_display,tag=drift.onyx] -96.123 65 -27.472 -15.53 0
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.7457f,-0.183f,-0.1344f,0.6264f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.2009f,0.644f,-0.7306f,0.1056f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.5437f,-0.0071f,0.011f,0.8392f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.011f,-0.8392f,0.5437f,0.0071f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.3994f,0.8497f,0.2399f],left_rotation:[0.0758f,0.1688f,-0.8821f,0.4331f]}}
particle minecraft:campfire_cosy_smoke -95.42 65.12 -29.9 0.055 0.022 -0.047 1 0 force
particle minecraft:cloud -95.42 65.32 -29.9 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -97.07 65.12 -29.47 -0.026 0.022 -0.036 1 0 force
particle minecraft:cloud -97.07 65.32 -29.47 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -97.07 65.42 -29.47 0.45 0.2 0.45 0.008 1 force
