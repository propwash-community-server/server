tp @e[type=minecraft:item_display,tag=drift.kaze] -85.019 65 31.777 -39.75 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0.0086f,0.0001f,0.0107f,0.9999f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.988f,0.0427f,0.1244f,0.081f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.1166f,0.0684f,0.989f,0.0609f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.989f,0.0129f,0.0019f,0.1475f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.0019f,0.1475f,0.989f,0.0129f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.3883f,0.8498f,0.1248f],left_rotation:[0.0938f,-0.1758f,0.8743f,0.4426f]}}
particle minecraft:campfire_cosy_smoke -85.69 65.12 29.06 0.002 0.016 -0.083 1 0 force
particle minecraft:cloud -85.69 65.32 29.06 0.35 0.18 0.35 0.02 1 force
particle minecraft:campfire_cosy_smoke -87 65.12 30.08 -0.06 0.016 -0.032 1 0 force
particle minecraft:cloud -87 65.32 30.08 0.35 0.18 0.35 0.02 1 force
tp @e[type=minecraft:item_display,tag=drift.onyx] -91.762 65 14.905 -26.09 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0051f,-0.0001f,0.0109f,0.9999f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.9713f,0.0372f,0.072f,0.2236f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.0489f,0.2173f,0.9727f,0.0647f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.989f,0.0129f,0.0019f,0.1475f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.0019f,0.1475f,0.989f,0.0129f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.3888f,0.8542f,0.2412f],left_rotation:[0.1585f,-0.0969f,0.5305f,0.8271f]}}
