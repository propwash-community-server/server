tp @e[type=minecraft:item_display,tag=drift.kaze] 89.005 65 -5.438 142.57 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0004f,0f,0.0223f,0.9998f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.9747f,0.0324f,0.194f,0.1064f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.1839f,0.0866f,0.9766f,0.0698f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.9935f,0.013f,0.0015f,0.113f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.0015f,0.113f,0.9935f,0.013f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4079f,0.8428f,0.1093f],left_rotation:[0.0244f,0.1889f,-0.9671f,0.1689f]}}
particle minecraft:campfire_cosy_smoke 89.31 65.12 -2.83 -0.014 0.021 0.068 1 0 force
particle minecraft:cloud 89.31 65.32 -2.83 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke 90.66 65.12 -3.82 0.05 0.021 0.029 1 0 force
particle minecraft:cloud 90.66 65.32 -3.82 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke 90.66 65.42 -3.82 0.45 0.2 0.45 0.008 1 force
tp @e[type=minecraft:item_display,tag=drift.onyx] 90.789 65 9.503 154.91 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0002f,0f,0.0223f,0.9998f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.7409f,-0.1815f,-0.1298f,0.6335f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.1971f,0.6506f,-0.7259f,0.1047f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.9935f,0.013f,0.0015f,0.113f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.0015f,0.113f,0.9935f,0.013f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4079f,0.8428f,0.2496f],left_rotation:[0.0708f,0.1769f,-0.8943f,0.4048f]}}
particle minecraft:campfire_cosy_smoke 90.49 65.12 12.22 -0.04 0.022 0.065 1 0 force
particle minecraft:cloud 90.49 65.32 12.22 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 90.49 65.42 12.22 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke 92.05 65.12 11.53 0.041 0.022 0.044 1 0 force
particle minecraft:cloud 92.05 65.32 11.53 0.35 0.18 0.35 0.02 3 force
