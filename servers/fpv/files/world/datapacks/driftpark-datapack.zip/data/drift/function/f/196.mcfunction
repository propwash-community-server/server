tp @e[type=minecraft:item_display,tag=drift.kaze] 64.05 65 -40.588 98.91 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0059f,-0.0001f,0.0222f,0.9997f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.9816f,-0.0632f,-0.1705f,0.0576f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.1775f,-0.0758f,0.9804f,0.0396f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.9987f,-0.0131f,0.0006f,0.0493f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.0006f,-0.0493f,0.9987f,0.0131f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4079f,0.844f,0.0999f],left_rotation:[-0.0025f,0.185f,-0.9823f,0.0303f]}}
particle minecraft:campfire_cosy_smoke 66.21 65.12 -38.89 0.052 0.02 0.062 1 0 force
particle minecraft:cloud 66.21 65.32 -38.89 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke 66.49 65.12 -40.54 0.052 0.02 -0.007 1 0 force
particle minecraft:cloud 66.49 65.32 -40.54 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke 66.49 65.42 -40.54 0.45 0.2 0.45 0.008 1 force
tp @e[type=minecraft:item_display,tag=drift.onyx] 76.876 65 -31.117 108.39 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0047f,-0.0001f,0.0223f,0.9997f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.451f,-0.2125f,-0.0504f,0.8654f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.1416f,0.8755f,-0.4311f,0.1663f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.9987f,-0.0131f,0.0006f,0.0493f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.0006f,-0.0493f,0.9987f,0.0131f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.408f,0.845f,0.2419f],left_rotation:[0.0613f,0.1758f,-0.9125f,0.3644f]}}
particle minecraft:campfire_cosy_smoke 78.66 65.12 -29.05 0.031 0.022 0.07 1 0 force
particle minecraft:cloud 78.66 65.32 -29.05 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 78.66 65.42 -29.05 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke 79.23 65.12 -30.66 0.052 0.022 0.001 1 0 force
particle minecraft:cloud 79.23 65.32 -30.66 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 79.23 65.42 -30.66 0.45 0.2 0.45 0.008 1 force
