tp @e[type=minecraft:item_display,tag=drift.kaze] -95.676 65 -1.54 -24.26 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0059f,-0.0001f,0.0145f,0.9999f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.5101f,-0.1131f,-0.0063f,0.8526f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.096f,0.858f,-0.5011f,0.0601f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.5678f,-0.0074f,0.0108f,0.823f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.0108f,-0.823f,0.5678f,0.0074f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.3949f,0.8501f,0.0998f],left_rotation:[0.116f,-0.1441f,0.7832f,0.5936f]}}
particle minecraft:campfire_cosy_smoke -95.66 65.12 -4.19 0.029 0.015 -0.07 1 0 force
particle minecraft:campfire_cosy_smoke -97.18 65.12 -3.49 -0.042 0.015 -0.045 1 0 force
tp @e[type=minecraft:item_display,tag=drift.onyx] -97.72 65 -16.332 -25.81 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0059f,-0.0001f,0.0189f,0.9998f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.7279f,-0.1765f,-0.1169f,0.6522f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.1861f,0.668f,-0.7134f,0.101f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.5678f,-0.0074f,0.0108f,0.823f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.0108f,-0.823f,0.5678f,0.0074f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4024f,0.8483f,0.2399f],left_rotation:[0.0503f,0.1781f,-0.9349f,0.3027f]}}
particle minecraft:campfire_cosy_smoke -97.51 65.12 -18.97 0.037 0.022 -0.077 1 0 force
particle minecraft:cloud -97.51 65.32 -18.97 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -97.51 65.42 -18.97 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke -99.06 65.12 -18.25 -0.044 0.022 -0.031 1 0 force
particle minecraft:cloud -99.06 65.32 -18.25 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -99.06 65.42 -18.25 0.45 0.2 0.45 0.008 1 force
