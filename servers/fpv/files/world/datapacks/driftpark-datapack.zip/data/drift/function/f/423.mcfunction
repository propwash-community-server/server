tp @e[type=minecraft:item_display,tag=drift.kaze] -89.725 65 -39.035 0.43 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0058f,-0.0001f,0.0213f,0.9998f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.8689f,-0.1588f,-0.2029f,0.4225f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.2484f,0.4462f,-0.857f,0.0684f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.2358f,-0.0031f,0.0127f,0.9717f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.0127f,-0.9717f,0.2358f,0.0031f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4064f,0.8447f,0.0999f],left_rotation:[0.1206f,0.1404f,-0.7173f,0.6717f]}}
particle minecraft:campfire_cosy_smoke -88.43 65.12 -40.85 0.056 0.022 -0.022 1 0 force
particle minecraft:cloud -88.43 65.32 -40.85 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -88.43 65.42 -40.85 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke -90.1 65.12 -40.89 -0.017 0.022 -0.037 1 0 force
particle minecraft:cloud -90.1 65.32 -40.89 0.35 0.18 0.35 0.02 3 force
tp @e[type=minecraft:item_display,tag=drift.onyx] -83.473 65 -45.265 18.87 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0.0041f,0.0001f,0.0223f,0.9997f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.7149f,-0.1565f,0.2607f,0.6297f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.1959f,0.6058f,0.7353f,0.2325f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.2358f,-0.0031f,0.0127f,0.9717f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.0127f,-0.9717f,0.2358f,0.0031f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4078f,0.8406f,0.2571f],left_rotation:[0.178f,0.0792f,-0.3583f,0.913f]}}
particle minecraft:campfire_cosy_smoke -81.59 65.12 -46.53 0.059 0.022 0 1 0 force
particle minecraft:cloud -81.59 65.32 -46.53 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -81.59 65.42 -46.53 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke -83.19 65.12 -47.14 -0.015 0.022 -0.027 1 0 force
particle minecraft:cloud -83.19 65.32 -47.14 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -83.19 65.42 -47.14 0.45 0.2 0.45 0.008 1 force
