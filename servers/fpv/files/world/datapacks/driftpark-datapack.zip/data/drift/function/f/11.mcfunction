tp @e[type=minecraft:item_display,tag=drift.kaze] -39.719 65 64.036 -98.01 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0058f,-0.0001f,0.0153f,0.9999f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.9676f,-0.0731f,-0.0811f,0.2277f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.1055f,-0.2375f,0.9652f,0.0282f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.9724f,-0.0127f,0.0031f,0.233f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.0031f,-0.233f,0.9724f,0.0127f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.3962f,0.8495f,0.1f],left_rotation:[0.1221f,-0.1391f,0.7582f,0.6252f]}}
particle minecraft:campfire_cosy_smoke -42.32 65.12 63.29 -0.074 0.014 -0.053 1 0 force
particle minecraft:campfire_cosy_smoke -42.07 65.12 64.94 -0.052 0.014 0.037 1 0 force
tp @e[type=minecraft:item_display,tag=drift.onyx] -55.275 65 61.842 -99.74 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0059f,-0.0001f,0.0186f,0.9998f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.9396f,-0.1067f,-0.1753f,0.2739f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.205f,0.2938f,-0.9336f,0.0085f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.9724f,-0.0127f,0.0031f,0.233f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.0031f,-0.233f,0.9724f,0.0127f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4018f,0.8485f,0.2398f],left_rotation:[0.0392f,0.1808f,-0.9521f,0.2436f]}}
particle minecraft:campfire_cosy_smoke -57.82 65.12 60.93 -0.06 0.022 -0.051 1 0 force
particle minecraft:cloud -57.82 65.32 60.93 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -57.82 65.42 60.93 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke -57.55 65.12 62.61 -0.052 0.022 0.021 1 0 force
particle minecraft:cloud -57.55 65.32 62.61 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -57.55 65.42 62.61 0.45 0.2 0.45 0.008 1 force
