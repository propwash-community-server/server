tp @e[type=minecraft:item_display,tag=drift.kaze] -88.427 65 -40.554 3.64 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0059f,-0.0001f,0.022f,0.9997f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.8235f,-0.1823f,-0.1955f,0.5004f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.2492f,0.5237f,-0.8089f,0.0967f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.8501f,-0.0111f,0.0069f,0.5265f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.0069f,-0.5265f,0.8501f,0.0111f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4075f,0.8441f,0.0999f],left_rotation:[0.1329f,0.1288f,-0.6521f,0.7352f]}}
particle minecraft:campfire_cosy_smoke -87.03 65.12 -42.25 0.053 0.022 -0.023 1 0 force
particle minecraft:cloud -87.03 65.32 -42.25 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -87.03 65.42 -42.25 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke -88.69 65.12 -42.4 -0.018 0.022 -0.021 1 0 force
particle minecraft:cloud -88.69 65.32 -42.4 0.35 0.18 0.35 0.02 3 force
tp @e[type=minecraft:item_display,tag=drift.onyx] -81.698 65 -45.965 24.9 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0.0059f,0.0001f,0.0223f,0.9997f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.8882f,-0.0575f,0.3055f,0.3384f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.2716f,0.3081f,0.8991f,0.1512f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.8501f,-0.0111f,0.0069f,0.5265f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.0069f,-0.5265f,0.8501f,0.0111f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4078f,0.8397f,0.2601f],left_rotation:[0.1844f,0.068f,-0.2979f,0.9341f]}}
particle minecraft:campfire_cosy_smoke -79.67 65.12 -47.04 0.062 0.022 0.001 1 0 force
particle minecraft:cloud -79.67 65.32 -47.04 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -79.67 65.42 -47.04 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke -81.2 65.12 -47.81 -0.008 0.022 -0.033 1 0 force
particle minecraft:cloud -81.2 65.32 -47.81 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -81.2 65.42 -47.81 0.45 0.2 0.45 0.008 1 force
