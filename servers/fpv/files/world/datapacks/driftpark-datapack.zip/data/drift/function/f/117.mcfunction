tp @e[type=minecraft:item_display,tag=drift.kaze] 82.251 65 32.982 -174.44 0
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.858f,-0.1411f,-0.1458f,0.4719f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.1962f,0.4898f,-0.8479f,0.0517f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.8764f,-0.0115f,0.0063f,0.4814f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.0063f,-0.4814f,0.8764f,0.0115f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4079f,0.8418f,0.1164f],left_rotation:[0.0362f,0.191f,-0.9547f,0.2254f]}}
particle minecraft:campfire_cosy_smoke 80.7 65.12 35.06 -0.077 0.022 0.041 1 0 force
particle minecraft:cloud 80.7 65.32 35.06 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke 80.7 65.42 35.06 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke 82.36 65.12 35.25 0.006 0.022 0.047 1 0 force
particle minecraft:cloud 82.36 65.32 35.25 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke 82.36 65.42 35.25 0.45 0.2 0.45 0.008 1 force
tp @e[type=minecraft:item_display,tag=drift.onyx] 72.956 65 45.022 -160.82 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0.0029f,0.0001f,0.0223f,0.9997f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.4258f,-0.2166f,-0.0456f,0.8773f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.138f,0.887f,-0.4053f,0.1731f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.8764f,-0.0115f,0.0063f,0.4814f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.0063f,-0.4814f,0.8764f,0.0115f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4078f,0.8412f,0.255f],left_rotation:[0.0688f,0.181f,-0.9006f,0.3892f]}}
particle minecraft:campfire_cosy_smoke 70.8 65.12 46.8 -0.09 0.022 0.032 1 0 force
particle minecraft:cloud 70.8 65.32 46.8 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 70.8 65.42 46.8 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke 72.4 65.12 47.4 -0.003 0.022 0.046 1 0 force
particle minecraft:cloud 72.4 65.32 47.4 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 72.4 65.42 47.4 0.45 0.2 0.45 0.008 1 force
