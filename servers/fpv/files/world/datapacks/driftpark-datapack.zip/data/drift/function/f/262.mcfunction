tp @e[type=minecraft:item_display,tag=drift.kaze] 8.186 65 -37.538 14.16 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0058f,-0.0001f,0.0161f,0.9999f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.1878f,-0.1297f,0.079f,0.9704f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.0226f,0.9674f,0.2025f,0.1502f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.1101f,-0.0014f,0.013f,0.9938f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.013f,-0.9938f,0.1101f,0.0014f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.3976f,0.8489f,0.1f],left_rotation:[0.054f,-0.177f,0.9488f,0.256f]}}
particle minecraft:campfire_cosy_smoke 9.75 65.12 -39.26 0.059 0.019 -0.021 1 0 force
particle minecraft:cloud 9.75 65.32 -39.26 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke 9.75 65.42 -39.26 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke 8.12 65.12 -39.63 -0.023 0.019 -0.046 1 0 force
particle minecraft:cloud 8.12 65.32 -39.63 0.35 0.18 0.35 0.02 2 force
tp @e[type=minecraft:item_display,tag=drift.onyx] 15.015 65 -45.483 14.98 0
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.6275f,-0.1854f,0.2346f,0.7189f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.1603f,0.6982f,0.6505f,0.2524f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.1101f,-0.0014f,0.013f,0.9938f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.013f,-0.9938f,0.1101f,0.0014f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4077f,0.8394f,0.2611f],left_rotation:[0.1761f,0.0887f,-0.4018f,0.8943f]}}
particle minecraft:campfire_cosy_smoke 16.91 65.12 -47.02 0.076 0.022 -0.017 1 0 force
particle minecraft:cloud 16.91 65.32 -47.02 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 16.91 65.42 -47.02 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke 15.27 65.12 -47.51 -0.009 0.022 -0.04 1 0 force
particle minecraft:cloud 15.27 65.32 -47.51 0.35 0.18 0.35 0.02 3 force
