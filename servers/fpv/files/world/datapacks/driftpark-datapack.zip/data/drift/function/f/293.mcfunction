tp @e[type=minecraft:item_display,tag=drift.kaze] -7.454 65 -15.598 93.89 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0.0099f,-0.0002f,-0.0223f,0.9997f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.7427f,0.144f,0.2666f,0.5971f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.2053f,-0.5724f,0.762f,0.2228f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.4324f,-0.0057f,0.0118f,0.9016f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.0118f,-0.9016f,0.4324f,0.0057f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.3315f,0.8733f,0.127f],left_rotation:[0.1824f,-0.0833f,0.3671f,0.9083f]}}
particle minecraft:campfire_cosy_smoke -5.59 65.12 -15.19 0.031 0.022 0.018 1 0 force
particle minecraft:cloud -5.59 65.32 -15.19 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -5.53 65.12 -16.86 0.027 0.022 -0.069 1 0 force
particle minecraft:cloud -5.53 65.32 -16.86 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -5.53 65.42 -16.86 0.45 0.2 0.45 0.008 1 force
tp @e[type=minecraft:item_display,tag=drift.onyx] 1.174 65 -24.418 65.16 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0038f,0.0001f,-0.0159f,0.9999f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.4639f,0.2388f,-0.0688f,0.8503f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.1586f,-0.8622f,-0.4414f,0.1914f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.4324f,-0.0057f,0.0118f,0.9016f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.0118f,-0.9016f,0.4324f,0.0057f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.3424f,0.8732f,0.2435f],left_rotation:[0.11f,-0.1513f,0.7758f,0.6027f]}}
particle minecraft:campfire_cosy_smoke 3.25 65.12 -25.2 0.046 0.022 0.001 1 0 force
particle minecraft:cloud 3.25 65.32 -25.2 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 3.25 65.42 -25.2 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke 2.45 65.12 -26.71 0.006 0.022 -0.078 1 0 force
particle minecraft:cloud 2.45 65.32 -26.71 0.35 0.18 0.35 0.02 3 force
