tp @e[type=minecraft:item_display,tag=drift.kaze] -26.003 65 64.477 -91.96 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0022f,0f,0.0079f,1f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.4542f,0.0193f,0.0489f,0.8893f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.0443f,0.8891f,0.4547f,0.0283f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.4532f,0.0059f,0.0117f,0.8913f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.0117f,0.8913f,0.4532f,0.0059f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.3836f,0.8545f,0.1062f],left_rotation:[0.1885f,-0.0072f,0.0528f,0.9806f]}}
tp @e[type=minecraft:item_display,tag=drift.onyx] -43.291 65 64.18 -101.8 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0058f,-0.0001f,0.0166f,0.9998f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.5425f,-0.0896f,0.1221f,0.8263f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.0359f,0.818f,0.5549f,0.1471f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.4532f,0.0059f,0.0117f,0.8913f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.0117f,0.8913f,0.4532f,0.0059f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.3984f,0.8501f,0.24f],left_rotation:[0.0548f,-0.1768f,0.9478f,0.2597f]}}
particle minecraft:campfire_cosy_smoke -46.01 65.12 63.51 -0.064 0.018 -0.047 1 0 force
particle minecraft:cloud -46.01 65.32 63.51 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -45.65 65.12 65.18 -0.051 0.018 0.039 1 0 force
particle minecraft:cloud -45.65 65.32 65.18 0.35 0.18 0.35 0.02 2 force
