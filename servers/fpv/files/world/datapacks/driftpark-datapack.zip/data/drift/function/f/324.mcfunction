tp @e[type=minecraft:item_display,tag=drift.kaze] -27.525 65 -12.178 144.68 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0.0004f,0f,-0.0223f,0.9998f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.2944f,0.266f,-0.0284f,0.9175f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.125f,-0.9255f,-0.2681f,0.2365f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.706f,-0.0092f,0.0093f,0.7081f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.0093f,-0.7081f,0.706f,0.0092f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.3314f,0.8755f,0.1106f],left_rotation:[0.1375f,-0.1329f,0.6501f,0.7354f]}}
particle minecraft:campfire_cosy_smoke -26.68 65.12 -10.42 0.005 0.022 0.036 1 0 force
particle minecraft:cloud -26.68 65.32 -10.42 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -26.68 65.42 -10.42 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke -25.35 65.12 -11.43 0.074 0.022 -0.007 1 0 force
particle minecraft:cloud -25.35 65.32 -11.43 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -25.35 65.42 -11.43 0.45 0.2 0.45 0.008 1 force
tp @e[type=minecraft:item_display,tag=drift.onyx] -17.463 65 -10.336 128.21 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0052f,0.0001f,-0.0223f,0.9997f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.7138f,0.2415f,-0.1909f,0.6291f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.2581f,-0.6526f,-0.6923f,0.1678f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.706f,-0.0092f,0.0093f,0.7081f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.0093f,-0.7081f,0.706f,0.0092f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.3313f,0.8782f,0.241f],left_rotation:[0.1723f,-0.0692f,0.3254f,0.9272f]}}
particle minecraft:campfire_cosy_smoke -16.15 65.12 -8.9 0.017 0.022 0.034 1 0 force
particle minecraft:cloud -16.15 65.32 -8.9 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -16.15 65.42 -8.9 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke -15.13 65.12 -10.27 0.051 0.022 -0.044 1 0 force
particle minecraft:cloud -15.13 65.32 -10.27 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -15.13 65.42 -10.27 0.45 0.2 0.45 0.008 1 force
