tp @e[type=minecraft:item_display,tag=drift.kaze] -96.371 65 -5.935 -25.69 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0059f,-0.0001f,0.0167f,0.9998f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.4878f,-0.0909f,0.1122f,0.8609f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.0223f,0.8539f,0.5f,0.1426f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.4376f,0.0057f,0.0118f,0.8991f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.0118f,0.8991f,0.4376f,0.0057f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.3986f,0.8484f,0.0999f],left_rotation:[0.0668f,-0.1726f,0.9277f,0.3241f]}}
particle minecraft:campfire_cosy_smoke -96.33 65.12 -8.56 0.024 0.017 -0.08 1 0 force
particle minecraft:cloud -96.33 65.32 -8.56 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -97.83 65.12 -7.82 -0.044 0.017 -0.031 1 0 force
particle minecraft:cloud -97.83 65.32 -7.82 0.35 0.18 0.35 0.02 2 force
tp @e[type=minecraft:item_display,tag=drift.onyx] -97.476 65 -20.251 -22.39 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0059f,-0.0001f,0.0185f,0.9998f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.189f,-0.196f,0.0933f,0.9577f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.0069f,0.9532f,0.2107f,0.217f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.4376f,0.0057f,0.0118f,0.8991f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.0118f,0.8991f,0.4376f,0.0057f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4016f,0.8486f,0.2398f],left_rotation:[0.0593f,0.1753f,-0.9186f,0.3492f]}}
particle minecraft:campfire_cosy_smoke -97.09 65.12 -22.83 0.048 0.022 -0.064 1 0 force
particle minecraft:cloud -97.09 65.32 -22.83 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -98.68 65.12 -22.2 -0.026 0.022 -0.027 1 0 force
particle minecraft:cloud -98.68 65.32 -22.2 0.35 0.18 0.35 0.02 3 force
