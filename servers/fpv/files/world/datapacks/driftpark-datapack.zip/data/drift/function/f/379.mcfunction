tp @e[type=minecraft:item_display,tag=drift.kaze] -62.412 65 -43.257 78.83 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0.0037f,0.0001f,0.0223f,0.9997f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.1615f,-0.2713f,0.0089f,0.9488f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.0908f,0.9531f,-0.1338f,0.2559f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.9241f,-0.0121f,0.005f,0.382f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.005f,-0.382f,0.9241f,0.0121f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4079f,0.8419f,0.1163f],left_rotation:[0.1449f,0.1297f,-0.6211f,0.7592f]}}
particle minecraft:campfire_cosy_smoke -60.31 65.12 -42.31 0.042 0.022 0.056 1 0 force
particle minecraft:cloud -60.31 65.32 -42.31 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -60.31 65.42 -42.31 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke -60.6 65.12 -43.95 0.027 0.022 -0.023 1 0 force
particle minecraft:cloud -60.6 65.32 -43.95 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -60.6 65.42 -43.95 0.45 0.2 0.45 0.008 1 force
tp @e[type=minecraft:item_display,tag=drift.onyx] -52.475 65 -36.509 101.41 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0.011f,0.0002f,0.0181f,0.9998f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.7358f,-0.1287f,0.2365f,0.6214f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.1725f,0.5999f,0.7534f,0.2067f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.9241f,-0.0121f,0.005f,0.382f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.005f,-0.382f,0.9241f,0.0121f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4006f,0.8403f,0.2689f],left_rotation:[0.1479f,0.1371f,-0.6394f,0.742f]}}
particle minecraft:campfire_cosy_smoke -50.68 65.12 -34.55 0.021 0.022 0.085 1 0 force
particle minecraft:cloud -50.68 65.32 -34.55 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -50.68 65.42 -34.55 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke -50.27 65.12 -36.21 0.046 0.022 -0.001 1 0 force
particle minecraft:cloud -50.27 65.32 -36.21 0.35 0.18 0.35 0.02 3 force
