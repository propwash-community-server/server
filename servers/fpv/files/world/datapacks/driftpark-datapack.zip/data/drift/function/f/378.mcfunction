tp @e[type=minecraft:item_display,tag=drift.kaze] -61.746 65 -42.906 80.23 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0.0049f,0.0001f,0.0223f,0.9997f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.9345f,-0.1163f,-0.2472f,0.2283f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.2726f,0.2555f,-0.9274f,0.0187f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.6101f,0.008f,0.0104f,0.7923f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.0104f,0.7923f,0.6101f,0.008f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4078f,0.8416f,0.1185f],left_rotation:[0.1479f,0.1281f,-0.6082f,0.7693f]}}
particle minecraft:campfire_cosy_smoke -59.67 65.12 -41.89 0.043 0.022 0.054 1 0 force
particle minecraft:cloud -59.67 65.32 -41.89 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -59.67 65.42 -41.89 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke -59.9 65.12 -43.54 0.029 0.022 -0.019 1 0 force
particle minecraft:cloud -59.9 65.32 -43.54 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -59.9 65.42 -43.54 0.45 0.2 0.45 0.008 1 force
tp @e[type=minecraft:item_display,tag=drift.onyx] -51.847 65 -35.717 103.9 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0.0092f,0.0002f,0.017f,0.9998f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.413f,-0.2526f,-0.0596f,0.873f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.1517f,0.884f,-0.3887f,0.2106f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.6101f,0.008f,0.0104f,0.7923f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.0104f,0.7923f,0.6101f,0.008f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.3988f,0.8422f,0.2657f],left_rotation:[0.1336f,0.1485f,-0.7059f,0.6796f]}}
particle minecraft:campfire_cosy_smoke -50.1 65.12 -33.68 0.018 0.022 0.083 1 0 force
particle minecraft:cloud -50.1 65.32 -33.68 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -50.1 65.42 -33.68 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke -49.62 65.12 -35.32 0.05 0.022 0 1 0 force
particle minecraft:cloud -49.62 65.32 -35.32 0.35 0.18 0.35 0.02 3 force
particle minecraft:flame -48.76 65.24 -34.36 0.05 0.04 0.05 0.02 6 force
particle minecraft:large_smoke -48.76 65.24 -34.36 0.05 0.04 0.05 0.01 2 force
particle minecraft:flame -48.86 65.24 -34.02 0.05 0.04 0.05 0.02 6 force
particle minecraft:large_smoke -48.86 65.24 -34.02 0.05 0.04 0.05 0.01 2 force
