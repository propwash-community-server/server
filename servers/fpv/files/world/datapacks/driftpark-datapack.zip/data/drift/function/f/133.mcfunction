tp @e[type=minecraft:item_display,tag=drift.kaze] 88.634 65 17.824 167.44 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0013f,0f,0.0223f,0.9998f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.8192f,-0.0602f,0.1888f,0.5382f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.1333f,0.5213f,0.83f,0.1467f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.8344f,0.0109f,0.0072f,0.551f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.0072f,0.551f,0.8344f,0.0109f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4079f,0.843f,0.1077f],left_rotation:[0.0269f,0.1876f,-0.9648f,0.1826f]}}
particle minecraft:campfire_cosy_smoke 87.82 65.12 20.3 -0.045 0.022 0.062 1 0 force
particle minecraft:cloud 87.82 65.32 20.3 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke 89.46 65.12 19.96 0.018 0.022 0.048 1 0 force
particle minecraft:cloud 89.46 65.32 19.96 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke 89.46 65.42 19.96 0.45 0.2 0.45 0.008 1 force
tp @e[type=minecraft:item_display,tag=drift.onyx] 84.095 65 31.674 179.52 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0.0023f,0.0001f,0.0223f,0.9997f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.9667f,-0.0796f,-0.2143f,0.1152f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.2276f,-0.1383f,0.9636f,0.0216f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.8344f,0.0109f,0.0072f,0.551f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.0072f,0.551f,0.8344f,0.0109f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4078f,0.8415f,0.254f],left_rotation:[0.0809f,0.1753f,-0.8717f,0.4504f]}}
particle minecraft:campfire_cosy_smoke 82.69 65.12 33.98 -0.062 0.022 0.051 1 0 force
particle minecraft:cloud 82.69 65.32 33.98 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 82.69 65.42 33.98 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke 84.4 65.12 34 0.004 0.022 0.051 1 0 force
particle minecraft:cloud 84.4 65.32 34 0.35 0.18 0.35 0.02 3 force
