tp @e[type=minecraft:item_display,tag=drift.kaze] -87.065 65 27.017 -32.83 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0.0004f,0f,0.0113f,0.9999f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.557f,-0.0947f,-0.0006f,0.8251f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.0873f,0.8297f,-0.5502f,0.0367f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[-0.6146f,-0.008f,0.0103f,0.7887f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[-0.0103f,-0.7887f,0.6146f,0.008f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.3893f,0.8513f,0.1107f],left_rotation:[0.146f,-0.1235f,0.6507f,0.7349f]}}
particle minecraft:campfire_cosy_smoke -87.52 65.12 24.26 0.019 0.013 -0.087 1 0 force
particle minecraft:campfire_cosy_smoke -88.95 65.12 25.13 -0.063 0.013 -0.039 1 0 force
tp @e[type=minecraft:item_display,tag=drift.onyx] -93.204 65 10.07 -24.65 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0058f,-0.0001f,0.0101f,0.9999f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.6878f,-0.0832f,-0.0069f,0.721f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.0828f,0.7257f,-0.6829f,0.0114f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[-0.6146f,-0.008f,0.0103f,0.7887f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[-0.0103f,-0.7887f,0.6146f,0.008f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.3874f,0.8552f,0.24f],left_rotation:[0.155f,-0.1011f,0.5534f,0.8121f]}}
