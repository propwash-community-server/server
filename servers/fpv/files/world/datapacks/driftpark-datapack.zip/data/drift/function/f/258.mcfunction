tp @e[type=minecraft:item_display,tag=drift.kaze] 10.051 65 -39.951 10.61 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0058f,-0.0001f,0.0202f,0.9998f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.9487f,-0.1008f,-0.1821f,0.2379f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.2081f,0.2584f,-0.9434f,0.0016f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.8113f,0.0106f,0.0077f,0.5844f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.0077f,0.5844f,0.8113f,0.0106f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4046f,0.8455f,0.0999f],left_rotation:[0.0439f,0.1798f,-0.9444f,0.2717f]}}
particle minecraft:campfire_cosy_smoke 11.6 65.12 -41.64 0.061 0.022 -0.016 1 0 force
particle minecraft:cloud 11.6 65.32 -41.64 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 11.6 65.42 -41.64 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke 9.96 65.12 -41.95 -0.012 0.022 -0.044 1 0 force
particle minecraft:cloud 9.96 65.32 -41.95 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 9.96 65.42 -41.95 0.45 0.2 0.45 0.008 1 force
tp @e[type=minecraft:item_display,tag=drift.onyx] 17.836 65 -47.101 22.14 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[0.0063f,0.0001f,0.0223f,0.9997f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[-0.7882f,-0.2101f,-0.2103f,0.5388f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.2681f,0.5639f,-0.7705f,0.1284f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.8113f,0.0106f,0.0077f,0.5844f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.0077f,0.5844f,0.8113f,0.0106f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4078f,0.8394f,0.2609f],left_rotation:[0.1744f,0.0916f,-0.4167f,0.8874f]}}
particle minecraft:campfire_cosy_smoke 19.95 65.12 -48.41 0.065 0.022 0.006 1 0 force
particle minecraft:cloud 19.95 65.32 -48.41 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke 19.95 65.42 -48.41 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke 18.39 65.12 -49.11 0.001 0.022 -0.043 1 0 force
particle minecraft:cloud 18.39 65.32 -49.11 0.35 0.18 0.35 0.02 3 force
particle minecraft:flame 19.45 65.24 -49.83 0.05 0.04 0.05 0.02 6 force
particle minecraft:large_smoke 19.45 65.24 -49.83 0.05 0.04 0.05 0.01 2 force
particle minecraft:flame 19.78 65.24 -49.69 0.05 0.04 0.05 0.02 6 force
particle minecraft:large_smoke 19.78 65.24 -49.69 0.05 0.04 0.05 0.01 2 force
