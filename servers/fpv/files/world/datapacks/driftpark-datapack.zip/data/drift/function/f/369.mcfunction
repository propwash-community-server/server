tp @e[type=minecraft:item_display,tag=drift.kaze] -55.759 65 -38.6 96.21 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[0.0112f,0.0002f,0.0212f,0.9997f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[-0.0719f,-0.2647f,0.0346f,0.961f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[0.0662f,0.9627f,-0.0445f,0.2586f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.9941f,0.013f,0.0014f,0.1072f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.0014f,0.1072f,0.9941f,0.013f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.406f,0.8409f,0.1293f],left_rotation:[0.1445f,0.1409f,-0.6534f,0.7296f]}}
particle minecraft:campfire_cosy_smoke -53.91 65.12 -36.96 0.018 0.022 0.067 1 0 force
particle minecraft:cloud -53.91 65.32 -36.96 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -53.91 65.42 -36.96 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke -53.67 65.12 -38.62 0.048 0.022 -0.006 1 0 force
particle minecraft:cloud -53.67 65.32 -38.62 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -53.67 65.42 -38.62 0.45 0.2 0.45 0.008 1 force
tp @e[type=minecraft:item_display,tag=drift.onyx] -46.584 65 -28.233 129.63 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0059f,0f,0.0007f,1f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.3176f,-0.0799f,0.0825f,0.9413f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[0.016f,0.9378f,0.3277f,0.1137f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.9941f,0.013f,0.0014f,0.1072f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.0014f,0.1072f,0.9941f,0.013f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.3713f,0.8623f,0.2399f],left_rotation:[0.1116f,-0.1476f,0.7846f,0.5917f]}}
particle minecraft:campfire_cosy_smoke -45.6 65.12 -25.84 0.003 0.014 0.07 1 0 force
particle minecraft:campfire_cosy_smoke -44.44 65.12 -27.09 0.06 0.014 0.005 1 0 force
