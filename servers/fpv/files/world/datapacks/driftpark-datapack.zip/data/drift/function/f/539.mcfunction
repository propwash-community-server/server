tp @e[type=minecraft:item_display,tag=drift.kaze] -54.055 65 61.443 -96.93 0
data merge entity 425483f9-2934-53dd-805b-82336df4bdbc {start_interpolation:0,transformation:{left_rotation:[-0.0059f,-0.0001f,0.0184f,0.9998f]}}
data merge entity 77d4edec-4f89-5806-8a73-69da291cf64a {start_interpolation:0,transformation:{left_rotation:[0.4882f,-0.1214f,0.1305f,0.8543f]}}
data merge entity a18c987f-26df-590a-b51c-8f6379e10218 {start_interpolation:0,transformation:{left_rotation:[-0.0415f,0.8453f,0.5037f,0.1734f]}}
data merge entity 8bd36e4e-1a75-51ba-b224-63055ff644c2 {start_interpolation:0,transformation:{left_rotation:[0.5041f,0.0066f,0.0113f,0.8635f]}}
data merge entity 7b07c259-0b81-5b46-b286-5b101f183bf9 {start_interpolation:0,transformation:{left_rotation:[0.0113f,0.8635f,0.5041f,0.0066f]}}
data merge entity 04fc5281-333c-5c0d-ba69-0b625cbc7206 {start_interpolation:0,transformation:{translation:[-0.4015f,0.847f,0.0999f],left_rotation:[0.0081f,-0.1848f,0.9827f,0.007f]}}
particle minecraft:campfire_cosy_smoke -56.45 65.12 60.46 -0.054 0.02 -0.045 1 0 force
particle minecraft:cloud -56.45 65.32 60.46 0.35 0.18 0.35 0.02 2 force
particle minecraft:campfire_cosy_smoke -56.45 65.42 60.46 0.45 0.2 0.45 0.008 1 force
particle minecraft:campfire_cosy_smoke -56.27 65.12 62.12 -0.041 0.02 0.02 1 0 force
particle minecraft:cloud -56.27 65.32 62.12 0.35 0.18 0.35 0.02 2 force
tp @e[type=minecraft:item_display,tag=drift.onyx] -67.1 65 56.794 -90.51 0
data merge entity 6ed9ae07-2229-5b6f-8ff8-189708e0cf64 {start_interpolation:0,transformation:{left_rotation:[-0.0059f,-0.0001f,0.0214f,0.9998f]}}
data merge entity f74f363c-8714-5fe5-bb64-beafe6b6ac28 {start_interpolation:0,transformation:{left_rotation:[0.4703f,-0.1755f,0.1585f,0.8502f]}}
data merge entity 97428e5f-5a51-575c-8305-607c4b0f68cb {start_interpolation:0,transformation:{left_rotation:[-0.07f,0.8383f,0.4913f,0.2259f]}}
data merge entity 186c432f-da2b-5bec-ba8a-9d97f056504e {start_interpolation:0,transformation:{left_rotation:[0.5041f,0.0066f,0.0113f,0.8635f]}}
data merge entity b7fef3cd-3066-54f8-9318-2747261e9dd9 {start_interpolation:0,transformation:{left_rotation:[0.0113f,0.8635f,0.5041f,0.0066f]}}
data merge entity 0d17ad00-82d8-5739-af58-9e93f268e98c {start_interpolation:0,transformation:{translation:[-0.4067f,0.8462f,0.2399f],left_rotation:[0.09f,0.1617f,-0.8374f,0.5142f]}}
particle minecraft:campfire_cosy_smoke -69.29 65.12 55.44 -0.034 0.022 -0.075 1 0 force
particle minecraft:cloud -69.29 65.32 55.44 0.35 0.18 0.35 0.02 3 force
particle minecraft:campfire_cosy_smoke -69.3 65.12 57.15 -0.032 0.022 0.023 1 0 force
particle minecraft:cloud -69.3 65.32 57.15 0.35 0.18 0.35 0.02 3 force
